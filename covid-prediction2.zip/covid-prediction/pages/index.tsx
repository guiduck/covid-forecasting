import React from 'react';
import Dashboard from '../src/components/Dashboard';

const Home: React.FC = () => {
  return (
    <Dashboard />
  )
}

export default Home;