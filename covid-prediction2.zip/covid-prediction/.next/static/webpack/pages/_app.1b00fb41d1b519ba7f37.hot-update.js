"use strict";
self["webpackHotUpdate_N_E"]("pages/_app",{

/***/ "./src/utils/scaler.ts":
/*!*****************************!*\
  !*** ./src/utils/scaler.ts ***!
  \*****************************/
/***/ (function(module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* module decorator */ module = __webpack_require__.hmd(module);
var X_min = 0;
var X_max = 0;
var min_ = 0;
var max_ = 1;
var data = {
  X_max: X_max,
  X_min: X_min,
  max_: max_,
  min_: min_
};

function fit(X) {
  var min = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 0;
  var max = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : 1;
  X_max = Math.max.apply(null, X);
  X_min = Math.min.apply(null, X);
  min_ = min;
  max_ = max;
  data = {
    X_max: X_max,
    X_min: X_min,
    max_: max_,
    min_: min_
  };
  var X_minArr = X.map(function (values) {
    return values - X_min;
  }); // X_std = (X - X.min()) / (X.max() - X.min())

  var X_std = X_minArr.map(function (values) {
    return values / (X_max - X_min);
  }); // X_scaled = X_std * (max - min) + min

  var X_scaled = X_std.map(function (values) {
    return values * (max - min) + min;
  });
  return X_scaled;
}

function fit_transform(data) {
  var min = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 0;
  var max = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : 1;
  var train_scaled = fit(data, min, max);
  return train_scaled;
}

function inverse_transform(input) {
  var min = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 0;
  var max = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : 1;
  var fit = data;
  console.log(fit);
  var X = input.map(function (values) {
    return (values - min) / (max - min);
  });
  var X_ = X.map(function (values) {
    return values * (fit.X_max - fit.X_min) + fit.X_min;
  });
  return X_;
}

/* harmony default export */ __webpack_exports__["default"] = ({
  fit_transform: fit_transform,
  inverse_transform: inverse_transform
});

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.id);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }


/***/ })

});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic3RhdGljL3dlYnBhY2svcGFnZXMvX2FwcC4xYjAwZmI0MWQxYjUxOWJhN2YzNy5ob3QtdXBkYXRlLmpzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7O0FBQUEsSUFBSUEsS0FBSyxHQUFHLENBQVo7QUFDQSxJQUFJQyxLQUFLLEdBQUcsQ0FBWjtBQUNBLElBQUlDLElBQUksR0FBRyxDQUFYO0FBQ0EsSUFBSUMsSUFBSSxHQUFHLENBQVg7QUFFQSxJQUFJQyxJQUFJLEdBQUc7QUFBRUgsRUFBQUEsS0FBSyxFQUFFQSxLQUFUO0FBQWdCRCxFQUFBQSxLQUFLLEVBQUVBLEtBQXZCO0FBQThCRyxFQUFBQSxJQUFJLEVBQUVBLElBQXBDO0FBQTBDRCxFQUFBQSxJQUFJLEVBQUVBO0FBQWhELENBQVg7O0FBRUEsU0FBU0csR0FBVCxDQUFhQyxDQUFiLEVBQWtDO0FBQUEsTUFBbEJDLEdBQWtCLHVFQUFaLENBQVk7QUFBQSxNQUFUQyxHQUFTLHVFQUFILENBQUc7QUFDaENQLEVBQUFBLEtBQUssR0FBR1EsSUFBSSxDQUFDRCxHQUFMLENBQVNFLEtBQVQsQ0FBZSxJQUFmLEVBQXFCSixDQUFyQixDQUFSO0FBQ0FOLEVBQUFBLEtBQUssR0FBR1MsSUFBSSxDQUFDRixHQUFMLENBQVNHLEtBQVQsQ0FBZSxJQUFmLEVBQXFCSixDQUFyQixDQUFSO0FBQ0FKLEVBQUFBLElBQUksR0FBR0ssR0FBUDtBQUNBSixFQUFBQSxJQUFJLEdBQUdLLEdBQVA7QUFFQUosRUFBQUEsSUFBSSxHQUFHO0FBQUVILElBQUFBLEtBQUssRUFBRUEsS0FBVDtBQUFnQkQsSUFBQUEsS0FBSyxFQUFFQSxLQUF2QjtBQUE4QkcsSUFBQUEsSUFBSSxFQUFFQSxJQUFwQztBQUEwQ0QsSUFBQUEsSUFBSSxFQUFFQTtBQUFoRCxHQUFQO0FBRUEsTUFBSVMsUUFBUSxHQUFHTCxDQUFDLENBQUNNLEdBQUYsQ0FBTSxVQUFVQyxNQUFWLEVBQWtCO0FBQ3JDLFdBQU9BLE1BQU0sR0FBR2IsS0FBaEI7QUFDRCxHQUZjLENBQWYsQ0FSZ0MsQ0FXaEM7O0FBQ0EsTUFBSWMsS0FBSyxHQUFHSCxRQUFRLENBQUNDLEdBQVQsQ0FBYSxVQUFVQyxNQUFWLEVBQWtCO0FBQ3pDLFdBQU9BLE1BQU0sSUFBSVosS0FBSyxHQUFHRCxLQUFaLENBQWI7QUFDRCxHQUZXLENBQVosQ0FaZ0MsQ0FlaEM7O0FBQ0EsTUFBSWUsUUFBUSxHQUFHRCxLQUFLLENBQUNGLEdBQU4sQ0FBVSxVQUFVQyxNQUFWLEVBQWtCO0FBQ3pDLFdBQU9BLE1BQU0sSUFBSUwsR0FBRyxHQUFHRCxHQUFWLENBQU4sR0FBdUJBLEdBQTlCO0FBQ0QsR0FGYyxDQUFmO0FBSUEsU0FBT1EsUUFBUDtBQUNEOztBQUVELFNBQVNDLGFBQVQsQ0FBdUJaLElBQXZCLEVBQStDO0FBQUEsTUFBbEJHLEdBQWtCLHVFQUFaLENBQVk7QUFBQSxNQUFUQyxHQUFTLHVFQUFILENBQUc7QUFDN0MsTUFBSVMsWUFBWSxHQUFHWixHQUFHLENBQUNELElBQUQsRUFBT0csR0FBUCxFQUFZQyxHQUFaLENBQXRCO0FBR0EsU0FBT1MsWUFBUDtBQUNEOztBQUVELFNBQVNDLGlCQUFULENBQTJCQyxLQUEzQixFQUFvRDtBQUFBLE1BQWxCWixHQUFrQix1RUFBWixDQUFZO0FBQUEsTUFBVEMsR0FBUyx1RUFBSCxDQUFHO0FBQ2xELE1BQUlILEdBQUcsR0FBR0QsSUFBVjtBQUNBZ0IsRUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVloQixHQUFaO0FBRUEsTUFBSUMsQ0FBQyxHQUFHYSxLQUFLLENBQUNQLEdBQU4sQ0FBVSxVQUFVQyxNQUFWLEVBQWtCO0FBQ2xDLFdBQU8sQ0FBQ0EsTUFBTSxHQUFHTixHQUFWLEtBQWtCQyxHQUFHLEdBQUdELEdBQXhCLENBQVA7QUFDRCxHQUZPLENBQVI7QUFHQSxNQUFJZSxFQUFFLEdBQUdoQixDQUFDLENBQUNNLEdBQUYsQ0FBTSxVQUFVQyxNQUFWLEVBQWtCO0FBQy9CLFdBQU9BLE1BQU0sSUFBSVIsR0FBRyxDQUFDSixLQUFKLEdBQVlJLEdBQUcsQ0FBQ0wsS0FBcEIsQ0FBTixHQUFtQ0ssR0FBRyxDQUFDTCxLQUE5QztBQUNELEdBRlEsQ0FBVDtBQUlBLFNBQU9zQixFQUFQO0FBQ0Q7O0FBRUQsK0RBQWU7QUFBRU4sRUFBQUEsYUFBYSxFQUFiQSxhQUFGO0FBQWlCRSxFQUFBQSxpQkFBaUIsRUFBakJBO0FBQWpCLENBQWYiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vc3JjL3V0aWxzL3NjYWxlci50cyJdLCJzb3VyY2VzQ29udGVudCI6WyJ2YXIgWF9taW4gPSAwO1xudmFyIFhfbWF4ID0gMDtcbnZhciBtaW5fID0gMDtcbnZhciBtYXhfID0gMTtcblxudmFyIGRhdGEgPSB7IFhfbWF4OiBYX21heCwgWF9taW46IFhfbWluLCBtYXhfOiBtYXhfLCBtaW5fOiBtaW5fIH07XG5cbmZ1bmN0aW9uIGZpdChYLCBtaW4gPSAwLCBtYXggPSAxKSB7XG4gIFhfbWF4ID0gTWF0aC5tYXguYXBwbHkobnVsbCwgWCk7XG4gIFhfbWluID0gTWF0aC5taW4uYXBwbHkobnVsbCwgWCk7XG4gIG1pbl8gPSBtaW47XG4gIG1heF8gPSBtYXg7XG5cbiAgZGF0YSA9IHsgWF9tYXg6IFhfbWF4LCBYX21pbjogWF9taW4sIG1heF86IG1heF8sIG1pbl86IG1pbl8gfTtcblxuICB2YXIgWF9taW5BcnIgPSBYLm1hcChmdW5jdGlvbiAodmFsdWVzKSB7XG4gICAgcmV0dXJuIHZhbHVlcyAtIFhfbWluO1xuICB9KTtcbiAgLy8gWF9zdGQgPSAoWCAtIFgubWluKCkpIC8gKFgubWF4KCkgLSBYLm1pbigpKVxuICB2YXIgWF9zdGQgPSBYX21pbkFyci5tYXAoZnVuY3Rpb24gKHZhbHVlcykge1xuICAgIHJldHVybiB2YWx1ZXMgLyAoWF9tYXggLSBYX21pbik7XG4gIH0pO1xuICAvLyBYX3NjYWxlZCA9IFhfc3RkICogKG1heCAtIG1pbikgKyBtaW5cbiAgdmFyIFhfc2NhbGVkID0gWF9zdGQubWFwKGZ1bmN0aW9uICh2YWx1ZXMpIHtcbiAgICByZXR1cm4gdmFsdWVzICogKG1heCAtIG1pbikgKyBtaW47XG4gIH0pO1xuXG4gIHJldHVybiBYX3NjYWxlZDtcbn1cblxuZnVuY3Rpb24gZml0X3RyYW5zZm9ybShkYXRhLCBtaW4gPSAwLCBtYXggPSAxKSB7XG4gIHZhciB0cmFpbl9zY2FsZWQgPSBmaXQoZGF0YSwgbWluLCBtYXgpO1xuXG5cbiAgcmV0dXJuIHRyYWluX3NjYWxlZDtcbn1cblxuZnVuY3Rpb24gaW52ZXJzZV90cmFuc2Zvcm0oaW5wdXQsIG1pbiA9IDAsIG1heCA9IDEpIHtcbiAgdmFyIGZpdCA9IGRhdGE7XG4gIGNvbnNvbGUubG9nKGZpdClcblxuICB2YXIgWCA9IGlucHV0Lm1hcChmdW5jdGlvbiAodmFsdWVzKSB7XG4gICAgcmV0dXJuICh2YWx1ZXMgLSBtaW4pIC8gKG1heCAtIG1pbik7XG4gIH0pO1xuICB2YXIgWF8gPSBYLm1hcChmdW5jdGlvbiAodmFsdWVzKSB7XG4gICAgcmV0dXJuIHZhbHVlcyAqIChmaXQuWF9tYXggLSBmaXQuWF9taW4pICsgZml0LlhfbWluO1xuICB9KTtcblxuICByZXR1cm4gWF87XG59XG5cbmV4cG9ydCBkZWZhdWx0IHsgZml0X3RyYW5zZm9ybSwgaW52ZXJzZV90cmFuc2Zvcm0gfTsiXSwibmFtZXMiOlsiWF9taW4iLCJYX21heCIsIm1pbl8iLCJtYXhfIiwiZGF0YSIsImZpdCIsIlgiLCJtaW4iLCJtYXgiLCJNYXRoIiwiYXBwbHkiLCJYX21pbkFyciIsIm1hcCIsInZhbHVlcyIsIlhfc3RkIiwiWF9zY2FsZWQiLCJmaXRfdHJhbnNmb3JtIiwidHJhaW5fc2NhbGVkIiwiaW52ZXJzZV90cmFuc2Zvcm0iLCJpbnB1dCIsImNvbnNvbGUiLCJsb2ciLCJYXyJdLCJzb3VyY2VSb290IjoiIn0=