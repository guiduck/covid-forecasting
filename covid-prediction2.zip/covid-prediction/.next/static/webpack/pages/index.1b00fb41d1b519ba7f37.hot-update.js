"use strict";
self["webpackHotUpdate_N_E"]("pages/index",{

/***/ "./src/utils/scaler.ts":
/*!*****************************!*\
  !*** ./src/utils/scaler.ts ***!
  \*****************************/
/***/ (function(module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* module decorator */ module = __webpack_require__.hmd(module);
var X_min = 0;
var X_max = 0;
var min_ = 0;
var max_ = 1;
var data = {
  X_max: X_max,
  X_min: X_min,
  max_: max_,
  min_: min_
};

function fit(X) {
  var min = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 0;
  var max = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : 1;
  X_max = Math.max.apply(null, X);
  X_min = Math.min.apply(null, X);
  min_ = min;
  max_ = max;
  data = {
    X_max: X_max,
    X_min: X_min,
    max_: max_,
    min_: min_
  };
  var X_minArr = X.map(function (values) {
    return values - X_min;
  }); // X_std = (X - X.min()) / (X.max() - X.min())

  var X_std = X_minArr.map(function (values) {
    return values / (X_max - X_min);
  }); // X_scaled = X_std * (max - min) + min

  var X_scaled = X_std.map(function (values) {
    return values * (max - min) + min;
  });
  return X_scaled;
}

function fit_transform(data) {
  var min = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 0;
  var max = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : 1;
  var train_scaled = fit(data, min, max);
  return train_scaled;
}

function inverse_transform(input) {
  var min = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 0;
  var max = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : 1;
  var fit = data;
  console.log(fit);
  var X = input.map(function (values) {
    return (values - min) / (max - min);
  });
  var X_ = X.map(function (values) {
    return values * (fit.X_max - fit.X_min) + fit.X_min;
  });
  return X_;
}

/* harmony default export */ __webpack_exports__["default"] = ({
  fit_transform: fit_transform,
  inverse_transform: inverse_transform
});

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.id);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }


/***/ })

});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic3RhdGljL3dlYnBhY2svcGFnZXMvaW5kZXguMWIwMGZiNDFkMWI1MTliYTdmMzcuaG90LXVwZGF0ZS5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7OztBQUFBLElBQUlBLEtBQUssR0FBRyxDQUFaO0FBQ0EsSUFBSUMsS0FBSyxHQUFHLENBQVo7QUFDQSxJQUFJQyxJQUFJLEdBQUcsQ0FBWDtBQUNBLElBQUlDLElBQUksR0FBRyxDQUFYO0FBRUEsSUFBSUMsSUFBSSxHQUFHO0FBQUVILEVBQUFBLEtBQUssRUFBRUEsS0FBVDtBQUFnQkQsRUFBQUEsS0FBSyxFQUFFQSxLQUF2QjtBQUE4QkcsRUFBQUEsSUFBSSxFQUFFQSxJQUFwQztBQUEwQ0QsRUFBQUEsSUFBSSxFQUFFQTtBQUFoRCxDQUFYOztBQUVBLFNBQVNHLEdBQVQsQ0FBYUMsQ0FBYixFQUFrQztBQUFBLE1BQWxCQyxHQUFrQix1RUFBWixDQUFZO0FBQUEsTUFBVEMsR0FBUyx1RUFBSCxDQUFHO0FBQ2hDUCxFQUFBQSxLQUFLLEdBQUdRLElBQUksQ0FBQ0QsR0FBTCxDQUFTRSxLQUFULENBQWUsSUFBZixFQUFxQkosQ0FBckIsQ0FBUjtBQUNBTixFQUFBQSxLQUFLLEdBQUdTLElBQUksQ0FBQ0YsR0FBTCxDQUFTRyxLQUFULENBQWUsSUFBZixFQUFxQkosQ0FBckIsQ0FBUjtBQUNBSixFQUFBQSxJQUFJLEdBQUdLLEdBQVA7QUFDQUosRUFBQUEsSUFBSSxHQUFHSyxHQUFQO0FBRUFKLEVBQUFBLElBQUksR0FBRztBQUFFSCxJQUFBQSxLQUFLLEVBQUVBLEtBQVQ7QUFBZ0JELElBQUFBLEtBQUssRUFBRUEsS0FBdkI7QUFBOEJHLElBQUFBLElBQUksRUFBRUEsSUFBcEM7QUFBMENELElBQUFBLElBQUksRUFBRUE7QUFBaEQsR0FBUDtBQUVBLE1BQUlTLFFBQVEsR0FBR0wsQ0FBQyxDQUFDTSxHQUFGLENBQU0sVUFBVUMsTUFBVixFQUFrQjtBQUNyQyxXQUFPQSxNQUFNLEdBQUdiLEtBQWhCO0FBQ0QsR0FGYyxDQUFmLENBUmdDLENBV2hDOztBQUNBLE1BQUljLEtBQUssR0FBR0gsUUFBUSxDQUFDQyxHQUFULENBQWEsVUFBVUMsTUFBVixFQUFrQjtBQUN6QyxXQUFPQSxNQUFNLElBQUlaLEtBQUssR0FBR0QsS0FBWixDQUFiO0FBQ0QsR0FGVyxDQUFaLENBWmdDLENBZWhDOztBQUNBLE1BQUllLFFBQVEsR0FBR0QsS0FBSyxDQUFDRixHQUFOLENBQVUsVUFBVUMsTUFBVixFQUFrQjtBQUN6QyxXQUFPQSxNQUFNLElBQUlMLEdBQUcsR0FBR0QsR0FBVixDQUFOLEdBQXVCQSxHQUE5QjtBQUNELEdBRmMsQ0FBZjtBQUlBLFNBQU9RLFFBQVA7QUFDRDs7QUFFRCxTQUFTQyxhQUFULENBQXVCWixJQUF2QixFQUErQztBQUFBLE1BQWxCRyxHQUFrQix1RUFBWixDQUFZO0FBQUEsTUFBVEMsR0FBUyx1RUFBSCxDQUFHO0FBQzdDLE1BQUlTLFlBQVksR0FBR1osR0FBRyxDQUFDRCxJQUFELEVBQU9HLEdBQVAsRUFBWUMsR0FBWixDQUF0QjtBQUdBLFNBQU9TLFlBQVA7QUFDRDs7QUFFRCxTQUFTQyxpQkFBVCxDQUEyQkMsS0FBM0IsRUFBb0Q7QUFBQSxNQUFsQlosR0FBa0IsdUVBQVosQ0FBWTtBQUFBLE1BQVRDLEdBQVMsdUVBQUgsQ0FBRztBQUNsRCxNQUFJSCxHQUFHLEdBQUdELElBQVY7QUFDQWdCLEVBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZaEIsR0FBWjtBQUVBLE1BQUlDLENBQUMsR0FBR2EsS0FBSyxDQUFDUCxHQUFOLENBQVUsVUFBVUMsTUFBVixFQUFrQjtBQUNsQyxXQUFPLENBQUNBLE1BQU0sR0FBR04sR0FBVixLQUFrQkMsR0FBRyxHQUFHRCxHQUF4QixDQUFQO0FBQ0QsR0FGTyxDQUFSO0FBR0EsTUFBSWUsRUFBRSxHQUFHaEIsQ0FBQyxDQUFDTSxHQUFGLENBQU0sVUFBVUMsTUFBVixFQUFrQjtBQUMvQixXQUFPQSxNQUFNLElBQUlSLEdBQUcsQ0FBQ0osS0FBSixHQUFZSSxHQUFHLENBQUNMLEtBQXBCLENBQU4sR0FBbUNLLEdBQUcsQ0FBQ0wsS0FBOUM7QUFDRCxHQUZRLENBQVQ7QUFJQSxTQUFPc0IsRUFBUDtBQUNEOztBQUVELCtEQUFlO0FBQUVOLEVBQUFBLGFBQWEsRUFBYkEsYUFBRjtBQUFpQkUsRUFBQUEsaUJBQWlCLEVBQWpCQTtBQUFqQixDQUFmIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vX05fRS8uL3NyYy91dGlscy9zY2FsZXIudHMiXSwic291cmNlc0NvbnRlbnQiOlsidmFyIFhfbWluID0gMDtcbnZhciBYX21heCA9IDA7XG52YXIgbWluXyA9IDA7XG52YXIgbWF4XyA9IDE7XG5cbnZhciBkYXRhID0geyBYX21heDogWF9tYXgsIFhfbWluOiBYX21pbiwgbWF4XzogbWF4XywgbWluXzogbWluXyB9O1xuXG5mdW5jdGlvbiBmaXQoWCwgbWluID0gMCwgbWF4ID0gMSkge1xuICBYX21heCA9IE1hdGgubWF4LmFwcGx5KG51bGwsIFgpO1xuICBYX21pbiA9IE1hdGgubWluLmFwcGx5KG51bGwsIFgpO1xuICBtaW5fID0gbWluO1xuICBtYXhfID0gbWF4O1xuXG4gIGRhdGEgPSB7IFhfbWF4OiBYX21heCwgWF9taW46IFhfbWluLCBtYXhfOiBtYXhfLCBtaW5fOiBtaW5fIH07XG5cbiAgdmFyIFhfbWluQXJyID0gWC5tYXAoZnVuY3Rpb24gKHZhbHVlcykge1xuICAgIHJldHVybiB2YWx1ZXMgLSBYX21pbjtcbiAgfSk7XG4gIC8vIFhfc3RkID0gKFggLSBYLm1pbigpKSAvIChYLm1heCgpIC0gWC5taW4oKSlcbiAgdmFyIFhfc3RkID0gWF9taW5BcnIubWFwKGZ1bmN0aW9uICh2YWx1ZXMpIHtcbiAgICByZXR1cm4gdmFsdWVzIC8gKFhfbWF4IC0gWF9taW4pO1xuICB9KTtcbiAgLy8gWF9zY2FsZWQgPSBYX3N0ZCAqIChtYXggLSBtaW4pICsgbWluXG4gIHZhciBYX3NjYWxlZCA9IFhfc3RkLm1hcChmdW5jdGlvbiAodmFsdWVzKSB7XG4gICAgcmV0dXJuIHZhbHVlcyAqIChtYXggLSBtaW4pICsgbWluO1xuICB9KTtcblxuICByZXR1cm4gWF9zY2FsZWQ7XG59XG5cbmZ1bmN0aW9uIGZpdF90cmFuc2Zvcm0oZGF0YSwgbWluID0gMCwgbWF4ID0gMSkge1xuICB2YXIgdHJhaW5fc2NhbGVkID0gZml0KGRhdGEsIG1pbiwgbWF4KTtcblxuXG4gIHJldHVybiB0cmFpbl9zY2FsZWQ7XG59XG5cbmZ1bmN0aW9uIGludmVyc2VfdHJhbnNmb3JtKGlucHV0LCBtaW4gPSAwLCBtYXggPSAxKSB7XG4gIHZhciBmaXQgPSBkYXRhO1xuICBjb25zb2xlLmxvZyhmaXQpXG5cbiAgdmFyIFggPSBpbnB1dC5tYXAoZnVuY3Rpb24gKHZhbHVlcykge1xuICAgIHJldHVybiAodmFsdWVzIC0gbWluKSAvIChtYXggLSBtaW4pO1xuICB9KTtcbiAgdmFyIFhfID0gWC5tYXAoZnVuY3Rpb24gKHZhbHVlcykge1xuICAgIHJldHVybiB2YWx1ZXMgKiAoZml0LlhfbWF4IC0gZml0LlhfbWluKSArIGZpdC5YX21pbjtcbiAgfSk7XG5cbiAgcmV0dXJuIFhfO1xufVxuXG5leHBvcnQgZGVmYXVsdCB7IGZpdF90cmFuc2Zvcm0sIGludmVyc2VfdHJhbnNmb3JtIH07Il0sIm5hbWVzIjpbIlhfbWluIiwiWF9tYXgiLCJtaW5fIiwibWF4XyIsImRhdGEiLCJmaXQiLCJYIiwibWluIiwibWF4IiwiTWF0aCIsImFwcGx5IiwiWF9taW5BcnIiLCJtYXAiLCJ2YWx1ZXMiLCJYX3N0ZCIsIlhfc2NhbGVkIiwiZml0X3RyYW5zZm9ybSIsInRyYWluX3NjYWxlZCIsImludmVyc2VfdHJhbnNmb3JtIiwiaW5wdXQiLCJjb25zb2xlIiwibG9nIiwiWF8iXSwic291cmNlUm9vdCI6IiJ9