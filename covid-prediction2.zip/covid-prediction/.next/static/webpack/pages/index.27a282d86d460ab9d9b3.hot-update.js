"use strict";
self["webpackHotUpdate_N_E"]("pages/index",{

/***/ "./src/components/Dashboard/index.tsx":
/*!********************************************!*\
  !*** ./src/components/Dashboard/index.tsx ***!
  \********************************************/
/***/ (function(module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _chakra_ui_react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @chakra-ui/react */ "./node_modules/@chakra-ui/react/dist/chakra-ui-react.esm.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _Chart__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../Chart */ "./src/components/Chart/index.tsx");
/* harmony import */ var _context_BrainContext__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../context/BrainContext */ "./src/context/BrainContext.tsx");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__);
/* module decorator */ module = __webpack_require__.hmd(module);
var _jsxFileName = "/home/vittis/dev/github/covid-prediction/src/components/Dashboard/index.tsx",
    _this = undefined,
    _s = $RefreshSig$();







var Dashboard = function Dashboard() {
  _s();

  var _useBrainContext = (0,_context_BrainContext__WEBPACK_IMPORTED_MODULE_2__.useBrainContext)(),
      dailyData = _useBrainContext.dailyData,
      forecast = _useBrainContext.forecast,
      trainingData = _useBrainContext.trainingData,
      daysInput = _useBrainContext.daysInput,
      setDaysInput = _useBrainContext.setDaysInput;

  var handleForecast = function handleForecast(e) {
    console.log(daysInput);
    forecast(trainingData, parseInt(daysInput, 10));
  };

  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_4__.Flex, {
    direction: "column",
    width: "100vw",
    justifyContent: "center",
    children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_4__.Flex, {
      direction: "column",
      alignItems: "center",
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_4__.Heading, {
        p: 10,
        size: "xl",
        children: "How many days ahead would you like to predict? "
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 25,
        columnNumber: 9
      }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_4__.Flex, {
        children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_4__.Input, {
          width: "200px",
          placeholder: "days to predict",
          type: "number",
          value: daysInput,
          onChange: function onChange(e) {
            return setDaysInput(e.target.value);
          }
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 27,
          columnNumber: 11
        }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_4__.Button, {
          ml: "1.5",
          onClick: handleForecast,
          children: "Train AI"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 34,
          columnNumber: 11
        }, _this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 26,
        columnNumber: 9
      }, _this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 24,
      columnNumber: 7
    }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_4__.Box, {
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)(_Chart__WEBPACK_IMPORTED_MODULE_1__.default, {
        dailyData: dailyData
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 38,
        columnNumber: 9
      }, _this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 37,
      columnNumber: 7
    }, _this)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 23,
    columnNumber: 5
  }, _this);
};

_s(Dashboard, "OuKT1dXiAsKsruOdN9I9yQs7Mns=", false, function () {
  return [_context_BrainContext__WEBPACK_IMPORTED_MODULE_2__.useBrainContext];
});

_c = Dashboard;
/* harmony default export */ __webpack_exports__["default"] = (Dashboard);

var _c;

$RefreshReg$(_c, "Dashboard");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.id);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }


/***/ })

});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic3RhdGljL3dlYnBhY2svcGFnZXMvaW5kZXguMjdhMjgyZDg2ZDQ2MGFiOWQ5YjMuaG90LXVwZGF0ZS5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7QUFDQTtBQUNBO0FBQ0E7OztBQVNBLElBQU1RLFNBQW1CLEdBQUcsU0FBdEJBLFNBQXNCLEdBQU07QUFBQTs7QUFFaEMseUJBQXVFRCxzRUFBZSxFQUF0RjtBQUFBLE1BQVFFLFNBQVIsb0JBQVFBLFNBQVI7QUFBQSxNQUFtQkMsUUFBbkIsb0JBQW1CQSxRQUFuQjtBQUFBLE1BQTZCQyxZQUE3QixvQkFBNkJBLFlBQTdCO0FBQUEsTUFBMkNDLFNBQTNDLG9CQUEyQ0EsU0FBM0M7QUFBQSxNQUFzREMsWUFBdEQsb0JBQXNEQSxZQUF0RDs7QUFFQSxNQUFNQyxjQUFjLEdBQUcsU0FBakJBLGNBQWlCLENBQUNDLENBQUQsRUFBTztBQUM1QkMsSUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVlMLFNBQVo7QUFDQUYsSUFBQUEsUUFBUSxDQUFDQyxZQUFELEVBQWVPLFFBQVEsQ0FBQ04sU0FBRCxFQUFZLEVBQVosQ0FBdkIsQ0FBUjtBQUNELEdBSEQ7O0FBS0Esc0JBQ0UsOERBQUMsa0RBQUQ7QUFBTSxhQUFTLEVBQUMsUUFBaEI7QUFBeUIsU0FBSyxFQUFDLE9BQS9CO0FBQXVDLGtCQUFjLEVBQUMsUUFBdEQ7QUFBQSw0QkFDRSw4REFBQyxrREFBRDtBQUFNLGVBQVMsRUFBQyxRQUFoQjtBQUF5QixnQkFBVSxFQUFDLFFBQXBDO0FBQUEsOEJBQ0UsOERBQUMscURBQUQ7QUFBUyxTQUFDLEVBQUUsRUFBWjtBQUFnQixZQUFJLEVBQUMsSUFBckI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFERixlQUVFLDhEQUFDLGtEQUFEO0FBQUEsZ0NBQ0UsOERBQUMsbURBQUQ7QUFDRSxlQUFLLEVBQUMsT0FEUjtBQUVFLHFCQUFXLEVBQUMsaUJBRmQ7QUFHRSxjQUFJLEVBQUMsUUFIUDtBQUlFLGVBQUssRUFBRUEsU0FKVDtBQUtFLGtCQUFRLEVBQUUsa0JBQUNHLENBQUQ7QUFBQSxtQkFBT0YsWUFBWSxDQUFDRSxDQUFDLENBQUNJLE1BQUYsQ0FBU0MsS0FBVixDQUFuQjtBQUFBO0FBTFo7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFERixlQVFFLDhEQUFDLG9EQUFEO0FBQVEsWUFBRSxFQUFDLEtBQVg7QUFBaUIsaUJBQU8sRUFBRU4sY0FBMUI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBUkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBREYsZUFjRSw4REFBQyxpREFBRDtBQUFBLDZCQUNFLDhEQUFDLDJDQUFEO0FBQU8saUJBQVMsRUFBRUw7QUFBbEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFkRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FERjtBQW9CRCxDQTdCRDs7R0FBTUQ7VUFFbUVEOzs7S0FGbkVDO0FBK0JOLCtEQUFlQSxTQUFmIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vX05fRS8uL3NyYy9jb21wb25lbnRzL0Rhc2hib2FyZC9pbmRleC50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgQm94LCBCdXR0b24sIEZsZXgsIEhlYWRpbmcsIElucHV0IH0gZnJvbSAnQGNoYWtyYS11aS9yZWFjdCc7XG5pbXBvcnQgUmVhY3QsIHsgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgQ2hhcnQgZnJvbSAnLi4vQ2hhcnQnO1xuaW1wb3J0IHsgdXNlQnJhaW5Db250ZXh0IH0gZnJvbSAnLi4vLi4vY29udGV4dC9CcmFpbkNvbnRleHQnO1xuXG50eXBlIERhaWx5RGF0YSA9IHtcbiAgcG9zaXRpdmU6IG51bWJlcixcbiAgcmVjb3ZlcmVkOiBudW1iZXIsXG4gIGRlYXRoOiBudW1iZXIsXG4gIGRhdGU6IHN0cmluZ1xufVxuXG5jb25zdCBEYXNoYm9hcmQ6IFJlYWN0LkZDID0gKCkgPT4ge1xuXG4gIGNvbnN0IHsgZGFpbHlEYXRhLCBmb3JlY2FzdCwgdHJhaW5pbmdEYXRhLCBkYXlzSW5wdXQsIHNldERheXNJbnB1dCB9ID0gdXNlQnJhaW5Db250ZXh0KCk7XG5cbiAgY29uc3QgaGFuZGxlRm9yZWNhc3QgPSAoZSkgPT4ge1xuICAgIGNvbnNvbGUubG9nKGRheXNJbnB1dClcbiAgICBmb3JlY2FzdCh0cmFpbmluZ0RhdGEsIHBhcnNlSW50KGRheXNJbnB1dCwgMTApKVxuICB9XG5cbiAgcmV0dXJuIChcbiAgICA8RmxleCBkaXJlY3Rpb249J2NvbHVtbicgd2lkdGg9JzEwMHZ3JyBqdXN0aWZ5Q29udGVudD0nY2VudGVyJyA+XG4gICAgICA8RmxleCBkaXJlY3Rpb249J2NvbHVtbicgYWxpZ25JdGVtcz0nY2VudGVyJz5cbiAgICAgICAgPEhlYWRpbmcgcD17MTB9IHNpemU9J3hsJz5Ib3cgbWFueSBkYXlzIGFoZWFkIHdvdWxkIHlvdSBsaWtlIHRvIHByZWRpY3Q/IDwvSGVhZGluZz5cbiAgICAgICAgPEZsZXg+XG4gICAgICAgICAgPElucHV0XG4gICAgICAgICAgICB3aWR0aD0nMjAwcHgnXG4gICAgICAgICAgICBwbGFjZWhvbGRlcj0nZGF5cyB0byBwcmVkaWN0J1xuICAgICAgICAgICAgdHlwZT0nbnVtYmVyJ1xuICAgICAgICAgICAgdmFsdWU9e2RheXNJbnB1dH1cbiAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0RGF5c0lucHV0KGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAvPlxuICAgICAgICAgIDxCdXR0b24gbWw9JzEuNScgb25DbGljaz17aGFuZGxlRm9yZWNhc3R9PlRyYWluIEFJPC9CdXR0b24+XG4gICAgICAgIDwvRmxleD5cbiAgICAgIDwvRmxleD5cbiAgICAgIDxCb3g+XG4gICAgICAgIDxDaGFydCBkYWlseURhdGE9e2RhaWx5RGF0YX0gLz5cbiAgICAgIDwvQm94PlxuICAgIDwvRmxleD5cbiAgKTtcbn1cblxuZXhwb3J0IGRlZmF1bHQgRGFzaGJvYXJkOyJdLCJuYW1lcyI6WyJCb3giLCJCdXR0b24iLCJGbGV4IiwiSGVhZGluZyIsIklucHV0IiwiUmVhY3QiLCJDaGFydCIsInVzZUJyYWluQ29udGV4dCIsIkRhc2hib2FyZCIsImRhaWx5RGF0YSIsImZvcmVjYXN0IiwidHJhaW5pbmdEYXRhIiwiZGF5c0lucHV0Iiwic2V0RGF5c0lucHV0IiwiaGFuZGxlRm9yZWNhc3QiLCJlIiwiY29uc29sZSIsImxvZyIsInBhcnNlSW50IiwidGFyZ2V0IiwidmFsdWUiXSwic291cmNlUm9vdCI6IiJ9