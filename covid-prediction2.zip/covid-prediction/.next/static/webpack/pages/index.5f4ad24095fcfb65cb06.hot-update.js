"use strict";
self["webpackHotUpdate_N_E"]("pages/index",{

/***/ "./src/context/BrainContext.tsx":
/*!**************************************!*\
  !*** ./src/context/BrainContext.tsx ***!
  \**************************************/
/***/ (function(module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "BrainContext": function() { return /* binding */ BrainContext; },
/* harmony export */   "BrainProvider": function() { return /* binding */ BrainProvider; },
/* harmony export */   "useBrainContext": function() { return /* binding */ useBrainContext; }
/* harmony export */ });
/* harmony import */ var _home_vittis_dev_github_covid_prediction_node_modules_next_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/next/node_modules/@babel/runtime/helpers/esm/asyncToGenerator */ "./node_modules/next/node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var _home_vittis_dev_github_covid_prediction_node_modules_next_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/next/node_modules/@babel/runtime/regenerator */ "./node_modules/next/node_modules/@babel/runtime/regenerator/index.js");
/* harmony import */ var _home_vittis_dev_github_covid_prediction_node_modules_next_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_home_vittis_dev_github_covid_prediction_node_modules_next_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _services_api__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../services/api */ "./src/services/api.ts");
/* harmony import */ var brain_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! brain.js */ "./node_modules/brain.js/dist/src/index");
/* harmony import */ var _utils_scaler__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../utils/scaler */ "./src/utils/scaler.ts");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__);
/* module decorator */ module = __webpack_require__.hmd(module);


var _jsxFileName = "/home/vittis/dev/github/covid-prediction/src/context/BrainContext.tsx",
    _this = undefined,
    _s = $RefreshSig$(),
    _s2 = $RefreshSig$();




 // import scaler from 'minmaxscaler'



var BrainContext = /*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_2__.createContext)({});
var BrainProvider = function BrainProvider(_ref) {
  _s();

  var children = _ref.children;

  var _useState = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(false),
      training = _useState[0],
      setTraining = _useState[1];

  var _useState2 = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)([]),
      dailyData = _useState2[0],
      setDailyData = _useState2[1];

  var _useState3 = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)({}),
      globalData = _useState3[0],
      setGlobalData = _useState3[1];

  var _useState4 = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)([]),
      trainingData = _useState4[0],
      setTrainingData = _useState4[1];

  var _useState5 = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(''),
      daysInput = _useState5[0],
      setDaysInput = _useState5[1];

  var _useState6 = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)([]),
      prediction = _useState6[0],
      setPrediction = _useState6[1];

  var predictedChartData = {
    data: {
      labels: prediction.map(function (n, index) {
        return index;
      }),
      datasets: [{
        data: prediction.map(function (data) {
          return data;
        }),
        label: 'Infected',
        borderColor: 'rgb(53, 162, 235)',
        backgroundColor: 'rgba(53, 162, 235, 0.5)'
      }]
    },
    options: {
      responsive: true,
      plugins: {
        legend: {
          position: 'top'
        },
        title: {
          display: true,
          text: 'Your Covid-19 infection forecasting'
        }
      }
    }
  };
  var trainingChartData = {
    data: {
      labels: trainingData.map(function (_ref2) {
        var date = _ref2.date;
        return new Date(date).toLocaleDateString();
      }),
      datasets: [{
        data: trainingData.map(function (data) {
          return data.confirmed;
        }),
        label: 'Infected',
        borderColor: 'rgb(53, 162, 235)',
        backgroundColor: 'rgba(53, 162, 235, 0.5)'
      }, {
        data: trainingData.map(function (data) {
          return data.deaths;
        }),
        label: 'Deaths',
        borderColor: 'rgb(255, 99, 132)',
        backgroundColor: 'rgba(255, 99, 132, 0.5)'
      }]
    },
    options: {
      responsive: true,
      plugins: {
        legend: {
          position: 'top'
        },
        title: {
          display: true,
          text: 'AI training data'
        }
      }
    }
  };

  var forecast = function forecast(trainingData, daysInput) {
    setTraining(true);
    var newTrainingData = new Array(50).fill(0);

    if (trainingData) {
      for (var i = 0; i <= 50; i++) {
        var _trainingData;

        newTrainingData[i] = (_trainingData = trainingData[trainingData.length - 51 + i]) === null || _trainingData === void 0 ? void 0 : _trainingData.confirmed;
      }
    }

    var scaledData = _utils_scaler__WEBPACK_IMPORTED_MODULE_5__.default.fit_transform(newTrainingData);
    var network = new brain_js__WEBPACK_IMPORTED_MODULE_4__.recurrent.LSTMTimeStep({
      inputSize: 1,
      hiddenLayers: [10],
      outputSize: 1
    });
    network.train([scaledData], {
      learningRate: 0.005,
      errorThresh: 0.01,
      log: function log(stats) {
        console.log(stats);
      }
    });
    var result = network.forecast([1], daysInput);
    setPrediction(_utils_scaler__WEBPACK_IMPORTED_MODULE_5__.default.inverse_transform(result));
    setTraining(false);
  };

  (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(function () {
    var loadDailyData = /*#__PURE__*/function () {
      var _ref3 = (0,_home_vittis_dev_github_covid_prediction_node_modules_next_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0__.default)( /*#__PURE__*/_home_vittis_dev_github_covid_prediction_node_modules_next_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_1___default().mark(function _callee() {
        var initialDailyData;
        return _home_vittis_dev_github_covid_prediction_node_modules_next_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_1___default().wrap(function _callee$(_context) {
          while (1) {
            switch (_context.prev = _context.next) {
              case 0:
                _context.next = 2;
                return (0,_services_api__WEBPACK_IMPORTED_MODULE_3__.fetchDailyData)();

              case 2:
                initialDailyData = _context.sent;

                if (initialDailyData) {
                  setDailyData(initialDailyData);
                }

              case 4:
              case "end":
                return _context.stop();
            }
          }
        }, _callee);
      }));

      return function loadDailyData() {
        return _ref3.apply(this, arguments);
      };
    }();

    var loadGlobalData = /*#__PURE__*/function () {
      var _ref4 = (0,_home_vittis_dev_github_covid_prediction_node_modules_next_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0__.default)( /*#__PURE__*/_home_vittis_dev_github_covid_prediction_node_modules_next_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_1___default().mark(function _callee2() {
        var globalData;
        return _home_vittis_dev_github_covid_prediction_node_modules_next_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_1___default().wrap(function _callee2$(_context2) {
          while (1) {
            switch (_context2.prev = _context2.next) {
              case 0:
                _context2.next = 2;
                return (0,_services_api__WEBPACK_IMPORTED_MODULE_3__.fetchGlobalData)();

              case 2:
                globalData = _context2.sent;

                if (globalData) {
                  setGlobalData(globalData);
                }

              case 4:
              case "end":
                return _context2.stop();
            }
          }
        }, _callee2);
      }));

      return function loadGlobalData() {
        return _ref4.apply(this, arguments);
      };
    }();

    loadDailyData();
    loadGlobalData();
  }, []);
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(BrainContext.Provider, {
    value: {
      trainingData: trainingData,
      setTrainingData: setTrainingData,
      setDailyData: setDailyData,
      dailyData: dailyData,
      trainingChartData: trainingChartData,
      forecast: forecast,
      daysInput: daysInput,
      setDaysInput: setDaysInput,
      prediction: prediction,
      predictedChartData: predictedChartData,
      training: training
    },
    children: children
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 208,
    columnNumber: 5
  }, _this);
}; //easier export

_s(BrainProvider, "Lqs1God9SV0nPJ7CcIpFkA5AQ5A=");

_c = BrainProvider;
var useBrainContext = function useBrainContext() {
  _s2();

  return (0,react__WEBPACK_IMPORTED_MODULE_2__.useContext)(BrainContext);
};

_s2(useBrainContext, "gDsCjeeItUuvgOWf1v4qoK9RF6k=");

var _c;

$RefreshReg$(_c, "BrainProvider");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.id);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }


/***/ })

});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic3RhdGljL3dlYnBhY2svcGFnZXMvaW5kZXguNWY0YWQyNDA5NWZjZmI2NWNiMDYuaG90LXVwZGF0ZS5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7QUFDQTtDQUVBOztBQUNBOztBQXFGTyxJQUFNUSxZQUFZLGdCQUFHUixvREFBYSxDQUFDLEVBQUQsQ0FBbEM7QUFFQSxJQUFNUyxhQUFhLEdBQUcsU0FBaEJBLGFBQWdCLE9BQWtCO0FBQUE7O0FBQUEsTUFBZkMsUUFBZSxRQUFmQSxRQUFlOztBQUU3QyxrQkFBZ0NQLCtDQUFRLENBQUMsS0FBRCxDQUF4QztBQUFBLE1BQU9RLFFBQVA7QUFBQSxNQUFpQkMsV0FBakI7O0FBQ0EsbUJBQWtDVCwrQ0FBUSxDQUFjLEVBQWQsQ0FBMUM7QUFBQSxNQUFPVSxTQUFQO0FBQUEsTUFBa0JDLFlBQWxCOztBQUNBLG1CQUFvQ1gsK0NBQVEsQ0FBQyxFQUFELENBQTVDO0FBQUEsTUFBT1ksVUFBUDtBQUFBLE1BQW1CQyxhQUFuQjs7QUFDQSxtQkFBd0NiLCtDQUFRLENBQWlCLEVBQWpCLENBQWhEO0FBQUEsTUFBT2MsWUFBUDtBQUFBLE1BQXFCQyxlQUFyQjs7QUFFQSxtQkFBa0NmLCtDQUFRLENBQUMsRUFBRCxDQUExQztBQUFBLE1BQU9nQixTQUFQO0FBQUEsTUFBa0JDLFlBQWxCOztBQUNBLG1CQUFvQ2pCLCtDQUFRLENBQUMsRUFBRCxDQUE1QztBQUFBLE1BQU9rQixVQUFQO0FBQUEsTUFBbUJDLGFBQW5COztBQUVBLE1BQU1DLGtCQUFrQixHQUFHO0FBQ3pCQyxJQUFBQSxJQUFJLEVBQUU7QUFDSkMsTUFBQUEsTUFBTSxFQUFFSixVQUFVLENBQUNLLEdBQVgsQ0FBZSxVQUFFQyxDQUFGLEVBQUtDLEtBQUw7QUFBQSxlQUFnQkEsS0FBaEI7QUFBQSxPQUFmLENBREo7QUFFSkMsTUFBQUEsUUFBUSxFQUFFLENBQUM7QUFDVEwsUUFBQUEsSUFBSSxFQUFFSCxVQUFVLENBQUNLLEdBQVgsQ0FBZSxVQUFDRixJQUFEO0FBQUEsaUJBQVVBLElBQVY7QUFBQSxTQUFmLENBREc7QUFFVE0sUUFBQUEsS0FBSyxFQUFFLFVBRkU7QUFHVEMsUUFBQUEsV0FBVyxFQUFFLG1CQUhKO0FBSVRDLFFBQUFBLGVBQWUsRUFBRTtBQUpSLE9BQUQ7QUFGTixLQURtQjtBQVV6QkMsSUFBQUEsT0FBTyxFQUFFO0FBQ1BDLE1BQUFBLFVBQVUsRUFBRSxJQURMO0FBRVBDLE1BQUFBLE9BQU8sRUFBRTtBQUNQQyxRQUFBQSxNQUFNLEVBQUU7QUFDTkMsVUFBQUEsUUFBUSxFQUFFO0FBREosU0FERDtBQUlQQyxRQUFBQSxLQUFLLEVBQUU7QUFDTEMsVUFBQUEsT0FBTyxFQUFFLElBREo7QUFFTEMsVUFBQUEsSUFBSSxFQUFFO0FBRkQ7QUFKQTtBQUZGO0FBVmdCLEdBQTNCO0FBd0JBLE1BQU1DLGlCQUFpQixHQUFHO0FBQ3hCakIsSUFBQUEsSUFBSSxFQUFFO0FBQ0pDLE1BQUFBLE1BQU0sRUFBRVIsWUFBWSxDQUFDUyxHQUFiLENBQWlCO0FBQUEsWUFBR2dCLElBQUgsU0FBR0EsSUFBSDtBQUFBLGVBQWMsSUFBSUMsSUFBSixDQUFTRCxJQUFULEVBQWVFLGtCQUFmLEVBQWQ7QUFBQSxPQUFqQixDQURKO0FBRUpmLE1BQUFBLFFBQVEsRUFBRSxDQUFDO0FBQ1RMLFFBQUFBLElBQUksRUFBRVAsWUFBWSxDQUFDUyxHQUFiLENBQWlCLFVBQUNGLElBQUQ7QUFBQSxpQkFBVUEsSUFBSSxDQUFDcUIsU0FBZjtBQUFBLFNBQWpCLENBREc7QUFFVGYsUUFBQUEsS0FBSyxFQUFFLFVBRkU7QUFHVEMsUUFBQUEsV0FBVyxFQUFFLG1CQUhKO0FBSVRDLFFBQUFBLGVBQWUsRUFBRTtBQUpSLE9BQUQsRUFLUDtBQUNEUixRQUFBQSxJQUFJLEVBQUVQLFlBQVksQ0FBQ1MsR0FBYixDQUFpQixVQUFDRixJQUFEO0FBQUEsaUJBQVVBLElBQUksQ0FBQ3NCLE1BQWY7QUFBQSxTQUFqQixDQURMO0FBRURoQixRQUFBQSxLQUFLLEVBQUUsUUFGTjtBQUdEQyxRQUFBQSxXQUFXLEVBQUUsbUJBSFo7QUFJREMsUUFBQUEsZUFBZSxFQUFFO0FBSmhCLE9BTE87QUFGTixLQURrQjtBQWV4QkMsSUFBQUEsT0FBTyxFQUFFO0FBQ1BDLE1BQUFBLFVBQVUsRUFBRSxJQURMO0FBRVBDLE1BQUFBLE9BQU8sRUFBRTtBQUNQQyxRQUFBQSxNQUFNLEVBQUU7QUFDTkMsVUFBQUEsUUFBUSxFQUFFO0FBREosU0FERDtBQUlQQyxRQUFBQSxLQUFLLEVBQUU7QUFDTEMsVUFBQUEsT0FBTyxFQUFFLElBREo7QUFFTEMsVUFBQUEsSUFBSSxFQUFFO0FBRkQ7QUFKQTtBQUZGO0FBZmUsR0FBMUI7O0FBNkJBLE1BQU1PLFFBQVEsR0FBRyxTQUFYQSxRQUFXLENBQUM5QixZQUFELEVBQStCRSxTQUEvQixFQUFxRDtBQUNwRVAsSUFBQUEsV0FBVyxDQUFDLElBQUQsQ0FBWDtBQUVBLFFBQU1vQyxlQUFlLEdBQUcsSUFBSUMsS0FBSixDQUFVLEVBQVYsRUFBY0MsSUFBZCxDQUFtQixDQUFuQixDQUF4Qjs7QUFFQSxRQUFJakMsWUFBSixFQUFrQjtBQUNoQixXQUFJLElBQUlrQyxDQUFDLEdBQUcsQ0FBWixFQUFlQSxDQUFDLElBQUksRUFBcEIsRUFBd0JBLENBQUMsRUFBekIsRUFBOEI7QUFBQTs7QUFDNUJILFFBQUFBLGVBQWUsQ0FBQ0csQ0FBRCxDQUFmLG9CQUFxQmxDLFlBQVksQ0FBQ0EsWUFBWSxDQUFDbUMsTUFBYixHQUFzQixFQUF0QixHQUEyQkQsQ0FBNUIsQ0FBakMsa0RBQXFCLGNBQTRDTixTQUFqRTtBQUNEO0FBQ0Y7O0FBRUQsUUFBTVEsVUFBVSxHQUFHOUMsZ0VBQUEsQ0FBcUJ5QyxlQUFyQixDQUFuQjtBQUVBLFFBQU1PLE9BQU8sR0FBRyxJQUFJakQsNERBQUosQ0FBaUM7QUFDL0NvRCxNQUFBQSxTQUFTLEVBQUUsQ0FEb0M7QUFFL0NDLE1BQUFBLFlBQVksRUFBRSxDQUFDLEVBQUQsQ0FGaUM7QUFHL0NDLE1BQUFBLFVBQVUsRUFBRTtBQUhtQyxLQUFqQyxDQUFoQjtBQU1BTCxJQUFBQSxPQUFPLENBQUNNLEtBQVIsQ0FBYyxDQUFDUixVQUFELENBQWQsRUFBNEI7QUFDMUJTLE1BQUFBLFlBQVksRUFBRSxLQURZO0FBRTFCQyxNQUFBQSxXQUFXLEVBQUUsSUFGYTtBQUcxQkMsTUFBQUEsR0FBRyxFQUFFLGFBQUFDLEtBQUssRUFBSTtBQUNaQyxRQUFBQSxPQUFPLENBQUNGLEdBQVIsQ0FBWUMsS0FBWjtBQUNEO0FBTHlCLEtBQTVCO0FBUUEsUUFBTUUsTUFBTSxHQUFHWixPQUFPLENBQUNSLFFBQVIsQ0FBaUIsQ0FBQyxDQUFELENBQWpCLEVBQXNCNUIsU0FBdEIsQ0FBZjtBQUNBRyxJQUFBQSxhQUFhLENBQUNmLG9FQUFBLENBQXlCNEQsTUFBekIsQ0FBRCxDQUFiO0FBQ0F2RCxJQUFBQSxXQUFXLENBQUMsS0FBRCxDQUFYO0FBQ0QsR0E5QkQ7O0FBZ0NBVixFQUFBQSxnREFBUyxDQUFDLFlBQU07QUFDZCxRQUFNbUUsYUFBYTtBQUFBLDBVQUFHO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQ1dqRSw2REFBYyxFQUR6Qjs7QUFBQTtBQUNka0UsZ0JBQUFBLGdCQURjOztBQUdwQixvQkFBSUEsZ0JBQUosRUFBc0I7QUFDcEJ4RCxrQkFBQUEsWUFBWSxDQUFDd0QsZ0JBQUQsQ0FBWjtBQUNEOztBQUxtQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxPQUFIOztBQUFBLHNCQUFiRCxhQUFhO0FBQUE7QUFBQTtBQUFBLE9BQW5COztBQVFBLFFBQU1FLGNBQWM7QUFBQSwwVUFBRztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUNJbEUsOERBQWUsRUFEbkI7O0FBQUE7QUFDZlUsZ0JBQUFBLFVBRGU7O0FBRXJCLG9CQUFJQSxVQUFKLEVBQWdCO0FBQ2RDLGtCQUFBQSxhQUFhLENBQUNELFVBQUQsQ0FBYjtBQUNEOztBQUpvQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxPQUFIOztBQUFBLHNCQUFkd0QsY0FBYztBQUFBO0FBQUE7QUFBQSxPQUFwQjs7QUFPQUYsSUFBQUEsYUFBYTtBQUNiRSxJQUFBQSxjQUFjO0FBQ2YsR0FsQlEsRUFrQk4sRUFsQk0sQ0FBVDtBQW9CQSxzQkFDRSw4REFBQyxZQUFELENBQWMsUUFBZDtBQUNFLFNBQUssRUFBRTtBQUNMdEQsTUFBQUEsWUFBWSxFQUFaQSxZQURLO0FBRUxDLE1BQUFBLGVBQWUsRUFBZkEsZUFGSztBQUdMSixNQUFBQSxZQUFZLEVBQVpBLFlBSEs7QUFJTEQsTUFBQUEsU0FBUyxFQUFUQSxTQUpLO0FBS0w0QixNQUFBQSxpQkFBaUIsRUFBakJBLGlCQUxLO0FBTUxNLE1BQUFBLFFBQVEsRUFBUkEsUUFOSztBQU9MNUIsTUFBQUEsU0FBUyxFQUFUQSxTQVBLO0FBUUxDLE1BQUFBLFlBQVksRUFBWkEsWUFSSztBQVNMQyxNQUFBQSxVQUFVLEVBQVZBLFVBVEs7QUFVTEUsTUFBQUEsa0JBQWtCLEVBQWxCQSxrQkFWSztBQVdMWixNQUFBQSxRQUFRLEVBQVJBO0FBWEssS0FEVDtBQUFBLGNBZUdEO0FBZkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQURGO0FBbUJELENBdElNLEVBd0lQOztHQXhJYUQ7O0tBQUFBO0FBeUlOLElBQU0rRCxlQUFlLEdBQUcsU0FBbEJBLGVBQWtCO0FBQUE7O0FBQUEsU0FBTXZFLGlEQUFVLENBQUNPLFlBQUQsQ0FBaEI7QUFBQSxDQUF4Qjs7SUFBTWdFIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vX05fRS8uL3NyYy9jb250ZXh0L0JyYWluQ29udGV4dC50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgY3JlYXRlQ29udGV4dCwgRGlzcGF0Y2gsIFNldFN0YXRlQWN0aW9uLCB1c2VDb250ZXh0LCB1c2VFZmZlY3QsIHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgeyBmZXRjaERhaWx5RGF0YSwgZmV0Y2hHbG9iYWxEYXRhIH0gZnJvbSBcIi4uL3NlcnZpY2VzL2FwaVwiO1xuaW1wb3J0ICogYXMgYnJhaW4gZnJvbSAnYnJhaW4uanMnO1xuLy8gaW1wb3J0IHNjYWxlciBmcm9tICdtaW5tYXhzY2FsZXInXG5pbXBvcnQgc2NhbGVyIGZyb20gJy4uL3V0aWxzL3NjYWxlcidcblxudHlwZSBEYWlseURhdGEgPSB7XG4gIHBvc2l0aXZlOiBudW1iZXIsXG4gIHJlY292ZXJlZDogbnVtYmVyLFxuICBkZWF0aDogbnVtYmVyLFxuICBkYXRlOiBzdHJpbmdcbn1cblxudHlwZSBUcmFpbmluZ0RhdGEgPSB7XG4gIGNvbmZpcm1lZDogbnVtYmVyLFxuICByZWNvdmVyZWQ6IG51bWJlcixcbiAgZGVhdGhzOiBudW1iZXIsXG4gIGRhdGU6IHN0cmluZ1xufVxuXG50eXBlIFRyYWluaW5nQ2hhcnQgPSB7XG4gIGRhdGE6IHtcbiAgICBsYWJlbHM6IHN0cmluZ1tdO1xuICAgIGRhdGFzZXRzOiAoe1xuICAgICAgICBkYXRhOiBudW1iZXJbXTtcbiAgICAgICAgbGFiZWw6IHN0cmluZztcbiAgICAgICAgYm9yZGVyQ29sb3I6IHN0cmluZztcbiAgICAgICAgYmFja2dyb3VuZENvbG9yOiBzdHJpbmc7XG4gICAgICAgIGZpbGw/OiB1bmRlZmluZWQ7XG4gICAgfSB8IHtcbiAgICAgICAgZGF0YTogbnVtYmVyW107XG4gICAgICAgIGxhYmVsOiBzdHJpbmc7XG4gICAgICAgIGJvcmRlckNvbG9yOiBzdHJpbmc7XG4gICAgICAgIGJhY2tncm91bmRDb2xvcjogc3RyaW5nO1xuICAgICAgICBmaWxsOiBib29sZWFuO1xuICAgIH0pW107XG4gIH07XG4gIG9wdGlvbnM6IHtcbiAgICByZXNwb25zaXZlOiBib29sZWFuLFxuICAgIHBsdWdpbnM6IHtcbiAgICAgIGxlZ2VuZDoge1xuICAgICAgICBwb3NpdGlvbjogYW55LFxuICAgICAgfSxcbiAgICAgIHRpdGxlOiB7XG4gICAgICAgIGRpc3BsYXk6IGJvb2xlYW4sXG4gICAgICAgIHRleHQ6IHN0cmluZyxcbiAgICAgIH0sXG4gICAgfVxuICB9O1xufVxuXG50eXBlIFByZWRpY3RlZENoYXJ0ID0ge1xuICBkYXRhOiB7XG4gICAgbGFiZWxzOiBudW1iZXJbXTtcbiAgICBkYXRhc2V0czoge1xuICAgICAgICBkYXRhOiBudW1iZXJbXTtcbiAgICAgICAgbGFiZWw6IHN0cmluZztcbiAgICAgICAgYm9yZGVyQ29sb3I6IHN0cmluZztcbiAgICAgICAgYmFja2dyb3VuZENvbG9yOiBzdHJpbmc7XG4gICAgfVtdO1xuICB9O1xuICBvcHRpb25zOiB7XG4gICAgICByZXNwb25zaXZlOiBib29sZWFuO1xuICAgICAgcGx1Z2luczoge1xuICAgICAgICAgIGxlZ2VuZDoge1xuICAgICAgICAgICAgICBwb3NpdGlvbjogYW55O1xuICAgICAgICAgIH07XG4gICAgICAgICAgdGl0bGU6IHtcbiAgICAgICAgICAgICAgZGlzcGxheTogYm9vbGVhbjtcbiAgICAgICAgICAgICAgdGV4dDogc3RyaW5nO1xuICAgICAgICAgIH07XG4gICAgICB9O1xuICB9O1xufVxuXG50eXBlIEJyYWluQ29udGV4dFR5cGUgPSB7XG4gIHRyYWluaW5nRGF0YTogVHJhaW5pbmdEYXRhW10sXG4gIHNldFRyYWluaW5nRGF0YTogRGlzcGF0Y2g8U2V0U3RhdGVBY3Rpb248VHJhaW5pbmdEYXRhW10+PixcbiAgc2V0RGFpbHlEYXRhOiBEaXNwYXRjaDxTZXRTdGF0ZUFjdGlvbjxEYWlseURhdGFbXT4+LFxuICBkYWlseURhdGE6IERhaWx5RGF0YVtdLFxuICB0cmFpbmluZ0NoYXJ0RGF0YTogVHJhaW5pbmdDaGFydCxcbiAgcHJlZGljdGVkQ2hhcnREYXRhOiBQcmVkaWN0ZWRDaGFydCxcbiAgZm9yZWNhc3Q6IChkYXRhOiBUcmFpbmluZ0RhdGFbXSwgZGF5czogbnVtYmVyKSA9PiB2b2lkLFxuICBkYXlzSW5wdXQ6IHN0cmluZyxcbiAgc2V0RGF5c0lucHV0OiBEaXNwYXRjaDxTZXRTdGF0ZUFjdGlvbjxzdHJpbmc+PixcbiAgcHJlZGljdGlvbjogbnVtYmVyW10sXG4gIHRyYWluaW5nOiBib29sZWFuXG59XG5cbmV4cG9ydCBjb25zdCBCcmFpbkNvbnRleHQgPSBjcmVhdGVDb250ZXh0KHt9IGFzIEJyYWluQ29udGV4dFR5cGUpXG5cbmV4cG9ydCBjb25zdCBCcmFpblByb3ZpZGVyID0gKHsgY2hpbGRyZW4gfSkgPT4ge1xuXG4gIGNvbnN0IFt0cmFpbmluZywgc2V0VHJhaW5pbmddID0gdXNlU3RhdGUoZmFsc2UpXG4gIGNvbnN0IFtkYWlseURhdGEsIHNldERhaWx5RGF0YV0gPSB1c2VTdGF0ZTxEYWlseURhdGFbXT4oW10pXG4gIGNvbnN0IFtnbG9iYWxEYXRhLCBzZXRHbG9iYWxEYXRhXSA9IHVzZVN0YXRlKHt9KVxuICBjb25zdCBbdHJhaW5pbmdEYXRhLCBzZXRUcmFpbmluZ0RhdGFdID0gdXNlU3RhdGU8VHJhaW5pbmdEYXRhW10+KFtdKVxuXG4gIGNvbnN0IFtkYXlzSW5wdXQsIHNldERheXNJbnB1dF0gPSB1c2VTdGF0ZSgnJylcbiAgY29uc3QgW3ByZWRpY3Rpb24sIHNldFByZWRpY3Rpb25dID0gdXNlU3RhdGUoW10pO1xuXG4gIGNvbnN0IHByZWRpY3RlZENoYXJ0RGF0YSA9IHtcbiAgICBkYXRhOiB7XG4gICAgICBsYWJlbHM6IHByZWRpY3Rpb24ubWFwKCggbiwgaW5kZXggKSA9PiBpbmRleCksXG4gICAgICBkYXRhc2V0czogW3tcbiAgICAgICAgZGF0YTogcHJlZGljdGlvbi5tYXAoKGRhdGEpID0+IGRhdGEpLFxuICAgICAgICBsYWJlbDogJ0luZmVjdGVkJyxcbiAgICAgICAgYm9yZGVyQ29sb3I6ICdyZ2IoNTMsIDE2MiwgMjM1KScsXG4gICAgICAgIGJhY2tncm91bmRDb2xvcjogJ3JnYmEoNTMsIDE2MiwgMjM1LCAwLjUpJyxcbiAgICAgIH1dLFxuICAgIH0sXG4gICAgb3B0aW9uczoge1xuICAgICAgcmVzcG9uc2l2ZTogdHJ1ZSxcbiAgICAgIHBsdWdpbnM6IHtcbiAgICAgICAgbGVnZW5kOiB7XG4gICAgICAgICAgcG9zaXRpb246ICd0b3AnIGFzIGNvbnN0LFxuICAgICAgICB9LFxuICAgICAgICB0aXRsZToge1xuICAgICAgICAgIGRpc3BsYXk6IHRydWUsXG4gICAgICAgICAgdGV4dDogJ1lvdXIgQ292aWQtMTkgaW5mZWN0aW9uIGZvcmVjYXN0aW5nJyxcbiAgICAgICAgfSxcbiAgICAgIH1cbiAgICB9XG4gIH1cblxuICBjb25zdCB0cmFpbmluZ0NoYXJ0RGF0YSA9IHtcbiAgICBkYXRhOiB7XG4gICAgICBsYWJlbHM6IHRyYWluaW5nRGF0YS5tYXAoKHsgZGF0ZSB9KSA9PiBuZXcgRGF0ZShkYXRlKS50b0xvY2FsZURhdGVTdHJpbmcoKSksXG4gICAgICBkYXRhc2V0czogW3tcbiAgICAgICAgZGF0YTogdHJhaW5pbmdEYXRhLm1hcCgoZGF0YSkgPT4gZGF0YS5jb25maXJtZWQpLFxuICAgICAgICBsYWJlbDogJ0luZmVjdGVkJyxcbiAgICAgICAgYm9yZGVyQ29sb3I6ICdyZ2IoNTMsIDE2MiwgMjM1KScsXG4gICAgICAgIGJhY2tncm91bmRDb2xvcjogJ3JnYmEoNTMsIDE2MiwgMjM1LCAwLjUpJyxcbiAgICAgIH0sIHtcbiAgICAgICAgZGF0YTogdHJhaW5pbmdEYXRhLm1hcCgoZGF0YSkgPT4gZGF0YS5kZWF0aHMpLFxuICAgICAgICBsYWJlbDogJ0RlYXRocycsXG4gICAgICAgIGJvcmRlckNvbG9yOiAncmdiKDI1NSwgOTksIDEzMiknLFxuICAgICAgICBiYWNrZ3JvdW5kQ29sb3I6ICdyZ2JhKDI1NSwgOTksIDEzMiwgMC41KScsXG4gICAgICB9XSxcbiAgICB9LFxuICAgIG9wdGlvbnM6IHtcbiAgICAgIHJlc3BvbnNpdmU6IHRydWUsXG4gICAgICBwbHVnaW5zOiB7XG4gICAgICAgIGxlZ2VuZDoge1xuICAgICAgICAgIHBvc2l0aW9uOiAndG9wJyBhcyBjb25zdCxcbiAgICAgICAgfSxcbiAgICAgICAgdGl0bGU6IHtcbiAgICAgICAgICBkaXNwbGF5OiB0cnVlLFxuICAgICAgICAgIHRleHQ6ICdBSSB0cmFpbmluZyBkYXRhJyxcbiAgICAgICAgfSxcbiAgICAgIH1cbiAgICB9XG4gIH1cblxuICBjb25zdCBmb3JlY2FzdCA9ICh0cmFpbmluZ0RhdGE6IFRyYWluaW5nRGF0YVtdLCBkYXlzSW5wdXQ6IG51bWJlcikgPT4ge1xuICAgIHNldFRyYWluaW5nKHRydWUpXG5cbiAgICBjb25zdCBuZXdUcmFpbmluZ0RhdGEgPSBuZXcgQXJyYXkoNTApLmZpbGwoMClcblxuICAgIGlmICh0cmFpbmluZ0RhdGEpIHtcbiAgICAgIGZvcihsZXQgaSA9IDA7IGkgPD0gNTA7IGkgKyspIHtcbiAgICAgICAgbmV3VHJhaW5pbmdEYXRhW2ldID0gdHJhaW5pbmdEYXRhW3RyYWluaW5nRGF0YS5sZW5ndGggLSA1MSArIGldPy5jb25maXJtZWRcbiAgICAgIH1cbiAgICB9XG5cbiAgICBjb25zdCBzY2FsZWREYXRhID0gc2NhbGVyLmZpdF90cmFuc2Zvcm0obmV3VHJhaW5pbmdEYXRhKTtcblxuICAgIGNvbnN0IG5ldHdvcmsgPSBuZXcgYnJhaW4ucmVjdXJyZW50LkxTVE1UaW1lU3RlcCh7XG4gICAgICBpbnB1dFNpemU6IDEsXG4gICAgICBoaWRkZW5MYXllcnM6IFsxMF0sXG4gICAgICBvdXRwdXRTaXplOiAxXG4gICAgfSlcblxuICAgIG5ldHdvcmsudHJhaW4oW3NjYWxlZERhdGFdLCB7XG4gICAgICBsZWFybmluZ1JhdGU6IDAuMDA1LFxuICAgICAgZXJyb3JUaHJlc2g6IDAuMDEsXG4gICAgICBsb2c6IHN0YXRzID0+IHtcbiAgICAgICAgY29uc29sZS5sb2coc3RhdHMpO1xuICAgICAgfVxuICAgIH0pXG5cbiAgICBjb25zdCByZXN1bHQgPSBuZXR3b3JrLmZvcmVjYXN0KFsxXSwgZGF5c0lucHV0KVxuICAgIHNldFByZWRpY3Rpb24oc2NhbGVyLmludmVyc2VfdHJhbnNmb3JtKHJlc3VsdCkpXG4gICAgc2V0VHJhaW5pbmcoZmFsc2UpXG4gIH1cblxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGNvbnN0IGxvYWREYWlseURhdGEgPSBhc3luYyAoKSA9PiB7XG4gICAgICBjb25zdCBpbml0aWFsRGFpbHlEYXRhID0gYXdhaXQgZmV0Y2hEYWlseURhdGEoKVxuXG4gICAgICBpZiAoaW5pdGlhbERhaWx5RGF0YSkge1xuICAgICAgICBzZXREYWlseURhdGEoaW5pdGlhbERhaWx5RGF0YSk7XG4gICAgICB9XG4gICAgfVxuXG4gICAgY29uc3QgbG9hZEdsb2JhbERhdGEgPSBhc3luYyAoKSA9PiB7XG4gICAgICBjb25zdCBnbG9iYWxEYXRhID0gYXdhaXQgZmV0Y2hHbG9iYWxEYXRhKClcbiAgICAgIGlmIChnbG9iYWxEYXRhKSB7XG4gICAgICAgIHNldEdsb2JhbERhdGEoZ2xvYmFsRGF0YSlcbiAgICAgIH1cbiAgICB9XG5cbiAgICBsb2FkRGFpbHlEYXRhKClcbiAgICBsb2FkR2xvYmFsRGF0YSgpXG4gIH0sIFtdKVxuXG4gIHJldHVybiAoXG4gICAgPEJyYWluQ29udGV4dC5Qcm92aWRlclxuICAgICAgdmFsdWU9e3tcbiAgICAgICAgdHJhaW5pbmdEYXRhLFxuICAgICAgICBzZXRUcmFpbmluZ0RhdGEsXG4gICAgICAgIHNldERhaWx5RGF0YSxcbiAgICAgICAgZGFpbHlEYXRhLFxuICAgICAgICB0cmFpbmluZ0NoYXJ0RGF0YSxcbiAgICAgICAgZm9yZWNhc3QsXG4gICAgICAgIGRheXNJbnB1dCxcbiAgICAgICAgc2V0RGF5c0lucHV0LFxuICAgICAgICBwcmVkaWN0aW9uLFxuICAgICAgICBwcmVkaWN0ZWRDaGFydERhdGEsXG4gICAgICAgIHRyYWluaW5nXG4gICAgICB9fVxuICAgID5cbiAgICAgIHtjaGlsZHJlbn1cbiAgICA8L0JyYWluQ29udGV4dC5Qcm92aWRlcj5cbiAgKTtcbn1cblxuLy9lYXNpZXIgZXhwb3J0XG5leHBvcnQgY29uc3QgdXNlQnJhaW5Db250ZXh0ID0gKCkgPT4gdXNlQ29udGV4dChCcmFpbkNvbnRleHQpO1xuIl0sIm5hbWVzIjpbImNyZWF0ZUNvbnRleHQiLCJ1c2VDb250ZXh0IiwidXNlRWZmZWN0IiwidXNlU3RhdGUiLCJmZXRjaERhaWx5RGF0YSIsImZldGNoR2xvYmFsRGF0YSIsImJyYWluIiwic2NhbGVyIiwiQnJhaW5Db250ZXh0IiwiQnJhaW5Qcm92aWRlciIsImNoaWxkcmVuIiwidHJhaW5pbmciLCJzZXRUcmFpbmluZyIsImRhaWx5RGF0YSIsInNldERhaWx5RGF0YSIsImdsb2JhbERhdGEiLCJzZXRHbG9iYWxEYXRhIiwidHJhaW5pbmdEYXRhIiwic2V0VHJhaW5pbmdEYXRhIiwiZGF5c0lucHV0Iiwic2V0RGF5c0lucHV0IiwicHJlZGljdGlvbiIsInNldFByZWRpY3Rpb24iLCJwcmVkaWN0ZWRDaGFydERhdGEiLCJkYXRhIiwibGFiZWxzIiwibWFwIiwibiIsImluZGV4IiwiZGF0YXNldHMiLCJsYWJlbCIsImJvcmRlckNvbG9yIiwiYmFja2dyb3VuZENvbG9yIiwib3B0aW9ucyIsInJlc3BvbnNpdmUiLCJwbHVnaW5zIiwibGVnZW5kIiwicG9zaXRpb24iLCJ0aXRsZSIsImRpc3BsYXkiLCJ0ZXh0IiwidHJhaW5pbmdDaGFydERhdGEiLCJkYXRlIiwiRGF0ZSIsInRvTG9jYWxlRGF0ZVN0cmluZyIsImNvbmZpcm1lZCIsImRlYXRocyIsImZvcmVjYXN0IiwibmV3VHJhaW5pbmdEYXRhIiwiQXJyYXkiLCJmaWxsIiwiaSIsImxlbmd0aCIsInNjYWxlZERhdGEiLCJmaXRfdHJhbnNmb3JtIiwibmV0d29yayIsInJlY3VycmVudCIsIkxTVE1UaW1lU3RlcCIsImlucHV0U2l6ZSIsImhpZGRlbkxheWVycyIsIm91dHB1dFNpemUiLCJ0cmFpbiIsImxlYXJuaW5nUmF0ZSIsImVycm9yVGhyZXNoIiwibG9nIiwic3RhdHMiLCJjb25zb2xlIiwicmVzdWx0IiwiaW52ZXJzZV90cmFuc2Zvcm0iLCJsb2FkRGFpbHlEYXRhIiwiaW5pdGlhbERhaWx5RGF0YSIsImxvYWRHbG9iYWxEYXRhIiwidXNlQnJhaW5Db250ZXh0Il0sInNvdXJjZVJvb3QiOiIifQ==