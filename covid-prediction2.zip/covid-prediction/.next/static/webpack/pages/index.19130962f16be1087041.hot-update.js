"use strict";
self["webpackHotUpdate_N_E"]("pages/index",{

/***/ "./src/components/Dashboard/index.tsx":
/*!********************************************!*\
  !*** ./src/components/Dashboard/index.tsx ***!
  \********************************************/
/***/ (function(module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _chakra_ui_react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @chakra-ui/react */ "./node_modules/@chakra-ui/react/dist/chakra-ui-react.esm.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _Chart__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../Chart */ "./src/components/Chart/index.tsx");
/* harmony import */ var _context_BrainContext__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../context/BrainContext */ "./src/context/BrainContext.tsx");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__);
/* module decorator */ module = __webpack_require__.hmd(module);
var _jsxFileName = "/home/vittis/dev/github/covid-prediction/src/components/Dashboard/index.tsx",
    _this = undefined,
    _s = $RefreshSig$();







var Dashboard = function Dashboard() {
  _s();

  var _useBrainContext = (0,_context_BrainContext__WEBPACK_IMPORTED_MODULE_2__.useBrainContext)(),
      dailyData = _useBrainContext.dailyData,
      forecast = _useBrainContext.forecast,
      trainingData = _useBrainContext.trainingData,
      daysInput = _useBrainContext.daysInput,
      setDaysInput = _useBrainContext.setDaysInput;

  var handleForecast = function handleForecast(e) {
    console.log(daysInput);
    forecast(trainingData, parseInt(daysInput, 10));
  };

  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_4__.Flex, {
    direction: "column",
    width: "100vw",
    justifyContent: "center",
    children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_4__.Flex, {
      direction: "column",
      alignItems: "center",
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_4__.Heading, {
        p: 5,
        size: "xl",
        children: "How many days ahead would you like to predict? "
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 25,
        columnNumber: 9
      }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_4__.Text, {
        size: "md",
        children: "Textinho explicando coisa boa"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 26,
        columnNumber: 9
      }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_4__.Flex, {
        children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_4__.Input, {
          width: "200px",
          placeholder: "days to predict",
          type: "number",
          value: daysInput,
          onChange: function onChange(e) {
            return setDaysInput(e.target.value);
          }
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 28,
          columnNumber: 11
        }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_4__.Button, {
          ml: "1.5",
          onClick: handleForecast,
          children: "Train AI"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 35,
          columnNumber: 11
        }, _this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 27,
        columnNumber: 9
      }, _this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 24,
      columnNumber: 7
    }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_4__.Box, {
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)(_Chart__WEBPACK_IMPORTED_MODULE_1__.default, {
        dailyData: dailyData
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 39,
        columnNumber: 9
      }, _this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 38,
      columnNumber: 7
    }, _this)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 23,
    columnNumber: 5
  }, _this);
};

_s(Dashboard, "OuKT1dXiAsKsruOdN9I9yQs7Mns=", false, function () {
  return [_context_BrainContext__WEBPACK_IMPORTED_MODULE_2__.useBrainContext];
});

_c = Dashboard;
/* harmony default export */ __webpack_exports__["default"] = (Dashboard);

var _c;

$RefreshReg$(_c, "Dashboard");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.id);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }


/***/ })

});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic3RhdGljL3dlYnBhY2svcGFnZXMvaW5kZXguMTkxMzA5NjJmMTZiZTEwODcwNDEuaG90LXVwZGF0ZS5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7QUFDQTtBQUNBO0FBQ0E7OztBQVNBLElBQU1TLFNBQW1CLEdBQUcsU0FBdEJBLFNBQXNCLEdBQU07QUFBQTs7QUFFaEMseUJBQXVFRCxzRUFBZSxFQUF0RjtBQUFBLE1BQVFFLFNBQVIsb0JBQVFBLFNBQVI7QUFBQSxNQUFtQkMsUUFBbkIsb0JBQW1CQSxRQUFuQjtBQUFBLE1BQTZCQyxZQUE3QixvQkFBNkJBLFlBQTdCO0FBQUEsTUFBMkNDLFNBQTNDLG9CQUEyQ0EsU0FBM0M7QUFBQSxNQUFzREMsWUFBdEQsb0JBQXNEQSxZQUF0RDs7QUFFQSxNQUFNQyxjQUFjLEdBQUcsU0FBakJBLGNBQWlCLENBQUNDLENBQUQsRUFBTztBQUM1QkMsSUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVlMLFNBQVo7QUFDQUYsSUFBQUEsUUFBUSxDQUFDQyxZQUFELEVBQWVPLFFBQVEsQ0FBQ04sU0FBRCxFQUFZLEVBQVosQ0FBdkIsQ0FBUjtBQUNELEdBSEQ7O0FBS0Esc0JBQ0UsOERBQUMsa0RBQUQ7QUFBTSxhQUFTLEVBQUMsUUFBaEI7QUFBeUIsU0FBSyxFQUFDLE9BQS9CO0FBQXVDLGtCQUFjLEVBQUMsUUFBdEQ7QUFBQSw0QkFDRSw4REFBQyxrREFBRDtBQUFNLGVBQVMsRUFBQyxRQUFoQjtBQUF5QixnQkFBVSxFQUFDLFFBQXBDO0FBQUEsOEJBQ0UsOERBQUMscURBQUQ7QUFBUyxTQUFDLEVBQUUsQ0FBWjtBQUFlLFlBQUksRUFBQyxJQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQURGLGVBRUUsOERBQUMsa0RBQUQ7QUFBTSxZQUFJLEVBQUMsSUFBWDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUZGLGVBR0UsOERBQUMsa0RBQUQ7QUFBQSxnQ0FDRSw4REFBQyxtREFBRDtBQUNFLGVBQUssRUFBQyxPQURSO0FBRUUscUJBQVcsRUFBQyxpQkFGZDtBQUdFLGNBQUksRUFBQyxRQUhQO0FBSUUsZUFBSyxFQUFFQSxTQUpUO0FBS0Usa0JBQVEsRUFBRSxrQkFBQ0csQ0FBRDtBQUFBLG1CQUFPRixZQUFZLENBQUNFLENBQUMsQ0FBQ0ksTUFBRixDQUFTQyxLQUFWLENBQW5CO0FBQUE7QUFMWjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQURGLGVBUUUsOERBQUMsb0RBQUQ7QUFBUSxZQUFFLEVBQUMsS0FBWDtBQUFpQixpQkFBTyxFQUFFTixjQUExQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFSRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFIRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFERixlQWVFLDhEQUFDLGlEQUFEO0FBQUEsNkJBQ0UsOERBQUMsMkNBQUQ7QUFBTyxpQkFBUyxFQUFFTDtBQUFsQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWZGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQURGO0FBcUJELENBOUJEOztHQUFNRDtVQUVtRUQ7OztLQUZuRUM7QUFnQ04sK0RBQWVBLFNBQWYiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vc3JjL2NvbXBvbmVudHMvRGFzaGJvYXJkL2luZGV4LnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBCb3gsIEJ1dHRvbiwgRmxleCwgSGVhZGluZywgSW5wdXQsIFRleHQgfSBmcm9tICdAY2hha3JhLXVpL3JlYWN0JztcbmltcG9ydCBSZWFjdCwgeyB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0JztcbmltcG9ydCBDaGFydCBmcm9tICcuLi9DaGFydCc7XG5pbXBvcnQgeyB1c2VCcmFpbkNvbnRleHQgfSBmcm9tICcuLi8uLi9jb250ZXh0L0JyYWluQ29udGV4dCc7XG5cbnR5cGUgRGFpbHlEYXRhID0ge1xuICBwb3NpdGl2ZTogbnVtYmVyLFxuICByZWNvdmVyZWQ6IG51bWJlcixcbiAgZGVhdGg6IG51bWJlcixcbiAgZGF0ZTogc3RyaW5nXG59XG5cbmNvbnN0IERhc2hib2FyZDogUmVhY3QuRkMgPSAoKSA9PiB7XG5cbiAgY29uc3QgeyBkYWlseURhdGEsIGZvcmVjYXN0LCB0cmFpbmluZ0RhdGEsIGRheXNJbnB1dCwgc2V0RGF5c0lucHV0IH0gPSB1c2VCcmFpbkNvbnRleHQoKTtcblxuICBjb25zdCBoYW5kbGVGb3JlY2FzdCA9IChlKSA9PiB7XG4gICAgY29uc29sZS5sb2coZGF5c0lucHV0KVxuICAgIGZvcmVjYXN0KHRyYWluaW5nRGF0YSwgcGFyc2VJbnQoZGF5c0lucHV0LCAxMCkpXG4gIH1cblxuICByZXR1cm4gKFxuICAgIDxGbGV4IGRpcmVjdGlvbj0nY29sdW1uJyB3aWR0aD0nMTAwdncnIGp1c3RpZnlDb250ZW50PSdjZW50ZXInID5cbiAgICAgIDxGbGV4IGRpcmVjdGlvbj0nY29sdW1uJyBhbGlnbkl0ZW1zPSdjZW50ZXInPlxuICAgICAgICA8SGVhZGluZyBwPXs1fSBzaXplPSd4bCc+SG93IG1hbnkgZGF5cyBhaGVhZCB3b3VsZCB5b3UgbGlrZSB0byBwcmVkaWN0PyA8L0hlYWRpbmc+XG4gICAgICAgIDxUZXh0IHNpemU9J21kJz5UZXh0aW5obyBleHBsaWNhbmRvIGNvaXNhIGJvYTwvVGV4dD5cbiAgICAgICAgPEZsZXg+XG4gICAgICAgICAgPElucHV0XG4gICAgICAgICAgICB3aWR0aD0nMjAwcHgnXG4gICAgICAgICAgICBwbGFjZWhvbGRlcj0nZGF5cyB0byBwcmVkaWN0J1xuICAgICAgICAgICAgdHlwZT0nbnVtYmVyJ1xuICAgICAgICAgICAgdmFsdWU9e2RheXNJbnB1dH1cbiAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0RGF5c0lucHV0KGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAvPlxuICAgICAgICAgIDxCdXR0b24gbWw9JzEuNScgb25DbGljaz17aGFuZGxlRm9yZWNhc3R9PlRyYWluIEFJPC9CdXR0b24+XG4gICAgICAgIDwvRmxleD5cbiAgICAgIDwvRmxleD5cbiAgICAgIDxCb3g+XG4gICAgICAgIDxDaGFydCBkYWlseURhdGE9e2RhaWx5RGF0YX0gLz5cbiAgICAgIDwvQm94PlxuICAgIDwvRmxleD5cbiAgKTtcbn1cblxuZXhwb3J0IGRlZmF1bHQgRGFzaGJvYXJkOyJdLCJuYW1lcyI6WyJCb3giLCJCdXR0b24iLCJGbGV4IiwiSGVhZGluZyIsIklucHV0IiwiVGV4dCIsIlJlYWN0IiwiQ2hhcnQiLCJ1c2VCcmFpbkNvbnRleHQiLCJEYXNoYm9hcmQiLCJkYWlseURhdGEiLCJmb3JlY2FzdCIsInRyYWluaW5nRGF0YSIsImRheXNJbnB1dCIsInNldERheXNJbnB1dCIsImhhbmRsZUZvcmVjYXN0IiwiZSIsImNvbnNvbGUiLCJsb2ciLCJwYXJzZUludCIsInRhcmdldCIsInZhbHVlIl0sInNvdXJjZVJvb3QiOiIifQ==