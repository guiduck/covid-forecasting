"use strict";
self["webpackHotUpdate_N_E"]("pages/index",{

/***/ "./src/components/Chart/index.tsx":
/*!****************************************!*\
  !*** ./src/components/Chart/index.tsx ***!
  \****************************************/
/***/ (function(module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _chakra_ui_react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @chakra-ui/react */ "./node_modules/@chakra-ui/react/dist/chakra-ui-react.esm.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var chart_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! chart.js */ "./node_modules/chart.js/dist/chart.esm.js");
/* harmony import */ var react_chartjs_2__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! react-chartjs-2 */ "./node_modules/react-chartjs-2/dist/index.modern.js");
/* harmony import */ var _context_BrainContext__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../context/BrainContext */ "./src/context/BrainContext.tsx");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__);
/* module decorator */ module = __webpack_require__.hmd(module);
var _jsxFileName = "/home/vittis/dev/github/covid-prediction/src/components/Chart/index.tsx",
    _this = undefined,
    _s = $RefreshSig$();







chart_js__WEBPACK_IMPORTED_MODULE_1__.Chart.register(chart_js__WEBPACK_IMPORTED_MODULE_1__.CategoryScale, chart_js__WEBPACK_IMPORTED_MODULE_1__.LinearScale, chart_js__WEBPACK_IMPORTED_MODULE_1__.PointElement, chart_js__WEBPACK_IMPORTED_MODULE_1__.LineElement, chart_js__WEBPACK_IMPORTED_MODULE_1__.Title, chart_js__WEBPACK_IMPORTED_MODULE_1__.Tooltip, chart_js__WEBPACK_IMPORTED_MODULE_1__.Legend);

var Chart = function Chart(_ref) {
  _s();

  var dailyData = _ref.dailyData;

  var _useBrainContext = (0,_context_BrainContext__WEBPACK_IMPORTED_MODULE_2__.useBrainContext)(),
      setTrainingData = _useBrainContext.setTrainingData,
      trainingChartData = _useBrainContext.trainingChartData,
      predictedChartData = _useBrainContext.predictedChartData,
      training = _useBrainContext.training;

  (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(function () {
    if (dailyData) {
      setTrainingData(dailyData.reverse());
    }
  }, [dailyData]);
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_4__.Flex, {
    children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_4__.Flex, {
      w: "70%",
      p: 50,
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)(react_chartjs_2__WEBPACK_IMPORTED_MODULE_5__.Line, {
        options: trainingChartData.options,
        data: trainingChartData.data
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 41,
        columnNumber: 9
      }, _this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 40,
      columnNumber: 7
    }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_4__.Flex, {
      w: "70%",
      p: 50,
      children: !training ? /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)(react_chartjs_2__WEBPACK_IMPORTED_MODULE_5__.Line, {
        options: predictedChartData.options,
        data: predictedChartData.data
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 44,
        columnNumber: 22
      }, _this) : /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_4__.Spinner, {
        size: "xl"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 44,
        columnNumber: 101
      }, _this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 43,
      columnNumber: 7
    }, _this)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 39,
    columnNumber: 5
  }, _this);
};

_s(Chart, "QpbGdUnUD5AC4mrfTo+LMIIt320=", false, function () {
  return [_context_BrainContext__WEBPACK_IMPORTED_MODULE_2__.useBrainContext];
});

_c = Chart;
/* harmony default export */ __webpack_exports__["default"] = (Chart);

var _c;

$RefreshReg$(_c, "Chart");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.id);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }


/***/ })

});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic3RhdGljL3dlYnBhY2svcGFnZXMvaW5kZXguY2ZjZmZhYzFjOGJiYjhjY2IxMDUuaG90LXVwZGF0ZS5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBQ0E7QUFDQTtBQVVBO0FBQ0E7O0FBRUFLLG9EQUFBLENBQ0VDLG1EQURGLEVBRUVDLGlEQUZGLEVBR0VDLGtEQUhGLEVBSUVDLGlEQUpGLEVBS0VDLDJDQUxGLEVBTUVDLDZDQU5GLEVBT0VDLDRDQVBGOztBQVVBLElBQU1SLEtBQW9CLEdBQUcsU0FBdkJBLEtBQXVCLE9BQW1CO0FBQUE7O0FBQUEsTUFBaEJZLFNBQWdCLFFBQWhCQSxTQUFnQjs7QUFFOUMseUJBQTZFRixzRUFBZSxFQUE1RjtBQUFBLE1BQVFHLGVBQVIsb0JBQVFBLGVBQVI7QUFBQSxNQUF5QkMsaUJBQXpCLG9CQUF5QkEsaUJBQXpCO0FBQUEsTUFBNENDLGtCQUE1QyxvQkFBNENBLGtCQUE1QztBQUFBLE1BQWdFQyxRQUFoRSxvQkFBZ0VBLFFBQWhFOztBQUVBakIsRUFBQUEsZ0RBQVMsQ0FBQyxZQUFNO0FBQ2QsUUFBSWEsU0FBSixFQUFlO0FBQ2JDLE1BQUFBLGVBQWUsQ0FBQ0QsU0FBUyxDQUFDSyxPQUFWLEVBQUQsQ0FBZjtBQUNEO0FBRUYsR0FMUSxFQUtOLENBQUNMLFNBQUQsQ0FMTSxDQUFUO0FBUUEsc0JBQ0UsOERBQUMsa0RBQUQ7QUFBQSw0QkFDRSw4REFBQyxrREFBRDtBQUFNLE9BQUMsRUFBQyxLQUFSO0FBQWMsT0FBQyxFQUFFLEVBQWpCO0FBQUEsNkJBQ0UsOERBQUMsaURBQUQ7QUFBTSxlQUFPLEVBQUVFLGlCQUFpQixDQUFDSSxPQUFqQztBQUEwQyxZQUFJLEVBQUVKLGlCQUFpQixDQUFDSztBQUFsRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQURGLGVBSUUsOERBQUMsa0RBQUQ7QUFBTSxPQUFDLEVBQUMsS0FBUjtBQUFjLE9BQUMsRUFBRSxFQUFqQjtBQUFBLGdCQUNHLENBQUNILFFBQUQsZ0JBQVksOERBQUMsaURBQUQ7QUFBTSxlQUFPLEVBQUVELGtCQUFrQixDQUFDRyxPQUFsQztBQUEyQyxZQUFJLEVBQUVILGtCQUFrQixDQUFDSTtBQUFwRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQVosZ0JBQTJGLDhEQUFDLHFEQUFEO0FBQVMsWUFBSSxFQUFDO0FBQWQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUQ5RjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBREY7QUFXRCxDQXZCRDs7R0FBTW5CO1VBRXlFVTs7O0tBRnpFVjtBQXlCTiwrREFBZUEsS0FBZiIsInNvdXJjZXMiOlsid2VicGFjazovL19OX0UvLi9zcmMvY29tcG9uZW50cy9DaGFydC9pbmRleC50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgRmxleCwgU3Bpbm5lciB9IGZyb20gJ0BjaGFrcmEtdWkvcmVhY3QnO1xuaW1wb3J0IFJlYWN0LCB7IHVzZUVmZmVjdCB9IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7XG4gIENoYXJ0IGFzIENoYXJ0SlMsXG4gIENhdGVnb3J5U2NhbGUsXG4gIExpbmVhclNjYWxlLFxuICBQb2ludEVsZW1lbnQsXG4gIExpbmVFbGVtZW50LFxuICBUaXRsZSxcbiAgVG9vbHRpcCxcbiAgTGVnZW5kLFxufSBmcm9tICdjaGFydC5qcydcbmltcG9ydCB7IExpbmUgfSBmcm9tICdyZWFjdC1jaGFydGpzLTInO1xuaW1wb3J0IHsgdXNlQnJhaW5Db250ZXh0IH0gZnJvbSAnLi4vLi4vY29udGV4dC9CcmFpbkNvbnRleHQnO1xuXG5DaGFydEpTLnJlZ2lzdGVyKFxuICBDYXRlZ29yeVNjYWxlLFxuICBMaW5lYXJTY2FsZSxcbiAgUG9pbnRFbGVtZW50LFxuICBMaW5lRWxlbWVudCxcbiAgVGl0bGUsXG4gIFRvb2x0aXAsXG4gIExlZ2VuZFxuKVxuXG5jb25zdCBDaGFydDogUmVhY3QuRkM8YW55PiA9ICh7IGRhaWx5RGF0YSB9KSA9PiB7XG5cbiAgY29uc3QgeyBzZXRUcmFpbmluZ0RhdGEsIHRyYWluaW5nQ2hhcnREYXRhLCBwcmVkaWN0ZWRDaGFydERhdGEsIHRyYWluaW5nIH0gPSB1c2VCcmFpbkNvbnRleHQoKTtcblxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGlmIChkYWlseURhdGEpIHtcbiAgICAgIHNldFRyYWluaW5nRGF0YShkYWlseURhdGEucmV2ZXJzZSgpKTtcbiAgICB9XG5cbiAgfSwgW2RhaWx5RGF0YV0pXG5cblxuICByZXR1cm4gKFxuICAgIDxGbGV4PlxuICAgICAgPEZsZXggdz0nNzAlJyBwPXs1MH0+XG4gICAgICAgIDxMaW5lIG9wdGlvbnM9e3RyYWluaW5nQ2hhcnREYXRhLm9wdGlvbnN9IGRhdGE9e3RyYWluaW5nQ2hhcnREYXRhLmRhdGF9IC8+XG4gICAgICA8L0ZsZXg+XG4gICAgICA8RmxleCB3PSc3MCUnIHA9ezUwfT5cbiAgICAgICAgeyF0cmFpbmluZyA/IDxMaW5lIG9wdGlvbnM9e3ByZWRpY3RlZENoYXJ0RGF0YS5vcHRpb25zfSBkYXRhPXtwcmVkaWN0ZWRDaGFydERhdGEuZGF0YX0gLz4gOiA8U3Bpbm5lciBzaXplPSd4bCcgLz59XG5cbiAgICAgIDwvRmxleD5cbiAgICA8L0ZsZXg+XG4gICk7XG59XG5cbmV4cG9ydCBkZWZhdWx0IENoYXJ0OyJdLCJuYW1lcyI6WyJGbGV4IiwiU3Bpbm5lciIsIlJlYWN0IiwidXNlRWZmZWN0IiwiQ2hhcnQiLCJDaGFydEpTIiwiQ2F0ZWdvcnlTY2FsZSIsIkxpbmVhclNjYWxlIiwiUG9pbnRFbGVtZW50IiwiTGluZUVsZW1lbnQiLCJUaXRsZSIsIlRvb2x0aXAiLCJMZWdlbmQiLCJMaW5lIiwidXNlQnJhaW5Db250ZXh0IiwicmVnaXN0ZXIiLCJkYWlseURhdGEiLCJzZXRUcmFpbmluZ0RhdGEiLCJ0cmFpbmluZ0NoYXJ0RGF0YSIsInByZWRpY3RlZENoYXJ0RGF0YSIsInRyYWluaW5nIiwicmV2ZXJzZSIsIm9wdGlvbnMiLCJkYXRhIl0sInNvdXJjZVJvb3QiOiIifQ==