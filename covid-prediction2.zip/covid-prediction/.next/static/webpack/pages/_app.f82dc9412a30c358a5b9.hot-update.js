"use strict";
self["webpackHotUpdate_N_E"]("pages/_app",{

/***/ "./src/utils/scaler.ts":
/*!*****************************!*\
  !*** ./src/utils/scaler.ts ***!
  \*****************************/
/***/ (function(module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* module decorator */ module = __webpack_require__.hmd(module);
var X_min = 0;
var X_max = 0;
var min_ = 0;
var max_ = 1;
var data = {
  X_max: X_max,
  X_min: X_min,
  max_: max_,
  min_: min_
};

function fit(X) {
  var min = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 0;
  var max = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : 1;
  X_max = Math.max.apply(null, X);
  X_min = Math.min.apply(null, X);
  min_ = min;
  max_ = max;
  data = {
    X_max: X_max,
    X_min: X_min,
    max_: max_,
    min_: min_
  };
  var X_minArr = X.map(function (values) {
    return values - X_min;
  }); // X_std = (X - X.min()) / (X.max() - X.min())

  var X_std = X_minArr.map(function (values) {
    return values / (X_max - X_min);
  }); // X_scaled = X_std * (max - min) + min

  var X_scaled = X_std.map(function (values) {
    return values * (max - min) + min;
  });
  return X_scaled;
}

function fit_transform(data) {
  var min = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 0;
  var max = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : 1;
  var train_scaled = fit(data, min, max);
  return train_scaled;
}

function inverse_transform(input) {
  var min = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 0;
  var max = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : 1;
  var fit = data;
  console.log(fit);
  var X = input.map(function (values) {
    return (values - min) / (max - min);
  });
  var X_ = X.map(function (values) {
    return values * (fit.X_max - fit.X_min) + fit.X_min;
  });
  return X_;
}

/* harmony default export */ __webpack_exports__["default"] = ({
  fit_transform: fit_transform,
  inverse_transform: inverse_transform
});

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.id);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }


/***/ })

});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic3RhdGljL3dlYnBhY2svcGFnZXMvX2FwcC5mODJkYzk0MTJhMzBjMzU4YTViOS5ob3QtdXBkYXRlLmpzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7O0FBQUEsSUFBSUEsS0FBSyxHQUFHLENBQVo7QUFDQSxJQUFJQyxLQUFLLEdBQUcsQ0FBWjtBQUNBLElBQUlDLElBQUksR0FBRyxDQUFYO0FBQ0EsSUFBSUMsSUFBSSxHQUFHLENBQVg7QUFFQSxJQUFJQyxJQUFJLEdBQUc7QUFBRUgsRUFBQUEsS0FBSyxFQUFFQSxLQUFUO0FBQWdCRCxFQUFBQSxLQUFLLEVBQUVBLEtBQXZCO0FBQThCRyxFQUFBQSxJQUFJLEVBQUVBLElBQXBDO0FBQTBDRCxFQUFBQSxJQUFJLEVBQUVBO0FBQWhELENBQVg7O0FBRUEsU0FBU0csR0FBVCxDQUFhQyxDQUFiLEVBQWtDO0FBQUEsTUFBbEJDLEdBQWtCLHVFQUFaLENBQVk7QUFBQSxNQUFUQyxHQUFTLHVFQUFILENBQUc7QUFDaENQLEVBQUFBLEtBQUssR0FBR1EsSUFBSSxDQUFDRCxHQUFMLENBQVNFLEtBQVQsQ0FBZSxJQUFmLEVBQXFCSixDQUFyQixDQUFSO0FBQ0FOLEVBQUFBLEtBQUssR0FBR1MsSUFBSSxDQUFDRixHQUFMLENBQVNHLEtBQVQsQ0FBZSxJQUFmLEVBQXFCSixDQUFyQixDQUFSO0FBQ0FKLEVBQUFBLElBQUksR0FBR0ssR0FBUDtBQUNBSixFQUFBQSxJQUFJLEdBQUdLLEdBQVA7QUFFQUosRUFBQUEsSUFBSSxHQUFHO0FBQUVILElBQUFBLEtBQUssRUFBRUEsS0FBVDtBQUFnQkQsSUFBQUEsS0FBSyxFQUFFQSxLQUF2QjtBQUE4QkcsSUFBQUEsSUFBSSxFQUFFQSxJQUFwQztBQUEwQ0QsSUFBQUEsSUFBSSxFQUFFQTtBQUFoRCxHQUFQO0FBRUEsTUFBTVMsUUFBUSxHQUFHTCxDQUFDLENBQUNNLEdBQUYsQ0FBTSxVQUFVQyxNQUFWLEVBQWtCO0FBQ3ZDLFdBQU9BLE1BQU0sR0FBR2IsS0FBaEI7QUFDRCxHQUZnQixDQUFqQixDQVJnQyxDQVdoQzs7QUFDQSxNQUFNYyxLQUFLLEdBQUdILFFBQVEsQ0FBQ0MsR0FBVCxDQUFhLFVBQVVDLE1BQVYsRUFBa0I7QUFDM0MsV0FBT0EsTUFBTSxJQUFJWixLQUFLLEdBQUdELEtBQVosQ0FBYjtBQUNELEdBRmEsQ0FBZCxDQVpnQyxDQWVoQzs7QUFDQSxNQUFNZSxRQUFRLEdBQUdELEtBQUssQ0FBQ0YsR0FBTixDQUFVLFVBQVVDLE1BQVYsRUFBa0I7QUFDM0MsV0FBT0EsTUFBTSxJQUFJTCxHQUFHLEdBQUdELEdBQVYsQ0FBTixHQUF1QkEsR0FBOUI7QUFDRCxHQUZnQixDQUFqQjtBQUlBLFNBQU9RLFFBQVA7QUFDRDs7QUFFRCxTQUFTQyxhQUFULENBQXVCWixJQUF2QixFQUErQztBQUFBLE1BQWxCRyxHQUFrQix1RUFBWixDQUFZO0FBQUEsTUFBVEMsR0FBUyx1RUFBSCxDQUFHO0FBQzdDLE1BQU1TLFlBQVksR0FBR1osR0FBRyxDQUFDRCxJQUFELEVBQU9HLEdBQVAsRUFBWUMsR0FBWixDQUF4QjtBQUdBLFNBQU9TLFlBQVA7QUFDRDs7QUFFRCxTQUFTQyxpQkFBVCxDQUEyQkMsS0FBM0IsRUFBb0Q7QUFBQSxNQUFsQlosR0FBa0IsdUVBQVosQ0FBWTtBQUFBLE1BQVRDLEdBQVMsdUVBQUgsQ0FBRztBQUNsRCxNQUFNSCxHQUFHLEdBQUdELElBQVo7QUFDQWdCLEVBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZaEIsR0FBWjtBQUVBLE1BQU1DLENBQUMsR0FBR2EsS0FBSyxDQUFDUCxHQUFOLENBQVUsVUFBVUMsTUFBVixFQUFrQjtBQUNwQyxXQUFPLENBQUNBLE1BQU0sR0FBR04sR0FBVixLQUFrQkMsR0FBRyxHQUFHRCxHQUF4QixDQUFQO0FBQ0QsR0FGUyxDQUFWO0FBR0EsTUFBTWUsRUFBRSxHQUFHaEIsQ0FBQyxDQUFDTSxHQUFGLENBQU0sVUFBVUMsTUFBVixFQUFrQjtBQUNqQyxXQUFPQSxNQUFNLElBQUlSLEdBQUcsQ0FBQ0osS0FBSixHQUFZSSxHQUFHLENBQUNMLEtBQXBCLENBQU4sR0FBbUNLLEdBQUcsQ0FBQ0wsS0FBOUM7QUFDRCxHQUZVLENBQVg7QUFJQSxTQUFPc0IsRUFBUDtBQUNEOztBQUVELCtEQUFlO0FBQUVOLEVBQUFBLGFBQWEsRUFBYkEsYUFBRjtBQUFpQkUsRUFBQUEsaUJBQWlCLEVBQWpCQTtBQUFqQixDQUFmIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vX05fRS8uL3NyYy91dGlscy9zY2FsZXIudHMiXSwic291cmNlc0NvbnRlbnQiOlsibGV0IFhfbWluID0gMDtcbmxldCBYX21heCA9IDA7XG5sZXQgbWluXyA9IDA7XG5sZXQgbWF4XyA9IDE7XG5cbmxldCBkYXRhID0geyBYX21heDogWF9tYXgsIFhfbWluOiBYX21pbiwgbWF4XzogbWF4XywgbWluXzogbWluXyB9O1xuXG5mdW5jdGlvbiBmaXQoWCwgbWluID0gMCwgbWF4ID0gMSkge1xuICBYX21heCA9IE1hdGgubWF4LmFwcGx5KG51bGwsIFgpO1xuICBYX21pbiA9IE1hdGgubWluLmFwcGx5KG51bGwsIFgpO1xuICBtaW5fID0gbWluO1xuICBtYXhfID0gbWF4O1xuXG4gIGRhdGEgPSB7IFhfbWF4OiBYX21heCwgWF9taW46IFhfbWluLCBtYXhfOiBtYXhfLCBtaW5fOiBtaW5fIH07XG5cbiAgY29uc3QgWF9taW5BcnIgPSBYLm1hcChmdW5jdGlvbiAodmFsdWVzKSB7XG4gICAgcmV0dXJuIHZhbHVlcyAtIFhfbWluO1xuICB9KTtcbiAgLy8gWF9zdGQgPSAoWCAtIFgubWluKCkpIC8gKFgubWF4KCkgLSBYLm1pbigpKVxuICBjb25zdCBYX3N0ZCA9IFhfbWluQXJyLm1hcChmdW5jdGlvbiAodmFsdWVzKSB7XG4gICAgcmV0dXJuIHZhbHVlcyAvIChYX21heCAtIFhfbWluKTtcbiAgfSk7XG4gIC8vIFhfc2NhbGVkID0gWF9zdGQgKiAobWF4IC0gbWluKSArIG1pblxuICBjb25zdCBYX3NjYWxlZCA9IFhfc3RkLm1hcChmdW5jdGlvbiAodmFsdWVzKSB7XG4gICAgcmV0dXJuIHZhbHVlcyAqIChtYXggLSBtaW4pICsgbWluO1xuICB9KTtcblxuICByZXR1cm4gWF9zY2FsZWQ7XG59XG5cbmZ1bmN0aW9uIGZpdF90cmFuc2Zvcm0oZGF0YSwgbWluID0gMCwgbWF4ID0gMSkge1xuICBjb25zdCB0cmFpbl9zY2FsZWQgPSBmaXQoZGF0YSwgbWluLCBtYXgpO1xuXG5cbiAgcmV0dXJuIHRyYWluX3NjYWxlZDtcbn1cblxuZnVuY3Rpb24gaW52ZXJzZV90cmFuc2Zvcm0oaW5wdXQsIG1pbiA9IDAsIG1heCA9IDEpIHtcbiAgY29uc3QgZml0ID0gZGF0YTtcbiAgY29uc29sZS5sb2coZml0KVxuXG4gIGNvbnN0IFggPSBpbnB1dC5tYXAoZnVuY3Rpb24gKHZhbHVlcykge1xuICAgIHJldHVybiAodmFsdWVzIC0gbWluKSAvIChtYXggLSBtaW4pO1xuICB9KTtcbiAgY29uc3QgWF8gPSBYLm1hcChmdW5jdGlvbiAodmFsdWVzKSB7XG4gICAgcmV0dXJuIHZhbHVlcyAqIChmaXQuWF9tYXggLSBmaXQuWF9taW4pICsgZml0LlhfbWluO1xuICB9KTtcblxuICByZXR1cm4gWF87XG59XG5cbmV4cG9ydCBkZWZhdWx0IHsgZml0X3RyYW5zZm9ybSwgaW52ZXJzZV90cmFuc2Zvcm0gfTsiXSwibmFtZXMiOlsiWF9taW4iLCJYX21heCIsIm1pbl8iLCJtYXhfIiwiZGF0YSIsImZpdCIsIlgiLCJtaW4iLCJtYXgiLCJNYXRoIiwiYXBwbHkiLCJYX21pbkFyciIsIm1hcCIsInZhbHVlcyIsIlhfc3RkIiwiWF9zY2FsZWQiLCJmaXRfdHJhbnNmb3JtIiwidHJhaW5fc2NhbGVkIiwiaW52ZXJzZV90cmFuc2Zvcm0iLCJpbnB1dCIsImNvbnNvbGUiLCJsb2ciLCJYXyJdLCJzb3VyY2VSb290IjoiIn0=