"use strict";
self["webpackHotUpdate_N_E"]("pages/_app",{

/***/ "./src/context/BrainContext.tsx":
/*!**************************************!*\
  !*** ./src/context/BrainContext.tsx ***!
  \**************************************/
/***/ (function(module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "BrainContext": function() { return /* binding */ BrainContext; },
/* harmony export */   "BrainProvider": function() { return /* binding */ BrainProvider; },
/* harmony export */   "useBrainContext": function() { return /* binding */ useBrainContext; }
/* harmony export */ });
/* harmony import */ var _home_vittis_dev_github_covid_prediction_node_modules_next_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/next/node_modules/@babel/runtime/helpers/esm/asyncToGenerator */ "./node_modules/next/node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var _home_vittis_dev_github_covid_prediction_node_modules_next_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/next/node_modules/@babel/runtime/regenerator */ "./node_modules/next/node_modules/@babel/runtime/regenerator/index.js");
/* harmony import */ var _home_vittis_dev_github_covid_prediction_node_modules_next_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_home_vittis_dev_github_covid_prediction_node_modules_next_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _services_api__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../services/api */ "./src/services/api.ts");
/* harmony import */ var brain_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! brain.js */ "./node_modules/brain.js/dist/src/index");
/* harmony import */ var _utils_scaler__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../utils/scaler */ "./src/utils/scaler.ts");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__);
/* module decorator */ module = __webpack_require__.hmd(module);


var _jsxFileName = "/home/vittis/dev/github/covid-prediction/src/context/BrainContext.tsx",
    _this = undefined,
    _s = $RefreshSig$(),
    _s2 = $RefreshSig$();




 // import scaler from 'minmaxscaler'



var BrainContext = /*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_2__.createContext)({});
var BrainProvider = function BrainProvider(_ref) {
  _s();

  var children = _ref.children;

  var _useState = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(false),
      training = _useState[0],
      setTraining = _useState[1];

  var _useState2 = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)([]),
      dailyData = _useState2[0],
      setDailyData = _useState2[1];

  var _useState3 = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)({}),
      globalData = _useState3[0],
      setGlobalData = _useState3[1];

  var _useState4 = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)([]),
      trainingData = _useState4[0],
      setTrainingData = _useState4[1];

  var _useState5 = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(''),
      daysInput = _useState5[0],
      setDaysInput = _useState5[1];

  var _useState6 = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)([]),
      prediction = _useState6[0],
      setPrediction = _useState6[1];

  var predictedChartData = {
    data: {
      labels: prediction.map(function (n, index) {
        return index;
      }),
      datasets: [{
        data: prediction.map(function (data) {
          return data;
        }),
        label: 'Infected',
        borderColor: 'rgb(53, 162, 235)',
        backgroundColor: 'rgba(53, 162, 235, 0.5)'
      }]
    },
    options: {
      responsive: true,
      plugins: {
        legend: {
          position: 'top'
        },
        title: {
          display: true,
          text: 'Your Covid-19 infection forecasting'
        }
      }
    }
  };
  var trainingChartData = {
    data: {
      labels: trainingData.map(function (_ref2) {
        var date = _ref2.date;
        return new Date(date).toLocaleDateString();
      }),
      datasets: [{
        data: trainingData.map(function (data) {
          return data.confirmed;
        }),
        label: 'Infected',
        borderColor: 'rgb(53, 162, 235)',
        backgroundColor: 'rgba(53, 162, 235, 0.5)'
      }, {
        data: trainingData.map(function (data) {
          return data.deaths;
        }),
        label: 'Deaths',
        borderColor: 'rgb(255, 99, 132)',
        backgroundColor: 'rgba(255, 99, 132, 0.5)'
      }]
    },
    options: {
      responsive: true,
      plugins: {
        legend: {
          position: 'top'
        },
        title: {
          display: true,
          text: 'AI training data'
        }
      }
    }
  };

  var forecast = function forecast(trainingData, daysInput) {
    setTraining(true);
    var newTrainingData = new Array(50).fill(0);

    if (trainingData) {
      for (var i = 0; i <= 50; i++) {
        var _trainingData;

        newTrainingData[i] = (_trainingData = trainingData[trainingData.length - 51 + i]) === null || _trainingData === void 0 ? void 0 : _trainingData.confirmed;
      }
    }

    var scaledData = _utils_scaler__WEBPACK_IMPORTED_MODULE_5__.default.fit_transform(newTrainingData);
    var network = new brain_js__WEBPACK_IMPORTED_MODULE_4__.recurrent.LSTMTimeStep({
      inputSize: 1,
      hiddenLayers: [10],
      outputSize: 1
    });
    network.train([scaledData], {
      learningRate: 0.005,
      errorThresh: 0.01,
      log: function log(stats) {
        console.log(stats);
      }
    });
    var result = network.forecast([1], daysInput);
    setPrediction(_utils_scaler__WEBPACK_IMPORTED_MODULE_5__.default.inverse_transform(result));
    setTraining(false);
  };

  (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(function () {
    var loadDailyData = /*#__PURE__*/function () {
      var _ref3 = (0,_home_vittis_dev_github_covid_prediction_node_modules_next_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0__.default)( /*#__PURE__*/_home_vittis_dev_github_covid_prediction_node_modules_next_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_1___default().mark(function _callee() {
        var initialDailyData;
        return _home_vittis_dev_github_covid_prediction_node_modules_next_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_1___default().wrap(function _callee$(_context) {
          while (1) {
            switch (_context.prev = _context.next) {
              case 0:
                _context.next = 2;
                return (0,_services_api__WEBPACK_IMPORTED_MODULE_3__.fetchDailyData)();

              case 2:
                initialDailyData = _context.sent;

                if (initialDailyData) {
                  setDailyData(initialDailyData);
                }

              case 4:
              case "end":
                return _context.stop();
            }
          }
        }, _callee);
      }));

      return function loadDailyData() {
        return _ref3.apply(this, arguments);
      };
    }();

    var loadGlobalData = /*#__PURE__*/function () {
      var _ref4 = (0,_home_vittis_dev_github_covid_prediction_node_modules_next_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0__.default)( /*#__PURE__*/_home_vittis_dev_github_covid_prediction_node_modules_next_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_1___default().mark(function _callee2() {
        var globalData;
        return _home_vittis_dev_github_covid_prediction_node_modules_next_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_1___default().wrap(function _callee2$(_context2) {
          while (1) {
            switch (_context2.prev = _context2.next) {
              case 0:
                _context2.next = 2;
                return (0,_services_api__WEBPACK_IMPORTED_MODULE_3__.fetchGlobalData)();

              case 2:
                globalData = _context2.sent;

                if (globalData) {
                  setGlobalData(globalData);
                }

              case 4:
              case "end":
                return _context2.stop();
            }
          }
        }, _callee2);
      }));

      return function loadGlobalData() {
        return _ref4.apply(this, arguments);
      };
    }();

    loadDailyData();
    loadGlobalData();
  }, []);
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(BrainContext.Provider, {
    value: {
      trainingData: trainingData,
      setTrainingData: setTrainingData,
      setDailyData: setDailyData,
      dailyData: dailyData,
      trainingChartData: trainingChartData,
      forecast: forecast,
      daysInput: daysInput,
      setDaysInput: setDaysInput,
      prediction: prediction,
      predictedChartData: predictedChartData,
      training: training
    },
    children: children
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 208,
    columnNumber: 5
  }, _this);
}; //easier export

_s(BrainProvider, "Lqs1God9SV0nPJ7CcIpFkA5AQ5A=");

_c = BrainProvider;
var useBrainContext = function useBrainContext() {
  _s2();

  return (0,react__WEBPACK_IMPORTED_MODULE_2__.useContext)(BrainContext);
};

_s2(useBrainContext, "gDsCjeeItUuvgOWf1v4qoK9RF6k=");

var _c;

$RefreshReg$(_c, "BrainProvider");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.id);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }


/***/ })

});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic3RhdGljL3dlYnBhY2svcGFnZXMvX2FwcC41ZjRhZDI0MDk1ZmNmYjY1Y2IwNi5ob3QtdXBkYXRlLmpzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUNBO0NBRUE7O0FBQ0E7O0FBcUZPLElBQU1RLFlBQVksZ0JBQUdSLG9EQUFhLENBQUMsRUFBRCxDQUFsQztBQUVBLElBQU1TLGFBQWEsR0FBRyxTQUFoQkEsYUFBZ0IsT0FBa0I7QUFBQTs7QUFBQSxNQUFmQyxRQUFlLFFBQWZBLFFBQWU7O0FBRTdDLGtCQUFnQ1AsK0NBQVEsQ0FBQyxLQUFELENBQXhDO0FBQUEsTUFBT1EsUUFBUDtBQUFBLE1BQWlCQyxXQUFqQjs7QUFDQSxtQkFBa0NULCtDQUFRLENBQWMsRUFBZCxDQUExQztBQUFBLE1BQU9VLFNBQVA7QUFBQSxNQUFrQkMsWUFBbEI7O0FBQ0EsbUJBQW9DWCwrQ0FBUSxDQUFDLEVBQUQsQ0FBNUM7QUFBQSxNQUFPWSxVQUFQO0FBQUEsTUFBbUJDLGFBQW5COztBQUNBLG1CQUF3Q2IsK0NBQVEsQ0FBaUIsRUFBakIsQ0FBaEQ7QUFBQSxNQUFPYyxZQUFQO0FBQUEsTUFBcUJDLGVBQXJCOztBQUVBLG1CQUFrQ2YsK0NBQVEsQ0FBQyxFQUFELENBQTFDO0FBQUEsTUFBT2dCLFNBQVA7QUFBQSxNQUFrQkMsWUFBbEI7O0FBQ0EsbUJBQW9DakIsK0NBQVEsQ0FBQyxFQUFELENBQTVDO0FBQUEsTUFBT2tCLFVBQVA7QUFBQSxNQUFtQkMsYUFBbkI7O0FBRUEsTUFBTUMsa0JBQWtCLEdBQUc7QUFDekJDLElBQUFBLElBQUksRUFBRTtBQUNKQyxNQUFBQSxNQUFNLEVBQUVKLFVBQVUsQ0FBQ0ssR0FBWCxDQUFlLFVBQUVDLENBQUYsRUFBS0MsS0FBTDtBQUFBLGVBQWdCQSxLQUFoQjtBQUFBLE9BQWYsQ0FESjtBQUVKQyxNQUFBQSxRQUFRLEVBQUUsQ0FBQztBQUNUTCxRQUFBQSxJQUFJLEVBQUVILFVBQVUsQ0FBQ0ssR0FBWCxDQUFlLFVBQUNGLElBQUQ7QUFBQSxpQkFBVUEsSUFBVjtBQUFBLFNBQWYsQ0FERztBQUVUTSxRQUFBQSxLQUFLLEVBQUUsVUFGRTtBQUdUQyxRQUFBQSxXQUFXLEVBQUUsbUJBSEo7QUFJVEMsUUFBQUEsZUFBZSxFQUFFO0FBSlIsT0FBRDtBQUZOLEtBRG1CO0FBVXpCQyxJQUFBQSxPQUFPLEVBQUU7QUFDUEMsTUFBQUEsVUFBVSxFQUFFLElBREw7QUFFUEMsTUFBQUEsT0FBTyxFQUFFO0FBQ1BDLFFBQUFBLE1BQU0sRUFBRTtBQUNOQyxVQUFBQSxRQUFRLEVBQUU7QUFESixTQUREO0FBSVBDLFFBQUFBLEtBQUssRUFBRTtBQUNMQyxVQUFBQSxPQUFPLEVBQUUsSUFESjtBQUVMQyxVQUFBQSxJQUFJLEVBQUU7QUFGRDtBQUpBO0FBRkY7QUFWZ0IsR0FBM0I7QUF3QkEsTUFBTUMsaUJBQWlCLEdBQUc7QUFDeEJqQixJQUFBQSxJQUFJLEVBQUU7QUFDSkMsTUFBQUEsTUFBTSxFQUFFUixZQUFZLENBQUNTLEdBQWIsQ0FBaUI7QUFBQSxZQUFHZ0IsSUFBSCxTQUFHQSxJQUFIO0FBQUEsZUFBYyxJQUFJQyxJQUFKLENBQVNELElBQVQsRUFBZUUsa0JBQWYsRUFBZDtBQUFBLE9BQWpCLENBREo7QUFFSmYsTUFBQUEsUUFBUSxFQUFFLENBQUM7QUFDVEwsUUFBQUEsSUFBSSxFQUFFUCxZQUFZLENBQUNTLEdBQWIsQ0FBaUIsVUFBQ0YsSUFBRDtBQUFBLGlCQUFVQSxJQUFJLENBQUNxQixTQUFmO0FBQUEsU0FBakIsQ0FERztBQUVUZixRQUFBQSxLQUFLLEVBQUUsVUFGRTtBQUdUQyxRQUFBQSxXQUFXLEVBQUUsbUJBSEo7QUFJVEMsUUFBQUEsZUFBZSxFQUFFO0FBSlIsT0FBRCxFQUtQO0FBQ0RSLFFBQUFBLElBQUksRUFBRVAsWUFBWSxDQUFDUyxHQUFiLENBQWlCLFVBQUNGLElBQUQ7QUFBQSxpQkFBVUEsSUFBSSxDQUFDc0IsTUFBZjtBQUFBLFNBQWpCLENBREw7QUFFRGhCLFFBQUFBLEtBQUssRUFBRSxRQUZOO0FBR0RDLFFBQUFBLFdBQVcsRUFBRSxtQkFIWjtBQUlEQyxRQUFBQSxlQUFlLEVBQUU7QUFKaEIsT0FMTztBQUZOLEtBRGtCO0FBZXhCQyxJQUFBQSxPQUFPLEVBQUU7QUFDUEMsTUFBQUEsVUFBVSxFQUFFLElBREw7QUFFUEMsTUFBQUEsT0FBTyxFQUFFO0FBQ1BDLFFBQUFBLE1BQU0sRUFBRTtBQUNOQyxVQUFBQSxRQUFRLEVBQUU7QUFESixTQUREO0FBSVBDLFFBQUFBLEtBQUssRUFBRTtBQUNMQyxVQUFBQSxPQUFPLEVBQUUsSUFESjtBQUVMQyxVQUFBQSxJQUFJLEVBQUU7QUFGRDtBQUpBO0FBRkY7QUFmZSxHQUExQjs7QUE2QkEsTUFBTU8sUUFBUSxHQUFHLFNBQVhBLFFBQVcsQ0FBQzlCLFlBQUQsRUFBK0JFLFNBQS9CLEVBQXFEO0FBQ3BFUCxJQUFBQSxXQUFXLENBQUMsSUFBRCxDQUFYO0FBRUEsUUFBTW9DLGVBQWUsR0FBRyxJQUFJQyxLQUFKLENBQVUsRUFBVixFQUFjQyxJQUFkLENBQW1CLENBQW5CLENBQXhCOztBQUVBLFFBQUlqQyxZQUFKLEVBQWtCO0FBQ2hCLFdBQUksSUFBSWtDLENBQUMsR0FBRyxDQUFaLEVBQWVBLENBQUMsSUFBSSxFQUFwQixFQUF3QkEsQ0FBQyxFQUF6QixFQUE4QjtBQUFBOztBQUM1QkgsUUFBQUEsZUFBZSxDQUFDRyxDQUFELENBQWYsb0JBQXFCbEMsWUFBWSxDQUFDQSxZQUFZLENBQUNtQyxNQUFiLEdBQXNCLEVBQXRCLEdBQTJCRCxDQUE1QixDQUFqQyxrREFBcUIsY0FBNENOLFNBQWpFO0FBQ0Q7QUFDRjs7QUFFRCxRQUFNUSxVQUFVLEdBQUc5QyxnRUFBQSxDQUFxQnlDLGVBQXJCLENBQW5CO0FBRUEsUUFBTU8sT0FBTyxHQUFHLElBQUlqRCw0REFBSixDQUFpQztBQUMvQ29ELE1BQUFBLFNBQVMsRUFBRSxDQURvQztBQUUvQ0MsTUFBQUEsWUFBWSxFQUFFLENBQUMsRUFBRCxDQUZpQztBQUcvQ0MsTUFBQUEsVUFBVSxFQUFFO0FBSG1DLEtBQWpDLENBQWhCO0FBTUFMLElBQUFBLE9BQU8sQ0FBQ00sS0FBUixDQUFjLENBQUNSLFVBQUQsQ0FBZCxFQUE0QjtBQUMxQlMsTUFBQUEsWUFBWSxFQUFFLEtBRFk7QUFFMUJDLE1BQUFBLFdBQVcsRUFBRSxJQUZhO0FBRzFCQyxNQUFBQSxHQUFHLEVBQUUsYUFBQUMsS0FBSyxFQUFJO0FBQ1pDLFFBQUFBLE9BQU8sQ0FBQ0YsR0FBUixDQUFZQyxLQUFaO0FBQ0Q7QUFMeUIsS0FBNUI7QUFRQSxRQUFNRSxNQUFNLEdBQUdaLE9BQU8sQ0FBQ1IsUUFBUixDQUFpQixDQUFDLENBQUQsQ0FBakIsRUFBc0I1QixTQUF0QixDQUFmO0FBQ0FHLElBQUFBLGFBQWEsQ0FBQ2Ysb0VBQUEsQ0FBeUI0RCxNQUF6QixDQUFELENBQWI7QUFDQXZELElBQUFBLFdBQVcsQ0FBQyxLQUFELENBQVg7QUFDRCxHQTlCRDs7QUFnQ0FWLEVBQUFBLGdEQUFTLENBQUMsWUFBTTtBQUNkLFFBQU1tRSxhQUFhO0FBQUEsMFVBQUc7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFDV2pFLDZEQUFjLEVBRHpCOztBQUFBO0FBQ2RrRSxnQkFBQUEsZ0JBRGM7O0FBR3BCLG9CQUFJQSxnQkFBSixFQUFzQjtBQUNwQnhELGtCQUFBQSxZQUFZLENBQUN3RCxnQkFBRCxDQUFaO0FBQ0Q7O0FBTG1CO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE9BQUg7O0FBQUEsc0JBQWJELGFBQWE7QUFBQTtBQUFBO0FBQUEsT0FBbkI7O0FBUUEsUUFBTUUsY0FBYztBQUFBLDBVQUFHO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQ0lsRSw4REFBZSxFQURuQjs7QUFBQTtBQUNmVSxnQkFBQUEsVUFEZTs7QUFFckIsb0JBQUlBLFVBQUosRUFBZ0I7QUFDZEMsa0JBQUFBLGFBQWEsQ0FBQ0QsVUFBRCxDQUFiO0FBQ0Q7O0FBSm9CO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE9BQUg7O0FBQUEsc0JBQWR3RCxjQUFjO0FBQUE7QUFBQTtBQUFBLE9BQXBCOztBQU9BRixJQUFBQSxhQUFhO0FBQ2JFLElBQUFBLGNBQWM7QUFDZixHQWxCUSxFQWtCTixFQWxCTSxDQUFUO0FBb0JBLHNCQUNFLDhEQUFDLFlBQUQsQ0FBYyxRQUFkO0FBQ0UsU0FBSyxFQUFFO0FBQ0x0RCxNQUFBQSxZQUFZLEVBQVpBLFlBREs7QUFFTEMsTUFBQUEsZUFBZSxFQUFmQSxlQUZLO0FBR0xKLE1BQUFBLFlBQVksRUFBWkEsWUFISztBQUlMRCxNQUFBQSxTQUFTLEVBQVRBLFNBSks7QUFLTDRCLE1BQUFBLGlCQUFpQixFQUFqQkEsaUJBTEs7QUFNTE0sTUFBQUEsUUFBUSxFQUFSQSxRQU5LO0FBT0w1QixNQUFBQSxTQUFTLEVBQVRBLFNBUEs7QUFRTEMsTUFBQUEsWUFBWSxFQUFaQSxZQVJLO0FBU0xDLE1BQUFBLFVBQVUsRUFBVkEsVUFUSztBQVVMRSxNQUFBQSxrQkFBa0IsRUFBbEJBLGtCQVZLO0FBV0xaLE1BQUFBLFFBQVEsRUFBUkE7QUFYSyxLQURUO0FBQUEsY0FlR0Q7QUFmSDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBREY7QUFtQkQsQ0F0SU0sRUF3SVA7O0dBeElhRDs7S0FBQUE7QUF5SU4sSUFBTStELGVBQWUsR0FBRyxTQUFsQkEsZUFBa0I7QUFBQTs7QUFBQSxTQUFNdkUsaURBQVUsQ0FBQ08sWUFBRCxDQUFoQjtBQUFBLENBQXhCOztJQUFNZ0UiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vc3JjL2NvbnRleHQvQnJhaW5Db250ZXh0LnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBjcmVhdGVDb250ZXh0LCBEaXNwYXRjaCwgU2V0U3RhdGVBY3Rpb24sIHVzZUNvbnRleHQsIHVzZUVmZmVjdCwgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7IGZldGNoRGFpbHlEYXRhLCBmZXRjaEdsb2JhbERhdGEgfSBmcm9tIFwiLi4vc2VydmljZXMvYXBpXCI7XG5pbXBvcnQgKiBhcyBicmFpbiBmcm9tICdicmFpbi5qcyc7XG4vLyBpbXBvcnQgc2NhbGVyIGZyb20gJ21pbm1heHNjYWxlcidcbmltcG9ydCBzY2FsZXIgZnJvbSAnLi4vdXRpbHMvc2NhbGVyJ1xuXG50eXBlIERhaWx5RGF0YSA9IHtcbiAgcG9zaXRpdmU6IG51bWJlcixcbiAgcmVjb3ZlcmVkOiBudW1iZXIsXG4gIGRlYXRoOiBudW1iZXIsXG4gIGRhdGU6IHN0cmluZ1xufVxuXG50eXBlIFRyYWluaW5nRGF0YSA9IHtcbiAgY29uZmlybWVkOiBudW1iZXIsXG4gIHJlY292ZXJlZDogbnVtYmVyLFxuICBkZWF0aHM6IG51bWJlcixcbiAgZGF0ZTogc3RyaW5nXG59XG5cbnR5cGUgVHJhaW5pbmdDaGFydCA9IHtcbiAgZGF0YToge1xuICAgIGxhYmVsczogc3RyaW5nW107XG4gICAgZGF0YXNldHM6ICh7XG4gICAgICAgIGRhdGE6IG51bWJlcltdO1xuICAgICAgICBsYWJlbDogc3RyaW5nO1xuICAgICAgICBib3JkZXJDb2xvcjogc3RyaW5nO1xuICAgICAgICBiYWNrZ3JvdW5kQ29sb3I6IHN0cmluZztcbiAgICAgICAgZmlsbD86IHVuZGVmaW5lZDtcbiAgICB9IHwge1xuICAgICAgICBkYXRhOiBudW1iZXJbXTtcbiAgICAgICAgbGFiZWw6IHN0cmluZztcbiAgICAgICAgYm9yZGVyQ29sb3I6IHN0cmluZztcbiAgICAgICAgYmFja2dyb3VuZENvbG9yOiBzdHJpbmc7XG4gICAgICAgIGZpbGw6IGJvb2xlYW47XG4gICAgfSlbXTtcbiAgfTtcbiAgb3B0aW9uczoge1xuICAgIHJlc3BvbnNpdmU6IGJvb2xlYW4sXG4gICAgcGx1Z2luczoge1xuICAgICAgbGVnZW5kOiB7XG4gICAgICAgIHBvc2l0aW9uOiBhbnksXG4gICAgICB9LFxuICAgICAgdGl0bGU6IHtcbiAgICAgICAgZGlzcGxheTogYm9vbGVhbixcbiAgICAgICAgdGV4dDogc3RyaW5nLFxuICAgICAgfSxcbiAgICB9XG4gIH07XG59XG5cbnR5cGUgUHJlZGljdGVkQ2hhcnQgPSB7XG4gIGRhdGE6IHtcbiAgICBsYWJlbHM6IG51bWJlcltdO1xuICAgIGRhdGFzZXRzOiB7XG4gICAgICAgIGRhdGE6IG51bWJlcltdO1xuICAgICAgICBsYWJlbDogc3RyaW5nO1xuICAgICAgICBib3JkZXJDb2xvcjogc3RyaW5nO1xuICAgICAgICBiYWNrZ3JvdW5kQ29sb3I6IHN0cmluZztcbiAgICB9W107XG4gIH07XG4gIG9wdGlvbnM6IHtcbiAgICAgIHJlc3BvbnNpdmU6IGJvb2xlYW47XG4gICAgICBwbHVnaW5zOiB7XG4gICAgICAgICAgbGVnZW5kOiB7XG4gICAgICAgICAgICAgIHBvc2l0aW9uOiBhbnk7XG4gICAgICAgICAgfTtcbiAgICAgICAgICB0aXRsZToge1xuICAgICAgICAgICAgICBkaXNwbGF5OiBib29sZWFuO1xuICAgICAgICAgICAgICB0ZXh0OiBzdHJpbmc7XG4gICAgICAgICAgfTtcbiAgICAgIH07XG4gIH07XG59XG5cbnR5cGUgQnJhaW5Db250ZXh0VHlwZSA9IHtcbiAgdHJhaW5pbmdEYXRhOiBUcmFpbmluZ0RhdGFbXSxcbiAgc2V0VHJhaW5pbmdEYXRhOiBEaXNwYXRjaDxTZXRTdGF0ZUFjdGlvbjxUcmFpbmluZ0RhdGFbXT4+LFxuICBzZXREYWlseURhdGE6IERpc3BhdGNoPFNldFN0YXRlQWN0aW9uPERhaWx5RGF0YVtdPj4sXG4gIGRhaWx5RGF0YTogRGFpbHlEYXRhW10sXG4gIHRyYWluaW5nQ2hhcnREYXRhOiBUcmFpbmluZ0NoYXJ0LFxuICBwcmVkaWN0ZWRDaGFydERhdGE6IFByZWRpY3RlZENoYXJ0LFxuICBmb3JlY2FzdDogKGRhdGE6IFRyYWluaW5nRGF0YVtdLCBkYXlzOiBudW1iZXIpID0+IHZvaWQsXG4gIGRheXNJbnB1dDogc3RyaW5nLFxuICBzZXREYXlzSW5wdXQ6IERpc3BhdGNoPFNldFN0YXRlQWN0aW9uPHN0cmluZz4+LFxuICBwcmVkaWN0aW9uOiBudW1iZXJbXSxcbiAgdHJhaW5pbmc6IGJvb2xlYW5cbn1cblxuZXhwb3J0IGNvbnN0IEJyYWluQ29udGV4dCA9IGNyZWF0ZUNvbnRleHQoe30gYXMgQnJhaW5Db250ZXh0VHlwZSlcblxuZXhwb3J0IGNvbnN0IEJyYWluUHJvdmlkZXIgPSAoeyBjaGlsZHJlbiB9KSA9PiB7XG5cbiAgY29uc3QgW3RyYWluaW5nLCBzZXRUcmFpbmluZ10gPSB1c2VTdGF0ZShmYWxzZSlcbiAgY29uc3QgW2RhaWx5RGF0YSwgc2V0RGFpbHlEYXRhXSA9IHVzZVN0YXRlPERhaWx5RGF0YVtdPihbXSlcbiAgY29uc3QgW2dsb2JhbERhdGEsIHNldEdsb2JhbERhdGFdID0gdXNlU3RhdGUoe30pXG4gIGNvbnN0IFt0cmFpbmluZ0RhdGEsIHNldFRyYWluaW5nRGF0YV0gPSB1c2VTdGF0ZTxUcmFpbmluZ0RhdGFbXT4oW10pXG5cbiAgY29uc3QgW2RheXNJbnB1dCwgc2V0RGF5c0lucHV0XSA9IHVzZVN0YXRlKCcnKVxuICBjb25zdCBbcHJlZGljdGlvbiwgc2V0UHJlZGljdGlvbl0gPSB1c2VTdGF0ZShbXSk7XG5cbiAgY29uc3QgcHJlZGljdGVkQ2hhcnREYXRhID0ge1xuICAgIGRhdGE6IHtcbiAgICAgIGxhYmVsczogcHJlZGljdGlvbi5tYXAoKCBuLCBpbmRleCApID0+IGluZGV4KSxcbiAgICAgIGRhdGFzZXRzOiBbe1xuICAgICAgICBkYXRhOiBwcmVkaWN0aW9uLm1hcCgoZGF0YSkgPT4gZGF0YSksXG4gICAgICAgIGxhYmVsOiAnSW5mZWN0ZWQnLFxuICAgICAgICBib3JkZXJDb2xvcjogJ3JnYig1MywgMTYyLCAyMzUpJyxcbiAgICAgICAgYmFja2dyb3VuZENvbG9yOiAncmdiYSg1MywgMTYyLCAyMzUsIDAuNSknLFxuICAgICAgfV0sXG4gICAgfSxcbiAgICBvcHRpb25zOiB7XG4gICAgICByZXNwb25zaXZlOiB0cnVlLFxuICAgICAgcGx1Z2luczoge1xuICAgICAgICBsZWdlbmQ6IHtcbiAgICAgICAgICBwb3NpdGlvbjogJ3RvcCcgYXMgY29uc3QsXG4gICAgICAgIH0sXG4gICAgICAgIHRpdGxlOiB7XG4gICAgICAgICAgZGlzcGxheTogdHJ1ZSxcbiAgICAgICAgICB0ZXh0OiAnWW91ciBDb3ZpZC0xOSBpbmZlY3Rpb24gZm9yZWNhc3RpbmcnLFxuICAgICAgICB9LFxuICAgICAgfVxuICAgIH1cbiAgfVxuXG4gIGNvbnN0IHRyYWluaW5nQ2hhcnREYXRhID0ge1xuICAgIGRhdGE6IHtcbiAgICAgIGxhYmVsczogdHJhaW5pbmdEYXRhLm1hcCgoeyBkYXRlIH0pID0+IG5ldyBEYXRlKGRhdGUpLnRvTG9jYWxlRGF0ZVN0cmluZygpKSxcbiAgICAgIGRhdGFzZXRzOiBbe1xuICAgICAgICBkYXRhOiB0cmFpbmluZ0RhdGEubWFwKChkYXRhKSA9PiBkYXRhLmNvbmZpcm1lZCksXG4gICAgICAgIGxhYmVsOiAnSW5mZWN0ZWQnLFxuICAgICAgICBib3JkZXJDb2xvcjogJ3JnYig1MywgMTYyLCAyMzUpJyxcbiAgICAgICAgYmFja2dyb3VuZENvbG9yOiAncmdiYSg1MywgMTYyLCAyMzUsIDAuNSknLFxuICAgICAgfSwge1xuICAgICAgICBkYXRhOiB0cmFpbmluZ0RhdGEubWFwKChkYXRhKSA9PiBkYXRhLmRlYXRocyksXG4gICAgICAgIGxhYmVsOiAnRGVhdGhzJyxcbiAgICAgICAgYm9yZGVyQ29sb3I6ICdyZ2IoMjU1LCA5OSwgMTMyKScsXG4gICAgICAgIGJhY2tncm91bmRDb2xvcjogJ3JnYmEoMjU1LCA5OSwgMTMyLCAwLjUpJyxcbiAgICAgIH1dLFxuICAgIH0sXG4gICAgb3B0aW9uczoge1xuICAgICAgcmVzcG9uc2l2ZTogdHJ1ZSxcbiAgICAgIHBsdWdpbnM6IHtcbiAgICAgICAgbGVnZW5kOiB7XG4gICAgICAgICAgcG9zaXRpb246ICd0b3AnIGFzIGNvbnN0LFxuICAgICAgICB9LFxuICAgICAgICB0aXRsZToge1xuICAgICAgICAgIGRpc3BsYXk6IHRydWUsXG4gICAgICAgICAgdGV4dDogJ0FJIHRyYWluaW5nIGRhdGEnLFxuICAgICAgICB9LFxuICAgICAgfVxuICAgIH1cbiAgfVxuXG4gIGNvbnN0IGZvcmVjYXN0ID0gKHRyYWluaW5nRGF0YTogVHJhaW5pbmdEYXRhW10sIGRheXNJbnB1dDogbnVtYmVyKSA9PiB7XG4gICAgc2V0VHJhaW5pbmcodHJ1ZSlcblxuICAgIGNvbnN0IG5ld1RyYWluaW5nRGF0YSA9IG5ldyBBcnJheSg1MCkuZmlsbCgwKVxuXG4gICAgaWYgKHRyYWluaW5nRGF0YSkge1xuICAgICAgZm9yKGxldCBpID0gMDsgaSA8PSA1MDsgaSArKykge1xuICAgICAgICBuZXdUcmFpbmluZ0RhdGFbaV0gPSB0cmFpbmluZ0RhdGFbdHJhaW5pbmdEYXRhLmxlbmd0aCAtIDUxICsgaV0/LmNvbmZpcm1lZFxuICAgICAgfVxuICAgIH1cblxuICAgIGNvbnN0IHNjYWxlZERhdGEgPSBzY2FsZXIuZml0X3RyYW5zZm9ybShuZXdUcmFpbmluZ0RhdGEpO1xuXG4gICAgY29uc3QgbmV0d29yayA9IG5ldyBicmFpbi5yZWN1cnJlbnQuTFNUTVRpbWVTdGVwKHtcbiAgICAgIGlucHV0U2l6ZTogMSxcbiAgICAgIGhpZGRlbkxheWVyczogWzEwXSxcbiAgICAgIG91dHB1dFNpemU6IDFcbiAgICB9KVxuXG4gICAgbmV0d29yay50cmFpbihbc2NhbGVkRGF0YV0sIHtcbiAgICAgIGxlYXJuaW5nUmF0ZTogMC4wMDUsXG4gICAgICBlcnJvclRocmVzaDogMC4wMSxcbiAgICAgIGxvZzogc3RhdHMgPT4ge1xuICAgICAgICBjb25zb2xlLmxvZyhzdGF0cyk7XG4gICAgICB9XG4gICAgfSlcblxuICAgIGNvbnN0IHJlc3VsdCA9IG5ldHdvcmsuZm9yZWNhc3QoWzFdLCBkYXlzSW5wdXQpXG4gICAgc2V0UHJlZGljdGlvbihzY2FsZXIuaW52ZXJzZV90cmFuc2Zvcm0ocmVzdWx0KSlcbiAgICBzZXRUcmFpbmluZyhmYWxzZSlcbiAgfVxuXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgY29uc3QgbG9hZERhaWx5RGF0YSA9IGFzeW5jICgpID0+IHtcbiAgICAgIGNvbnN0IGluaXRpYWxEYWlseURhdGEgPSBhd2FpdCBmZXRjaERhaWx5RGF0YSgpXG5cbiAgICAgIGlmIChpbml0aWFsRGFpbHlEYXRhKSB7XG4gICAgICAgIHNldERhaWx5RGF0YShpbml0aWFsRGFpbHlEYXRhKTtcbiAgICAgIH1cbiAgICB9XG5cbiAgICBjb25zdCBsb2FkR2xvYmFsRGF0YSA9IGFzeW5jICgpID0+IHtcbiAgICAgIGNvbnN0IGdsb2JhbERhdGEgPSBhd2FpdCBmZXRjaEdsb2JhbERhdGEoKVxuICAgICAgaWYgKGdsb2JhbERhdGEpIHtcbiAgICAgICAgc2V0R2xvYmFsRGF0YShnbG9iYWxEYXRhKVxuICAgICAgfVxuICAgIH1cblxuICAgIGxvYWREYWlseURhdGEoKVxuICAgIGxvYWRHbG9iYWxEYXRhKClcbiAgfSwgW10pXG5cbiAgcmV0dXJuIChcbiAgICA8QnJhaW5Db250ZXh0LlByb3ZpZGVyXG4gICAgICB2YWx1ZT17e1xuICAgICAgICB0cmFpbmluZ0RhdGEsXG4gICAgICAgIHNldFRyYWluaW5nRGF0YSxcbiAgICAgICAgc2V0RGFpbHlEYXRhLFxuICAgICAgICBkYWlseURhdGEsXG4gICAgICAgIHRyYWluaW5nQ2hhcnREYXRhLFxuICAgICAgICBmb3JlY2FzdCxcbiAgICAgICAgZGF5c0lucHV0LFxuICAgICAgICBzZXREYXlzSW5wdXQsXG4gICAgICAgIHByZWRpY3Rpb24sXG4gICAgICAgIHByZWRpY3RlZENoYXJ0RGF0YSxcbiAgICAgICAgdHJhaW5pbmdcbiAgICAgIH19XG4gICAgPlxuICAgICAge2NoaWxkcmVufVxuICAgIDwvQnJhaW5Db250ZXh0LlByb3ZpZGVyPlxuICApO1xufVxuXG4vL2Vhc2llciBleHBvcnRcbmV4cG9ydCBjb25zdCB1c2VCcmFpbkNvbnRleHQgPSAoKSA9PiB1c2VDb250ZXh0KEJyYWluQ29udGV4dCk7XG4iXSwibmFtZXMiOlsiY3JlYXRlQ29udGV4dCIsInVzZUNvbnRleHQiLCJ1c2VFZmZlY3QiLCJ1c2VTdGF0ZSIsImZldGNoRGFpbHlEYXRhIiwiZmV0Y2hHbG9iYWxEYXRhIiwiYnJhaW4iLCJzY2FsZXIiLCJCcmFpbkNvbnRleHQiLCJCcmFpblByb3ZpZGVyIiwiY2hpbGRyZW4iLCJ0cmFpbmluZyIsInNldFRyYWluaW5nIiwiZGFpbHlEYXRhIiwic2V0RGFpbHlEYXRhIiwiZ2xvYmFsRGF0YSIsInNldEdsb2JhbERhdGEiLCJ0cmFpbmluZ0RhdGEiLCJzZXRUcmFpbmluZ0RhdGEiLCJkYXlzSW5wdXQiLCJzZXREYXlzSW5wdXQiLCJwcmVkaWN0aW9uIiwic2V0UHJlZGljdGlvbiIsInByZWRpY3RlZENoYXJ0RGF0YSIsImRhdGEiLCJsYWJlbHMiLCJtYXAiLCJuIiwiaW5kZXgiLCJkYXRhc2V0cyIsImxhYmVsIiwiYm9yZGVyQ29sb3IiLCJiYWNrZ3JvdW5kQ29sb3IiLCJvcHRpb25zIiwicmVzcG9uc2l2ZSIsInBsdWdpbnMiLCJsZWdlbmQiLCJwb3NpdGlvbiIsInRpdGxlIiwiZGlzcGxheSIsInRleHQiLCJ0cmFpbmluZ0NoYXJ0RGF0YSIsImRhdGUiLCJEYXRlIiwidG9Mb2NhbGVEYXRlU3RyaW5nIiwiY29uZmlybWVkIiwiZGVhdGhzIiwiZm9yZWNhc3QiLCJuZXdUcmFpbmluZ0RhdGEiLCJBcnJheSIsImZpbGwiLCJpIiwibGVuZ3RoIiwic2NhbGVkRGF0YSIsImZpdF90cmFuc2Zvcm0iLCJuZXR3b3JrIiwicmVjdXJyZW50IiwiTFNUTVRpbWVTdGVwIiwiaW5wdXRTaXplIiwiaGlkZGVuTGF5ZXJzIiwib3V0cHV0U2l6ZSIsInRyYWluIiwibGVhcm5pbmdSYXRlIiwiZXJyb3JUaHJlc2giLCJsb2ciLCJzdGF0cyIsImNvbnNvbGUiLCJyZXN1bHQiLCJpbnZlcnNlX3RyYW5zZm9ybSIsImxvYWREYWlseURhdGEiLCJpbml0aWFsRGFpbHlEYXRhIiwibG9hZEdsb2JhbERhdGEiLCJ1c2VCcmFpbkNvbnRleHQiXSwic291cmNlUm9vdCI6IiJ9