"use strict";
self["webpackHotUpdate_N_E"]("pages/index",{

/***/ "./src/utils/scaler.ts":
/*!*****************************!*\
  !*** ./src/utils/scaler.ts ***!
  \*****************************/
/***/ (function(module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* module decorator */ module = __webpack_require__.hmd(module);
var X_min = 0;
var X_max = 0;
var min_ = 0;
var max_ = 1;
var data = {
  X_max: X_max,
  X_min: X_min,
  max_: max_,
  min_: min_
};

function fit(X) {
  var min = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 0;
  var max = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : 1;
  X_max = Math.max.apply(null, X);
  X_min = Math.min.apply(null, X);
  min_ = min;
  max_ = max;
  data = {
    X_max: X_max,
    X_min: X_min,
    max_: max_,
    min_: min_
  };
  var X_minArr = X.map(function (values) {
    return values - X_min;
  }); // X_std = (X - X.min()) / (X.max() - X.min())

  var X_std = X_minArr.map(function (values) {
    return values / (X_max - X_min);
  }); // X_scaled = X_std * (max - min) + min

  var X_scaled = X_std.map(function (values) {
    return values * (max - min) + min;
  });
  return X_scaled;
}

function fit_transform(data) {
  var min = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 0;
  var max = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : 1;
  var train_scaled = fit(data, min, max);
  return train_scaled;
}

function inverse_transform(input) {
  var min = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 0;
  var max = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : 1;
  var fit = data;
  console.log(fit);
  var X = input.map(function (values) {
    return (values - min) / (max - min);
  });
  var X_ = X.map(function (values) {
    return values * (fit.X_max - fit.X_min) + fit.X_min;
  });
  return X_;
}

/* harmony default export */ __webpack_exports__["default"] = ({
  fit_transform: fit_transform,
  inverse_transform: inverse_transform
});

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.id);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }


/***/ })

});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic3RhdGljL3dlYnBhY2svcGFnZXMvaW5kZXguZjgyZGM5NDEyYTMwYzM1OGE1YjkuaG90LXVwZGF0ZS5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7OztBQUFBLElBQUlBLEtBQUssR0FBRyxDQUFaO0FBQ0EsSUFBSUMsS0FBSyxHQUFHLENBQVo7QUFDQSxJQUFJQyxJQUFJLEdBQUcsQ0FBWDtBQUNBLElBQUlDLElBQUksR0FBRyxDQUFYO0FBRUEsSUFBSUMsSUFBSSxHQUFHO0FBQUVILEVBQUFBLEtBQUssRUFBRUEsS0FBVDtBQUFnQkQsRUFBQUEsS0FBSyxFQUFFQSxLQUF2QjtBQUE4QkcsRUFBQUEsSUFBSSxFQUFFQSxJQUFwQztBQUEwQ0QsRUFBQUEsSUFBSSxFQUFFQTtBQUFoRCxDQUFYOztBQUVBLFNBQVNHLEdBQVQsQ0FBYUMsQ0FBYixFQUFrQztBQUFBLE1BQWxCQyxHQUFrQix1RUFBWixDQUFZO0FBQUEsTUFBVEMsR0FBUyx1RUFBSCxDQUFHO0FBQ2hDUCxFQUFBQSxLQUFLLEdBQUdRLElBQUksQ0FBQ0QsR0FBTCxDQUFTRSxLQUFULENBQWUsSUFBZixFQUFxQkosQ0FBckIsQ0FBUjtBQUNBTixFQUFBQSxLQUFLLEdBQUdTLElBQUksQ0FBQ0YsR0FBTCxDQUFTRyxLQUFULENBQWUsSUFBZixFQUFxQkosQ0FBckIsQ0FBUjtBQUNBSixFQUFBQSxJQUFJLEdBQUdLLEdBQVA7QUFDQUosRUFBQUEsSUFBSSxHQUFHSyxHQUFQO0FBRUFKLEVBQUFBLElBQUksR0FBRztBQUFFSCxJQUFBQSxLQUFLLEVBQUVBLEtBQVQ7QUFBZ0JELElBQUFBLEtBQUssRUFBRUEsS0FBdkI7QUFBOEJHLElBQUFBLElBQUksRUFBRUEsSUFBcEM7QUFBMENELElBQUFBLElBQUksRUFBRUE7QUFBaEQsR0FBUDtBQUVBLE1BQU1TLFFBQVEsR0FBR0wsQ0FBQyxDQUFDTSxHQUFGLENBQU0sVUFBVUMsTUFBVixFQUFrQjtBQUN2QyxXQUFPQSxNQUFNLEdBQUdiLEtBQWhCO0FBQ0QsR0FGZ0IsQ0FBakIsQ0FSZ0MsQ0FXaEM7O0FBQ0EsTUFBTWMsS0FBSyxHQUFHSCxRQUFRLENBQUNDLEdBQVQsQ0FBYSxVQUFVQyxNQUFWLEVBQWtCO0FBQzNDLFdBQU9BLE1BQU0sSUFBSVosS0FBSyxHQUFHRCxLQUFaLENBQWI7QUFDRCxHQUZhLENBQWQsQ0FaZ0MsQ0FlaEM7O0FBQ0EsTUFBTWUsUUFBUSxHQUFHRCxLQUFLLENBQUNGLEdBQU4sQ0FBVSxVQUFVQyxNQUFWLEVBQWtCO0FBQzNDLFdBQU9BLE1BQU0sSUFBSUwsR0FBRyxHQUFHRCxHQUFWLENBQU4sR0FBdUJBLEdBQTlCO0FBQ0QsR0FGZ0IsQ0FBakI7QUFJQSxTQUFPUSxRQUFQO0FBQ0Q7O0FBRUQsU0FBU0MsYUFBVCxDQUF1QlosSUFBdkIsRUFBK0M7QUFBQSxNQUFsQkcsR0FBa0IsdUVBQVosQ0FBWTtBQUFBLE1BQVRDLEdBQVMsdUVBQUgsQ0FBRztBQUM3QyxNQUFNUyxZQUFZLEdBQUdaLEdBQUcsQ0FBQ0QsSUFBRCxFQUFPRyxHQUFQLEVBQVlDLEdBQVosQ0FBeEI7QUFHQSxTQUFPUyxZQUFQO0FBQ0Q7O0FBRUQsU0FBU0MsaUJBQVQsQ0FBMkJDLEtBQTNCLEVBQW9EO0FBQUEsTUFBbEJaLEdBQWtCLHVFQUFaLENBQVk7QUFBQSxNQUFUQyxHQUFTLHVFQUFILENBQUc7QUFDbEQsTUFBTUgsR0FBRyxHQUFHRCxJQUFaO0FBQ0FnQixFQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWWhCLEdBQVo7QUFFQSxNQUFNQyxDQUFDLEdBQUdhLEtBQUssQ0FBQ1AsR0FBTixDQUFVLFVBQVVDLE1BQVYsRUFBa0I7QUFDcEMsV0FBTyxDQUFDQSxNQUFNLEdBQUdOLEdBQVYsS0FBa0JDLEdBQUcsR0FBR0QsR0FBeEIsQ0FBUDtBQUNELEdBRlMsQ0FBVjtBQUdBLE1BQU1lLEVBQUUsR0FBR2hCLENBQUMsQ0FBQ00sR0FBRixDQUFNLFVBQVVDLE1BQVYsRUFBa0I7QUFDakMsV0FBT0EsTUFBTSxJQUFJUixHQUFHLENBQUNKLEtBQUosR0FBWUksR0FBRyxDQUFDTCxLQUFwQixDQUFOLEdBQW1DSyxHQUFHLENBQUNMLEtBQTlDO0FBQ0QsR0FGVSxDQUFYO0FBSUEsU0FBT3NCLEVBQVA7QUFDRDs7QUFFRCwrREFBZTtBQUFFTixFQUFBQSxhQUFhLEVBQWJBLGFBQUY7QUFBaUJFLEVBQUFBLGlCQUFpQixFQUFqQkE7QUFBakIsQ0FBZiIsInNvdXJjZXMiOlsid2VicGFjazovL19OX0UvLi9zcmMvdXRpbHMvc2NhbGVyLnRzIl0sInNvdXJjZXNDb250ZW50IjpbImxldCBYX21pbiA9IDA7XG5sZXQgWF9tYXggPSAwO1xubGV0IG1pbl8gPSAwO1xubGV0IG1heF8gPSAxO1xuXG5sZXQgZGF0YSA9IHsgWF9tYXg6IFhfbWF4LCBYX21pbjogWF9taW4sIG1heF86IG1heF8sIG1pbl86IG1pbl8gfTtcblxuZnVuY3Rpb24gZml0KFgsIG1pbiA9IDAsIG1heCA9IDEpIHtcbiAgWF9tYXggPSBNYXRoLm1heC5hcHBseShudWxsLCBYKTtcbiAgWF9taW4gPSBNYXRoLm1pbi5hcHBseShudWxsLCBYKTtcbiAgbWluXyA9IG1pbjtcbiAgbWF4XyA9IG1heDtcblxuICBkYXRhID0geyBYX21heDogWF9tYXgsIFhfbWluOiBYX21pbiwgbWF4XzogbWF4XywgbWluXzogbWluXyB9O1xuXG4gIGNvbnN0IFhfbWluQXJyID0gWC5tYXAoZnVuY3Rpb24gKHZhbHVlcykge1xuICAgIHJldHVybiB2YWx1ZXMgLSBYX21pbjtcbiAgfSk7XG4gIC8vIFhfc3RkID0gKFggLSBYLm1pbigpKSAvIChYLm1heCgpIC0gWC5taW4oKSlcbiAgY29uc3QgWF9zdGQgPSBYX21pbkFyci5tYXAoZnVuY3Rpb24gKHZhbHVlcykge1xuICAgIHJldHVybiB2YWx1ZXMgLyAoWF9tYXggLSBYX21pbik7XG4gIH0pO1xuICAvLyBYX3NjYWxlZCA9IFhfc3RkICogKG1heCAtIG1pbikgKyBtaW5cbiAgY29uc3QgWF9zY2FsZWQgPSBYX3N0ZC5tYXAoZnVuY3Rpb24gKHZhbHVlcykge1xuICAgIHJldHVybiB2YWx1ZXMgKiAobWF4IC0gbWluKSArIG1pbjtcbiAgfSk7XG5cbiAgcmV0dXJuIFhfc2NhbGVkO1xufVxuXG5mdW5jdGlvbiBmaXRfdHJhbnNmb3JtKGRhdGEsIG1pbiA9IDAsIG1heCA9IDEpIHtcbiAgY29uc3QgdHJhaW5fc2NhbGVkID0gZml0KGRhdGEsIG1pbiwgbWF4KTtcblxuXG4gIHJldHVybiB0cmFpbl9zY2FsZWQ7XG59XG5cbmZ1bmN0aW9uIGludmVyc2VfdHJhbnNmb3JtKGlucHV0LCBtaW4gPSAwLCBtYXggPSAxKSB7XG4gIGNvbnN0IGZpdCA9IGRhdGE7XG4gIGNvbnNvbGUubG9nKGZpdClcblxuICBjb25zdCBYID0gaW5wdXQubWFwKGZ1bmN0aW9uICh2YWx1ZXMpIHtcbiAgICByZXR1cm4gKHZhbHVlcyAtIG1pbikgLyAobWF4IC0gbWluKTtcbiAgfSk7XG4gIGNvbnN0IFhfID0gWC5tYXAoZnVuY3Rpb24gKHZhbHVlcykge1xuICAgIHJldHVybiB2YWx1ZXMgKiAoZml0LlhfbWF4IC0gZml0LlhfbWluKSArIGZpdC5YX21pbjtcbiAgfSk7XG5cbiAgcmV0dXJuIFhfO1xufVxuXG5leHBvcnQgZGVmYXVsdCB7IGZpdF90cmFuc2Zvcm0sIGludmVyc2VfdHJhbnNmb3JtIH07Il0sIm5hbWVzIjpbIlhfbWluIiwiWF9tYXgiLCJtaW5fIiwibWF4XyIsImRhdGEiLCJmaXQiLCJYIiwibWluIiwibWF4IiwiTWF0aCIsImFwcGx5IiwiWF9taW5BcnIiLCJtYXAiLCJ2YWx1ZXMiLCJYX3N0ZCIsIlhfc2NhbGVkIiwiZml0X3RyYW5zZm9ybSIsInRyYWluX3NjYWxlZCIsImludmVyc2VfdHJhbnNmb3JtIiwiaW5wdXQiLCJjb25zb2xlIiwibG9nIiwiWF8iXSwic291cmNlUm9vdCI6IiJ9