"use strict";
(() => {
var exports = {};
exports.id = "pages/_app";
exports.ids = ["pages/_app"];
exports.modules = {

/***/ "./node_modules/brain.js/dist/src/index":
/*!**********************************************!*\
  !*** ./node_modules/brain.js/dist/src/index ***!
  \**********************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {



Object.defineProperty(exports, "__esModule", ({ value: true }));

var gpu_js = __webpack_require__(/*! gpu.js */ "gpu.js");
var stream = __webpack_require__(/*! stream */ "stream");

/**
 * Relu Activation, aka Rectified Linear Unit Activation
 * @description https://en.wikipedia.org/wiki/Rectifier_(neural_networks)
 */
function activate$3(weight) {
    return Math.max(0, weight);
}
/**
 * Relu derivative
 */
function measure$3(weight, delta) {
    if (weight <= 0) {
        return 0;
    }
    return delta;
}

var relu$2 = /*#__PURE__*/Object.freeze({
    __proto__: null,
    activate: activate$3,
    measure: measure$3
});

/**
 * sigmoid activation
 */
function activate$2(value) {
    return 1 / (1 + Math.exp(-value));
}
/**
 * sigmoid derivative
 */
function measure$2(weight, error) {
    return weight * (1 - weight) * error;
}

var sigmoid$2 = /*#__PURE__*/Object.freeze({
    __proto__: null,
    activate: activate$2,
    measure: measure$2
});

/**
 * Hyperbolic tan
 */
function activate$1(weight) {
    return Math.tanh(weight);
}
/**
 * @description grad for z = tanh(x) is (1 - z^2)
 */
function measure$1(weight, error) {
    return (1 - weight * weight) * error;
}

var tanh$2 = /*#__PURE__*/Object.freeze({
    __proto__: null,
    activate: activate$1,
    measure: measure$1
});

/**
 * Leaky Relu Activation, aka Leaky Rectified Linear Unit Activation
 * @description https://en.wikipedia.org/wiki/Rectifier_(neural_networks)
 */
function activate(weight) {
    return weight > 0 ? weight : 0.01 * weight;
}
/**
 * Leaky Relu derivative
 */
function measure(weight, error) {
    return weight > 0 ? error : 0.01 * error;
}

var leakyRelu$1 = /*#__PURE__*/Object.freeze({
    __proto__: null,
    activate: activate,
    measure: measure
});

var index$1 = /*#__PURE__*/Object.freeze({
    __proto__: null,
    relu: relu$2,
    sigmoid: sigmoid$2,
    tanh: tanh$2,
    leakyRelu: leakyRelu$1
});

class CrossValidate {
    constructor(initClassifier) {
        this.json = {
            avgs: {
                error: 0,
                iterations: 0,
                testTime: 0,
                trainTime: 0,
            },
            stats: {
                total: 0,
                testSize: 0,
                trainSize: 0,
            },
            sets: [],
        };
        this.initClassifier = initClassifier;
    }
    testPartition(trainOpts, trainSet, testSet) {
        const classifier = this.initClassifier();
        const beginTrain = Date.now();
        const trainingStats = classifier.train(trainSet, trainOpts);
        const beginTest = Date.now();
        const testStats = classifier.test(testSet);
        const endTest = Date.now();
        return {
            ...testStats,
            trainTime: beginTest - beginTrain,
            testTime: endTest - beginTest,
            iterations: trainingStats.iterations,
            error: trainingStats.error,
            total: testStats.total,
            network: classifier.toJSON(),
        };
    }
    /**
     * Randomize array element order in-place.
     * Using Durstenfeld shuffle algorithm.
     * source: http://stackoverflow.com/a/12646864/1324039
     */
    shuffleArray(array) {
        for (let i = array.length - 1; i > 0; i--) {
            const j = Math.floor(Math.random() * (i + 1));
            const temp = array[i];
            array[i] = array[j];
            array[j] = temp;
        }
        return array;
    }
    train(data, trainOpts = {}, k = 4) {
        if (data.length < k) {
            throw new Error(`Training set size is too small for ${data.length} k folds of ${k}`);
        }
        this.shuffleArray(data);
        const size = data.length / k;
        const avgs = {
            trainTime: 0,
            testTime: 0,
            iterations: 0,
            error: 0,
        };
        const stats = {
            total: 0,
            testSize: 0,
            trainSize: 0,
        };
        const binaryStats = {
            total: 0,
            testSize: 0,
            trainSize: 0,
            truePos: 0,
            trueNeg: 0,
            falsePos: 0,
            falseNeg: 0,
            precision: 0,
            recall: 0,
            accuracy: 0,
        };
        const results = [];
        let isBinary = null;
        for (let i = 0; i < k; i++) {
            const dclone = data.slice(0);
            const testSet = dclone.splice(i * size, size);
            const trainSet = dclone;
            const result = this.testPartition(trainOpts, trainSet, testSet);
            if (isBinary === null) {
                isBinary =
                    result.hasOwnProperty('falseNeg') &&
                        result.hasOwnProperty('falsePos') &&
                        result.hasOwnProperty('trueNeg') &&
                        result.hasOwnProperty('truePos');
                if (isBinary) {
                    Object.assign(stats, binaryStats);
                }
            }
            avgs.iterations += result.iterations;
            avgs.testTime += result.testTime;
            avgs.trainTime += result.trainTime;
            avgs.error += result.error;
            stats.total += result.total;
            if (CrossValidate.isBinaryStats(stats) &&
                CrossValidate.isBinaryPartitionResults(result)) {
                stats.accuracy += result.accuracy;
                stats.falseNeg += result.falseNeg;
                stats.falsePos += result.falsePos;
                stats.precision += result.precision;
                stats.recall += result.recall;
                stats.trueNeg += result.trueNeg;
                stats.truePos += result.truePos;
            }
            results.push(result);
        }
        avgs.error /= k;
        avgs.iterations /= k;
        avgs.testTime /= k;
        avgs.trainTime /= k;
        if (CrossValidate.isBinaryStats(stats)) {
            stats.precision = stats.truePos / (stats.truePos + stats.falsePos);
            stats.recall = stats.truePos / (stats.truePos + stats.falseNeg);
            stats.accuracy = (stats.trueNeg + stats.truePos) / stats.total;
        }
        stats.testSize = size;
        stats.trainSize = data.length - size;
        this.json = {
            avgs: avgs,
            stats: stats,
            sets: results,
        };
        return this.json;
    }
    toNeuralNetwork() {
        return this.fromJSON(this.json);
    }
    toJSON() {
        return this.json;
    }
    fromJSON(crossValidateJson) {
        const winningJSON = crossValidateJson.sets.reduce((prev, cur) => (prev.error < cur.error ? prev : cur));
        return this.initClassifier().fromJSON(winningJSON.network);
    }
}
CrossValidate.isBinaryStats = (stats) => {
    return (stats.accuracy !== undefined);
};
CrossValidate.isBinaryResults = (stats) => stats.stats.accuracy !== undefined;
CrossValidate.isBinaryPartitionResults = (stats) => stats.accuracy !==
    undefined;

let gpuInstance = null;
/**
 * Sets up the gpu.js instance
 */
function setup(value) {
    gpuInstance = value;
}
function makeKernel(fn, settings) {
    let _gpuInstance = gpuInstance;
    if (_gpuInstance === null) {
        _gpuInstance = new gpu_js.GPU({ mode: 'gpu' });
        setup(_gpuInstance);
    }
    return _gpuInstance
        .createKernel(fn, settings)
        .setPipeline(true);
}
function makeKernelMap(map, fn, settings) {
    let _gpuInstance = gpuInstance;
    if (_gpuInstance === null) {
        _gpuInstance = new gpu_js.GPU({ mode: 'gpu' });
        setup(_gpuInstance);
    }
    return _gpuInstance
        .createKernelMap(map, fn, settings)
        .setPipeline(true);
}
/**
 * Compiles a function into a gpu.js dev mode kernel
 */
// export function makeDevKernel(
//   fn: ThreadFunction,
//   settings: makeKernelSettings
// ): IKernelRunShortcut {
//   if ('map' in settings) {
//     throw new Error('map kernels are not supported by dev kernels');
//   }
//   const gpu = new GPU({ mode: 'dev' });
//   return gpu.createKernel(fn, settings);
// }
function kernelInput(value, size) {
    return new gpu_js.Input(value, size);
}
/**
 * Deletes a gpu.js texture and frees VRAM
 */
function release(possibleTexture) {
    if (possibleTexture instanceof gpu_js.Texture) {
        possibleTexture.delete();
    }
}
/**
 * Cleans ie sets all elements to 0 of a Texture or a js array
 */
function clear(value) {
    if (value instanceof gpu_js.Texture) {
        value.clear();
        return;
    }
    // array
    if (Array.isArray(value)) {
        if (typeof value[0] === 'number') {
            value.fill(0);
        }
        else if (typeof value[0][0] === 'number') {
            for (let x = 0; x < value.length; x++) {
                value[x].fill(0);
            }
            return;
        }
        else if (typeof value[0][0][0] === 'number') {
            // cube
            for (let y = 0; y < value.length; y++) {
                const row = value[y];
                for (let x = 0; x < row.length; x++) {
                    row[x].fill(0);
                }
            }
            return;
        }
    }
    throw new Error('unhandled value');
}
/**
 * Clones a value
 */
function clone(value) {
    if (value instanceof gpu_js.Texture) {
        return value.clone();
    }
    if (value instanceof Float32Array) {
        return value.slice(0);
    }
    if (Array.isArray(value)) {
        if (typeof value[0] === 'number') {
            return value.slice(0);
        }
        else if (typeof value[0][0] === 'number') {
            const matrix = new Array(value.length);
            for (let x = 0; x < value.length; x++) {
                matrix[x] = value[x].slice(0);
            }
            return matrix;
        }
        else if (typeof value[0][0][0] === 'number') {
            const cube = new Array(value.length);
            for (let y = 0; y < value.length; y++) {
                const row = value[y];
                const matrix = new Array(row.length);
                for (let x = 0; x < row.length; x++) {
                    matrix[x] = row[x].slice(0);
                }
            }
            return cube;
        }
    }
    throw new Error('unhandled value');
}

/**
 * 2D Mean Squared Error
 */
function mse2d(errors) {
    let sum = 0;
    for (let y = 0; y < this.constants.height; y++) {
        for (let x = 0; x < this.constants.width; x++) {
            sum += errors[y][x] ** 2;
        }
    }
    return sum / this.constants.length;
}
class MeanSquaredError {
    constructor({ width, height }) {
        this.calculate = makeKernel(mse2d, {
            output: [1],
            constants: {
                width,
                height,
                length: width * height,
            },
            immutable: true,
        });
        this.addAbsolute = makeKernel(function (prevError, prevLayerErrors) {
            return prevError[0] + Math.abs(prevLayerErrors[0][0]);
        }, {
            output: [1],
            immutable: true,
        });
        this.add = makeKernel(function (value1, value2) {
            return value1[0] + value2[0];
        }, {
            output: [1],
            immutable: true,
        });
        this.divide = makeKernel(function (length, mseSum) {
            const value = mseSum[0];
            if (value > 0) {
                return value / length;
            }
            return 0;
        }, {
            output: [1],
            immutable: true,
        });
    }
}

const baseLayerDefaultSettings = {
    width: 1,
    height: 1,
    depth: null,
    weights: null,
    deltas: null,
    praxis: null,
    praxisOpts: null,
};
class BaseLayer {
    constructor(settings) {
        this.praxis = null;
        this.predictKernel = null;
        this.compareKernel = null;
        if (settings) {
            this.settings = { ...baseLayerDefaultSettings, ...settings };
        }
        else {
            this.settings = { ...baseLayerDefaultSettings };
        }
        this.setupPraxis();
    }
    get width() {
        var _a;
        return (_a = this.settings.width) !== null && _a !== void 0 ? _a : 0;
    }
    get height() {
        var _a;
        return (_a = this.settings.height) !== null && _a !== void 0 ? _a : 0;
    }
    get depth() {
        var _a;
        return (_a = this.settings.depth) !== null && _a !== void 0 ? _a : 0;
    }
    get weights() {
        return this.settings.weights;
    }
    set weights(weights) {
        this.settings.weights = weights;
    }
    get deltas() {
        return this.settings.deltas;
    }
    set deltas(deltas) {
        this.settings.deltas = deltas;
    }
    get id() {
        var _a;
        return (_a = this.settings.id) !== null && _a !== void 0 ? _a : '';
    }
    set id(title) {
        this.settings.id = title;
    }
    setupPraxis() {
        const { initPraxis, praxis, praxisOpts } = this.settings;
        if (!this.praxis) {
            if (initPraxis) {
                if (praxisOpts) {
                    this.praxis = initPraxis(this, praxisOpts);
                }
                else {
                    this.praxis = initPraxis(this);
                }
            }
            else if (praxis) {
                this.praxis = praxis;
            }
        }
    }
    /*
    get weights() {
      return this._weights;
    }
  
    set weights(value) {
      if (value) {
        if (value.dimensions) {
          if (value.dimensions[0] !== this.width) {
            throw new Error(`${this.constructor.name}.weights being set with improper value width`);
          }
          if (value.dimensions[1] !== this.height) {
            throw new Error(`${this.constructor.name}.weights being set with improper value height`);
          }
        } else {
          if (value[0].length !== this.width) {
            throw new Error(`${this.constructor.name}.weights being set with improper value width`);
          }
          if (value.length !== this.height) {
            throw new Error(`${this.constructor.name}.weights being set with improper value height`);
          }
        }
      }
      this._weights = value;
    }
  
    get deltas() {
      return this._deltas;
    }
  
    set deltas(value) {
      if (value) {
        if (value.dimensions) {
          if (value.dimensions[0] !== this.width) {
            throw new Error(`${this.constructor.name}.deltas being set with improper value width`);
          }
          if (value.dimensions[1] !== this.height) {
            throw new Error(`${this.constructor.name}.deltas being set with improper value height`);
          }
        } else {
          if (value[0].length !== this.width) {
            throw new Error(`${this.constructor.name}.deltas being set with improper value width`);
          }
          if (value.length !== this.height) {
            throw new Error(`${this.constructor.name}.deltas being set with improper value height`);
          }
        }
      }
      this._deltas = value;
    } */
    validate() {
        if (Number.isNaN(this.height)) {
            throw new Error(`${this.constructor.name} layer height is not a number`);
        }
        if (Number.isNaN(this.width)) {
            throw new Error(`${this.constructor.name} layer width is not a number`);
        }
        if (this.height < 1) {
            throw new Error(`${this.constructor.name} layer height is less than 1`);
        }
        if (this.width < 1) {
            throw new Error(`${this.constructor.name} layer width is less than 1`);
        }
    }
    setupKernels(isTraining) { }
    reuseKernels(layer) {
        if (layer.width !== this.width) {
            throw new Error(`${this.constructor.name} kernel width mismatch ${layer.width} is not ${this.width}`);
        }
        if (layer.height !== this.height) {
            throw new Error(`${this.constructor.name} kernel width mismatch ${layer.height} is not ${this.height}`);
        }
        if (layer.hasOwnProperty('predictKernel') && layer.predictKernel !== null) {
            if (!layer.predictKernel.immutable) {
                throw new Error(`${layer.constructor.name}.predictKernel is not reusable, set kernel.immutable = true`);
            }
            this.predictKernel = layer.predictKernel;
        }
        if (layer.hasOwnProperty('compareKernel') && layer.compareKernel !== null) {
            if (!layer.compareKernel.immutable) {
                throw new Error(`${layer.constructor.name}.compareKernel is not reusable, set kernel.immutable = true`);
            }
            this.compareKernel = layer.compareKernel;
        }
        this.praxis = layer.praxis;
    }
    predict(inputs) { }
    compare(targetValues) { }
    learn(learningRate) {
        // TODO: do we need to release here?
        const { weights: oldWeights } = this;
        if (!this.praxis)
            throw new Error('this.praxis not defined');
        this.weights = this.praxis.run(this, learningRate);
        release(oldWeights);
        clear(this.deltas);
    }
    toArray() {
        return Array.isArray(this.weights)
            ? this.weights
            : this.weights.toArray();
    }
    toJSON() {
        return BaseLayer.toJSON(this);
    }
    static toJSON(layer) {
        const { weights } = layer;
        return {
            width: layer.width,
            height: layer.height,
            depth: layer.depth,
            weights: toUntypedArray((weights && weights instanceof gpu_js.Texture
                ? weights.toArray()
                : weights)),
            type: layer.constructor.name,
            praxisOpts: layer.praxis ? layer.praxis.toJSON() : null,
        };
    }
}
function toUntypedArray(weights) {
    if (weights === null)
        return null;
    if (Array.isArray(weights)) {
        if (typeof weights[0] === 'number') {
            return weights;
        }
        else if (Array.isArray(weights[0]) && typeof weights[0][0] === 'number') {
            return weights;
        }
        else if (Array.isArray(weights[0][0]) &&
            typeof weights[0][0][0] === 'number') {
            return weights;
        }
        else if (weights[0] instanceof Float32Array) {
            const matrix = weights;
            return matrix.map((row) => {
                return Array.from(row);
            });
        }
        else if (weights[0][0] instanceof Float32Array) {
            const cube = weights;
            return cube.map((matrix) => {
                return matrix.map((row) => {
                    return Array.from(row);
                });
            });
        }
    }
    else if (weights) {
        return Array.from(weights);
    }
    throw new Error('unexpected value');
}

/**
 * Returns an array of zeros
 */
function zeros$1(size) {
    return new Float32Array(size);
}

/**
 * Returns a 2D tensor(matrix) of zeros
 */
function zeros2D(width, height) {
    const result = new Array(height);
    for (let y = 0; y < height; y++) {
        result[y] = zeros$1(width);
    }
    return result;
}

/**
 * Returns a 3D tensor of arrays
 */
function zeros3D(width, height, depth) {
    const result = new Array(depth);
    for (let z = 0; z < depth; z++) {
        result[z] = zeros2D(width, height);
    }
    return result;
}

class Activation extends BaseLayer {
    constructor(inputLayer, settings) {
        super(settings);
        this.inputLayer = inputLayer;
        const { width, height, depth } = this;
        this.predictKernel = null;
        this.compareKernel = null;
        this.validate();
        if (depth > 0) {
            this.weights = zeros3D(width, height, depth);
            this.deltas = zeros3D(width, height, depth);
        }
        else if (height > 0) {
            this.weights = zeros2D(width, height);
            this.deltas = zeros2D(width, height);
        }
        this.setupPraxis();
    }
    get width() {
        return this.inputLayer.width;
    }
    get height() {
        return this.inputLayer.height;
    }
    get depth() {
        return this.inputLayer.depth;
    }
}

class Filter extends BaseLayer {
    constructor(settings, inputLayer) {
        super();
        this.settings = settings;
        this.inputLayer = inputLayer;
    }
    get width() {
        return this.inputLayer.width;
    }
    get height() {
        return this.inputLayer.height;
    }
    get depth() {
        return this.inputLayer.depth;
    }
    get filterCount() {
        return this.settings.filterCount;
    }
    get filterWidth() {
        return this.settings.filterWidth;
    }
    get filterHeight() {
        return this.settings.filterHeight;
    }
    get filters() {
        return this.settings.filters;
    }
    set filters(filters) {
        this.settings.filters = filters;
    }
    get filterDeltas() {
        return this.settings.filterDeltas;
    }
    set filterDeltas(filterDeltas) {
        this.settings.filterDeltas = filterDeltas;
    }
}

class Internal {
    constructor() {
        this.predictKernel = null;
        this.compareKernel = null;
        this.praxis = null;
    }
    get width() {
        return this.settings.width;
    }
    get height() {
        return this.settings.height;
    }
    get depth() {
        return this.settings.depth;
    }
    get weights() {
        return this.settings.weights;
    }
    set weights(weights) {
        this.settings.weights = weights;
    }
    get deltas() {
        return this.settings.deltas;
    }
    set deltas(deltas) {
        this.settings.deltas = deltas;
    }
    toJSON() {
        return BaseLayer.toJSON(this);
    }
}

class Modifier extends BaseLayer {
    constructor(inputLayer, settings) {
        super({
            ...settings,
            width: inputLayer.width,
            height: inputLayer.height,
            depth: inputLayer.depth,
        });
        this.inputLayer = inputLayer;
    }
    validate() {
        var _a;
        super.validate();
        if (this.width !== this.inputLayer.width) {
            throw new Error(`width of ${this.width} does not match inputLayer.width of ${this.inputLayer.width}`);
        }
        if (this.height !== this.inputLayer.height) {
            throw new Error(`height of ${this.height} does not match inputLayer.height of ${this.inputLayer.height}`);
        }
        if (this.depth !== ((_a = this.inputLayer.depth) !== null && _a !== void 0 ? _a : 0)) {
            throw new Error(`depth of ${this.depth} does not match inputLayer.depth of ${this.inputLayer.depth}`);
        }
    }
}

class Operator extends BaseLayer {
    constructor(inputLayer1, inputLayer2, settings) {
        super(settings);
        this.inputLayer1 = inputLayer1;
        this.inputLayer2 = inputLayer2;
        this.validate();
        this.weights = zeros2D(this.width, this.height);
        this.deltas = zeros2D(this.width, this.height);
        this.setupPraxis();
    }
}

function compare1D(weights, targetValues) {
    return weights[this.thread.y][this.thread.x] - targetValues[this.thread.x];
}
function compare2D$5(weights, targetValues) {
    return (weights[this.thread.y][this.thread.x] -
        targetValues[this.thread.y][this.thread.x]);
}
class Target extends BaseLayer {
    constructor(settings, inputLayer) {
        super(settings);
        this.inputLayer = inputLayer;
        this.validate();
        if (this.depth) {
            throw new Error('Target layer not implemented for depth');
        }
        else if (this.height) {
            this.weights = zeros2D(this.width, this.height);
            this.deltas = zeros2D(this.width, this.height);
            this.errors = zeros2D(this.width, this.height);
        }
        else {
            this.weights = zeros$1(this.width);
            this.deltas = zeros$1(this.width);
            this.errors = zeros$1(this.width);
        }
    }
    setupKernels() {
        if (this.width === 1) {
            this.compareKernel = makeKernel(compare1D, {
                output: [this.width, this.height],
                immutable: true,
            });
        }
        else {
            this.compareKernel = makeKernel(compare2D$5, {
                output: [this.width, this.height],
                immutable: true,
            });
        }
    }
    predict() {
        // TODO: should we clone here?
        // NOTE: this looks like it shouldn't be, but the weights are immutable, and this is where they are reused.
        release(this.weights);
        this.weights = clone(this.inputLayer.weights);
        clear(this.deltas);
    }
    compare(targetValues) {
        // this is where weights attach to deltas
        // deltas will be zero on learn, so save it in error for comparing to mse later
        release(this.deltas);
        release(this.errors);
        release(this.inputLayer.deltas);
        this.deltas = this.compareKernel(this.weights, targetValues);
        this.inputLayer.deltas = clone(this.deltas);
        this.errors = clone(this.deltas);
    }
    setupPraxis() { }
}
function target(settings, inputLayer) {
    return new Target(settings, inputLayer);
}

// eslint-disable-next-line @typescript-eslint/no-extraneous-class
class InternalModel {
}
// eslint-disable-next-line @typescript-eslint/no-extraneous-class
class EntryPoint extends BaseLayer {
}
// eslint-disable-next-line @typescript-eslint/no-extraneous-class
class Model extends BaseLayer {
}

/* Functions for turning sparse hashes into arrays and vice versa */
const lookup = {
    /**
     * Performs `[{a: 1}, {b: 6, c: 7}] -> {a: 0, b: 1, c: 2}`
     * @param {Object} hashes
     * @returns {Object}
     */
    toTable(hashes) {
        const hash = hashes.reduce((memo, hash) => {
            return Object.assign(memo, hash);
        }, {});
        return lookup.toHash(hash);
    },
    /**
     * Performs `[{a: 1}, {b: 6, c: 7}] -> {a: 0, b: 1, c: 2}`
     */
    toTable2D(objects2D) {
        const table = {};
        let valueIndex = 0;
        for (let i = 0; i < objects2D.length; i++) {
            const objects = objects2D[i];
            for (let j = 0; j < objects.length; j++) {
                const object = objects[j];
                for (const p in object) {
                    if (object.hasOwnProperty(p) && !table.hasOwnProperty(p)) {
                        table[p] = valueIndex++;
                    }
                }
            }
        }
        return table;
    },
    toInputTable2D(data) {
        const table = {};
        let tableIndex = 0;
        for (let dataIndex = 0; dataIndex < data.length; dataIndex++) {
            const input = data[dataIndex].input;
            for (let i = 0; i < input.length; i++) {
                const object = input[i];
                for (const p in object) {
                    if (!object.hasOwnProperty(p))
                        continue;
                    if (!table.hasOwnProperty(p)) {
                        table[p] = tableIndex++;
                    }
                }
            }
        }
        return table;
    },
    toOutputTable2D(data) {
        const table = {};
        let tableIndex = 0;
        for (let dataIndex = 0; dataIndex < data.length; dataIndex++) {
            const output = data[dataIndex].output;
            for (let i = 0; i < output.length; i++) {
                const object = output[i];
                for (const p in object) {
                    if (!object.hasOwnProperty(p))
                        continue;
                    if (!table.hasOwnProperty(p)) {
                        table[p] = tableIndex++;
                    }
                }
            }
        }
        return table;
    },
    /**
     * performs `{a: 6, b: 7} -> {a: 0, b: 1}`
     */
    toHash(hash) {
        const lookup = {};
        let index = 0;
        const keys = Object.keys(hash);
        for (let i = 0; i < keys.length; i++) {
            lookup[keys[i]] = index++;
        }
        return lookup;
    },
    /**
     * performs `{a: 0, b: 1}, {a: 6} -> [6, 0]`
     */
    toArray(lookup, object, arrayLength) {
        const result = new Float32Array(arrayLength);
        for (const p in lookup) {
            if (!lookup.hasOwnProperty(p))
                continue;
            result[lookup[p]] = object.hasOwnProperty(p) ? object[p] : 0;
        }
        return result;
    },
    toArrayShort(lookup, object) {
        const result = [];
        for (const p in lookup) {
            if (!lookup.hasOwnProperty(p))
                continue;
            if (!object.hasOwnProperty(p))
                break;
            result[lookup[p]] = object[p];
        }
        return Float32Array.from(result);
    },
    toArrays(lookup, objects, arrayLength) {
        const result = [];
        for (let i = 0; i < objects.length; i++) {
            result.push(this.toArray(lookup, objects[i], arrayLength));
        }
        return result;
    },
    /**
     * performs `{a: 0, b: 1}, [6, 7] -> {a: 6, b: 7}`
     * @param {Object} lookup
     * @param {Array} array
     * @returns {Object}
     */
    toObject(lookup, array) {
        const object = {};
        for (const p in lookup) {
            if (!lookup.hasOwnProperty(p))
                continue;
            object[p] = array[lookup[p]];
        }
        return object;
    },
    toObjectPartial(lookup, array, offset = 0, limit = 0) {
        const object = {};
        let i = 0;
        for (const p in lookup) {
            if (!lookup.hasOwnProperty(p))
                continue;
            if (offset > 0) {
                if (i++ < offset)
                    continue;
            }
            if (limit > 0) {
                if (i++ >= limit)
                    continue;
            }
            object[p] = array[lookup[p] - offset];
        }
        return object;
    },
    dataShape(data) {
        const shape = [];
        let lastData;
        if (data.hasOwnProperty('input')) {
            shape.push('datum');
            lastData = data.input;
        }
        else if (Array.isArray(data)) {
            if (data[0] &&
                data[0].input) {
                shape.push('array', 'datum');
                lastData = data[0].input;
            }
            else if (Array.isArray(data[0])) {
                shape.push('array');
                lastData = data[0];
            }
            else {
                lastData = data;
            }
        }
        else {
            lastData = data;
        }
        let p;
        while (lastData) {
            p = Object.keys(lastData)[0];
            if (Array.isArray(lastData) ||
                typeof lastData.buffer === 'object') {
                shape.push('array');
                const possibleNumber = lastData[parseInt(p)];
                if (typeof possibleNumber === 'number') {
                    shape.push('number');
                    break;
                }
                else {
                    lastData = possibleNumber;
                }
            }
            else if (typeof lastData === 'object' &&
                typeof lastData.buffer !== 'object') {
                shape.push('object');
                const possibleNumber = lastData[p];
                if (typeof possibleNumber === 'number') {
                    shape.push('number');
                    break;
                }
                else {
                    lastData = possibleNumber;
                }
            }
            else {
                throw new Error('unhandled signature');
            }
        }
        return shape;
    },
    addKeys(value, table) {
        if (Array.isArray(value))
            return table;
        let i = Object.keys(table).length;
        for (const p in value) {
            if (!value.hasOwnProperty(p))
                continue;
            if (table.hasOwnProperty(p))
                continue;
            table[p] = i++;
        }
        return table;
    },
};

class BasePraxis {
    constructor(layerTemplate, settings = {}) {
        this.layerTemplate = layerTemplate;
        this.settings = { ...settings };
        this.kernel = null;
    }
    get width() {
        return this.layerTemplate.width;
    }
    get height() {
        return this.layerTemplate.height;
    }
    get depth() {
        return this.layerTemplate.depth;
    }
    setupKernels() { }
    reuseKernels(praxis) {
        if (praxis.width !== this.width) {
            throw new Error(`${this.constructor.name} kernel width mismatch ${praxis.width} is not ${this.width}`);
        }
        if (praxis.height !== this.height) {
            throw new Error(`${this.constructor.name} kernel width mismatch ${praxis.height} is not ${this.height}`);
        }
        if (praxis.hasOwnProperty('kernel')) {
            this.kernel = praxis.kernel;
        }
    }
    toJSON() {
        return { ...this.settings };
    }
}

function update$2(weights, deltas) {
    return (weights[this.thread.y][this.thread.x] +
        this.constants.learningRate * deltas[this.thread.y][this.thread.x]);
}
const defaultSettings$1 = {
    learningRate: 0.3,
};
class ArthurDeviationBiases extends BasePraxis {
    constructor(layer, settings) {
        super(layer);
        this.settings = { ...defaultSettings$1, ...settings };
        this.kernel = null;
    }
    run(layer) {
        return this.kernel(layer.weights, layer.deltas);
    }
    setupKernels() {
        this.kernel = makeKernel(update$2, {
            output: [this.width, this.height],
            constants: {
                learningRate: this.settings.learningRate,
            },
        });
    }
}
function arthurDeviationBiases(layer, settings) {
    return new ArthurDeviationBiases(layer, settings);
}

function updateChange(value) {
    return value;
}
function update$1(changes, weights, incomingWeights, inputDeltas) {
    const lastChange = changes[this.thread.y][this.thread.x];
    const inputDelta = inputDeltas[this.thread.y][0];
    const weight = weights[this.thread.y][this.thread.x];
    const incoming = incomingWeights[this.thread.x][0];
    const change = this.constants.learningRate * inputDelta * incoming +
        this.constants.momentum * lastChange;
    return weight + change;
}
const defaultSettings = {
    learningRate: 0.3,
    momentum: 0.1,
    weightsLayer: null,
    incomingLayer: null,
    deltaLayer: null,
};
class ArthurDeviationWeights extends BasePraxis {
    constructor(layer, settings) {
        super(layer);
        this.kernelMap = null;
        this.settings = { ...defaultSettings, ...settings };
        this.changes = zeros2D(layer.width, layer.height);
    }
    get learningRate() {
        return this.settings.learningRate;
    }
    get momentum() {
        return this.settings.momentum;
    }
    get weightsLayer() {
        return this.settings.weightsLayer;
    }
    set weightsLayer(layer) {
        this.settings.weightsLayer = layer;
    }
    get deltaLayer() {
        return this.settings.deltaLayer;
    }
    set deltaLayer(layer) {
        this.settings.deltaLayer = layer;
    }
    get incomingLayer() {
        return this.settings.incomingLayer;
    }
    set incomingLayer(layer) {
        this.settings.incomingLayer = layer;
    }
    run() {
        const output = this.kernelMap(this.changes, this.weightsLayer.weights, this.incomingLayer.weights, this.deltaLayer.deltas);
        this.changes = output.changes;
        return output.result;
    }
    setupKernels() {
        this.kernelMap = makeKernelMap({
            changes: updateChange,
        }, update$1, {
            output: [this.width, this.height],
            constants: {
                learningRate: this.learningRate,
                momentum: this.momentum,
            },
        });
    }
}
function arthurDeviationWeights(layer, settings) {
    return new ArthurDeviationWeights(layer, settings);
}

function getMomentum(delta, decay, previousMomentum) {
    return previousMomentum * decay + (1 - decay) * delta * delta;
}
function clipByValue(value, max, min) {
    if (value > max) {
        return max;
    }
    if (value < min) {
        return min;
    }
    return value;
}
/**
 * @description Momentum Root Mean Square Propagation Function
 */
function update(weights, deltas, previousMomenta) {
    const delta = deltas[this.thread.y][this.thread.x];
    const clippedDelta = clipByValue(delta, this.constants.clipValue, -this.constants.clipValue);
    const weight = weights[this.thread.y][this.thread.x];
    const previousMomentum = previousMomenta[this.thread.y][this.thread.x];
    const momentum = getMomentum(delta, this.constants.decayRate, previousMomentum);
    return (weight +
        (-this.constants.learningRate * clippedDelta) /
            Math.sqrt(momentum + this.constants.smoothEps) -
        this.constants.regularizationStrength * weight);
}
const defaults$8 = {
    decayRate: 0.999,
    regularizationStrength: 0.0001,
    learningRate: 0.01,
    smoothEps: 1e-8,
    clipValue: 5,
};
class MomentumRootMeanSquaredPropagation extends BasePraxis {
    constructor(layerTemplate, settings = {}) {
        super(layerTemplate);
        this.kernelMap = null;
        this.settings = { ...defaults$8, ...settings };
        this.momenta = zeros2D(layerTemplate.width, layerTemplate.height);
    }
    get clipValue() {
        return this.settings.clipValue;
    }
    get decayRate() {
        return this.settings.decayRate;
    }
    get learningRate() {
        return this.settings.learningRate;
    }
    get regularizationStrength() {
        return this.settings.regularizationStrength;
    }
    get smoothEps() {
        return this.settings.smoothEps;
    }
    run(layer) {
        const { momenta, result } = this.kernelMap(layer.weights, layer.deltas, this.momenta);
        release(this.momenta);
        this.momenta = momenta;
        return result;
    }
    setupKernels() {
        this.kernelMap = makeKernelMap({
            momenta: getMomentum,
        }, update, {
            output: [this.width, this.height],
            constants: {
                clipValue: this.clipValue,
                decayRate: this.decayRate,
                learningRate: this.learningRate,
                regularizationStrength: this.regularizationStrength,
                smoothEps: this.smoothEps,
            },
            functions: [clipByValue],
            immutable: true,
        });
    }
}
function momentumRootMeanSquaredPropagation(layer, settings) {
    return new MomentumRootMeanSquaredPropagation(layer, settings);
}
/**
 * @description Mathematician friendly name of MomentumRootMeanSquaredPropagation class. For those that are not mere mortals
 */
const MRmsProp = MomentumRootMeanSquaredPropagation;
const mRmsProp = momentumRootMeanSquaredPropagation;

var index = /*#__PURE__*/Object.freeze({
    __proto__: null,
    ArthurDeviationBiases: ArthurDeviationBiases,
    arthurDeviationBiases: arthurDeviationBiases,
    ArthurDeviationWeights: ArthurDeviationWeights,
    arthurDeviationWeights: arthurDeviationWeights,
    MomentumRootMeanSquaredPropagation: MomentumRootMeanSquaredPropagation,
    momentumRootMeanSquaredPropagation: momentumRootMeanSquaredPropagation,
    MRmsProp: MRmsProp,
    mRmsProp: mRmsProp
});

function traverseLayersFrom(layer, cb) {
    if (layer.hasOwnProperty('inputLayer')) {
        traverseLayersFrom(layer.inputLayer, cb);
    }
    else {
        if (layer.hasOwnProperty('inputLayer1')) {
            traverseLayersFrom(layer.inputLayer1, cb);
        }
        if (layer.hasOwnProperty('inputLayer2')) {
            traverseLayersFrom(layer.inputLayer2, cb);
        }
    }
    cb(layer);
}

function flattenLayers(layers) {
    const result = layers.slice(0);
    for (let i = 0; i < result.length; i++) {
        let offset = 0;
        traverseLayersFrom(result[i], (layer) => {
            if (!result.includes(layer)) {
                result.splice(i + offset, 0, layer);
                offset++;
            }
        });
    }
    return result;
}

function checkSameSize(layer1, layer2) {
    if (layer1.width !== layer2.width) {
        throw new Error(`Layer width mismatch of ${layer1.width} and ${layer2.width}`);
    }
    if (layer1.height !== layer2.height) {
        throw new Error(`Layer height mismatch of ${layer1.height} and ${layer2.height}`);
    }
}

function predict$8(inputWeights1, inputWeights2) {
    return (inputWeights1[this.thread.y][this.thread.x] +
        inputWeights2[this.thread.y][this.thread.x]);
}
class Add extends Operator {
    get width() {
        return this.inputLayer1.width;
    }
    get height() {
        return this.inputLayer1.height;
    }
    get depth() {
        return this.inputLayer1.depth;
    }
    validate() {
        super.validate();
        checkSameSize(this.inputLayer1, this.inputLayer2);
    }
    setupKernels() {
        this.predictKernel = makeKernel(predict$8, {
            output: [this.width, this.height],
            immutable: true,
        });
    }
    predict() {
        release(this.weights);
        this.weights = this.predictKernel(this.inputLayer1.weights, this.inputLayer2.weights);
        clear(this.deltas);
    }
    compare() {
        // TODO: Do we need release and clone here?
        release(this.inputLayer1.deltas);
        release(this.inputLayer2.deltas);
        this.inputLayer1.deltas = clone(this.deltas);
        this.inputLayer2.deltas = clone(this.deltas);
    }
    learn() { }
}
function add$1(inputLayer1, inputLayer2, settings) {
    return new Add(inputLayer1, inputLayer2, settings);
}

function randomWeight() {
    return Math.random() * 0.4 - 0.2;
}

/**
 * Returns a random float between given min and max bounds (inclusive)
 * @param min Minimum value of the ranfom float
 * @param max Maximum value of the random float
 */
function randomFloat(min, max) {
    return Math.random() * (max - min) + min;
}
/**
 * Complicated math. All you need to know is that it returns a random number.
 * More info: https://en.wikipedia.org/wiki/Normal_distribution
 */
function gaussRandom() {
    if (gaussRandom.returnV) {
        gaussRandom.returnV = false;
        return gaussRandom.vVal;
    }
    const u = 2 * Math.random() - 1;
    const v = 2 * Math.random() - 1;
    const r = u * u + v * v;
    if (r === 0 || r > 1) {
        return gaussRandom();
    }
    const c = Math.sqrt((-2 * Math.log(r)) / r);
    gaussRandom.vVal = v * c; // cache this
    gaussRandom.returnV = true;
    return u * c;
}
/**
 * Returns a random integer between given min and max bounds
 * @param min Minimum value of the random integer
 * @param max Maximum value of the random integer
 */
function randomInteger(min, max) {
    return Math.floor(Math.random() * (max - min) + min);
}
/**
 * If you know what this is: https://en.wikipedia.org/wiki/Normal_distribution
 * @param mu
 * @param std
 */
function randomN(mu, std) {
    return mu + gaussRandom() * std;
}
gaussRandom.returnV = false;
gaussRandom.vVal = 0;

var random$1 = /*#__PURE__*/Object.freeze({
    __proto__: null,
    randomFloat: randomFloat,
    gaussRandom: gaussRandom,
    randomInteger: randomInteger,
    randomN: randomN
});

/**
 * Returns an array of given size, full of randomness
 */
function randos(size, std = null) {
    const array = new Float32Array(size);
    if (std === null) {
        for (let i = 0; i < size; i++) {
            array[i] = randomWeight();
        }
    }
    else {
        for (let i = 0; i < size; i++) {
            array[i] = randomFloat(-std, std);
        }
    }
    return array;
}
/**
 * Returns a 2D matrix of given size, full of randomness
 */
function randos2D(width, height, std) {
    const result = new Array(height);
    for (let y = 0; y < height; y++) {
        result[y] = randos(width, std);
    }
    return result;
}
/**
 * Returns a 3D tensor of given size, full of randomness
 */
function randos3D(width, height, depth, std) {
    const result = new Array(depth);
    for (let z = 0; z < depth; z++) {
        result[z] = randos2D(width, height, std);
    }
    return result;
}

const defaults$7 = {
    ...baseLayerDefaultSettings,
    std: null,
};
class Random extends Model {
    constructor(settings) {
        super();
        this.settings = { ...defaults$7, ...settings };
        this.setupPraxis();
        this.validate();
        if (!this.weights) {
            this.weights = randos2D(this.width, this.height, settings.std);
        }
        if (!this.deltas) {
            this.deltas = zeros2D(this.width, this.height);
        }
    }
    predict() { }
    compare() { }
}
function random(settings) {
    return new Random(settings);
}

function predict$7(weights1, weights2) {
    let sum = 0;
    for (let i = 0; i < this.constants.size; i++) {
        sum += weights1[this.thread.y][i] * weights2[i][this.thread.x];
    }
    return sum;
}
function compareFromX(deltas, inputDeltas, inputWeights) {
    let sum = inputDeltas[this.thread.y][this.thread.x];
    for (let i = 0; i < this.constants.size; i++) {
        sum += deltas[this.thread.y][i] * inputWeights[this.thread.x][i];
    }
    return sum;
}
function compareFromY(deltas, inputDeltas, inputWeights) {
    let sum = inputDeltas[this.thread.y][this.thread.x];
    for (let i = 0; i < this.constants.size; i++) {
        sum += deltas[i][this.thread.x] * inputWeights[i][this.thread.y];
    }
    return sum;
}
class Multiply extends Operator {
    constructor() {
        super(...arguments);
        this.compareKernel1 = null;
        this.compareKernel2 = null;
    }
    get width() {
        return this.inputLayer2.width;
    }
    set width(width) {
        throw new Error('Cannot set width on Multiply');
    }
    get height() {
        return this.inputLayer1.height;
    }
    set height(height) {
        throw new Error('Cannot set height on Multiply');
    }
    get depth() {
        return this.inputLayer1.depth;
    }
    set depth(depth) {
        throw new Error('Cannot set depth on Multiply');
    }
    validate() {
        super.validate();
        if (this.inputLayer1.width !== this.inputLayer2.height) {
            throw new Error(`Layer width mismatch of ${this.inputLayer1.width} and ${this.inputLayer2.height}`);
        }
    }
    setupKernels() {
        this.predictKernel = makeKernel(predict$7, {
            output: [this.width, this.height],
            constants: {
                size: this.inputLayer2.height,
            },
            immutable: true,
        });
        this.compareKernel1 = makeKernel(compareFromX, {
            output: [this.inputLayer1.width, this.inputLayer1.height],
            constants: {
                size: this.inputLayer2.width,
            },
            immutable: true,
        });
        this.compareKernel2 = makeKernel(compareFromY, {
            output: [this.inputLayer2.width, this.inputLayer2.height],
            constants: {
                size: this.inputLayer1.height,
            },
            immutable: true,
        });
    }
    reuseKernels(layer) {
        super.reuseKernels(layer);
        this.compareKernel1 = layer.compareKernel1;
        this.compareKernel2 = layer.compareKernel2;
    }
    predict() {
        release(this.weights);
        if (!this.predictKernel)
            throw new Error('this.predictKernel is not set');
        this.weights = this.predictKernel(this.inputLayer1.weights, this.inputLayer2.weights);
        clear(this.deltas);
    }
    compare() {
        if (!this.compareKernel1)
            throw new Error('this.compareKernel1 not set');
        if (!this.compareKernel2)
            throw new Error('this.compareKernel2 not set');
        const inputLayer1Deltas = this.inputLayer1.deltas;
        const inputLayer2Deltas = this.inputLayer2.deltas;
        const newDeltas1 = this.compareKernel1(this.deltas, this.inputLayer1.deltas, this.inputLayer2.weights);
        const newDeltas2 = this.compareKernel2(this.deltas, this.inputLayer2.deltas, this.inputLayer1.weights);
        this.inputLayer2.deltas = newDeltas2;
        this.inputLayer1.deltas = newDeltas1;
        release(inputLayer1Deltas);
        release(inputLayer2Deltas);
    }
    setupPraxis() { }
    learn() { }
    toJSON() {
        return {
            ...super.toJSON(),
            width: this.width,
            height: this.height,
        };
    }
}
function multiply$1(inputLayer1, inputLayer2, settings) {
    return new Multiply(inputLayer1, inputLayer2, settings);
}

function predict2D$4(inputs) {
    return 1 / (1 + Math.exp(-inputs[this.thread.y][this.thread.x]));
}
function predict3D$5(inputs) {
    return (1 / (1 + Math.exp(-inputs[this.thread.z][this.thread.y][this.thread.x])));
}
function compare2D$4(weights, deltas) {
    const weight = weights[this.thread.y][this.thread.x];
    const delta = deltas[this.thread.y][this.thread.x];
    return weight * (1 - weight) * delta;
}
function compare3D$4(weights, deltas) {
    const weight = weights[this.thread.z][this.thread.y][this.thread.x];
    const delta = deltas[this.thread.z][this.thread.y][this.thread.x];
    return weight * (1 - weight) * delta;
}
class Sigmoid extends Activation {
    setupKernels() {
        if (this.depth > 0) {
            this.predictKernel = makeKernel(predict3D$5, {
                output: [this.width, this.height, this.depth],
                functions: [activate$2],
                immutable: true,
            });
            this.compareKernel = makeKernel(compare3D$4, {
                output: [this.width, this.height, this.depth],
                functions: [measure$2],
                immutable: true,
            });
        }
        else {
            this.predictKernel = makeKernel(predict2D$4, {
                output: [this.width, this.height],
                functions: [activate$2],
                immutable: true,
            });
            this.compareKernel = makeKernel(compare2D$4, {
                output: [this.width, this.height],
                functions: [measure$2],
                immutable: true,
            });
        }
    }
    predict() {
        release(this.weights);
        this.weights = this.predictKernel(this.inputLayer.weights);
        clear(this.deltas);
    }
    compare() {
        release(this.inputLayer.deltas);
        this.inputLayer.deltas = this.compareKernel(this.weights, this.deltas);
    }
}
function sigmoid$1(inputLayer, settings) {
    return new Sigmoid(inputLayer, settings);
}

function arthurFeedForward(settings, inputLayer) {
    const { height } = settings;
    function initWeightsPraxis(layerTemplate, settings) {
        const praxis = arthurDeviationWeights(layerTemplate, settings);
        praxis.setupKernels();
        return praxis;
    }
    function initBiasesPraxis(layerTemplate, settings) {
        const praxis = arthurDeviationBiases(layerTemplate, settings);
        praxis.setupKernels();
        return praxis;
    }
    const weightsLayer = random({
        id: 'weights',
        height,
        width: inputLayer.height,
        initPraxis: initWeightsPraxis,
    });
    const biasesLayer = random({
        id: 'biases',
        height,
        initPraxis: initBiasesPraxis,
    });
    const multiplyLayer = multiply$1(weightsLayer, inputLayer);
    const addLayer = add$1(multiplyLayer, biasesLayer);
    const sigmoidLayer = sigmoid$1(addLayer);
    const weightsPraxis = weightsLayer.praxis;
    weightsPraxis.weightsLayer = weightsLayer;
    weightsPraxis.incomingLayer = inputLayer;
    weightsPraxis.deltaLayer = sigmoidLayer;
    return sigmoidLayer;
}

function getStride(settings, defaults) {
    if (typeof settings.stride === 'number') {
        return { strideX: settings.stride, strideY: settings.stride };
    }
    else {
        let strideX = defaults.stride;
        let strideY = defaults.stride;
        if (typeof settings.strideX === 'number') {
            strideX = settings.strideX;
        }
        if (typeof settings.strideY === 'number') {
            strideY = settings.strideY;
        }
        return { strideX, strideY };
    }
}
function getPadding(settings, defaults) {
    if (typeof settings.padding === 'number') {
        return { paddingX: settings.padding, paddingY: settings.padding };
    }
    else {
        let paddingX = defaults.padding;
        let paddingY = defaults.padding;
        if (typeof settings.paddingX === 'number') {
            paddingX = settings.paddingX;
        }
        if (typeof settings.paddingY === 'number') {
            paddingY = settings.paddingY;
        }
        return { paddingX, paddingY };
    }
}

/**
 * Returns an array of a given size with each element filled with a single value
 */
function values(size, value) {
    return new Float32Array(size).fill(value);
}

function predict$6(inputs, filters, biases) {
    const startFilterX = this.constants.paddingX - this.thread.x * this.constants.strideX;
    const startInputX = this.thread.x * this.constants.strideX - this.constants.paddingX;
    const endFilterX = Math.min(this.constants.filterWidth, startFilterX + this.constants.inputWidth);
    const startFilterY = this.constants.paddingY - this.thread.y * this.constants.strideY;
    const startInputY = this.thread.y * this.constants.strideY - this.constants.paddingY;
    const endFilterY = Math.min(this.constants.filterHeight, startFilterY + this.constants.inputHeight);
    let sum = 0;
    for (let z = 0; z < this.constants.inputDepth; z++) {
        for (let filterY = Math.max(0, startFilterY), inputY = Math.max(0, startInputY); filterY < endFilterY; filterY++, inputY++) {
            for (let filterX = Math.max(0, startFilterX), inputX = Math.max(0, startInputX); filterX < endFilterX; filterX++, inputX++) {
                sum += filters[z][filterY][filterX] * inputs[z][inputY][inputX];
            }
        }
    }
    return sum + biases[this.thread.z];
}
function compareFilterDeltas$1(filterDeltas, inputs, deltas) {
    const startDeltaX = Math.max(0, Math.ceil((this.constants.paddingX - this.thread.x) / this.constants.strideX));
    const startInputX = startDeltaX * this.constants.strideX +
        this.thread.x -
        this.constants.paddingX;
    const endDeltaX = Math.min(this.constants.deltaWidth, Math.floor((this.constants.inputWidth -
        1 -
        this.thread.x +
        this.constants.paddingX) /
        this.constants.strideX) + 1);
    const startDeltaY = Math.max(0, Math.ceil((this.constants.paddingY - this.thread.y) / this.constants.strideY));
    const startInputY = startDeltaY * this.constants.strideY +
        this.thread.y -
        this.constants.paddingY;
    const endDeltaY = Math.min(this.constants.deltaHeight, Math.floor((this.constants.inputHeight -
        1 -
        this.thread.y +
        this.constants.paddingY) /
        this.constants.strideY) + 1);
    let sum = filterDeltas[this.thread.z][this.thread.y][this.thread.x];
    for (let deltaY = startDeltaY, inputY = startInputY; deltaY < endDeltaY; deltaY++, inputY += this.constants.strideY) {
        for (let deltaX = startDeltaX, inputX = startInputX; deltaX < endDeltaX; deltaX++, inputX += this.constants.strideX) {
            sum +=
                inputs[this.thread.z][inputY][inputX] *
                    deltas[this.constants.deltaZ][deltaY][deltaX];
        }
    }
    return sum;
}
function compareInputDeltas$1(inputDeltas, filters, deltas) {
    const x = this.thread.x + this.constants.paddingX;
    const startDeltaX = x < this.constants.filterWidth
        ? 0
        : Math.floor((x - this.constants.filterWidth + this.constants.strideX) /
            this.constants.strideX);
    const startFilterX = x - startDeltaX * this.constants.strideX;
    const endDeltaX = Math.min(startDeltaX + Math.floor(startFilterX / this.constants.strideX) + 1, this.constants.deltaWidth);
    const y = this.thread.y + this.constants.paddingY;
    const startDeltaY = y < this.constants.filterHeight
        ? 0
        : Math.floor((y - this.constants.filterHeight + this.constants.strideY) /
            this.constants.strideY);
    const startFilterY = y - startDeltaY * this.constants.strideY;
    const endDeltaY = Math.min(startDeltaY + Math.floor(startFilterY / this.constants.strideY) + 1, this.constants.deltaHeight);
    let sum = inputDeltas[this.thread.z][this.thread.y][this.thread.x];
    let deltaY = startDeltaY;
    for (let filterY = startFilterY; deltaY < endDeltaY; filterY -= this.constants.strideY, deltaY++) {
        let deltaX = startDeltaX;
        for (let filterX = startFilterX; deltaX < endDeltaX; filterX -= this.constants.strideX, deltaX++) {
            sum +=
                filters[this.thread.z][filterY][filterX] *
                    deltas[this.constants.deltaZ][deltaY][deltaX];
        }
    }
    return sum;
}
function compareBiases$1(biasDeltas, deltas) {
    let sum = 0;
    for (let y = 0; y < this.constants.deltaHeight; y++) {
        for (let x = 0; x < this.constants.deltaWidth; x++) {
            sum += deltas[this.thread.z][y][x];
        }
    }
    return biasDeltas[this.thread.z][this.thread.y][this.thread.x] + sum;
}
const defaults$6 = {
    stride: 0,
    padding: 0,
    bias: 0.1,
    filterCount: 1,
    filterWidth: 0,
    filterHeight: 0,
};
class Convolution extends Filter {
    constructor(settings, inputLayer) {
        var _a, _b, _c;
        super(settings, inputLayer);
        this.compareFilterDeltasKernel = null;
        this.compareInputDeltasKernel = null;
        this.compareBiasesKernel = null;
        this.settings = {
            ...defaults$6,
            ...settings,
            ...getPadding(settings, defaults$6),
            ...getStride(settings, defaults$6),
        };
        this.weights = (_a = settings.weights) !== null && _a !== void 0 ? _a : randos3D(this.width, this.height, this.depth);
        this.deltas = zeros3D(this.width, this.height, this.depth);
        this.biases = values(this.depth, this.bias);
        this.biasDeltas = (_b = settings.biasDeltas) !== null && _b !== void 0 ? _b : randos(this.depth);
        this.filters = (_c = settings.filters) !== null && _c !== void 0 ? _c : randos3D(this.filterWidth, this.filterHeight, this.filterCount);
        this.filterDeltas = zeros3D(this.filterWidth, this.filterHeight, this.filterCount);
        this.validate();
    }
    get strideX() {
        return this.settings.strideX;
    }
    get strideY() {
        return this.settings.strideY;
    }
    get paddingX() {
        return this.settings.paddingX;
    }
    get paddingY() {
        return this.settings.paddingX;
    }
    get width() {
        return Math.floor((this.inputLayer.width + this.paddingX * 2 - this.filterWidth) /
            this.strideX +
            1);
    }
    get height() {
        return Math.floor((this.inputLayer.height + this.paddingY * 2 - this.filterHeight) /
            this.strideY +
            1);
    }
    get bias() {
        return this.settings.bias;
    }
    get depth() {
        return this.filterCount;
    }
    get biases() {
        return this.settings.biases;
    }
    set biases(biases) {
        this.settings.biases = biases;
    }
    get biasDeltas() {
        return this.settings.biasDeltas;
    }
    set biasDeltas(weights) {
        this.settings.biasDeltas = weights;
    }
    get filters() {
        return this.settings.filters;
    }
    set filters(filters) {
        this.settings.filters = filters;
    }
    get filterDeltas() {
        return this.settings.filterDeltas;
    }
    set filterDeltas(filterDeltas) {
        this.settings.filterDeltas = filterDeltas;
    }
    setupKernels() {
        this.predictKernel = makeKernel(predict$6, {
            constants: {
                inputWidth: this.inputLayer.width,
                inputHeight: this.inputLayer.height,
                inputDepth: this.inputLayer.depth,
                strideX: this.strideX,
                strideY: this.strideY,
                paddingX: this.paddingX,
                paddingY: this.paddingY,
                filterWidth: this.filterWidth,
                filterHeight: this.filterHeight,
            },
            output: [this.width, this.height, this.depth],
            immutable: true,
        });
        this.compareFilterDeltasKernel = makeKernel(compareFilterDeltas$1, {
            constants: {
                deltasWidth: this.width,
                deltasHeight: this.height,
                deltasDepth: this.depth,
                inputWidth: this.inputLayer.width,
                inputHeight: this.inputLayer.height,
                inputDepth: this.inputLayer.depth,
                strideX: this.strideX,
                strideY: this.strideY,
                paddingX: this.paddingX,
                paddingY: this.paddingY,
                filterWidth: this.filterWidth,
                filterHeight: this.filterHeight,
            },
            output: [this.width, this.height, this.depth],
            immutable: true,
        });
        this.compareInputDeltasKernel = makeKernel(compareInputDeltas$1, {
            constants: {
                filterCount: this.filterCount,
            },
            output: [
                this.inputLayer.width,
                this.inputLayer.height,
                this.inputLayer.depth,
            ],
            immutable: true,
        });
        this.compareBiasesKernel = makeKernel(compareBiases$1, {
            output: [1, 1, this.depth],
            constants: {
                deltaWidth: this.width,
                deltaHeight: this.height,
            },
            immutable: true,
        });
    }
    predict() {
        this.weights = this.predictKernel(this.inputLayer.weights, this.filters, this.biases);
    }
    compare() {
        const { filterDeltas, biasDeltas } = this;
        this.filterDeltas = this.compareFilterDeltasKernel(filterDeltas, this.inputLayer.weights, this.deltas);
        release(filterDeltas);
        this.biasDeltas = this.compareBiasesKernel(biasDeltas, this.deltas);
        release(biasDeltas);
        release(this.deltas);
        this.deltas = this.compareInputDeltasKernel(this.filters, this.inputLayer.deltas);
        release(this.inputLayer.deltas);
        // TODO: do we need to clone here?
        this.inputLayer.deltas = clone(this.deltas);
    }
    learn(learningRate) {
        // TODO: handle filters
        // TODO: do we need to release here?
        const { weights: oldWeights } = this;
        this.weights = this.praxis.run(this, learningRate);
        release(oldWeights);
        clear(this.deltas);
    }
}
function convolution(settings, inputLayer) {
    return new Convolution(settings, inputLayer);
}

function setDropout(dropout) {
    return dropout;
}
function trainingPredict(inputs) {
    if (setDropout(Math.random()) < this.constants.probability) {
        return 0;
    }
    return inputs[this.thread.y][this.thread.x];
}
function predict$5(inputs) {
    return inputs[this.thread.y][this.thread.x] * this.constants.probability;
}
function compare$3(dropouts, deltas) {
    if (dropouts[this.thread.y][this.thread.x] === 0) {
        return 0;
    }
    return deltas[this.thread.y][this.thread.x];
}
const dropoutDefaults = {
    ...baseLayerDefaultSettings,
    probability: 0.5,
};
class Dropout extends Filter {
    constructor(inputLayer, settings) {
        super(settings, inputLayer);
        this.predictKernelMap = null;
        this.settings = { ...dropoutDefaults, ...settings };
        this.dropouts = null;
        this.validate();
    }
    setupKernels(isTraining) {
        const output = [this.width, this.height];
        if (isTraining) {
            this.predictKernelMap = makeKernelMap({ dropouts: setDropout }, trainingPredict, {
                output,
                immutable: true,
            });
            this.compareKernel = makeKernel(compare$3, { output, immutable: true });
        }
        else {
            this.predictKernelMap = makeKernelMap({}, predict$5, { output, immutable: true });
        }
    }
    predict() {
        release(this.weights);
        if (this.dropouts) {
            release(this.dropouts);
        }
        const { result, dropouts } = this
            .predictKernelMap(this.inputLayer.weights);
        this.weights = result;
        this.dropouts = dropouts;
    }
    compare() {
        release(this.deltas);
        this.deltas = this.compareKernel(this.dropouts, this.inputLayer.deltas);
    }
}
function dropout(inputLayer, settings) {
    return new Dropout(inputLayer, settings);
}

function feedForward(settings, input) {
    const { height, praxisOpts = null } = settings;
    const weights = random({
        id: 'weights',
        height,
        width: input.height,
        praxisOpts,
    });
    const biases = random({ id: 'biases', height, praxisOpts });
    return sigmoid$1(add$1(multiply$1(weights, input, { praxisOpts }), biases, { praxisOpts }), { praxisOpts });
}

function predict$4(inputs, filters, biases) {
    let output = 0;
    let i = 0;
    for (let y = 0; y < this.constants.inputHeight; y++) {
        for (let x = 0; x < this.constants.inputWidth; x++) {
            output += inputs[y][x] * filters[this.thread.x][i];
            i++;
        }
    }
    return output + biases[this.thread.x];
}
function predict3D$4(inputs, filters, biases) {
    let output = 0;
    let i = 0;
    for (let z = 0; z < this.constants.inputDepth; z++) {
        for (let y = 0; y < this.constants.inputHeight; y++) {
            for (let x = 0; x < this.constants.inputWidth; x++) {
                output += inputs[z][y][x] * filters[this.thread.x][i];
                i++;
            }
        }
    }
    return output + biases[this.thread.x];
}
function compareInputDeltas(inputDeltas, deltas, filters) {
    let sum = 0;
    const filterX = this.thread.x + this.thread.y * this.output.x;
    for (let filterY = 0; filterY < this.constants.filterCount; filterY++) {
        sum += filters[filterY][filterX] * deltas[0][filterY];
    }
    return sum + inputDeltas[this.thread.y][this.thread.x];
}
function compareInputDeltas3D(inputDeltas, deltas, filters) {
    let sum = 0;
    const filterX = this.thread.x + this.thread.y * this.output.x;
    for (let filterY = 0; filterY < this.constants.filterCount; filterY++) {
        sum += filters[filterY][filterX] * deltas[0][filterY];
    }
    return sum + inputDeltas[this.thread.z][this.thread.y][this.thread.x];
}
function compareBiases(biases, deltas) {
    return biases[this.thread.x] + deltas[this.thread.y][this.thread.x];
}
function compareFilterDeltas(filterDeltas, inputWeights, deltas) {
    return (filterDeltas[this.thread.y][this.thread.x] +
        inputWeights[this.thread.y][this.thread.x] *
            deltas[this.constants.deltaY][this.constants.deltaX]);
}
function compareFilterDeltas3D(filterDeltas, inputWeights, deltas) {
    const inputZ = Math.floor(this.thread.x / (this.constants.inputWidth * this.constants.inputHeight));
    const inputY = Math.floor((this.thread.x -
        inputZ * this.constants.inputWidth * this.constants.inputHeight) /
        this.constants.inputWidth);
    const inputX = this.thread.x -
        this.constants.inputWidth * (inputY + this.constants.inputHeight * inputZ);
    return (filterDeltas[this.thread.y][this.thread.x] +
        inputWeights[inputZ][inputY][inputX] * deltas[0][this.thread.y]);
}
class FullyConnected extends Filter {
    constructor(settings, inputLayer) {
        super(settings, inputLayer);
        this.compareFilterDeltasKernel = null;
        this.compareInputDeltasKernel = null;
        this.compareBiasesKernel = null;
        this.settings = { ...settings };
        this.validate();
        const connectionCount = inputLayer.width * inputLayer.height * inputLayer.depth;
        this.biases = values(this.height, this.bias);
        this.biasDeltas = zeros$1(this.height);
        this.filters = randos2D(connectionCount, this.height);
        this.filterDeltas = zeros2D(connectionCount, this.height);
        if (this.depth > 0) {
            this.weights = randos3D(this.width, this.height, this.depth);
            this.deltas = zeros3D(this.width, this.height, this.depth);
        }
        else if (this.height > 0) {
            this.weights = randos2D(this.width, this.height);
            this.deltas = zeros2D(this.width, this.height);
        }
    }
    get bias() {
        return this.settings.bias;
    }
    get biases() {
        return this.settings.biases;
    }
    set biases(biases) {
        this.settings.biases = biases;
    }
    get biasDeltas() {
        return this.settings.biases;
    }
    set biasDeltas(biasDeltas) {
        this.settings.biasDeltas = biasDeltas;
    }
    validate() {
        super.validate();
        if (this.depth > 0)
            throw new Error('depth not supported');
    }
    setupKernels() {
        const { inputLayer } = this;
        const connectionCount = inputLayer.width * inputLayer.height * inputLayer.depth;
        if (inputLayer.depth > 0) {
            this.predictKernel = makeKernel(predict3D$4, {
                output: [this.width, this.height],
                constants: {
                    inputHeight: inputLayer.height,
                    inputWidth: inputLayer.width,
                    inputDepth: inputLayer.depth,
                },
            });
            this.compareFilterDeltasKernel = makeKernel(compareFilterDeltas3D, {
                output: [connectionCount, this.height],
                constants: {
                    inputWidth: inputLayer.width,
                    inputHeight: inputLayer.height,
                },
                immutable: true,
            });
            this.compareInputDeltasKernel = makeKernel(compareInputDeltas3D, {
                output: [inputLayer.width, inputLayer.height, inputLayer.depth],
                constants: {
                    filterCount: this.height,
                },
                immutable: true,
            });
        }
        else {
            this.predictKernel = makeKernel(predict$4, {
                output: [this.width, this.height],
                constants: {
                    inputHeight: inputLayer.height,
                    inputWidth: inputLayer.width,
                },
            });
            this.compareFilterDeltasKernel = makeKernel(compareFilterDeltas, {
                output: [connectionCount, this.height],
                constants: {
                    inputWidth: inputLayer.width,
                },
            });
            this.compareInputDeltasKernel = makeKernel(compareInputDeltas, {
                output: [inputLayer.width, inputLayer.height],
                constants: {
                    filterCount: this.height,
                },
            });
        }
        this.compareBiasesKernel = makeKernel(compareBiases, {
            output: [this.width, this.height],
        });
    }
    predict() {
        this.weights = this.predictKernel(this.inputLayer.weights, this.filters, this.biases);
    }
    compare() {
        const inputLayerDeltas = this.inputLayer.deltas;
        this.inputLayer.deltas = this
            .compareInputDeltasKernel(inputLayerDeltas, this.deltas, this.filters);
        release(inputLayerDeltas);
        const { biasDeltas, filterDeltas } = this;
        // TODO: handle biasDeltas learn
        this.biasDeltas = this.compareBiasesKernel(this.biases, this.deltas);
        // TODO: handle filterDeltas learn
        this.filterDeltas = this.compareFilterDeltasKernel(filterDeltas, this.inputLayer.weights, this.deltas);
        release(biasDeltas);
        release(filterDeltas);
    }
}
function fullyConnected(settings, inputLayer) {
    return new FullyConnected(settings, inputLayer);
}

function predict$3(weights) {
    return -weights[this.thread.y][this.thread.x];
}
class Negative extends Modifier {
    constructor(inputLayer, settings) {
        super(inputLayer, settings);
        this.validate();
    }
    setupKernels() {
        this.predictKernel = makeKernel(predict$3, {
            output: [this.width, this.height],
        });
    }
    predict() {
        this.weights = this.predictKernel(this.inputLayer.weights);
    }
}
function negative(inputLayer, settings) {
    return new Negative(inputLayer, settings);
}

function predict$2(inputLayerWeights1, inputLayerWeights2) {
    return (inputLayerWeights1[this.thread.y][this.thread.x] *
        inputLayerWeights2[this.thread.y][this.thread.x]);
}
function compare$2(weights, deltas) {
    return (weights[this.thread.y][this.thread.x] * deltas[this.thread.y][this.thread.x]);
}
class MultiplyElement extends Operator {
    get width() {
        return this.inputLayer1.width;
    }
    get height() {
        return this.inputLayer1.height;
    }
    get depth() {
        return this.inputLayer1.depth;
    }
    validate() {
        super.validate();
        checkSameSize(this.inputLayer1, this.inputLayer2);
    }
    setupKernels() {
        this.predictKernel = makeKernel(predict$2, {
            output: [this.width, this.height],
            immutable: true,
        });
        this.compareKernel = makeKernel(compare$2, {
            output: [this.width, this.height],
            immutable: true,
        });
    }
    predict() {
        release(this.weights);
        this.weights = this.predictKernel(this.inputLayer1.weights, this.inputLayer2.weights);
        clear(this.deltas);
    }
    compare() {
        release(this.inputLayer1.deltas);
        release(this.inputLayer2.deltas);
        this.inputLayer1.deltas = this.compareKernel(this.inputLayer2.weights, this.deltas);
        this.inputLayer2.deltas = this.compareKernel(this.inputLayer1.weights, this.deltas);
    }
}
function multiplyElement$1(inputLayer1, inputLayer2, settings) {
    return new MultiplyElement(inputLayer1, inputLayer2, settings);
}

function ones$1(size) {
    return new Float32Array(size).fill(1);
}
function ones2D(width, height) {
    const result = new Array(height);
    for (let y = 0; y < height; y++) {
        result[y] = ones$1(width);
    }
    return result;
}

class Ones extends Model {
    constructor(settings) {
        super(settings);
        this.validate();
        this.weights = ones2D(this.width, this.height);
        this.deltas = zeros2D(this.width, this.height);
    }
}
function ones(settings) {
    return new Ones(settings);
}

function predict2D$3(inputs) {
    return activate$1(inputs[this.thread.y][this.thread.x]);
}
function predict3D$3(inputs) {
    return activate$1(inputs[this.thread.z][this.thread.y][this.thread.x]);
}
function compare2D$3(weights, errors) {
    return measure$1(weights[this.thread.y][this.thread.x], errors[this.thread.y][this.thread.x]);
}
function compare3D$3(weights, errors) {
    return measure$1(weights[this.thread.z][this.thread.y][this.thread.x], errors[this.thread.z][this.thread.y][this.thread.x]);
}
class Tanh extends Activation {
    setupKernels() {
        if (this.depth > 0) {
            this.predictKernel = makeKernel(predict3D$3, {
                output: [this.width, this.height, this.depth],
                functions: [activate$1],
                immutable: true,
            });
            this.compareKernel = makeKernel(compare3D$3, {
                output: [this.width, this.height, this.depth],
                functions: [measure$1],
                immutable: true,
            });
        }
        else {
            this.predictKernel = makeKernel(predict2D$3, {
                output: [this.width, this.height],
                functions: [activate$1],
                immutable: true,
            });
            this.compareKernel = makeKernel(compare2D$3, {
                output: [this.width, this.height],
                functions: [measure$1],
                immutable: true,
            });
        }
    }
    predict() {
        release(this.weights);
        this.weights = this.predictKernel(this.inputLayer.weights);
        clear(this.deltas);
    }
    compare() {
        release(this.inputLayer.deltas);
        this.inputLayer.deltas = this.compareKernel(this.weights, this.deltas);
    }
}
function tanh$1(inputLayer, settings) {
    return new Tanh(inputLayer, settings);
}

class Zeros extends Model {
    constructor(settings) {
        super(settings);
        this.validate();
        this.weights = zeros2D(this.width, this.height);
        this.deltas = zeros2D(this.width, this.height);
    }
    predict() {
        // throw new Error(`${this.constructor.name}-predict is not yet implemented`)
    }
    compare() {
        // throw new Error(`${this.constructor.name}-compare is not yet implemented`)
    }
}
function zeros(settings) {
    return new Zeros(settings);
}

function gru(settings, recurrentInput, input) {
    const { height } = settings;
    const updateGateWeights = random({ height, width: input.height });
    const updateGatePeepholes = random({ width: height, height });
    const updateGateBias = zeros({ height });
    const updateGate = sigmoid$1(add$1(add$1(multiply$1(updateGateWeights, input), multiply$1(updateGatePeepholes, recurrentInput)), updateGateBias));
    const resetGateWeights = random({ height, width: input.height });
    const resetGatePeepholes = random({ width: height, height });
    const resetGateBias = zeros({ height });
    const resetGate = sigmoid$1(add$1(add$1(multiply$1(resetGateWeights, input), multiply$1(resetGatePeepholes, recurrentInput)), resetGateBias));
    const cellWeights = random({ height, width: input.height });
    const cellPeepholes = random({ width: height, height });
    const cellBias = zeros({ height });
    const cell = tanh$1(add$1(add$1(multiply$1(cellWeights, input), multiply$1(cellPeepholes, multiplyElement$1(resetGate, recurrentInput))), cellBias));
    // compute hidden state as gated, saturated cell activations
    // negate updateGate
    return add$1(multiplyElement$1(add$1(ones({ width: updateGate.width, height: updateGate.height }), negative(updateGate)), cell), multiplyElement$1(recurrentInput, updateGate));
}

const defaults$5 = {
    weights: null,
};
class Input extends EntryPoint {
    constructor(settings) {
        super({ ...defaults$5, ...settings });
        this.reshapeInput = null;
        this.validate();
        this.reshapeInput = null;
        this.deltas = zeros2D(this.width, this.height);
    }
    setupKernels() {
        if (this.width === 1) {
            this.predict = this.predict1D;
            this.reshapeInput = makeKernel(function (value) {
                return value[this.thread.y];
            }, {
                output: [1, this.height],
                immutable: true,
            });
        }
    }
    reuseKernels(layer) {
        // super.reuseKernels(layer);
        this.reshapeInput = layer.reshapeInput;
    }
    predict(inputs) {
        if ((Array.isArray(inputs) || inputs instanceof Float32Array) &&
            typeof inputs[0] === 'number' &&
            inputs.length === this.height * this.width) {
            release(this.weights);
            this.weights = kernelInput(inputs, [this.width, this.height]);
        }
        else if (Array.isArray(inputs) &&
            inputs.length === this.height &&
            (Array.isArray(inputs[0]) || inputs[0] instanceof Float32Array) &&
            inputs[0].length === this.width) {
            this.weights = clone(inputs);
        }
        else {
            throw new Error('Inputs are not of sized correctly');
        }
        clear(this.deltas);
    }
    predict1D(inputs) {
        if (this.weights)
            release(this.weights);
        if (this.reshapeInput) {
            this.weights = this.reshapeInput(inputs);
        }
        else {
            this.weights = inputs;
        }
        clear(this.deltas);
    }
    compare() {
        // throw new Error(`${this.constructor.name}-compare is not yet implemented`)
    }
}
function input(settings) {
    return new Input(settings);
}

function predict2D$2(inputs) {
    return activate(inputs[this.thread.y][this.thread.x]);
}
function predict3D$2(inputs) {
    return activate(inputs[this.thread.z][this.thread.y][this.thread.x]);
}
function compare2D$2(weights, deltas) {
    return measure(weights[this.thread.y][this.thread.x], deltas[this.thread.y][this.thread.x]);
}
function compare3D$2(weights, deltas) {
    return measure(weights[this.thread.z][this.thread.y][this.thread.x], deltas[this.thread.z][this.thread.y][this.thread.x]);
}
class LeakyRelu extends Activation {
    setupKernels() {
        const { width, height, depth } = this.inputLayer;
        if (this.depth > 0) {
            this.predictKernel = makeKernel(predict3D$2, {
                output: [width, height, depth],
                functions: [activate],
                immutable: true,
            });
            this.compareKernel = makeKernel(compare3D$2, {
                output: [width, height, depth],
                functions: [measure],
                immutable: true,
            });
        }
        else {
            this.predictKernel = makeKernel(predict2D$2, {
                output: [width, height],
                functions: [activate],
                immutable: true,
            });
            this.compareKernel = makeKernel(compare2D$2, {
                output: [width, height],
                functions: [measure],
                immutable: true,
            });
        }
    }
    predict() {
        release(this.weights);
        this.weights = this.predictKernel(this.inputLayer.weights);
        clear(this.deltas);
    }
    compare() {
        const { deltas } = this;
        this.deltas = this.compareKernel(this.weights, deltas);
        release(deltas);
    }
}
function leakyRelu(inputLayer, settings) {
    return new LeakyRelu(inputLayer, settings);
}

function lstmCell(settings, input, recurrentInput) {
    const { height } = settings;
    if (typeof height !== 'number') {
        throw new Error('no settings.height given');
    }
    if (recurrentInput.setDimensions) {
        recurrentInput.setDimensions(1, height);
    }
    const inputGateWeights = random({
        height,
        width: input.height,
        std: 0.08,
        id: 'inputGateWeights',
    });
    const inputGatePeepholes = random({
        width: height,
        height,
        std: 0.08,
        id: 'inputGatePeepholes',
    });
    const inputGateBias = zeros({ height, id: 'inputGateBias' });
    const inputGate = sigmoid$1(add$1(add$1(multiply$1(inputGateWeights, input), multiply$1(inputGatePeepholes, recurrentInput)), inputGateBias), { id: 'inputGate' });
    const forgetGateWeights = random({
        height,
        width: input.height,
        std: 0.08,
        id: 'forgetGateWeights',
    });
    const forgetGatePeepholes = random({
        width: height,
        height,
        std: 0.08,
        id: 'forgetGatePeepholes',
    });
    const forgetGateBias = zeros({ height, id: 'forgetGateBias' });
    const forgetGate = sigmoid$1(add$1(add$1(multiply$1(forgetGateWeights, input), multiply$1(forgetGatePeepholes, recurrentInput)), forgetGateBias), { id: 'forgetGate' });
    const outputGateWeights = random({
        height,
        width: input.height,
        std: 0.08,
        id: 'outputGateWeights',
    });
    const outputGatePeepholes = random({
        width: height,
        height,
        std: 0.08,
        id: 'outputGatePeepholes',
    });
    const outputGateBias = zeros({ height, id: 'outputGateBias' });
    const outputGate = sigmoid$1(add$1(add$1(multiply$1(outputGateWeights, input), multiply$1(outputGatePeepholes, recurrentInput)), outputGateBias), { id: 'outputGate' });
    const memoryWeights = random({
        height,
        width: input.height,
        std: 0.08,
        id: 'memoryWeights',
    });
    const memoryPeepholes = random({
        width: height,
        height,
        std: 0.08,
        id: 'memoryPeepholes',
    });
    const memoryBias = zeros({ height, id: 'memoryBias' });
    const memory = tanh$1(add$1(add$1(multiply$1(memoryWeights, input), multiply$1(memoryPeepholes, recurrentInput)), memoryBias), { id: 'memory' });
    // compute new cell activation
    const retainCell = multiplyElement$1(forgetGate, recurrentInput, {
        id: 'retainCell',
    }); // what do we keep from cell
    const writeCell = multiplyElement$1(inputGate, memory, { id: 'writeCell' }); // what do we write to cell
    const cell = add$1(retainCell, writeCell, { id: 'cell' }); // new cell contents
    // compute hidden state as gated, saturated cell activations
    return multiplyElement$1(outputGate, tanh$1(cell), { id: 'activations' });
}

function output(settings, inputLayer) {
    const { height } = settings;
    const outputGate = random({
        height,
        width: inputLayer.height,
        id: 'outputGate',
        std: 0.08,
    });
    const output = random({ height, id: 'output', std: 0.08 });
    const outputGateConnector = multiply$1(outputGate, inputLayer, {
        id: 'outputGateConnected',
    });
    return target({ id: 'target', ...settings }, add$1(outputGateConnector, output));
}

function setSwitchY(value) {
    return value;
}
function setSwitchX(value) {
    return value;
}
function predict$1(inputs) {
    const startFilterX = this.constants.paddingX - this.thread.x * this.constants.strideX;
    const startInputX = this.thread.x * this.constants.strideX - this.constants.paddingX;
    const endFilterX = Math.min(this.constants.filterWidth, startFilterX + this.constants.inputWidth);
    const startFilterY = this.constants.paddingY - this.thread.y * this.constants.strideY;
    const startInputY = this.thread.y * this.constants.strideY - this.constants.paddingY;
    const endFilterY = Math.min(this.constants.filterHeight, startFilterY + this.constants.inputHeight);
    let largestValue = -99999;
    // convolve centered at this particular location
    for (let filterY = Math.max(0, startFilterY), inputY = Math.max(0, startInputY); filterY < endFilterY; filterY++, inputY++) {
        for (let filterX = Math.max(0, startFilterX), inputX = Math.max(0, startInputX); filterX < endFilterX; filterX++, inputX++) {
            if (inputY >= 0 &&
                inputY < this.constants.inputHeight &&
                inputX >= 0 &&
                inputX < this.constants.inputWidth) {
                const input = inputs[this.thread.z][inputY][inputX];
                if (input > largestValue) {
                    largestValue = input;
                }
            }
        }
    }
    return largestValue;
}
function compare$1(deltas, switchY, switchX) {
    const x = Math.floor((this.thread.x / this.output.x) * this.constants.outputWidth);
    const y = Math.floor((this.thread.y / this.output.y) * this.constants.outputHeight);
    let value = 0;
    for (let deltasY = 0; deltasY < this.constants.inputHeight; deltasY++) {
        for (let deltasX = 0; deltasX < this.constants.inputWidth; deltasX++) {
            const switchXValue = switchX[deltasY][deltasX];
            const switchYValue = switchY[deltasY][deltasX];
            if (switchXValue === x && switchYValue === y) {
                value += deltas[deltasY][deltasX];
            }
        }
    }
    return value;
}
const defaults$4 = {
    padding: 0,
    stride: 0,
    filterWidth: 0,
    filterHeight: 0,
    filterCount: 0,
};
class Pool extends Filter {
    constructor(settings, inputLayer) {
        super(settings, inputLayer);
        this.predictKernelMap = null;
        this.settings = {
            ...settings,
            ...getStride(settings, defaults$4),
            ...getPadding(settings, defaults$4),
        };
        this.weights = randos3D(this.width, this.height, this.depth);
        this.deltas = zeros3D(this.width, this.height, this.depth);
        this.filters = randos3D(this.filterWidth, this.filterHeight, this.filterCount);
        this.filterDeltas = zeros3D(this.filterWidth, this.filterHeight, this.filterCount);
        this.validate();
    }
    get strideX() {
        return this.settings.strideX;
    }
    get strideY() {
        return this.settings.strideY;
    }
    get paddingX() {
        return this.settings.paddingX;
    }
    get paddingY() {
        return this.settings.paddingY;
    }
    get width() {
        return Math.floor((this.inputLayer.width + this.paddingX * 2 - this.filterWidth) /
            this.strideX +
            1);
    }
    get height() {
        return Math.floor((this.inputLayer.height + this.paddingY * 2 - this.filterHeight) /
            this.strideY +
            1);
    }
    get depth() {
        return this.settings.filterCount;
    }
    get filterCount() {
        // TODO: handle 1 depth?
        return this.settings.filterCount;
    }
    get switchX() {
        return this.settings.switchX;
    }
    set switchX(switchX) {
        this.settings.switchX = switchX;
    }
    get switchY() {
        return this.settings.switchY;
    }
    set switchY(switchY) {
        this.settings.switchY = switchY;
    }
    setupKernels() {
        this.predictKernelMap = makeKernelMap({
            switchX: setSwitchX,
            switchY: setSwitchY,
        }, predict$1, {
            output: [this.width, this.height, this.depth],
            constants: {
                inputWidth: this.inputLayer.width,
                inputHeight: this.inputLayer.height,
                paddingX: this.paddingX,
                paddingY: this.paddingY,
                filterHeight: this.filterHeight,
                filterWidth: this.filterWidth,
            },
        });
        this.compareKernel = makeKernel(compare$1, {
            output: [
                this.inputLayer.width,
                this.inputLayer.height,
                this.inputLayer.depth,
            ],
            constants: {
                inputWidth: this.inputLayer.width,
                inputHeight: this.inputLayer.height,
                outputWidth: this.width,
                outputHeight: this.height,
            },
        });
    }
    predict() {
        const { result: weights, switchX, switchY } = this
            .predictKernelMap(this.inputLayer.weights);
        this.switchX = switchX;
        this.switchY = switchY;
        this.weights = weights;
    }
    compare() {
        // debugger;
        // const depth = this.inputLayer.deltas.length;
        // const height = this.inputLayer.deltas[0].length;
        // const width = this.inputLayer.deltas[0][0].length;
        // const type = typeof this.inputLayer.deltas[0][0][0];
        const inputLayerDeltas = this.inputLayer.deltas;
        this.inputLayer.deltas = this.compareKernel(this.deltas, this.switchX, this.switchY);
        release(inputLayerDeltas);
        // debugger;
        // if (depth !== this.inputLayer.deltas.length) debugger;
        // if (height !== this.inputLayer.deltas[0].length) debugger;
        // if (width !== this.inputLayer.deltas[0][0].length) debugger;
        // if (type !== typeof this.inputLayer.deltas[0][0][0]) debugger;
    }
}
function pool(settings, inputLayer) {
    return new Pool(settings, inputLayer);
}

class RecurrentInput extends Internal {
    constructor(recurrentInput) {
        super();
        this.praxis = null;
        this.predictKernel = null;
        this.compareKernel = null;
        this.settings = {};
        this.recurrentInput = recurrentInput;
        this.validate();
    }
    get width() {
        return this.recurrentInput.width;
    }
    get height() {
        return this.recurrentInput.height;
    }
    get depth() {
        return this.recurrentInput.depth;
    }
    get deltas() {
        return this.recurrentInput.deltas;
    }
    set deltas(deltas) {
        const recurrentInputDeltas = this.recurrentInput.deltas;
        this.recurrentInput.deltas = deltas;
        release(recurrentInputDeltas);
    }
    get weights() {
        return this.recurrentInput.weights;
    }
    set weights(weights) {
        const recurrentInputWeights = this.recurrentInput.weights;
        this.recurrentInput.weights = weights;
        release(recurrentInputWeights);
    }
    validate() {
        BaseLayer.prototype.validate.call(this);
        if (this.width !== this.recurrentInput.width) {
            throw new Error(`${this.constructor.name} layer width ${this.width} and ${this.recurrentInput.constructor.name} width (${this.recurrentInput.width}) are not same`);
        }
        if (this.height !== this.recurrentInput.height) {
            throw new Error(`${this.constructor.name} layer height ${this.height} and ${this.recurrentInput.constructor.name} width (${this.recurrentInput.height}) are not same`);
        }
    }
    setDimensions(width, height) {
        this.recurrentInput.width = width;
        this.recurrentInput.height = height;
    }
    predict() {
        // throw new Error(`${this.constructor.name}-predict is not yet implemented`)
    }
    compare() {
        // throw new Error(`${this.constructor.name}-compare is not yet implemented`)
    }
    learn() {
        // throw new Error(`${this.constructor.name}-learn is not yet implemented`)
    }
    setupKernels() {
        // throw new Error(
        //   `${this.constructor.name}-setupKernels is not yet implemented`
        // )
    }
    reuseKernels() {
        // throw new Error(
        //   `${this.constructor.name}-reuseKernels is not yet implemented`
        // )
    }
}

class RecurrentZeros extends Internal {
    constructor(settings) {
        super();
        this.praxis = null;
        this.settings = {};
        this.predictKernel = null;
        this.compareKernel = null;
        if (settings) {
            this.settings = { ...settings };
        }
    }
    setDimensions(width, height) {
        this.praxis = null;
        this.settings = {
            ...this.settings,
            width,
            height,
            weights: zeros2D(width, height),
            deltas: zeros2D(width, height),
        };
    }
    setupKernels() {
        // throw new Error(
        //   `${this.constructor.name}-setupKernels is not yet implemented`
        // )
    }
    reuseKernels() {
        // throw new Error(
        //   `${this.constructor.name}-reuseKernels is not yet implemented`
        // )
    }
    predict() {
        // throw new Error(`${this.constructor.name}-predict is not yet implemented`)
    }
    compare() {
        // throw new Error(`${this.constructor.name}-compare is not yet implemented`)
    }
    learn(learningRate) {
        const { weights: oldWeights } = this;
        this.weights = this.praxis.run(this, learningRate);
        // this.deltas = deltas;
        release(oldWeights);
        clear(this.deltas);
    }
}
function recurrentZeros() {
    return new RecurrentZeros();
}

function predict2D$1(inputs) {
    return activate$3(inputs[this.thread.y][this.thread.x]);
}
function compare2D$1(weights, deltas) {
    return measure$3(weights[this.thread.y][this.thread.x], deltas[this.thread.y][this.thread.x]);
}
function predict3D$1(inputs) {
    return activate$3(inputs[this.thread.z][this.thread.y][this.thread.x]);
}
function compare3D$1(weights, deltas) {
    return measure$3(weights[this.thread.z][this.thread.y][this.thread.x], deltas[this.thread.z][this.thread.y][this.thread.x]);
}
class Relu extends Activation {
    setupKernels() {
        const { width, height, depth } = this.inputLayer;
        if (depth > 0) {
            this.predictKernel = makeKernel(predict3D$1, {
                output: [width, height, depth],
                functions: [activate$3],
                immutable: true,
            });
            this.compareKernel = makeKernel(compare3D$1, {
                output: [width, height, depth],
                functions: [measure$3],
                immutable: true,
            });
        }
        else {
            this.predictKernel = makeKernel(predict2D$1, {
                output: [width, height],
                functions: [activate$3],
                immutable: true,
            });
            this.compareKernel = makeKernel(compare2D$1, {
                output: [width, height],
                functions: [measure$3],
                immutable: true,
            });
        }
    }
    predict() {
        release(this.weights);
        this.weights = this.predictKernel(this.inputLayer.weights);
        clear(this.deltas);
    }
    compare() {
        release(this.inputLayer.deltas);
        this.inputLayer.deltas = this.compareKernel(this.weights, this.deltas);
    }
}
function relu$1(inputLayer, settings) {
    return new Relu(inputLayer, settings);
}

function rnnCell(settings, input, recurrentInput) {
    const { height } = settings;
    if (typeof height !== 'number')
        throw new Error('height not set');
    if (recurrentInput.setDimensions) {
        recurrentInput.setDimensions(1, height);
    }
    // wxh
    const weight = random({
        id: 'weight',
        height,
        width: input.height,
        std: 0.08,
    });
    // whh
    const transition = random({
        id: 'transition',
        height,
        width: height,
        std: 0.08,
    });
    // bhh
    const bias = zeros({ id: 'bias', height });
    return relu$1(add$1(add$1(multiply$1(weight, input), multiply$1(transition, recurrentInput)), bias));
}

class Regression extends BaseLayer {
    constructor(settings, inputLayer) {
        super(settings);
        this.inputLayer = inputLayer;
        this.validate();
    }
    predict() {
        release(this.weights);
        this.weights = clone(this.inputLayer.weights);
    }
    learn() {
        // throw new Error(`${this.constructor.name}-learn is not yet implemented`)
    }
}
// TODO: handle `loss += 0.5*dy*dy;` total and sum in learn
function regression(settings, inputLayer) {
    return new Regression(settings, inputLayer);
}

function getMaxValue2D(inputs) {
    let maxInput = -Infinity;
    for (let y = 0; y < this.constants.inputHeight; y++) {
        for (let x = 0; x < this.constants.inputWidth; x++) {
            const input = inputs[y][x];
            if (input > maxInput) {
                maxInput = input;
            }
        }
    }
    return maxInput;
}
function getMaxValue3D(inputs) {
    let maxInput = -Infinity;
    for (let z = 0; z < this.constants.inputDepth; z++) {
        for (let y = 0; y < this.constants.inputHeight; y++) {
            for (let x = 0; x < this.constants.inputWidth; x++) {
                const input = inputs[z][y][x];
                if (input > maxInput) {
                    maxInput = input;
                }
            }
        }
    }
    return maxInput;
}
function getSum2D(inputs) {
    let sum = 0;
    for (let y = 0; y < this.constants.inputHeight; y++) {
        for (let x = 0; x < this.constants.inputWidth; x++) {
            sum += inputs[y][x];
        }
    }
    return sum;
}
function getSum3D(inputs) {
    let sum = 0;
    for (let z = 0; z < this.constants.inputDepth; z++) {
        for (let y = 0; y < this.constants.inputHeight; y++) {
            for (let x = 0; x < this.constants.inputWidth; x++) {
                sum += inputs[z][y][x];
            }
        }
    }
    return sum;
}
function getExponentials(inputs, maxInput) {
    return Math.exp(inputs[this.thread.x] - maxInput[0]);
}
function getExponentials3D(inputs, maxInput) {
    return Math.exp(inputs[this.thread.z][this.thread.y][this.thread.x] - maxInput[0]);
}
function predict2D(exponentials, exponentialsSum) {
    return exponentials[this.thread.y][this.thread.x] / exponentialsSum[0];
}
function predict3D(exponentials, exponentialsSum) {
    return (exponentials[this.thread.z][this.thread.y][this.thread.x] /
        exponentialsSum[0]);
}
function compare2D(target, exponentials) {
    let indicator = 0;
    const index = this.thread.x + this.thread.y * this.output.x;
    if (index === target) {
        indicator = 1;
    }
    return -(indicator - exponentials[this.thread.y][this.thread.x]);
}
function compare3D(target, exponentials) {
    let indicator = 0;
    const index = this.thread.x +
        this.thread.y * this.output.x +
        this.thread.z * this.output.x * this.output.y;
    if (index === target) {
        indicator = 1;
    }
    return -(indicator - exponentials[this.thread.z][this.thread.y][this.thread.x]);
}
// TODO: handle: `return -Math.log(this.es[y]);` in learn
class SoftMax extends Modifier {
    constructor(inputLayer, settings) {
        super(inputLayer, settings);
        this.errors = null;
        this.getExponentialsKernel = null;
        this.getMaxValueKernel = null;
        this.getSumKernel = null;
        this.validate();
        if (this.depth > 0) {
            this.weights = randos3D(this.width, this.height, this.depth);
            this.deltas = zeros3D(this.width, this.height, this.depth);
        }
        else if (this.height > 0) {
            this.weights = randos2D(this.width, this.height);
            this.deltas = zeros2D(this.width, this.height);
        }
        else {
            this.weights = randos(this.width);
            this.deltas = zeros$1(this.width);
        }
    }
    setupKernels() {
        const { width, height, depth } = this;
        if (depth > 0) {
            this.getExponentialsKernel = makeKernel(getExponentials3D, {
                output: [width, height, depth],
            });
            this.getMaxValueKernel = makeKernel(getMaxValue3D, {
                output: [1, 1, 1],
                constants: {
                    inputWidth: width,
                    inputHeight: height,
                    inputDepth: depth,
                },
            });
            this.getSumKernel = makeKernel(getSum3D, {
                output: [1, 1, 1],
                constants: {
                    inputWidth: width,
                    inputHeight: height,
                    inputDepth: depth,
                },
            });
            this.predictKernel = makeKernel(predict3D, {
                output: [width, height, depth],
            });
            this.compareKernel = makeKernel(compare3D, {
                output: [width, height, depth],
                immutable: true,
            });
        }
        else {
            this.getExponentialsKernel = makeKernel(getExponentials, {
                output: [width, height],
            });
            this.getMaxValueKernel = makeKernel(getMaxValue2D, {
                output: [1, 1],
                constants: {
                    inputWidth: width,
                    inputHeight: height,
                },
            });
            this.getSumKernel = makeKernel(getSum2D, {
                output: [1, 1],
                constants: {
                    inputWidth: width,
                    inputHeight: height,
                },
            });
            this.predictKernel = makeKernel(predict2D, {
                output: [width, height],
            });
            this.compareKernel = makeKernel(compare2D, {
                output: [width, height],
                immutable: true,
            });
        }
    }
    predict() {
        const maxValue = this.getMaxValueKernel(this.inputLayer.weights);
        const exponentials = this.getExponentialsKernel(this.inputLayer.weights, maxValue);
        const exponentialsSum = this.getSumKernel(exponentials);
        this.weights = this.predictKernel(exponentials, exponentialsSum);
    }
    compare(targetValues) {
        const { deltas, errors } = this;
        this.errors = this.compareKernel(targetValues[0], deltas);
        this.deltas = clone(this.errors);
        release(deltas);
        release(errors);
        const inputLayerDeltas = this.inputLayer.deltas;
        this.inputLayer.deltas = clone(this.deltas);
        release(inputLayerDeltas);
    }
}
function softMax(inputLayer, settings) {
    return new SoftMax(inputLayer, settings);
}

class SVM extends BaseLayer {
    constructor(inputLayer, settings) {
        super(settings);
        this.inputLayer = inputLayer;
    }
    predict() {
        release(this.weights);
        this.weights = clone(this.inputLayer.weights);
        this.validate();
    }
    learn() {
        // throw new Error(`${this.constructor.name}-learn is not yet implemented`)
    }
}
// function learn(target) {
//   if (y === i) {
//     continue;
//   }
//   const ydiff = -yscore + x.w[i] + margin;
//   if (ydiff > 0) {
//     // violating dimension, apply loss
//     x.dw[i] += 1;
//     x.dw[y] -= 1;
//     loss += ydiff;
//   }
// }
function svm(inputLayer, settings) {
    return new SVM(inputLayer, settings);
}

function predict(value) {
    return value[this.thread.x][this.thread.y];
}
const compare = predict;
class Transpose extends Modifier {
    get width() {
        return this.inputLayer.height;
    }
    get height() {
        return this.inputLayer.width;
    }
    constructor(inputLayer) {
        super(inputLayer);
        this.validate();
    }
    setupKernels() {
        this.predictKernel = makeKernel(predict, {
            output: [this.height, this.width],
        });
        this.compareKernel = makeKernel(compare, {
            output: [this.width, this.height],
        });
    }
    predict() {
        this.weights = this.predictKernel(this.inputLayer.weights);
        clear(this.deltas);
    }
    compare() {
        this.inputLayer.deltas = this.compareKernel(this.deltas);
    }
}
function transpose(inputLayer) {
    return new Transpose(inputLayer);
}

const layerTypes = {
    Activation,
    Internal,
    InternalModel,
    EntryPoint,
    Filter,
    Model,
    Modifier,
    Operator,
    Target,
};

var layer = /*#__PURE__*/Object.freeze({
    __proto__: null,
    layerTypes: layerTypes,
    Add: Add,
    add: add$1,
    arthurFeedForward: arthurFeedForward,
    BaseLayer: BaseLayer,
    baseLayerDefaultSettings: baseLayerDefaultSettings,
    Convolution: Convolution,
    convolution: convolution,
    Dropout: Dropout,
    dropout: dropout,
    feedForward: feedForward,
    FullyConnected: FullyConnected,
    fullyConnected: fullyConnected,
    gru: gru,
    Input: Input,
    input: input,
    LeakyRelu: LeakyRelu,
    leakyRelu: leakyRelu,
    lstmCell: lstmCell,
    Multiply: Multiply,
    multiply: multiply$1,
    MultiplyElement: MultiplyElement,
    multiplyElement: multiplyElement$1,
    Negative: Negative,
    negative: negative,
    Ones: Ones,
    ones: ones,
    output: output,
    Pool: Pool,
    pool: pool,
    Random: Random,
    random: random,
    RecurrentInput: RecurrentInput,
    RecurrentZeros: RecurrentZeros,
    rnnCell: rnnCell,
    Regression: Regression,
    regression: regression,
    Relu: Relu,
    relu: relu$1,
    Sigmoid: Sigmoid,
    sigmoid: sigmoid$1,
    SoftMax: SoftMax,
    softMax: softMax,
    SVM: SVM,
    svm: svm,
    Tanh: Tanh,
    tanh: tanh$1,
    Target: Target,
    target: target,
    Transpose: Transpose,
    transpose: transpose,
    Zeros: Zeros,
    zeros: zeros
});

const layerNameTypes = Object.keys(layer);
function layerFromJSON(jsonLayer, inputLayer1, inputLayer2) {
    if (!layerNameTypes.find((layerNameType) => layerNameType === jsonLayer.type)) {
        return null;
    }
    const Layer = layer[jsonLayer.type];
    if (Layer.prototype instanceof layerTypes.Filter) {
        if (!inputLayer1)
            throw new Error('inputLayer missing');
        return new Layer(jsonLayer, inputLayer1);
    }
    else if (Layer.prototype instanceof layerTypes.Activation ||
        Layer.prototype instanceof layerTypes.Modifier) {
        if (!inputLayer1)
            throw new Error('inputLayer missing');
        return new Layer(inputLayer1, jsonLayer);
    }
    else if (Layer.prototype instanceof layerTypes.Internal) {
        return new Layer(jsonLayer);
    }
    else if (Layer.prototype instanceof layerTypes.Operator) {
        if (!inputLayer1)
            throw new Error('inputLayer1 missing');
        if (!inputLayer2)
            throw new Error('inputLayer2 missing');
        return new Layer(inputLayer1, inputLayer2, jsonLayer);
    }
    else if (Layer.prototype instanceof layerTypes.InternalModel ||
        Layer.prototype instanceof layerTypes.EntryPoint ||
        Layer.prototype instanceof layerTypes.Model) {
        return new Layer(jsonLayer);
    }
    else if (Layer === Target) {
        if (!inputLayer1)
            throw new Error('inputLayer missing');
        return new Layer(jsonLayer, inputLayer1);
    }
    return null;
}

class LookupTable {
    constructor(data, prop) {
        this.prop = null;
        this.table = {};
        this.length = 0;
        const table = this.table;
        if (prop) {
            this.prop = prop;
            for (let i = 0; i < data.length; i++) {
                const datum = data[i];
                const object = datum[prop];
                for (const p in object) {
                    if (!object.hasOwnProperty(p))
                        continue;
                    if (table.hasOwnProperty(p))
                        continue;
                    table[p] = this.length++;
                }
            }
        }
        else if (Array.isArray(data) && Array.isArray(data[0])) {
            for (let i = 0; i < data.length; i++) {
                const array = data[i];
                for (let j = 0; j < array.length; j++) {
                    const object = array[j];
                    for (const p in object) {
                        if (!object.hasOwnProperty(p))
                            continue;
                        if (table.hasOwnProperty(p))
                            continue;
                        table[p] = this.length++;
                    }
                }
            }
        }
        else {
            for (let i = 0; i < data.length; i++) {
                const object = data[i];
                for (const p in object) {
                    if (!object.hasOwnProperty(p))
                        continue;
                    if (table.hasOwnProperty(p))
                        continue;
                    table[p] = this.length++;
                }
            }
        }
    }
}

const defaults$3 = {
    learningRate: 0.3,
    binaryThresh: 0.5,
    initPraxis: (layerTemplate, settings) => {
        var _a;
        return momentumRootMeanSquaredPropagation(layerTemplate, (_a = layerTemplate.settings.praxisOpts) !== null && _a !== void 0 ? _a : settings);
    },
};
const trainDefaults$3 = {
    iterations: 20000,
    errorThresh: 0.005,
    log: false,
    logPeriod: 10,
    learningRate: 0.3,
    callbackPeriod: 10,
    errorCheckInterval: 100,
    timeout: Infinity,
};
class FeedForward {
    constructor(options = {}) {
        this.trainOpts = {};
        this.layers = null;
        this._inputLayer = null;
        this._hiddenLayers = null;
        this._outputLayer = null;
        this._model = null;
        this.meanSquaredError = null;
        this.inputLookup = null;
        this.inputLookupLength = null;
        this.outputLookup = null;
        this.outputLookupLength = null;
        this.options = { ...defaults$3, ...options };
        this._updateTrainingOptions({
            ...trainDefaults$3,
            ...options,
        });
    }
    static _validateTrainingOptions(options) {
        const { iterations, errorThresh, log, logPeriod, learningRate, callback, callbackPeriod, timeout, } = options;
        const validations = {
            iterations: () => typeof iterations === 'number' && iterations > 0,
            errorThresh: () => typeof errorThresh === 'number' && errorThresh > 0 && errorThresh < 1,
            log: () => typeof log === 'function' || typeof log === 'boolean',
            logPeriod: () => typeof logPeriod === 'number' && logPeriod > 0,
            learningRate: () => typeof learningRate === 'number' &&
                learningRate > 0 &&
                learningRate < 1,
            callback: () => typeof callback === 'function' || callback === null,
            callbackPeriod: () => typeof callbackPeriod === 'number' && callbackPeriod > 0,
            timeout: () => typeof timeout === 'number' && timeout > 0,
        };
        Object.keys(trainDefaults$3).forEach((key) => {
            if (validations.hasOwnProperty(key) && !validations[key]()) {
                const val = options[key];
                throw new Error(`[${key}, ${(val !== null && val !== void 0 ? val : 'undefined').toString()}] is out of normal training range, your network will probably not train.`);
            }
        });
    }
    /**
     * if a method is passed in method is used
     * if false passed in nothing is logged
     */
    _setLogMethod(log) {
        if (typeof log === 'function') {
            this.trainOpts.log = log;
        }
        else if (log) {
            // eslint-disable-next-line
            this.trainOpts.log = console.log;
        }
        else {
            this.trainOpts.log = false;
        }
    }
    _updateTrainingOptions(opts) {
        var _a;
        this.trainOpts = { ...trainDefaults$3, ...this.trainOpts, ...opts };
        FeedForward._validateTrainingOptions(this.trainOpts);
        this._setLogMethod((_a = opts.log) !== null && _a !== void 0 ? _a : this.trainOpts.log);
        const { callback, callbackPeriod, errorCheckInterval } = this.trainOpts;
        if (callback && callbackPeriod !== errorCheckInterval) {
            console.warn(`options.callbackPeriod with value of ${(callbackPeriod !== null && callbackPeriod !== void 0 ? callbackPeriod : 'undefined').toString()} does not match options.errorCheckInterval with value of ${(errorCheckInterval !== null && errorCheckInterval !== void 0 ? errorCheckInterval : 'undefined').toString()}, if logging error, it will repeat.  These values may need to match`);
        }
    }
    _connectOptionsLayers() {
        const { inputLayerIndex, outputLayerIndex, layers } = this.options;
        if (!layers)
            throw new Error('this.options.layers in unexpected state');
        if (typeof inputLayerIndex !== 'number')
            throw new Error('inputLayerIndex not a number');
        if (typeof outputLayerIndex !== 'number')
            throw new Error('inputLayerIndex not a number');
        const inputLayer = layers[inputLayerIndex];
        if (!inputLayer) {
            throw new Error('inputLayer not found in this.options.layers');
        }
        const outputLayer = layers[outputLayerIndex];
        if (!outputLayer) {
            throw new Error('outputLayer not found in this.options.layers');
        }
        this._inputLayer = inputLayer;
        this._hiddenLayers = layers.slice(inputLayerIndex, outputLayerIndex - inputLayerIndex);
        this._outputLayer = outputLayer;
        return layers;
    }
    _connectNewLayers() {
        const { inputLayer, outputLayer } = this.options;
        if (!inputLayer)
            throw new Error('inputLayer not defined');
        const layers = [];
        this._inputLayer = inputLayer();
        const hiddenLayers = this._connectHiddenLayers(this._inputLayer);
        if (!outputLayer)
            throw new Error('outputLayer not defined');
        this._outputLayer = outputLayer(hiddenLayers[hiddenLayers.length - 1], hiddenLayers.length);
        layers.push(this._inputLayer);
        layers.push(...hiddenLayers);
        layers.push(this._outputLayer);
        return flattenLayers(layers);
    }
    _connectHiddenLayers(previousLayer) {
        this._hiddenLayers = [];
        const result = [];
        const { hiddenLayers } = this.options;
        if (!hiddenLayers)
            throw new Error('hiddenLayers not defined');
        for (let i = 0; i < hiddenLayers.length; i++) {
            const hiddenLayer = hiddenLayers[i](previousLayer, i);
            result.push(hiddenLayer);
            this._hiddenLayers.push(hiddenLayer);
            previousLayer = hiddenLayer;
        }
        return result;
    }
    initialize() {
        this.layers = this.options.layers
            ? this._connectOptionsLayers()
            : this._connectNewLayers();
        this.initializeLayers(this.layers);
        this._model = this.layers.filter((l) => l instanceof Model);
    }
    initializeLayers(layers) {
        var _a, _b;
        for (let i = 0; i < layers.length; i++) {
            const layer = layers[i];
            // TODO: optimize for when training or just running
            layer.setupKernels(true);
            if (layer instanceof Model &&
                layer.praxis === null &&
                typeof this.options.initPraxis === 'function') {
                layer.praxis = this.options.initPraxis(layer, (_b = (_a = layer.settings.praxisOpts) !== null && _a !== void 0 ? _a : this.options.praxisOpts) !== null && _b !== void 0 ? _b : {});
                layer.praxis.setupKernels();
            }
        }
        const lastLayer = layers[layers.length - 1];
        this.meanSquaredError = new MeanSquaredError({
            width: lastLayer.width,
            height: lastLayer.height,
        });
    }
    run(input) {
        let typeSafeInput;
        if (Array.isArray(input) || input.buffer) {
            typeSafeInput = input;
        }
        else {
            if (this.inputLookup) {
                typeSafeInput = lookup.toArray(this.inputLookup, input, this.inputLookupLength);
            }
            else {
                throw new Error('input is incompatible with net');
            }
        }
        let output = this.runInput(typeSafeInput);
        if (output instanceof gpu_js.Texture) {
            output = output.toArray();
        }
        if (this.outputLookup) {
            return lookup.toObject(this.outputLookup, output);
        }
        return output;
    }
    runInput(input) {
        if (!this.layers)
            throw new Error('not initialized');
        this.layers[0].predict(input);
        for (let i = 1; i < this.layers.length; i++) {
            this.layers[i].predict();
        }
        return this.layers[this.layers.length - 1].weights;
    }
    train(data, options = {}) {
        const { preparedData, status, endTime } = this._prepTraining(data, options);
        let continueTicking = true;
        const calculateError = () => this._calculateTrainingError(preparedData);
        const trainPatters = () => this._trainPatterns(preparedData);
        while (continueTicking) {
            continueTicking = this._trainingTick(status, endTime, calculateError, trainPatters);
        }
        return status;
    }
    _trainingTick(status, endTime, calculateError, trainPatterns) {
        const { trainOpts } = this;
        if (status.iterations >= trainOpts.iterations ||
            status.error <= trainOpts.errorThresh ||
            Date.now() >= endTime) {
            return false;
        }
        if (typeof trainOpts.log === 'function' &&
            status.iterations % trainOpts.logPeriod === 0) {
            status.error = calculateError();
            trainOpts.log(`iterations: ${status.iterations}, training error: ${status.error}`);
        }
        else if (status.iterations % trainOpts.errorCheckInterval ===
            0) {
            status.error = calculateError();
        }
        else {
            trainPatterns();
        }
        if (trainOpts.callback &&
            status.iterations % trainOpts.callbackPeriod === 0) {
            trainOpts.callback(Object.assign(status));
        }
        status.iterations++;
        return true;
    }
    _prepTraining(data, options) {
        this._updateTrainingOptions(options);
        const formattedData = this.formatData(data);
        const endTime = this.trainOpts.timeout
            ? Date.now() + this.trainOpts.timeout
            : 0;
        const status = {
            error: 1,
            iterations: 0,
        };
        this.verifyIsInitialized();
        return {
            preparedData: this.transferData(formattedData),
            status,
            endTime,
        };
    }
    verifyIsInitialized() {
        if (!this._model) {
            this.initialize();
        }
    }
    _calculateTrainingError(preparedData) {
        let sum = new Float32Array([0]);
        const meanSquaredError = this.meanSquaredError;
        for (let i = 0; i < preparedData.length; ++i) {
            const prevSum = sum;
            const error = this._trainPattern(preparedData[i].input, preparedData[i].output, true);
            sum = meanSquaredError.add(sum, error);
            release(error);
            release(prevSum);
        }
        const result = meanSquaredError.divide(preparedData.length, sum);
        release(sum);
        if (result instanceof gpu_js.Texture) {
            const resultArray = result.toArray();
            release(result);
            return resultArray[0];
        }
        return result[0];
    }
    /**
     * @param data
     * @private
     */
    _trainPatterns(data) {
        for (let i = 0; i < data.length; ++i) {
            this._trainPattern(data[i].input, data[i].output, false);
        }
    }
    _trainPattern(input, target, logErrorRate) {
        var _a;
        // forward propagate
        this.runInput(input);
        // back propagate
        this._calculateDeltas(target);
        this.adjustWeights();
        if (logErrorRate) {
            if (!((_a = this._outputLayer) === null || _a === void 0 ? void 0 : _a.errors)) {
                throw new Error('outputLayer.errors not defined');
            }
            return this.meanSquaredError.calculate(this._outputLayer.errors);
        }
        return null;
    }
    _calculateDeltas(target) {
        const layers = this.layers;
        for (let i = layers.length - 1; i > -1; i--) {
            layers[i].compare(target);
        }
    }
    /**
     *
     */
    adjustWeights() {
        const _model = this._model;
        for (let i = 0; i < _model.length; i++) {
            _model[i].learn(this.trainOpts.learningRate);
        }
    }
    /**
     *
     * @param data
     * @returns {*}
     */
    formatData(data) {
        if (!Array.isArray(data)) {
            // turn stream datum into array
            const tmp = [];
            tmp.push(data);
            data = tmp;
        }
        // turn sparse hash input into arrays with 0s as filler
        const inputDatumCheck = data[0].input;
        let formattedData;
        if (Array.isArray(data) &&
            !Array.isArray(inputDatumCheck) &&
            !(inputDatumCheck instanceof Float32Array)) {
            if (!this.inputLookup) {
                const lookupTable = new LookupTable(data, 'input');
                this.inputLookup = lookupTable.table;
                this.inputLookupLength = lookupTable.length;
            }
            formattedData = data.map((datumParam) => {
                const array = lookup.toArray(this.inputLookup, datumParam.input, this.inputLookupLength);
                return { input: array };
            }, this);
        }
        else {
            formattedData = data;
        }
        const outputDatumCheck = data[0].output;
        if (!Array.isArray(outputDatumCheck) &&
            !(outputDatumCheck instanceof Float32Array)) {
            if (!this.outputLookup) {
                const lookupTable = new LookupTable(data, 'output');
                this.outputLookup = lookupTable.table;
                this.outputLookupLength = lookupTable.length;
            }
            formattedData = data.map((datumParam, index) => {
                const array = lookup.toArray(this.outputLookup, datumParam.output, this.inputLookupLength);
                return {
                    input: formattedData[index].input,
                    output: array,
                };
            }, this);
        }
        return formattedData;
    }
    transferData(formattedData) {
        const transferredData = new Array(formattedData.length);
        const transferInput = makeKernel(function (value) {
            return value[this.thread.x];
        }, {
            output: [formattedData[0].input.length],
            immutable: true,
        });
        const transferOutput = makeKernel(function (value) {
            return value[this.thread.x];
        }, {
            output: [formattedData[0].output.length],
            immutable: true,
        });
        for (let i = 0; i < formattedData.length; i++) {
            const formattedDatum = formattedData[i];
            transferredData[i] = {
                input: transferInput(formattedDatum.input),
                output: transferOutput(formattedDatum.output),
            };
        }
        return transferredData;
    }
    /**
     *
     * @param data
     * @returns {
     *  {
     *    error: number,
     *    misclasses: Array
     *  }
     * }
     */
    test() {
        throw new Error(`${this.constructor.name}-test is not yet implemented`);
    }
    /**
     *
     */
    toJSON() {
        var _a;
        if (!this.layers) {
            this.initialize();
        }
        if (!this._model ||
            !this.layers ||
            !this._inputLayer ||
            !this._hiddenLayers ||
            !this._outputLayer) {
            throw new Error('network is not initialized');
        }
        const jsonLayers = [];
        for (let i = 0; i < this.layers.length; i++) {
            const layer = this.layers[i];
            const jsonLayer = layer.toJSON();
            if (layer.hasOwnProperty('inputLayer')) {
                jsonLayer.inputLayerIndex = this.layers.indexOf(layer.inputLayer);
            }
            else if (layer.hasOwnProperty('inputLayer1') &&
                layer.hasOwnProperty('inputLayer2')) {
                jsonLayer.inputLayer1Index = this.layers.indexOf(layer.inputLayer1);
                jsonLayer.inputLayer2Index = this.layers.indexOf(layer.inputLayer2);
            }
            jsonLayers.push(jsonLayer);
        }
        return {
            type: this.constructor.name,
            sizes: (_a = this.options.sizes) !== null && _a !== void 0 ? _a : [this._inputLayer.height]
                .concat(this._hiddenLayers.map((l) => l.height))
                .concat([this._outputLayer.height]),
            outputLayerIndex: this.layers.indexOf(this._outputLayer),
            layers: jsonLayers,
            inputLayerIndex: this.layers.indexOf(this._inputLayer),
        };
    }
    static fromJSON(json, getLayer) {
        var _a, _b, _c, _d;
        const jsonLayers = json.layers;
        const layers = [];
        const inputLayer = getLayer
            ? (_a = layerFromJSON(jsonLayers[0])) !== null && _a !== void 0 ? _a : getLayer(jsonLayers[0]) : layerFromJSON(jsonLayers[0]);
        if (!inputLayer)
            throw new Error('unable to find layer');
        layers.push(inputLayer);
        for (let i = 1; i < jsonLayers.length; i++) {
            const jsonLayer = jsonLayers[i];
            if (typeof jsonLayer.inputLayerIndex === 'undefined' &&
                typeof jsonLayer.inputLayer1Index === 'undefined' &&
                typeof jsonLayer.inputLayer2Index === 'undefined') {
                const layer = getLayer
                    ? (_b = layerFromJSON(jsonLayer)) !== null && _b !== void 0 ? _b : getLayer(jsonLayer) : layerFromJSON(jsonLayer);
                if (!layer)
                    throw new Error('unable to find layer');
                layers.push(layer);
            }
            else if (typeof jsonLayer.inputLayerIndex === 'number') {
                const inputLayer = layers[jsonLayer.inputLayerIndex];
                if (!inputLayer) {
                    throw new Error('inputLayer1 not found');
                }
                const layer = getLayer
                    ? (_c = layerFromJSON(jsonLayer, inputLayer)) !== null && _c !== void 0 ? _c : getLayer(jsonLayer, inputLayer) : layerFromJSON(jsonLayer, inputLayer);
                if (!layer)
                    throw new Error('unable to find layer');
                layers.push(layer);
            }
            else {
                if (typeof jsonLayer.inputLayer1Index !== 'number') {
                    throw new Error('Cannot create network from provided JSON. inputLayer1Index not defined.');
                }
                if (typeof jsonLayer.inputLayer2Index !== 'number') {
                    throw new Error('Cannot create network from provided JSON. inputLayer2Index not defined.');
                }
                const inputLayer1 = layers[jsonLayer.inputLayer1Index];
                const inputLayer2 = layers[jsonLayer.inputLayer2Index];
                if (inputLayer1 === undefined)
                    throw new Error(`Cannot create network from provided JSON. layer of index ${jsonLayer.inputLayer1Index} not found.`);
                if (inputLayer2 === undefined)
                    throw new Error(`Cannot create network from provided JSON. layer of index ${jsonLayer.inputLayer2Index} not found.`);
                const layer = getLayer
                    ? (_d = layerFromJSON(jsonLayer, inputLayer1, inputLayer2)) !== null && _d !== void 0 ? _d : getLayer(jsonLayer, inputLayer1, inputLayer2) : layerFromJSON(jsonLayer, inputLayer1, inputLayer2);
                if (!layer)
                    throw new Error('unable to find layer');
                layers.push(layer);
            }
        }
        return new this({ ...json, layers });
    }
    /**
     *
     * @returns {Function}
     */
    toFunction() {
        throw new Error(`${this.constructor.name}-toFunction is not yet implemented`);
    }
    /**
     * This will create a TrainStream (WriteStream) for us to send the training data to.
     * @param opts training options
     * @returns {TrainStream|*}
     */
    createTrainStream() {
        throw new Error(`${this.constructor.name}-createTrainStream is not yet implemented`);
    }
}

function likely(input, net) {
    if (!net) {
        throw new TypeError(`Required parameter 'net' is of type ${typeof net}. Must be of type 'brain.NeuralNetwork'`);
    }
    const output = net.run(input);
    let maxProp = null;
    let maxValue = -1;
    Object.entries(output).forEach(([key, value]) => {
        if (typeof value !== 'undefined' &&
            typeof value === 'number' &&
            value > maxValue) {
            maxProp = key;
            maxValue = value;
        }
    });
    return maxProp;
}

var commonjsGlobal = typeof globalThis !== 'undefined' ? globalThis : typeof window !== 'undefined' ? window : typeof global !== 'undefined' ? global : typeof self !== 'undefined' ? self : {};

function createCommonjsModule(fn, basedir, module) {
	return module = {
		path: basedir,
		exports: {},
		require: function (path, base) {
			return commonjsRequire(path, (base === undefined || base === null) ? module.path : base);
		}
	}, fn(module, module.exports), module.exports;
}

function commonjsRequire () {
	throw new Error('Dynamic requires are not currently supported by @rollup/plugin-commonjs');
}

var thaw_1 = createCommonjsModule(function (module, exports) {
var __assign = (commonjsGlobal && commonjsGlobal.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.thaw = exports.Thaw = void 0;
/**
 * thaw an array of items
 */
var Thaw = /** @class */ (function () {
    function Thaw(items, options) {
        var _this = this;
        if (options === void 0) { options = {}; }
        var _a = __assign(__assign({}, Thaw.defaultSettings), options), each = _a.each, done = _a.done;
        this.i = 0;
        this.isStopped = false;
        this.items = items;
        this.options = options;
        this.tick = function () {
            if (_this.isStopped)
                return;
            _this.timeout = setTimeout(_this.tick, 0);
            if (Thaw.thawing)
                return;
            var item = _this.items[_this.i];
            if (_this.i >= _this.items.length) {
                if (done !== null) {
                    Thaw.thawing = true;
                    done();
                    Thaw.thawing = false;
                }
                _this.isStopped = true;
                clearTimeout(_this.timeout);
                return;
            }
            if (each !== null) {
                Thaw.thawing = true;
                each(item, _this.i);
                Thaw.thawing = false;
            }
            else if (item !== undefined) {
                item();
            }
            _this.i++;
        };
        Thaw.thaws.push(this);
        if (!options.delay) {
            this.tick();
        }
    }
    Object.defineProperty(Thaw, "isThawing", {
        /**
         * returns if Thaw.js is thawing
         */
        get: function () {
            return Thaw.thawing;
        },
        enumerable: false,
        configurable: true
    });
    /**
     * Stops all Thaw instances
     */
    Thaw.stopAll = function () {
        for (var i = 0; i < Thaw.thaws.length; i++) {
            Thaw.thaws[i].stop();
        }
    };
    /**
     * readies thaw to continue
     */
    Thaw.prototype.makeReady = function () {
        if (this.isStopped) {
            this.isStopped = false;
            return true;
        }
        return false;
    };
    /**
     * Adds an item to the end of this instance of Thaw and readies Thaw to process it
     */
    Thaw.prototype.add = function (item) {
        this.items.push(item);
        if (this.makeReady()) {
            this.tick();
        }
        return this;
    };
    /**
     * Inserts an item just after the current item being processed in Thaw and readies Thaw to process it
     */
    Thaw.prototype.insert = function (item) {
        this.items.splice(this.i, 0, item);
        if (this.makeReady()) {
            this.tick();
        }
        return this;
    };
    /**
     * Adds an Array to the end of this instance of Thaw and readies Thaw to process it
     */
    Thaw.prototype.addArray = function (items) {
        this.items = this.items.concat(items);
        if (this.makeReady()) {
            this.tick();
        }
        return this;
    };
    /**
     * Inserts an Array just after the current item being processed in Thaw and readies Thaw to process them
     */
    Thaw.prototype.insertArray = function (items) {
        var before = this.items.splice(0, this.i);
        var after = this.items;
        this.items = before.concat(items, after);
        if (this.makeReady()) {
            this.tick();
        }
        return this;
    };
    /**
     * Stops this instance of Thaw
     */
    Thaw.prototype.stop = function () {
        this.isStopped = true;
        clearTimeout(this.timeout);
        if (this.options.done) {
            this.options.done();
        }
        return this;
    };
    Thaw.thawing = false;
    Thaw.thaws = [];
    Thaw.defaultSettings = {
        each: null,
        done: null
    };
    return Thaw;
}());
exports.Thaw = Thaw;
/**
 * simple thaw
 */
function thaw(items, options) {
    return new Thaw(items, options);
}
exports.thaw = thaw;

});

var block = createCommonjsModule(function (module, exports) {
Object.defineProperty(exports, "__esModule", { value: true });
exports.Block = void 0;

var Block = /** @class */ (function () {
    function Block(options, count) {
        if (count === void 0) { count = 200; }
        this.index = 0;
        this.thaws = [];
        this.count = count;
        this.options = options;
    }
    /**
     * add an item to the end of items
     */
    Block.prototype.add = function (item) {
        var next = this.next();
        next.add(item);
        return this;
    };
    /**
     * add an Array to the end of items
     */
    Block.prototype.addArray = function (items) {
        var next = this.next();
        next.addArray(items);
        return this;
    };
    /**
     * insert an item into items @ current position
     */
    Block.prototype.insert = function (item) {
        var next = this.next();
        next.insert(item);
        return this;
    };
    /**
     * insert and array into items @ current position
     */
    Block.prototype.insertArray = function (items) {
        var next = this.next();
        next.insertArray(items);
        return this;
    };
    /**
     * Stops all thaws in this block
     */
    Block.prototype.stop = function () {
        for (var i = 0; i < this.thaws.length; i++) {
            this.thaws[i].stop();
        }
        return this;
    };
    /**
     * Get next available in block
     */
    Block.prototype.next = function () {
        var thaw;
        var thaws = this.thaws;
        if (thaws.length < this.count) {
            thaw = new thaw_1.Thaw([], this.options);
            thaws.push(thaw);
        }
        else {
            thaw = thaws[this.index] || null;
        }
        this.index++;
        if (this.index >= this.count) {
            this.index = 0;
        }
        return thaw;
    };
    return Block;
}());
exports.Block = Block;

});

var dist = createCommonjsModule(function (module, exports) {
Object.defineProperty(exports, "__esModule", { value: true });
exports.Block = exports.thaw = exports.Thaw = void 0;

Object.defineProperty(exports, "Thaw", { enumerable: true, get: function () { return thaw_1.Thaw; } });
Object.defineProperty(exports, "thaw", { enumerable: true, get: function () { return thaw_1.thaw; } });

Object.defineProperty(exports, "Block", { enumerable: true, get: function () { return block.Block; } });
if (typeof window !== 'undefined') {
    // @ts-ignore
    window.Thaw = thaw_1.Thaw;
    // @ts-ignore
    window.thaw = thaw_1.thaw;
    // @ts-ignore
    window.Thaw.Block = block.Block;
}

});

function arraysToFloat32Arrays(arrays) {
    const result = [];
    for (let i = 0; i < arrays.length; i++) {
        result.push(Float32Array.from(arrays[i]));
    }
    return result;
}
function inputOutputArraysToFloat32Arrays(input, output) {
    const result = [];
    for (let i = 0; i < input.length; i++) {
        result.push(Float32Array.from(input[i]));
    }
    for (let i = 0; i < output.length; i++) {
        result.push(Float32Array.from(output[i]));
    }
    return result;
}
function arrayToFloat32Arrays(array) {
    const result = [];
    for (let i = 0; i < array.length; i++) {
        result.push(Float32Array.from([array[i]]));
    }
    return result;
}
function inputOutputArrayToFloat32Arrays(input, output) {
    const result = [];
    for (let i = 0; i < input.length; i++) {
        result.push(Float32Array.from([input[i]]));
    }
    for (let i = 0; i < output.length; i++) {
        result.push(Float32Array.from([output[i]]));
    }
    return result;
}
function arrayToFloat32Array(array) {
    return Float32Array.from(array);
}
function inputOutputObjectsToFloat32Arrays(input, output, inputTable, outputTable, inputLength, outputLength) {
    const results = [];
    for (let i = 0; i < input.length; i++) {
        const object = input[i];
        const result = new Float32Array(inputLength);
        for (const p in object) {
            if (object.hasOwnProperty(p)) {
                result[inputTable[p]] = object[p];
            }
        }
        results.push(result);
    }
    for (let i = 0; i < output.length; i++) {
        const object = output[i];
        const result = new Float32Array(outputLength);
        for (const p in object) {
            if (object.hasOwnProperty(p)) {
                result[outputTable[p]] = object[p];
            }
        }
        results.push(result);
    }
    return results;
}
function objectToFloat32Arrays(object) {
    const result = [];
    for (const p in object) {
        if (!object.hasOwnProperty(p))
            continue;
        result.push(Float32Array.from([object[p]]));
    }
    return result;
}
function inputOutputObjectToFloat32Arrays(input, output) {
    const result = [];
    for (const p in input) {
        if (!input.hasOwnProperty(p))
            continue;
        result.push(Float32Array.from([input[p]]));
    }
    for (const p in output) {
        if (!output.hasOwnProperty(p))
            continue;
        result.push(Float32Array.from([output[p]]));
    }
    return result;
}
function objectToFloat32Array(object, table, length) {
    const result = new Float32Array(length);
    for (const p in object) {
        if (object.hasOwnProperty(p)) {
            result[table[p]] = object[p];
        }
    }
    return result;
}

function max(values) {
    if (Array.isArray(values) || values instanceof Float32Array) {
        return Math.max(...values);
    }
    else {
        return Math.max(...Object.values(values));
    }
}

function mse$1(errors) {
    // mean squared error
    let sum = 0;
    for (let i = 0; i < errors.length; i++) {
        sum += errors[i] ** 2;
    }
    return sum / errors.length;
}

function getTypedArrayFn(value, table) {
    if (value.buffer instanceof ArrayBuffer) {
        return null;
    }
    if (Array.isArray(value)) {
        return arrayToFloat32Array;
    }
    if (!table)
        throw new Error('table is not Object');
    const { length } = Object.keys(table);
    return (v) => {
        const array = new Float32Array(length);
        for (const p in table) {
            if (!table.hasOwnProperty(p))
                continue;
            array[table[p]] = v[p] || 0;
        }
        return array;
    };
}
function defaults$2() {
    return {
        inputSize: 0,
        outputSize: 0,
        binaryThresh: 0.5,
    };
}
function trainDefaults$2() {
    return {
        activation: 'sigmoid',
        iterations: 20000,
        errorThresh: 0.005,
        log: false,
        logPeriod: 10,
        leakyReluAlpha: 0.01,
        learningRate: 0.3,
        momentum: 0.1,
        callbackPeriod: 10,
        timeout: Infinity,
        beta1: 0.9,
        beta2: 0.999,
        epsilon: 1e-8,
    };
}
class NeuralNetwork {
    constructor(options = {}) {
        this.options = defaults$2();
        this.trainOpts = trainDefaults$2();
        this.sizes = [];
        this.outputLayer = -1;
        this.biases = [];
        this.weights = []; // weights for bias nodes
        this.outputs = [];
        // state for training
        this.deltas = [];
        this.changes = []; // for momentum
        this.errors = [];
        this.errorCheckInterval = 1;
        this.inputLookup = null;
        this.inputLookupLength = 0;
        this.outputLookup = null;
        this.outputLookupLength = 0;
        this._formatInput = null;
        this._formatOutput = null;
        this.runInput = (input) => {
            this.setActivation();
            return this.runInput(input);
        };
        this.calculateDeltas = (output) => {
            this.setActivation();
            return this.calculateDeltas(output);
        };
        // adam
        this.biasChangesLow = [];
        this.biasChangesHigh = [];
        this.changesLow = [];
        this.changesHigh = [];
        this.iterations = 0;
        this.options = { ...this.options, ...options };
        this.updateTrainingOptions(options);
        const { inputSize, hiddenLayers, outputSize } = this.options;
        if (inputSize && outputSize) {
            this.sizes = [inputSize].concat(hiddenLayers !== null && hiddenLayers !== void 0 ? hiddenLayers : []).concat([outputSize]);
        }
    }
    /**
     *
     * Expects this.sizes to have been set
     */
    initialize() {
        if (!this.sizes.length) {
            throw new Error('Sizes must be set before initializing');
        }
        this.outputLayer = this.sizes.length - 1;
        this.biases = new Array(this.outputLayer); // weights for bias nodes
        this.weights = new Array(this.outputLayer);
        this.outputs = new Array(this.outputLayer);
        // state for training
        this.deltas = new Array(this.outputLayer);
        this.changes = new Array(this.outputLayer); // for momentum
        this.errors = new Array(this.outputLayer);
        for (let layerIndex = 0; layerIndex <= this.outputLayer; layerIndex++) {
            const size = this.sizes[layerIndex];
            this.deltas[layerIndex] = zeros$1(size);
            this.errors[layerIndex] = zeros$1(size);
            this.outputs[layerIndex] = zeros$1(size);
            if (layerIndex > 0) {
                this.biases[layerIndex] = randos(size);
                this.weights[layerIndex] = new Array(size);
                this.changes[layerIndex] = new Array(size);
                for (let nodeIndex = 0; nodeIndex < size; nodeIndex++) {
                    const prevSize = this.sizes[layerIndex - 1];
                    this.weights[layerIndex][nodeIndex] = randos(prevSize);
                    this.changes[layerIndex][nodeIndex] = zeros$1(prevSize);
                }
            }
        }
        this.setActivation();
        if (this.trainOpts.praxis === 'adam') {
            this._setupAdam();
        }
    }
    setActivation(activation) {
        const value = activation !== null && activation !== void 0 ? activation : this.trainOpts.activation;
        switch (value) {
            case 'sigmoid':
                this.runInput = this._runInputSigmoid;
                this.calculateDeltas = this._calculateDeltasSigmoid;
                break;
            case 'relu':
                this.runInput = this._runInputRelu;
                this.calculateDeltas = this._calculateDeltasRelu;
                break;
            case 'leaky-relu':
                this.runInput = this._runInputLeakyRelu;
                this.calculateDeltas = this._calculateDeltasLeakyRelu;
                break;
            case 'tanh':
                this.runInput = this._runInputTanh;
                this.calculateDeltas = this._calculateDeltasTanh;
                break;
            default:
                throw new Error(`Unknown activation ${value}. Available activations are: 'sigmoid', 'relu', 'leaky-relu', 'tanh'`);
        }
    }
    get isRunnable() {
        return this.sizes.length > 0;
    }
    run(input) {
        if (!this.isRunnable) {
            throw new Error('network not runnable');
        }
        let formattedInput;
        if (this.inputLookup) {
            formattedInput = lookup.toArray(this.inputLookup, input, this.inputLookupLength);
        }
        else {
            formattedInput = input;
        }
        if (formattedInput.length !== this.sizes[0]) {
            throw new Error(`input is not in correct length of ${this.sizes[0]}`);
        }
        const output = this.runInput(formattedInput).slice(0);
        if (this.outputLookup) {
            return lookup.toObject(this.outputLookup, output);
        }
        return output;
    }
    _runInputSigmoid(input) {
        this.outputs[0] = input; // set output state of input layer
        let output = null;
        for (let layer = 1; layer <= this.outputLayer; layer++) {
            const activeLayer = this.sizes[layer];
            const activeWeights = this.weights[layer];
            const activeBiases = this.biases[layer];
            const activeOutputs = this.outputs[layer];
            for (let node = 0; node < activeLayer; node++) {
                const weights = activeWeights[node];
                let sum = activeBiases[node];
                for (let k = 0; k < weights.length; k++) {
                    sum += weights[k] * input[k];
                }
                // sigmoid
                activeOutputs[node] = 1 / (1 + Math.exp(-sum));
            }
            output = input = activeOutputs;
        }
        if (!output) {
            throw new Error('output was empty');
        }
        return output;
    }
    _runInputRelu(input) {
        this.outputs[0] = input; // set output state of input layer
        let output = null;
        for (let layer = 1; layer <= this.outputLayer; layer++) {
            const activeSize = this.sizes[layer];
            const activeWeights = this.weights[layer];
            const activeBiases = this.biases[layer];
            const activeOutputs = this.outputs[layer];
            for (let node = 0; node < activeSize; node++) {
                const weights = activeWeights[node];
                let sum = activeBiases[node];
                for (let k = 0; k < weights.length; k++) {
                    sum += weights[k] * input[k];
                }
                // relu
                activeOutputs[node] = sum < 0 ? 0 : sum;
            }
            output = input = activeOutputs;
        }
        if (!output) {
            throw new Error('output was empty');
        }
        return output;
    }
    _runInputLeakyRelu(input) {
        this.outputs[0] = input; // set output state of input layer
        const { leakyReluAlpha } = this.trainOpts;
        let output = null;
        for (let layer = 1; layer <= this.outputLayer; layer++) {
            const activeSize = this.sizes[layer];
            const activeWeights = this.weights[layer];
            const activeBiases = this.biases[layer];
            const activeOutputs = this.outputs[layer];
            for (let node = 0; node < activeSize; node++) {
                const weights = activeWeights[node];
                let sum = activeBiases[node];
                for (let k = 0; k < weights.length; k++) {
                    sum += weights[k] * input[k];
                }
                // leaky relu
                activeOutputs[node] = Math.max(sum, leakyReluAlpha * sum);
            }
            output = input = activeOutputs;
        }
        if (!output) {
            throw new Error('output was empty');
        }
        return output;
    }
    _runInputTanh(input) {
        this.outputs[0] = input; // set output state of input layer
        let output = null;
        for (let layer = 1; layer <= this.outputLayer; layer++) {
            const activeSize = this.sizes[layer];
            const activeWeights = this.weights[layer];
            const activeBiases = this.biases[layer];
            const activeOutputs = this.outputs[layer];
            for (let node = 0; node < activeSize; node++) {
                const weights = activeWeights[node];
                let sum = activeBiases[node];
                for (let k = 0; k < weights.length; k++) {
                    sum += weights[k] * input[k];
                }
                // tanh
                activeOutputs[node] = Math.tanh(sum);
            }
            output = input = activeOutputs;
        }
        if (!output) {
            throw new Error('output was empty');
        }
        return output;
    }
    /**
     *
     * Verifies network sizes are initialized
     * If they are not it will initialize them based off the data set.
     */
    verifyIsInitialized(preparedData) {
        if (this.sizes.length)
            return;
        this.sizes = [];
        this.sizes.push(preparedData[0].input.length);
        if (!this.options.hiddenLayers) {
            this.sizes.push(Math.max(3, Math.floor(preparedData[0].input.length / 2)));
        }
        else {
            this.options.hiddenLayers.forEach((size) => {
                this.sizes.push(size);
            });
        }
        this.sizes.push(preparedData[0].output.length);
        this.initialize();
    }
    updateTrainingOptions(trainOpts) {
        const merged = { ...this.trainOpts, ...trainOpts };
        this.validateTrainingOptions(merged);
        this.trainOpts = merged;
        this.setLogMethod(this.trainOpts.log);
    }
    validateTrainingOptions(options) {
        const validations = {
            activation: () => {
                return ['sigmoid', 'relu', 'leaky-relu', 'tanh'].includes(options.activation);
            },
            iterations: () => {
                const val = options.iterations;
                return typeof val === 'number' && val > 0;
            },
            errorThresh: () => {
                const val = options.errorThresh;
                return typeof val === 'number' && val > 0 && val < 1;
            },
            log: () => {
                const val = options.log;
                return typeof val === 'function' || typeof val === 'boolean';
            },
            logPeriod: () => {
                const val = options.logPeriod;
                return typeof val === 'number' && val > 0;
            },
            leakyReluAlpha: () => {
                const val = options.leakyReluAlpha;
                return typeof val === 'number' && val > 0 && val < 1;
            },
            learningRate: () => {
                const val = options.learningRate;
                return typeof val === 'number' && val > 0 && val < 1;
            },
            momentum: () => {
                const val = options.momentum;
                return typeof val === 'number' && val > 0 && val < 1;
            },
            callback: () => {
                const val = options.callback;
                return typeof val === 'function' || val === undefined;
            },
            callbackPeriod: () => {
                const val = options.callbackPeriod;
                return typeof val === 'number' && val > 0;
            },
            timeout: () => {
                const val = options.timeout;
                return typeof val === 'number' && val > 0;
            },
            praxis: () => {
                const val = options.praxis;
                return !val || val === 'adam';
            },
            beta1: () => {
                const val = options.beta1;
                return val > 0 && val < 1;
            },
            beta2: () => {
                const val = options.beta2;
                return val > 0 && val < 1;
            },
            epsilon: () => {
                const val = options.epsilon;
                return val > 0 && val < 1;
            },
        };
        for (const p in validations) {
            const v = options;
            if (!validations[p]()) {
                throw new Error(`[${p}, ${v[p]}] is out of normal training range, your network will probably not train.`);
            }
        }
    }
    /**
     *
     *  Gets JSON of trainOpts object
     *    NOTE: Activation is stored directly on JSON object and not in the training options
     */
    getTrainOptsJSON() {
        const { activation, iterations, errorThresh, log, logPeriod, leakyReluAlpha, learningRate, momentum, callbackPeriod, timeout, praxis, beta1, beta2, epsilon, } = this.trainOpts;
        return {
            activation,
            iterations,
            errorThresh,
            log: typeof log === 'function'
                ? true
                : typeof log === 'boolean'
                    ? log
                    : false,
            logPeriod,
            leakyReluAlpha,
            learningRate,
            momentum,
            callbackPeriod,
            timeout: timeout === Infinity ? 'Infinity' : timeout,
            praxis,
            beta1,
            beta2,
            epsilon,
        };
    }
    setLogMethod(log) {
        if (typeof log === 'function') {
            this.trainOpts.log = log;
        }
        else if (log) {
            this.trainOpts.log = this.logTrainingStatus;
        }
        else {
            this.trainOpts.log = false;
        }
    }
    logTrainingStatus(status) {
        console.log(`iterations: ${status.iterations}, training error: ${status.error}`);
    }
    calculateTrainingError(data) {
        let sum = 0;
        for (let i = 0; i < data.length; ++i) {
            sum += this.trainPattern(data[i], true);
        }
        return sum / data.length;
    }
    trainPatterns(data) {
        for (let i = 0; i < data.length; ++i) {
            this.trainPattern(data[i]);
        }
    }
    trainingTick(data, status, endTime) {
        const { callback, callbackPeriod, errorThresh, iterations, log, logPeriod, } = this.trainOpts;
        if (status.iterations >= iterations ||
            status.error <= errorThresh ||
            Date.now() >= endTime) {
            return false;
        }
        status.iterations++;
        if (log && status.iterations % logPeriod === 0) {
            status.error = this.calculateTrainingError(data);
            log(status);
        }
        else if (status.iterations % this.errorCheckInterval === 0) {
            status.error = this.calculateTrainingError(data);
        }
        else {
            this.trainPatterns(data);
        }
        if (callback && status.iterations % callbackPeriod === 0) {
            callback({
                iterations: status.iterations,
                error: status.error,
            });
        }
        return true;
    }
    prepTraining(data, options = {}) {
        this.updateTrainingOptions(options);
        const preparedData = this.formatData(data);
        const endTime = Date.now() + this.trainOpts.timeout;
        const status = {
            error: 1,
            iterations: 0,
        };
        this.verifyIsInitialized(preparedData);
        return {
            preparedData,
            status,
            endTime,
        };
    }
    train(data, options = {}) {
        const { preparedData, status, endTime } = this.prepTraining(data, options);
        while (true) {
            if (!this.trainingTick(preparedData, status, endTime)) {
                break;
            }
        }
        return status;
    }
    async trainAsync(data, options = {}) {
        const { preparedData, status, endTime } = this.prepTraining(data, options);
        return await new Promise((resolve, reject) => {
            try {
                const thawedTrain = new dist.Thaw(new Array(this.trainOpts.iterations), {
                    delay: true,
                    each: () => this.trainingTick(preparedData, status, endTime) ||
                        thawedTrain.stop(),
                    done: () => resolve(status),
                });
                thawedTrain.tick();
            }
            catch (trainError) {
                reject(trainError);
            }
        });
    }
    trainPattern(value, logErrorRate) {
        // forward propagate
        this.runInput(value.input);
        // back propagate
        this.calculateDeltas(value.output);
        this.adjustWeights();
        if (logErrorRate) {
            return mse$1(this.errors[this.outputLayer]);
        }
        return null;
    }
    _calculateDeltasSigmoid(target) {
        for (let layer = this.outputLayer; layer >= 0; layer--) {
            const activeSize = this.sizes[layer];
            const activeOutput = this.outputs[layer];
            const activeError = this.errors[layer];
            const activeDeltas = this.deltas[layer];
            const nextLayer = this.weights[layer + 1];
            for (let node = 0; node < activeSize; node++) {
                const output = activeOutput[node];
                let error = 0;
                if (layer === this.outputLayer) {
                    error = target[node] - output;
                }
                else {
                    const deltas = this.deltas[layer + 1];
                    for (let k = 0; k < deltas.length; k++) {
                        error += deltas[k] * nextLayer[k][node];
                    }
                }
                activeError[node] = error;
                activeDeltas[node] = error * output * (1 - output);
            }
        }
    }
    _calculateDeltasRelu(target) {
        for (let layer = this.outputLayer; layer >= 0; layer--) {
            const currentSize = this.sizes[layer];
            const currentOutputs = this.outputs[layer];
            const nextWeights = this.weights[layer + 1];
            const nextDeltas = this.deltas[layer + 1];
            const currentErrors = this.errors[layer];
            const currentDeltas = this.deltas[layer];
            for (let node = 0; node < currentSize; node++) {
                const output = currentOutputs[node];
                let error = 0;
                if (layer === this.outputLayer) {
                    error = target[node] - output;
                }
                else {
                    for (let k = 0; k < nextDeltas.length; k++) {
                        error += nextDeltas[k] * nextWeights[k][node];
                    }
                }
                currentErrors[node] = error;
                currentDeltas[node] = output > 0 ? error : 0;
            }
        }
    }
    _calculateDeltasLeakyRelu(target) {
        const alpha = this.trainOpts.leakyReluAlpha;
        for (let layer = this.outputLayer; layer >= 0; layer--) {
            const currentSize = this.sizes[layer];
            const currentOutputs = this.outputs[layer];
            const nextDeltas = this.deltas[layer + 1];
            const nextWeights = this.weights[layer + 1];
            const currentErrors = this.errors[layer];
            const currentDeltas = this.deltas[layer];
            for (let node = 0; node < currentSize; node++) {
                const output = currentOutputs[node];
                let error = 0;
                if (layer === this.outputLayer) {
                    error = target[node] - output;
                }
                else {
                    for (let k = 0; k < nextDeltas.length; k++) {
                        error += nextDeltas[k] * nextWeights[k][node];
                    }
                }
                currentErrors[node] = error;
                currentDeltas[node] = output > 0 ? error : alpha * error;
            }
        }
    }
    _calculateDeltasTanh(target) {
        for (let layer = this.outputLayer; layer >= 0; layer--) {
            const currentSize = this.sizes[layer];
            const currentOutputs = this.outputs[layer];
            const nextDeltas = this.deltas[layer + 1];
            const nextWeights = this.weights[layer + 1];
            const currentErrors = this.errors[layer];
            const currentDeltas = this.deltas[layer];
            for (let node = 0; node < currentSize; node++) {
                const output = currentOutputs[node];
                let error = 0;
                if (layer === this.outputLayer) {
                    error = target[node] - output;
                }
                else {
                    for (let k = 0; k < nextDeltas.length; k++) {
                        error += nextDeltas[k] * nextWeights[k][node];
                    }
                }
                currentErrors[node] = error;
                currentDeltas[node] = (1 - output * output) * error;
            }
        }
    }
    /**
     *
     * Changes weights of networks
     */
    adjustWeights() {
        const { learningRate, momentum } = this.trainOpts;
        for (let layer = 1; layer <= this.outputLayer; layer++) {
            const incoming = this.outputs[layer - 1];
            const activeSize = this.sizes[layer];
            const activeDelta = this.deltas[layer];
            const activeChanges = this.changes[layer];
            const activeWeights = this.weights[layer];
            const activeBiases = this.biases[layer];
            for (let node = 0; node < activeSize; node++) {
                const delta = activeDelta[node];
                for (let k = 0; k < incoming.length; k++) {
                    let change = activeChanges[node][k];
                    change = learningRate * delta * incoming[k] + momentum * change;
                    activeChanges[node][k] = change;
                    activeWeights[node][k] += change;
                }
                activeBiases[node] += learningRate * delta;
            }
        }
    }
    _setupAdam() {
        this.biasChangesLow = [];
        this.biasChangesHigh = [];
        this.changesLow = [];
        this.changesHigh = [];
        this.iterations = 0;
        for (let layer = 0; layer <= this.outputLayer; layer++) {
            const size = this.sizes[layer];
            if (layer > 0) {
                this.biasChangesLow[layer] = zeros$1(size);
                this.biasChangesHigh[layer] = zeros$1(size);
                this.changesLow[layer] = new Array(size);
                this.changesHigh[layer] = new Array(size);
                for (let node = 0; node < size; node++) {
                    const prevSize = this.sizes[layer - 1];
                    this.changesLow[layer][node] = zeros$1(prevSize);
                    this.changesHigh[layer][node] = zeros$1(prevSize);
                }
            }
        }
        this.adjustWeights = this._adjustWeightsAdam;
    }
    _adjustWeightsAdam() {
        this.iterations++;
        const { iterations } = this;
        const { beta1, beta2, epsilon, learningRate } = this.trainOpts;
        for (let layer = 1; layer <= this.outputLayer; layer++) {
            const incoming = this.outputs[layer - 1];
            const currentSize = this.sizes[layer];
            const currentDeltas = this.deltas[layer];
            const currentChangesLow = this.changesLow[layer];
            const currentChangesHigh = this.changesHigh[layer];
            const currentWeights = this.weights[layer];
            const currentBiases = this.biases[layer];
            const currentBiasChangesLow = this.biasChangesLow[layer];
            const currentBiasChangesHigh = this.biasChangesHigh[layer];
            for (let node = 0; node < currentSize; node++) {
                const delta = currentDeltas[node];
                for (let k = 0; k < incoming.length; k++) {
                    const gradient = delta * incoming[k];
                    const changeLow = currentChangesLow[node][k] * beta1 + (1 - beta1) * gradient;
                    const changeHigh = currentChangesHigh[node][k] * beta2 +
                        (1 - beta2) * gradient * gradient;
                    const momentumCorrection = changeLow / (1 - Math.pow(beta1, iterations));
                    const gradientCorrection = changeHigh / (1 - Math.pow(beta2, iterations));
                    currentChangesLow[node][k] = changeLow;
                    currentChangesHigh[node][k] = changeHigh;
                    currentWeights[node][k] +=
                        (learningRate * momentumCorrection) /
                            (Math.sqrt(gradientCorrection) + epsilon);
                }
                const biasGradient = currentDeltas[node];
                const biasChangeLow = currentBiasChangesLow[node] * beta1 + (1 - beta1) * biasGradient;
                const biasChangeHigh = currentBiasChangesHigh[node] * beta2 +
                    (1 - beta2) * biasGradient * biasGradient;
                const biasMomentumCorrection = currentBiasChangesLow[node] / (1 - Math.pow(beta1, iterations));
                const biasGradientCorrection = currentBiasChangesHigh[node] / (1 - Math.pow(beta2, iterations));
                currentBiasChangesLow[node] = biasChangeLow;
                currentBiasChangesHigh[node] = biasChangeHigh;
                currentBiases[node] +=
                    (learningRate * biasMomentumCorrection) /
                        (Math.sqrt(biasGradientCorrection) + epsilon);
            }
        }
    }
    formatData(data) {
        if (!Array.isArray(data[0].input)) {
            if (this.inputLookup) {
                this.inputLookupLength = Object.keys(this.inputLookup).length;
            }
            else {
                const inputLookup = new LookupTable(data, 'input');
                this.inputLookup = inputLookup.table;
                this.inputLookupLength = inputLookup.length;
            }
        }
        if (!Array.isArray(data[0].output)) {
            if (this.outputLookup) {
                this.outputLookupLength = Object.keys(this.outputLookup).length;
            }
            else {
                const lookup = new LookupTable(data, 'output');
                this.outputLookup = lookup.table;
                this.outputLookupLength = lookup.length;
            }
        }
        if (!this._formatInput) {
            this._formatInput = getTypedArrayFn(data[0].input, this.inputLookup);
        }
        if (!this._formatOutput) {
            this._formatOutput = getTypedArrayFn(data[0].output, this.outputLookup);
        }
        // turn sparse hash input into arrays with 0s as filler
        if (this._formatInput && this._formatOutput) {
            const result = [];
            for (let i = 0; i < data.length; i++) {
                result.push({
                    input: this._formatInput(data[i].input),
                    output: this._formatOutput(data[i].output),
                });
            }
            return result;
        }
        if (this._formatInput) {
            const result = [];
            for (let i = 0; i < data.length; i++) {
                result.push({
                    input: this._formatInput(data[i].input),
                    output: data[i].output,
                });
            }
            return result;
        }
        if (this._formatOutput) {
            const result = [];
            for (let i = 0; i < data.length; i++) {
                result.push({
                    input: data[i].input,
                    output: this._formatOutput(data[i].output),
                });
            }
            return result;
        }
        return data;
    }
    addFormat(data) {
        var _a, _b;
        if (!Array.isArray(data.input) || typeof data.input[0] !== 'number') {
            this.inputLookup = lookup.addKeys(data.input, (_a = this.inputLookup) !== null && _a !== void 0 ? _a : {});
            if (this.inputLookup) {
                this.inputLookupLength = Object.keys(this.inputLookup).length;
            }
        }
        if (!Array.isArray(data.output) || typeof data.output[0] !== 'number') {
            this.outputLookup = lookup.addKeys(data.output, (_b = this.outputLookup) !== null && _b !== void 0 ? _b : {});
            if (this.outputLookup) {
                this.outputLookupLength = Object.keys(this.outputLookup).length;
            }
        }
    }
    test(data) {
        const { preparedData } = this.prepTraining(data);
        // for binary classification problems with one output node
        const isBinary = preparedData[0].output.length === 1;
        // for classification problems
        const misclasses = [];
        // run each pattern through the trained network and collect
        // error and misclassification statistics
        let errorSum = 0;
        if (isBinary) {
            let falsePos = 0;
            let falseNeg = 0;
            let truePos = 0;
            let trueNeg = 0;
            for (let i = 0; i < preparedData.length; i++) {
                const output = this.runInput(preparedData[i].input);
                const target = preparedData[i].output;
                const actual = output[0] > this.options.binaryThresh ? 1 : 0;
                const expected = target[0];
                if (actual !== expected) {
                    const misclass = preparedData[i];
                    misclasses.push({
                        input: misclass.input,
                        output: misclass.output,
                        actual,
                        expected,
                    });
                }
                if (actual === 0 && expected === 0) {
                    trueNeg++;
                }
                else if (actual === 1 && expected === 1) {
                    truePos++;
                }
                else if (actual === 0 && expected === 1) {
                    falseNeg++;
                }
                else if (actual === 1 && expected === 0) {
                    falsePos++;
                }
                errorSum += mse$1(output.map((value, i) => {
                    return target[i] - value;
                }));
            }
            return {
                error: errorSum / preparedData.length,
                misclasses,
                total: preparedData.length,
                trueNeg,
                truePos,
                falseNeg,
                falsePos,
                precision: truePos > 0 ? truePos / (truePos + falsePos) : 0,
                recall: truePos > 0 ? truePos / (truePos + falseNeg) : 0,
                accuracy: (trueNeg + truePos) / preparedData.length,
            };
        }
        for (let i = 0; i < preparedData.length; i++) {
            const output = this.runInput(preparedData[i].input);
            const target = preparedData[i].output;
            const actual = output.indexOf(max(output));
            const expected = target.indexOf(max(target));
            if (actual !== expected) {
                const misclass = preparedData[i];
                misclasses.push({
                    input: misclass.input,
                    output: misclass.output,
                    actual,
                    expected,
                });
            }
            errorSum += mse$1(output.map((value, i) => {
                return target[i] - value;
            }));
        }
        return {
            error: errorSum / preparedData.length,
            misclasses,
            total: preparedData.length,
        };
    }
    toJSON() {
        var _a, _b;
        if (!this.isRunnable) {
            this.initialize();
        }
        // use Array.from, keeping json small
        const jsonLayerWeights = this.weights.map((layerWeights) => {
            return layerWeights.map((layerWeights) => Array.from(layerWeights));
        });
        const jsonLayerBiases = this.biases.map((layerBiases) => Array.from(layerBiases));
        const jsonLayers = [];
        const outputLength = this.sizes.length - 1;
        for (let i = 0; i <= outputLength; i++) {
            jsonLayers.push({
                weights: (_a = jsonLayerWeights[i]) !== null && _a !== void 0 ? _a : [],
                biases: (_b = jsonLayerBiases[i]) !== null && _b !== void 0 ? _b : [],
            });
        }
        return {
            type: 'NeuralNetwork',
            sizes: [...this.sizes],
            layers: jsonLayers,
            inputLookup: this.inputLookup ? { ...this.inputLookup } : null,
            inputLookupLength: this.inputLookupLength,
            outputLookup: this.outputLookup ? { ...this.outputLookup } : null,
            outputLookupLength: this.outputLookupLength,
            options: { ...this.options },
            trainOpts: this.getTrainOptsJSON(),
        };
    }
    fromJSON(json) {
        this.options = { ...defaults$2(), ...json.options };
        if (json.hasOwnProperty('trainOpts')) {
            const trainOpts = {
                ...json.trainOpts,
                timeout: json.trainOpts.timeout === 'Infinity'
                    ? Infinity
                    : json.trainOpts.timeout,
            };
            this.updateTrainingOptions(trainOpts);
        }
        this.sizes = json.sizes;
        this.initialize();
        this.inputLookup = json.inputLookup ? { ...json.inputLookup } : null;
        this.inputLookupLength = json.inputLookupLength;
        this.outputLookup = json.outputLookup ? { ...json.outputLookup } : null;
        this.outputLookupLength = json.outputLookupLength;
        const jsonLayers = json.layers;
        const layerWeights = this.weights.map((layerWeights, layerIndex) => {
            return jsonLayers[layerIndex].weights.map((layerWeights) => Float32Array.from(layerWeights));
        });
        const layerBiases = this.biases.map((layerBiases, layerIndex) => Float32Array.from(jsonLayers[layerIndex].biases));
        for (let i = 0; i <= this.outputLayer; i++) {
            this.weights[i] = layerWeights[i] || [];
            this.biases[i] = layerBiases[i] || [];
        }
        return this;
    }
    toFunction(cb) {
        const { activation, leakyReluAlpha } = this.trainOpts;
        let needsVar = false;
        const nodeHandle = (layerIndex, nodeIndex) => {
            if (layerIndex === 0) {
                return `(input[${nodeIndex}]||0)`;
            }
            const weights = this.weights[layerIndex][nodeIndex];
            const bias = this.biases[layerIndex][nodeIndex];
            if (!weights) {
                throw new Error(`weights at layerIndex ${layerIndex} & nodeIndex ${nodeIndex} not found`);
            }
            if (!bias) {
                throw new Error(`bias as layerIndex ${layerIndex} & nodeIndex ${nodeIndex} not found`);
            }
            const weightsArray = [];
            weights.forEach((weight, subNodeIndex) => {
                if (weight < 0) {
                    weightsArray.push(`${weight}*${nodeHandle(layerIndex - 1, subNodeIndex)}`);
                }
                else {
                    weightsArray.push(`+${weight}*${nodeHandle(layerIndex - 1, subNodeIndex)}`);
                }
            });
            const result = `(${bias.toString()}${weightsArray.join('')})`;
            switch (activation) {
                case 'sigmoid':
                    return `1/(1+1/Math.exp(${result}))`;
                case 'relu': {
                    needsVar = true;
                    return `((v=${result})<0?0:v)`;
                }
                case 'leaky-relu': {
                    needsVar = true;
                    return `Math.max((v=${result}),${leakyReluAlpha}*v)`;
                }
                case 'tanh':
                    return `Math.tanh(${result})`;
                default:
                    throw new Error(`Unknown activation ${activation}. Available activations are: 'sigmoid', 'relu', 'leaky-relu', 'tanh'`);
            }
        };
        function checkKeys(keys) {
            if (keys.find((v) => v.includes('"'))) {
                throw new Error(`key contains '"', which is not compatible`);
            }
        }
        const layersAsMath = [];
        let result;
        let inputLookup = '';
        if (this.inputLookup) {
            const keys = Object.keys(this.inputLookup);
            checkKeys(keys);
            inputLookup = `input = new Float32Array([${Object.keys(this.inputLookup)
                .map((key) => `input["${key}"]`)
                .join(',')}]);`;
        }
        if (this.sizes.length < 1)
            throw new Error('No layers');
        for (let nodeIndex = 0; nodeIndex < this.sizes[this.outputLayer]; nodeIndex++) {
            layersAsMath.push(nodeHandle(this.outputLayer, nodeIndex));
        }
        if (this.outputLookup) {
            const keys = Object.keys(this.outputLookup);
            checkKeys(keys);
            const values = keys
                .map((key, i) => `"${key}":${layersAsMath[i]}`)
                .join(',');
            result = `{${values}}`;
        }
        else {
            result = `[${layersAsMath.join(',')}]`;
        }
        const source = `${inputLookup}${needsVar ? 'var v;' : ''}return ${result};`;
        // eslint-disable-next-line @typescript-eslint/no-implied-eval,no-new-func
        return new Function('input', cb ? cb(source) : source);
    }
}

function weightedSumSigmoid(weights, biases, inputs) {
    let sum = biases[this.thread.x];
    for (let k = 0; k < this.constants.size; k++) {
        sum += weights[this.thread.x][k] * inputs[k];
    }
    // sigmoid
    return 1 / (1 + Math.exp(-sum));
}
function weightedSumRelu(weights, biases, inputs) {
    let sum = biases[this.thread.x];
    for (let k = 0; k < this.constants.size; k++) {
        sum += weights[this.thread.x][k] * inputs[k];
    }
    // relu
    return sum < 0 ? 0 : sum;
}
function weightedSumLeakyRelu(weights, biases, inputs) {
    let sum = biases[this.thread.x];
    for (let k = 0; k < this.constants.size; k++) {
        sum += weights[this.thread.x][k] * inputs[k];
    }
    // leaky relu
    return sum < 0 ? 0 : 0.01 * sum;
}
function weightedSumTanh(weights, biases, inputs) {
    let sum = biases[this.thread.x];
    for (let k = 0; k < this.constants.size; k++) {
        sum += weights[this.thread.x][k] * inputs[k];
    }
    // tanh
    return Math.tanh(sum);
}
function calcErrorOutput(output, target) {
    return target - output;
}
function calcDeltasSigmoid(error, output) {
    // sigmoid derivative
    return error * output * (1 - output);
}
function calcDeltasRelu(error, output) {
    // relu derivative
    return output > 0 ? error : 0;
}
function calcDeltasLeakyRelu(error, output) {
    // leaky relu derivative
    return output > 0 ? error : 0.01 * error;
}
function calcDeltasTanh(error, output) {
    // tanh derivative
    return (1 - output * output) * error;
}
function calcError(x, size, nextWeights, nextDeltas) {
    let error = 0;
    for (let k = 0; k < size; k++) {
        error += nextDeltas[k] * nextWeights[k][x];
    }
    return error;
}
function calcChanges(learningRate, momentum, previousChange, delta, previousOutput) {
    return learningRate * delta * previousOutput + momentum * previousChange;
}
function addWeights(change, weight) {
    return change + weight;
}
function addBiases(biases, deltas) {
    return (biases[this.thread.x] + deltas[this.thread.x] * this.constants.learningRate);
}
// mean squared error, reimplemented for GPU
function mse(errors) {
    let sum = 0;
    for (let i = 0; i < this.constants.size; i++) {
        sum += errors[i] ** 2;
    }
    return sum / this.constants.size;
}
class NeuralNetworkGPU extends NeuralNetwork {
    constructor(options = {}) {
        super(options);
        this.texturizeInputData = () => {
            throw new Error('not yet setup');
        };
        this.forwardPropagate = [];
        this.backwardPropagate = [];
        this.changesPropagate = [];
        this.biasesPropagate = [];
        this.getMSE = () => {
            throw new Error('not yet setup');
        };
        this._addMSE = () => {
            throw new Error('not yet setup');
        };
        this._divideMSESum = () => {
            throw new Error('not yet setup');
        };
        // eslint-disable-next-line @typescript-eslint/ban-ts-comment
        // @ts-expect-error
        this.outputs = [];
        // eslint-disable-next-line @typescript-eslint/ban-ts-comment
        // @ts-expect-error
        this.deltas = [];
        // eslint-disable-next-line @typescript-eslint/ban-ts-comment
        // @ts-expect-error
        this.errors = [];
        // eslint-disable-next-line @typescript-eslint/ban-ts-comment
        // @ts-expect-error
        this.weights = [];
        // eslint-disable-next-line @typescript-eslint/ban-ts-comment
        // @ts-expect-error
        this.changes = [];
        // eslint-disable-next-line @typescript-eslint/ban-ts-comment
        // @ts-expect-error
        this.biases = [];
        // eslint-disable-next-line @typescript-eslint/ban-ts-comment
        // @ts-expect-error
        this.runInput = (input) => {
            let output;
            this.outputs[0] = input;
            for (let layer = 1; layer <= this.outputLayer; layer++) {
                release(this.outputs[layer]);
                this.outputs[layer] = this.forwardPropagate[layer](this.weights[layer], this.biases[layer], input);
                output = input = this.outputs[layer];
            }
            return output;
        };
        this.calculateDeltas = (target) => {
            for (let layer = this.outputLayer; layer > 0; layer--) {
                release(this.deltas[layer]);
                release(this.errors[layer]);
                let output;
                if (layer === this.outputLayer) {
                    // eslint-disable-next-line @typescript-eslint/ban-ts-comment
                    // @ts-expect-error
                    output = this.backwardPropagate[layer](this.outputs[layer], target);
                }
                else {
                    // eslint-disable-next-line @typescript-eslint/ban-ts-comment
                    // @ts-expect-error
                    output = this.backwardPropagate[layer](this.weights[layer + 1], this.outputs[layer], this.deltas[layer + 1]);
                }
                this.deltas[layer] = output.result;
                this.errors[layer] = output.error;
            }
        };
        this.errorCheckInterval = 100;
        this.gpu = new gpu_js.GPU({ mode: options.mode });
    }
    initialize() {
        super.initialize();
        this.buildRunInput();
        this.buildCalculateDeltas();
        this.buildGetChanges();
        this.buildChangeBiases();
        this.buildGetMSE();
    }
    setActivation() { }
    // eslint-disable-next-line @typescript-eslint/ban-ts-comment
    // @ts-expect-error
    trainPattern(value, logErrorRate) {
        // forward propagate
        this.runInput(value.input);
        // back propagate
        this.calculateDeltas(value.output);
        this.adjustWeights();
        if (logErrorRate) {
            return this.getMSE(this.errors[this.outputLayer]);
        }
        return null;
    }
    calculateTrainingError(data) {
        let sum = new Float32Array([0]);
        for (let i = 0; i < data.length; ++i) {
            const prevSum = sum;
            const error = this.trainPattern(data[i], true);
            sum = this._addMSE(sum, error);
            release(error);
            release(prevSum);
        }
        const result = this._divideMSESum(data.length, sum);
        release(sum);
        return (result instanceof gpu_js.Texture
            ? result.toArray()
            : result)[0];
    }
    adjustWeights() {
        this.getChanges();
        this.changeBiases();
    }
    buildRunInput() {
        let weightedSum = null;
        switch (this.trainOpts.activation) {
            case 'sigmoid':
                weightedSum = weightedSumSigmoid;
                break;
            case 'relu':
                weightedSum = weightedSumRelu;
                break;
            case 'leaky-relu':
                weightedSum = weightedSumLeakyRelu;
                break;
            case 'tanh':
                weightedSum = weightedSumTanh;
                break;
            default:
                throw new Error(`Unknown activation ${this.trainOpts.activation}. Available activations are: 'sigmoid', 'relu', 'leaky-relu', 'tanh'`);
        }
        for (let layer = 1; layer <= this.outputLayer; layer++) {
            this.forwardPropagate[layer] = this.gpu.createKernel(weightedSum, {
                output: [this.sizes[layer]],
                pipeline: true,
                constants: {
                    size: this.sizes[layer - 1],
                },
                immutable: true,
            });
        }
        this.texturizeInputData = this.gpu.createKernel(function (value) {
            return value[this.thread.x];
        }, {
            output: [this.sizes[1]],
            pipeline: true,
            immutable: true,
        });
    }
    buildCalculateDeltas() {
        let calcDeltas;
        switch (this.trainOpts.activation) {
            case 'sigmoid':
                calcDeltas = calcDeltasSigmoid;
                break;
            case 'relu':
                calcDeltas = calcDeltasRelu;
                break;
            case 'leaky-relu':
                calcDeltas = calcDeltasLeakyRelu;
                break;
            case 'tanh':
                calcDeltas = calcDeltasTanh;
                break;
            default:
                throw new Error(`Unknown activation ${this.trainOpts.activation}. Available activations are: 'sigmoid', 'relu', 'leaky-relu', 'tanh'`);
        }
        calcDeltas = gpu_js.alias(gpu_js.utils.getMinifySafeName(() => calcDeltas), calcDeltas);
        this.gpu.addFunction(calcDeltas);
        for (let layer = this.outputLayer; layer > 0; layer--) {
            if (layer === this.outputLayer) {
                // eslint-disable-next-line @typescript-eslint/ban-ts-comment
                // @ts-expect-error
                this.backwardPropagate[this.outputLayer] = this.gpu.createKernelMap({
                    error: calcErrorOutput,
                }, function (outputs, targets) {
                    const output = outputs[this.thread.x];
                    const target = targets[this.thread.x];
                    // eslint-disable-next-line @typescript-eslint/ban-ts-comment
                    // @ts-expect-error
                    return calcDeltas(calcErrorOutput(output, target), output);
                }, {
                    output: [this.sizes[this.outputLayer]],
                    pipeline: true,
                    immutable: true,
                });
            }
            else {
                // eslint-disable-next-line @typescript-eslint/ban-ts-comment
                // @ts-expect-error
                this.backwardPropagate[layer] = this.gpu.createKernelMap({
                    error: calcError,
                }, function (nextWeights, outputs, nextDeltas) {
                    const output = outputs[this.thread.x];
                    // eslint-disable-next-line @typescript-eslint/ban-ts-comment
                    // @ts-expect-error
                    return calcDeltas(calcError(this.thread.x, this.constants.size, nextWeights, nextDeltas), output);
                }, {
                    output: [this.sizes[layer]],
                    pipeline: true,
                    constants: {
                        size: this.sizes[layer + 1],
                    },
                    immutable: true,
                });
            }
        }
    }
    buildGetChanges() {
        for (let layer = 1; layer <= this.outputLayer; layer++) {
            // eslint-disable-next-line @typescript-eslint/ban-ts-comment
            // @ts-expect-error
            this.changesPropagate[layer] = this.gpu.createKernelMap({
                weights: addWeights,
                changes: calcChanges,
            }, function (previousOutputs, deltas, weights, previousChanges) {
                const change = calcChanges(this.constants.learningRate, this.constants.momentum, previousChanges[this.thread.y][this.thread.x], deltas[this.thread.y], previousOutputs[this.thread.x]);
                return addWeights(change, weights[this.thread.y][this.thread.x]);
            }, {
                output: [this.sizes[layer - 1], this.sizes[layer]],
                pipeline: true,
                constants: {
                    size: this.sizes[layer - 1],
                    learningRate: this.trainOpts.learningRate,
                    momentum: this.trainOpts.momentum,
                },
                immutable: true,
            });
        }
    }
    getChanges() {
        for (let layer = 1; layer <= this.outputLayer; layer++) {
            const weights = this.weights[layer];
            const changes = this.changes[layer];
            const output = this.changesPropagate[layer](this.outputs[layer - 1], this.deltas[layer], weights, changes);
            release(weights);
            release(changes);
            this.weights[layer] = output.weights;
            this.changes[layer] = output.changes;
            release(output.result);
        }
    }
    buildChangeBiases() {
        for (let layer = 1; layer <= this.outputLayer; layer++) {
            this.biasesPropagate[layer] = this.gpu.createKernel(addBiases, {
                output: [this.sizes[layer]],
                pipeline: true,
                constants: {
                    learningRate: this.trainOpts.learningRate,
                },
                immutable: true,
            });
        }
    }
    changeBiases() {
        for (let layer = 1; layer <= this.outputLayer; layer++) {
            const biases = this.biases[layer];
            this.biases[layer] = this.biasesPropagate[layer](biases, this.deltas[layer]);
            release(biases);
        }
    }
    buildGetMSE() {
        this.getMSE = this.gpu.createKernel(mse, {
            output: [1],
            constants: {
                size: this.sizes[this.outputLayer],
            },
            pipeline: true,
            immutable: true,
        });
        this._addMSE = this.gpu.createKernel(function (value1, value2) {
            return value1[0] + value2[0];
        }, {
            output: [1],
            pipeline: true,
            immutable: true,
        });
        this._divideMSESum = this.gpu.createKernel(function (length, mseSum) {
            const value = mseSum[0];
            if (value > 0) {
                return value / length;
            }
            return 0;
        }, {
            output: [1],
        });
    }
    run(input) {
        if (!this.isRunnable) {
            throw new Error('network not runnable');
        }
        let formattedInput;
        if (this.inputLookup) {
            formattedInput = lookup.toArray(this.inputLookup, input, this.inputLookupLength);
        }
        else {
            formattedInput = input;
        }
        const outputTextures = this.runInput(formattedInput);
        const output = outputTextures instanceof gpu_js.Texture
            ? outputTextures.toArray()
            : outputTextures;
        if (this.outputLookup) {
            return lookup.toObject(this.outputLookup, output);
        }
        return output;
    }
    // @ts-expect-error the underlying network works as normal, but we are working on the GPU
    prepTraining(data, options = {}) {
        this.updateTrainingOptions(options);
        const preparedData = this.formatData(data);
        const endTime = Date.now() + this.trainOpts.timeout;
        const status = {
            error: 1,
            iterations: 0,
        };
        this.verifyIsInitialized(preparedData);
        const texturizeOutputData = this.gpu.createKernel(function (value) {
            return value[this.thread.x];
        }, {
            output: [preparedData[0].output.length],
            pipeline: true,
            immutable: true,
        });
        return {
            preparedData: preparedData.map((set) => ({
                input: this.texturizeInputData(set.input),
                output: texturizeOutputData(set.output),
            })),
            status,
            endTime,
        };
    }
    // eslint-disable-next-line @typescript-eslint/ban-ts-comment
    // @ts-expect-error
    toFunction() {
        throw new Error(`${this.constructor.name}-toFunction is not yet implemented`);
    }
    toJSON() {
        var _a, _b;
        if (this.sizes === null) {
            this.initialize();
        }
        // use Array.from, keeping json small
        const jsonLayerWeights = this.weights.map((layerWeights) => {
            return (layerWeights instanceof gpu_js.Texture
                ? layerWeights.toArray()
                : layerWeights).map((layerWeights) => Array.from(layerWeights));
        });
        const jsonLayerBiases = this.biases.map((layerBiases) => Array.from(layerBiases instanceof gpu_js.Texture
            ? layerBiases.toArray()
            : layerBiases));
        const jsonLayers = [];
        for (let i = 0; i <= this.outputLayer; i++) {
            jsonLayers.push({
                weights: (_a = jsonLayerWeights[i]) !== null && _a !== void 0 ? _a : [],
                biases: (_b = jsonLayerBiases[i]) !== null && _b !== void 0 ? _b : [],
            });
        }
        return {
            type: 'NeuralNetworkGPU',
            sizes: [...this.sizes],
            layers: jsonLayers,
            inputLookup: this.inputLookup ? { ...this.inputLookup } : null,
            inputLookupLength: this.inputLookupLength,
            outputLookup: this.outputLookup ? { ...this.outputLookup } : null,
            outputLookupLength: this.outputLookupLength,
            options: { ...this.options },
            trainOpts: this.getTrainOptsJSON(),
        };
    }
}

class RecurrentConnection extends Internal {
    constructor() {
        super(...arguments);
        this.settings = {};
        this.layer = null;
    }
    setLayer(layer) {
        this.layer = layer;
    }
    get width() {
        if (!this.layer)
            throw new Error('layer not set');
        return this.layer.width;
    }
    set width(value) {
        throw new Error(`${this.constructor.name}-width is not yet implemented`);
    }
    get height() {
        if (!this.layer)
            throw new Error('layer not set');
        return this.layer.height;
    }
    set height(value) {
        throw new Error(`${this.constructor.name}-height is not yet implemented`);
    }
    get deltas() {
        if (!this.layer)
            throw new Error('layer not set');
        return this.layer.deltas;
    }
    set deltas(deltas) {
        if (!this.layer)
            throw new Error('layer not set');
        release(this.layer.deltas);
        this.layer.deltas = deltas;
    }
    get weights() {
        if (!this.layer)
            throw new Error('layer not set');
        return this.layer.weights;
    }
    set weights(weights) {
        if (!this.layer)
            throw new Error('layer not set');
        release(this.layer.weights);
        this.layer.weights = weights;
    }
    predict() {
        // throw new Error(`${this.constructor.name}-predict is not yet implemented`)
    }
    compare() {
        // throw new Error(`${this.constructor.name}-compare is not yet implemented`)
    }
    learn() {
        throw new Error('no longer using');
    }
    setupKernels() {
        // throw new Error(
        //   `${this.constructor.name}-setupKernels is not yet implemented`
        // )
    }
    reuseKernels() {
        // throw new Error(
        //   `${this.constructor.name}-reuseKernels is not yet implemented`
        // )
    }
}

class Recurrent extends FeedForward {
    // TODO: use generics in extend
    constructor(options = {}) {
        // eslint-disable-next-line @typescript-eslint/ban-ts-comment
        // @ts-expect-error
        super(options);
        this.trainOpts = {};
        this._outputConnection = null;
        this._layerSets = [];
        this._hiddenLayerOutputIndices = [];
        this._model = null;
    }
    _connectLayers() {
        if (!this.options.inputLayer) {
            throw new Error('inputLayer not found');
        }
        if (!this.options.outputLayer) {
            throw new Error('outputLayer not found');
        }
        const inputLayer = this.options.inputLayer();
        const hiddenLayers = this._connectHiddenLayers(inputLayer);
        const outputLayer = this.options.outputLayer(hiddenLayers[hiddenLayers.length - 1], -1);
        return {
            inputLayer,
            hiddenLayers,
            outputLayer,
        };
    }
    _connectLayersDeep() {
        const layers = [];
        const previousLayers = this._layerSets[this._layerSets.length - 1];
        let usedHiddenLayerOutputIndex = 0;
        function findInputLayer(inputLayer) {
            const index = previousLayers.indexOf(inputLayer);
            if (index < 0)
                throw new Error('unable to find layer');
            return layers[index];
        }
        function layerSettings(layer) {
            return {
                ...layer.settings,
                weights: null,
                deltas: null,
                praxis: null,
            };
        }
        for (let i = 0; i < previousLayers.length; i++) {
            const previousLayer = previousLayers[i];
            let layer;
            if (previousLayer instanceof Activation) {
                layer = new previousLayer.constructor(findInputLayer(previousLayer.inputLayer), layerSettings(previousLayer));
            }
            else if (previousLayer instanceof EntryPoint) {
                layer = new previousLayer.constructor(layerSettings(previousLayer));
            }
            else if (previousLayer instanceof Filter) {
                layer = new previousLayer.constructor(layerSettings(previousLayer.inputLayer), findInputLayer(previousLayer.inputLayer));
            }
            else if (previousLayer instanceof Internal) {
                const previousHiddenLayerOutput = previousLayers[this._hiddenLayerOutputIndices[usedHiddenLayerOutputIndex++]];
                if (previousLayer instanceof RecurrentConnection) {
                    throw new Error('unfinished');
                }
                else if (previousLayer instanceof RecurrentInput) {
                    layer = new RecurrentInput(previousHiddenLayerOutput);
                }
                else if (previousLayer instanceof RecurrentZeros) {
                    layer = new RecurrentInput(previousHiddenLayerOutput);
                }
                else {
                    throw new Error(`hidden layer ${previousLayer.constructor.name} extends unknown hidden layer`);
                }
            }
            else if (previousLayer instanceof InternalModel ||
                previousLayer instanceof Model) {
                layer = previousLayer;
            }
            else if (previousLayer instanceof Modifier) {
                layer = new previousLayer.constructor(findInputLayer(previousLayer.inputLayer), layerSettings(previousLayer.inputLayer));
            }
            else if (previousLayer instanceof Operator) {
                layer = new previousLayer.constructor(findInputLayer(previousLayer.inputLayer1), findInputLayer(previousLayer.inputLayer2), layerSettings(previousLayer));
            }
            else if (previousLayer instanceof Target) {
                layer = new previousLayer.constructor(layerSettings(previousLayer), findInputLayer(previousLayer.inputLayer));
            }
            else {
                throw new Error(`hidden layer ${previousLayer.constructor.name} extends unknown hidden layer`);
            }
            layers.push(layer);
        }
        return layers;
    }
    _connectHiddenLayers(previousLayer) {
        const hiddenLayers = [];
        if (!this.options.hiddenLayers)
            throw new Error('hiddenLayers not defined');
        for (let i = 0; i < this.options.hiddenLayers.length; i++) {
            const recurrentInput = new RecurrentZeros();
            const hiddenLayer = this.options.hiddenLayers[i](previousLayer, recurrentInput, i);
            previousLayer = hiddenLayer;
            hiddenLayers.push(hiddenLayer);
        }
        return hiddenLayers;
    }
    initialize() {
        this._outputConnection = new RecurrentConnection();
        let layerSet;
        if (this.options.layers) {
            layerSet = this._connectOptionsLayers();
        }
        else {
            const { inputLayer, hiddenLayers, outputLayer } = this._connectLayers();
            layerSet = flattenLayers([inputLayer, ...hiddenLayers, outputLayer]);
            this._hiddenLayerOutputIndices = hiddenLayers.map((l) => layerSet.indexOf(l));
            this._inputLayer = inputLayer;
            this._hiddenLayers = hiddenLayers;
            this._outputLayer = outputLayer;
        }
        this.layers = layerSet;
        this._layerSets = [layerSet];
        this._model = layerSet.filter((l) => l instanceof Model || l instanceof InternalModel);
        this.initializeLayers(layerSet);
    }
    initializeDeep() {
        const layers = this._connectLayersDeep();
        for (let i = 0; i < layers.length; i++) {
            const layer = layers[i];
            layer.setupKernels(true);
            // TODO: enable this?
            // layer.reuseKernels(this._layerSets[0][i]);
        }
        this._layerSets.push(layers);
    }
    // eslint-disable-next-line @typescript-eslint/ban-ts-comment
    // @ts-expect-error
    run(inputs) {
        while (this._layerSets.length <= inputs.length) {
            this.initializeDeep();
        }
        const result = this.runInputs(inputs);
        if (result instanceof gpu_js.Texture)
            return result.toArray();
        return result;
    }
    runInput(input) {
        throw new Error('use .runInputs()');
    }
    runInputs(inputs) {
        while (this._layerSets.length < inputs.length) {
            this.initializeDeep();
        }
        const max = inputs.length - 1; // last output will be compared with last index
        for (let x = 0; x <= max; x++) {
            const layerSet = this._layerSets[x];
            layerSet[0].predict(inputs[x]);
            for (let i = 1; i < layerSet.length; i++) {
                layerSet[i].predict();
            }
        }
        const lastLayerUsed = this._layerSets[max];
        const result = lastLayerUsed[lastLayerUsed.length - 1].weights;
        this.end();
        return result;
    }
    // eslint-disable-next-line @typescript-eslint/ban-ts-comment
    // @ts-expect-error
    train(data, options = {}) {
        const { preparedData, status, endTime } = this._prepTraining(data, options);
        let continueTicking = true;
        const calculateError = () => this._calculateTrainingError(preparedData);
        const trainPatters = () => this._trainPatterns(preparedData);
        while (continueTicking) {
            continueTicking = this._trainingTick(status, endTime, calculateError, trainPatters);
        }
        return status;
    }
    end() {
        const x = this._layerSets.length - 1;
        const lastLayerSet = this._layerSets[x];
        lastLayerSet[0].predict([new Float32Array([0])]);
        for (let i = 1; i < lastLayerSet.length; i++) {
            lastLayerSet[i].predict();
        }
    }
    // eslint-disable-next-line @typescript-eslint/ban-ts-comment
    // @ts-expect-error
    transferData(formattedData) {
        return formattedData;
    }
    // eslint-disable-next-line @typescript-eslint/ban-ts-comment
    // @ts-expect-error
    _prepTraining(data, options) {
        this._updateTrainingOptions(options);
        const endTime = this.trainOpts.timeout
            ? Date.now() + this.trainOpts.timeout
            : 0;
        const status = {
            error: 1,
            iterations: 0,
        };
        this.verifyIsInitialized();
        return {
            preparedData: this.transferData(data),
            status,
            endTime,
        };
    }
    // eslint-disable-next-line @typescript-eslint/ban-ts-comment
    // @ts-expect-error
    _calculateTrainingError(data) {
        if (!this.meanSquaredError) {
            throw new Error('this.meanSquaredError not setup');
        }
        let sum = new Float32Array(1);
        for (let i = 0; i < data.length; ++i) {
            const prevSum = sum;
            const error = this._trainPattern(data[i], true);
            sum = this.meanSquaredError.add(sum, error);
            release(error);
            release(prevSum);
        }
        const result = this.meanSquaredError.divide(data.length, sum);
        release(sum);
        if (result instanceof gpu_js.Texture) {
            const resultArray = result.toArray();
            return resultArray[0];
        }
        return result[0];
    }
    // TODO: more types
    // eslint-disable-next-line @typescript-eslint/ban-ts-comment
    // @ts-expect-error
    formatData(data) {
        return data;
    }
    // eslint-disable-next-line @typescript-eslint/ban-ts-comment
    // @ts-expect-error
    _calculateDeltas(target) {
        const lastLayerSet = this._layerSets[this._layerSets.length - 1];
        // Iterate from the second to last layer backwards, propagating 0's
        for (let i = lastLayerSet.length - 2; i >= 0; i--) {
            lastLayerSet[i].compare();
        }
        for (let x = target.length - 2; x >= 0; x--) {
            const layerSet = this._layerSets[x];
            layerSet[layerSet.length - 1].compare(target[x + 1]);
            for (let i = layerSet.length - 2; i >= 0; i--) {
                layerSet[i].compare();
            }
        }
    }
    adjustWeights() {
        var _a;
        const _model = this._model;
        for (let i = 0; i < _model.length; i++) {
            _model[i].learn((_a = this.options.learningRate) !== null && _a !== void 0 ? _a : 0);
        }
    }
    // eslint-disable-next-line @typescript-eslint/ban-ts-comment
    // @ts-expect-error
    _trainPatterns(data) {
        for (let i = 0; i < data.length; ++i) {
            this._trainPattern(data[i], false);
        }
    }
    // eslint-disable-next-line @typescript-eslint/ban-ts-comment
    // @ts-expect-error
    _trainPattern(inputs, logErrorRate) {
        // forward propagate
        this.runInputs(inputs);
        // back propagate
        this._calculateDeltas(inputs);
        this.adjustWeights();
        if (logErrorRate) {
            if (!this.meanSquaredError) {
                throw new Error('this.meanSquaredError not setup');
            }
            let error = new Float32Array(1);
            for (let i = 0, max = inputs.length - 1; i <= max; i++) {
                const layerSet = this._layerSets[i];
                const lastLayer = layerSet[layerSet.length - 1];
                const prevError = error;
                error = this.meanSquaredError.addAbsolute(prevError, lastLayer.errors);
                release(prevError);
            }
            return clone(this.meanSquaredError.divide(inputs.length, error));
        }
        return null;
    }
}

/**
 * A matrix
 */
class Matrix {
    constructor(rows, columns) {
        this.rows = 0;
        this.columns = 0;
        if (rows)
            this.rows = rows;
        if (columns)
            this.columns = columns;
        this.weights = zeros$1(this.rows * this.columns);
        this.deltas = zeros$1(this.rows * this.columns);
    }
    getWeight(row, col) {
        // slow but careful accessor function
        // we want row-major order
        const ix = this.columns * row + col;
        if (ix < 0 || ix >= this.weights.length) {
            throw new Error('get accessor is skewed');
        }
        return this.weights[ix];
    }
    setWeight(row, col, v) {
        // slow but careful accessor function
        const ix = this.columns * row + col;
        if (ix < 0 || ix >= this.weights.length) {
            throw new Error('set accessor is skewed');
        }
        this.weights[ix] = v;
        return this;
    }
    getDelta(row, col) {
        // slow but careful accessor function
        // we want row-major order
        const ix = this.columns * row + col;
        if (ix < 0 || ix >= this.deltas.length) {
            throw new Error('get accessor is skewed');
        }
        return this.deltas[ix];
    }
    setDelta(row, col, v) {
        // slow but careful accessor function
        const ix = this.columns * row + col;
        if (ix < 0 || ix >= this.weights.length) {
            throw new Error('set accessor is skewed');
        }
        this.deltas[ix] = v;
        return this;
    }
    toJSON() {
        return {
            rows: this.rows,
            columns: this.columns,
            weights: Array.from(this.weights.slice(0)),
        };
    }
    static fromJSON(json) {
        const matrix = new Matrix(json.rows, json.columns);
        for (let i = 0, max = json.rows * json.columns; i < max; i++) {
            matrix.weights[i] = json.weights[i]; // copy over weights
        }
        return matrix;
    }
    static fromArray(weights) {
        const matrix = new Matrix(weights.length, weights[0].length);
        matrix.fromArray(weights);
        return matrix;
    }
    deltasToArray() {
        return this.toArray('deltas');
    }
    weightsToArray() {
        return this.toArray('weights');
    }
    toArray(prop = 'weights') {
        const result = new Array(this.rows);
        this.iterate({
            row: (rowIndex) => {
                result[rowIndex] = new Array(this.columns);
            },
            column: (rowIndex, columnIndex) => {
                if (prop === 'weights') {
                    result[rowIndex][columnIndex] = this.getWeight(rowIndex, columnIndex);
                }
                else if (prop === 'deltas') {
                    result[rowIndex][columnIndex] = this.getDelta(rowIndex, columnIndex);
                }
            },
        });
        return result;
    }
    fromArray(array, prop = 'weights') {
        if (array.length !== this.rows) {
            throw new Error('rows do not match');
        }
        if (array[0].length !== this.columns) {
            throw new Error('columns do not match');
        }
        this.iterate({
            column: (rowIndex, columnIndex) => {
                const value = array[rowIndex][columnIndex];
                if (typeof value !== 'number') {
                    throw new Error('value not number');
                }
                if (prop === 'weights') {
                    this.setWeight(rowIndex, columnIndex, value);
                }
                else if (prop === 'deltas') {
                    this.setDelta(rowIndex, columnIndex, value);
                }
            },
        });
        return this;
    }
    iterate(callbacks) {
        const rows = this.rows;
        const columns = this.columns;
        for (let rowIndex = 0; rowIndex < rows; rowIndex++) {
            if (callbacks.row) {
                callbacks.row(rowIndex);
            }
            for (let columnIndex = 0; columnIndex < columns; columnIndex++) {
                if (callbacks.column) {
                    callbacks.column(rowIndex, columnIndex);
                }
            }
        }
        return this;
    }
}

/** return Matrix but filled with random numbers from gaussian
 */
class RandomMatrix extends Matrix {
    constructor(rows, columns, std) {
        super(rows, columns);
        this.std = std;
        for (let i = 0, max = this.weights.length; i < max; i++) {
            this.weights[i] = randomFloat(-std, std);
        }
    }
}

class DataFormatter {
    constructor(values, maxThreshold = 0) {
        this.values = values;
        this.indexTable = {};
        this.characterTable = {};
        this.characters = [];
        this.specialIndexes = [];
        this.isSetup = false;
        if (values === undefined)
            return;
        this.setup(values, maxThreshold);
    }
    setup(values, maxThreshold = 0) {
        if (this.isSetup)
            throw new Error('DataFormatter is already setup');
        this.values = values;
        // go over all characters and keep track of all unique ones seen
        // count up all characters
        this.buildCharactersFromIterable(values);
        this.buildTables(maxThreshold);
        if (values[0].input) {
            this.addInputOutput();
        }
        this.addUnrecognized();
        this.isSetup = true;
    }
    buildCharactersFromIterable(values) {
        const tempCharactersTable = {};
        for (let dataFormatterIndex = 0, dataFormatterLength = values.length; dataFormatterIndex < dataFormatterLength; dataFormatterIndex++) {
            const characters = values[dataFormatterIndex];
            // if (typeof characters === 'string') {
            //   const character = characters;
            //   if (tempCharactersTable.hasOwnProperty(character)) continue;
            //   tempCharactersTable[character] = true;
            //   this.characters.push(character);
            if (characters.hasOwnProperty('length')) {
                const iteratable = characters;
                for (let characterIndex = 0, charactersLength = iteratable.length; characterIndex < charactersLength; characterIndex++) {
                    const character = iteratable[characterIndex];
                    if (tempCharactersTable.hasOwnProperty(character))
                        continue;
                    tempCharactersTable[character] = true;
                    this.characters.push(character);
                }
            }
            else if (typeof characters === 'number') {
                if (tempCharactersTable.hasOwnProperty(characters))
                    continue;
                tempCharactersTable[characters] = true;
                this.characters.push(characters);
            }
            else if (typeof characters === 'boolean') {
                const character = characters.toString();
                if (tempCharactersTable.hasOwnProperty(character))
                    continue;
                tempCharactersTable[character] = true;
                this.characters.push(character);
            }
            else if (Array.isArray(characters) &&
                typeof characters[0] === 'string') {
                for (let i = 0; i < characters.length; i++) {
                    const character = characters[i];
                    if (tempCharactersTable.hasOwnProperty(character))
                        continue;
                    tempCharactersTable[character] = true;
                    this.characters.push(character);
                }
            }
            else if (Array.isArray(characters) &&
                (typeof characters[0] === 'number' ||
                    typeof characters[0] === 'boolean')) {
                for (let i = 0; i < characters.length; i++) {
                    const character = characters[i].toString();
                    if (tempCharactersTable.hasOwnProperty(dataFormatterIndex))
                        continue;
                    tempCharactersTable[character] = true;
                    this.characters.push(character);
                }
            }
            else if (characters.hasOwnProperty('input') &&
                characters.hasOwnProperty('output')) {
                const { input, output } = characters;
                if (Array.isArray(input)) {
                    this.addCharacters(input, tempCharactersTable);
                }
                else {
                    this.addCharacters(input.toString(), tempCharactersTable);
                }
                if (Array.isArray(output)) {
                    this.addCharacters(output, tempCharactersTable);
                }
                else {
                    this.addCharacters(output.toString(), tempCharactersTable);
                }
            }
            else {
                throw new Error('Unhandled value');
            }
        }
    }
    addCharacters(characters, charactersTable) {
        for (let i = 0; i < characters.length; i++) {
            const character = characters[i].toString();
            if (charactersTable.hasOwnProperty(character))
                continue;
            charactersTable[character] = true;
            this.characters.push(character);
        }
    }
    buildTables(maxThreshold) {
        // filter by count threshold and create pointers
        const charactersLength = this.characters.length;
        for (let characterIndex = 0; characterIndex < charactersLength; characterIndex++) {
            const character = this.characters[characterIndex];
            if (characterIndex >= maxThreshold) {
                // add character to dataFormatter
                this.indexTable[character] = characterIndex;
                this.characterTable[characterIndex] = character;
            }
        }
    }
    toIndexes(value, maxThreshold = 0) {
        const result = [];
        const { indexTable } = this;
        switch (typeof value) {
            case 'number':
            case 'boolean':
                value = value.toString();
        }
        for (let i = 0, max = value.length; i < max; i++) {
            const character = value[i].toString();
            let index = indexTable[character];
            if (index === undefined) {
                if (indexTable.unrecognized) {
                    index = indexTable.unrecognized;
                }
                else {
                    throw new Error(`unrecognized character "${character}"`);
                }
            }
            if (index < maxThreshold)
                continue;
            result.push(index);
        }
        return result;
    }
    toIndexesInputOutput(input, output, maxThreshold = 0) {
        const result = this.toIndexesValue(input, maxThreshold, true);
        if (typeof output === 'undefined')
            return result;
        return result.concat(this.toIndexesValue(output, maxThreshold, false));
    }
    toIndexesValue(value, maxThreshold, isInput) {
        if (typeof value === 'string') {
            value = value.split('');
        }
        else if (typeof value === 'number' || typeof value === 'boolean') {
            value = value.toString().split('');
        }
        else if (Array.isArray(value) &&
            (typeof value[0] === 'number' ||
                typeof value[0] === 'boolean' ||
                typeof value[0] === 'string')) {
            value = value.map((v) => v.toString());
        }
        else {
            throw new Error('unrecognized value');
        }
        if (isInput) {
            value = value.concat(['stop-input', 'start-output']);
        }
        return this.toIndexes(value, maxThreshold);
    }
    toCharacters(indices, maxThreshold = 0) {
        const result = [];
        const { indexTable, characterTable } = this;
        for (let i = 0, max = indices.length; i < max; i++) {
            const index = indices[i];
            if (index < maxThreshold)
                continue;
            let character = characterTable[index];
            if (character === undefined) {
                if (indexTable.unrecognized) {
                    character = characterTable[indexTable.unrecognized];
                }
                else {
                    throw new Error(`unrecognized index "${index}"`);
                }
            }
            else if (character !== null) {
                result.push(character.toString());
            }
        }
        return result;
    }
    toString(indices, maxThreshold) {
        return this.toCharacters(indices, maxThreshold).join('');
    }
    addInputOutput() {
        this.addSpecial('stop-input');
        this.addSpecial('start-output');
    }
    addUnrecognized() {
        this.addSpecial('unrecognized');
    }
    static fromAllPrintable(maxThreshold, values = ['\n']) {
        for (let i = 32; i <= 126; i++) {
            values.push(String.fromCharCode(i));
        }
        return new DataFormatter(values, maxThreshold);
    }
    static fromAllPrintableInputOutput(maxThreshold, values = ['\n']) {
        const dataFormatter = DataFormatter.fromAllPrintable(maxThreshold, values);
        dataFormatter.addInputOutput();
        dataFormatter.addUnrecognized();
        return dataFormatter;
    }
    static fromStringInputOutput(string, maxThreshold) {
        const values = Array.from(new Set(string)).join('');
        const dataFormatter = new DataFormatter(values.split(''), maxThreshold);
        dataFormatter.addInputOutput();
        dataFormatter.addUnrecognized();
        dataFormatter.isSetup = true;
        return dataFormatter;
    }
    static fromArrayInputOutput(data, maxThreshold) {
        const values = [];
        for (let i = 0; i < data.length; i++) {
            const datum = data[i];
            values.push(validateAndCast(datum.input), validateAndCast(datum.output));
        }
        const flatArray = Array.isArray(values)
            ? values.flat()
            : values;
        const dataFormatter = new DataFormatter(Array.from(new Set(flatArray)), maxThreshold);
        dataFormatter.addInputOutput();
        dataFormatter.addUnrecognized();
        dataFormatter.isSetup = true;
        return dataFormatter;
    }
    static fromString(string, maxThreshold = 0) {
        const values = Array.from(new Set(string)).join('');
        return new DataFormatter(values.split(''), maxThreshold);
    }
    toJSON() {
        return {
            indexTable: this.indexTable,
            characterTable: this.characterTable,
            values: this.values,
            characters: this.characters,
            specialIndexes: this.specialIndexes,
        };
    }
    /** TODO: Type better, The type of json is not "string that is a valid JSON", it is a POJO in the shape of DataFormatter.
     * this method re-hydrates the the data as an instance of DataFormatter.
     */
    static fromJSON(json) {
        const dataFormatter = new DataFormatter();
        dataFormatter.indexTable = json.indexTable;
        dataFormatter.characterTable = json.characterTable;
        dataFormatter.values = json.values;
        dataFormatter.characters = json.characters;
        dataFormatter.specialIndexes = json.specialIndexes;
        return dataFormatter;
    }
    addSpecial(special, character = null) {
        const specialIndex = (this.indexTable[special] = this.characters.length);
        this.characterTable[specialIndex] = character;
        this.specialIndexes.push(this.characters.length);
        this.characters.push(special);
    }
    toFunctionString() {
        return `
var characterTable = ${JSON.stringify(this.characterTable)};
var indexTable = ${JSON.stringify(this.indexTable)};
var characters = ${JSON.stringify(this.characters)};
var dataFormatter = {
  toIndexes: function ${this.toIndexes.toString()},
  toIndexesInputOutput: function ${this.toIndexesInputOutput.toString()},
  toCharacters: function ${this.toCharacters.toString()},
  toIndexesValue: function ${this.toIndexesValue.toString()},
};`;
    }
    formatDataIn(input, output) {
        var _a;
        if (input === undefined)
            return [];
        if (Array.isArray(input) && typeof input[0] === 'number') {
            return input;
        }
        if ((_a = this.indexTable) === null || _a === void 0 ? void 0 : _a.hasOwnProperty('stop-input')) {
            return this.toIndexesInputOutput(input, output);
        }
        return this.toIndexes(input);
    }
    formatDataOut(input, output) {
        return this.toCharacters(output).join('');
    }
    format(data) {
        if (typeof data[0] === 'number' &&
            !Array.isArray(data[0]) &&
            (!data[0].hasOwnProperty('input') || !data[0].hasOwnProperty('output'))) {
            return data;
        }
        const result = [];
        if (typeof data[0] === 'string' ||
            typeof data[0] === 'number' ||
            Array.isArray(data[0])) {
            if (!this.isSetup) {
                this.setup(data);
                for (let i = 0; i < data.length; i++) {
                    result.push(this.formatDataIn(validateAndCast(data[i])));
                }
            }
            else {
                for (let i = 0, max = data.length; i < max; i++) {
                    result.push(this.formatDataIn(data[i]));
                }
            }
        }
        else if (data[0].input && data[0].output) {
            if (!this.isSetup) {
                this.setup(data);
            }
            for (let i = 0, max = data.length; i < max; i++) {
                result.push(this.formatDataIn(validateAndCast(data[i].input), validateAndCast(data[i].output)));
            }
        }
        else {
            throw new Error('unrecognized data');
        }
        return result;
    }
}
function validateAndCast(value) {
    if (typeof value === 'string')
        return value;
    if (typeof value === 'number')
        return value.toString();
    if (typeof value === 'boolean')
        return value.toString();
    if (Array.isArray(value) && typeof value[0] === 'string')
        return value;
    if (typeof value[0] === 'boolean') {
        return value.map((v) => v.toString());
    }
    if (typeof value[0] === 'number') {
        return value.map((v) => v.toString());
    }
    throw new Error('unrecognized value, expected string[], string, number[], number, boolean[], or boolean');
}

function copy(product, left) {
    product.rows = left.rows;
    product.columns = left.columns;
    product.weights = left.weights.slice(0);
    product.deltas = left.deltas.slice(0);
}

/**
 * add {left} and {right} matrix weights into {into}
 */
function add(product, left, right) {
    for (let i = 0; i < left.weights.length; i++) {
        product.weights[i] = left.weights[i] + right.weights[i];
        product.deltas[i] = 0;
    }
}

/**
 * adds {from} deltas to {left} and {right} deltas
 */
function addB(product, left, right) {
    for (let i = 0; i < product.deltas.length; i++) {
        left.deltas[i] = product.deltas[i];
        right.deltas[i] = product.deltas[i];
    }
}

/**
 * makes matrix weights and deltas all ones
 */
function allOnes(product) {
    for (let i = 0; i < product.weights.length; i++) {
        product.weights[i] = 1;
        product.deltas[i] = 0;
    }
}

function cloneNegative(product, left) {
    product.rows = left.rows;
    product.columns = left.columns;
    product.weights = left.weights.slice(0);
    product.deltas = left.deltas.slice(0);
    for (let i = 0; i < left.weights.length; i++) {
        product.weights[i] = -left.weights[i];
        product.deltas[i] = 0;
    }
}

/**
 * multiply {left} and {right} matrix weights to {into}
 */
function multiply(product, left, right) {
    const leftRows = left.rows;
    const leftColumns = left.columns;
    const rightColumns = right.columns;
    // loop over rows of left
    for (let leftRow = 0; leftRow < leftRows; leftRow++) {
        const leftRowBase = leftColumns * leftRow;
        const rightRowBase = rightColumns * leftRow;
        // loop over cols of right
        for (let rightColumn = 0; rightColumn < rightColumns; rightColumn++) {
            // dot product loop
            let dot = 0;
            // loop over columns of left
            for (let leftColumn = 0; leftColumn < leftColumns; leftColumn++) {
                const rightColumnBase = rightColumns * leftColumn;
                const leftIndex = leftRowBase + leftColumn;
                const rightIndex = rightColumnBase + rightColumn;
                dot += left.weights[leftIndex] * right.weights[rightIndex];
                left.deltas[leftIndex] = 0;
                right.deltas[rightIndex] = 0;
            }
            product.weights[rightRowBase + rightColumn] = dot;
        }
    }
}

/**
 * multiplies {from} deltas to {left} and {right}
 */
function multiplyB(product, left, right) {
    const leftRows = left.rows;
    const leftColumns = left.columns;
    const rightColumns = right.columns;
    // loop over rows of left
    for (let leftRowRoot = 0; leftRowRoot < leftRows; leftRowRoot++) {
        const leftRowBase = leftColumns * leftRowRoot;
        const rightRowBase = rightColumns * leftRowRoot;
        // loop over cols of right
        for (let rightColumn = 0; rightColumn < rightColumns; rightColumn++) {
            // loop over columns of left
            for (let leftColumn = 0; leftColumn < leftColumns; leftColumn++) {
                const rightColumnBase = rightColumns * leftColumn;
                const leftRow = leftRowBase + leftColumn;
                const rightRow = rightColumnBase + rightColumn;
                const backPropagateValue = product.deltas[rightRowBase + rightColumn];
                left.deltas[leftRow] += right.weights[rightRow] * backPropagateValue;
                right.deltas[rightRow] += left.weights[leftRow] * backPropagateValue;
            }
        }
    }
}

function multiplyElement(product, left, right) {
    const { weights } = left;
    for (let i = 0; i < weights.length; i++) {
        product.weights[i] = left.weights[i] * right.weights[i];
        product.deltas[i] = 0;
    }
}

/**
 * multiplies {left} and {right} weight by {from} deltas into {left} and {right} deltas
 */
function multiplyElementB(product, left, right) {
    for (let i = 0; i < left.weights.length; i++) {
        left.deltas[i] = right.weights[i] * product.deltas[i];
        right.deltas[i] = left.weights[i] * product.deltas[i];
    }
}

/**
 *
 * relu {m} weights to {into} weights
 */
function relu(product, left) {
    for (let i = 0; i < left.weights.length; i++) {
        product.weights[i] = Math.max(0, left.weights[i]); // relu
        product.deltas[i] = 0;
    }
}

/**
 * adds {from} deltas to {m} deltas when {m} weights are above other a threshold of 0
 */
function reluB(product, left) {
    for (let i = 0; i < product.deltas.length; i++) {
        left.deltas[i] = left.weights[i] > 0 ? product.deltas[i] : 0;
    }
}

function rowPluck(product, left, rowPluckIndex) {
    const { columns } = left;
    const rowBase = columns * rowPluckIndex;
    for (let column = 0; column < columns; column++) {
        product.weights[column] = left.weights[rowBase + column];
        product.deltas[column] = 0;
    }
}

/**
 * adds {from} deltas into {m} deltas
 */
function rowPluckB(product, left, rowIndex) {
    const { columns } = left;
    const rowBase = columns * rowIndex;
    for (let column = 0; column < columns; column++) {
        left.deltas[rowBase + column] = product.deltas[column];
    }
}

function sigmoid(product, left) {
    // sigmoid nonlinearity
    for (let i = 0; i < left.weights.length; i++) {
        product.weights[i] = 1 / (1 + Math.exp(-left.weights[i]));
        product.deltas[i] = 0;
    }
}
// function sig(x) {
//   // helper function for computing sigmoid
//   return 1 / (1 + Math.exp(-x));
// }

function sigmoidB(product, left) {
    for (let i = 0; i < product.deltas.length; i++) {
        const mwi = product.weights[i];
        left.deltas[i] = mwi * (1 - mwi) * product.deltas[i];
    }
}

function softmax(matrix) {
    // probability volume
    const result = new Matrix(matrix.rows, matrix.columns);
    let maxVal = -999999;
    for (let i = 0; i < matrix.weights.length; i++) {
        if (matrix.weights[i] > maxVal) {
            maxVal = matrix.weights[i];
        }
    }
    let s = 0;
    for (let i = 0; i < matrix.weights.length; i++) {
        result.weights[i] = Math.exp(matrix.weights[i] - maxVal);
        s += result.weights[i];
    }
    for (let i = 0; i < matrix.weights.length; i++) {
        result.weights[i] /= s;
    }
    // no backward pass here needed
    // since we will use the computed probabilities outside
    // to set gradients directly on m
    return result;
}

function tanh(product, left) {
    // tanh nonlinearity
    for (let i = 0; i < left.weights.length; i++) {
        product.weights[i] = Math.tanh(left.weights[i]);
        product.deltas[i] = 0;
    }
}

function tanhB(product, left) {
    for (let i = 0; i < product.deltas.length; i++) {
        // grad for z = tanh(x) is (1 - z^2)
        const mwi = product.weights[i];
        left.deltas[i] = (1 - mwi * mwi) * product.deltas[i];
    }
}

class Equation {
    constructor() {
        this.states = [];
        this.inputRow = 0;
    }
    add(left, right) {
        if (left.weights.length !== right.weights.length) {
            throw new Error('misaligned matrices');
        }
        const product = new Matrix(left.rows, left.columns);
        this.states.push({
            name: 'add',
            product,
            left,
            right,
            forwardFn: add,
            backpropagationFn: addB,
        });
        return product;
    }
    allOnes(rows, columns) {
        const product = new Matrix(rows, columns);
        this.states.push({
            name: 'allOnes',
            product,
            left: product,
            forwardFn: allOnes,
            backpropagationFn: () => { },
        });
        return product;
    }
    cloneNegative(matrix) {
        const product = new Matrix(matrix.rows, matrix.columns);
        this.states.push({
            name: 'cloneNegative',
            product,
            left: matrix,
            forwardFn: cloneNegative,
            backpropagationFn: () => { },
        });
        return product;
    }
    /**
     * connects two matrices together by subtract
     */
    subtract(left, right) {
        if (left.weights.length !== right.weights.length) {
            throw new Error('misaligned matrices');
        }
        return this.add(this.add(this.allOnes(left.rows, left.columns), this.cloneNegative(left)), right);
    }
    /**
     * connects two matrices together by multiply
     */
    multiply(left, right) {
        if (left.columns !== right.rows) {
            throw new Error('misaligned matrices');
        }
        const product = new Matrix(left.rows, right.columns);
        this.states.push({
            name: 'multiply',
            product,
            left,
            right,
            forwardFn: multiply,
            backpropagationFn: multiplyB,
        });
        return product;
    }
    /**
     * connects two matrices together by multiplyElement
     */
    multiplyElement(left, right) {
        if (left.weights.length !== right.weights.length) {
            throw new Error('misaligned matrices');
        }
        const product = new Matrix(left.rows, left.columns);
        this.states.push({
            name: 'multiplyElement',
            product,
            left,
            right,
            forwardFn: multiplyElement,
            backpropagationFn: multiplyElementB,
        });
        return product;
    }
    /**
     * connects a matrix to relu
     */
    relu(matrix) {
        const product = new Matrix(matrix.rows, matrix.columns);
        this.states.push({
            name: 'relu',
            product,
            left: matrix,
            forwardFn: relu,
            backpropagationFn: reluB,
        });
        return product;
    }
    /**
     * input a matrix
     */
    input(input) {
        this.states.push({
            name: 'input',
            product: input,
            forwardFn: (product) => {
                if (!this.inputValue)
                    return;
                if (this.inputValue.length !== product.weights.length) {
                    throw new Error('this.inputValue is of wrong dimensions');
                }
                product.weights = input.weights = this.inputValue;
            },
            backpropagationFn: () => { },
        });
        return input;
    }
    /**
     * connects a matrix via a row
     */
    inputMatrixToRow(matrix) {
        // eslint-disable-next-line @typescript-eslint/no-this-alias
        const self = this;
        const product = new Matrix(matrix.columns, 1);
        this.states.push({
            name: 'inputMatrixToRow',
            product,
            left: matrix,
            get right() {
                return self.inputRow;
            },
            forwardFn: rowPluck,
            backpropagationFn: rowPluckB,
        });
        return product;
    }
    /**
     * connects a matrix to sigmoid
     */
    sigmoid(matrix) {
        const product = new Matrix(matrix.rows, matrix.columns);
        this.states.push({
            name: 'sigmoid',
            product,
            left: matrix,
            forwardFn: sigmoid,
            backpropagationFn: sigmoidB,
        });
        return product;
    }
    /**
     * connects a matrix to tanh
     */
    tanh(matrix) {
        const product = new Matrix(matrix.rows, matrix.columns);
        this.states.push({
            name: 'tanh',
            product,
            left: matrix,
            forwardFn: tanh,
            backpropagationFn: tanhB,
        });
        return product;
    }
    /**
     *
     * Observe a matrix for debugging
     */
    observe(matrix) {
        this.states.push({
            name: 'observe',
            product: new Matrix(),
            forwardFn: () => { },
            backpropagationFn: () => { },
        });
        return matrix;
    }
    /**
     * Run index through equations via forward propagation
     */
    runIndex(rowIndex = 0) {
        this.inputRow = rowIndex;
        let state = this.states[0];
        for (let i = 0, max = this.states.length; i < max; i++) {
            state = this.states[i];
            if (!state.hasOwnProperty('forwardFn'))
                continue;
            state.forwardFn(state.product, state.left, state.right);
        }
        return state.product;
    }
    /**
     * Run value through equations via forward propagation
     */
    runInput(inputValue) {
        this.inputValue = inputValue;
        let state = this.states[0];
        for (let i = 0, max = this.states.length; i < max; i++) {
            state = this.states[i];
            if (!state.hasOwnProperty('forwardFn'))
                continue;
            state.forwardFn(state.product, state.left, state.right);
        }
        return state.product;
    }
    /**
     * Run value through equations via back propagation
     */
    backpropagate() {
        let i = this.states.length;
        let state = this.states[0];
        while (i-- > 0) {
            state = this.states[i];
            if (!state.hasOwnProperty('backpropagationFn'))
                continue;
            state.backpropagationFn(state.product, state.left, state.right);
        }
        return state.product;
    }
    /**
     * Run index through equations via back propagation
     */
    backpropagateIndex(rowIndex = 0) {
        this.inputRow = rowIndex;
        let i = this.states.length;
        let state = this.states[0];
        while (i-- > 0) {
            state = this.states[i];
            if (!state.hasOwnProperty('backpropagationFn'))
                continue;
            state.backpropagationFn(state.product, state.left, state.right);
        }
        return state.product;
    }
    /**
     * Predict a target value from equation
     */
    predictTarget(input, target) {
        let errorSum = 0;
        const output = this.runInput(input);
        for (let i = 0; i < output.weights.length; i++) {
            const error = output.weights[i] - target[i];
            // set gradients into log probabilities
            errorSum += Math.abs(error);
            // write gradients into log probabilities
            output.deltas[i] = error;
        }
        return errorSum;
    }
    /**
     * Predict a target index from equation
     */
    predictTargetIndex(input, target) {
        const output = this.runIndex(input);
        // set gradients into log probabilities
        const logProbabilities = output; // interpret output as log probabilities
        const probabilities = softmax(output); // compute the softmax probabilities
        // write gradients into log probabilities
        logProbabilities.deltas = probabilities.weights.slice(0);
        logProbabilities.deltas[target] -= 1;
        // accumulate base 2 log prob and do smoothing
        return -Math.log2(probabilities.weights[target]);
    }
}

function maxI(matrix) {
    // argmax of array w
    const { weights } = matrix;
    let maxv = weights[0];
    let maxix = 0;
    for (let i = 1; i < weights.length; i++) {
        const v = weights[i];
        if (v < maxv)
            continue;
        maxix = i;
        maxv = v;
    }
    return maxix;
}

function sampleI(matrix) {
    // sample argmax from w, assuming w are
    // probabilities that sum to one
    const r = randomFloat(0, 1);
    const w = matrix.weights;
    let x = 0;
    let i = 0;
    while (true) {
        x += w[i];
        if (x > r) {
            return i;
        }
        i++;
    }
}

const trainDefaults$1 = {
    iterations: 20000,
    errorThresh: 0.005,
    log: false,
    logPeriod: 10,
    learningRate: 0.01,
    callbackPeriod: 10,
    timeout: Infinity,
};
const defaults$1 = () => {
    return {
        inputSize: 20,
        inputRange: 20,
        hiddenLayers: [20, 20],
        outputSize: 20,
        decayRate: 0.999,
        smoothEps: 1e-8,
        regc: 0.000001,
        clipval: 5,
        maxPredictionLength: 100,
        dataFormatter: new DataFormatter(),
    };
};
class RNN {
    constructor(options = {}) {
        this.options = { ...defaults$1() };
        this.trainOpts = { ...trainDefaults$1 };
        this.stepCache = {};
        this.runs = 0;
        this.ratioClipped = 0;
        this.model = Object.seal({
            isInitialized: false,
            input: new Matrix(0, 0),
            hiddenLayers: [],
            output: new Matrix(0, 0),
            equations: [],
            allMatrices: [],
            equationConnections: [],
            outputConnector: new RandomMatrix(0, 0, 0.08),
        });
        this.initialLayerInputs = [];
        this.options = { ...this.options, ...options };
        this.updateTrainingOptions({
            ...trainDefaults$1,
        });
        if (options.json) {
            this.fromJSON(options.json);
        }
    }
    initialize() {
        const { dataFormatter } = this.options;
        if (dataFormatter === null || dataFormatter === void 0 ? void 0 : dataFormatter.characters.length) {
            this.options.inputSize = this.options.inputRange = this.options.outputSize =
                dataFormatter.characters.length;
        }
        this.model = this.mapModel();
    }
    createHiddenLayers() {
        const { hiddenLayers, inputSize } = this.options;
        const hiddenLayersModel = [];
        // 0 is end, so add 1 to offset
        hiddenLayersModel.push(this.getHiddenLayer(hiddenLayers[0], inputSize));
        let prevSize = hiddenLayers[0];
        for (let d = 1; d < hiddenLayers.length; d++) {
            // loop over depths
            const hiddenSize = hiddenLayers[d];
            hiddenLayersModel.push(this.getHiddenLayer(hiddenSize, prevSize));
            prevSize = hiddenSize;
        }
        return hiddenLayersModel;
    }
    getHiddenLayer(hiddenSize, prevSize) {
        return {
            // wxh
            weight: new RandomMatrix(hiddenSize, prevSize, 0.08),
            // whh
            transition: new RandomMatrix(hiddenSize, hiddenSize, 0.08),
            // bhh
            bias: new Matrix(hiddenSize, 1),
        };
    }
    getEquation(equation, inputMatrix, previousResult, hiddenLayer) {
        if (!hiddenLayer.weight || !hiddenLayer.transition || !hiddenLayer.bias) {
            throw new Error('hiddenLayer does not have expected properties');
        }
        const relu = equation.relu.bind(equation);
        const add = equation.add.bind(equation);
        const multiply = equation.multiply.bind(equation);
        return relu(add(add(multiply(hiddenLayer.weight, inputMatrix), multiply(hiddenLayer.transition, previousResult)), hiddenLayer.bias));
    }
    createInputMatrix() {
        const { inputRange, inputSize } = this.options;
        if (inputRange < 1)
            throw new Error('this.options.inputRange not an expected number');
        if (inputSize < 1)
            throw new Error('this.options.inputSize not an expected number');
        // 0 is end, so add 1 to offset
        return new RandomMatrix(inputRange + 1, inputSize, 0.08);
    }
    createOutputMatrices() {
        const { outputSize, hiddenLayers } = this.options;
        const lastHiddenSize = last(hiddenLayers);
        // 0 is end, so add 1 to offset
        return {
            // whd
            outputConnector: new RandomMatrix(outputSize + 1, lastHiddenSize, 0.08),
            // 0 is end, so add 1 to offset
            // bd
            output: new Matrix(outputSize + 1, 1),
        };
    }
    bindEquation() {
        const { model } = this;
        const { hiddenLayers } = this.options;
        const equation = new Equation();
        const outputs = [];
        const equationConnection = model.equationConnections.length > 0
            ? last(model.equationConnections)
            : this.initialLayerInputs;
        // 0 index
        let output = this.getEquation(equation, equation.inputMatrixToRow(model.input), equationConnection[0], model.hiddenLayers[0]);
        outputs.push(output);
        // 1+ indices
        for (let i = 1, max = hiddenLayers.length; i < max; i++) {
            if (!equationConnection[i]) {
                throw new Error(`Cannot find equation at index ${i}`);
            }
            output = this.getEquation(equation, output, equationConnection[i], model.hiddenLayers[i]);
            outputs.push(output);
        }
        model.equationConnections.push(outputs);
        equation.add(equation.multiply(model.outputConnector, output), model.output);
        model.equations.push(equation);
    }
    mapModel() {
        const allMatrices = [];
        this.initialLayerInputs = this.options.hiddenLayers.map((size) => new Matrix(size, 1));
        const input = this.createInputMatrix();
        allMatrices.push(input);
        const hiddenLayers = this.createHiddenLayers();
        if (!hiddenLayers.length)
            throw new Error('net.hiddenLayers not set');
        for (let i = 0, max = hiddenLayers.length; i < max; i++) {
            const hiddenMatrix = hiddenLayers[i];
            for (const property in hiddenMatrix) {
                if (!hiddenMatrix.hasOwnProperty(property))
                    continue;
                allMatrices.push(hiddenMatrix[property]);
            }
        }
        const { output, outputConnector } = this.createOutputMatrices();
        allMatrices.push(outputConnector);
        allMatrices.push(output);
        return Object.seal({
            isInitialized: true,
            input,
            hiddenLayers,
            output,
            equations: [],
            allMatrices,
            equationConnections: [],
            outputConnector,
        });
    }
    trainInput(input) {
        this.runs++;
        const { model } = this;
        const max = input.length;
        let log2ppl = 0;
        let equation;
        while (model.equations.length <= input.length + 1) {
            // last is zero
            this.bindEquation();
        }
        for (let inputIndex = -1, inputMax = input.length; inputIndex < inputMax; inputIndex++) {
            // start and end tokens are zeros
            const equationIndex = inputIndex + 1;
            equation = model.equations[equationIndex];
            const source = inputIndex === -1 ? 0 : input[inputIndex] + 1; // first step: start with START token
            const target = inputIndex === max - 1 ? 0 : input[inputIndex + 1] + 1; // last step: end with END token
            log2ppl += equation.predictTargetIndex(source, target);
        }
        return Math.pow(2, log2ppl / (max - 1)) / 100;
    }
    backpropagate(input) {
        let i = input.length;
        const { model } = this;
        const { equations } = model;
        while (i > 0) {
            equations[i].backpropagateIndex(input[i - 1] + 1);
            i--;
        }
        equations[0].backpropagateIndex(0);
    }
    adjustWeights() {
        const { regc, clipval, decayRate, smoothEps } = this.options;
        const { trainOpts, model, stepCache } = this;
        const { learningRate } = trainOpts;
        const { allMatrices } = model;
        let numClipped = 0;
        let numTot = 0;
        for (let matrixIndex = 0; matrixIndex < allMatrices.length; matrixIndex++) {
            const matrix = allMatrices[matrixIndex];
            const { weights, deltas } = matrix;
            if (!(matrixIndex in stepCache)) {
                stepCache[matrixIndex] = zeros$1(matrix.rows * matrix.columns);
            }
            const cache = stepCache[matrixIndex];
            for (let i = 0; i < weights.length; i++) {
                let r = deltas[i];
                const w = weights[i];
                // rmsprop adaptive learning rate
                cache[i] = cache[i] * decayRate + (1 - decayRate) * r * r;
                // gradient clip
                if (r > clipval) {
                    r = clipval;
                    numClipped++;
                }
                else if (r < -clipval) {
                    r = -clipval;
                    numClipped++;
                }
                numTot++;
                // update (and regularize)
                weights[i] =
                    w + (-learningRate * r) / Math.sqrt(cache[i] + smoothEps) - regc * w;
            }
        }
        this.ratioClipped = numClipped / numTot;
    }
    get isRunnable() {
        if (this.model && this.model.equations.length === 0) {
            console.error(`No equations bound, did you run train()?`);
            return false;
        }
        return true;
    }
    checkRunnable() {
        if (!this.isRunnable) {
            throw new Error('Network not runnable');
        }
    }
    run(rawInput = [], isSampleI = false, temperature = 1) {
        const maxPredictionLength = this.options.maxPredictionLength +
            (rawInput !== null ? rawInput.length : 0) +
            (this.options.dataFormatter
                ? this.options.dataFormatter.specialIndexes.length
                : 0);
        this.checkRunnable();
        const input = this.options.dataFormatter && rawInput.length > 0
            ? this.options.dataFormatter.formatDataIn(rawInput)
            : rawInput;
        const { model } = this;
        const output = [];
        let i = 0;
        while (true) {
            const previousIndex = i === 0 ? 0 : i < input.length ? input[i - 1] + 1 : output[i - 1];
            while (model.equations.length <= i) {
                this.bindEquation();
            }
            const equation = model.equations[i];
            // sample predicted letter
            const outputMatrix = equation.runIndex(previousIndex);
            const logProbabilities = new Matrix(model.output.rows, model.output.columns);
            copy(logProbabilities, outputMatrix);
            if (temperature !== 1 && isSampleI) {
                /**
                 * scale log probabilities by temperature and re-normalize
                 * if temperature is high, logProbabilities will go towards zero
                 * and the softmax outputs will be more diffuse. if temperature is
                 * very low, the softmax outputs will be more peaky
                 */
                for (let j = 0, max = logProbabilities.weights.length; j < max; j++) {
                    logProbabilities.weights[j] /= temperature;
                }
            }
            const probs = softmax(logProbabilities);
            const nextIndex = isSampleI ? sampleI(probs) : maxI(probs);
            i++;
            if (nextIndex === 0) {
                // END token predicted, break out
                break;
            }
            if (i >= maxPredictionLength) {
                // something is wrong
                break;
            }
            output.push(nextIndex);
        }
        /**
         * we slice the input length here, not because output contains it, but it will be erroneous as we are sending the
         * network what is contained in input, so the data is essentially guessed by the network what could be next, till it
         * locks in on a value.
         * Kind of like this, values are from input:
         * 0 -> 4 (or in English: "beginning on input" -> "I have no idea? I'll guess what they want next!")
         * 2 -> 2 (oh how interesting, I've narrowed down values...)
         * 1 -> 9 (oh how interesting, I've now know what the values are...)
         * then the output looks like: [4, 2, 9,...]
         * so we then remove the erroneous data to get our true output
         */
        return this.options.dataFormatter.formatDataOut(input, output.slice(input.length).map((value) => value - 1));
    }
    /**
     *
     * Verifies network sizes are initialized
     * If they are not it will initialize them
     */
    verifyIsInitialized() {
        if (!this.model.isInitialized) {
            this.initialize();
        }
    }
    /**
     *
     * @param options
     *    Supports all `trainDefaults` properties
     *    also supports:
     *       learningRate: (number),
     *       momentum: (number),
     *       activation: 'sigmoid', 'relu', 'leaky-relu', 'tanh'
     */
    updateTrainingOptions(options) {
        var _a;
        this.trainOpts = { ...trainDefaults$1, ...options };
        this.validateTrainingOptions(this.trainOpts);
        this.setLogMethod((_a = options.log) !== null && _a !== void 0 ? _a : this.trainOpts.log);
        // TODO: Remove this?
        // this.activation = options.activation || this.activation;
    }
    validateTrainingOptions(options) {
        const validations = {
            iterations: () => {
                const val = options.iterations;
                return typeof val === 'number' && val > 0;
            },
            errorThresh: () => {
                const val = options.errorThresh;
                return typeof val === 'number' && val > 0 && val < 1;
            },
            log: () => {
                const val = options.log;
                return typeof val === 'function' || typeof val === 'boolean';
            },
            logPeriod: () => {
                const val = options.logPeriod;
                return typeof val === 'number' && val > 0;
            },
            learningRate: () => {
                const val = options.learningRate;
                return typeof val === 'number' && val > 0 && val < 1;
            },
            callback: () => {
                const val = options.callback;
                return typeof val === 'function' || val === undefined;
            },
            callbackPeriod: () => {
                const val = options.callbackPeriod;
                return typeof val === 'number' && val > 0;
            },
            timeout: () => {
                const val = options.timeout;
                return typeof val === 'number' && val > 0;
            },
        };
        for (const p in validations) {
            const v = options;
            if (!validations[p]()) {
                throw new Error(`[${p}, ${v[p]}] is out of normal training range, your network will probably not train.`);
            }
        }
    }
    setLogMethod(log) {
        if (typeof log === 'function') {
            this.trainOpts.log = log;
        }
        else if (log) {
            this.trainOpts.log = console.log;
        }
        else {
            this.trainOpts.log = false;
        }
    }
    prepTraining(data, options) {
        var _a;
        this.updateTrainingOptions(options);
        const preparedData = this.options.dataFormatter.format(data);
        const endTime = Date.now() + ((_a = this.trainOpts.timeout) !== null && _a !== void 0 ? _a : 0);
        const status = {
            error: 1,
            iterations: 0,
        };
        this.verifyIsInitialized();
        return {
            preparedData,
            status,
            endTime,
        };
    }
    train(data, trainOpts = {}) {
        var _a;
        this.trainOpts = trainOpts = {
            ...trainDefaults$1,
            ...trainOpts,
        };
        const { iterations, errorThresh, logPeriod, callback, callbackPeriod, } = this.trainOpts;
        const log = trainOpts.log === true ? console.log : trainOpts.log;
        let error = Infinity;
        let i;
        let inputs;
        if ((_a = this.options) === null || _a === void 0 ? void 0 : _a.dataFormatter) {
            inputs = this.options.dataFormatter.format(data);
        }
        else if (Array.isArray(data) &&
            Array.isArray(data[0]) &&
            typeof data[0][0] === 'number') {
            inputs = data;
        }
        else {
            throw new Error('training not in expected format of number[][]');
        }
        this.verifyIsInitialized();
        for (i = 0; i < iterations && error > errorThresh; i++) {
            let sum = 0;
            for (let j = 0; j < inputs.length; j++) {
                const err = this.trainPattern(inputs[j], true);
                sum += err;
            }
            error = sum / data.length;
            if (isNaN(error)) {
                throw new Error('Network error rate is unexpected NaN, check network configurations and try again. Most probably input format is not correct or training data is not enough. ');
            }
            if (log && i % logPeriod === 0) {
                log(`iterations: ${i}, training error: ${error}`);
            }
            if (callback && i % callbackPeriod === 0) {
                callback({ error, iterations: i });
            }
        }
        return {
            error,
            iterations: i,
        };
    }
    addFormat() {
        throw new Error('not yet implemented');
    }
    toJSON() {
        if (!this.model.isInitialized) {
            this.initialize();
        }
        const { model, options } = this;
        return {
            type: this.constructor.name,
            options: { ...options, dataFormatter: options.dataFormatter.toJSON() },
            trainOpts: {
                ...this.trainOpts,
                timeout: this.trainOpts.timeout === Infinity
                    ? 'Infinity'
                    : this.trainOpts.timeout,
            },
            input: model.input.toJSON(),
            hiddenLayers: model.hiddenLayers.map((hiddenLayer) => {
                const layers = {};
                for (const p in hiddenLayer) {
                    if (!hiddenLayer.hasOwnProperty(p))
                        continue;
                    layers[p] = hiddenLayer[p].toJSON();
                }
                return layers;
            }),
            outputConnector: this.model.outputConnector.toJSON(),
            output: this.model.output.toJSON(),
        };
    }
    fromJSON(json) {
        const { options } = json;
        const allMatrices = [];
        const input = Matrix.fromJSON(json.input);
        allMatrices.push(input);
        const hiddenLayers = [];
        json.hiddenLayers.forEach((hiddenLayer) => {
            const layers = {};
            for (const p in hiddenLayer) {
                layers[p] = Matrix.fromJSON(hiddenLayer[p]);
                allMatrices.push(layers[p]);
            }
            hiddenLayers.push(layers);
        });
        const outputConnector = Matrix.fromJSON(json.outputConnector);
        allMatrices.push(outputConnector);
        const output = Matrix.fromJSON(json.output);
        allMatrices.push(output);
        if (options.dataFormatter) {
            this.options = {
                ...defaults$1(),
                ...options,
                dataFormatter: DataFormatter.fromJSON(options.dataFormatter),
            };
        }
        else {
            this.options = {
                ...defaults$1(),
                ...options,
                dataFormatter: new DataFormatter(),
            };
        }
        this.model = Object.seal({
            isInitialized: true,
            input,
            hiddenLayers,
            output,
            allMatrices,
            outputConnector,
            equations: [],
            equationConnections: [],
        });
        this.initialLayerInputs = this.options.hiddenLayers.map((size) => new Matrix(size, 1));
        this.bindEquation();
        return this;
    }
    toFunction(cb) {
        const { model } = this;
        const { equations } = this.model;
        const equation = equations[1];
        const { states } = equation;
        const jsonString = JSON.stringify(this.toJSON());
        function previousConnectionIndex(m) {
            const connection = model.equationConnections[0];
            const { states } = equations[0];
            for (let i = 0, max = states.length; i < max; i++) {
                if (states[i].product === m) {
                    return i;
                }
            }
            return connection.indexOf(m);
        }
        function matrixOrigin(m, stateIndex) {
            for (let i = 0, max = states.length; i < max; i++) {
                const state = states[i];
                if (i === stateIndex) {
                    const j = previousConnectionIndex(m);
                    if (j > -1 && (m === state.left || m === state.right)) {
                        return `typeof prevStates[${j}] === 'object' ? prevStates[${j}].product : new Matrix(${m.rows}, ${m.columns})`;
                    }
                    return `new Matrix(${m.rows}, ${m.columns})`;
                }
                if (m === state.product)
                    return `states[${i}].product`;
                if (m === state.right)
                    return `states[${i}].right`;
                if (m === state.left)
                    return `states[${i}].left`;
            }
            return '';
        }
        function matrixToString(m, stateIndex) {
            if (!m || !m.rows || !m.columns)
                return 'null';
            if (m === model.input)
                return `json.input`;
            if (m === model.outputConnector)
                return `json.outputConnector`;
            if (m === model.output)
                return `json.output`;
            for (let i = 0, max = model.hiddenLayers.length; i < max; i++) {
                const hiddenLayer = model.hiddenLayers[i];
                for (const p in hiddenLayer) {
                    if (!hiddenLayer.hasOwnProperty(p))
                        continue;
                    if (hiddenLayer[p] !== m)
                        continue;
                    return `json.hiddenLayers[${i}].${p}`;
                }
            }
            return matrixOrigin(m, stateIndex);
        }
        function toInner(fnString) {
            // crude, but should be sufficient for now
            // function() { body }
            const fnParts = fnString.toString().split('{');
            fnParts.shift();
            // body }
            const fnBodyString = fnParts.join('{');
            const fnBodyParts = fnBodyString.split('}');
            fnBodyParts.pop();
            // body
            return fnBodyParts
                .join('}')
                .split('\n')
                .join('\n        ')
                .replace('product.deltas[i] = 0;', '')
                .replace('product.deltas[column] = 0;', '')
                .replace('left.deltas[leftIndex] = 0;', '')
                .replace('right.deltas[rightIndex] = 0;', '')
                .replace('product.deltas = left.deltas.slice(0);', '');
        }
        function fileName(fnName) {
            return `src/recurrent/matrix/${fnName.replace(/[A-Z]/g, function (value) {
                return `-${value.toLowerCase()}`;
            })}.js`;
        }
        const statesRaw = [];
        const usedFunctionNames = {};
        const innerFunctionsSwitch = [];
        for (let i = 0, max = states.length; i < max; i++) {
            const state = states[i];
            statesRaw.push(`states[${i}] = {
      name: '${state.forwardFn.name}',
      left: ${state.left ? matrixToString(state.left, i) : 'undefined'},
      right: ${state.right ? matrixToString(state.right, i) : 'undefined'},
      product: ${matrixToString(state.product, i)}
    }`);
            const fnName = state.forwardFn.name;
            if (!usedFunctionNames[fnName]) {
                usedFunctionNames[fnName] = true;
                innerFunctionsSwitch.push(`        case '${fnName}': //compiled from ${fileName(fnName)}
          ${toInner(state.forwardFn.toString())}
          break;`);
            }
        }
        const src = `
  if (typeof rawInput === 'undefined') rawInput = [];
  if (typeof isSampleI === 'undefined') isSampleI = false;
  if (typeof temperature === 'undefined') temperature = 1;
  var json = ${jsonString};
  ${this.options.dataFormatter
            ? `${this.options.dataFormatter.toFunctionString()};
  Object.assign(dataFormatter, json.options.dataFormatter);`
            : ''}
  ${this.options.dataFormatter &&
            typeof this.options.dataFormatter.formatDataIn === 'function'
            ? `const formatDataIn = function (input, output) { ${toInner(this.options.dataFormatter.formatDataIn.toString())} }.bind(dataFormatter);`
            : ''}
  ${this.options.dataFormatter !== null &&
            typeof this.options.dataFormatter.formatDataOut === 'function'
            ? `const formatDataOut = function formatDataOut(input, output) { ${toInner(this.options.dataFormatter.formatDataOut.toString())} }.bind(dataFormatter);`
            : ''}
  var maxPredictionLength =
    ${this.options.maxPredictionLength} +
    rawInput.length +
    ${this.options.dataFormatter
            ? this.options.dataFormatter.specialIndexes.length
            : 0};
  var input = ${this.options.dataFormatter &&
            typeof this.options.dataFormatter.formatDataIn === 'function'
            ? 'formatDataIn(rawInput)'
            : 'rawInput'};
  var _i = 0;
  var output = [];
  var states = [];
  var prevStates;
  while (true) {
    var previousIndex = (_i === 0
        ? 0
        : _i < input.length
          ? input[_i - 1] + 1
          : output[_i - 1])
          ;
    var rowPluckIndex = previousIndex;
    prevStates = states;
    states = [];
    ${statesRaw.join(';\n    ')};
    for (var stateIndex = 0, stateMax = ${statesRaw.length}; stateIndex < stateMax; stateIndex++) {
      var state = states[stateIndex];
      var product = state.product;
      var left = state.left;
      var right = state.right;
      switch (state.name) {
${innerFunctionsSwitch.join('\n')}
      }
    }

    var logProbabilities = state.product;
    if (temperature !== 1 && isSampleI) {
      for (var q = 0, nq = logProbabilities.weights.length; q < nq; q++) {
        logProbabilities.weights[q] /= temperature;
      }
    }

    var probs = softmax(logProbabilities);
    var nextIndex = isSampleI ? sampleI(probs) : maxI(probs);

    _i++;
    if (nextIndex === 0) {
      break;
    }
    if (_i >= maxPredictionLength) {
      break;
    }

    output.push(nextIndex);
  }
  ${this.options.dataFormatter &&
            typeof this.options.dataFormatter.formatDataOut === 'function'
            ? 'return formatDataOut(input, output.slice(input.length).map(function(value) { return value - 1; }))'
            : 'return output.slice(input.length).map(function(value) { return value - 1; })'};
  function Matrix(rows, columns) {
    this.rows = rows;
    this.columns = columns;
    this.weights = zeros(rows * columns);
  }
  ${zeros$1.toString()}
  ${softmax.toString().replace('_1.Matrix', 'Matrix')}
  ${randomFloat.toString()}
  ${sampleI.toString()}
  ${maxI.toString()}`;
        // eslint-disable-next-line
        return new Function('rawInput', 'isSampleI', 'temperature', cb ? cb(src) : src);
    }
    trainPattern(input, logErrorRate) {
        const error = this.trainInput(input);
        this.backpropagate(input);
        this.adjustWeights();
        if (logErrorRate) {
            return error;
        }
        return 0;
    }
}
function last(values) {
    return values[values.length - 1];
}

class GRU extends RNN {
    getHiddenLayer(hiddenSize, prevSize) {
        return getGRUHiddenLayer(hiddenSize, prevSize);
    }
    getEquation(equation, inputMatrix, previousResult, hiddenLayer) {
        return getGRUEquation(equation, inputMatrix, previousResult, hiddenLayer);
    }
}
function getGRUHiddenLayer(hiddenSize, prevSize) {
    return {
        // update Gate
        // wzxh
        updateGateInputMatrix: new RandomMatrix(hiddenSize, prevSize, 0.08),
        updateGateHiddenMatrix: new RandomMatrix(hiddenSize, hiddenSize, 0.08),
        updateGateBias: new Matrix(hiddenSize, 1),
        // reset Gate
        // wrxh
        resetGateInputMatrix: new RandomMatrix(hiddenSize, prevSize, 0.08),
        resetGateHiddenMatrix: new RandomMatrix(hiddenSize, hiddenSize, 0.08),
        resetGateBias: new Matrix(hiddenSize, 1),
        // cell write parameters
        // wcxh
        cellWriteInputMatrix: new RandomMatrix(hiddenSize, prevSize, 0.08),
        cellWriteHiddenMatrix: new RandomMatrix(hiddenSize, hiddenSize, 0.08),
        cellWriteBias: new Matrix(hiddenSize, 1),
    };
}
function getGRUEquation(equation, inputMatrix, previousResult, hiddenLayer) {
    if (!hiddenLayer.updateGateInputMatrix ||
        !hiddenLayer.updateGateHiddenMatrix ||
        !hiddenLayer.updateGateBias ||
        !hiddenLayer.resetGateInputMatrix ||
        !hiddenLayer.resetGateHiddenMatrix ||
        !hiddenLayer.resetGateBias ||
        !hiddenLayer.cellWriteInputMatrix ||
        !hiddenLayer.cellWriteHiddenMatrix ||
        !hiddenLayer.cellWriteBias) {
        throw new Error('hiddenLayer does not have expected properties');
    }
    const sigmoid = equation.sigmoid.bind(equation);
    const add = equation.add.bind(equation);
    const multiply = equation.multiply.bind(equation);
    const multiplyElement = equation.multiplyElement.bind(equation);
    const tanh = equation.tanh.bind(equation);
    const allOnes = equation.allOnes.bind(equation);
    const cloneNegative = equation.cloneNegative.bind(equation);
    // update gate
    const updateGate = sigmoid(add(add(multiply(hiddenLayer.updateGateInputMatrix, inputMatrix), multiply(hiddenLayer.updateGateHiddenMatrix, previousResult)), hiddenLayer.updateGateBias));
    // reset gate
    const resetGate = sigmoid(add(add(multiply(hiddenLayer.resetGateInputMatrix, inputMatrix), multiply(hiddenLayer.resetGateHiddenMatrix, previousResult)), hiddenLayer.resetGateBias));
    // cell
    const cell = tanh(add(add(multiply(hiddenLayer.cellWriteInputMatrix, inputMatrix), multiply(hiddenLayer.cellWriteHiddenMatrix, multiplyElement(resetGate, previousResult))), hiddenLayer.cellWriteBias));
    // compute hidden state as gated, saturated cell activations
    // negate updateGate
    return add(multiplyElement(add(allOnes(updateGate.rows, updateGate.columns), cloneNegative(updateGate)), cell), multiplyElement(previousResult, updateGate));
}

class ArrayLookupTable {
    constructor(data, prop) {
        this.prop = prop;
        this.length = 0;
        this.table = {};
        for (let i = 0; i < data.length; i++) {
            const datum = data[i];
            const ioValue = datum[prop];
            for (let j = 0; j < ioValue.length; j++) {
                const value = ioValue[j];
                for (const p in value) {
                    if (!value.hasOwnProperty(p))
                        continue;
                    if (this.table.hasOwnProperty(p))
                        continue;
                    this.table[p] = this.length++;
                }
            }
        }
    }
}

const defaults = () => {
    return {
        ...defaults$1(),
        inputSize: 1,
        hiddenLayers: [20],
        outputSize: 1,
        inputRange: 0,
    };
};
class RNNTimeStep extends RNN {
    constructor(options = {}) {
        super();
        this.inputLookupLength = 0;
        this.inputLookup = null;
        this.outputLookup = null;
        this.outputLookupLength = 0;
        // eslint-disable-next-line @typescript-eslint/ban-ts-comment
        // @ts-expect-error
        this.model = Object.seal({
            isInitialized: false,
            hiddenLayers: [],
            output: new Matrix(0, 0),
            equations: [],
            allMatrices: [],
            equationConnections: [],
            outputConnector: new RandomMatrix(0, 0, 0.08),
        });
        // eslint-disable-next-line @typescript-eslint/ban-ts-comment
        // @ts-expect-error
        this.options = defaults();
        this.options = { ...this.options, ...options };
        this.updateTrainingOptions({
            ...trainDefaults,
            ...options,
        });
        if (options.json) {
            this.fromJSON(options.json);
        }
    }
    createInputMatrix() {
        throw new Error('Input Matrices do not exist on RNNTimeStep');
    }
    createOutputMatrices() {
        const { outputSize } = this.options;
        const lastHiddenSize = last(this.options.hiddenLayers);
        // whd
        const outputConnector = new RandomMatrix(outputSize, lastHiddenSize, 0.08);
        // bd
        const output = new RandomMatrix(outputSize, 1, 0.08);
        return { output, outputConnector };
    }
    bindEquation() {
        const { model, options } = this;
        const { hiddenLayers, inputSize } = options;
        const layers = model.hiddenLayers;
        const equation = new Equation();
        const outputs = [];
        const equationConnection = model.equationConnections.length > 0
            ? model.equationConnections[model.equationConnections.length - 1]
            : this.initialLayerInputs;
        // 0 index
        let output = this.getEquation(equation, equation.input(new Matrix(inputSize, 1)), equationConnection[0], layers[0]);
        outputs.push(output);
        // 1+ indices
        for (let i = 1, max = hiddenLayers.length; i < max; i++) {
            output = this.getEquation(equation, output, equationConnection[i], layers[i]);
            outputs.push(output);
        }
        model.equationConnections.push(outputs);
        equation.add(equation.multiply(model.outputConnector, output), model.output);
        model.equations.push(equation);
    }
    initialize() {
        this.model = this.mapModel();
    }
    // eslint-disable-next-line @typescript-eslint/ban-ts-comment
    // @ts-expect-error
    mapModel() {
        const allMatrices = [];
        this.initialLayerInputs = this.options.hiddenLayers.map((size) => new Matrix(size, 1));
        const hiddenLayers = this.createHiddenLayers();
        for (let i = 0, max = hiddenLayers.length; i < max; i++) {
            const hiddenMatrix = hiddenLayers[i];
            for (const property in hiddenMatrix) {
                if (!hiddenMatrix.hasOwnProperty(property))
                    continue;
                allMatrices.push(hiddenMatrix[property]);
            }
        }
        const { outputConnector, output } = this.createOutputMatrices();
        allMatrices.push(outputConnector);
        allMatrices.push(output);
        return Object.seal({
            isInitialized: true,
            hiddenLayers,
            output,
            equations: [],
            allMatrices,
            equationConnections: [],
            outputConnector,
        });
    }
    backpropagate() {
        for (let i = this.model.equations.length - 1; i > -1; i--) {
            this.model.equations[i].backpropagate();
        }
    }
    // eslint-disable-next-line @typescript-eslint/ban-ts-comment
    // @ts-expect-error
    run(rawInput) {
        const shape = lookup.dataShape(rawInput).join(',');
        switch (shape) {
            case 'array,number':
                // eslint-disable-next-line @typescript-eslint/ban-ts-comment
                // @ts-expect-error
                return this.runArray(rawInput);
            case 'array,array,number':
                // eslint-disable-next-line @typescript-eslint/ban-ts-comment
                // @ts-expect-error
                return this.runArrayOfArray(rawInput);
            case 'object,number':
                // eslint-disable-next-line @typescript-eslint/ban-ts-comment
                // @ts-expect-error
                return this.runObject(rawInput); // Backward compatibility, will be result of `unknown` and need casting.  Better to just use net.runObject() directly
            case 'array,object,number':
                // eslint-disable-next-line @typescript-eslint/ban-ts-comment
                // @ts-expect-error
                return this.runArrayOfObject(rawInput);
            default:
                throw new Error(`Unrecognized data shape ${shape}`);
        }
    }
    forecast(rawInput, count = 1) {
        const shape = lookup.dataShape(rawInput).join(',');
        switch (shape) {
            case 'array,number':
                // eslint-disable-next-line @typescript-eslint/ban-ts-comment
                // @ts-expect-error
                return this.forecastArray(rawInput, count);
            case 'array,array,number':
                // eslint-disable-next-line @typescript-eslint/ban-ts-comment
                // @ts-expect-error
                return this.forecastArrayOfArray(rawInput, count);
            case 'object,number':
                // eslint-disable-next-line @typescript-eslint/ban-ts-comment
                // @ts-expect-error
                return this.runObject(rawInput);
            case 'array,object,number':
                // eslint-disable-next-line @typescript-eslint/ban-ts-comment
                // @ts-expect-error
                return this.forecastArrayOfObject(rawInput, count);
            default:
                throw new Error(`Unrecognized data shape ${shape}`);
        }
    }
    forecastArray(input, count = 1) {
        this.checkRunnable();
        const { model } = this;
        const { equations } = model;
        const length = input.length + count;
        while (equations.length <= length) {
            this.bindEquation();
        }
        let lastOutput;
        let equationIndex = 0;
        if (this.options.inputSize === 1) {
            for (let i = 0; i < input.length; i++) {
                lastOutput = equations[equationIndex++].runInput(Float32Array.from([input[i]]));
            }
        }
        else {
            for (let i = 0; i < input.length; i++) {
                lastOutput = equations[equationIndex++].runInput(Float32Array.from([]));
            }
        }
        if (!lastOutput) {
            throw new Error('lastOutput not set');
        }
        const result = [lastOutput.weights[0]];
        for (let i = 0, max = count - 1; i < max; i++) {
            lastOutput = equations[equationIndex++].runInput(lastOutput.weights);
            result.push(lastOutput.weights[0]);
        }
        this.end();
        return Float32Array.from(result);
    }
    forecastArrayOfArray(input, count = 1) {
        this.checkRunnable();
        const { model } = this;
        const { equations } = model;
        const length = input.length + count;
        while (equations.length <= length) {
            this.bindEquation();
        }
        let lastOutput;
        let equationIndex = 0;
        for (let i = 0; i < input.length; i++) {
            lastOutput = equations[equationIndex++].runInput(input[i]);
        }
        if (!lastOutput) {
            throw new Error('lastOutput not set');
        }
        const result = [Float32Array.from(lastOutput.weights)];
        for (let i = 0, max = count - 1; i < max; i++) {
            lastOutput = equations[equationIndex++].runInput(lastOutput.weights);
            result.push(Float32Array.from(lastOutput.weights.slice(0)));
        }
        this.end();
        return result;
    }
    forecastArrayOfObject(input, count = 1) {
        if (!this.inputLookup) {
            throw new Error('this.inputLookup not set');
        }
        if (!this.outputLookup) {
            throw new Error('this.outputLookup not set');
        }
        const formattedData = input.map((value) => lookup.toArray(this.inputLookup, value, this.inputLookupLength));
        return this.forecastArrayOfArray(formattedData, count).map((value) => lookup.toObject(this.outputLookup, value));
    }
    // eslint-disable-next-line @typescript-eslint/ban-ts-comment
    // @ts-expect-error
    train(data, trainOpts = {}) {
        this.trainOpts = trainOpts = {
            ...trainDefaults$1,
            ...trainOpts,
        };
        // Don't destructure here because this.setSize() can reset this.options.
        if (this.options.inputSize === 1 && this.options.outputSize === 1) {
            this.setSize(data);
        }
        this.verifySize();
        const formattedData = this.formatData(data);
        let error = Infinity;
        let i;
        this.verifyIsInitialized();
        const { iterations, errorThresh, logPeriod, callback, callbackPeriod, } = this.trainOpts;
        const log = trainOpts.log === true ? console.log : trainOpts.log;
        for (i = 0; i < iterations && error > errorThresh; i++) {
            let sum = 0;
            for (let j = 0; j < formattedData.length; j++) {
                const err = this.trainPattern(formattedData[j], true);
                sum += err;
            }
            error = sum / formattedData.length;
            if (isNaN(error))
                throw new Error('Network error rate is unexpected NaN, check network configurations and try again. Most probably input format is not correct or training data is not enough. ');
            if (log && i % logPeriod === 0) {
                log(`iterations: ${i}, training error: ${error}`);
            }
            if (callback && i % callbackPeriod === 0) {
                callback({ error, iterations: i });
            }
        }
        return {
            error,
            iterations: i,
        };
    }
    trainArrayOfArray(input) {
        if (input.length < 2) {
            throw new Error('input must be an array of 2 or more');
        }
        const { equations } = this.model;
        while (equations.length < input.length) {
            this.bindEquation();
        }
        let errorSum = 0;
        for (let i = 0, max = input.length - 1; i < max; i++) {
            errorSum += equations[i].predictTarget(input[i], input[i + 1]);
        }
        this.end();
        return errorSum / input.length;
    }
    // eslint-disable-next-line @typescript-eslint/ban-ts-comment
    // @ts-expect-error
    trainPattern(input, logErrorRate) {
        const error = this.trainArrayOfArray(input);
        this.backpropagate();
        this.adjustWeights();
        if (logErrorRate) {
            return error;
        }
        return 0;
    }
    setSize(data) {
        let size = 0;
        const dataShape = lookup.dataShape(data).join(',');
        switch (dataShape) {
            case 'array,array,number':
            case 'array,object,number':
            case 'array,datum,array,number':
            case 'array,datum,object,number':
                size = 1;
                // probably 1
                break;
            case 'array,array,array,number':
                size = data[0][0].length;
                break;
            case 'array,array,object,number':
                // inputs and outputs should match
                size = Object.keys(lookup.toTable2D(data)).length;
                break;
            case 'array,datum,array,array,number':
                size = data[0].input[0].length;
                break;
            case 'array,datum,array,object,number':
                size = Object.keys(lookup.toInputTable2D(data)).length;
                break;
            default:
                throw new Error('unknown data shape or configuration');
        }
        this.options = Object.seal({
            ...this.options,
            inputSize: size,
            outputSize: size,
        });
    }
    verifySize() {
        if (this.options.inputSize || this.options.outputSize) {
            if (this.options.inputSize !== this.options.outputSize) {
                throw new Error('manually set inputSize and outputSize mismatch');
            }
        }
    }
    runArray(input) {
        this.checkRunnable();
        const { equations } = this.model;
        while (equations.length <= input.length) {
            this.bindEquation();
        }
        let lastOutput;
        for (let i = 0; i < input.length; i++) {
            lastOutput = equations[i].runInput(new Float32Array([input[i]]));
        }
        this.end();
        return lastOutput.weights[0];
    }
    runArrayOfArray(input) {
        this.checkRunnable();
        const { model } = this;
        const { equations } = model;
        while (equations.length <= input.length) {
            this.bindEquation();
        }
        let lastOutput;
        for (let i = 0; i < input.length; i++) {
            const outputMatrix = equations[i].runInput(input[i]);
            lastOutput = outputMatrix.weights;
        }
        this.end();
        return lastOutput !== null && lastOutput !== void 0 ? lastOutput : Float32Array.from([]);
    }
    runObject(input) {
        if (!this.inputLookup) {
            throw new Error('this.inputLookup not set');
        }
        if (!this.outputLookup) {
            throw new Error('this.outputLookup not set');
        }
        if (!this.outputLookupLength) {
            throw new Error('this.outputLookupLength not set');
        }
        if (this.inputLookup === this.outputLookup) {
            const inputArray = lookup.toArrayShort(this.inputLookup, input);
            return lookup.toObjectPartial(this.outputLookup, this.forecastArray(inputArray, this.outputLookupLength - inputArray.length), inputArray.length);
        }
        return lookup.toObject(this.outputLookup, this.forecastArray(lookup.toArray(this.inputLookup, input, this.inputLookupLength), this.outputLookupLength));
    }
    runArrayOfObject(input) {
        if (this.inputLookup === null) {
            throw new Error('this.inputLookup not set');
        }
        if (this.outputLookup === null) {
            throw new Error('this.outputLookup not set');
        }
        const formattedInput = input.map((value) => lookup.toArray(this.inputLookup, value, this.inputLookupLength));
        return this.forecastArrayOfArray(formattedInput, 1).map((value) => lookup.toObject(this.outputLookup, value))[0];
    }
    runArrayOfObjectOfArray(input) {
        if (!this.inputLookup) {
            throw new Error('this.inputLookup not set');
        }
        if (!this.outputLookup) {
            throw new Error('this.outputLookup not set');
        }
        return lookup.toObject(this.outputLookup, this.runArrayOfArray(lookup.toArrays(this.inputLookup, input, this.inputLookupLength)));
    }
    end() {
        this.model.equations[this.model.equations.length - 1].runInput(new Float32Array(this.options.outputSize));
    }
    requireInputOutputOfOne() {
        if (this.options.inputSize !== 1) {
            throw new Error('inputSize must be 1 for this data size');
        }
        if (this.options.outputSize !== 1) {
            throw new Error('outputSize must be 1 for this data size');
        }
    }
    // Handles data shape of 'array,number'
    formatArray(data) {
        const result = [];
        this.requireInputOutputOfOne();
        for (let i = 0; i < data.length; i++) {
            result.push(Float32Array.from([data[i]]));
        }
        return [result];
    }
    // Handles data shape of 'array,array,number'
    formatArrayOfArray(data) {
        const result = [];
        const { inputSize, outputSize } = this.options;
        if (inputSize === 1 && outputSize === 1) {
            for (let i = 0; i < data.length; i++) {
                result.push(arrayToFloat32Arrays(data[i]));
            }
            return result;
        }
        if (inputSize !== data[0].length) {
            throw new Error('inputSize must match data input size');
        }
        if (outputSize !== data[0].length) {
            throw new Error('outputSize must match data output size');
        }
        for (let i = 0; i < data.length; i++) {
            result.push(Float32Array.from(data[i]));
        }
        return [result];
    }
    // Handles data shape of 'array,object,number'
    formatArrayOfObject(data) {
        this.requireInputOutputOfOne();
        if (!this.inputLookup) {
            const lookupTable = new LookupTable(data);
            this.inputLookup = this.outputLookup = lookupTable.table;
            this.inputLookupLength = this.outputLookupLength = lookupTable.length;
        }
        const result = [];
        for (let i = 0; i < data.length; i++) {
            result.push(objectToFloat32Arrays(data[i]));
        }
        return result;
    }
    // Handles data shape of 'array,object,number' when this.options.inputSize > 1
    formatArrayOfObjectMulti(data) {
        if (!this.inputLookup) {
            const lookupTable = new LookupTable(data);
            this.inputLookup = this.outputLookup = lookupTable.table;
            this.inputLookupLength = this.outputLookupLength = lookupTable.length;
        }
        const result = [];
        for (let i = 0; i < data.length; i++) {
            result.push([
                objectToFloat32Array(data[i], this.inputLookup, this.inputLookupLength),
            ]);
        }
        return result;
    }
    // Handles data shape of 'array,datum,array,number'
    formatArrayOfDatumOfArray(data) {
        const result = [];
        this.requireInputOutputOfOne();
        for (let i = 0; i < data.length; i++) {
            const datum = data[i];
            result.push(inputOutputArrayToFloat32Arrays(datum.input, datum.output));
        }
        return result;
    }
    // Handles data shape of 'array,datum,object,number'
    formatArrayOfDatumOfObject(data) {
        this.requireInputOutputOfOne();
        if (!this.inputLookup) {
            const inputLookup = new LookupTable(data, 'input');
            this.inputLookup = inputLookup.table;
            this.inputLookupLength = inputLookup.length;
        }
        if (!this.outputLookup) {
            const outputLookup = new LookupTable(data, 'output');
            this.outputLookup = outputLookup.table;
            this.outputLookupLength = outputLookup.length;
        }
        const result = [];
        for (let i = 0; i < data.length; i++) {
            const datum = data[i];
            result.push(inputOutputObjectToFloat32Arrays(datum.input, datum.output));
        }
        return result;
    }
    // Handles data shape of 'array,array,array,number'
    formatArrayOfArrayOfArray(data) {
        const result = [];
        for (let i = 0; i < data.length; i++) {
            result.push(arraysToFloat32Arrays(data[i]));
        }
        return result;
    }
    // Handles data shape of 'array,array,object,number'
    formatArrayOfArrayOfObject(data) {
        if (!this.inputLookup) {
            const lookupTable = new LookupTable(data);
            this.inputLookup = this.outputLookup = lookupTable.table;
            this.inputLookupLength = this.outputLookupLength = lookupTable.length;
        }
        const result = [];
        for (let i = 0; i < data.length; i++) {
            const array = [];
            for (let j = 0; j < data[i].length; j++) {
                array.push(objectToFloat32Array(data[i][j], this.inputLookup, this.inputLookupLength));
            }
            result.push(array);
        }
        return result;
    }
    // Handles data shape of 'array,datum,array,array,number'
    formatArrayOfDatumOfArrayOfArray(data) {
        const result = [];
        const { inputSize, outputSize } = this.options;
        if (inputSize !== data[0].input[0].length) {
            throw new Error('inputSize must match data input size');
        }
        if (outputSize !== data[0].output[0].length) {
            throw new Error('outputSize must match data output size');
        }
        for (let i = 0; i < data.length; i++) {
            const datum = data[i];
            result.push(inputOutputArraysToFloat32Arrays(datum.input, datum.output));
        }
        return result;
    }
    // 'Handles data shape of array,datum,array,object,number'
    formatArrayOfDatumOfArrayOfObject(data) {
        if (!this.inputLookup) {
            const inputLookup = new ArrayLookupTable(data, 'input');
            this.inputLookup = inputLookup.table;
            this.inputLookupLength = inputLookup.length;
        }
        if (!this.outputLookup) {
            const outputLookup = new ArrayLookupTable(data, 'output');
            this.outputLookup = outputLookup.table;
            this.outputLookupLength = outputLookup.length;
        }
        if (!this.outputLookupLength) {
            throw new Error('this.outputLookupLength not set to usable number');
        }
        const result = [];
        for (let i = 0; i < data.length; i++) {
            const datum = data[i];
            result.push(inputOutputObjectsToFloat32Arrays(datum.input, datum.output, this.inputLookup, this.outputLookup, this.inputLookupLength, this.outputLookupLength));
        }
        return result;
    }
    formatData(data) {
        const dataShape = lookup.dataShape(data).join(',');
        switch (dataShape) {
            case 'array,number':
                return this.formatArray(data);
            case 'array,array,number':
                return this.formatArrayOfArray(data);
            case 'array,object,number':
                if (this.options.inputSize === 1) {
                    return this.formatArrayOfObject(data);
                }
                else {
                    return this.formatArrayOfObjectMulti(data);
                }
            case 'array,datum,array,number':
                return this.formatArrayOfDatumOfArray(data);
            case 'array,datum,object,number':
                return this.formatArrayOfDatumOfObject(data);
            case 'array,array,array,number':
                return this.formatArrayOfArrayOfArray(data);
            case 'array,array,object,number':
                return this.formatArrayOfArrayOfObject(data);
            case 'array,datum,array,array,number':
                return this.formatArrayOfDatumOfArrayOfArray(data);
            case 'array,datum,array,object,number':
                return this.formatArrayOfDatumOfArrayOfObject(data);
            default:
                throw new Error('unknown data shape or configuration');
        }
    }
    test(data) {
        // for classification problems
        const misclasses = [];
        // run each pattern through the trained network and collect
        // error and misclassification statistics
        let errorSum = 0;
        const formattedData = this.formatData(data);
        for (let i = 0; i < formattedData.length; i++) {
            const input = formattedData[i];
            const output = this.run(input.splice(0, input.length - 1));
            const target = input[input.length - 1];
            let errors = 0;
            let errorCount = 0;
            for (let j = 0; j < output.length; j++) {
                errorCount++;
                const error = target[j] - output[j];
                // mse
                errors += error * error;
            }
            errorSum += errors / errorCount;
            const errorsAbs = Math.abs(errors);
            if (errorsAbs > this.trainOpts.errorThresh) {
                const misclass = data[i];
                misclasses.push({
                    value: misclass,
                    actual: output,
                });
            }
        }
        return {
            error: errorSum / formattedData.length,
            misclasses,
            total: formattedData.length,
        };
    }
    // eslint-disable-next-line @typescript-eslint/ban-ts-comment
    // @ts-expect-error
    addFormat(value) {
        var _a, _b, _c, _d, _e, _f;
        const dataShape = lookup.dataShape(value).join(',');
        switch (dataShape) {
            case 'array,array,number':
            case 'datum,array,array,number':
            case 'array,number':
            case 'datum,array,number':
                return;
            case 'datum,object,number': {
                this.inputLookup = lookup.addKeys(value.input, (_a = this.inputLookup) !== null && _a !== void 0 ? _a : {});
                if (this.inputLookup) {
                    this.inputLookupLength = Object.keys(this.inputLookup).length;
                }
                this.outputLookup = lookup.addKeys(value.output, (_b = this.outputLookup) !== null && _b !== void 0 ? _b : {});
                if (this.outputLookup) {
                    this.outputLookupLength = Object.keys(this.outputLookup).length;
                }
                break;
            }
            case 'object,number': {
                this.inputLookup = this.outputLookup = lookup.addKeys(value, (_c = this.inputLookup) !== null && _c !== void 0 ? _c : {});
                if (this.inputLookup) {
                    this.inputLookupLength = this.outputLookupLength = Object.keys(this.inputLookup).length;
                }
                break;
            }
            case 'array,object,number': {
                const typedValue = value;
                for (let i = 0; i < typedValue.length; i++) {
                    this.inputLookup = this.outputLookup = lookup.addKeys(typedValue[i], (_d = this.inputLookup) !== null && _d !== void 0 ? _d : {});
                    if (this.inputLookup) {
                        this.inputLookupLength = this.outputLookupLength = Object.keys(this.inputLookup).length;
                    }
                }
                break;
            }
            case 'datum,array,object,number': {
                const typedValue = value;
                const typedInput = typedValue.input;
                for (let i = 0; i < typedInput.length; i++) {
                    this.inputLookup = lookup.addKeys(typedInput[i], (_e = this.inputLookup) !== null && _e !== void 0 ? _e : {});
                    if (this.inputLookup) {
                        this.inputLookupLength = Object.keys(this.inputLookup).length;
                    }
                }
                const typedOutput = typedValue.output;
                for (let i = 0; i < typedOutput.length; i++) {
                    this.outputLookup = lookup.addKeys(typedOutput[i], (_f = this.outputLookup) !== null && _f !== void 0 ? _f : {});
                    if (this.outputLookup) {
                        this.outputLookupLength = Object.keys(this.outputLookup).length;
                    }
                }
                break;
            }
            default:
                throw new Error('unknown data shape or configuration');
        }
    }
    // eslint-disable-next-line @typescript-eslint/ban-ts-comment
    // @ts-expect-error
    toJSON() {
        if (!this.model) {
            this.initialize();
        }
        const { model } = this;
        const options = { ...this.options, ...defaults$1 };
        return {
            type: this.constructor.name,
            options,
            hiddenLayers: model.hiddenLayers.map((hiddenLayer) => {
                const layers = {};
                for (const p in hiddenLayer) {
                    if (!hiddenLayer.hasOwnProperty(p))
                        continue;
                    layers[p] = hiddenLayer[p].toJSON();
                }
                return layers;
            }),
            outputConnector: model.outputConnector.toJSON(),
            output: model.output.toJSON(),
            inputLookup: this.inputLookup,
            inputLookupLength: this.inputLookupLength,
            outputLookup: this.outputLookup,
            outputLookupLength: this.outputLookupLength,
        };
    }
    // eslint-disable-next-line @typescript-eslint/ban-ts-comment
    // @ts-expect-error
    fromJSON(json) {
        const { options } = json;
        const allMatrices = [];
        const hiddenLayers = [];
        // backward compatibility for hiddenSizes
        json.hiddenLayers.forEach((hiddenLayer) => {
            const layers = {};
            for (const p in hiddenLayer) {
                layers[p] = Matrix.fromJSON(hiddenLayer[p]);
                allMatrices.push(layers[p]);
            }
            hiddenLayers.push(layers);
        });
        const outputConnector = Matrix.fromJSON(json.outputConnector);
        allMatrices.push(outputConnector);
        const output = Matrix.fromJSON(json.output);
        allMatrices.push(output);
        // eslint-disable-next-line @typescript-eslint/ban-ts-comment
        // @ts-expect-error
        this.options = { ...defaults(), ...options };
        this.inputLookup = json.inputLookup;
        this.inputLookupLength = json.inputLookupLength;
        this.outputLookup = json.outputLookup;
        this.outputLookupLength = json.outputLookupLength;
        this.model = Object.seal({
            isInitialized: true,
            hiddenLayers,
            output,
            allMatrices,
            outputConnector,
            equations: [],
            equationConnections: [],
        });
        this.initialLayerInputs = options.hiddenLayers.map((size) => new Matrix(size, 1));
        this.bindEquation();
        return this;
    }
    // eslint-disable-next-line @typescript-eslint/ban-ts-comment
    // @ts-expect-error
    toFunction(cb) {
        const { model, inputLookup, inputLookupLength, outputLookup, outputLookupLength, } = this;
        const { inputSize } = this.options;
        const { equations } = model;
        const equation = equations[1];
        const { states } = equation;
        const jsonString = JSON.stringify(this.toJSON());
        function previousConnectionIndex(m) {
            const connection = model.equationConnections[0];
            const { states } = equations[0];
            for (let i = 0, max = states.length; i < max; i++) {
                if (states[i].product === m) {
                    return i;
                }
            }
            return connection.indexOf(m);
        }
        function matrixOrigin(m, stateIndex) {
            for (let i = 0, max = states.length; i < max; i++) {
                const state = states[i];
                if (i === stateIndex) {
                    const j = previousConnectionIndex(m);
                    switch (m) {
                        case state.left:
                            if (j > -1) {
                                return `typeof prevStates[${j}] === 'object' ? prevStates[${j}].product : new Matrix(${m.rows}, ${m.columns})`;
                            }
                        // eslint-disable-next-line no-fallthrough
                        case state.right:
                            if (j > -1) {
                                return `typeof prevStates[${j}] === 'object' ? prevStates[${j}].product : new Matrix(${m.rows}, ${m.columns})`;
                            }
                        // eslint-disable-next-line no-fallthrough
                        case state.product:
                            return `new Matrix(${m.rows}, ${m.columns})`;
                        default:
                            throw Error('unknown state');
                    }
                }
                if (m === state.product)
                    return `states[${i}].product`;
                if (m === state.right)
                    return `states[${i}].right`;
                if (m === state.left)
                    return `states[${i}].left`;
            }
            return '';
        }
        function matrixToString(m, stateIndex) {
            if (!m || !m.rows || !m.columns)
                return 'null';
            if (m === model.outputConnector)
                return `json.outputConnector`;
            if (m === model.output)
                return `json.output`;
            for (let i = 0, max = model.hiddenLayers.length; i < max; i++) {
                const hiddenLayer = model.hiddenLayers[i];
                for (const p in hiddenLayer) {
                    if (!hiddenLayer.hasOwnProperty(p))
                        continue;
                    if (hiddenLayer[p] !== m)
                        continue;
                    return `json.hiddenLayers[${i}].${p}`;
                }
            }
            return matrixOrigin(m, stateIndex);
        }
        function formatInputData() {
            if (!inputLookup)
                return '';
            if (inputSize === 1) {
                if (inputLookup === outputLookup) {
                    return `function lookupInput(input) {
            var table = ${JSON.stringify(inputLookup)};
            var result = [];
            for (var p in table) {
              if (!input.hasOwnProperty(p)) break;
              result.push(Float32Array.from([input[p]]));
            }
            return result;
          }`;
                }
                return `function lookupInput(input) {
          var table = ${JSON.stringify(inputLookup)};
          var result = [];
          for (var p in table) {
            result.push(Float32Array.from([input[p]]));
          }
          return result;
        }`;
            }
            return `function lookupInput(rawInputs) {
        var table = ${JSON.stringify(inputLookup)};
        var result = [];
        for (var i = 0; i < rawInputs.length; i++) {
          var rawInput = rawInputs[i];
          var input = new Float32Array(${inputLookupLength});
          for (var p in table) {
            input[table[p]] = rawInput.hasOwnProperty(p) ? rawInput[p] : 0;
          }
          result.push(input);
        }
        return result;
      }`;
        }
        function formatOutputData() {
            if (!outputLookup)
                return '';
            if (inputSize === 1) {
                if (inputLookup === outputLookup) {
                    return `function lookupOutputPartial(output, input) {
            var table = ${JSON.stringify(outputLookup)};
            var offset = input.length;
            var result = {};
            var i = 0;
            for (var p in table) {
              if (i++ < offset) continue;
              result[p] = output[table[p] - offset][0];
            }
            return result;
          }`;
                }
                return `function lookupOutput(output) {
          var table = ${JSON.stringify(outputLookup)};
          var result = {};
          for (var p in table) {
            result[p] = output[table[p]][0];
          }
          return result;
        }`;
            }
            return `function lookupOutput(output) {
        var table = ${JSON.stringify(outputLookup)};
        var result = {};
        for (var p in table) {
          result[p] = output[table[p]];
        }
        return result;
      }`;
        }
        function toInner(fnString) {
            // crude, but should be sufficient for now
            // function() { body }
            // crude, but should be sufficient for now
            // function() { body }
            const fnParts = fnString.toString().split('{');
            fnParts.shift();
            // body }
            const fnBodyString = fnParts.join('{');
            const fnBodyParts = fnBodyString.split('}');
            fnBodyParts.pop();
            // body
            return fnBodyParts
                .join('}')
                .split('\n')
                .join('\n        ')
                .replace('product.deltas[i] = 0;', '')
                .replace('product.deltas[column] = 0;', '')
                .replace('left.deltas[leftIndex] = 0;', '')
                .replace('right.deltas[rightIndex] = 0;', '')
                .replace('product.deltas = left.deltas.slice(0);', '');
        }
        function fileName(fnName) {
            return `src/recurrent/matrix/${fnName.replace(/[A-Z]/g, function (value) {
                return `-${value.toLowerCase()}`;
            })}.js`;
        }
        const statesRaw = [];
        const usedFunctionNames = {};
        const innerFunctionsSwitch = [];
        for (let i = 0, max = states.length; i < max; i++) {
            const state = states[i];
            statesRaw.push(`states[${i}] = {
      name: '${state.forwardFn.name}',
      left: ${state.left ? matrixToString(state.left, i) : 'undefined'},
      right: ${state.right ? matrixToString(state.right, i) : 'undefined'},
      product: ${matrixToString(state.product, i)}
    }`);
            const fnName = state.forwardFn.name;
            if (!usedFunctionNames[fnName]) {
                usedFunctionNames[fnName] = true;
                if (state.name === 'input') {
                    innerFunctionsSwitch.push(`case '${fnName}':`);
                    innerFunctionsSwitch.push(inputLookup && inputSize === 1
                        ? 'product.weights = _i < input.length ? input[_i]: prevStates[prevStates.length - 1].product.weights;'
                        : inputSize === 1
                            ? 'product.weights = [input[_i]];'
                            : 'product.weights = input[_i];');
                    innerFunctionsSwitch.push('break;');
                }
                else {
                    innerFunctionsSwitch.push(`        case '${fnName}':${fnName !== 'forwardFn'
                        ? ` //compiled from ${fileName(fnName)}`
                        : ''}
          ${toInner(state.forwardFn.toString())}
          break;`);
                }
            }
        }
        const forceForecast = inputSize === 1 && this.outputLookup;
        const src = `
  var input = ${this.inputLookup ? 'lookupInput(rawInput)' : 'rawInput'};
  var json = ${jsonString};
  var output = [];
  var states = [];
  var prevStates;
  var state;
  var max = ${forceForecast
            ? inputLookup === outputLookup
                ? inputLookupLength
                : `input.length + ${outputLookupLength - 1}`
            : 'input.length'};
  for (var _i = 0; _i < max; _i++) {
    prevStates = states;
    states = [];
    ${statesRaw.join(';\n    ')};
    for (var stateIndex = 0, stateMax = ${statesRaw.length}; stateIndex < stateMax; stateIndex++) {
      state = states[stateIndex];
      var product = state.product;
      var left = state.left;
      var right = state.right;

      switch (state.name) {
${innerFunctionsSwitch.join('\n')}
      }
    }
    ${inputSize === 1 && inputLookup
            ? 'if (_i >= input.length - 1) { output.push(state.product.weights); }'
            : 'output = state.product.weights;'}
  }
  ${outputLookup
            ? outputLookup === inputLookup
                ? 'return lookupOutputPartial(output, input)'
                : 'return lookupOutput(output)'
            : inputSize === 1
                ? 'return output[0]'
                : 'return output'};
  ${formatInputData()}
  ${formatOutputData()}

  function Matrix(rows, columns) {
    this.rows = rows;
    this.columns = columns;
    this.weights = zeros(rows * columns);
  }
  ${zeros$1.toString()}
  ${softmax.toString().replace('_2.default', 'Matrix')}
  ${randomFloat.toString()}
  ${sampleI.toString()}
  ${maxI.toString()}`;
        // eslint-disable-next-line
        return new Function('rawInput', cb ? cb(src) : src);
    }
}
const trainDefaults = { ...trainDefaults$1 };

class GRUTimeStep extends RNNTimeStep {
    getHiddenLayer(hiddenSize, prevSize) {
        return getGRUHiddenLayer(hiddenSize, prevSize);
    }
    getEquation(equation, inputMatrix, previousResult, hiddenLayer) {
        return getGRUEquation(equation, inputMatrix, previousResult, hiddenLayer);
    }
}

class LSTM extends RNN {
    getHiddenLayer(hiddenSize, prevSize) {
        return getHiddenLSTMLayer(hiddenSize, prevSize);
    }
    getEquation(equation, inputMatrix, previousResult, hiddenLayer) {
        return getLSTMEquation(equation, inputMatrix, previousResult, hiddenLayer);
    }
}
function getHiddenLSTMLayer(hiddenSize, prevSize) {
    return {
        // gates parameters
        // wix
        inputMatrix: new RandomMatrix(hiddenSize, prevSize, 0.08),
        inputHidden: new RandomMatrix(hiddenSize, hiddenSize, 0.08),
        inputBias: new Matrix(hiddenSize, 1),
        // wfx
        forgetMatrix: new RandomMatrix(hiddenSize, prevSize, 0.08),
        forgetHidden: new RandomMatrix(hiddenSize, hiddenSize, 0.08),
        forgetBias: new Matrix(hiddenSize, 1),
        // wox
        outputMatrix: new RandomMatrix(hiddenSize, prevSize, 0.08),
        outputHidden: new RandomMatrix(hiddenSize, hiddenSize, 0.08),
        outputBias: new Matrix(hiddenSize, 1),
        // cell write params
        // wcx
        cellActivationMatrix: new RandomMatrix(hiddenSize, prevSize, 0.08),
        cellActivationHidden: new RandomMatrix(hiddenSize, hiddenSize, 0.08),
        cellActivationBias: new Matrix(hiddenSize, 1),
    };
}
function getLSTMEquation(equation, inputMatrix, previousResult, hiddenLayer) {
    if (!hiddenLayer.inputMatrix ||
        !hiddenLayer.inputHidden ||
        !hiddenLayer.inputBias ||
        !hiddenLayer.forgetMatrix ||
        !hiddenLayer.forgetHidden ||
        !hiddenLayer.forgetBias ||
        !hiddenLayer.outputMatrix ||
        !hiddenLayer.outputHidden ||
        !hiddenLayer.outputBias ||
        !hiddenLayer.cellActivationMatrix ||
        !hiddenLayer.cellActivationHidden ||
        !hiddenLayer.cellActivationBias) {
        throw new Error('hiddenLayer does not have expected properties');
    }
    const sigmoid = equation.sigmoid.bind(equation);
    const add = equation.add.bind(equation);
    const multiply = equation.multiply.bind(equation);
    const multiplyElement = equation.multiplyElement.bind(equation);
    const tanh = equation.tanh.bind(equation);
    const inputGate = sigmoid(add(add(multiply(hiddenLayer.inputMatrix, inputMatrix), multiply(hiddenLayer.inputHidden, previousResult)), hiddenLayer.inputBias));
    const forgetGate = sigmoid(add(add(multiply(hiddenLayer.forgetMatrix, inputMatrix), multiply(hiddenLayer.forgetHidden, previousResult)), hiddenLayer.forgetBias));
    // output gate
    const outputGate = sigmoid(add(add(multiply(hiddenLayer.outputMatrix, inputMatrix), multiply(hiddenLayer.outputHidden, previousResult)), hiddenLayer.outputBias));
    // write operation on cells
    const cellWrite = tanh(add(add(multiply(hiddenLayer.cellActivationMatrix, inputMatrix), multiply(hiddenLayer.cellActivationHidden, previousResult)), hiddenLayer.cellActivationBias));
    // compute new cell activation
    const retainCell = multiplyElement(forgetGate, previousResult); // what do we keep from cell
    const writeCell = multiplyElement(inputGate, cellWrite); // what do we write to cell
    const cell = add(retainCell, writeCell); // new cell contents
    // compute hidden state as gated, saturated cell activations
    return multiplyElement(outputGate, tanh(cell));
}

class LSTMTimeStep extends RNNTimeStep {
    getHiddenLayer(hiddenSize, prevSize) {
        return getHiddenLSTMLayer(hiddenSize, prevSize);
    }
    getEquation(equation, inputMatrix, previousResult, hiddenLayer) {
        return getLSTMEquation(equation, inputMatrix, previousResult, hiddenLayer);
    }
}

/**
 *
 * @param start
 * @param end
 * @returns {Array}
 */
function range(start, end) {
    const result = [];
    for (; start < end; start++) {
        result.push(start);
    }
    return result;
}

function toArray(values) {
    if (Array.isArray(values)) {
        return Float32Array.from(values);
    }
    return Float32Array.from(Object.values(values));
}

function drawInput({ pixelX, pixelY, radius, inputs, row, line, fontSize, fontClassName, }) {
    let svg = `<rect
              x="${pixelX / 2 - radius}"
              y="${pixelY / 2 + row * pixelY - radius}"
              width="${2 * radius}"
              height="${2 * radius}"
              stroke="black"
              stroke-width="1"
              fill="${inputs.color}"
              class="${inputs.className}" />
            <line
              x1="${pixelX / 4}"
              y1="${pixelY / 2 + row * pixelY}"
              x2="${pixelX / 2 - radius}"
              y2="${pixelY / 2 + row * pixelY}"
              style="stroke:${line.color};stroke-width:${line.width}"
              class="${line.className}" />`;
    if (inputs.labels) {
        svg += `<text
              x="${pixelX / 8}"
              y="${pixelY / 2 + row * pixelY - 5}"
              fill="black"
              font-size="${fontSize}"
              class="${fontClassName}">${inputs.labels[row]}</text>`;
    }
    return svg;
}
function drawNeuron({ pixelX, pixelY, row, column, radius, hidden, }) {
    return `<circle
            cx="${pixelX / 2 + column * pixelX}"
            cy="${pixelY / 2 + row * pixelY}"
            r="${radius}"
            stroke="black"
            stroke-width="1"
            fill="${hidden.color}"
            class="${hidden.className}" />`;
}
function drawOutput({ pixelX, pixelY, row, column, line, outputs, radius, }) {
    return `<circle
            cx="${pixelX / 2 + column * pixelX}"
            cy="${pixelY / 2 + row * pixelY}"
            r="${radius}"
            stroke="black"
            stroke-width="1"
            fill="${outputs.color}"
            class="${outputs.className}" />
          <line
            x1="${pixelX / 2 + column * pixelX + radius}"
            y1="${pixelY / 2 + row * pixelY}"
            x2="${pixelX / 2 + column * pixelX + pixelX / 4}"
            y2="${pixelY / 2 + row * pixelY}"
            style="stroke:${line.color};stroke-width:${line.width}"
            class="${line.className}" />`;
}
function drawBackwardConnections({ pixelX, pixelY, row, column, radius, lineY, line, previousConnectionIndex, }) {
    return `<line
            x1="${pixelX / 2 + (column - 1) * pixelX + radius}"
            y1="${lineY / 2 + previousConnectionIndex * lineY}"
            x2="${pixelX / 2 + column * pixelX - radius}"
            y2="${pixelY / 2 + row * pixelY}"
            style="stroke:${line.color};stroke-width:${line.width}"
            class="${line.className}" />`;
}
function neuralNetworkToInnerSVG(options) {
    const { sizes, height, width } = options;
    let svg = '';
    const pixelX = width / sizes.length;
    for (let column = 0; column < sizes.length; column++) {
        const size = sizes[column];
        const pixelY = height / size;
        for (let row = 0; row < size; row++) {
            if (column === 0) {
                svg += drawInput({ pixelX, pixelY, row, column, ...options });
            }
            else {
                if (column === sizes.length - 1) {
                    svg += drawOutput({ pixelX, pixelY, row, column, ...options });
                }
                else {
                    svg += drawNeuron({ pixelX, pixelY, row, column, ...options });
                }
                const previousSize = sizes[column - 1];
                const lineY = height / previousSize;
                for (let previousConnectionIndex = 0; previousConnectionIndex < previousSize; previousConnectionIndex++) {
                    svg += drawBackwardConnections({
                        pixelX,
                        pixelY,
                        row,
                        column,
                        lineY,
                        previousConnectionIndex,
                        ...options,
                    });
                }
            }
        }
    }
    return svg;
}
function drawRecurrentConnections({ pixelX, pixelY, row, column, radius, recurrentLine, }) {
    const moveX = pixelX / 2 + column * pixelX + radius + 1;
    const moveY = pixelY / 2 + row * pixelY;
    const x = moveX - radius * 2 - 2;
    const y = moveY;
    const x1 = x + 100;
    const y1 = y + 50;
    const x2 = moveX - 100;
    const y2 = moveY + 50;
    return `<path
              d="M ${moveX} ${moveY} C ${x1} ${y1}, ${x2} ${y2}, ${x} ${y}"
              stroke="${recurrentLine.color}"
              stroke-width="${recurrentLine.width}"
              fill="transparent"
              stroke-linecap="round"
              marker-end="url(#arrow)"
              class="${recurrentLine.className}" />`;
}
function rnnToInnerSVG(options) {
    const { width, height, recurrentLine, sizes, radius } = options;
    const pixelX = width / sizes.length;
    let svg = `<defs>
              <marker id="arrow" markerWidth="10" markerHeight="10" refX="8" refY="3" orient="auto" markerUnits="strokeWidth">
                <path d="M0,0 L0,6 L9,3 z" fill="${recurrentLine.color}" />
              </marker>
            </defs>`;
    svg += neuralNetworkToInnerSVG(options);
    for (let column = 1; column < sizes.length; column++) {
        const size = sizes[column];
        const pixelY = height / size;
        for (let row = 0; row < size; row++) {
            svg += drawRecurrentConnections({
                pixelX,
                pixelY,
                row,
                column,
                radius,
                recurrentLine,
            });
        }
    }
    return svg;
}
function getFeedForwardLayers(network) {
    const { options } = network;
    if (!options) {
        throw new Error('options not defined');
    }
    if (!options.inputLayer) {
        throw new Error('options.inputLater not defined');
    }
    if (!options.hiddenLayers) {
        throw new Error('options.hiddenLayers not defined');
    }
    if (options.hiddenLayers.length < 1) {
        throw new Error('options.hiddenLayers is empty');
    }
    if (!options.outputLayer) {
        throw new Error('options.outputLayer not defined');
    }
    const inputLayer = options.inputLayer();
    const hiddenLayers = [];
    hiddenLayers.push(options.hiddenLayers[0](inputLayer, 0));
    for (let i = 1; i < options.hiddenLayers.length; i++) {
        hiddenLayers.push(options.hiddenLayers[i](hiddenLayers[i - 1], i));
    }
    const outputLayer = options.outputLayer(hiddenLayers[hiddenLayers.length - 1], hiddenLayers.length);
    return {
        inputSize: inputLayer.height,
        hiddenLayers: hiddenLayers.map((hiddenLayer) => hiddenLayer.height),
        outputSize: outputLayer.height,
    };
}
function getRecurrentLayers(network) {
    const hiddenLayers = [];
    const { options } = network;
    if (!options.inputLayer) {
        throw new Error('inputLayer not defined');
    }
    if (!options.outputLayer) {
        throw new Error('outputLayer not defined');
    }
    const inputLayer = options.inputLayer();
    hiddenLayers.push(options.hiddenLayers[0](inputLayer, recurrentZeros(), 0));
    for (let i = 1; i < options.hiddenLayers.length; i++) {
        hiddenLayers.push(options.hiddenLayers[i](hiddenLayers[i - 1], recurrentZeros(), i));
    }
    const outputLayer = options.outputLayer(hiddenLayers[hiddenLayers.length - 1], -1);
    return {
        inputSize: inputLayer.height,
        hiddenLayers: hiddenLayers.map((hiddenLayer) => hiddenLayer.height),
        outputSize: outputLayer.height,
    };
}
function wrapOuterSVG(svgBody, width, height) {
    // language=html
    return `<svg
            xmlns="http://www.w3.org/2000/svg"
            xmlns:xlink="http://www.w3.org/1999/xlink"
            version="1.1"
            width="${width}"
            height="${height}">${svgBody}</svg>`;
}
function getNeuralNetworkJSONSizes(json) {
    return json.sizes;
}
function getNeuralNetworkSizes(net) {
    const { options, sizes } = net;
    const { inputSize, outputSize, hiddenLayers } = options;
    if (!sizes) {
        if (typeof inputSize === 'number' && inputSize < 1) {
            throw new Error('inputSize not set');
        }
        if (typeof outputSize === 'number' && outputSize < 1) {
            throw new Error('outputSize not set');
        }
        if (hiddenLayers === null || hiddenLayers === void 0 ? void 0 : hiddenLayers.some((v) => v < 1)) {
            throw new Error('hiddenLayers not set');
        }
    }
    return typeof inputSize === 'number' &&
        Array.isArray(hiddenLayers) &&
        typeof outputSize === 'number'
        ? [inputSize].concat(hiddenLayers).concat([outputSize])
        : sizes;
}
function getRNNSizes(net) {
    const { options } = net;
    const { inputSize, outputSize, hiddenLayers } = options;
    return [inputSize].concat(hiddenLayers).concat([outputSize]);
}
function defaultOptions() {
    return {
        line: {
            width: 0.5,
            color: 'black',
            className: 'connection',
        },
        recurrentLine: {
            width: 1,
            color: 'red',
            className: 'recurrence',
        },
        inputs: {
            color: 'rgba(0, 128, 0, 0.5)',
            labels: null,
            className: 'input',
        },
        outputs: {
            color: 'rgba(100, 149, 237, 0.5)',
            className: 'output',
        },
        hidden: {
            color: 'rgba(255, 127, 80, 0.5)',
            className: 'hidden-neuron',
        },
        fontSize: '14px',
        fontClassName: 'label',
        radius: 8,
        width: 400,
        height: 250,
        sizes: [],
    };
}
function toSVG(net, options) {
    const mergedOptions = { ...defaultOptions(), ...options };
    const { width, height, inputs } = mergedOptions;
    // Get network size array for NeuralNetwork or NeuralNetworkGPU
    let sizes = [];
    if (net instanceof NeuralNetwork || net instanceof NeuralNetworkGPU) {
        sizes = getNeuralNetworkSizes(net);
    }
    // get network size for Recurrent
    else if (net instanceof Recurrent) {
        const { inputSize, hiddenLayers, outputSize } = getRecurrentLayers(net);
        sizes = [inputSize].concat(hiddenLayers).concat([outputSize]);
    }
    // get network size for FeedForward
    else if (net instanceof FeedForward) {
        const { inputSize, hiddenLayers, outputSize } = getFeedForwardLayers(net);
        sizes = [inputSize].concat(hiddenLayers).concat([outputSize]);
    }
    // handle json, recurrent first
    else if (net instanceof RNN ||
        net instanceof LSTM ||
        net instanceof GRU ||
        net instanceof RNNTimeStep ||
        net instanceof LSTMTimeStep ||
        net instanceof GRUTimeStep) {
        return wrapOuterSVG(rnnToInnerSVG({
            ...mergedOptions,
            sizes: checkSizes(getRNNSizes(net), inputs.labels),
        }), width, height);
    }
    // handle json, NeuralNetwork
    else if (net.hasOwnProperty('type')) {
        switch (net.type) {
            case 'NeuralNetwork':
            case 'NeuralNetworkGPU':
                return wrapOuterSVG(neuralNetworkToInnerSVG({
                    ...mergedOptions,
                    sizes: checkSizes(getNeuralNetworkJSONSizes(net), inputs.labels),
                }), width, height);
            case 'RNN':
            case 'GRU':
            case 'LSTM':
            case 'RNNTimeStep':
            case 'GRUTimeStep':
            case 'LSTMTimeStep':
                return wrapOuterSVG(rnnToInnerSVG({
                    ...mergedOptions,
                    sizes: checkSizes(getRNNSizes(net), inputs.labels),
                }), width, height);
            default:
                throw new Error('unrecognized network');
        }
    }
    else if (net.hasOwnProperty('inputSize') &&
        net.hasOwnProperty('hiddenLayers') &&
        net.hasOwnProperty('outputSize')) {
        const { inputSize, hiddenLayers, outputSize } = net;
        sizes = [inputSize, ...hiddenLayers, outputSize];
    }
    else if (net.hasOwnProperty('sizes')) {
        sizes = net.sizes;
    }
    else {
        throw new Error('unrecognized network');
    }
    return wrapOuterSVG(neuralNetworkToInnerSVG({
        ...mergedOptions,
        sizes: checkSizes(sizes, inputs.labels),
    }), width, height);
}
function checkSizes(sizes, labels) {
    if (!sizes) {
        throw new Error('sizes not set');
    }
    if (sizes.some((size) => size < 1)) {
        throw new Error('sizes not set correctly');
    }
    if (labels && labels.length !== sizes[0]) {
        throw new Error('not enough labels for inputs');
    }
    return sizes;
}

const recurrent = {
    RNNTimeStep,
    LSTMTimeStep,
    GRUTimeStep,
    RNN,
    LSTM,
    GRU,
};
const utilities = {
    max,
    mse: mse$1,
    ones: ones$1,
    ones2D,
    random: random$1,
    randomWeight,
    randos,
    range,
    toArray,
    DataFormatter,
    zeros: zeros$1,
    toSVG,
};

class TrainStream extends stream.Writable {
    constructor(options) {
        super({
            objectMode: true,
        });
        // require the neuralNetwork
        if (!options.neuralNetwork) {
            throw new Error('No neural network specified. Please see list of available network types: https://github.com/BrainJS/brain.js#neural-network-types');
        }
        const { neuralNetwork } = options;
        // inherit trainOpts settings from neuralNetwork
        neuralNetwork.updateTrainingOptions(options);
        const trainOpts = neuralNetwork === null || neuralNetwork === void 0 ? void 0 : neuralNetwork.trainOpts; // just updated from above line
        this.neuralNetwork = neuralNetwork;
        this.dataFormatDetermined = false;
        this.i = 0; // keep track of internal iterations
        this.size = 0;
        this.count = 0;
        this.sum = 0;
        this.floodCallback = options.floodCallback;
        this.doneTrainingCallback = options.doneTrainingCallback;
        this.iterations = trainOpts.iterations;
        this.errorThresh = trainOpts.errorThresh;
        this.log = trainOpts.log;
        this.logPeriod = trainOpts.logPeriod;
        this.callbackPeriod = trainOpts.callbackPeriod;
        this.on('finish', this.finishStreamIteration.bind(this));
        this.callback = trainOpts.callback;
    }
    endInputs() {
        this.write(false);
    }
    _write(chunk, enc, next) {
        if (!chunk) {
            // check for the end of one iteration of the stream
            this.emit('finish');
            return next();
        }
        if (!this.dataFormatDetermined) {
            this.size++;
            this.neuralNetwork.addFormat(chunk);
            if (this.firstDatum === undefined) {
                this.firstDatum = chunk;
            }
            return next();
        }
        this.count++;
        const data = this.neuralNetwork.formatData([chunk]);
        const error = this.neuralNetwork.trainPattern(data[0], true);
        if (error !== null) {
            this.sum += error;
        }
        // tell the Readable Stream that we are ready for more data
        next();
    }
    finishStreamIteration() {
        if (this.dataFormatDetermined && this.size !== this.count) {
            console.warn("This iteration's data length was different from the first!");
        }
        if (!this.dataFormatDetermined && this.firstDatum !== undefined) {
            const data = this.neuralNetwork.formatData([this.firstDatum]);
            this.neuralNetwork.verifyIsInitialized(data);
            this.dataFormatDetermined = true;
            if (typeof this.floodCallback === 'function') {
                this.floodCallback();
            }
            return;
        }
        const error = this.sum / this.size;
        if (this.log && this.i % this.logPeriod === 0) {
            if (typeof this.log === 'function') {
                this.log({
                    iterations: this.i,
                    error: error,
                });
            }
            else {
                console.info(`iterations: ${this.i}, training error: ${error}`);
            }
        }
        if (this.callback && this.i % this.callbackPeriod === 0) {
            this.callback({
                error,
                iterations: this.i,
            });
        }
        this.sum = 0;
        this.count = 0;
        // update the iterations
        this.i++;
        // do a check here to see if we need the stream again
        if (this.i < this.iterations && error > this.errorThresh) {
            if (typeof this.floodCallback === 'function') {
                return this.floodCallback();
            }
        }
        else {
            // done training
            if (typeof this.doneTrainingCallback === 'function') {
                return this.doneTrainingCallback({
                    error,
                    iterations: this.i,
                });
            }
        }
    }
}

exports.CrossValidate = CrossValidate;
exports.FeedForward = FeedForward;
exports.NeuralNetwork = NeuralNetwork;
exports.NeuralNetworkGPU = NeuralNetworkGPU;
exports.Recurrent = Recurrent;
exports.TrainStream = TrainStream;
exports.activation = index$1;
exports.layer = layer;
exports.layerTypes = layerTypes;
exports.likely = likely;
exports.lookup = lookup;
exports.praxis = index;
exports.recurrent = recurrent;
exports.utilities = utilities;
//# sourceMappingURL=index.map


/***/ }),

/***/ "./pages/_app.tsx":
/*!************************!*\
  !*** ./pages/_app.tsx ***!
  \************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @chakra-ui/react */ "@chakra-ui/react");
/* harmony import */ var _chakra_ui_react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _src_context_BrainContext__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../src/context/BrainContext */ "./src/context/BrainContext.tsx");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__);
var _jsxFileName = "/home/vittis/dev/github/covid-prediction/pages/_app.tsx";

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }






const MyApp = ({
  Component,
  pageProps
}) => {
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.ChakraProvider, {
    children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)(_src_context_BrainContext__WEBPACK_IMPORTED_MODULE_2__.BrainProvider, {
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)(Component, _objectSpread({}, pageProps), void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 10,
        columnNumber: 9
      }, undefined)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 9,
      columnNumber: 7
    }, undefined)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 8,
    columnNumber: 5
  }, undefined);
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (MyApp);

/***/ }),

/***/ "./src/context/BrainContext.tsx":
/*!**************************************!*\
  !*** ./src/context/BrainContext.tsx ***!
  \**************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "BrainContext": () => (/* binding */ BrainContext),
/* harmony export */   "BrainProvider": () => (/* binding */ BrainProvider),
/* harmony export */   "useBrainContext": () => (/* binding */ useBrainContext)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _services_api__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../services/api */ "./src/services/api.ts");
/* harmony import */ var brain_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! brain.js */ "./node_modules/brain.js/dist/src/index");
/* harmony import */ var _utils_scaler__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../utils/scaler */ "./src/utils/scaler.ts");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__);
var _jsxFileName = "/home/vittis/dev/github/covid-prediction/src/context/BrainContext.tsx";


 // import scaler from 'minmaxscaler'



const BrainContext = /*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_0__.createContext)({});
const BrainProvider = ({
  children
}) => {
  const {
    0: training,
    1: setTraining
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
  const {
    0: dailyData,
    1: setDailyData
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)([]);
  const {
    0: globalData,
    1: setGlobalData
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)({});
  const {
    0: trainingData,
    1: setTrainingData
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)([]);
  const {
    0: daysInput,
    1: setDaysInput
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)('');
  const {
    0: prediction,
    1: setPrediction
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)([]);
  const predictedChartData = {
    data: {
      labels: prediction.map((n, index) => index),
      datasets: [{
        data: prediction.map(data => data),
        label: 'Infected',
        borderColor: 'rgb(53, 162, 235)',
        backgroundColor: 'rgba(53, 162, 235, 0.5)'
      }]
    },
    options: {
      responsive: true,
      plugins: {
        legend: {
          position: 'top'
        },
        title: {
          display: true,
          text: 'Your Covid-19 infection forecasting'
        }
      }
    }
  };
  const trainingChartData = {
    data: {
      labels: trainingData.map(({
        date
      }) => new Date(date).toLocaleDateString()),
      datasets: [{
        data: trainingData.map(data => data.confirmed),
        label: 'Infected',
        borderColor: 'rgb(53, 162, 235)',
        backgroundColor: 'rgba(53, 162, 235, 0.5)'
      }, {
        data: trainingData.map(data => data.deaths),
        label: 'Deaths',
        borderColor: 'rgb(255, 99, 132)',
        backgroundColor: 'rgba(255, 99, 132, 0.5)'
      }]
    },
    options: {
      responsive: true,
      plugins: {
        legend: {
          position: 'top'
        },
        title: {
          display: true,
          text: 'AI training data'
        }
      }
    }
  };

  const forecast = (trainingData, daysInput) => {
    setTraining(true);
    const newTrainingData = new Array(50).fill(0);

    if (trainingData) {
      for (let i = 0; i <= 50; i++) {
        var _trainingData;

        newTrainingData[i] = (_trainingData = trainingData[trainingData.length - 51 + i]) === null || _trainingData === void 0 ? void 0 : _trainingData.confirmed;
      }
    }

    const scaledData = _utils_scaler__WEBPACK_IMPORTED_MODULE_3__.default.fit_transform(newTrainingData);
    const network = new brain_js__WEBPACK_IMPORTED_MODULE_2__.recurrent.LSTMTimeStep({
      inputSize: 1,
      hiddenLayers: [10],
      outputSize: 1
    });
    network.train([scaledData], {
      learningRate: 0.005,
      errorThresh: 0.01,
      log: stats => {
        console.log(stats);
      }
    });
    const result = network.forecast([1], daysInput);
    setPrediction(_utils_scaler__WEBPACK_IMPORTED_MODULE_3__.default.inverse_transform(result));
    setTraining(false);
  };

  (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
    const loadDailyData = async () => {
      const initialDailyData = await (0,_services_api__WEBPACK_IMPORTED_MODULE_1__.fetchDailyData)();

      if (initialDailyData) {
        setDailyData(initialDailyData);
      }
    };

    const loadGlobalData = async () => {
      const globalData = await (0,_services_api__WEBPACK_IMPORTED_MODULE_1__.fetchGlobalData)();

      if (globalData) {
        setGlobalData(globalData);
      }
    };

    loadDailyData();
    loadGlobalData();
  }, []);
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)(BrainContext.Provider, {
    value: {
      trainingData,
      setTrainingData,
      setDailyData,
      dailyData,
      trainingChartData,
      forecast,
      daysInput,
      setDaysInput,
      prediction,
      predictedChartData,
      training
    },
    children: children
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 208,
    columnNumber: 5
  }, undefined);
}; //easier export

const useBrainContext = () => (0,react__WEBPACK_IMPORTED_MODULE_0__.useContext)(BrainContext);

/***/ }),

/***/ "./src/services/api.ts":
/*!*****************************!*\
  !*** ./src/services/api.ts ***!
  \*****************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "api": () => (/* binding */ api),
/* harmony export */   "fetchGlobalData": () => (/* binding */ fetchGlobalData),
/* harmony export */   "fetchDailyData": () => (/* binding */ fetchDailyData)
/* harmony export */ });
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! axios */ "axios");
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_0__);

const api = axios__WEBPACK_IMPORTED_MODULE_0___default().create({
  baseURL: 'https://covid-19-statistics.p.rapidapi.com/reports'
});
api.defaults.headers['x-rapidapi-host'] = 'covid-19-statistics.p.rapidapi.com';
api.defaults.headers['x-rapidapi-key'] = '0b8b88299dmsh633d177b4830bb2p1f4e62jsn9a410c7e91fc';
api.interceptors.request.use(config => {
  console.log(config);
  return config;
});
const fetchGlobalData = async () => {
  try {
    const {
      data
    } = await api.get('/total');
    return data;
  } catch (err) {
    return err;
  }
};
const fetchDailyData = async () => {
  try {
    const {
      data
    } = await axios__WEBPACK_IMPORTED_MODULE_0___default().get('https://api.covidtracking.com/v1/us/daily.json');
    return data.map(({
      positive,
      recovered,
      death,
      dateChecked: date
    }) => ({
      confirmed: positive,
      recovered,
      deaths: death,
      date
    }));
  } catch (error) {
    return error;
  }
};

/***/ }),

/***/ "./src/utils/scaler.ts":
/*!*****************************!*\
  !*** ./src/utils/scaler.ts ***!
  \*****************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
let X_min = 0;
let X_max = 0;
let min_ = 0;
let max_ = 1;
let data = {
  X_max: X_max,
  X_min: X_min,
  max_: max_,
  min_: min_
};

function fit(X, min = 0, max = 1) {
  X_max = Math.max.apply(null, X);
  X_min = Math.min.apply(null, X);
  min_ = min;
  max_ = max;
  data = {
    X_max: X_max,
    X_min: X_min,
    max_: max_,
    min_: min_
  };
  const X_minArr = X.map(function (values) {
    return values - X_min;
  }); // X_std = (X - X.min()) / (X.max() - X.min())

  const X_std = X_minArr.map(function (values) {
    return values / (X_max - X_min);
  }); // X_scaled = X_std * (max - min) + min

  const X_scaled = X_std.map(function (values) {
    return values * (max - min) + min;
  });
  return X_scaled;
}

function fit_transform(data, min = 0, max = 1) {
  const train_scaled = fit(data, min, max);
  return train_scaled;
}

function inverse_transform(input, min = 0, max = 1) {
  const fit = data;
  console.log(fit);
  const X = input.map(function (values) {
    return (values - min) / (max - min);
  });
  const X_ = X.map(function (values) {
    return values * (fit.X_max - fit.X_min) + fit.X_min;
  });
  return X_;
}

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  fit_transform,
  inverse_transform
});

/***/ }),

/***/ "@chakra-ui/react":
/*!***********************************!*\
  !*** external "@chakra-ui/react" ***!
  \***********************************/
/***/ ((module) => {

module.exports = require("@chakra-ui/react");

/***/ }),

/***/ "axios":
/*!************************!*\
  !*** external "axios" ***!
  \************************/
/***/ ((module) => {

module.exports = require("axios");

/***/ }),

/***/ "gpu.js":
/*!*************************!*\
  !*** external "gpu.js" ***!
  \*************************/
/***/ ((module) => {

module.exports = require("gpu.js");

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

module.exports = require("react/jsx-dev-runtime");

/***/ }),

/***/ "stream":
/*!*************************!*\
  !*** external "stream" ***!
  \*************************/
/***/ ((module) => {

module.exports = require("stream");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("./pages/_app.tsx"));
module.exports = __webpack_exports__;

})();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicGFnZXMvX2FwcC5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7O0FBQWE7O0FBRWIsOENBQTZDLEVBQUUsYUFBYSxFQUFDOztBQUU3RCxhQUFhLG1CQUFPLENBQUMsc0JBQVE7QUFDN0IsYUFBYSxtQkFBTyxDQUFDLHNCQUFROztBQUU3QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLENBQUM7O0FBRUQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsQ0FBQzs7QUFFRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQSxDQUFDOztBQUVEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsQ0FBQzs7QUFFRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxDQUFDOztBQUVEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxhQUFhO0FBQ2I7QUFDQTtBQUNBO0FBQ0E7QUFDQSxhQUFhO0FBQ2I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsdUNBQXVDLE9BQU87QUFDOUM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSw4QkFBOEI7QUFDOUI7QUFDQSxrRUFBa0UsYUFBYSxhQUFhLEVBQUU7QUFDOUY7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSx3QkFBd0IsT0FBTztBQUMvQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSx3Q0FBd0MsYUFBYTtBQUNyRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSx3Q0FBd0MsYUFBYTtBQUNyRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLDJCQUEyQixhQUFhO0FBQ3hDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLDRCQUE0QixrQkFBa0I7QUFDOUM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsNEJBQTRCLGtCQUFrQjtBQUM5QztBQUNBLGdDQUFnQyxnQkFBZ0I7QUFDaEQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsNEJBQTRCLGtCQUFrQjtBQUM5QztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSw0QkFBNEIsa0JBQWtCO0FBQzlDO0FBQ0E7QUFDQSxnQ0FBZ0MsZ0JBQWdCO0FBQ2hEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLG9CQUFvQiwyQkFBMkI7QUFDL0Msd0JBQXdCLDBCQUEwQjtBQUNsRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxrQkFBa0IsZUFBZTtBQUNqQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxhQUFhO0FBQ2I7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBLFNBQVM7QUFDVDtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBLFNBQVM7QUFDVDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBLFNBQVM7QUFDVDtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLDhCQUE4QjtBQUM5QjtBQUNBO0FBQ0EsOEJBQThCO0FBQzlCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxnQkFBZ0IsaUNBQWlDO0FBQ2pEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSwrQkFBK0Isc0JBQXNCO0FBQ3JEO0FBQ0E7QUFDQSwrQkFBK0Isc0JBQXNCO0FBQ3JEO0FBQ0EsVUFBVTtBQUNWO0FBQ0EsK0JBQStCLHNCQUFzQjtBQUNyRDtBQUNBO0FBQ0EsK0JBQStCLHNCQUFzQjtBQUNyRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsK0JBQStCLHNCQUFzQjtBQUNyRDtBQUNBO0FBQ0EsK0JBQStCLHNCQUFzQjtBQUNyRDtBQUNBLFVBQVU7QUFDVjtBQUNBLCtCQUErQixzQkFBc0I7QUFDckQ7QUFDQTtBQUNBLCtCQUErQixzQkFBc0I7QUFDckQ7QUFDQTtBQUNBO0FBQ0E7QUFDQSxNQUFNO0FBQ047QUFDQTtBQUNBLCtCQUErQix1QkFBdUI7QUFDdEQ7QUFDQTtBQUNBLCtCQUErQix1QkFBdUI7QUFDdEQ7QUFDQTtBQUNBLCtCQUErQix1QkFBdUI7QUFDdEQ7QUFDQTtBQUNBLCtCQUErQix1QkFBdUI7QUFDdEQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLCtCQUErQix1QkFBdUIsd0JBQXdCLGFBQWEsU0FBUyxXQUFXO0FBQy9HO0FBQ0E7QUFDQSwrQkFBK0IsdUJBQXVCLHdCQUF3QixjQUFjLFNBQVMsWUFBWTtBQUNqSDtBQUNBO0FBQ0E7QUFDQSxtQ0FBbUMsdUJBQXVCO0FBQzFEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxtQ0FBbUMsdUJBQXVCO0FBQzFEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGdCQUFnQixzQkFBc0I7QUFDdEM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsZ0JBQWdCLFVBQVU7QUFDMUI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsYUFBYTtBQUNiO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGlCQUFpQjtBQUNqQixhQUFhO0FBQ2I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxvQkFBb0IsWUFBWTtBQUNoQztBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esb0JBQW9CLFdBQVc7QUFDL0I7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQSxnQkFBZ0IsdUJBQXVCO0FBQ3ZDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esd0NBQXdDLFlBQVkscUNBQXFDLHNCQUFzQjtBQUMvRztBQUNBO0FBQ0EseUNBQXlDLGFBQWEsc0NBQXNDLHVCQUF1QjtBQUNuSDtBQUNBO0FBQ0Esd0NBQXdDLFlBQVkscUNBQXFDLHNCQUFzQjtBQUMvRztBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGFBQWE7QUFDYjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsYUFBYTtBQUNiO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0EsbUJBQW1CLEtBQUssR0FBRyxXQUFXLE1BQU0saUJBQWlCO0FBQzdELGVBQWUsUUFBUTtBQUN2QixpQkFBaUI7QUFDakI7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTLElBQUk7QUFDYjtBQUNBLEtBQUs7QUFDTDtBQUNBLG1CQUFtQixLQUFLLEdBQUcsV0FBVyxNQUFNLGlCQUFpQjtBQUM3RDtBQUNBO0FBQ0E7QUFDQTtBQUNBLHdCQUF3QixzQkFBc0I7QUFDOUM7QUFDQSw0QkFBNEIsb0JBQW9CO0FBQ2hEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0E7QUFDQSxnQ0FBZ0MseUJBQXlCO0FBQ3pEO0FBQ0EsNEJBQTRCLGtCQUFrQjtBQUM5QztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQTtBQUNBLGdDQUFnQyx5QkFBeUI7QUFDekQ7QUFDQSw0QkFBNEIsbUJBQW1CO0FBQy9DO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQSxrQkFBa0IsWUFBWSxJQUFJLFdBQVc7QUFDN0M7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHdCQUF3QixpQkFBaUI7QUFDekM7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0Esa0JBQWtCLFdBQVcsR0FBRyxNQUFNO0FBQ3RDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0Esd0JBQXdCLG9CQUFvQjtBQUM1QztBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQSxrQkFBa0IsV0FBVyxhQUFhLFdBQVc7QUFDckQsZUFBZSxRQUFRO0FBQ3ZCLGVBQWUsT0FBTztBQUN0QixpQkFBaUI7QUFDakI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7O0FBRUE7QUFDQSw0Q0FBNEM7QUFDNUM7QUFDQSwwQkFBMEI7QUFDMUI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLCtCQUErQix1QkFBdUIsd0JBQXdCLGNBQWMsU0FBUyxXQUFXO0FBQ2hIO0FBQ0E7QUFDQSwrQkFBK0IsdUJBQXVCLHdCQUF3QixlQUFlLFNBQVMsWUFBWTtBQUNsSDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxpQkFBaUI7QUFDakI7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLDBCQUEwQjtBQUMxQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGFBQWE7QUFDYixTQUFTO0FBQ1Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsMEJBQTBCO0FBQzFCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsYUFBYTtBQUNiLFNBQVM7QUFDVDtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsNENBQTRDO0FBQzVDO0FBQ0E7QUFDQSwwQkFBMEI7QUFDMUI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsZ0JBQWdCLGtCQUFrQjtBQUNsQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVM7QUFDVDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGFBQWE7QUFDYjtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsQ0FBQzs7QUFFRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQSxvQkFBb0IsbUJBQW1CO0FBQ3ZDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVM7QUFDVDtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBLG1EQUFtRCxjQUFjLE1BQU0sYUFBYTtBQUNwRjtBQUNBO0FBQ0Esb0RBQW9ELGVBQWUsTUFBTSxjQUFjO0FBQ3ZGO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSw4QkFBOEI7QUFDOUI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLENBQUM7O0FBRUQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esd0JBQXdCLFVBQVU7QUFDbEM7QUFDQTtBQUNBO0FBQ0E7QUFDQSx3QkFBd0IsVUFBVTtBQUNsQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLG9CQUFvQixZQUFZO0FBQ2hDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLG9CQUFvQixXQUFXO0FBQy9CO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsMEJBQTBCO0FBQzFCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0Esb0JBQW9CLHlCQUF5QjtBQUM3QztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxvQkFBb0IseUJBQXlCO0FBQzdDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLG9CQUFvQix5QkFBeUI7QUFDN0M7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSx1REFBdUQsd0JBQXdCLE1BQU0sd0JBQXdCO0FBQzdHO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsYUFBYTtBQUNiO0FBQ0EsU0FBUztBQUNUO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsYUFBYTtBQUNiO0FBQ0EsU0FBUztBQUNUO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsYUFBYTtBQUNiO0FBQ0EsU0FBUztBQUNUO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxhQUFhO0FBQ2I7QUFDQTtBQUNBO0FBQ0E7QUFDQSxhQUFhO0FBQ2I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsYUFBYTtBQUNiO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsYUFBYTtBQUNiO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBLFlBQVksU0FBUztBQUNyQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQSxpQkFBaUI7QUFDakI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxpQkFBaUI7QUFDakI7QUFDQTtBQUNBO0FBQ0E7QUFDQSxpQkFBaUI7QUFDakI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxpQkFBaUI7QUFDakI7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLG9CQUFvQiwrQkFBK0I7QUFDbkQseUZBQXlGLHNCQUFzQjtBQUMvRyw2RkFBNkYsc0JBQXNCO0FBQ25IO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSx5REFBeUQsb0JBQW9CO0FBQzdFLDZEQUE2RCxvQkFBb0I7QUFDakY7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EscUNBQXFDLG9CQUFvQjtBQUN6RDtBQUNBLHlDQUF5QyxvQkFBb0I7QUFDN0Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esb0JBQW9CLGdDQUFnQztBQUNwRCx3QkFBd0IsK0JBQStCO0FBQ3ZEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxhQUFhO0FBQ2I7QUFDQTtBQUNBLFNBQVM7QUFDVDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsYUFBYTtBQUNiO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBO0FBQ0EsYUFBYTtBQUNiO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVM7QUFDVDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsYUFBYTtBQUNiO0FBQ0EsU0FBUztBQUNUO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxnQkFBZ0IsMkJBQTJCO0FBQzNDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsZ0JBQWdCLHNCQUFzQjtBQUN0QztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSwwQkFBMEI7QUFDMUI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esb0RBQW9ELHNCQUFzQjtBQUMxRTtBQUNBO0FBQ0EsYUFBYTtBQUNiLHlEQUF5RCx5QkFBeUI7QUFDbEY7QUFDQTtBQUNBLG9EQUFvRCxlQUFlLHlCQUF5QjtBQUM1RjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGdCQUFnQixtQkFBbUI7QUFDbkM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0EsWUFBWSw0QkFBNEI7QUFDeEM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTCw0QkFBNEIsa0NBQWtDO0FBQzlELHdEQUF3RCxZQUFZLGFBQWEsWUFBWSxLQUFLLFlBQVk7QUFDOUc7O0FBRUE7QUFDQTtBQUNBO0FBQ0Esb0JBQW9CLGdDQUFnQztBQUNwRCx3QkFBd0IsK0JBQStCO0FBQ3ZEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLG9CQUFvQiwrQkFBK0I7QUFDbkQsd0JBQXdCLGdDQUFnQztBQUN4RCw0QkFBNEIsK0JBQStCO0FBQzNEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsMEJBQTBCLHNDQUFzQztBQUNoRTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLDBCQUEwQixzQ0FBc0M7QUFDaEU7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSwwQkFBMEI7QUFDMUI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsZ0JBQWdCLGFBQWE7QUFDN0I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGlCQUFpQjtBQUNqQixhQUFhO0FBQ2I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGlCQUFpQjtBQUNqQjtBQUNBLGFBQWE7QUFDYjtBQUNBO0FBQ0E7QUFDQTtBQUNBLGlCQUFpQjtBQUNqQjtBQUNBLGFBQWE7QUFDYjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGlCQUFpQjtBQUNqQixhQUFhO0FBQ2I7QUFDQTtBQUNBO0FBQ0E7QUFDQSxpQkFBaUI7QUFDakIsYUFBYTtBQUNiO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsaUJBQWlCO0FBQ2pCLGFBQWE7QUFDYjtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsZ0JBQWdCLDJCQUEyQjtBQUMzQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVM7QUFDVDtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLG9CQUFvQixZQUFZO0FBQ2hDO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxhQUFhO0FBQ2I7QUFDQTtBQUNBO0FBQ0E7QUFDQSxhQUFhO0FBQ2I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsYUFBYTtBQUNiO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsYUFBYTtBQUNiO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsOEJBQThCLHNCQUFzQjtBQUNwRDtBQUNBO0FBQ0EsOEJBQThCLHNCQUFzQjtBQUNwRDtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0EsWUFBWSxTQUFTO0FBQ3JCLHVDQUF1Qyw2QkFBNkI7QUFDcEUseUNBQXlDLHVCQUF1QjtBQUNoRSxtQ0FBbUMsUUFBUTtBQUMzQztBQUNBLHNDQUFzQyw2QkFBNkI7QUFDbkUsd0NBQXdDLHVCQUF1QjtBQUMvRCxrQ0FBa0MsUUFBUTtBQUMxQztBQUNBLGlDQUFpQyw2QkFBNkI7QUFDOUQsbUNBQW1DLHVCQUF1QjtBQUMxRCw2QkFBNkIsUUFBUTtBQUNyQztBQUNBO0FBQ0E7QUFDQSxnREFBZ0Qsb0RBQW9EO0FBQ3BHOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxnQkFBZ0IsNEJBQTRCO0FBQzVDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsYUFBYTtBQUNiO0FBQ0E7QUFDQSxhQUFhO0FBQ2I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsOEJBQThCLHNCQUFzQjtBQUNwRDtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxnQkFBZ0IsdUJBQXVCO0FBQ3ZDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxhQUFhO0FBQ2I7QUFDQTtBQUNBO0FBQ0E7QUFDQSxhQUFhO0FBQ2I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsYUFBYTtBQUNiO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsYUFBYTtBQUNiO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxnQkFBZ0IsU0FBUztBQUN6QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBLFlBQVksU0FBUztBQUNyQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0wsa0NBQWtDLDZCQUE2QjtBQUMvRCxvSkFBb0osaUJBQWlCO0FBQ3JLO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTCxtQ0FBbUMsOEJBQThCO0FBQ2pFLHdKQUF3SixrQkFBa0I7QUFDMUs7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMLG1DQUFtQyw4QkFBOEI7QUFDakUsd0pBQXdKLGtCQUFrQjtBQUMxSztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0wsK0JBQStCLDBCQUEwQjtBQUN6RCxxSUFBcUksY0FBYztBQUNuSjtBQUNBO0FBQ0E7QUFDQSxLQUFLLEdBQUc7QUFDUiw2REFBNkQsaUJBQWlCLEdBQUc7QUFDakYsZ0RBQWdELFlBQVksR0FBRztBQUMvRDtBQUNBLHlEQUF5RCxtQkFBbUI7QUFDNUU7O0FBRUE7QUFDQSxZQUFZLFNBQVM7QUFDckI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTCw0QkFBNEIsaUNBQWlDO0FBQzdEO0FBQ0E7QUFDQSxLQUFLO0FBQ0wsb0JBQW9CLDJCQUEyQjtBQUMvQzs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxxRkFBcUYsc0JBQXNCO0FBQzNHLHlGQUF5RixzQkFBc0I7QUFDL0c7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLDBCQUEwQixzQ0FBc0M7QUFDaEUsOEJBQThCLHFDQUFxQztBQUNuRTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVM7QUFDVDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsYUFBYTtBQUNiLFNBQVM7QUFDVDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsYUFBYTtBQUNiLFNBQVM7QUFDVDtBQUNBO0FBQ0EsZ0JBQWdCLG9DQUFvQztBQUNwRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLCtCQUErQix1QkFBdUIsY0FBYyxZQUFZLE1BQU0sc0NBQXNDLFNBQVMsMEJBQTBCO0FBQy9KO0FBQ0E7QUFDQSwrQkFBK0IsdUJBQXVCLGVBQWUsYUFBYSxNQUFNLHNDQUFzQyxTQUFTLDJCQUEyQjtBQUNsSztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLDhCQUE4QixzQkFBc0I7QUFDcEQ7QUFDQTtBQUNBLDhCQUE4QixzQkFBc0I7QUFDcEQ7QUFDQTtBQUNBLDhCQUE4QixzQkFBc0I7QUFDcEQ7QUFDQTtBQUNBO0FBQ0EsZ0JBQWdCLHNCQUFzQjtBQUN0QztBQUNBO0FBQ0E7QUFDQTtBQUNBLGdCQUFnQixzQkFBc0I7QUFDdEM7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSw4QkFBOEI7QUFDOUI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGdCQUFnQixzQkFBc0I7QUFDdEM7QUFDQTtBQUNBO0FBQ0E7QUFDQSxnQkFBZ0Isc0JBQXNCO0FBQ3RDO0FBQ0E7QUFDQTtBQUNBLDhCQUE4QixzQkFBc0I7QUFDcEQ7QUFDQTtBQUNBLDhCQUE4QixzQkFBc0I7QUFDcEQ7QUFDQTtBQUNBLGdCQUFnQixzQkFBc0I7QUFDdEM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxnQkFBZ0IsdUJBQXVCO0FBQ3ZDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxhQUFhO0FBQ2I7QUFDQTtBQUNBO0FBQ0E7QUFDQSxhQUFhO0FBQ2I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsYUFBYTtBQUNiO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsYUFBYTtBQUNiO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBLFlBQVksU0FBUztBQUNyQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBLHlCQUF5QixvQkFBb0I7QUFDN0M7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsOEJBQThCLHNCQUFzQjtBQUNwRDtBQUNBO0FBQ0EsbUNBQW1DO0FBQ25DO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0Esb0JBQW9CLGdDQUFnQztBQUNwRCx3QkFBd0IsK0JBQStCO0FBQ3ZEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esb0JBQW9CLCtCQUErQjtBQUNuRCx3QkFBd0IsZ0NBQWdDO0FBQ3hELDRCQUE0QiwrQkFBK0I7QUFDM0Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLG9CQUFvQixnQ0FBZ0M7QUFDcEQsd0JBQXdCLCtCQUErQjtBQUN2RDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLG9CQUFvQiwrQkFBK0I7QUFDbkQsd0JBQXdCLGdDQUFnQztBQUN4RCw0QkFBNEIsK0JBQStCO0FBQzNEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsK0NBQStDO0FBQy9DO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsZ0JBQWdCLHVCQUF1QjtBQUN2QztBQUNBO0FBQ0E7QUFDQSxhQUFhO0FBQ2I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsaUJBQWlCO0FBQ2pCLGFBQWE7QUFDYjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxpQkFBaUI7QUFDakIsYUFBYTtBQUNiO0FBQ0E7QUFDQSxhQUFhO0FBQ2I7QUFDQTtBQUNBO0FBQ0EsYUFBYTtBQUNiO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsYUFBYTtBQUNiO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxpQkFBaUI7QUFDakIsYUFBYTtBQUNiO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxpQkFBaUI7QUFDakIsYUFBYTtBQUNiO0FBQ0E7QUFDQSxhQUFhO0FBQ2I7QUFDQTtBQUNBO0FBQ0EsYUFBYTtBQUNiO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGdCQUFnQixpQkFBaUI7QUFDakM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSw4QkFBOEIsc0JBQXNCO0FBQ3BEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxDQUFDOztBQUVEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsNEJBQTRCLGlCQUFpQjtBQUM3QztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSw0QkFBNEIsaUJBQWlCO0FBQzdDO0FBQ0EsZ0NBQWdDLGtCQUFrQjtBQUNsRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSw0QkFBNEIsaUJBQWlCO0FBQzdDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsNEJBQTRCO0FBQzVCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSx5QkFBeUI7QUFDekI7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0E7QUFDQSxnQkFBZ0IsNEZBQTRGO0FBQzVHO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLG9DQUFvQyxJQUFJLElBQUksZ0VBQWdFO0FBQzVHO0FBQ0EsU0FBUztBQUNUO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsMkJBQTJCO0FBQzNCO0FBQ0E7QUFDQSxnQkFBZ0IsK0NBQStDO0FBQy9EO0FBQ0EsaUVBQWlFLGtHQUFrRywwREFBMEQsNkdBQTZHO0FBQzFVO0FBQ0E7QUFDQTtBQUNBLGdCQUFnQiw0Q0FBNEM7QUFDNUQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGdCQUFnQiwwQkFBMEI7QUFDMUM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxnQkFBZ0IsZUFBZTtBQUMvQjtBQUNBO0FBQ0Esd0JBQXdCLHlCQUF5QjtBQUNqRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHdCQUF3QixtQkFBbUI7QUFDM0M7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esa01BQWtNO0FBQ2xNO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHdCQUF3Qix3QkFBd0I7QUFDaEQ7QUFDQTtBQUNBO0FBQ0E7QUFDQSw0QkFBNEI7QUFDNUIsZ0JBQWdCLGdDQUFnQztBQUNoRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxnQkFBZ0IsWUFBWTtBQUM1QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EseUNBQXlDLGtCQUFrQixvQkFBb0IsYUFBYTtBQUM1RjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHdCQUF3Qix5QkFBeUI7QUFDakQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHdCQUF3QixpQkFBaUI7QUFDekM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHdDQUF3QyxRQUFRO0FBQ2hEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSx3QkFBd0IsbUJBQW1CO0FBQzNDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGlCQUFpQjtBQUNqQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSx5QkFBeUI7QUFDekIsYUFBYTtBQUNiO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGFBQWE7QUFDYjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVM7QUFDVDtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBLFNBQVM7QUFDVCx3QkFBd0IsMEJBQTBCO0FBQ2xEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsMkJBQTJCLHNCQUFzQjtBQUNqRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esd0JBQXdCLHdCQUF3QjtBQUNoRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHdCQUF3Qix1QkFBdUI7QUFDL0M7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxnR0FBZ0csNEJBQTRCO0FBQzVIO0FBQ0EsZ0dBQWdHLDRCQUE0QjtBQUM1SDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLDBCQUEwQixpQkFBaUI7QUFDM0M7QUFDQTtBQUNBO0FBQ0EsaUJBQWlCO0FBQ2pCO0FBQ0E7QUFDQSwyQkFBMkIsc0JBQXNCO0FBQ2pEO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsaUJBQWlCO0FBQ2pCO0FBQ0E7QUFDQSwyQkFBMkIsc0JBQXNCO0FBQ2pEO0FBQ0E7O0FBRUE7QUFDQTtBQUNBLG1FQUFtRSxXQUFXO0FBQzlFO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQTs7QUFFQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQSxhQUFhO0FBQ2I7QUFDQTtBQUNBO0FBQ0EsRUFBRTtBQUNGOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQSxpREFBaUQsT0FBTztBQUN4RDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsK0NBQStDLGFBQWE7QUFDNUQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxrQ0FBa0M7QUFDbEMscUNBQXFDO0FBQ3JDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVM7QUFDVDtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esd0JBQXdCLHVCQUF1QjtBQUMvQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLENBQUM7QUFDRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBLENBQUM7O0FBRUQ7QUFDQSwrQ0FBK0MsYUFBYTtBQUM1RDs7QUFFQTtBQUNBO0FBQ0EsZ0NBQWdDO0FBQ2hDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSx3QkFBd0IsdUJBQXVCO0FBQy9DO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLENBQUM7QUFDRDs7QUFFQSxDQUFDOztBQUVEO0FBQ0EsK0NBQStDLGFBQWE7QUFDNUQ7O0FBRUEseUNBQXlDLHFDQUFxQyx1QkFBdUI7QUFDckcseUNBQXlDLHFDQUFxQyx1QkFBdUI7O0FBRXJHLDBDQUEwQyxxQ0FBcUMsdUJBQXVCO0FBQ3RHO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUEsQ0FBQzs7QUFFRDtBQUNBO0FBQ0Esb0JBQW9CLG1CQUFtQjtBQUN2QztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxvQkFBb0Isa0JBQWtCO0FBQ3RDO0FBQ0E7QUFDQSxvQkFBb0IsbUJBQW1CO0FBQ3ZDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLG9CQUFvQixrQkFBa0I7QUFDdEM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esb0JBQW9CLGtCQUFrQjtBQUN0QztBQUNBO0FBQ0Esb0JBQW9CLG1CQUFtQjtBQUN2QztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxvQkFBb0Isa0JBQWtCO0FBQ3RDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLG9CQUFvQixtQkFBbUI7QUFDdkM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQSxvQkFBb0IsbUJBQW1CO0FBQ3ZDO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFlBQVksU0FBUztBQUNyQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsNEJBQTRCO0FBQzVCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSwyQkFBMkI7QUFDM0I7QUFDQTtBQUNBO0FBQ0EsMkJBQTJCO0FBQzNCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EseUJBQXlCO0FBQ3pCO0FBQ0EsZ0JBQWdCLHNDQUFzQztBQUN0RDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLG1EQUFtRDtBQUNuRDtBQUNBO0FBQ0E7QUFDQTtBQUNBLG9EQUFvRDtBQUNwRDtBQUNBLGlDQUFpQyxnQ0FBZ0M7QUFDakU7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHdDQUF3QyxrQkFBa0I7QUFDMUQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxzREFBc0QsTUFBTTtBQUM1RDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsaUVBQWlFLGNBQWM7QUFDL0U7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGlDQUFpQztBQUNqQztBQUNBLDRCQUE0QiwyQkFBMkI7QUFDdkQ7QUFDQTtBQUNBO0FBQ0E7QUFDQSwrQkFBK0Isb0JBQW9CO0FBQ25EO0FBQ0E7QUFDQSxnQ0FBZ0Msb0JBQW9CO0FBQ3BEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsaUNBQWlDO0FBQ2pDO0FBQ0EsNEJBQTRCLDJCQUEyQjtBQUN2RDtBQUNBO0FBQ0E7QUFDQTtBQUNBLCtCQUErQixtQkFBbUI7QUFDbEQ7QUFDQTtBQUNBLGdDQUFnQyxvQkFBb0I7QUFDcEQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxpQ0FBaUM7QUFDakMsZ0JBQWdCLGlCQUFpQjtBQUNqQztBQUNBLDRCQUE0QiwyQkFBMkI7QUFDdkQ7QUFDQTtBQUNBO0FBQ0E7QUFDQSwrQkFBK0IsbUJBQW1CO0FBQ2xEO0FBQ0E7QUFDQSxnQ0FBZ0Msb0JBQW9CO0FBQ3BEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsaUNBQWlDO0FBQ2pDO0FBQ0EsNEJBQTRCLDJCQUEyQjtBQUN2RDtBQUNBO0FBQ0E7QUFDQTtBQUNBLCtCQUErQixtQkFBbUI7QUFDbEQ7QUFDQTtBQUNBLGdDQUFnQyxvQkFBb0I7QUFDcEQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxhQUFhO0FBQ2I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHlCQUF5QjtBQUN6QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsYUFBYTtBQUNiO0FBQ0E7QUFDQTtBQUNBLGFBQWE7QUFDYjtBQUNBO0FBQ0E7QUFDQSxhQUFhO0FBQ2I7QUFDQTtBQUNBO0FBQ0EsYUFBYTtBQUNiO0FBQ0E7QUFDQTtBQUNBLGFBQWE7QUFDYjtBQUNBO0FBQ0E7QUFDQSxhQUFhO0FBQ2I7QUFDQTtBQUNBO0FBQ0EsYUFBYTtBQUNiO0FBQ0E7QUFDQTtBQUNBLGFBQWE7QUFDYjtBQUNBO0FBQ0E7QUFDQSxhQUFhO0FBQ2I7QUFDQTtBQUNBO0FBQ0EsYUFBYTtBQUNiO0FBQ0E7QUFDQTtBQUNBLGFBQWE7QUFDYjtBQUNBO0FBQ0E7QUFDQSxhQUFhO0FBQ2I7QUFDQTtBQUNBO0FBQ0EsYUFBYTtBQUNiO0FBQ0E7QUFDQTtBQUNBLGFBQWE7QUFDYjtBQUNBO0FBQ0E7QUFDQSxhQUFhO0FBQ2I7QUFDQTtBQUNBO0FBQ0E7QUFDQSxvQ0FBb0MsRUFBRSxJQUFJLEtBQUs7QUFDL0M7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsZ0JBQWdCLHVKQUF1SjtBQUN2SztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxtQ0FBbUMsa0JBQWtCLG9CQUFvQixhQUFhO0FBQ3RGO0FBQ0E7QUFDQTtBQUNBLHdCQUF3QixpQkFBaUI7QUFDekM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHdCQUF3QixpQkFBaUI7QUFDekM7QUFDQTtBQUNBO0FBQ0E7QUFDQSxnQkFBZ0IscUVBQXFFO0FBQ3JGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxhQUFhO0FBQ2I7QUFDQTtBQUNBO0FBQ0EsbUNBQW1DO0FBQ25DO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSw0QkFBNEI7QUFDNUIsZ0JBQWdCLGdDQUFnQztBQUNoRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHVDQUF1QztBQUN2QyxnQkFBZ0IsZ0NBQWdDO0FBQ2hEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsaUJBQWlCO0FBQ2pCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSwyQ0FBMkMsWUFBWTtBQUN2RDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsK0JBQStCLG1CQUFtQjtBQUNsRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLG9DQUFvQyxtQkFBbUI7QUFDdkQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsMkNBQTJDLFlBQVk7QUFDdkQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsK0JBQStCLG9CQUFvQjtBQUNuRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxvQ0FBb0MsdUJBQXVCO0FBQzNEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsMkNBQTJDLFlBQVk7QUFDdkQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsK0JBQStCLG9CQUFvQjtBQUNuRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxvQ0FBb0MsdUJBQXVCO0FBQzNEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLDJDQUEyQyxZQUFZO0FBQ3ZEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLCtCQUErQixvQkFBb0I7QUFDbkQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esb0NBQW9DLHVCQUF1QjtBQUMzRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGdCQUFnQix5QkFBeUI7QUFDekMsNEJBQTRCLDJCQUEyQjtBQUN2RDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSwrQkFBK0IsbUJBQW1CO0FBQ2xEO0FBQ0EsZ0NBQWdDLHFCQUFxQjtBQUNyRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSw0QkFBNEIsMkJBQTJCO0FBQ3ZEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLG1DQUFtQyxhQUFhO0FBQ2hEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsZ0JBQWdCLGFBQWE7QUFDN0IsZ0JBQWdCLHNDQUFzQztBQUN0RCw0QkFBNEIsMkJBQTJCO0FBQ3ZEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLCtCQUErQixvQkFBb0I7QUFDbkQ7QUFDQSxnQ0FBZ0MscUJBQXFCO0FBQ3JEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSw0QkFBNEIsaUJBQWlCO0FBQzdDO0FBQ0E7QUFDQTtBQUNBLGlCQUFpQjtBQUNqQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsNEJBQTRCLGlCQUFpQjtBQUM3QztBQUNBO0FBQ0E7QUFDQSxpQkFBaUI7QUFDakI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLDRCQUE0QixpQkFBaUI7QUFDN0M7QUFDQTtBQUNBO0FBQ0EsaUJBQWlCO0FBQ2pCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxxSEFBcUg7QUFDckg7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHdIQUF3SDtBQUN4SDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxnQkFBZ0IsZUFBZTtBQUMvQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSw0QkFBNEIseUJBQXlCO0FBQ3JEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxxQkFBcUI7QUFDckI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsaUJBQWlCO0FBQ2pCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSx3QkFBd0IseUJBQXlCO0FBQ2pEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxpQkFBaUI7QUFDakI7QUFDQTtBQUNBO0FBQ0EsYUFBYTtBQUNiO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVM7QUFDVDtBQUNBO0FBQ0E7QUFDQSx3QkFBd0IsbUJBQW1CO0FBQzNDO0FBQ0E7QUFDQTtBQUNBLGFBQWE7QUFDYjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsOENBQThDLHNCQUFzQjtBQUNwRTtBQUNBLGdEQUFnRCx1QkFBdUI7QUFDdkU7QUFDQSx1QkFBdUIsaUJBQWlCO0FBQ3hDO0FBQ0E7QUFDQTtBQUNBO0FBQ0EseUJBQXlCO0FBQ3pCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxnREFBZ0Qsc0JBQXNCO0FBQ3RFO0FBQ0Esa0RBQWtELHVCQUF1QjtBQUN6RTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVM7QUFDVDtBQUNBLHdCQUF3Qix1QkFBdUI7QUFDL0M7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsZ0JBQWdCLDZCQUE2QjtBQUM3QztBQUNBO0FBQ0E7QUFDQSxpQ0FBaUMsVUFBVTtBQUMzQztBQUNBO0FBQ0E7QUFDQTtBQUNBLHlEQUF5RCxZQUFZLGNBQWMsV0FBVztBQUM5RjtBQUNBO0FBQ0Esc0RBQXNELFlBQVksY0FBYyxXQUFXO0FBQzNGO0FBQ0E7QUFDQTtBQUNBO0FBQ0EseUNBQXlDLE9BQU8sR0FBRyx5Q0FBeUM7QUFDNUY7QUFDQTtBQUNBLDBDQUEwQyxPQUFPLEdBQUcseUNBQXlDO0FBQzdGO0FBQ0EsYUFBYTtBQUNiLCtCQUErQixnQkFBZ0IsRUFBRSxzQkFBc0I7QUFDdkU7QUFDQTtBQUNBLDhDQUE4QyxPQUFPO0FBQ3JEO0FBQ0E7QUFDQSxrQ0FBa0MsT0FBTztBQUN6QztBQUNBO0FBQ0E7QUFDQSwwQ0FBMEMsT0FBTyxJQUFJLGVBQWU7QUFDcEU7QUFDQTtBQUNBLHdDQUF3QyxPQUFPO0FBQy9DO0FBQ0EsMERBQTBELFdBQVc7QUFDckU7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSx1REFBdUQ7QUFDdkQsd0NBQXdDLElBQUk7QUFDNUMsMkJBQTJCLEdBQUc7QUFDOUI7QUFDQTtBQUNBO0FBQ0EsZ0NBQWdDLDBDQUEwQztBQUMxRTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxxQ0FBcUMsSUFBSSxJQUFJLGdCQUFnQjtBQUM3RDtBQUNBLHVCQUF1QixFQUFFLFFBQVE7QUFDakM7QUFDQTtBQUNBLHlCQUF5Qix1QkFBdUI7QUFDaEQ7QUFDQSwwQkFBMEIsWUFBWSxFQUFFLGtCQUFrQixPQUFPLFNBQVMsUUFBUTtBQUNsRjtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0Esb0JBQW9CLHlCQUF5QjtBQUM3QztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLG9CQUFvQix5QkFBeUI7QUFDN0M7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxvQkFBb0IseUJBQXlCO0FBQzdDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esb0JBQW9CLHlCQUF5QjtBQUM3QztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esb0JBQW9CLFVBQVU7QUFDOUI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxvQkFBb0IseUJBQXlCO0FBQzdDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSw0QkFBNEI7QUFDNUI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxnQ0FBZ0MsMkJBQTJCO0FBQzNEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsK0NBQStDLFdBQVc7QUFDMUQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esb0NBQW9DLG9CQUFvQjtBQUN4RDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHdCQUF3QixpQkFBaUI7QUFDekM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHNEQUFzRCwwQkFBMEI7QUFDaEY7QUFDQSw0QkFBNEIsMkJBQTJCO0FBQ3ZEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxpQkFBaUI7QUFDakI7QUFDQSxhQUFhO0FBQ2I7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0E7QUFDQTtBQUNBLFNBQVM7QUFDVDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esc0RBQXNELDBCQUEwQjtBQUNoRjtBQUNBO0FBQ0E7QUFDQSwyQ0FBMkMsV0FBVztBQUN0RDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsaUJBQWlCO0FBQ2pCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxpQkFBaUI7QUFDakI7QUFDQTtBQUNBO0FBQ0EsaUJBQWlCO0FBQ2pCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGlCQUFpQjtBQUNqQjtBQUNBO0FBQ0E7QUFDQTtBQUNBLGlCQUFpQjtBQUNqQjtBQUNBO0FBQ0E7QUFDQTtBQUNBLHFCQUFxQjtBQUNyQjtBQUNBLGlCQUFpQjtBQUNqQjtBQUNBO0FBQ0E7QUFDQTtBQUNBLDRCQUE0QiwyQkFBMkI7QUFDdkQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGFBQWE7QUFDYjtBQUNBO0FBQ0EsYUFBYTtBQUNiO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGlCQUFpQjtBQUNqQjtBQUNBLGFBQWE7QUFDYjtBQUNBO0FBQ0E7QUFDQSw0QkFBNEIsMkJBQTJCO0FBQ3ZEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSw0QkFBNEIsMkJBQTJCO0FBQ3ZEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxpQkFBaUI7QUFDakI7QUFDQSxhQUFhO0FBQ2I7QUFDQTtBQUNBO0FBQ0EsNEJBQTRCLDJCQUEyQjtBQUN2RDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGFBQWE7QUFDYjtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVM7QUFDVDtBQUNBLFNBQVM7QUFDVDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLG1DQUFtQztBQUNuQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVM7QUFDVDtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBO0FBQ0E7QUFDQSxhQUFhO0FBQ2I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSwyQkFBMkIsc0JBQXNCO0FBQ2pEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBO0FBQ0E7QUFDQSx3QkFBd0IsdUJBQXVCO0FBQy9DO0FBQ0E7QUFDQTtBQUNBLGFBQWE7QUFDYjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsOENBQThDLHNCQUFzQjtBQUNwRTtBQUNBLGdEQUFnRCx1QkFBdUI7QUFDdkU7QUFDQSx1QkFBdUIsaUJBQWlCO0FBQ3hDO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLDJCQUEyQixzQkFBc0I7QUFDakQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSwyQkFBMkIsc0JBQXNCO0FBQ2pEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLDhCQUE4QixzQkFBc0I7QUFDcEQ7QUFDQTtBQUNBLDhCQUE4QixzQkFBc0I7QUFDcEQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsZ0JBQWdCLHNCQUFzQjtBQUN0QztBQUNBO0FBQ0E7QUFDQTtBQUNBLGdCQUFnQixzQkFBc0I7QUFDdEM7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQSw0QkFBNEI7QUFDNUI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSx3QkFBd0IsMkJBQTJCO0FBQ25EO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxvREFBb0QsZ0NBQWdDO0FBQ3BGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsZ0RBQWdELGdDQUFnQztBQUNoRjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSx3QkFBd0Isc0NBQXNDO0FBQzlEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxvQkFBb0Isd0NBQXdDO0FBQzVEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esd0JBQXdCLG1CQUFtQjtBQUMzQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHVDQUF1QztBQUN2Qyx3QkFBd0IsVUFBVTtBQUNsQztBQUNBO0FBQ0EsNEJBQTRCLHFCQUFxQjtBQUNqRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLDRCQUE0QjtBQUM1QixnQkFBZ0IsZ0NBQWdDO0FBQ2hEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHdCQUF3Qix5QkFBeUI7QUFDakQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esd0JBQXdCLGlCQUFpQjtBQUN6QztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLDhDQUE4QyxRQUFRO0FBQ3REO0FBQ0E7QUFDQSx3Q0FBd0MsUUFBUTtBQUNoRDtBQUNBO0FBQ0EsOENBQThDLFFBQVE7QUFDdEQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSx3QkFBd0IsbUJBQW1CO0FBQzNDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHdCQUF3QixpQkFBaUI7QUFDekM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxxREFBcUQsVUFBVTtBQUMvRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSx3REFBd0QsU0FBUztBQUNqRSxpREFBaUQ7QUFDakQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxhQUFhO0FBQ2I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxhQUFhO0FBQ2IsU0FBUztBQUNUO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGFBQWE7QUFDYixTQUFTO0FBQ1Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLCtCQUErQixpQkFBaUI7QUFDaEQ7QUFDQTtBQUNBO0FBQ0Esc0NBQXNDLHVCQUF1QjtBQUM3RDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLG1EQUFtRCxTQUFTO0FBQzVEO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsOEVBQThFLDBDQUEwQztBQUN4SDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsbUZBQW1GLG1DQUFtQztBQUN0SDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGdDQUFnQyx1QkFBdUI7QUFDdkQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxnQ0FBZ0MsdUJBQXVCO0FBQ3ZEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHdCQUF3QixnQkFBZ0I7QUFDeEM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSx3QkFBd0IsdUJBQXVCO0FBQy9DO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EscUNBQXFDLG1DQUFtQztBQUN4RTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGdCQUFnQixhQUFhO0FBQzdCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSw0Q0FBNEMsU0FBUztBQUNyRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLCtEQUErRCxVQUFVO0FBQ3pFO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsZ0JBQWdCLDZCQUE2QjtBQUM3Qyw4Q0FBOEMsU0FBUztBQUN2RDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSwyREFBMkQsTUFBTTtBQUNqRTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHlCQUF5QixVQUFVO0FBQ25DO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSx3QkFBd0IsaUJBQWlCO0FBQ3pDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHVCQUF1QjtBQUN2QixtQkFBbUI7QUFDbkIsbUJBQW1CO0FBQ25CO0FBQ0Esd0JBQXdCLDBCQUEwQjtBQUNsRCxtQ0FBbUMscUNBQXFDO0FBQ3hFLDJCQUEyQiw2QkFBNkI7QUFDeEQsNkJBQTZCLCtCQUErQjtBQUM1RCxFQUFFO0FBQ0Y7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxnQ0FBZ0MsaUJBQWlCO0FBQ2pEO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsbURBQW1ELFNBQVM7QUFDNUQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLCtDQUErQyxTQUFTO0FBQ3hEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0EsUUFBUSxNQUFNLEtBQUssT0FBTyxxQkFBcUI7QUFDL0M7QUFDQTtBQUNBLG9CQUFvQix5QkFBeUI7QUFDN0M7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQSxTQUFTLE1BQU0sV0FBVyxNQUFNLEtBQUssT0FBTztBQUM1QztBQUNBO0FBQ0Esb0JBQW9CLDJCQUEyQjtBQUMvQztBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLG9CQUFvQiw0QkFBNEI7QUFDaEQ7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLG9CQUFvQix5QkFBeUI7QUFDN0M7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQSxhQUFhLE1BQU0sS0FBSyxPQUFPLG1CQUFtQjtBQUNsRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSwwQkFBMEIsb0JBQW9CO0FBQzlDO0FBQ0E7QUFDQTtBQUNBLGtDQUFrQyw0QkFBNEI7QUFDOUQ7QUFDQTtBQUNBO0FBQ0EscUNBQXFDLDBCQUEwQjtBQUMvRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0EsZUFBZSxNQUFNLFdBQVcsTUFBTSxLQUFLO0FBQzNDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLDhCQUE4Qix3QkFBd0I7QUFDdEQ7QUFDQTtBQUNBO0FBQ0Esa0NBQWtDLDRCQUE0QjtBQUM5RDtBQUNBLHFDQUFxQywwQkFBMEI7QUFDL0Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQSxZQUFZLFVBQVU7QUFDdEIsb0JBQW9CLG9CQUFvQjtBQUN4QztBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBLGVBQWUsTUFBTSxLQUFLLE9BQU8sV0FBVyxNQUFNLGFBQWEsTUFBTSxLQUFLLE9BQU87QUFDakY7QUFDQTtBQUNBLG9CQUFvQix5QkFBeUI7QUFDN0M7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBLFNBQVMsR0FBRyxZQUFZLE1BQU07QUFDOUI7QUFDQTtBQUNBLG9CQUFvQix5QkFBeUI7QUFDN0MsMkRBQTJEO0FBQzNEO0FBQ0E7QUFDQTs7QUFFQTtBQUNBLFNBQVMsTUFBTSxXQUFXLEdBQUcsYUFBYSxHQUFHO0FBQzdDO0FBQ0E7QUFDQSxvQkFBb0IsMkJBQTJCO0FBQy9DO0FBQ0E7QUFDQTs7QUFFQTtBQUNBLFlBQVksVUFBVTtBQUN0QjtBQUNBLHlCQUF5QixrQkFBa0I7QUFDM0M7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQSxTQUFTLE1BQU0sYUFBYSxHQUFHO0FBQy9CO0FBQ0E7QUFDQSxZQUFZLFVBQVU7QUFDdEI7QUFDQSx5QkFBeUIsa0JBQWtCO0FBQzNDO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0Esb0JBQW9CLHlCQUF5QjtBQUM3QztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0Esb0JBQW9CLDJCQUEyQjtBQUMvQztBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLG9CQUFvQiwyQkFBMkI7QUFDL0M7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLG9CQUFvQiwyQkFBMkI7QUFDL0M7QUFDQTtBQUNBO0FBQ0Esb0JBQW9CLDJCQUEyQjtBQUMvQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0Esb0JBQW9CLHlCQUF5QjtBQUM3QztBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBLG9CQUFvQiwyQkFBMkI7QUFDL0M7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHdDQUF3QztBQUN4QyxTQUFTO0FBQ1Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esd0NBQXdDO0FBQ3hDLFNBQVM7QUFDVDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxhQUFhO0FBQ2Isd0NBQXdDO0FBQ3hDLFNBQVM7QUFDVDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxhQUFhO0FBQ2I7QUFDQTtBQUNBLFNBQVM7QUFDVDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVM7QUFDVDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVM7QUFDVDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGdDQUFnQztBQUNoQyx3Q0FBd0M7QUFDeEMsU0FBUztBQUNUO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxrREFBa0QsU0FBUztBQUMzRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGtEQUFrRCxTQUFTO0FBQzNEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHdCQUF3QiwyQkFBMkI7QUFDbkQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHlDQUF5QztBQUN6QywrQ0FBK0M7QUFDL0M7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBLFlBQVksVUFBVTtBQUN0QjtBQUNBO0FBQ0Esb0JBQW9CLG9CQUFvQjtBQUN4QztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSw0QkFBNEI7QUFDNUIseUJBQXlCO0FBQ3pCLDJCQUEyQjtBQUMzQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQSx5QkFBeUI7QUFDekI7QUFDQTtBQUNBLFNBQVM7QUFDVDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsZ0JBQWdCLGdCQUFnQjtBQUNoQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGdCQUFnQiwwQkFBMEI7QUFDMUM7QUFDQTtBQUNBO0FBQ0E7QUFDQSx3QkFBd0IseUJBQXlCO0FBQ2pEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGdCQUFnQix3QkFBd0I7QUFDeEM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGdCQUFnQiwyQkFBMkI7QUFDM0M7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGdCQUFnQixRQUFRO0FBQ3hCLGdCQUFnQixlQUFlO0FBQy9CO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLG1EQUFtRCxTQUFTO0FBQzVEO0FBQ0EsaUVBQWlFLEVBQUU7QUFDbkU7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxtREFBbUQsU0FBUztBQUM1RDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGdCQUFnQiwwQkFBMEI7QUFDMUM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVM7QUFDVDtBQUNBO0FBQ0E7QUFDQSxnQkFBZ0IsUUFBUTtBQUN4QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLDJEQUEyRCx1QkFBdUI7QUFDbEY7QUFDQTtBQUNBO0FBQ0EsMEVBQTBFO0FBQzFFLG1GQUFtRjtBQUNuRjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxnQkFBZ0IsUUFBUTtBQUN4QixnQkFBZ0IsWUFBWTtBQUM1QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGdCQUFnQixzQ0FBc0M7QUFDdEQsZ0JBQWdCLDhCQUE4QjtBQUM5QyxnQkFBZ0IsZUFBZTtBQUMvQixnQkFBZ0IsY0FBYztBQUM5QjtBQUNBO0FBQ0Esa0NBQWtDLGtDQUFrQztBQUNwRTtBQUNBLG9CQUFvQixrQkFBa0I7QUFDdEM7QUFDQTtBQUNBO0FBQ0E7QUFDQSw0QkFBNEIsb0JBQW9CO0FBQ2hEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsZ0JBQWdCLFFBQVE7QUFDeEI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSx1RUFBdUUsU0FBUztBQUNoRjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsMkJBQTJCO0FBQzNCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsYUFBYTtBQUNiO0FBQ0E7QUFDQTtBQUNBLGFBQWE7QUFDYjtBQUNBO0FBQ0E7QUFDQSxhQUFhO0FBQ2I7QUFDQTtBQUNBO0FBQ0EsYUFBYTtBQUNiO0FBQ0E7QUFDQTtBQUNBLGFBQWE7QUFDYjtBQUNBO0FBQ0E7QUFDQSxhQUFhO0FBQ2I7QUFDQTtBQUNBO0FBQ0EsYUFBYTtBQUNiO0FBQ0E7QUFDQTtBQUNBLGFBQWE7QUFDYjtBQUNBO0FBQ0E7QUFDQTtBQUNBLG9DQUFvQyxFQUFFLElBQUksS0FBSztBQUMvQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSw4QkFBOEI7QUFDOUI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGdCQUFnQixnRUFBZ0U7QUFDaEY7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxvQkFBb0IsdUNBQXVDO0FBQzNEO0FBQ0EsNEJBQTRCLG1CQUFtQjtBQUMvQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsbUNBQW1DLEVBQUUsb0JBQW9CLE1BQU07QUFDL0Q7QUFDQTtBQUNBLDJCQUEyQixzQkFBc0I7QUFDakQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGdCQUFnQixpQkFBaUI7QUFDakM7QUFDQTtBQUNBLHVCQUF1QiwyREFBMkQ7QUFDbEY7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGFBQWE7QUFDYjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxhQUFhO0FBQ2I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGdCQUFnQixVQUFVO0FBQzFCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxnQkFBZ0IsUUFBUTtBQUN4QixnQkFBZ0IsWUFBWTtBQUM1QjtBQUNBLGdCQUFnQixTQUFTO0FBQ3pCO0FBQ0E7QUFDQTtBQUNBLG9CQUFvQixTQUFTO0FBQzdCLGlEQUFpRCxTQUFTO0FBQzFEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsaURBQWlELFNBQVM7QUFDMUQ7QUFDQTtBQUNBO0FBQ0E7QUFDQSxvREFBb0QsRUFBRSw4QkFBOEIsRUFBRSx5QkFBeUIsT0FBTyxJQUFJLFVBQVU7QUFDcEk7QUFDQSx5Q0FBeUMsT0FBTyxJQUFJLFVBQVU7QUFDOUQ7QUFDQTtBQUNBLHFDQUFxQyxFQUFFO0FBQ3ZDO0FBQ0EscUNBQXFDLEVBQUU7QUFDdkM7QUFDQSxxQ0FBcUMsRUFBRTtBQUN2QztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSw2REFBNkQsU0FBUztBQUN0RTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxnREFBZ0QsRUFBRSxJQUFJLEVBQUU7QUFDeEQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsNEJBQTRCO0FBQzVCLHdEQUF3RDtBQUN4RDtBQUNBO0FBQ0EsZ0RBQWdEO0FBQ2hELHFEQUFxRDtBQUNyRDtBQUNBO0FBQ0E7QUFDQSx3QkFBd0I7QUFDeEI7QUFDQTtBQUNBLGdEQUFnRDtBQUNoRCxxREFBcUQ7QUFDckQscURBQXFEO0FBQ3JELHVEQUF1RDtBQUN2RCxnRUFBZ0U7QUFDaEU7QUFDQTtBQUNBLDJDQUEyQztBQUMzQywyQkFBMkIsb0JBQW9CO0FBQy9DLGFBQWEsRUFBRTtBQUNmO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsNkNBQTZDLFNBQVM7QUFDdEQ7QUFDQSxxQ0FBcUMsRUFBRTtBQUN2QyxlQUFlLHFCQUFxQjtBQUNwQyxjQUFjLHlEQUF5RDtBQUN2RSxlQUFlLDJEQUEyRDtBQUMxRSxpQkFBaUI7QUFDakIsS0FBSztBQUNMO0FBQ0E7QUFDQTtBQUNBLDJEQUEyRCxPQUFPLHFCQUFxQjtBQUN2RixZQUFZO0FBQ1osZ0JBQWdCO0FBQ2hCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGVBQWU7QUFDZixJQUFJO0FBQ0osaUJBQWlCO0FBQ2pCLDJEQUEyRDtBQUMzRDtBQUNBLElBQUk7QUFDSjtBQUNBLCtEQUErRCxFQUFFLDhEQUE4RCxxQkFBcUI7QUFDcEo7QUFDQSxJQUFJO0FBQ0o7QUFDQSw2RUFBNkUsRUFBRSwrREFBK0QscUJBQXFCO0FBQ25LO0FBQ0E7QUFDQSxNQUFNLGtDQUFrQztBQUN4QztBQUNBLE1BQU07QUFDTjtBQUNBO0FBQ0EsZ0JBQWdCO0FBQ2hCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxNQUFNLGlCQUFpQjtBQUN2QiwwQ0FBMEMsbUJBQW1CLHVCQUF1QjtBQUNwRjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsRUFBRTtBQUNGO0FBQ0E7O0FBRUE7QUFDQTtBQUNBLDREQUE0RCxRQUFRO0FBQ3BFO0FBQ0E7QUFDQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQSxJQUFJO0FBQ0o7QUFDQSw0RkFBNEYsbUJBQW1CO0FBQy9HLHVFQUF1RSxtQkFBbUI7QUFDMUY7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLElBQUk7QUFDSixJQUFJO0FBQ0osSUFBSTtBQUNKLElBQUk7QUFDSixJQUFJLGdCQUFnQjtBQUNwQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSx3QkFBd0IsaUJBQWlCO0FBQ3pDO0FBQ0E7QUFDQSw0QkFBNEIsb0JBQW9CO0FBQ2hEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLDRCQUE0QjtBQUM1QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBO0FBQ0EseUJBQXlCO0FBQ3pCO0FBQ0E7QUFDQTtBQUNBLFNBQVM7QUFDVDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsZ0JBQWdCLGFBQWE7QUFDN0I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGlCQUFpQjtBQUNqQjtBQUNBO0FBQ0EsZ0JBQWdCLGlCQUFpQjtBQUNqQyxnQkFBZ0IsMEJBQTBCO0FBQzFDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsbURBQW1ELFNBQVM7QUFDNUQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxtREFBbUQsU0FBUztBQUM1RDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGdCQUFnQiwwQkFBMEI7QUFDMUM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBLHNEQUFzRCxRQUFRO0FBQzlEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsaURBQWlEO0FBQ2pEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSwyREFBMkQsTUFBTTtBQUNqRTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLDJEQUEyRCxNQUFNO0FBQ2pFO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsZ0JBQWdCLFFBQVE7QUFDeEIsZ0JBQWdCLFlBQVk7QUFDNUI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSw0QkFBNEIsa0JBQWtCO0FBQzlDO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsNEJBQTRCLGtCQUFrQjtBQUM5QztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHlDQUF5QyxTQUFTO0FBQ2xEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxnQkFBZ0IsUUFBUTtBQUN4QixnQkFBZ0IsWUFBWTtBQUM1QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSx3QkFBd0Isa0JBQWtCO0FBQzFDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHlDQUF5QyxTQUFTO0FBQ2xEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLDhCQUE4QjtBQUM5QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGdCQUFnQixnRUFBZ0U7QUFDaEY7QUFDQSxvQkFBb0IsdUNBQXVDO0FBQzNEO0FBQ0EsNEJBQTRCLDBCQUEwQjtBQUN0RDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLG1DQUFtQyxFQUFFLG9CQUFvQixNQUFNO0FBQy9EO0FBQ0E7QUFDQSwyQkFBMkIsc0JBQXNCO0FBQ2pEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxnQkFBZ0IsWUFBWTtBQUM1QjtBQUNBO0FBQ0E7QUFDQTtBQUNBLGdEQUFnRCxTQUFTO0FBQ3pEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxnQkFBZ0IsWUFBWTtBQUM1QjtBQUNBO0FBQ0E7QUFDQTtBQUNBLHdCQUF3QixrQkFBa0I7QUFDMUM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxnQkFBZ0IsUUFBUTtBQUN4QixnQkFBZ0IsWUFBWTtBQUM1QjtBQUNBO0FBQ0E7QUFDQTtBQUNBLHdCQUF3QixrQkFBa0I7QUFDMUM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHdCQUF3QixpQkFBaUI7QUFDekM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxnQkFBZ0Isd0JBQXdCO0FBQ3hDO0FBQ0EsNEJBQTRCLGlCQUFpQjtBQUM3QztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHdCQUF3QixpQkFBaUI7QUFDekM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSx3QkFBd0IsaUJBQWlCO0FBQ3pDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHdCQUF3QixpQkFBaUI7QUFDekM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSx3QkFBd0IsaUJBQWlCO0FBQ3pDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esd0JBQXdCLGlCQUFpQjtBQUN6QztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esd0JBQXdCLGlCQUFpQjtBQUN6QztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSx3QkFBd0IsaUJBQWlCO0FBQ3pDO0FBQ0EsNEJBQTRCLG9CQUFvQjtBQUNoRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxnQkFBZ0Isd0JBQXdCO0FBQ3hDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHdCQUF3QixpQkFBaUI7QUFDekM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esd0JBQXdCLGlCQUFpQjtBQUN6QztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSx3QkFBd0IsMEJBQTBCO0FBQ2xEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSw0QkFBNEIsbUJBQW1CO0FBQy9DO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGlCQUFpQjtBQUNqQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsMEhBQTBIO0FBQzFIO0FBQ0E7QUFDQTtBQUNBLDZIQUE2SDtBQUM3SDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSx3SUFBd0k7QUFDeEk7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxnQ0FBZ0MsdUJBQXVCO0FBQ3ZELG9KQUFvSjtBQUNwSjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxnQ0FBZ0MsdUJBQXVCO0FBQ3ZELGdJQUFnSTtBQUNoSTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsZ0NBQWdDLHdCQUF3QjtBQUN4RCxtSUFBbUk7QUFDbkk7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxnQkFBZ0IsUUFBUTtBQUN4QiwwQkFBMEI7QUFDMUI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGFBQWE7QUFDYjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsZ0JBQWdCLFVBQVU7QUFDMUI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EseUJBQXlCO0FBQ3pCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVM7QUFDVDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGdCQUFnQiwyRUFBMkU7QUFDM0YsZ0JBQWdCLFlBQVk7QUFDNUIsZ0JBQWdCLFlBQVk7QUFDNUI7QUFDQSxnQkFBZ0IsU0FBUztBQUN6QjtBQUNBO0FBQ0E7QUFDQSxvQkFBb0IsU0FBUztBQUM3QixpREFBaUQsU0FBUztBQUMxRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGlEQUFpRCxTQUFTO0FBQzFEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLDREQUE0RCxFQUFFLDhCQUE4QixFQUFFLHlCQUF5QixPQUFPLElBQUksVUFBVTtBQUM1STtBQUNBO0FBQ0E7QUFDQTtBQUNBLDREQUE0RCxFQUFFLDhCQUE4QixFQUFFLHlCQUF5QixPQUFPLElBQUksVUFBVTtBQUM1STtBQUNBO0FBQ0E7QUFDQSxpREFBaUQsT0FBTyxJQUFJLFVBQVU7QUFDdEU7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHFDQUFxQyxFQUFFO0FBQ3ZDO0FBQ0EscUNBQXFDLEVBQUU7QUFDdkM7QUFDQSxxQ0FBcUMsRUFBRTtBQUN2QztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLDZEQUE2RCxTQUFTO0FBQ3RFO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGdEQUFnRCxFQUFFLElBQUksRUFBRTtBQUN4RDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLDBCQUEwQjtBQUMxQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxXQUFXO0FBQ1g7QUFDQTtBQUNBLHdCQUF3QjtBQUN4QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0E7QUFDQSxzQkFBc0I7QUFDdEI7QUFDQSx3QkFBd0Isc0JBQXNCO0FBQzlDO0FBQ0EseUNBQXlDLGtCQUFrQjtBQUMzRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxPQUFPO0FBQ1A7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSwwQkFBMEI7QUFDMUI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFdBQVc7QUFDWDtBQUNBO0FBQ0Esd0JBQXdCO0FBQ3hCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBLHNCQUFzQjtBQUN0QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsT0FBTztBQUNQO0FBQ0E7QUFDQTtBQUNBLDRCQUE0QjtBQUM1QjtBQUNBLDRCQUE0QjtBQUM1Qix3REFBd0Q7QUFDeEQ7QUFDQTtBQUNBLGdEQUFnRDtBQUNoRCxxREFBcUQ7QUFDckQ7QUFDQTtBQUNBO0FBQ0Esd0JBQXdCO0FBQ3hCO0FBQ0E7QUFDQSxnREFBZ0Q7QUFDaEQscURBQXFEO0FBQ3JELHFEQUFxRDtBQUNyRCx1REFBdUQ7QUFDdkQsZ0VBQWdFO0FBQ2hFO0FBQ0E7QUFDQSwyQ0FBMkM7QUFDM0MsMkJBQTJCLG9CQUFvQjtBQUMvQyxhQUFhLEVBQUU7QUFDZjtBQUNBO0FBQ0E7QUFDQTtBQUNBLDZDQUE2QyxTQUFTO0FBQ3REO0FBQ0EscUNBQXFDLEVBQUU7QUFDdkMsZUFBZSxxQkFBcUI7QUFDcEMsY0FBYyx5REFBeUQ7QUFDdkUsZUFBZSwyREFBMkQ7QUFDMUUsaUJBQWlCO0FBQ2pCLEtBQUs7QUFDTDtBQUNBO0FBQ0E7QUFDQTtBQUNBLHVEQUF1RCxPQUFPO0FBQzlEO0FBQ0EsOEhBQThIO0FBQzlIO0FBQ0EsNkRBQTZEO0FBQzdELDJEQUEyRDtBQUMzRCxxREFBcUQ7QUFDckQ7QUFDQTtBQUNBLCtEQUErRCxPQUFPLElBQUk7QUFDMUUsOENBQThDLGlCQUFpQjtBQUMvRDtBQUNBLFlBQVk7QUFDWixnQkFBZ0I7QUFDaEI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGdCQUFnQjtBQUNoQixlQUFlO0FBQ2Y7QUFDQTtBQUNBO0FBQ0E7QUFDQSxjQUFjO0FBQ2Q7QUFDQTtBQUNBLG9DQUFvQyx1QkFBdUI7QUFDM0Q7QUFDQSxtQkFBbUIsVUFBVTtBQUM3QjtBQUNBO0FBQ0EsTUFBTSxpQkFBaUI7QUFDdkIsMENBQTBDLG1CQUFtQix1QkFBdUI7QUFDcEY7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQSxFQUFFO0FBQ0Y7QUFDQTtBQUNBLE1BQU07QUFDTiw2Q0FBNkMscUNBQXFDO0FBQ2xGLDhDQUE4QztBQUM5QztBQUNBLElBQUk7QUFDSjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxJQUFJO0FBQ0osSUFBSTs7QUFFSjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsSUFBSTtBQUNKLElBQUk7QUFDSixJQUFJO0FBQ0osSUFBSTtBQUNKLElBQUksZ0JBQWdCO0FBQ3BCO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esd0JBQXdCOztBQUV4QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLG9FQUFvRTtBQUNwRSw2REFBNkQ7QUFDN0QsNkNBQTZDO0FBQzdDO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsYUFBYTtBQUNiO0FBQ0E7QUFDQTtBQUNBLFdBQVcsYUFBYTtBQUN4QjtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUEscUJBQXFCLHFFQUFxRTtBQUMxRjtBQUNBLG1CQUFtQixvQkFBb0I7QUFDdkMsbUJBQW1CLG1DQUFtQztBQUN0RCx1QkFBdUIsV0FBVztBQUNsQyx3QkFBd0IsV0FBVztBQUNuQztBQUNBO0FBQ0Esc0JBQXNCLGFBQWE7QUFDbkMsdUJBQXVCLGlCQUFpQjtBQUN4QztBQUNBLG9CQUFvQixXQUFXO0FBQy9CLG9CQUFvQiwwQkFBMEI7QUFDOUMsb0JBQW9CLG9CQUFvQjtBQUN4QyxvQkFBb0IsMEJBQTBCO0FBQzlDLDhCQUE4QixZQUFZLGVBQWUsV0FBVztBQUNwRSx1QkFBdUIsZUFBZTtBQUN0QztBQUNBO0FBQ0EsbUJBQW1CLFdBQVc7QUFDOUIsbUJBQW1CLDhCQUE4QjtBQUNqRDtBQUNBLDJCQUEyQixTQUFTO0FBQ3BDLHVCQUF1QixjQUFjLElBQUksbUJBQW1CO0FBQzVEO0FBQ0E7QUFDQTtBQUNBLHNCQUFzQiw4Q0FBOEM7QUFDcEU7QUFDQSxrQkFBa0IsNkJBQTZCO0FBQy9DLGtCQUFrQiwwQkFBMEI7QUFDNUMsaUJBQWlCLE9BQU87QUFDeEI7QUFDQTtBQUNBLG9CQUFvQixhQUFhO0FBQ2pDLHFCQUFxQixpQkFBaUI7QUFDdEM7QUFDQSxzQkFBc0IscURBQXFEO0FBQzNFO0FBQ0Esa0JBQWtCLDZCQUE2QjtBQUMvQyxrQkFBa0IsMEJBQTBCO0FBQzVDLGlCQUFpQixPQUFPO0FBQ3hCO0FBQ0E7QUFDQSxvQkFBb0IsY0FBYztBQUNsQyxxQkFBcUIsa0JBQWtCO0FBQ3ZDO0FBQ0Esa0JBQWtCLHNDQUFzQztBQUN4RCxrQkFBa0IsMEJBQTBCO0FBQzVDLGtCQUFrQiwwQ0FBMEM7QUFDNUQsa0JBQWtCLDBCQUEwQjtBQUM1Qyw0QkFBNEIsWUFBWSxlQUFlLFdBQVc7QUFDbEUscUJBQXFCLGVBQWU7QUFDcEM7QUFDQSxtQ0FBbUMsNEVBQTRFO0FBQy9HO0FBQ0Esa0JBQWtCLDRDQUE0QztBQUM5RCxrQkFBa0IsNENBQTRDO0FBQzlELGtCQUFrQixzQ0FBc0M7QUFDeEQsa0JBQWtCLDBCQUEwQjtBQUM1Qyw0QkFBNEIsWUFBWSxlQUFlLFdBQVc7QUFDbEUscUJBQXFCLGVBQWU7QUFDcEM7QUFDQTtBQUNBLFlBQVksdUJBQXVCO0FBQ25DO0FBQ0E7QUFDQSx5QkFBeUIsdUJBQXVCO0FBQ2hEO0FBQ0E7QUFDQSwwQkFBMEIsWUFBWTtBQUN0QztBQUNBLG1DQUFtQyx5Q0FBeUM7QUFDNUU7QUFDQTtBQUNBO0FBQ0Esd0NBQXdDLHlDQUF5QztBQUNqRjtBQUNBO0FBQ0Esd0NBQXdDLHlDQUF5QztBQUNqRjtBQUNBO0FBQ0E7QUFDQSxzREFBc0Qsd0NBQXdDO0FBQzlGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxxQkFBcUI7QUFDckI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esb0NBQW9DLHFEQUFxRDtBQUN6RjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxxQkFBcUIsT0FBTyxFQUFFLE9BQU8sSUFBSSxJQUFJLEVBQUUsR0FBRyxJQUFJLElBQUksRUFBRSxHQUFHLElBQUksR0FBRyxFQUFFLEVBQUU7QUFDMUUsd0JBQXdCLG9CQUFvQjtBQUM1Qyw4QkFBOEIsb0JBQW9CO0FBQ2xEO0FBQ0E7QUFDQTtBQUNBLHVCQUF1Qix3QkFBd0I7QUFDL0M7QUFDQTtBQUNBLFlBQVksOENBQThDO0FBQzFEO0FBQ0E7QUFDQTtBQUNBLG1EQUFtRCxvQkFBb0I7QUFDdkU7QUFDQTtBQUNBO0FBQ0EseUJBQXlCLHVCQUF1QjtBQUNoRDtBQUNBO0FBQ0EsMEJBQTBCLFlBQVk7QUFDdEM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxhQUFhO0FBQ2I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFlBQVksVUFBVTtBQUN0QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxvQkFBb0IsaUNBQWlDO0FBQ3JEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxZQUFZLFVBQVU7QUFDdEI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLG9CQUFvQixpQ0FBaUM7QUFDckQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EscUJBQXFCLE1BQU07QUFDM0Isc0JBQXNCLE9BQU8sSUFBSSxRQUFRO0FBQ3pDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxZQUFZLGlCQUFpQjtBQUM3QixZQUFZLHNDQUFzQztBQUNsRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxZQUFZLFVBQVU7QUFDdEIsWUFBWSxzQ0FBc0M7QUFDbEQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVM7QUFDVDtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVM7QUFDVDtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVM7QUFDVDtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLDRCQUE0QjtBQUM1QixZQUFZLHdCQUF3QjtBQUNwQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGdCQUFnQixzQ0FBc0M7QUFDdEQ7QUFDQTtBQUNBO0FBQ0E7QUFDQSxnQkFBZ0Isc0NBQXNDO0FBQ3REO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVM7QUFDVDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxpQkFBaUI7QUFDakI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsaUJBQWlCO0FBQ2pCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsZ0JBQWdCLHNDQUFzQztBQUN0RDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsZ0JBQWdCLGdCQUFnQjtBQUNoQztBQUNBO0FBQ0EsaUhBQWlIO0FBQ2pIO0FBQ0E7QUFDQSxvQkFBb0I7QUFDcEI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxpQkFBaUI7QUFDakI7QUFDQTtBQUNBLDRDQUE0QyxPQUFPLG9CQUFvQixNQUFNO0FBQzdFO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGFBQWE7QUFDYjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsaUJBQWlCO0FBQ2pCO0FBQ0E7QUFDQTtBQUNBOztBQUVBLHFCQUFxQjtBQUNyQixtQkFBbUI7QUFDbkIscUJBQXFCO0FBQ3JCLHdCQUF3QjtBQUN4QixpQkFBaUI7QUFDakIsbUJBQW1CO0FBQ25CLGtCQUFrQjtBQUNsQixhQUFhO0FBQ2Isa0JBQWtCO0FBQ2xCLGNBQWM7QUFDZCxjQUFjO0FBQ2QsY0FBYztBQUNkLGlCQUFpQjtBQUNqQixpQkFBaUI7QUFDakI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ2h6U0E7QUFFQTtBQUNBOzs7QUFFQSxNQUFNRyxLQUF5QixHQUFHLENBQUM7QUFBRUMsRUFBQUEsU0FBRjtBQUFhQyxFQUFBQTtBQUFiLENBQUQsS0FBOEI7QUFDOUQsc0JBQ0UsOERBQUMsNERBQUQ7QUFBQSwyQkFDRSw4REFBQyxvRUFBRDtBQUFBLDZCQUNFLDhEQUFDLFNBQUQsb0JBQWVBLFNBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBREY7QUFPRCxDQVJEOztBQVVBLGlFQUFlRixLQUFmOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNmQTtBQUNBO0NBRUE7O0FBQ0E7O0FBcUZPLE1BQU1XLFlBQVksZ0JBQUdSLG9EQUFhLENBQUMsRUFBRCxDQUFsQztBQUVBLE1BQU1KLGFBQWEsR0FBRyxDQUFDO0FBQUVhLEVBQUFBO0FBQUYsQ0FBRCxLQUFrQjtBQUU3QyxRQUFNO0FBQUEsT0FBQ0MsUUFBRDtBQUFBLE9BQVdDO0FBQVgsTUFBMEJSLCtDQUFRLENBQUMsS0FBRCxDQUF4QztBQUNBLFFBQU07QUFBQSxPQUFDUyxTQUFEO0FBQUEsT0FBWUM7QUFBWixNQUE0QlYsK0NBQVEsQ0FBYyxFQUFkLENBQTFDO0FBQ0EsUUFBTTtBQUFBLE9BQUNXLFVBQUQ7QUFBQSxPQUFhQztBQUFiLE1BQThCWiwrQ0FBUSxDQUFDLEVBQUQsQ0FBNUM7QUFDQSxRQUFNO0FBQUEsT0FBQ2EsWUFBRDtBQUFBLE9BQWVDO0FBQWYsTUFBa0NkLCtDQUFRLENBQWlCLEVBQWpCLENBQWhEO0FBRUEsUUFBTTtBQUFBLE9BQUNlLFNBQUQ7QUFBQSxPQUFZQztBQUFaLE1BQTRCaEIsK0NBQVEsQ0FBQyxFQUFELENBQTFDO0FBQ0EsUUFBTTtBQUFBLE9BQUNpQixVQUFEO0FBQUEsT0FBYUM7QUFBYixNQUE4QmxCLCtDQUFRLENBQUMsRUFBRCxDQUE1QztBQUVBLFFBQU1tQixrQkFBa0IsR0FBRztBQUN6QkMsSUFBQUEsSUFBSSxFQUFFO0FBQ0pDLE1BQUFBLE1BQU0sRUFBRUosVUFBVSxDQUFDSyxHQUFYLENBQWUsQ0FBRUMsQ0FBRixFQUFLQyxLQUFMLEtBQWdCQSxLQUEvQixDQURKO0FBRUpDLE1BQUFBLFFBQVEsRUFBRSxDQUFDO0FBQ1RMLFFBQUFBLElBQUksRUFBRUgsVUFBVSxDQUFDSyxHQUFYLENBQWdCRixJQUFELElBQVVBLElBQXpCLENBREc7QUFFVE0sUUFBQUEsS0FBSyxFQUFFLFVBRkU7QUFHVEMsUUFBQUEsV0FBVyxFQUFFLG1CQUhKO0FBSVRDLFFBQUFBLGVBQWUsRUFBRTtBQUpSLE9BQUQ7QUFGTixLQURtQjtBQVV6QkMsSUFBQUEsT0FBTyxFQUFFO0FBQ1BDLE1BQUFBLFVBQVUsRUFBRSxJQURMO0FBRVBDLE1BQUFBLE9BQU8sRUFBRTtBQUNQQyxRQUFBQSxNQUFNLEVBQUU7QUFDTkMsVUFBQUEsUUFBUSxFQUFFO0FBREosU0FERDtBQUlQQyxRQUFBQSxLQUFLLEVBQUU7QUFDTEMsVUFBQUEsT0FBTyxFQUFFLElBREo7QUFFTEMsVUFBQUEsSUFBSSxFQUFFO0FBRkQ7QUFKQTtBQUZGO0FBVmdCLEdBQTNCO0FBd0JBLFFBQU1DLGlCQUFpQixHQUFHO0FBQ3hCakIsSUFBQUEsSUFBSSxFQUFFO0FBQ0pDLE1BQUFBLE1BQU0sRUFBRVIsWUFBWSxDQUFDUyxHQUFiLENBQWlCLENBQUM7QUFBRWdCLFFBQUFBO0FBQUYsT0FBRCxLQUFjLElBQUlDLElBQUosQ0FBU0QsSUFBVCxFQUFlRSxrQkFBZixFQUEvQixDQURKO0FBRUpmLE1BQUFBLFFBQVEsRUFBRSxDQUFDO0FBQ1RMLFFBQUFBLElBQUksRUFBRVAsWUFBWSxDQUFDUyxHQUFiLENBQWtCRixJQUFELElBQVVBLElBQUksQ0FBQ3FCLFNBQWhDLENBREc7QUFFVGYsUUFBQUEsS0FBSyxFQUFFLFVBRkU7QUFHVEMsUUFBQUEsV0FBVyxFQUFFLG1CQUhKO0FBSVRDLFFBQUFBLGVBQWUsRUFBRTtBQUpSLE9BQUQsRUFLUDtBQUNEUixRQUFBQSxJQUFJLEVBQUVQLFlBQVksQ0FBQ1MsR0FBYixDQUFrQkYsSUFBRCxJQUFVQSxJQUFJLENBQUNzQixNQUFoQyxDQURMO0FBRURoQixRQUFBQSxLQUFLLEVBQUUsUUFGTjtBQUdEQyxRQUFBQSxXQUFXLEVBQUUsbUJBSFo7QUFJREMsUUFBQUEsZUFBZSxFQUFFO0FBSmhCLE9BTE87QUFGTixLQURrQjtBQWV4QkMsSUFBQUEsT0FBTyxFQUFFO0FBQ1BDLE1BQUFBLFVBQVUsRUFBRSxJQURMO0FBRVBDLE1BQUFBLE9BQU8sRUFBRTtBQUNQQyxRQUFBQSxNQUFNLEVBQUU7QUFDTkMsVUFBQUEsUUFBUSxFQUFFO0FBREosU0FERDtBQUlQQyxRQUFBQSxLQUFLLEVBQUU7QUFDTEMsVUFBQUEsT0FBTyxFQUFFLElBREo7QUFFTEMsVUFBQUEsSUFBSSxFQUFFO0FBRkQ7QUFKQTtBQUZGO0FBZmUsR0FBMUI7O0FBNkJBLFFBQU1PLFFBQVEsR0FBRyxDQUFDOUIsWUFBRCxFQUErQkUsU0FBL0IsS0FBcUQ7QUFDcEVQLElBQUFBLFdBQVcsQ0FBQyxJQUFELENBQVg7QUFFQSxVQUFNb0MsZUFBZSxHQUFHLElBQUlDLEtBQUosQ0FBVSxFQUFWLEVBQWNDLElBQWQsQ0FBbUIsQ0FBbkIsQ0FBeEI7O0FBRUEsUUFBSWpDLFlBQUosRUFBa0I7QUFDaEIsV0FBSSxJQUFJa0MsQ0FBQyxHQUFHLENBQVosRUFBZUEsQ0FBQyxJQUFJLEVBQXBCLEVBQXdCQSxDQUFDLEVBQXpCLEVBQThCO0FBQUE7O0FBQzVCSCxRQUFBQSxlQUFlLENBQUNHLENBQUQsQ0FBZixvQkFBcUJsQyxZQUFZLENBQUNBLFlBQVksQ0FBQ21DLE1BQWIsR0FBc0IsRUFBdEIsR0FBMkJELENBQTVCLENBQWpDLGtEQUFxQixjQUE0Q04sU0FBakU7QUFDRDtBQUNGOztBQUVELFVBQU1RLFVBQVUsR0FBRzdDLGdFQUFBLENBQXFCd0MsZUFBckIsQ0FBbkI7QUFFQSxVQUFNTyxPQUFPLEdBQUcsSUFBSWhELDREQUFKLENBQWlDO0FBQy9DbUQsTUFBQUEsU0FBUyxFQUFFLENBRG9DO0FBRS9DQyxNQUFBQSxZQUFZLEVBQUUsQ0FBQyxFQUFELENBRmlDO0FBRy9DQyxNQUFBQSxVQUFVLEVBQUU7QUFIbUMsS0FBakMsQ0FBaEI7QUFNQUwsSUFBQUEsT0FBTyxDQUFDTSxLQUFSLENBQWMsQ0FBQ1IsVUFBRCxDQUFkLEVBQTRCO0FBQzFCUyxNQUFBQSxZQUFZLEVBQUUsS0FEWTtBQUUxQkMsTUFBQUEsV0FBVyxFQUFFLElBRmE7QUFHMUJDLE1BQUFBLEdBQUcsRUFBRUMsS0FBSyxJQUFJO0FBQ1pDLFFBQUFBLE9BQU8sQ0FBQ0YsR0FBUixDQUFZQyxLQUFaO0FBQ0Q7QUFMeUIsS0FBNUI7QUFRQSxVQUFNRSxNQUFNLEdBQUdaLE9BQU8sQ0FBQ1IsUUFBUixDQUFpQixDQUFDLENBQUQsQ0FBakIsRUFBc0I1QixTQUF0QixDQUFmO0FBQ0FHLElBQUFBLGFBQWEsQ0FBQ2Qsb0VBQUEsQ0FBeUIyRCxNQUF6QixDQUFELENBQWI7QUFDQXZELElBQUFBLFdBQVcsQ0FBQyxLQUFELENBQVg7QUFDRCxHQTlCRDs7QUFnQ0FULEVBQUFBLGdEQUFTLENBQUMsTUFBTTtBQUNkLFVBQU1rRSxhQUFhLEdBQUcsWUFBWTtBQUNoQyxZQUFNQyxnQkFBZ0IsR0FBRyxNQUFNakUsNkRBQWMsRUFBN0M7O0FBRUEsVUFBSWlFLGdCQUFKLEVBQXNCO0FBQ3BCeEQsUUFBQUEsWUFBWSxDQUFDd0QsZ0JBQUQsQ0FBWjtBQUNEO0FBQ0YsS0FORDs7QUFRQSxVQUFNQyxjQUFjLEdBQUcsWUFBWTtBQUNqQyxZQUFNeEQsVUFBVSxHQUFHLE1BQU1ULDhEQUFlLEVBQXhDOztBQUNBLFVBQUlTLFVBQUosRUFBZ0I7QUFDZEMsUUFBQUEsYUFBYSxDQUFDRCxVQUFELENBQWI7QUFDRDtBQUNGLEtBTEQ7O0FBT0FzRCxJQUFBQSxhQUFhO0FBQ2JFLElBQUFBLGNBQWM7QUFDZixHQWxCUSxFQWtCTixFQWxCTSxDQUFUO0FBb0JBLHNCQUNFLDhEQUFDLFlBQUQsQ0FBYyxRQUFkO0FBQ0UsU0FBSyxFQUFFO0FBQ0x0RCxNQUFBQSxZQURLO0FBRUxDLE1BQUFBLGVBRks7QUFHTEosTUFBQUEsWUFISztBQUlMRCxNQUFBQSxTQUpLO0FBS0w0QixNQUFBQSxpQkFMSztBQU1MTSxNQUFBQSxRQU5LO0FBT0w1QixNQUFBQSxTQVBLO0FBUUxDLE1BQUFBLFlBUks7QUFTTEMsTUFBQUEsVUFUSztBQVVMRSxNQUFBQSxrQkFWSztBQVdMWixNQUFBQTtBQVhLLEtBRFQ7QUFBQSxjQWVHRDtBQWZIO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFERjtBQW1CRCxDQXRJTSxFQXdJUDs7QUFDTyxNQUFNOEQsZUFBZSxHQUFHLE1BQU10RSxpREFBVSxDQUFDTyxZQUFELENBQXhDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNwT1A7QUFFTyxNQUFNaUUsR0FBRyxHQUFHRCxtREFBQSxDQUFhO0FBQzlCRyxFQUFBQSxPQUFPLEVBQUU7QUFEcUIsQ0FBYixDQUFaO0FBSVBGLEdBQUcsQ0FBQ0csUUFBSixDQUFhQyxPQUFiLENBQXFCLGlCQUFyQixJQUEwQyxvQ0FBMUM7QUFDQUosR0FBRyxDQUFDRyxRQUFKLENBQWFDLE9BQWIsQ0FBcUIsZ0JBQXJCLElBQXlDLG9EQUF6QztBQUVBSixHQUFHLENBQUNLLFlBQUosQ0FBaUJDLE9BQWpCLENBQXlCQyxHQUF6QixDQUE2QkMsTUFBTSxJQUFJO0FBQ3JDaEIsRUFBQUEsT0FBTyxDQUFDRixHQUFSLENBQVlrQixNQUFaO0FBQ0EsU0FBT0EsTUFBUDtBQUNELENBSEQ7QUFLTyxNQUFNNUUsZUFBZSxHQUFHLFlBQVk7QUFDekMsTUFBSTtBQUNGLFVBQU07QUFBRWtCLE1BQUFBO0FBQUYsUUFBVyxNQUFNa0QsR0FBRyxDQUFDUyxHQUFKLENBQVEsUUFBUixDQUF2QjtBQUNBLFdBQU8zRCxJQUFQO0FBQ0QsR0FIRCxDQUdFLE9BQU80RCxHQUFQLEVBQVk7QUFDWixXQUFPQSxHQUFQO0FBQ0Q7QUFDRixDQVBNO0FBU0EsTUFBTS9FLGNBQWMsR0FBRyxZQUFZO0FBQ3hDLE1BQUk7QUFDRixVQUFNO0FBQUVtQixNQUFBQTtBQUFGLFFBQVcsTUFBTWlELGdEQUFBLENBQVUsZ0RBQVYsQ0FBdkI7QUFFQSxXQUFPakQsSUFBSSxDQUFDRSxHQUFMLENBQVMsQ0FBQztBQUFFMkQsTUFBQUEsUUFBRjtBQUFZQyxNQUFBQSxTQUFaO0FBQXVCQyxNQUFBQSxLQUF2QjtBQUE4QkMsTUFBQUEsV0FBVyxFQUFFOUM7QUFBM0MsS0FBRCxNQUF3RDtBQUFFRyxNQUFBQSxTQUFTLEVBQUV3QyxRQUFiO0FBQXVCQyxNQUFBQSxTQUF2QjtBQUFrQ3hDLE1BQUFBLE1BQU0sRUFBRXlDLEtBQTFDO0FBQWlEN0MsTUFBQUE7QUFBakQsS0FBeEQsQ0FBVCxDQUFQO0FBQ0QsR0FKRCxDQUlFLE9BQU8rQyxLQUFQLEVBQWM7QUFDZCxXQUFPQSxLQUFQO0FBQ0Q7QUFDRixDQVJNOzs7Ozs7Ozs7Ozs7OztBQ3ZCUCxJQUFJQyxLQUFLLEdBQUcsQ0FBWjtBQUNBLElBQUlDLEtBQUssR0FBRyxDQUFaO0FBQ0EsSUFBSUMsSUFBSSxHQUFHLENBQVg7QUFDQSxJQUFJQyxJQUFJLEdBQUcsQ0FBWDtBQUVBLElBQUlyRSxJQUFJLEdBQUc7QUFBRW1FLEVBQUFBLEtBQUssRUFBRUEsS0FBVDtBQUFnQkQsRUFBQUEsS0FBSyxFQUFFQSxLQUF2QjtBQUE4QkcsRUFBQUEsSUFBSSxFQUFFQSxJQUFwQztBQUEwQ0QsRUFBQUEsSUFBSSxFQUFFQTtBQUFoRCxDQUFYOztBQUVBLFNBQVNFLEdBQVQsQ0FBYUMsQ0FBYixFQUFnQkMsR0FBRyxHQUFHLENBQXRCLEVBQXlCQyxHQUFHLEdBQUcsQ0FBL0IsRUFBa0M7QUFDaENOLEVBQUFBLEtBQUssR0FBR08sSUFBSSxDQUFDRCxHQUFMLENBQVNFLEtBQVQsQ0FBZSxJQUFmLEVBQXFCSixDQUFyQixDQUFSO0FBQ0FMLEVBQUFBLEtBQUssR0FBR1EsSUFBSSxDQUFDRixHQUFMLENBQVNHLEtBQVQsQ0FBZSxJQUFmLEVBQXFCSixDQUFyQixDQUFSO0FBQ0FILEVBQUFBLElBQUksR0FBR0ksR0FBUDtBQUNBSCxFQUFBQSxJQUFJLEdBQUdJLEdBQVA7QUFFQXpFLEVBQUFBLElBQUksR0FBRztBQUFFbUUsSUFBQUEsS0FBSyxFQUFFQSxLQUFUO0FBQWdCRCxJQUFBQSxLQUFLLEVBQUVBLEtBQXZCO0FBQThCRyxJQUFBQSxJQUFJLEVBQUVBLElBQXBDO0FBQTBDRCxJQUFBQSxJQUFJLEVBQUVBO0FBQWhELEdBQVA7QUFFQSxRQUFNUSxRQUFRLEdBQUdMLENBQUMsQ0FBQ3JFLEdBQUYsQ0FBTSxVQUFVMkUsTUFBVixFQUFrQjtBQUN2QyxXQUFPQSxNQUFNLEdBQUdYLEtBQWhCO0FBQ0QsR0FGZ0IsQ0FBakIsQ0FSZ0MsQ0FXaEM7O0FBQ0EsUUFBTVksS0FBSyxHQUFHRixRQUFRLENBQUMxRSxHQUFULENBQWEsVUFBVTJFLE1BQVYsRUFBa0I7QUFDM0MsV0FBT0EsTUFBTSxJQUFJVixLQUFLLEdBQUdELEtBQVosQ0FBYjtBQUNELEdBRmEsQ0FBZCxDQVpnQyxDQWVoQzs7QUFDQSxRQUFNYSxRQUFRLEdBQUdELEtBQUssQ0FBQzVFLEdBQU4sQ0FBVSxVQUFVMkUsTUFBVixFQUFrQjtBQUMzQyxXQUFPQSxNQUFNLElBQUlKLEdBQUcsR0FBR0QsR0FBVixDQUFOLEdBQXVCQSxHQUE5QjtBQUNELEdBRmdCLENBQWpCO0FBSUEsU0FBT08sUUFBUDtBQUNEOztBQUVELFNBQVNqRCxhQUFULENBQXVCOUIsSUFBdkIsRUFBNkJ3RSxHQUFHLEdBQUcsQ0FBbkMsRUFBc0NDLEdBQUcsR0FBRyxDQUE1QyxFQUErQztBQUM3QyxRQUFNTyxZQUFZLEdBQUdWLEdBQUcsQ0FBQ3RFLElBQUQsRUFBT3dFLEdBQVAsRUFBWUMsR0FBWixDQUF4QjtBQUdBLFNBQU9PLFlBQVA7QUFDRDs7QUFFRCxTQUFTcEMsaUJBQVQsQ0FBMkJxQyxLQUEzQixFQUFrQ1QsR0FBRyxHQUFHLENBQXhDLEVBQTJDQyxHQUFHLEdBQUcsQ0FBakQsRUFBb0Q7QUFDbEQsUUFBTUgsR0FBRyxHQUFHdEUsSUFBWjtBQUNBMEMsRUFBQUEsT0FBTyxDQUFDRixHQUFSLENBQVk4QixHQUFaO0FBRUEsUUFBTUMsQ0FBQyxHQUFHVSxLQUFLLENBQUMvRSxHQUFOLENBQVUsVUFBVTJFLE1BQVYsRUFBa0I7QUFDcEMsV0FBTyxDQUFDQSxNQUFNLEdBQUdMLEdBQVYsS0FBa0JDLEdBQUcsR0FBR0QsR0FBeEIsQ0FBUDtBQUNELEdBRlMsQ0FBVjtBQUdBLFFBQU1VLEVBQUUsR0FBR1gsQ0FBQyxDQUFDckUsR0FBRixDQUFNLFVBQVUyRSxNQUFWLEVBQWtCO0FBQ2pDLFdBQU9BLE1BQU0sSUFBSVAsR0FBRyxDQUFDSCxLQUFKLEdBQVlHLEdBQUcsQ0FBQ0osS0FBcEIsQ0FBTixHQUFtQ0ksR0FBRyxDQUFDSixLQUE5QztBQUNELEdBRlUsQ0FBWDtBQUlBLFNBQU9nQixFQUFQO0FBQ0Q7O0FBRUQsaUVBQWU7QUFBRXBELEVBQUFBLGFBQUY7QUFBaUJjLEVBQUFBO0FBQWpCLENBQWY7Ozs7Ozs7Ozs7QUNuREE7Ozs7Ozs7Ozs7QUNBQTs7Ozs7Ozs7OztBQ0FBOzs7Ozs7Ozs7O0FDQUE7Ozs7Ozs7Ozs7QUNBQTs7Ozs7Ozs7OztBQ0FBIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vcmVhY3RzZXR1cC8uL25vZGVfbW9kdWxlcy9icmFpbi5qcy9kaXN0L3NyYy9pbmRleCIsIndlYnBhY2s6Ly9yZWFjdHNldHVwLy4vcGFnZXMvX2FwcC50c3giLCJ3ZWJwYWNrOi8vcmVhY3RzZXR1cC8uL3NyYy9jb250ZXh0L0JyYWluQ29udGV4dC50c3giLCJ3ZWJwYWNrOi8vcmVhY3RzZXR1cC8uL3NyYy9zZXJ2aWNlcy9hcGkudHMiLCJ3ZWJwYWNrOi8vcmVhY3RzZXR1cC8uL3NyYy91dGlscy9zY2FsZXIudHMiLCJ3ZWJwYWNrOi8vcmVhY3RzZXR1cC9leHRlcm5hbCBcIkBjaGFrcmEtdWkvcmVhY3RcIiIsIndlYnBhY2s6Ly9yZWFjdHNldHVwL2V4dGVybmFsIFwiYXhpb3NcIiIsIndlYnBhY2s6Ly9yZWFjdHNldHVwL2V4dGVybmFsIFwiZ3B1LmpzXCIiLCJ3ZWJwYWNrOi8vcmVhY3RzZXR1cC9leHRlcm5hbCBcInJlYWN0XCIiLCJ3ZWJwYWNrOi8vcmVhY3RzZXR1cC9leHRlcm5hbCBcInJlYWN0L2pzeC1kZXYtcnVudGltZVwiIiwid2VicGFjazovL3JlYWN0c2V0dXAvZXh0ZXJuYWwgXCJzdHJlYW1cIiJdLCJzb3VyY2VzQ29udGVudCI6WyIndXNlIHN0cmljdCc7XG5cbk9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCAnX19lc01vZHVsZScsIHsgdmFsdWU6IHRydWUgfSk7XG5cbnZhciBncHVfanMgPSByZXF1aXJlKCdncHUuanMnKTtcbnZhciBzdHJlYW0gPSByZXF1aXJlKCdzdHJlYW0nKTtcblxuLyoqXG4gKiBSZWx1IEFjdGl2YXRpb24sIGFrYSBSZWN0aWZpZWQgTGluZWFyIFVuaXQgQWN0aXZhdGlvblxuICogQGRlc2NyaXB0aW9uIGh0dHBzOi8vZW4ud2lraXBlZGlhLm9yZy93aWtpL1JlY3RpZmllcl8obmV1cmFsX25ldHdvcmtzKVxuICovXG5mdW5jdGlvbiBhY3RpdmF0ZSQzKHdlaWdodCkge1xuICAgIHJldHVybiBNYXRoLm1heCgwLCB3ZWlnaHQpO1xufVxuLyoqXG4gKiBSZWx1IGRlcml2YXRpdmVcbiAqL1xuZnVuY3Rpb24gbWVhc3VyZSQzKHdlaWdodCwgZGVsdGEpIHtcbiAgICBpZiAod2VpZ2h0IDw9IDApIHtcbiAgICAgICAgcmV0dXJuIDA7XG4gICAgfVxuICAgIHJldHVybiBkZWx0YTtcbn1cblxudmFyIHJlbHUkMiA9IC8qI19fUFVSRV9fKi9PYmplY3QuZnJlZXplKHtcbiAgICBfX3Byb3RvX186IG51bGwsXG4gICAgYWN0aXZhdGU6IGFjdGl2YXRlJDMsXG4gICAgbWVhc3VyZTogbWVhc3VyZSQzXG59KTtcblxuLyoqXG4gKiBzaWdtb2lkIGFjdGl2YXRpb25cbiAqL1xuZnVuY3Rpb24gYWN0aXZhdGUkMih2YWx1ZSkge1xuICAgIHJldHVybiAxIC8gKDEgKyBNYXRoLmV4cCgtdmFsdWUpKTtcbn1cbi8qKlxuICogc2lnbW9pZCBkZXJpdmF0aXZlXG4gKi9cbmZ1bmN0aW9uIG1lYXN1cmUkMih3ZWlnaHQsIGVycm9yKSB7XG4gICAgcmV0dXJuIHdlaWdodCAqICgxIC0gd2VpZ2h0KSAqIGVycm9yO1xufVxuXG52YXIgc2lnbW9pZCQyID0gLyojX19QVVJFX18qL09iamVjdC5mcmVlemUoe1xuICAgIF9fcHJvdG9fXzogbnVsbCxcbiAgICBhY3RpdmF0ZTogYWN0aXZhdGUkMixcbiAgICBtZWFzdXJlOiBtZWFzdXJlJDJcbn0pO1xuXG4vKipcbiAqIEh5cGVyYm9saWMgdGFuXG4gKi9cbmZ1bmN0aW9uIGFjdGl2YXRlJDEod2VpZ2h0KSB7XG4gICAgcmV0dXJuIE1hdGgudGFuaCh3ZWlnaHQpO1xufVxuLyoqXG4gKiBAZGVzY3JpcHRpb24gZ3JhZCBmb3IgeiA9IHRhbmgoeCkgaXMgKDEgLSB6XjIpXG4gKi9cbmZ1bmN0aW9uIG1lYXN1cmUkMSh3ZWlnaHQsIGVycm9yKSB7XG4gICAgcmV0dXJuICgxIC0gd2VpZ2h0ICogd2VpZ2h0KSAqIGVycm9yO1xufVxuXG52YXIgdGFuaCQyID0gLyojX19QVVJFX18qL09iamVjdC5mcmVlemUoe1xuICAgIF9fcHJvdG9fXzogbnVsbCxcbiAgICBhY3RpdmF0ZTogYWN0aXZhdGUkMSxcbiAgICBtZWFzdXJlOiBtZWFzdXJlJDFcbn0pO1xuXG4vKipcbiAqIExlYWt5IFJlbHUgQWN0aXZhdGlvbiwgYWthIExlYWt5IFJlY3RpZmllZCBMaW5lYXIgVW5pdCBBY3RpdmF0aW9uXG4gKiBAZGVzY3JpcHRpb24gaHR0cHM6Ly9lbi53aWtpcGVkaWEub3JnL3dpa2kvUmVjdGlmaWVyXyhuZXVyYWxfbmV0d29ya3MpXG4gKi9cbmZ1bmN0aW9uIGFjdGl2YXRlKHdlaWdodCkge1xuICAgIHJldHVybiB3ZWlnaHQgPiAwID8gd2VpZ2h0IDogMC4wMSAqIHdlaWdodDtcbn1cbi8qKlxuICogTGVha3kgUmVsdSBkZXJpdmF0aXZlXG4gKi9cbmZ1bmN0aW9uIG1lYXN1cmUod2VpZ2h0LCBlcnJvcikge1xuICAgIHJldHVybiB3ZWlnaHQgPiAwID8gZXJyb3IgOiAwLjAxICogZXJyb3I7XG59XG5cbnZhciBsZWFreVJlbHUkMSA9IC8qI19fUFVSRV9fKi9PYmplY3QuZnJlZXplKHtcbiAgICBfX3Byb3RvX186IG51bGwsXG4gICAgYWN0aXZhdGU6IGFjdGl2YXRlLFxuICAgIG1lYXN1cmU6IG1lYXN1cmVcbn0pO1xuXG52YXIgaW5kZXgkMSA9IC8qI19fUFVSRV9fKi9PYmplY3QuZnJlZXplKHtcbiAgICBfX3Byb3RvX186IG51bGwsXG4gICAgcmVsdTogcmVsdSQyLFxuICAgIHNpZ21vaWQ6IHNpZ21vaWQkMixcbiAgICB0YW5oOiB0YW5oJDIsXG4gICAgbGVha3lSZWx1OiBsZWFreVJlbHUkMVxufSk7XG5cbmNsYXNzIENyb3NzVmFsaWRhdGUge1xuICAgIGNvbnN0cnVjdG9yKGluaXRDbGFzc2lmaWVyKSB7XG4gICAgICAgIHRoaXMuanNvbiA9IHtcbiAgICAgICAgICAgIGF2Z3M6IHtcbiAgICAgICAgICAgICAgICBlcnJvcjogMCxcbiAgICAgICAgICAgICAgICBpdGVyYXRpb25zOiAwLFxuICAgICAgICAgICAgICAgIHRlc3RUaW1lOiAwLFxuICAgICAgICAgICAgICAgIHRyYWluVGltZTogMCxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBzdGF0czoge1xuICAgICAgICAgICAgICAgIHRvdGFsOiAwLFxuICAgICAgICAgICAgICAgIHRlc3RTaXplOiAwLFxuICAgICAgICAgICAgICAgIHRyYWluU2l6ZTogMCxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBzZXRzOiBbXSxcbiAgICAgICAgfTtcbiAgICAgICAgdGhpcy5pbml0Q2xhc3NpZmllciA9IGluaXRDbGFzc2lmaWVyO1xuICAgIH1cbiAgICB0ZXN0UGFydGl0aW9uKHRyYWluT3B0cywgdHJhaW5TZXQsIHRlc3RTZXQpIHtcbiAgICAgICAgY29uc3QgY2xhc3NpZmllciA9IHRoaXMuaW5pdENsYXNzaWZpZXIoKTtcbiAgICAgICAgY29uc3QgYmVnaW5UcmFpbiA9IERhdGUubm93KCk7XG4gICAgICAgIGNvbnN0IHRyYWluaW5nU3RhdHMgPSBjbGFzc2lmaWVyLnRyYWluKHRyYWluU2V0LCB0cmFpbk9wdHMpO1xuICAgICAgICBjb25zdCBiZWdpblRlc3QgPSBEYXRlLm5vdygpO1xuICAgICAgICBjb25zdCB0ZXN0U3RhdHMgPSBjbGFzc2lmaWVyLnRlc3QodGVzdFNldCk7XG4gICAgICAgIGNvbnN0IGVuZFRlc3QgPSBEYXRlLm5vdygpO1xuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgLi4udGVzdFN0YXRzLFxuICAgICAgICAgICAgdHJhaW5UaW1lOiBiZWdpblRlc3QgLSBiZWdpblRyYWluLFxuICAgICAgICAgICAgdGVzdFRpbWU6IGVuZFRlc3QgLSBiZWdpblRlc3QsXG4gICAgICAgICAgICBpdGVyYXRpb25zOiB0cmFpbmluZ1N0YXRzLml0ZXJhdGlvbnMsXG4gICAgICAgICAgICBlcnJvcjogdHJhaW5pbmdTdGF0cy5lcnJvcixcbiAgICAgICAgICAgIHRvdGFsOiB0ZXN0U3RhdHMudG90YWwsXG4gICAgICAgICAgICBuZXR3b3JrOiBjbGFzc2lmaWVyLnRvSlNPTigpLFxuICAgICAgICB9O1xuICAgIH1cbiAgICAvKipcbiAgICAgKiBSYW5kb21pemUgYXJyYXkgZWxlbWVudCBvcmRlciBpbi1wbGFjZS5cbiAgICAgKiBVc2luZyBEdXJzdGVuZmVsZCBzaHVmZmxlIGFsZ29yaXRobS5cbiAgICAgKiBzb3VyY2U6IGh0dHA6Ly9zdGFja292ZXJmbG93LmNvbS9hLzEyNjQ2ODY0LzEzMjQwMzlcbiAgICAgKi9cbiAgICBzaHVmZmxlQXJyYXkoYXJyYXkpIHtcbiAgICAgICAgZm9yIChsZXQgaSA9IGFycmF5Lmxlbmd0aCAtIDE7IGkgPiAwOyBpLS0pIHtcbiAgICAgICAgICAgIGNvbnN0IGogPSBNYXRoLmZsb29yKE1hdGgucmFuZG9tKCkgKiAoaSArIDEpKTtcbiAgICAgICAgICAgIGNvbnN0IHRlbXAgPSBhcnJheVtpXTtcbiAgICAgICAgICAgIGFycmF5W2ldID0gYXJyYXlbal07XG4gICAgICAgICAgICBhcnJheVtqXSA9IHRlbXA7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIGFycmF5O1xuICAgIH1cbiAgICB0cmFpbihkYXRhLCB0cmFpbk9wdHMgPSB7fSwgayA9IDQpIHtcbiAgICAgICAgaWYgKGRhdGEubGVuZ3RoIDwgaykge1xuICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKGBUcmFpbmluZyBzZXQgc2l6ZSBpcyB0b28gc21hbGwgZm9yICR7ZGF0YS5sZW5ndGh9IGsgZm9sZHMgb2YgJHtrfWApO1xuICAgICAgICB9XG4gICAgICAgIHRoaXMuc2h1ZmZsZUFycmF5KGRhdGEpO1xuICAgICAgICBjb25zdCBzaXplID0gZGF0YS5sZW5ndGggLyBrO1xuICAgICAgICBjb25zdCBhdmdzID0ge1xuICAgICAgICAgICAgdHJhaW5UaW1lOiAwLFxuICAgICAgICAgICAgdGVzdFRpbWU6IDAsXG4gICAgICAgICAgICBpdGVyYXRpb25zOiAwLFxuICAgICAgICAgICAgZXJyb3I6IDAsXG4gICAgICAgIH07XG4gICAgICAgIGNvbnN0IHN0YXRzID0ge1xuICAgICAgICAgICAgdG90YWw6IDAsXG4gICAgICAgICAgICB0ZXN0U2l6ZTogMCxcbiAgICAgICAgICAgIHRyYWluU2l6ZTogMCxcbiAgICAgICAgfTtcbiAgICAgICAgY29uc3QgYmluYXJ5U3RhdHMgPSB7XG4gICAgICAgICAgICB0b3RhbDogMCxcbiAgICAgICAgICAgIHRlc3RTaXplOiAwLFxuICAgICAgICAgICAgdHJhaW5TaXplOiAwLFxuICAgICAgICAgICAgdHJ1ZVBvczogMCxcbiAgICAgICAgICAgIHRydWVOZWc6IDAsXG4gICAgICAgICAgICBmYWxzZVBvczogMCxcbiAgICAgICAgICAgIGZhbHNlTmVnOiAwLFxuICAgICAgICAgICAgcHJlY2lzaW9uOiAwLFxuICAgICAgICAgICAgcmVjYWxsOiAwLFxuICAgICAgICAgICAgYWNjdXJhY3k6IDAsXG4gICAgICAgIH07XG4gICAgICAgIGNvbnN0IHJlc3VsdHMgPSBbXTtcbiAgICAgICAgbGV0IGlzQmluYXJ5ID0gbnVsbDtcbiAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBrOyBpKyspIHtcbiAgICAgICAgICAgIGNvbnN0IGRjbG9uZSA9IGRhdGEuc2xpY2UoMCk7XG4gICAgICAgICAgICBjb25zdCB0ZXN0U2V0ID0gZGNsb25lLnNwbGljZShpICogc2l6ZSwgc2l6ZSk7XG4gICAgICAgICAgICBjb25zdCB0cmFpblNldCA9IGRjbG9uZTtcbiAgICAgICAgICAgIGNvbnN0IHJlc3VsdCA9IHRoaXMudGVzdFBhcnRpdGlvbih0cmFpbk9wdHMsIHRyYWluU2V0LCB0ZXN0U2V0KTtcbiAgICAgICAgICAgIGlmIChpc0JpbmFyeSA9PT0gbnVsbCkge1xuICAgICAgICAgICAgICAgIGlzQmluYXJ5ID1cbiAgICAgICAgICAgICAgICAgICAgcmVzdWx0Lmhhc093blByb3BlcnR5KCdmYWxzZU5lZycpICYmXG4gICAgICAgICAgICAgICAgICAgICAgICByZXN1bHQuaGFzT3duUHJvcGVydHkoJ2ZhbHNlUG9zJykgJiZcbiAgICAgICAgICAgICAgICAgICAgICAgIHJlc3VsdC5oYXNPd25Qcm9wZXJ0eSgndHJ1ZU5lZycpICYmXG4gICAgICAgICAgICAgICAgICAgICAgICByZXN1bHQuaGFzT3duUHJvcGVydHkoJ3RydWVQb3MnKTtcbiAgICAgICAgICAgICAgICBpZiAoaXNCaW5hcnkpIHtcbiAgICAgICAgICAgICAgICAgICAgT2JqZWN0LmFzc2lnbihzdGF0cywgYmluYXJ5U3RhdHMpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGF2Z3MuaXRlcmF0aW9ucyArPSByZXN1bHQuaXRlcmF0aW9ucztcbiAgICAgICAgICAgIGF2Z3MudGVzdFRpbWUgKz0gcmVzdWx0LnRlc3RUaW1lO1xuICAgICAgICAgICAgYXZncy50cmFpblRpbWUgKz0gcmVzdWx0LnRyYWluVGltZTtcbiAgICAgICAgICAgIGF2Z3MuZXJyb3IgKz0gcmVzdWx0LmVycm9yO1xuICAgICAgICAgICAgc3RhdHMudG90YWwgKz0gcmVzdWx0LnRvdGFsO1xuICAgICAgICAgICAgaWYgKENyb3NzVmFsaWRhdGUuaXNCaW5hcnlTdGF0cyhzdGF0cykgJiZcbiAgICAgICAgICAgICAgICBDcm9zc1ZhbGlkYXRlLmlzQmluYXJ5UGFydGl0aW9uUmVzdWx0cyhyZXN1bHQpKSB7XG4gICAgICAgICAgICAgICAgc3RhdHMuYWNjdXJhY3kgKz0gcmVzdWx0LmFjY3VyYWN5O1xuICAgICAgICAgICAgICAgIHN0YXRzLmZhbHNlTmVnICs9IHJlc3VsdC5mYWxzZU5lZztcbiAgICAgICAgICAgICAgICBzdGF0cy5mYWxzZVBvcyArPSByZXN1bHQuZmFsc2VQb3M7XG4gICAgICAgICAgICAgICAgc3RhdHMucHJlY2lzaW9uICs9IHJlc3VsdC5wcmVjaXNpb247XG4gICAgICAgICAgICAgICAgc3RhdHMucmVjYWxsICs9IHJlc3VsdC5yZWNhbGw7XG4gICAgICAgICAgICAgICAgc3RhdHMudHJ1ZU5lZyArPSByZXN1bHQudHJ1ZU5lZztcbiAgICAgICAgICAgICAgICBzdGF0cy50cnVlUG9zICs9IHJlc3VsdC50cnVlUG9zO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgcmVzdWx0cy5wdXNoKHJlc3VsdCk7XG4gICAgICAgIH1cbiAgICAgICAgYXZncy5lcnJvciAvPSBrO1xuICAgICAgICBhdmdzLml0ZXJhdGlvbnMgLz0gaztcbiAgICAgICAgYXZncy50ZXN0VGltZSAvPSBrO1xuICAgICAgICBhdmdzLnRyYWluVGltZSAvPSBrO1xuICAgICAgICBpZiAoQ3Jvc3NWYWxpZGF0ZS5pc0JpbmFyeVN0YXRzKHN0YXRzKSkge1xuICAgICAgICAgICAgc3RhdHMucHJlY2lzaW9uID0gc3RhdHMudHJ1ZVBvcyAvIChzdGF0cy50cnVlUG9zICsgc3RhdHMuZmFsc2VQb3MpO1xuICAgICAgICAgICAgc3RhdHMucmVjYWxsID0gc3RhdHMudHJ1ZVBvcyAvIChzdGF0cy50cnVlUG9zICsgc3RhdHMuZmFsc2VOZWcpO1xuICAgICAgICAgICAgc3RhdHMuYWNjdXJhY3kgPSAoc3RhdHMudHJ1ZU5lZyArIHN0YXRzLnRydWVQb3MpIC8gc3RhdHMudG90YWw7XG4gICAgICAgIH1cbiAgICAgICAgc3RhdHMudGVzdFNpemUgPSBzaXplO1xuICAgICAgICBzdGF0cy50cmFpblNpemUgPSBkYXRhLmxlbmd0aCAtIHNpemU7XG4gICAgICAgIHRoaXMuanNvbiA9IHtcbiAgICAgICAgICAgIGF2Z3M6IGF2Z3MsXG4gICAgICAgICAgICBzdGF0czogc3RhdHMsXG4gICAgICAgICAgICBzZXRzOiByZXN1bHRzLFxuICAgICAgICB9O1xuICAgICAgICByZXR1cm4gdGhpcy5qc29uO1xuICAgIH1cbiAgICB0b05ldXJhbE5ldHdvcmsoKSB7XG4gICAgICAgIHJldHVybiB0aGlzLmZyb21KU09OKHRoaXMuanNvbik7XG4gICAgfVxuICAgIHRvSlNPTigpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuanNvbjtcbiAgICB9XG4gICAgZnJvbUpTT04oY3Jvc3NWYWxpZGF0ZUpzb24pIHtcbiAgICAgICAgY29uc3Qgd2lubmluZ0pTT04gPSBjcm9zc1ZhbGlkYXRlSnNvbi5zZXRzLnJlZHVjZSgocHJldiwgY3VyKSA9PiAocHJldi5lcnJvciA8IGN1ci5lcnJvciA/IHByZXYgOiBjdXIpKTtcbiAgICAgICAgcmV0dXJuIHRoaXMuaW5pdENsYXNzaWZpZXIoKS5mcm9tSlNPTih3aW5uaW5nSlNPTi5uZXR3b3JrKTtcbiAgICB9XG59XG5Dcm9zc1ZhbGlkYXRlLmlzQmluYXJ5U3RhdHMgPSAoc3RhdHMpID0+IHtcbiAgICByZXR1cm4gKHN0YXRzLmFjY3VyYWN5ICE9PSB1bmRlZmluZWQpO1xufTtcbkNyb3NzVmFsaWRhdGUuaXNCaW5hcnlSZXN1bHRzID0gKHN0YXRzKSA9PiBzdGF0cy5zdGF0cy5hY2N1cmFjeSAhPT0gdW5kZWZpbmVkO1xuQ3Jvc3NWYWxpZGF0ZS5pc0JpbmFyeVBhcnRpdGlvblJlc3VsdHMgPSAoc3RhdHMpID0+IHN0YXRzLmFjY3VyYWN5ICE9PVxuICAgIHVuZGVmaW5lZDtcblxubGV0IGdwdUluc3RhbmNlID0gbnVsbDtcbi8qKlxuICogU2V0cyB1cCB0aGUgZ3B1LmpzIGluc3RhbmNlXG4gKi9cbmZ1bmN0aW9uIHNldHVwKHZhbHVlKSB7XG4gICAgZ3B1SW5zdGFuY2UgPSB2YWx1ZTtcbn1cbmZ1bmN0aW9uIG1ha2VLZXJuZWwoZm4sIHNldHRpbmdzKSB7XG4gICAgbGV0IF9ncHVJbnN0YW5jZSA9IGdwdUluc3RhbmNlO1xuICAgIGlmIChfZ3B1SW5zdGFuY2UgPT09IG51bGwpIHtcbiAgICAgICAgX2dwdUluc3RhbmNlID0gbmV3IGdwdV9qcy5HUFUoeyBtb2RlOiAnZ3B1JyB9KTtcbiAgICAgICAgc2V0dXAoX2dwdUluc3RhbmNlKTtcbiAgICB9XG4gICAgcmV0dXJuIF9ncHVJbnN0YW5jZVxuICAgICAgICAuY3JlYXRlS2VybmVsKGZuLCBzZXR0aW5ncylcbiAgICAgICAgLnNldFBpcGVsaW5lKHRydWUpO1xufVxuZnVuY3Rpb24gbWFrZUtlcm5lbE1hcChtYXAsIGZuLCBzZXR0aW5ncykge1xuICAgIGxldCBfZ3B1SW5zdGFuY2UgPSBncHVJbnN0YW5jZTtcbiAgICBpZiAoX2dwdUluc3RhbmNlID09PSBudWxsKSB7XG4gICAgICAgIF9ncHVJbnN0YW5jZSA9IG5ldyBncHVfanMuR1BVKHsgbW9kZTogJ2dwdScgfSk7XG4gICAgICAgIHNldHVwKF9ncHVJbnN0YW5jZSk7XG4gICAgfVxuICAgIHJldHVybiBfZ3B1SW5zdGFuY2VcbiAgICAgICAgLmNyZWF0ZUtlcm5lbE1hcChtYXAsIGZuLCBzZXR0aW5ncylcbiAgICAgICAgLnNldFBpcGVsaW5lKHRydWUpO1xufVxuLyoqXG4gKiBDb21waWxlcyBhIGZ1bmN0aW9uIGludG8gYSBncHUuanMgZGV2IG1vZGUga2VybmVsXG4gKi9cbi8vIGV4cG9ydCBmdW5jdGlvbiBtYWtlRGV2S2VybmVsKFxuLy8gICBmbjogVGhyZWFkRnVuY3Rpb24sXG4vLyAgIHNldHRpbmdzOiBtYWtlS2VybmVsU2V0dGluZ3Ncbi8vICk6IElLZXJuZWxSdW5TaG9ydGN1dCB7XG4vLyAgIGlmICgnbWFwJyBpbiBzZXR0aW5ncykge1xuLy8gICAgIHRocm93IG5ldyBFcnJvcignbWFwIGtlcm5lbHMgYXJlIG5vdCBzdXBwb3J0ZWQgYnkgZGV2IGtlcm5lbHMnKTtcbi8vICAgfVxuLy8gICBjb25zdCBncHUgPSBuZXcgR1BVKHsgbW9kZTogJ2RldicgfSk7XG4vLyAgIHJldHVybiBncHUuY3JlYXRlS2VybmVsKGZuLCBzZXR0aW5ncyk7XG4vLyB9XG5mdW5jdGlvbiBrZXJuZWxJbnB1dCh2YWx1ZSwgc2l6ZSkge1xuICAgIHJldHVybiBuZXcgZ3B1X2pzLklucHV0KHZhbHVlLCBzaXplKTtcbn1cbi8qKlxuICogRGVsZXRlcyBhIGdwdS5qcyB0ZXh0dXJlIGFuZCBmcmVlcyBWUkFNXG4gKi9cbmZ1bmN0aW9uIHJlbGVhc2UocG9zc2libGVUZXh0dXJlKSB7XG4gICAgaWYgKHBvc3NpYmxlVGV4dHVyZSBpbnN0YW5jZW9mIGdwdV9qcy5UZXh0dXJlKSB7XG4gICAgICAgIHBvc3NpYmxlVGV4dHVyZS5kZWxldGUoKTtcbiAgICB9XG59XG4vKipcbiAqIENsZWFucyBpZSBzZXRzIGFsbCBlbGVtZW50cyB0byAwIG9mIGEgVGV4dHVyZSBvciBhIGpzIGFycmF5XG4gKi9cbmZ1bmN0aW9uIGNsZWFyKHZhbHVlKSB7XG4gICAgaWYgKHZhbHVlIGluc3RhbmNlb2YgZ3B1X2pzLlRleHR1cmUpIHtcbiAgICAgICAgdmFsdWUuY2xlYXIoKTtcbiAgICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICAvLyBhcnJheVxuICAgIGlmIChBcnJheS5pc0FycmF5KHZhbHVlKSkge1xuICAgICAgICBpZiAodHlwZW9mIHZhbHVlWzBdID09PSAnbnVtYmVyJykge1xuICAgICAgICAgICAgdmFsdWUuZmlsbCgwKTtcbiAgICAgICAgfVxuICAgICAgICBlbHNlIGlmICh0eXBlb2YgdmFsdWVbMF1bMF0gPT09ICdudW1iZXInKSB7XG4gICAgICAgICAgICBmb3IgKGxldCB4ID0gMDsgeCA8IHZhbHVlLmxlbmd0aDsgeCsrKSB7XG4gICAgICAgICAgICAgICAgdmFsdWVbeF0uZmlsbCgwKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICBlbHNlIGlmICh0eXBlb2YgdmFsdWVbMF1bMF1bMF0gPT09ICdudW1iZXInKSB7XG4gICAgICAgICAgICAvLyBjdWJlXG4gICAgICAgICAgICBmb3IgKGxldCB5ID0gMDsgeSA8IHZhbHVlLmxlbmd0aDsgeSsrKSB7XG4gICAgICAgICAgICAgICAgY29uc3Qgcm93ID0gdmFsdWVbeV07XG4gICAgICAgICAgICAgICAgZm9yIChsZXQgeCA9IDA7IHggPCByb3cubGVuZ3RoOyB4KyspIHtcbiAgICAgICAgICAgICAgICAgICAgcm93W3hdLmZpbGwoMCk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgfVxuICAgIHRocm93IG5ldyBFcnJvcigndW5oYW5kbGVkIHZhbHVlJyk7XG59XG4vKipcbiAqIENsb25lcyBhIHZhbHVlXG4gKi9cbmZ1bmN0aW9uIGNsb25lKHZhbHVlKSB7XG4gICAgaWYgKHZhbHVlIGluc3RhbmNlb2YgZ3B1X2pzLlRleHR1cmUpIHtcbiAgICAgICAgcmV0dXJuIHZhbHVlLmNsb25lKCk7XG4gICAgfVxuICAgIGlmICh2YWx1ZSBpbnN0YW5jZW9mIEZsb2F0MzJBcnJheSkge1xuICAgICAgICByZXR1cm4gdmFsdWUuc2xpY2UoMCk7XG4gICAgfVxuICAgIGlmIChBcnJheS5pc0FycmF5KHZhbHVlKSkge1xuICAgICAgICBpZiAodHlwZW9mIHZhbHVlWzBdID09PSAnbnVtYmVyJykge1xuICAgICAgICAgICAgcmV0dXJuIHZhbHVlLnNsaWNlKDApO1xuICAgICAgICB9XG4gICAgICAgIGVsc2UgaWYgKHR5cGVvZiB2YWx1ZVswXVswXSA9PT0gJ251bWJlcicpIHtcbiAgICAgICAgICAgIGNvbnN0IG1hdHJpeCA9IG5ldyBBcnJheSh2YWx1ZS5sZW5ndGgpO1xuICAgICAgICAgICAgZm9yIChsZXQgeCA9IDA7IHggPCB2YWx1ZS5sZW5ndGg7IHgrKykge1xuICAgICAgICAgICAgICAgIG1hdHJpeFt4XSA9IHZhbHVlW3hdLnNsaWNlKDApO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgcmV0dXJuIG1hdHJpeDtcbiAgICAgICAgfVxuICAgICAgICBlbHNlIGlmICh0eXBlb2YgdmFsdWVbMF1bMF1bMF0gPT09ICdudW1iZXInKSB7XG4gICAgICAgICAgICBjb25zdCBjdWJlID0gbmV3IEFycmF5KHZhbHVlLmxlbmd0aCk7XG4gICAgICAgICAgICBmb3IgKGxldCB5ID0gMDsgeSA8IHZhbHVlLmxlbmd0aDsgeSsrKSB7XG4gICAgICAgICAgICAgICAgY29uc3Qgcm93ID0gdmFsdWVbeV07XG4gICAgICAgICAgICAgICAgY29uc3QgbWF0cml4ID0gbmV3IEFycmF5KHJvdy5sZW5ndGgpO1xuICAgICAgICAgICAgICAgIGZvciAobGV0IHggPSAwOyB4IDwgcm93Lmxlbmd0aDsgeCsrKSB7XG4gICAgICAgICAgICAgICAgICAgIG1hdHJpeFt4XSA9IHJvd1t4XS5zbGljZSgwKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICByZXR1cm4gY3ViZTtcbiAgICAgICAgfVxuICAgIH1cbiAgICB0aHJvdyBuZXcgRXJyb3IoJ3VuaGFuZGxlZCB2YWx1ZScpO1xufVxuXG4vKipcbiAqIDJEIE1lYW4gU3F1YXJlZCBFcnJvclxuICovXG5mdW5jdGlvbiBtc2UyZChlcnJvcnMpIHtcbiAgICBsZXQgc3VtID0gMDtcbiAgICBmb3IgKGxldCB5ID0gMDsgeSA8IHRoaXMuY29uc3RhbnRzLmhlaWdodDsgeSsrKSB7XG4gICAgICAgIGZvciAobGV0IHggPSAwOyB4IDwgdGhpcy5jb25zdGFudHMud2lkdGg7IHgrKykge1xuICAgICAgICAgICAgc3VtICs9IGVycm9yc1t5XVt4XSAqKiAyO1xuICAgICAgICB9XG4gICAgfVxuICAgIHJldHVybiBzdW0gLyB0aGlzLmNvbnN0YW50cy5sZW5ndGg7XG59XG5jbGFzcyBNZWFuU3F1YXJlZEVycm9yIHtcbiAgICBjb25zdHJ1Y3Rvcih7IHdpZHRoLCBoZWlnaHQgfSkge1xuICAgICAgICB0aGlzLmNhbGN1bGF0ZSA9IG1ha2VLZXJuZWwobXNlMmQsIHtcbiAgICAgICAgICAgIG91dHB1dDogWzFdLFxuICAgICAgICAgICAgY29uc3RhbnRzOiB7XG4gICAgICAgICAgICAgICAgd2lkdGgsXG4gICAgICAgICAgICAgICAgaGVpZ2h0LFxuICAgICAgICAgICAgICAgIGxlbmd0aDogd2lkdGggKiBoZWlnaHQsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgaW1tdXRhYmxlOiB0cnVlLFxuICAgICAgICB9KTtcbiAgICAgICAgdGhpcy5hZGRBYnNvbHV0ZSA9IG1ha2VLZXJuZWwoZnVuY3Rpb24gKHByZXZFcnJvciwgcHJldkxheWVyRXJyb3JzKSB7XG4gICAgICAgICAgICByZXR1cm4gcHJldkVycm9yWzBdICsgTWF0aC5hYnMocHJldkxheWVyRXJyb3JzWzBdWzBdKTtcbiAgICAgICAgfSwge1xuICAgICAgICAgICAgb3V0cHV0OiBbMV0sXG4gICAgICAgICAgICBpbW11dGFibGU6IHRydWUsXG4gICAgICAgIH0pO1xuICAgICAgICB0aGlzLmFkZCA9IG1ha2VLZXJuZWwoZnVuY3Rpb24gKHZhbHVlMSwgdmFsdWUyKSB7XG4gICAgICAgICAgICByZXR1cm4gdmFsdWUxWzBdICsgdmFsdWUyWzBdO1xuICAgICAgICB9LCB7XG4gICAgICAgICAgICBvdXRwdXQ6IFsxXSxcbiAgICAgICAgICAgIGltbXV0YWJsZTogdHJ1ZSxcbiAgICAgICAgfSk7XG4gICAgICAgIHRoaXMuZGl2aWRlID0gbWFrZUtlcm5lbChmdW5jdGlvbiAobGVuZ3RoLCBtc2VTdW0pIHtcbiAgICAgICAgICAgIGNvbnN0IHZhbHVlID0gbXNlU3VtWzBdO1xuICAgICAgICAgICAgaWYgKHZhbHVlID4gMCkge1xuICAgICAgICAgICAgICAgIHJldHVybiB2YWx1ZSAvIGxlbmd0aDtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHJldHVybiAwO1xuICAgICAgICB9LCB7XG4gICAgICAgICAgICBvdXRwdXQ6IFsxXSxcbiAgICAgICAgICAgIGltbXV0YWJsZTogdHJ1ZSxcbiAgICAgICAgfSk7XG4gICAgfVxufVxuXG5jb25zdCBiYXNlTGF5ZXJEZWZhdWx0U2V0dGluZ3MgPSB7XG4gICAgd2lkdGg6IDEsXG4gICAgaGVpZ2h0OiAxLFxuICAgIGRlcHRoOiBudWxsLFxuICAgIHdlaWdodHM6IG51bGwsXG4gICAgZGVsdGFzOiBudWxsLFxuICAgIHByYXhpczogbnVsbCxcbiAgICBwcmF4aXNPcHRzOiBudWxsLFxufTtcbmNsYXNzIEJhc2VMYXllciB7XG4gICAgY29uc3RydWN0b3Ioc2V0dGluZ3MpIHtcbiAgICAgICAgdGhpcy5wcmF4aXMgPSBudWxsO1xuICAgICAgICB0aGlzLnByZWRpY3RLZXJuZWwgPSBudWxsO1xuICAgICAgICB0aGlzLmNvbXBhcmVLZXJuZWwgPSBudWxsO1xuICAgICAgICBpZiAoc2V0dGluZ3MpIHtcbiAgICAgICAgICAgIHRoaXMuc2V0dGluZ3MgPSB7IC4uLmJhc2VMYXllckRlZmF1bHRTZXR0aW5ncywgLi4uc2V0dGluZ3MgfTtcbiAgICAgICAgfVxuICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgIHRoaXMuc2V0dGluZ3MgPSB7IC4uLmJhc2VMYXllckRlZmF1bHRTZXR0aW5ncyB9O1xuICAgICAgICB9XG4gICAgICAgIHRoaXMuc2V0dXBQcmF4aXMoKTtcbiAgICB9XG4gICAgZ2V0IHdpZHRoKCkge1xuICAgICAgICB2YXIgX2E7XG4gICAgICAgIHJldHVybiAoX2EgPSB0aGlzLnNldHRpbmdzLndpZHRoKSAhPT0gbnVsbCAmJiBfYSAhPT0gdm9pZCAwID8gX2EgOiAwO1xuICAgIH1cbiAgICBnZXQgaGVpZ2h0KCkge1xuICAgICAgICB2YXIgX2E7XG4gICAgICAgIHJldHVybiAoX2EgPSB0aGlzLnNldHRpbmdzLmhlaWdodCkgIT09IG51bGwgJiYgX2EgIT09IHZvaWQgMCA/IF9hIDogMDtcbiAgICB9XG4gICAgZ2V0IGRlcHRoKCkge1xuICAgICAgICB2YXIgX2E7XG4gICAgICAgIHJldHVybiAoX2EgPSB0aGlzLnNldHRpbmdzLmRlcHRoKSAhPT0gbnVsbCAmJiBfYSAhPT0gdm9pZCAwID8gX2EgOiAwO1xuICAgIH1cbiAgICBnZXQgd2VpZ2h0cygpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuc2V0dGluZ3Mud2VpZ2h0cztcbiAgICB9XG4gICAgc2V0IHdlaWdodHMod2VpZ2h0cykge1xuICAgICAgICB0aGlzLnNldHRpbmdzLndlaWdodHMgPSB3ZWlnaHRzO1xuICAgIH1cbiAgICBnZXQgZGVsdGFzKCkge1xuICAgICAgICByZXR1cm4gdGhpcy5zZXR0aW5ncy5kZWx0YXM7XG4gICAgfVxuICAgIHNldCBkZWx0YXMoZGVsdGFzKSB7XG4gICAgICAgIHRoaXMuc2V0dGluZ3MuZGVsdGFzID0gZGVsdGFzO1xuICAgIH1cbiAgICBnZXQgaWQoKSB7XG4gICAgICAgIHZhciBfYTtcbiAgICAgICAgcmV0dXJuIChfYSA9IHRoaXMuc2V0dGluZ3MuaWQpICE9PSBudWxsICYmIF9hICE9PSB2b2lkIDAgPyBfYSA6ICcnO1xuICAgIH1cbiAgICBzZXQgaWQodGl0bGUpIHtcbiAgICAgICAgdGhpcy5zZXR0aW5ncy5pZCA9IHRpdGxlO1xuICAgIH1cbiAgICBzZXR1cFByYXhpcygpIHtcbiAgICAgICAgY29uc3QgeyBpbml0UHJheGlzLCBwcmF4aXMsIHByYXhpc09wdHMgfSA9IHRoaXMuc2V0dGluZ3M7XG4gICAgICAgIGlmICghdGhpcy5wcmF4aXMpIHtcbiAgICAgICAgICAgIGlmIChpbml0UHJheGlzKSB7XG4gICAgICAgICAgICAgICAgaWYgKHByYXhpc09wdHMpIHtcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5wcmF4aXMgPSBpbml0UHJheGlzKHRoaXMsIHByYXhpc09wdHMpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5wcmF4aXMgPSBpbml0UHJheGlzKHRoaXMpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGVsc2UgaWYgKHByYXhpcykge1xuICAgICAgICAgICAgICAgIHRoaXMucHJheGlzID0gcHJheGlzO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfVxuICAgIC8qXG4gICAgZ2V0IHdlaWdodHMoKSB7XG4gICAgICByZXR1cm4gdGhpcy5fd2VpZ2h0cztcbiAgICB9XG4gIFxuICAgIHNldCB3ZWlnaHRzKHZhbHVlKSB7XG4gICAgICBpZiAodmFsdWUpIHtcbiAgICAgICAgaWYgKHZhbHVlLmRpbWVuc2lvbnMpIHtcbiAgICAgICAgICBpZiAodmFsdWUuZGltZW5zaW9uc1swXSAhPT0gdGhpcy53aWR0aCkge1xuICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKGAke3RoaXMuY29uc3RydWN0b3IubmFtZX0ud2VpZ2h0cyBiZWluZyBzZXQgd2l0aCBpbXByb3BlciB2YWx1ZSB3aWR0aGApO1xuICAgICAgICAgIH1cbiAgICAgICAgICBpZiAodmFsdWUuZGltZW5zaW9uc1sxXSAhPT0gdGhpcy5oZWlnaHQpIHtcbiAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcihgJHt0aGlzLmNvbnN0cnVjdG9yLm5hbWV9LndlaWdodHMgYmVpbmcgc2V0IHdpdGggaW1wcm9wZXIgdmFsdWUgaGVpZ2h0YCk7XG4gICAgICAgICAgfVxuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIGlmICh2YWx1ZVswXS5sZW5ndGggIT09IHRoaXMud2lkdGgpIHtcbiAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcihgJHt0aGlzLmNvbnN0cnVjdG9yLm5hbWV9LndlaWdodHMgYmVpbmcgc2V0IHdpdGggaW1wcm9wZXIgdmFsdWUgd2lkdGhgKTtcbiAgICAgICAgICB9XG4gICAgICAgICAgaWYgKHZhbHVlLmxlbmd0aCAhPT0gdGhpcy5oZWlnaHQpIHtcbiAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcihgJHt0aGlzLmNvbnN0cnVjdG9yLm5hbWV9LndlaWdodHMgYmVpbmcgc2V0IHdpdGggaW1wcm9wZXIgdmFsdWUgaGVpZ2h0YCk7XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICB9XG4gICAgICB0aGlzLl93ZWlnaHRzID0gdmFsdWU7XG4gICAgfVxuICBcbiAgICBnZXQgZGVsdGFzKCkge1xuICAgICAgcmV0dXJuIHRoaXMuX2RlbHRhcztcbiAgICB9XG4gIFxuICAgIHNldCBkZWx0YXModmFsdWUpIHtcbiAgICAgIGlmICh2YWx1ZSkge1xuICAgICAgICBpZiAodmFsdWUuZGltZW5zaW9ucykge1xuICAgICAgICAgIGlmICh2YWx1ZS5kaW1lbnNpb25zWzBdICE9PSB0aGlzLndpZHRoKSB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoYCR7dGhpcy5jb25zdHJ1Y3Rvci5uYW1lfS5kZWx0YXMgYmVpbmcgc2V0IHdpdGggaW1wcm9wZXIgdmFsdWUgd2lkdGhgKTtcbiAgICAgICAgICB9XG4gICAgICAgICAgaWYgKHZhbHVlLmRpbWVuc2lvbnNbMV0gIT09IHRoaXMuaGVpZ2h0KSB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoYCR7dGhpcy5jb25zdHJ1Y3Rvci5uYW1lfS5kZWx0YXMgYmVpbmcgc2V0IHdpdGggaW1wcm9wZXIgdmFsdWUgaGVpZ2h0YCk7XG4gICAgICAgICAgfVxuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIGlmICh2YWx1ZVswXS5sZW5ndGggIT09IHRoaXMud2lkdGgpIHtcbiAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcihgJHt0aGlzLmNvbnN0cnVjdG9yLm5hbWV9LmRlbHRhcyBiZWluZyBzZXQgd2l0aCBpbXByb3BlciB2YWx1ZSB3aWR0aGApO1xuICAgICAgICAgIH1cbiAgICAgICAgICBpZiAodmFsdWUubGVuZ3RoICE9PSB0aGlzLmhlaWdodCkge1xuICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKGAke3RoaXMuY29uc3RydWN0b3IubmFtZX0uZGVsdGFzIGJlaW5nIHNldCB3aXRoIGltcHJvcGVyIHZhbHVlIGhlaWdodGApO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgfVxuICAgICAgdGhpcy5fZGVsdGFzID0gdmFsdWU7XG4gICAgfSAqL1xuICAgIHZhbGlkYXRlKCkge1xuICAgICAgICBpZiAoTnVtYmVyLmlzTmFOKHRoaXMuaGVpZ2h0KSkge1xuICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKGAke3RoaXMuY29uc3RydWN0b3IubmFtZX0gbGF5ZXIgaGVpZ2h0IGlzIG5vdCBhIG51bWJlcmApO1xuICAgICAgICB9XG4gICAgICAgIGlmIChOdW1iZXIuaXNOYU4odGhpcy53aWR0aCkpIHtcbiAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcihgJHt0aGlzLmNvbnN0cnVjdG9yLm5hbWV9IGxheWVyIHdpZHRoIGlzIG5vdCBhIG51bWJlcmApO1xuICAgICAgICB9XG4gICAgICAgIGlmICh0aGlzLmhlaWdodCA8IDEpIHtcbiAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcihgJHt0aGlzLmNvbnN0cnVjdG9yLm5hbWV9IGxheWVyIGhlaWdodCBpcyBsZXNzIHRoYW4gMWApO1xuICAgICAgICB9XG4gICAgICAgIGlmICh0aGlzLndpZHRoIDwgMSkge1xuICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKGAke3RoaXMuY29uc3RydWN0b3IubmFtZX0gbGF5ZXIgd2lkdGggaXMgbGVzcyB0aGFuIDFgKTtcbiAgICAgICAgfVxuICAgIH1cbiAgICBzZXR1cEtlcm5lbHMoaXNUcmFpbmluZykgeyB9XG4gICAgcmV1c2VLZXJuZWxzKGxheWVyKSB7XG4gICAgICAgIGlmIChsYXllci53aWR0aCAhPT0gdGhpcy53aWR0aCkge1xuICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKGAke3RoaXMuY29uc3RydWN0b3IubmFtZX0ga2VybmVsIHdpZHRoIG1pc21hdGNoICR7bGF5ZXIud2lkdGh9IGlzIG5vdCAke3RoaXMud2lkdGh9YCk7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKGxheWVyLmhlaWdodCAhPT0gdGhpcy5oZWlnaHQpIHtcbiAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcihgJHt0aGlzLmNvbnN0cnVjdG9yLm5hbWV9IGtlcm5lbCB3aWR0aCBtaXNtYXRjaCAke2xheWVyLmhlaWdodH0gaXMgbm90ICR7dGhpcy5oZWlnaHR9YCk7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKGxheWVyLmhhc093blByb3BlcnR5KCdwcmVkaWN0S2VybmVsJykgJiYgbGF5ZXIucHJlZGljdEtlcm5lbCAhPT0gbnVsbCkge1xuICAgICAgICAgICAgaWYgKCFsYXllci5wcmVkaWN0S2VybmVsLmltbXV0YWJsZSkge1xuICAgICAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcihgJHtsYXllci5jb25zdHJ1Y3Rvci5uYW1lfS5wcmVkaWN0S2VybmVsIGlzIG5vdCByZXVzYWJsZSwgc2V0IGtlcm5lbC5pbW11dGFibGUgPSB0cnVlYCk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICB0aGlzLnByZWRpY3RLZXJuZWwgPSBsYXllci5wcmVkaWN0S2VybmVsO1xuICAgICAgICB9XG4gICAgICAgIGlmIChsYXllci5oYXNPd25Qcm9wZXJ0eSgnY29tcGFyZUtlcm5lbCcpICYmIGxheWVyLmNvbXBhcmVLZXJuZWwgIT09IG51bGwpIHtcbiAgICAgICAgICAgIGlmICghbGF5ZXIuY29tcGFyZUtlcm5lbC5pbW11dGFibGUpIHtcbiAgICAgICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoYCR7bGF5ZXIuY29uc3RydWN0b3IubmFtZX0uY29tcGFyZUtlcm5lbCBpcyBub3QgcmV1c2FibGUsIHNldCBrZXJuZWwuaW1tdXRhYmxlID0gdHJ1ZWApO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgdGhpcy5jb21wYXJlS2VybmVsID0gbGF5ZXIuY29tcGFyZUtlcm5lbDtcbiAgICAgICAgfVxuICAgICAgICB0aGlzLnByYXhpcyA9IGxheWVyLnByYXhpcztcbiAgICB9XG4gICAgcHJlZGljdChpbnB1dHMpIHsgfVxuICAgIGNvbXBhcmUodGFyZ2V0VmFsdWVzKSB7IH1cbiAgICBsZWFybihsZWFybmluZ1JhdGUpIHtcbiAgICAgICAgLy8gVE9ETzogZG8gd2UgbmVlZCB0byByZWxlYXNlIGhlcmU/XG4gICAgICAgIGNvbnN0IHsgd2VpZ2h0czogb2xkV2VpZ2h0cyB9ID0gdGhpcztcbiAgICAgICAgaWYgKCF0aGlzLnByYXhpcylcbiAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcigndGhpcy5wcmF4aXMgbm90IGRlZmluZWQnKTtcbiAgICAgICAgdGhpcy53ZWlnaHRzID0gdGhpcy5wcmF4aXMucnVuKHRoaXMsIGxlYXJuaW5nUmF0ZSk7XG4gICAgICAgIHJlbGVhc2Uob2xkV2VpZ2h0cyk7XG4gICAgICAgIGNsZWFyKHRoaXMuZGVsdGFzKTtcbiAgICB9XG4gICAgdG9BcnJheSgpIHtcbiAgICAgICAgcmV0dXJuIEFycmF5LmlzQXJyYXkodGhpcy53ZWlnaHRzKVxuICAgICAgICAgICAgPyB0aGlzLndlaWdodHNcbiAgICAgICAgICAgIDogdGhpcy53ZWlnaHRzLnRvQXJyYXkoKTtcbiAgICB9XG4gICAgdG9KU09OKCkge1xuICAgICAgICByZXR1cm4gQmFzZUxheWVyLnRvSlNPTih0aGlzKTtcbiAgICB9XG4gICAgc3RhdGljIHRvSlNPTihsYXllcikge1xuICAgICAgICBjb25zdCB7IHdlaWdodHMgfSA9IGxheWVyO1xuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgd2lkdGg6IGxheWVyLndpZHRoLFxuICAgICAgICAgICAgaGVpZ2h0OiBsYXllci5oZWlnaHQsXG4gICAgICAgICAgICBkZXB0aDogbGF5ZXIuZGVwdGgsXG4gICAgICAgICAgICB3ZWlnaHRzOiB0b1VudHlwZWRBcnJheSgod2VpZ2h0cyAmJiB3ZWlnaHRzIGluc3RhbmNlb2YgZ3B1X2pzLlRleHR1cmVcbiAgICAgICAgICAgICAgICA/IHdlaWdodHMudG9BcnJheSgpXG4gICAgICAgICAgICAgICAgOiB3ZWlnaHRzKSksXG4gICAgICAgICAgICB0eXBlOiBsYXllci5jb25zdHJ1Y3Rvci5uYW1lLFxuICAgICAgICAgICAgcHJheGlzT3B0czogbGF5ZXIucHJheGlzID8gbGF5ZXIucHJheGlzLnRvSlNPTigpIDogbnVsbCxcbiAgICAgICAgfTtcbiAgICB9XG59XG5mdW5jdGlvbiB0b1VudHlwZWRBcnJheSh3ZWlnaHRzKSB7XG4gICAgaWYgKHdlaWdodHMgPT09IG51bGwpXG4gICAgICAgIHJldHVybiBudWxsO1xuICAgIGlmIChBcnJheS5pc0FycmF5KHdlaWdodHMpKSB7XG4gICAgICAgIGlmICh0eXBlb2Ygd2VpZ2h0c1swXSA9PT0gJ251bWJlcicpIHtcbiAgICAgICAgICAgIHJldHVybiB3ZWlnaHRzO1xuICAgICAgICB9XG4gICAgICAgIGVsc2UgaWYgKEFycmF5LmlzQXJyYXkod2VpZ2h0c1swXSkgJiYgdHlwZW9mIHdlaWdodHNbMF1bMF0gPT09ICdudW1iZXInKSB7XG4gICAgICAgICAgICByZXR1cm4gd2VpZ2h0cztcbiAgICAgICAgfVxuICAgICAgICBlbHNlIGlmIChBcnJheS5pc0FycmF5KHdlaWdodHNbMF1bMF0pICYmXG4gICAgICAgICAgICB0eXBlb2Ygd2VpZ2h0c1swXVswXVswXSA9PT0gJ251bWJlcicpIHtcbiAgICAgICAgICAgIHJldHVybiB3ZWlnaHRzO1xuICAgICAgICB9XG4gICAgICAgIGVsc2UgaWYgKHdlaWdodHNbMF0gaW5zdGFuY2VvZiBGbG9hdDMyQXJyYXkpIHtcbiAgICAgICAgICAgIGNvbnN0IG1hdHJpeCA9IHdlaWdodHM7XG4gICAgICAgICAgICByZXR1cm4gbWF0cml4Lm1hcCgocm93KSA9PiB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIEFycmF5LmZyb20ocm93KTtcbiAgICAgICAgICAgIH0pO1xuICAgICAgICB9XG4gICAgICAgIGVsc2UgaWYgKHdlaWdodHNbMF1bMF0gaW5zdGFuY2VvZiBGbG9hdDMyQXJyYXkpIHtcbiAgICAgICAgICAgIGNvbnN0IGN1YmUgPSB3ZWlnaHRzO1xuICAgICAgICAgICAgcmV0dXJuIGN1YmUubWFwKChtYXRyaXgpID0+IHtcbiAgICAgICAgICAgICAgICByZXR1cm4gbWF0cml4Lm1hcCgocm93KSA9PiB7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBBcnJheS5mcm9tKHJvdyk7XG4gICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICB9KTtcbiAgICAgICAgfVxuICAgIH1cbiAgICBlbHNlIGlmICh3ZWlnaHRzKSB7XG4gICAgICAgIHJldHVybiBBcnJheS5mcm9tKHdlaWdodHMpO1xuICAgIH1cbiAgICB0aHJvdyBuZXcgRXJyb3IoJ3VuZXhwZWN0ZWQgdmFsdWUnKTtcbn1cblxuLyoqXG4gKiBSZXR1cm5zIGFuIGFycmF5IG9mIHplcm9zXG4gKi9cbmZ1bmN0aW9uIHplcm9zJDEoc2l6ZSkge1xuICAgIHJldHVybiBuZXcgRmxvYXQzMkFycmF5KHNpemUpO1xufVxuXG4vKipcbiAqIFJldHVybnMgYSAyRCB0ZW5zb3IobWF0cml4KSBvZiB6ZXJvc1xuICovXG5mdW5jdGlvbiB6ZXJvczJEKHdpZHRoLCBoZWlnaHQpIHtcbiAgICBjb25zdCByZXN1bHQgPSBuZXcgQXJyYXkoaGVpZ2h0KTtcbiAgICBmb3IgKGxldCB5ID0gMDsgeSA8IGhlaWdodDsgeSsrKSB7XG4gICAgICAgIHJlc3VsdFt5XSA9IHplcm9zJDEod2lkdGgpO1xuICAgIH1cbiAgICByZXR1cm4gcmVzdWx0O1xufVxuXG4vKipcbiAqIFJldHVybnMgYSAzRCB0ZW5zb3Igb2YgYXJyYXlzXG4gKi9cbmZ1bmN0aW9uIHplcm9zM0Qod2lkdGgsIGhlaWdodCwgZGVwdGgpIHtcbiAgICBjb25zdCByZXN1bHQgPSBuZXcgQXJyYXkoZGVwdGgpO1xuICAgIGZvciAobGV0IHogPSAwOyB6IDwgZGVwdGg7IHorKykge1xuICAgICAgICByZXN1bHRbel0gPSB6ZXJvczJEKHdpZHRoLCBoZWlnaHQpO1xuICAgIH1cbiAgICByZXR1cm4gcmVzdWx0O1xufVxuXG5jbGFzcyBBY3RpdmF0aW9uIGV4dGVuZHMgQmFzZUxheWVyIHtcbiAgICBjb25zdHJ1Y3RvcihpbnB1dExheWVyLCBzZXR0aW5ncykge1xuICAgICAgICBzdXBlcihzZXR0aW5ncyk7XG4gICAgICAgIHRoaXMuaW5wdXRMYXllciA9IGlucHV0TGF5ZXI7XG4gICAgICAgIGNvbnN0IHsgd2lkdGgsIGhlaWdodCwgZGVwdGggfSA9IHRoaXM7XG4gICAgICAgIHRoaXMucHJlZGljdEtlcm5lbCA9IG51bGw7XG4gICAgICAgIHRoaXMuY29tcGFyZUtlcm5lbCA9IG51bGw7XG4gICAgICAgIHRoaXMudmFsaWRhdGUoKTtcbiAgICAgICAgaWYgKGRlcHRoID4gMCkge1xuICAgICAgICAgICAgdGhpcy53ZWlnaHRzID0gemVyb3MzRCh3aWR0aCwgaGVpZ2h0LCBkZXB0aCk7XG4gICAgICAgICAgICB0aGlzLmRlbHRhcyA9IHplcm9zM0Qod2lkdGgsIGhlaWdodCwgZGVwdGgpO1xuICAgICAgICB9XG4gICAgICAgIGVsc2UgaWYgKGhlaWdodCA+IDApIHtcbiAgICAgICAgICAgIHRoaXMud2VpZ2h0cyA9IHplcm9zMkQod2lkdGgsIGhlaWdodCk7XG4gICAgICAgICAgICB0aGlzLmRlbHRhcyA9IHplcm9zMkQod2lkdGgsIGhlaWdodCk7XG4gICAgICAgIH1cbiAgICAgICAgdGhpcy5zZXR1cFByYXhpcygpO1xuICAgIH1cbiAgICBnZXQgd2lkdGgoKSB7XG4gICAgICAgIHJldHVybiB0aGlzLmlucHV0TGF5ZXIud2lkdGg7XG4gICAgfVxuICAgIGdldCBoZWlnaHQoKSB7XG4gICAgICAgIHJldHVybiB0aGlzLmlucHV0TGF5ZXIuaGVpZ2h0O1xuICAgIH1cbiAgICBnZXQgZGVwdGgoKSB7XG4gICAgICAgIHJldHVybiB0aGlzLmlucHV0TGF5ZXIuZGVwdGg7XG4gICAgfVxufVxuXG5jbGFzcyBGaWx0ZXIgZXh0ZW5kcyBCYXNlTGF5ZXIge1xuICAgIGNvbnN0cnVjdG9yKHNldHRpbmdzLCBpbnB1dExheWVyKSB7XG4gICAgICAgIHN1cGVyKCk7XG4gICAgICAgIHRoaXMuc2V0dGluZ3MgPSBzZXR0aW5ncztcbiAgICAgICAgdGhpcy5pbnB1dExheWVyID0gaW5wdXRMYXllcjtcbiAgICB9XG4gICAgZ2V0IHdpZHRoKCkge1xuICAgICAgICByZXR1cm4gdGhpcy5pbnB1dExheWVyLndpZHRoO1xuICAgIH1cbiAgICBnZXQgaGVpZ2h0KCkge1xuICAgICAgICByZXR1cm4gdGhpcy5pbnB1dExheWVyLmhlaWdodDtcbiAgICB9XG4gICAgZ2V0IGRlcHRoKCkge1xuICAgICAgICByZXR1cm4gdGhpcy5pbnB1dExheWVyLmRlcHRoO1xuICAgIH1cbiAgICBnZXQgZmlsdGVyQ291bnQoKSB7XG4gICAgICAgIHJldHVybiB0aGlzLnNldHRpbmdzLmZpbHRlckNvdW50O1xuICAgIH1cbiAgICBnZXQgZmlsdGVyV2lkdGgoKSB7XG4gICAgICAgIHJldHVybiB0aGlzLnNldHRpbmdzLmZpbHRlcldpZHRoO1xuICAgIH1cbiAgICBnZXQgZmlsdGVySGVpZ2h0KCkge1xuICAgICAgICByZXR1cm4gdGhpcy5zZXR0aW5ncy5maWx0ZXJIZWlnaHQ7XG4gICAgfVxuICAgIGdldCBmaWx0ZXJzKCkge1xuICAgICAgICByZXR1cm4gdGhpcy5zZXR0aW5ncy5maWx0ZXJzO1xuICAgIH1cbiAgICBzZXQgZmlsdGVycyhmaWx0ZXJzKSB7XG4gICAgICAgIHRoaXMuc2V0dGluZ3MuZmlsdGVycyA9IGZpbHRlcnM7XG4gICAgfVxuICAgIGdldCBmaWx0ZXJEZWx0YXMoKSB7XG4gICAgICAgIHJldHVybiB0aGlzLnNldHRpbmdzLmZpbHRlckRlbHRhcztcbiAgICB9XG4gICAgc2V0IGZpbHRlckRlbHRhcyhmaWx0ZXJEZWx0YXMpIHtcbiAgICAgICAgdGhpcy5zZXR0aW5ncy5maWx0ZXJEZWx0YXMgPSBmaWx0ZXJEZWx0YXM7XG4gICAgfVxufVxuXG5jbGFzcyBJbnRlcm5hbCB7XG4gICAgY29uc3RydWN0b3IoKSB7XG4gICAgICAgIHRoaXMucHJlZGljdEtlcm5lbCA9IG51bGw7XG4gICAgICAgIHRoaXMuY29tcGFyZUtlcm5lbCA9IG51bGw7XG4gICAgICAgIHRoaXMucHJheGlzID0gbnVsbDtcbiAgICB9XG4gICAgZ2V0IHdpZHRoKCkge1xuICAgICAgICByZXR1cm4gdGhpcy5zZXR0aW5ncy53aWR0aDtcbiAgICB9XG4gICAgZ2V0IGhlaWdodCgpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuc2V0dGluZ3MuaGVpZ2h0O1xuICAgIH1cbiAgICBnZXQgZGVwdGgoKSB7XG4gICAgICAgIHJldHVybiB0aGlzLnNldHRpbmdzLmRlcHRoO1xuICAgIH1cbiAgICBnZXQgd2VpZ2h0cygpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuc2V0dGluZ3Mud2VpZ2h0cztcbiAgICB9XG4gICAgc2V0IHdlaWdodHMod2VpZ2h0cykge1xuICAgICAgICB0aGlzLnNldHRpbmdzLndlaWdodHMgPSB3ZWlnaHRzO1xuICAgIH1cbiAgICBnZXQgZGVsdGFzKCkge1xuICAgICAgICByZXR1cm4gdGhpcy5zZXR0aW5ncy5kZWx0YXM7XG4gICAgfVxuICAgIHNldCBkZWx0YXMoZGVsdGFzKSB7XG4gICAgICAgIHRoaXMuc2V0dGluZ3MuZGVsdGFzID0gZGVsdGFzO1xuICAgIH1cbiAgICB0b0pTT04oKSB7XG4gICAgICAgIHJldHVybiBCYXNlTGF5ZXIudG9KU09OKHRoaXMpO1xuICAgIH1cbn1cblxuY2xhc3MgTW9kaWZpZXIgZXh0ZW5kcyBCYXNlTGF5ZXIge1xuICAgIGNvbnN0cnVjdG9yKGlucHV0TGF5ZXIsIHNldHRpbmdzKSB7XG4gICAgICAgIHN1cGVyKHtcbiAgICAgICAgICAgIC4uLnNldHRpbmdzLFxuICAgICAgICAgICAgd2lkdGg6IGlucHV0TGF5ZXIud2lkdGgsXG4gICAgICAgICAgICBoZWlnaHQ6IGlucHV0TGF5ZXIuaGVpZ2h0LFxuICAgICAgICAgICAgZGVwdGg6IGlucHV0TGF5ZXIuZGVwdGgsXG4gICAgICAgIH0pO1xuICAgICAgICB0aGlzLmlucHV0TGF5ZXIgPSBpbnB1dExheWVyO1xuICAgIH1cbiAgICB2YWxpZGF0ZSgpIHtcbiAgICAgICAgdmFyIF9hO1xuICAgICAgICBzdXBlci52YWxpZGF0ZSgpO1xuICAgICAgICBpZiAodGhpcy53aWR0aCAhPT0gdGhpcy5pbnB1dExheWVyLndpZHRoKSB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoYHdpZHRoIG9mICR7dGhpcy53aWR0aH0gZG9lcyBub3QgbWF0Y2ggaW5wdXRMYXllci53aWR0aCBvZiAke3RoaXMuaW5wdXRMYXllci53aWR0aH1gKTtcbiAgICAgICAgfVxuICAgICAgICBpZiAodGhpcy5oZWlnaHQgIT09IHRoaXMuaW5wdXRMYXllci5oZWlnaHQpIHtcbiAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcihgaGVpZ2h0IG9mICR7dGhpcy5oZWlnaHR9IGRvZXMgbm90IG1hdGNoIGlucHV0TGF5ZXIuaGVpZ2h0IG9mICR7dGhpcy5pbnB1dExheWVyLmhlaWdodH1gKTtcbiAgICAgICAgfVxuICAgICAgICBpZiAodGhpcy5kZXB0aCAhPT0gKChfYSA9IHRoaXMuaW5wdXRMYXllci5kZXB0aCkgIT09IG51bGwgJiYgX2EgIT09IHZvaWQgMCA/IF9hIDogMCkpIHtcbiAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcihgZGVwdGggb2YgJHt0aGlzLmRlcHRofSBkb2VzIG5vdCBtYXRjaCBpbnB1dExheWVyLmRlcHRoIG9mICR7dGhpcy5pbnB1dExheWVyLmRlcHRofWApO1xuICAgICAgICB9XG4gICAgfVxufVxuXG5jbGFzcyBPcGVyYXRvciBleHRlbmRzIEJhc2VMYXllciB7XG4gICAgY29uc3RydWN0b3IoaW5wdXRMYXllcjEsIGlucHV0TGF5ZXIyLCBzZXR0aW5ncykge1xuICAgICAgICBzdXBlcihzZXR0aW5ncyk7XG4gICAgICAgIHRoaXMuaW5wdXRMYXllcjEgPSBpbnB1dExheWVyMTtcbiAgICAgICAgdGhpcy5pbnB1dExheWVyMiA9IGlucHV0TGF5ZXIyO1xuICAgICAgICB0aGlzLnZhbGlkYXRlKCk7XG4gICAgICAgIHRoaXMud2VpZ2h0cyA9IHplcm9zMkQodGhpcy53aWR0aCwgdGhpcy5oZWlnaHQpO1xuICAgICAgICB0aGlzLmRlbHRhcyA9IHplcm9zMkQodGhpcy53aWR0aCwgdGhpcy5oZWlnaHQpO1xuICAgICAgICB0aGlzLnNldHVwUHJheGlzKCk7XG4gICAgfVxufVxuXG5mdW5jdGlvbiBjb21wYXJlMUQod2VpZ2h0cywgdGFyZ2V0VmFsdWVzKSB7XG4gICAgcmV0dXJuIHdlaWdodHNbdGhpcy50aHJlYWQueV1bdGhpcy50aHJlYWQueF0gLSB0YXJnZXRWYWx1ZXNbdGhpcy50aHJlYWQueF07XG59XG5mdW5jdGlvbiBjb21wYXJlMkQkNSh3ZWlnaHRzLCB0YXJnZXRWYWx1ZXMpIHtcbiAgICByZXR1cm4gKHdlaWdodHNbdGhpcy50aHJlYWQueV1bdGhpcy50aHJlYWQueF0gLVxuICAgICAgICB0YXJnZXRWYWx1ZXNbdGhpcy50aHJlYWQueV1bdGhpcy50aHJlYWQueF0pO1xufVxuY2xhc3MgVGFyZ2V0IGV4dGVuZHMgQmFzZUxheWVyIHtcbiAgICBjb25zdHJ1Y3RvcihzZXR0aW5ncywgaW5wdXRMYXllcikge1xuICAgICAgICBzdXBlcihzZXR0aW5ncyk7XG4gICAgICAgIHRoaXMuaW5wdXRMYXllciA9IGlucHV0TGF5ZXI7XG4gICAgICAgIHRoaXMudmFsaWRhdGUoKTtcbiAgICAgICAgaWYgKHRoaXMuZGVwdGgpIHtcbiAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcignVGFyZ2V0IGxheWVyIG5vdCBpbXBsZW1lbnRlZCBmb3IgZGVwdGgnKTtcbiAgICAgICAgfVxuICAgICAgICBlbHNlIGlmICh0aGlzLmhlaWdodCkge1xuICAgICAgICAgICAgdGhpcy53ZWlnaHRzID0gemVyb3MyRCh0aGlzLndpZHRoLCB0aGlzLmhlaWdodCk7XG4gICAgICAgICAgICB0aGlzLmRlbHRhcyA9IHplcm9zMkQodGhpcy53aWR0aCwgdGhpcy5oZWlnaHQpO1xuICAgICAgICAgICAgdGhpcy5lcnJvcnMgPSB6ZXJvczJEKHRoaXMud2lkdGgsIHRoaXMuaGVpZ2h0KTtcbiAgICAgICAgfVxuICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgIHRoaXMud2VpZ2h0cyA9IHplcm9zJDEodGhpcy53aWR0aCk7XG4gICAgICAgICAgICB0aGlzLmRlbHRhcyA9IHplcm9zJDEodGhpcy53aWR0aCk7XG4gICAgICAgICAgICB0aGlzLmVycm9ycyA9IHplcm9zJDEodGhpcy53aWR0aCk7XG4gICAgICAgIH1cbiAgICB9XG4gICAgc2V0dXBLZXJuZWxzKCkge1xuICAgICAgICBpZiAodGhpcy53aWR0aCA9PT0gMSkge1xuICAgICAgICAgICAgdGhpcy5jb21wYXJlS2VybmVsID0gbWFrZUtlcm5lbChjb21wYXJlMUQsIHtcbiAgICAgICAgICAgICAgICBvdXRwdXQ6IFt0aGlzLndpZHRoLCB0aGlzLmhlaWdodF0sXG4gICAgICAgICAgICAgICAgaW1tdXRhYmxlOiB0cnVlLFxuICAgICAgICAgICAgfSk7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICB0aGlzLmNvbXBhcmVLZXJuZWwgPSBtYWtlS2VybmVsKGNvbXBhcmUyRCQ1LCB7XG4gICAgICAgICAgICAgICAgb3V0cHV0OiBbdGhpcy53aWR0aCwgdGhpcy5oZWlnaHRdLFxuICAgICAgICAgICAgICAgIGltbXV0YWJsZTogdHJ1ZSxcbiAgICAgICAgICAgIH0pO1xuICAgICAgICB9XG4gICAgfVxuICAgIHByZWRpY3QoKSB7XG4gICAgICAgIC8vIFRPRE86IHNob3VsZCB3ZSBjbG9uZSBoZXJlP1xuICAgICAgICAvLyBOT1RFOiB0aGlzIGxvb2tzIGxpa2UgaXQgc2hvdWxkbid0IGJlLCBidXQgdGhlIHdlaWdodHMgYXJlIGltbXV0YWJsZSwgYW5kIHRoaXMgaXMgd2hlcmUgdGhleSBhcmUgcmV1c2VkLlxuICAgICAgICByZWxlYXNlKHRoaXMud2VpZ2h0cyk7XG4gICAgICAgIHRoaXMud2VpZ2h0cyA9IGNsb25lKHRoaXMuaW5wdXRMYXllci53ZWlnaHRzKTtcbiAgICAgICAgY2xlYXIodGhpcy5kZWx0YXMpO1xuICAgIH1cbiAgICBjb21wYXJlKHRhcmdldFZhbHVlcykge1xuICAgICAgICAvLyB0aGlzIGlzIHdoZXJlIHdlaWdodHMgYXR0YWNoIHRvIGRlbHRhc1xuICAgICAgICAvLyBkZWx0YXMgd2lsbCBiZSB6ZXJvIG9uIGxlYXJuLCBzbyBzYXZlIGl0IGluIGVycm9yIGZvciBjb21wYXJpbmcgdG8gbXNlIGxhdGVyXG4gICAgICAgIHJlbGVhc2UodGhpcy5kZWx0YXMpO1xuICAgICAgICByZWxlYXNlKHRoaXMuZXJyb3JzKTtcbiAgICAgICAgcmVsZWFzZSh0aGlzLmlucHV0TGF5ZXIuZGVsdGFzKTtcbiAgICAgICAgdGhpcy5kZWx0YXMgPSB0aGlzLmNvbXBhcmVLZXJuZWwodGhpcy53ZWlnaHRzLCB0YXJnZXRWYWx1ZXMpO1xuICAgICAgICB0aGlzLmlucHV0TGF5ZXIuZGVsdGFzID0gY2xvbmUodGhpcy5kZWx0YXMpO1xuICAgICAgICB0aGlzLmVycm9ycyA9IGNsb25lKHRoaXMuZGVsdGFzKTtcbiAgICB9XG4gICAgc2V0dXBQcmF4aXMoKSB7IH1cbn1cbmZ1bmN0aW9uIHRhcmdldChzZXR0aW5ncywgaW5wdXRMYXllcikge1xuICAgIHJldHVybiBuZXcgVGFyZ2V0KHNldHRpbmdzLCBpbnB1dExheWVyKTtcbn1cblxuLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIEB0eXBlc2NyaXB0LWVzbGludC9uby1leHRyYW5lb3VzLWNsYXNzXG5jbGFzcyBJbnRlcm5hbE1vZGVsIHtcbn1cbi8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBAdHlwZXNjcmlwdC1lc2xpbnQvbm8tZXh0cmFuZW91cy1jbGFzc1xuY2xhc3MgRW50cnlQb2ludCBleHRlbmRzIEJhc2VMYXllciB7XG59XG4vLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgQHR5cGVzY3JpcHQtZXNsaW50L25vLWV4dHJhbmVvdXMtY2xhc3NcbmNsYXNzIE1vZGVsIGV4dGVuZHMgQmFzZUxheWVyIHtcbn1cblxuLyogRnVuY3Rpb25zIGZvciB0dXJuaW5nIHNwYXJzZSBoYXNoZXMgaW50byBhcnJheXMgYW5kIHZpY2UgdmVyc2EgKi9cbmNvbnN0IGxvb2t1cCA9IHtcbiAgICAvKipcbiAgICAgKiBQZXJmb3JtcyBgW3thOiAxfSwge2I6IDYsIGM6IDd9XSAtPiB7YTogMCwgYjogMSwgYzogMn1gXG4gICAgICogQHBhcmFtIHtPYmplY3R9IGhhc2hlc1xuICAgICAqIEByZXR1cm5zIHtPYmplY3R9XG4gICAgICovXG4gICAgdG9UYWJsZShoYXNoZXMpIHtcbiAgICAgICAgY29uc3QgaGFzaCA9IGhhc2hlcy5yZWR1Y2UoKG1lbW8sIGhhc2gpID0+IHtcbiAgICAgICAgICAgIHJldHVybiBPYmplY3QuYXNzaWduKG1lbW8sIGhhc2gpO1xuICAgICAgICB9LCB7fSk7XG4gICAgICAgIHJldHVybiBsb29rdXAudG9IYXNoKGhhc2gpO1xuICAgIH0sXG4gICAgLyoqXG4gICAgICogUGVyZm9ybXMgYFt7YTogMX0sIHtiOiA2LCBjOiA3fV0gLT4ge2E6IDAsIGI6IDEsIGM6IDJ9YFxuICAgICAqL1xuICAgIHRvVGFibGUyRChvYmplY3RzMkQpIHtcbiAgICAgICAgY29uc3QgdGFibGUgPSB7fTtcbiAgICAgICAgbGV0IHZhbHVlSW5kZXggPSAwO1xuICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IG9iamVjdHMyRC5sZW5ndGg7IGkrKykge1xuICAgICAgICAgICAgY29uc3Qgb2JqZWN0cyA9IG9iamVjdHMyRFtpXTtcbiAgICAgICAgICAgIGZvciAobGV0IGogPSAwOyBqIDwgb2JqZWN0cy5sZW5ndGg7IGorKykge1xuICAgICAgICAgICAgICAgIGNvbnN0IG9iamVjdCA9IG9iamVjdHNbal07XG4gICAgICAgICAgICAgICAgZm9yIChjb25zdCBwIGluIG9iamVjdCkge1xuICAgICAgICAgICAgICAgICAgICBpZiAob2JqZWN0Lmhhc093blByb3BlcnR5KHApICYmICF0YWJsZS5oYXNPd25Qcm9wZXJ0eShwKSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgdGFibGVbcF0gPSB2YWx1ZUluZGV4Kys7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHRhYmxlO1xuICAgIH0sXG4gICAgdG9JbnB1dFRhYmxlMkQoZGF0YSkge1xuICAgICAgICBjb25zdCB0YWJsZSA9IHt9O1xuICAgICAgICBsZXQgdGFibGVJbmRleCA9IDA7XG4gICAgICAgIGZvciAobGV0IGRhdGFJbmRleCA9IDA7IGRhdGFJbmRleCA8IGRhdGEubGVuZ3RoOyBkYXRhSW5kZXgrKykge1xuICAgICAgICAgICAgY29uc3QgaW5wdXQgPSBkYXRhW2RhdGFJbmRleF0uaW5wdXQ7XG4gICAgICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IGlucHV0Lmxlbmd0aDsgaSsrKSB7XG4gICAgICAgICAgICAgICAgY29uc3Qgb2JqZWN0ID0gaW5wdXRbaV07XG4gICAgICAgICAgICAgICAgZm9yIChjb25zdCBwIGluIG9iamVjdCkge1xuICAgICAgICAgICAgICAgICAgICBpZiAoIW9iamVjdC5oYXNPd25Qcm9wZXJ0eShwKSlcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnRpbnVlO1xuICAgICAgICAgICAgICAgICAgICBpZiAoIXRhYmxlLmhhc093blByb3BlcnR5KHApKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB0YWJsZVtwXSA9IHRhYmxlSW5kZXgrKztcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gdGFibGU7XG4gICAgfSxcbiAgICB0b091dHB1dFRhYmxlMkQoZGF0YSkge1xuICAgICAgICBjb25zdCB0YWJsZSA9IHt9O1xuICAgICAgICBsZXQgdGFibGVJbmRleCA9IDA7XG4gICAgICAgIGZvciAobGV0IGRhdGFJbmRleCA9IDA7IGRhdGFJbmRleCA8IGRhdGEubGVuZ3RoOyBkYXRhSW5kZXgrKykge1xuICAgICAgICAgICAgY29uc3Qgb3V0cHV0ID0gZGF0YVtkYXRhSW5kZXhdLm91dHB1dDtcbiAgICAgICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgb3V0cHV0Lmxlbmd0aDsgaSsrKSB7XG4gICAgICAgICAgICAgICAgY29uc3Qgb2JqZWN0ID0gb3V0cHV0W2ldO1xuICAgICAgICAgICAgICAgIGZvciAoY29uc3QgcCBpbiBvYmplY3QpIHtcbiAgICAgICAgICAgICAgICAgICAgaWYgKCFvYmplY3QuaGFzT3duUHJvcGVydHkocCkpXG4gICAgICAgICAgICAgICAgICAgICAgICBjb250aW51ZTtcbiAgICAgICAgICAgICAgICAgICAgaWYgKCF0YWJsZS5oYXNPd25Qcm9wZXJ0eShwKSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgdGFibGVbcF0gPSB0YWJsZUluZGV4Kys7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHRhYmxlO1xuICAgIH0sXG4gICAgLyoqXG4gICAgICogcGVyZm9ybXMgYHthOiA2LCBiOiA3fSAtPiB7YTogMCwgYjogMX1gXG4gICAgICovXG4gICAgdG9IYXNoKGhhc2gpIHtcbiAgICAgICAgY29uc3QgbG9va3VwID0ge307XG4gICAgICAgIGxldCBpbmRleCA9IDA7XG4gICAgICAgIGNvbnN0IGtleXMgPSBPYmplY3Qua2V5cyhoYXNoKTtcbiAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBrZXlzLmxlbmd0aDsgaSsrKSB7XG4gICAgICAgICAgICBsb29rdXBba2V5c1tpXV0gPSBpbmRleCsrO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBsb29rdXA7XG4gICAgfSxcbiAgICAvKipcbiAgICAgKiBwZXJmb3JtcyBge2E6IDAsIGI6IDF9LCB7YTogNn0gLT4gWzYsIDBdYFxuICAgICAqL1xuICAgIHRvQXJyYXkobG9va3VwLCBvYmplY3QsIGFycmF5TGVuZ3RoKSB7XG4gICAgICAgIGNvbnN0IHJlc3VsdCA9IG5ldyBGbG9hdDMyQXJyYXkoYXJyYXlMZW5ndGgpO1xuICAgICAgICBmb3IgKGNvbnN0IHAgaW4gbG9va3VwKSB7XG4gICAgICAgICAgICBpZiAoIWxvb2t1cC5oYXNPd25Qcm9wZXJ0eShwKSlcbiAgICAgICAgICAgICAgICBjb250aW51ZTtcbiAgICAgICAgICAgIHJlc3VsdFtsb29rdXBbcF1dID0gb2JqZWN0Lmhhc093blByb3BlcnR5KHApID8gb2JqZWN0W3BdIDogMDtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gcmVzdWx0O1xuICAgIH0sXG4gICAgdG9BcnJheVNob3J0KGxvb2t1cCwgb2JqZWN0KSB7XG4gICAgICAgIGNvbnN0IHJlc3VsdCA9IFtdO1xuICAgICAgICBmb3IgKGNvbnN0IHAgaW4gbG9va3VwKSB7XG4gICAgICAgICAgICBpZiAoIWxvb2t1cC5oYXNPd25Qcm9wZXJ0eShwKSlcbiAgICAgICAgICAgICAgICBjb250aW51ZTtcbiAgICAgICAgICAgIGlmICghb2JqZWN0Lmhhc093blByb3BlcnR5KHApKVxuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgcmVzdWx0W2xvb2t1cFtwXV0gPSBvYmplY3RbcF07XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIEZsb2F0MzJBcnJheS5mcm9tKHJlc3VsdCk7XG4gICAgfSxcbiAgICB0b0FycmF5cyhsb29rdXAsIG9iamVjdHMsIGFycmF5TGVuZ3RoKSB7XG4gICAgICAgIGNvbnN0IHJlc3VsdCA9IFtdO1xuICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IG9iamVjdHMubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgICAgIHJlc3VsdC5wdXNoKHRoaXMudG9BcnJheShsb29rdXAsIG9iamVjdHNbaV0sIGFycmF5TGVuZ3RoKSk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHJlc3VsdDtcbiAgICB9LFxuICAgIC8qKlxuICAgICAqIHBlcmZvcm1zIGB7YTogMCwgYjogMX0sIFs2LCA3XSAtPiB7YTogNiwgYjogN31gXG4gICAgICogQHBhcmFtIHtPYmplY3R9IGxvb2t1cFxuICAgICAqIEBwYXJhbSB7QXJyYXl9IGFycmF5XG4gICAgICogQHJldHVybnMge09iamVjdH1cbiAgICAgKi9cbiAgICB0b09iamVjdChsb29rdXAsIGFycmF5KSB7XG4gICAgICAgIGNvbnN0IG9iamVjdCA9IHt9O1xuICAgICAgICBmb3IgKGNvbnN0IHAgaW4gbG9va3VwKSB7XG4gICAgICAgICAgICBpZiAoIWxvb2t1cC5oYXNPd25Qcm9wZXJ0eShwKSlcbiAgICAgICAgICAgICAgICBjb250aW51ZTtcbiAgICAgICAgICAgIG9iamVjdFtwXSA9IGFycmF5W2xvb2t1cFtwXV07XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIG9iamVjdDtcbiAgICB9LFxuICAgIHRvT2JqZWN0UGFydGlhbChsb29rdXAsIGFycmF5LCBvZmZzZXQgPSAwLCBsaW1pdCA9IDApIHtcbiAgICAgICAgY29uc3Qgb2JqZWN0ID0ge307XG4gICAgICAgIGxldCBpID0gMDtcbiAgICAgICAgZm9yIChjb25zdCBwIGluIGxvb2t1cCkge1xuICAgICAgICAgICAgaWYgKCFsb29rdXAuaGFzT3duUHJvcGVydHkocCkpXG4gICAgICAgICAgICAgICAgY29udGludWU7XG4gICAgICAgICAgICBpZiAob2Zmc2V0ID4gMCkge1xuICAgICAgICAgICAgICAgIGlmIChpKysgPCBvZmZzZXQpXG4gICAgICAgICAgICAgICAgICAgIGNvbnRpbnVlO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaWYgKGxpbWl0ID4gMCkge1xuICAgICAgICAgICAgICAgIGlmIChpKysgPj0gbGltaXQpXG4gICAgICAgICAgICAgICAgICAgIGNvbnRpbnVlO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgb2JqZWN0W3BdID0gYXJyYXlbbG9va3VwW3BdIC0gb2Zmc2V0XTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gb2JqZWN0O1xuICAgIH0sXG4gICAgZGF0YVNoYXBlKGRhdGEpIHtcbiAgICAgICAgY29uc3Qgc2hhcGUgPSBbXTtcbiAgICAgICAgbGV0IGxhc3REYXRhO1xuICAgICAgICBpZiAoZGF0YS5oYXNPd25Qcm9wZXJ0eSgnaW5wdXQnKSkge1xuICAgICAgICAgICAgc2hhcGUucHVzaCgnZGF0dW0nKTtcbiAgICAgICAgICAgIGxhc3REYXRhID0gZGF0YS5pbnB1dDtcbiAgICAgICAgfVxuICAgICAgICBlbHNlIGlmIChBcnJheS5pc0FycmF5KGRhdGEpKSB7XG4gICAgICAgICAgICBpZiAoZGF0YVswXSAmJlxuICAgICAgICAgICAgICAgIGRhdGFbMF0uaW5wdXQpIHtcbiAgICAgICAgICAgICAgICBzaGFwZS5wdXNoKCdhcnJheScsICdkYXR1bScpO1xuICAgICAgICAgICAgICAgIGxhc3REYXRhID0gZGF0YVswXS5pbnB1dDtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGVsc2UgaWYgKEFycmF5LmlzQXJyYXkoZGF0YVswXSkpIHtcbiAgICAgICAgICAgICAgICBzaGFwZS5wdXNoKCdhcnJheScpO1xuICAgICAgICAgICAgICAgIGxhc3REYXRhID0gZGF0YVswXTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgIGxhc3REYXRhID0gZGF0YTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgIGxhc3REYXRhID0gZGF0YTtcbiAgICAgICAgfVxuICAgICAgICBsZXQgcDtcbiAgICAgICAgd2hpbGUgKGxhc3REYXRhKSB7XG4gICAgICAgICAgICBwID0gT2JqZWN0LmtleXMobGFzdERhdGEpWzBdO1xuICAgICAgICAgICAgaWYgKEFycmF5LmlzQXJyYXkobGFzdERhdGEpIHx8XG4gICAgICAgICAgICAgICAgdHlwZW9mIGxhc3REYXRhLmJ1ZmZlciA9PT0gJ29iamVjdCcpIHtcbiAgICAgICAgICAgICAgICBzaGFwZS5wdXNoKCdhcnJheScpO1xuICAgICAgICAgICAgICAgIGNvbnN0IHBvc3NpYmxlTnVtYmVyID0gbGFzdERhdGFbcGFyc2VJbnQocCldO1xuICAgICAgICAgICAgICAgIGlmICh0eXBlb2YgcG9zc2libGVOdW1iZXIgPT09ICdudW1iZXInKSB7XG4gICAgICAgICAgICAgICAgICAgIHNoYXBlLnB1c2goJ251bWJlcicpO1xuICAgICAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgIGxhc3REYXRhID0gcG9zc2libGVOdW1iZXI7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZWxzZSBpZiAodHlwZW9mIGxhc3REYXRhID09PSAnb2JqZWN0JyAmJlxuICAgICAgICAgICAgICAgIHR5cGVvZiBsYXN0RGF0YS5idWZmZXIgIT09ICdvYmplY3QnKSB7XG4gICAgICAgICAgICAgICAgc2hhcGUucHVzaCgnb2JqZWN0Jyk7XG4gICAgICAgICAgICAgICAgY29uc3QgcG9zc2libGVOdW1iZXIgPSBsYXN0RGF0YVtwXTtcbiAgICAgICAgICAgICAgICBpZiAodHlwZW9mIHBvc3NpYmxlTnVtYmVyID09PSAnbnVtYmVyJykge1xuICAgICAgICAgICAgICAgICAgICBzaGFwZS5wdXNoKCdudW1iZXInKTtcbiAgICAgICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICBsYXN0RGF0YSA9IHBvc3NpYmxlTnVtYmVyO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcigndW5oYW5kbGVkIHNpZ25hdHVyZScpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIHJldHVybiBzaGFwZTtcbiAgICB9LFxuICAgIGFkZEtleXModmFsdWUsIHRhYmxlKSB7XG4gICAgICAgIGlmIChBcnJheS5pc0FycmF5KHZhbHVlKSlcbiAgICAgICAgICAgIHJldHVybiB0YWJsZTtcbiAgICAgICAgbGV0IGkgPSBPYmplY3Qua2V5cyh0YWJsZSkubGVuZ3RoO1xuICAgICAgICBmb3IgKGNvbnN0IHAgaW4gdmFsdWUpIHtcbiAgICAgICAgICAgIGlmICghdmFsdWUuaGFzT3duUHJvcGVydHkocCkpXG4gICAgICAgICAgICAgICAgY29udGludWU7XG4gICAgICAgICAgICBpZiAodGFibGUuaGFzT3duUHJvcGVydHkocCkpXG4gICAgICAgICAgICAgICAgY29udGludWU7XG4gICAgICAgICAgICB0YWJsZVtwXSA9IGkrKztcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gdGFibGU7XG4gICAgfSxcbn07XG5cbmNsYXNzIEJhc2VQcmF4aXMge1xuICAgIGNvbnN0cnVjdG9yKGxheWVyVGVtcGxhdGUsIHNldHRpbmdzID0ge30pIHtcbiAgICAgICAgdGhpcy5sYXllclRlbXBsYXRlID0gbGF5ZXJUZW1wbGF0ZTtcbiAgICAgICAgdGhpcy5zZXR0aW5ncyA9IHsgLi4uc2V0dGluZ3MgfTtcbiAgICAgICAgdGhpcy5rZXJuZWwgPSBudWxsO1xuICAgIH1cbiAgICBnZXQgd2lkdGgoKSB7XG4gICAgICAgIHJldHVybiB0aGlzLmxheWVyVGVtcGxhdGUud2lkdGg7XG4gICAgfVxuICAgIGdldCBoZWlnaHQoKSB7XG4gICAgICAgIHJldHVybiB0aGlzLmxheWVyVGVtcGxhdGUuaGVpZ2h0O1xuICAgIH1cbiAgICBnZXQgZGVwdGgoKSB7XG4gICAgICAgIHJldHVybiB0aGlzLmxheWVyVGVtcGxhdGUuZGVwdGg7XG4gICAgfVxuICAgIHNldHVwS2VybmVscygpIHsgfVxuICAgIHJldXNlS2VybmVscyhwcmF4aXMpIHtcbiAgICAgICAgaWYgKHByYXhpcy53aWR0aCAhPT0gdGhpcy53aWR0aCkge1xuICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKGAke3RoaXMuY29uc3RydWN0b3IubmFtZX0ga2VybmVsIHdpZHRoIG1pc21hdGNoICR7cHJheGlzLndpZHRofSBpcyBub3QgJHt0aGlzLndpZHRofWApO1xuICAgICAgICB9XG4gICAgICAgIGlmIChwcmF4aXMuaGVpZ2h0ICE9PSB0aGlzLmhlaWdodCkge1xuICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKGAke3RoaXMuY29uc3RydWN0b3IubmFtZX0ga2VybmVsIHdpZHRoIG1pc21hdGNoICR7cHJheGlzLmhlaWdodH0gaXMgbm90ICR7dGhpcy5oZWlnaHR9YCk7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKHByYXhpcy5oYXNPd25Qcm9wZXJ0eSgna2VybmVsJykpIHtcbiAgICAgICAgICAgIHRoaXMua2VybmVsID0gcHJheGlzLmtlcm5lbDtcbiAgICAgICAgfVxuICAgIH1cbiAgICB0b0pTT04oKSB7XG4gICAgICAgIHJldHVybiB7IC4uLnRoaXMuc2V0dGluZ3MgfTtcbiAgICB9XG59XG5cbmZ1bmN0aW9uIHVwZGF0ZSQyKHdlaWdodHMsIGRlbHRhcykge1xuICAgIHJldHVybiAod2VpZ2h0c1t0aGlzLnRocmVhZC55XVt0aGlzLnRocmVhZC54XSArXG4gICAgICAgIHRoaXMuY29uc3RhbnRzLmxlYXJuaW5nUmF0ZSAqIGRlbHRhc1t0aGlzLnRocmVhZC55XVt0aGlzLnRocmVhZC54XSk7XG59XG5jb25zdCBkZWZhdWx0U2V0dGluZ3MkMSA9IHtcbiAgICBsZWFybmluZ1JhdGU6IDAuMyxcbn07XG5jbGFzcyBBcnRodXJEZXZpYXRpb25CaWFzZXMgZXh0ZW5kcyBCYXNlUHJheGlzIHtcbiAgICBjb25zdHJ1Y3RvcihsYXllciwgc2V0dGluZ3MpIHtcbiAgICAgICAgc3VwZXIobGF5ZXIpO1xuICAgICAgICB0aGlzLnNldHRpbmdzID0geyAuLi5kZWZhdWx0U2V0dGluZ3MkMSwgLi4uc2V0dGluZ3MgfTtcbiAgICAgICAgdGhpcy5rZXJuZWwgPSBudWxsO1xuICAgIH1cbiAgICBydW4obGF5ZXIpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMua2VybmVsKGxheWVyLndlaWdodHMsIGxheWVyLmRlbHRhcyk7XG4gICAgfVxuICAgIHNldHVwS2VybmVscygpIHtcbiAgICAgICAgdGhpcy5rZXJuZWwgPSBtYWtlS2VybmVsKHVwZGF0ZSQyLCB7XG4gICAgICAgICAgICBvdXRwdXQ6IFt0aGlzLndpZHRoLCB0aGlzLmhlaWdodF0sXG4gICAgICAgICAgICBjb25zdGFudHM6IHtcbiAgICAgICAgICAgICAgICBsZWFybmluZ1JhdGU6IHRoaXMuc2V0dGluZ3MubGVhcm5pbmdSYXRlLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgfSk7XG4gICAgfVxufVxuZnVuY3Rpb24gYXJ0aHVyRGV2aWF0aW9uQmlhc2VzKGxheWVyLCBzZXR0aW5ncykge1xuICAgIHJldHVybiBuZXcgQXJ0aHVyRGV2aWF0aW9uQmlhc2VzKGxheWVyLCBzZXR0aW5ncyk7XG59XG5cbmZ1bmN0aW9uIHVwZGF0ZUNoYW5nZSh2YWx1ZSkge1xuICAgIHJldHVybiB2YWx1ZTtcbn1cbmZ1bmN0aW9uIHVwZGF0ZSQxKGNoYW5nZXMsIHdlaWdodHMsIGluY29taW5nV2VpZ2h0cywgaW5wdXREZWx0YXMpIHtcbiAgICBjb25zdCBsYXN0Q2hhbmdlID0gY2hhbmdlc1t0aGlzLnRocmVhZC55XVt0aGlzLnRocmVhZC54XTtcbiAgICBjb25zdCBpbnB1dERlbHRhID0gaW5wdXREZWx0YXNbdGhpcy50aHJlYWQueV1bMF07XG4gICAgY29uc3Qgd2VpZ2h0ID0gd2VpZ2h0c1t0aGlzLnRocmVhZC55XVt0aGlzLnRocmVhZC54XTtcbiAgICBjb25zdCBpbmNvbWluZyA9IGluY29taW5nV2VpZ2h0c1t0aGlzLnRocmVhZC54XVswXTtcbiAgICBjb25zdCBjaGFuZ2UgPSB0aGlzLmNvbnN0YW50cy5sZWFybmluZ1JhdGUgKiBpbnB1dERlbHRhICogaW5jb21pbmcgK1xuICAgICAgICB0aGlzLmNvbnN0YW50cy5tb21lbnR1bSAqIGxhc3RDaGFuZ2U7XG4gICAgcmV0dXJuIHdlaWdodCArIGNoYW5nZTtcbn1cbmNvbnN0IGRlZmF1bHRTZXR0aW5ncyA9IHtcbiAgICBsZWFybmluZ1JhdGU6IDAuMyxcbiAgICBtb21lbnR1bTogMC4xLFxuICAgIHdlaWdodHNMYXllcjogbnVsbCxcbiAgICBpbmNvbWluZ0xheWVyOiBudWxsLFxuICAgIGRlbHRhTGF5ZXI6IG51bGwsXG59O1xuY2xhc3MgQXJ0aHVyRGV2aWF0aW9uV2VpZ2h0cyBleHRlbmRzIEJhc2VQcmF4aXMge1xuICAgIGNvbnN0cnVjdG9yKGxheWVyLCBzZXR0aW5ncykge1xuICAgICAgICBzdXBlcihsYXllcik7XG4gICAgICAgIHRoaXMua2VybmVsTWFwID0gbnVsbDtcbiAgICAgICAgdGhpcy5zZXR0aW5ncyA9IHsgLi4uZGVmYXVsdFNldHRpbmdzLCAuLi5zZXR0aW5ncyB9O1xuICAgICAgICB0aGlzLmNoYW5nZXMgPSB6ZXJvczJEKGxheWVyLndpZHRoLCBsYXllci5oZWlnaHQpO1xuICAgIH1cbiAgICBnZXQgbGVhcm5pbmdSYXRlKCkge1xuICAgICAgICByZXR1cm4gdGhpcy5zZXR0aW5ncy5sZWFybmluZ1JhdGU7XG4gICAgfVxuICAgIGdldCBtb21lbnR1bSgpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuc2V0dGluZ3MubW9tZW50dW07XG4gICAgfVxuICAgIGdldCB3ZWlnaHRzTGF5ZXIoKSB7XG4gICAgICAgIHJldHVybiB0aGlzLnNldHRpbmdzLndlaWdodHNMYXllcjtcbiAgICB9XG4gICAgc2V0IHdlaWdodHNMYXllcihsYXllcikge1xuICAgICAgICB0aGlzLnNldHRpbmdzLndlaWdodHNMYXllciA9IGxheWVyO1xuICAgIH1cbiAgICBnZXQgZGVsdGFMYXllcigpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuc2V0dGluZ3MuZGVsdGFMYXllcjtcbiAgICB9XG4gICAgc2V0IGRlbHRhTGF5ZXIobGF5ZXIpIHtcbiAgICAgICAgdGhpcy5zZXR0aW5ncy5kZWx0YUxheWVyID0gbGF5ZXI7XG4gICAgfVxuICAgIGdldCBpbmNvbWluZ0xheWVyKCkge1xuICAgICAgICByZXR1cm4gdGhpcy5zZXR0aW5ncy5pbmNvbWluZ0xheWVyO1xuICAgIH1cbiAgICBzZXQgaW5jb21pbmdMYXllcihsYXllcikge1xuICAgICAgICB0aGlzLnNldHRpbmdzLmluY29taW5nTGF5ZXIgPSBsYXllcjtcbiAgICB9XG4gICAgcnVuKCkge1xuICAgICAgICBjb25zdCBvdXRwdXQgPSB0aGlzLmtlcm5lbE1hcCh0aGlzLmNoYW5nZXMsIHRoaXMud2VpZ2h0c0xheWVyLndlaWdodHMsIHRoaXMuaW5jb21pbmdMYXllci53ZWlnaHRzLCB0aGlzLmRlbHRhTGF5ZXIuZGVsdGFzKTtcbiAgICAgICAgdGhpcy5jaGFuZ2VzID0gb3V0cHV0LmNoYW5nZXM7XG4gICAgICAgIHJldHVybiBvdXRwdXQucmVzdWx0O1xuICAgIH1cbiAgICBzZXR1cEtlcm5lbHMoKSB7XG4gICAgICAgIHRoaXMua2VybmVsTWFwID0gbWFrZUtlcm5lbE1hcCh7XG4gICAgICAgICAgICBjaGFuZ2VzOiB1cGRhdGVDaGFuZ2UsXG4gICAgICAgIH0sIHVwZGF0ZSQxLCB7XG4gICAgICAgICAgICBvdXRwdXQ6IFt0aGlzLndpZHRoLCB0aGlzLmhlaWdodF0sXG4gICAgICAgICAgICBjb25zdGFudHM6IHtcbiAgICAgICAgICAgICAgICBsZWFybmluZ1JhdGU6IHRoaXMubGVhcm5pbmdSYXRlLFxuICAgICAgICAgICAgICAgIG1vbWVudHVtOiB0aGlzLm1vbWVudHVtLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgfSk7XG4gICAgfVxufVxuZnVuY3Rpb24gYXJ0aHVyRGV2aWF0aW9uV2VpZ2h0cyhsYXllciwgc2V0dGluZ3MpIHtcbiAgICByZXR1cm4gbmV3IEFydGh1ckRldmlhdGlvbldlaWdodHMobGF5ZXIsIHNldHRpbmdzKTtcbn1cblxuZnVuY3Rpb24gZ2V0TW9tZW50dW0oZGVsdGEsIGRlY2F5LCBwcmV2aW91c01vbWVudHVtKSB7XG4gICAgcmV0dXJuIHByZXZpb3VzTW9tZW50dW0gKiBkZWNheSArICgxIC0gZGVjYXkpICogZGVsdGEgKiBkZWx0YTtcbn1cbmZ1bmN0aW9uIGNsaXBCeVZhbHVlKHZhbHVlLCBtYXgsIG1pbikge1xuICAgIGlmICh2YWx1ZSA+IG1heCkge1xuICAgICAgICByZXR1cm4gbWF4O1xuICAgIH1cbiAgICBpZiAodmFsdWUgPCBtaW4pIHtcbiAgICAgICAgcmV0dXJuIG1pbjtcbiAgICB9XG4gICAgcmV0dXJuIHZhbHVlO1xufVxuLyoqXG4gKiBAZGVzY3JpcHRpb24gTW9tZW50dW0gUm9vdCBNZWFuIFNxdWFyZSBQcm9wYWdhdGlvbiBGdW5jdGlvblxuICovXG5mdW5jdGlvbiB1cGRhdGUod2VpZ2h0cywgZGVsdGFzLCBwcmV2aW91c01vbWVudGEpIHtcbiAgICBjb25zdCBkZWx0YSA9IGRlbHRhc1t0aGlzLnRocmVhZC55XVt0aGlzLnRocmVhZC54XTtcbiAgICBjb25zdCBjbGlwcGVkRGVsdGEgPSBjbGlwQnlWYWx1ZShkZWx0YSwgdGhpcy5jb25zdGFudHMuY2xpcFZhbHVlLCAtdGhpcy5jb25zdGFudHMuY2xpcFZhbHVlKTtcbiAgICBjb25zdCB3ZWlnaHQgPSB3ZWlnaHRzW3RoaXMudGhyZWFkLnldW3RoaXMudGhyZWFkLnhdO1xuICAgIGNvbnN0IHByZXZpb3VzTW9tZW50dW0gPSBwcmV2aW91c01vbWVudGFbdGhpcy50aHJlYWQueV1bdGhpcy50aHJlYWQueF07XG4gICAgY29uc3QgbW9tZW50dW0gPSBnZXRNb21lbnR1bShkZWx0YSwgdGhpcy5jb25zdGFudHMuZGVjYXlSYXRlLCBwcmV2aW91c01vbWVudHVtKTtcbiAgICByZXR1cm4gKHdlaWdodCArXG4gICAgICAgICgtdGhpcy5jb25zdGFudHMubGVhcm5pbmdSYXRlICogY2xpcHBlZERlbHRhKSAvXG4gICAgICAgICAgICBNYXRoLnNxcnQobW9tZW50dW0gKyB0aGlzLmNvbnN0YW50cy5zbW9vdGhFcHMpIC1cbiAgICAgICAgdGhpcy5jb25zdGFudHMucmVndWxhcml6YXRpb25TdHJlbmd0aCAqIHdlaWdodCk7XG59XG5jb25zdCBkZWZhdWx0cyQ4ID0ge1xuICAgIGRlY2F5UmF0ZTogMC45OTksXG4gICAgcmVndWxhcml6YXRpb25TdHJlbmd0aDogMC4wMDAxLFxuICAgIGxlYXJuaW5nUmF0ZTogMC4wMSxcbiAgICBzbW9vdGhFcHM6IDFlLTgsXG4gICAgY2xpcFZhbHVlOiA1LFxufTtcbmNsYXNzIE1vbWVudHVtUm9vdE1lYW5TcXVhcmVkUHJvcGFnYXRpb24gZXh0ZW5kcyBCYXNlUHJheGlzIHtcbiAgICBjb25zdHJ1Y3RvcihsYXllclRlbXBsYXRlLCBzZXR0aW5ncyA9IHt9KSB7XG4gICAgICAgIHN1cGVyKGxheWVyVGVtcGxhdGUpO1xuICAgICAgICB0aGlzLmtlcm5lbE1hcCA9IG51bGw7XG4gICAgICAgIHRoaXMuc2V0dGluZ3MgPSB7IC4uLmRlZmF1bHRzJDgsIC4uLnNldHRpbmdzIH07XG4gICAgICAgIHRoaXMubW9tZW50YSA9IHplcm9zMkQobGF5ZXJUZW1wbGF0ZS53aWR0aCwgbGF5ZXJUZW1wbGF0ZS5oZWlnaHQpO1xuICAgIH1cbiAgICBnZXQgY2xpcFZhbHVlKCkge1xuICAgICAgICByZXR1cm4gdGhpcy5zZXR0aW5ncy5jbGlwVmFsdWU7XG4gICAgfVxuICAgIGdldCBkZWNheVJhdGUoKSB7XG4gICAgICAgIHJldHVybiB0aGlzLnNldHRpbmdzLmRlY2F5UmF0ZTtcbiAgICB9XG4gICAgZ2V0IGxlYXJuaW5nUmF0ZSgpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuc2V0dGluZ3MubGVhcm5pbmdSYXRlO1xuICAgIH1cbiAgICBnZXQgcmVndWxhcml6YXRpb25TdHJlbmd0aCgpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuc2V0dGluZ3MucmVndWxhcml6YXRpb25TdHJlbmd0aDtcbiAgICB9XG4gICAgZ2V0IHNtb290aEVwcygpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuc2V0dGluZ3Muc21vb3RoRXBzO1xuICAgIH1cbiAgICBydW4obGF5ZXIpIHtcbiAgICAgICAgY29uc3QgeyBtb21lbnRhLCByZXN1bHQgfSA9IHRoaXMua2VybmVsTWFwKGxheWVyLndlaWdodHMsIGxheWVyLmRlbHRhcywgdGhpcy5tb21lbnRhKTtcbiAgICAgICAgcmVsZWFzZSh0aGlzLm1vbWVudGEpO1xuICAgICAgICB0aGlzLm1vbWVudGEgPSBtb21lbnRhO1xuICAgICAgICByZXR1cm4gcmVzdWx0O1xuICAgIH1cbiAgICBzZXR1cEtlcm5lbHMoKSB7XG4gICAgICAgIHRoaXMua2VybmVsTWFwID0gbWFrZUtlcm5lbE1hcCh7XG4gICAgICAgICAgICBtb21lbnRhOiBnZXRNb21lbnR1bSxcbiAgICAgICAgfSwgdXBkYXRlLCB7XG4gICAgICAgICAgICBvdXRwdXQ6IFt0aGlzLndpZHRoLCB0aGlzLmhlaWdodF0sXG4gICAgICAgICAgICBjb25zdGFudHM6IHtcbiAgICAgICAgICAgICAgICBjbGlwVmFsdWU6IHRoaXMuY2xpcFZhbHVlLFxuICAgICAgICAgICAgICAgIGRlY2F5UmF0ZTogdGhpcy5kZWNheVJhdGUsXG4gICAgICAgICAgICAgICAgbGVhcm5pbmdSYXRlOiB0aGlzLmxlYXJuaW5nUmF0ZSxcbiAgICAgICAgICAgICAgICByZWd1bGFyaXphdGlvblN0cmVuZ3RoOiB0aGlzLnJlZ3VsYXJpemF0aW9uU3RyZW5ndGgsXG4gICAgICAgICAgICAgICAgc21vb3RoRXBzOiB0aGlzLnNtb290aEVwcyxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBmdW5jdGlvbnM6IFtjbGlwQnlWYWx1ZV0sXG4gICAgICAgICAgICBpbW11dGFibGU6IHRydWUsXG4gICAgICAgIH0pO1xuICAgIH1cbn1cbmZ1bmN0aW9uIG1vbWVudHVtUm9vdE1lYW5TcXVhcmVkUHJvcGFnYXRpb24obGF5ZXIsIHNldHRpbmdzKSB7XG4gICAgcmV0dXJuIG5ldyBNb21lbnR1bVJvb3RNZWFuU3F1YXJlZFByb3BhZ2F0aW9uKGxheWVyLCBzZXR0aW5ncyk7XG59XG4vKipcbiAqIEBkZXNjcmlwdGlvbiBNYXRoZW1hdGljaWFuIGZyaWVuZGx5IG5hbWUgb2YgTW9tZW50dW1Sb290TWVhblNxdWFyZWRQcm9wYWdhdGlvbiBjbGFzcy4gRm9yIHRob3NlIHRoYXQgYXJlIG5vdCBtZXJlIG1vcnRhbHNcbiAqL1xuY29uc3QgTVJtc1Byb3AgPSBNb21lbnR1bVJvb3RNZWFuU3F1YXJlZFByb3BhZ2F0aW9uO1xuY29uc3QgbVJtc1Byb3AgPSBtb21lbnR1bVJvb3RNZWFuU3F1YXJlZFByb3BhZ2F0aW9uO1xuXG52YXIgaW5kZXggPSAvKiNfX1BVUkVfXyovT2JqZWN0LmZyZWV6ZSh7XG4gICAgX19wcm90b19fOiBudWxsLFxuICAgIEFydGh1ckRldmlhdGlvbkJpYXNlczogQXJ0aHVyRGV2aWF0aW9uQmlhc2VzLFxuICAgIGFydGh1ckRldmlhdGlvbkJpYXNlczogYXJ0aHVyRGV2aWF0aW9uQmlhc2VzLFxuICAgIEFydGh1ckRldmlhdGlvbldlaWdodHM6IEFydGh1ckRldmlhdGlvbldlaWdodHMsXG4gICAgYXJ0aHVyRGV2aWF0aW9uV2VpZ2h0czogYXJ0aHVyRGV2aWF0aW9uV2VpZ2h0cyxcbiAgICBNb21lbnR1bVJvb3RNZWFuU3F1YXJlZFByb3BhZ2F0aW9uOiBNb21lbnR1bVJvb3RNZWFuU3F1YXJlZFByb3BhZ2F0aW9uLFxuICAgIG1vbWVudHVtUm9vdE1lYW5TcXVhcmVkUHJvcGFnYXRpb246IG1vbWVudHVtUm9vdE1lYW5TcXVhcmVkUHJvcGFnYXRpb24sXG4gICAgTVJtc1Byb3A6IE1SbXNQcm9wLFxuICAgIG1SbXNQcm9wOiBtUm1zUHJvcFxufSk7XG5cbmZ1bmN0aW9uIHRyYXZlcnNlTGF5ZXJzRnJvbShsYXllciwgY2IpIHtcbiAgICBpZiAobGF5ZXIuaGFzT3duUHJvcGVydHkoJ2lucHV0TGF5ZXInKSkge1xuICAgICAgICB0cmF2ZXJzZUxheWVyc0Zyb20obGF5ZXIuaW5wdXRMYXllciwgY2IpO1xuICAgIH1cbiAgICBlbHNlIHtcbiAgICAgICAgaWYgKGxheWVyLmhhc093blByb3BlcnR5KCdpbnB1dExheWVyMScpKSB7XG4gICAgICAgICAgICB0cmF2ZXJzZUxheWVyc0Zyb20obGF5ZXIuaW5wdXRMYXllcjEsIGNiKTtcbiAgICAgICAgfVxuICAgICAgICBpZiAobGF5ZXIuaGFzT3duUHJvcGVydHkoJ2lucHV0TGF5ZXIyJykpIHtcbiAgICAgICAgICAgIHRyYXZlcnNlTGF5ZXJzRnJvbShsYXllci5pbnB1dExheWVyMiwgY2IpO1xuICAgICAgICB9XG4gICAgfVxuICAgIGNiKGxheWVyKTtcbn1cblxuZnVuY3Rpb24gZmxhdHRlbkxheWVycyhsYXllcnMpIHtcbiAgICBjb25zdCByZXN1bHQgPSBsYXllcnMuc2xpY2UoMCk7XG4gICAgZm9yIChsZXQgaSA9IDA7IGkgPCByZXN1bHQubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgbGV0IG9mZnNldCA9IDA7XG4gICAgICAgIHRyYXZlcnNlTGF5ZXJzRnJvbShyZXN1bHRbaV0sIChsYXllcikgPT4ge1xuICAgICAgICAgICAgaWYgKCFyZXN1bHQuaW5jbHVkZXMobGF5ZXIpKSB7XG4gICAgICAgICAgICAgICAgcmVzdWx0LnNwbGljZShpICsgb2Zmc2V0LCAwLCBsYXllcik7XG4gICAgICAgICAgICAgICAgb2Zmc2V0Kys7XG4gICAgICAgICAgICB9XG4gICAgICAgIH0pO1xuICAgIH1cbiAgICByZXR1cm4gcmVzdWx0O1xufVxuXG5mdW5jdGlvbiBjaGVja1NhbWVTaXplKGxheWVyMSwgbGF5ZXIyKSB7XG4gICAgaWYgKGxheWVyMS53aWR0aCAhPT0gbGF5ZXIyLndpZHRoKSB7XG4gICAgICAgIHRocm93IG5ldyBFcnJvcihgTGF5ZXIgd2lkdGggbWlzbWF0Y2ggb2YgJHtsYXllcjEud2lkdGh9IGFuZCAke2xheWVyMi53aWR0aH1gKTtcbiAgICB9XG4gICAgaWYgKGxheWVyMS5oZWlnaHQgIT09IGxheWVyMi5oZWlnaHQpIHtcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKGBMYXllciBoZWlnaHQgbWlzbWF0Y2ggb2YgJHtsYXllcjEuaGVpZ2h0fSBhbmQgJHtsYXllcjIuaGVpZ2h0fWApO1xuICAgIH1cbn1cblxuZnVuY3Rpb24gcHJlZGljdCQ4KGlucHV0V2VpZ2h0czEsIGlucHV0V2VpZ2h0czIpIHtcbiAgICByZXR1cm4gKGlucHV0V2VpZ2h0czFbdGhpcy50aHJlYWQueV1bdGhpcy50aHJlYWQueF0gK1xuICAgICAgICBpbnB1dFdlaWdodHMyW3RoaXMudGhyZWFkLnldW3RoaXMudGhyZWFkLnhdKTtcbn1cbmNsYXNzIEFkZCBleHRlbmRzIE9wZXJhdG9yIHtcbiAgICBnZXQgd2lkdGgoKSB7XG4gICAgICAgIHJldHVybiB0aGlzLmlucHV0TGF5ZXIxLndpZHRoO1xuICAgIH1cbiAgICBnZXQgaGVpZ2h0KCkge1xuICAgICAgICByZXR1cm4gdGhpcy5pbnB1dExheWVyMS5oZWlnaHQ7XG4gICAgfVxuICAgIGdldCBkZXB0aCgpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuaW5wdXRMYXllcjEuZGVwdGg7XG4gICAgfVxuICAgIHZhbGlkYXRlKCkge1xuICAgICAgICBzdXBlci52YWxpZGF0ZSgpO1xuICAgICAgICBjaGVja1NhbWVTaXplKHRoaXMuaW5wdXRMYXllcjEsIHRoaXMuaW5wdXRMYXllcjIpO1xuICAgIH1cbiAgICBzZXR1cEtlcm5lbHMoKSB7XG4gICAgICAgIHRoaXMucHJlZGljdEtlcm5lbCA9IG1ha2VLZXJuZWwocHJlZGljdCQ4LCB7XG4gICAgICAgICAgICBvdXRwdXQ6IFt0aGlzLndpZHRoLCB0aGlzLmhlaWdodF0sXG4gICAgICAgICAgICBpbW11dGFibGU6IHRydWUsXG4gICAgICAgIH0pO1xuICAgIH1cbiAgICBwcmVkaWN0KCkge1xuICAgICAgICByZWxlYXNlKHRoaXMud2VpZ2h0cyk7XG4gICAgICAgIHRoaXMud2VpZ2h0cyA9IHRoaXMucHJlZGljdEtlcm5lbCh0aGlzLmlucHV0TGF5ZXIxLndlaWdodHMsIHRoaXMuaW5wdXRMYXllcjIud2VpZ2h0cyk7XG4gICAgICAgIGNsZWFyKHRoaXMuZGVsdGFzKTtcbiAgICB9XG4gICAgY29tcGFyZSgpIHtcbiAgICAgICAgLy8gVE9ETzogRG8gd2UgbmVlZCByZWxlYXNlIGFuZCBjbG9uZSBoZXJlP1xuICAgICAgICByZWxlYXNlKHRoaXMuaW5wdXRMYXllcjEuZGVsdGFzKTtcbiAgICAgICAgcmVsZWFzZSh0aGlzLmlucHV0TGF5ZXIyLmRlbHRhcyk7XG4gICAgICAgIHRoaXMuaW5wdXRMYXllcjEuZGVsdGFzID0gY2xvbmUodGhpcy5kZWx0YXMpO1xuICAgICAgICB0aGlzLmlucHV0TGF5ZXIyLmRlbHRhcyA9IGNsb25lKHRoaXMuZGVsdGFzKTtcbiAgICB9XG4gICAgbGVhcm4oKSB7IH1cbn1cbmZ1bmN0aW9uIGFkZCQxKGlucHV0TGF5ZXIxLCBpbnB1dExheWVyMiwgc2V0dGluZ3MpIHtcbiAgICByZXR1cm4gbmV3IEFkZChpbnB1dExheWVyMSwgaW5wdXRMYXllcjIsIHNldHRpbmdzKTtcbn1cblxuZnVuY3Rpb24gcmFuZG9tV2VpZ2h0KCkge1xuICAgIHJldHVybiBNYXRoLnJhbmRvbSgpICogMC40IC0gMC4yO1xufVxuXG4vKipcbiAqIFJldHVybnMgYSByYW5kb20gZmxvYXQgYmV0d2VlbiBnaXZlbiBtaW4gYW5kIG1heCBib3VuZHMgKGluY2x1c2l2ZSlcbiAqIEBwYXJhbSBtaW4gTWluaW11bSB2YWx1ZSBvZiB0aGUgcmFuZm9tIGZsb2F0XG4gKiBAcGFyYW0gbWF4IE1heGltdW0gdmFsdWUgb2YgdGhlIHJhbmRvbSBmbG9hdFxuICovXG5mdW5jdGlvbiByYW5kb21GbG9hdChtaW4sIG1heCkge1xuICAgIHJldHVybiBNYXRoLnJhbmRvbSgpICogKG1heCAtIG1pbikgKyBtaW47XG59XG4vKipcbiAqIENvbXBsaWNhdGVkIG1hdGguIEFsbCB5b3UgbmVlZCB0byBrbm93IGlzIHRoYXQgaXQgcmV0dXJucyBhIHJhbmRvbSBudW1iZXIuXG4gKiBNb3JlIGluZm86IGh0dHBzOi8vZW4ud2lraXBlZGlhLm9yZy93aWtpL05vcm1hbF9kaXN0cmlidXRpb25cbiAqL1xuZnVuY3Rpb24gZ2F1c3NSYW5kb20oKSB7XG4gICAgaWYgKGdhdXNzUmFuZG9tLnJldHVyblYpIHtcbiAgICAgICAgZ2F1c3NSYW5kb20ucmV0dXJuViA9IGZhbHNlO1xuICAgICAgICByZXR1cm4gZ2F1c3NSYW5kb20udlZhbDtcbiAgICB9XG4gICAgY29uc3QgdSA9IDIgKiBNYXRoLnJhbmRvbSgpIC0gMTtcbiAgICBjb25zdCB2ID0gMiAqIE1hdGgucmFuZG9tKCkgLSAxO1xuICAgIGNvbnN0IHIgPSB1ICogdSArIHYgKiB2O1xuICAgIGlmIChyID09PSAwIHx8IHIgPiAxKSB7XG4gICAgICAgIHJldHVybiBnYXVzc1JhbmRvbSgpO1xuICAgIH1cbiAgICBjb25zdCBjID0gTWF0aC5zcXJ0KCgtMiAqIE1hdGgubG9nKHIpKSAvIHIpO1xuICAgIGdhdXNzUmFuZG9tLnZWYWwgPSB2ICogYzsgLy8gY2FjaGUgdGhpc1xuICAgIGdhdXNzUmFuZG9tLnJldHVyblYgPSB0cnVlO1xuICAgIHJldHVybiB1ICogYztcbn1cbi8qKlxuICogUmV0dXJucyBhIHJhbmRvbSBpbnRlZ2VyIGJldHdlZW4gZ2l2ZW4gbWluIGFuZCBtYXggYm91bmRzXG4gKiBAcGFyYW0gbWluIE1pbmltdW0gdmFsdWUgb2YgdGhlIHJhbmRvbSBpbnRlZ2VyXG4gKiBAcGFyYW0gbWF4IE1heGltdW0gdmFsdWUgb2YgdGhlIHJhbmRvbSBpbnRlZ2VyXG4gKi9cbmZ1bmN0aW9uIHJhbmRvbUludGVnZXIobWluLCBtYXgpIHtcbiAgICByZXR1cm4gTWF0aC5mbG9vcihNYXRoLnJhbmRvbSgpICogKG1heCAtIG1pbikgKyBtaW4pO1xufVxuLyoqXG4gKiBJZiB5b3Uga25vdyB3aGF0IHRoaXMgaXM6IGh0dHBzOi8vZW4ud2lraXBlZGlhLm9yZy93aWtpL05vcm1hbF9kaXN0cmlidXRpb25cbiAqIEBwYXJhbSBtdVxuICogQHBhcmFtIHN0ZFxuICovXG5mdW5jdGlvbiByYW5kb21OKG11LCBzdGQpIHtcbiAgICByZXR1cm4gbXUgKyBnYXVzc1JhbmRvbSgpICogc3RkO1xufVxuZ2F1c3NSYW5kb20ucmV0dXJuViA9IGZhbHNlO1xuZ2F1c3NSYW5kb20udlZhbCA9IDA7XG5cbnZhciByYW5kb20kMSA9IC8qI19fUFVSRV9fKi9PYmplY3QuZnJlZXplKHtcbiAgICBfX3Byb3RvX186IG51bGwsXG4gICAgcmFuZG9tRmxvYXQ6IHJhbmRvbUZsb2F0LFxuICAgIGdhdXNzUmFuZG9tOiBnYXVzc1JhbmRvbSxcbiAgICByYW5kb21JbnRlZ2VyOiByYW5kb21JbnRlZ2VyLFxuICAgIHJhbmRvbU46IHJhbmRvbU5cbn0pO1xuXG4vKipcbiAqIFJldHVybnMgYW4gYXJyYXkgb2YgZ2l2ZW4gc2l6ZSwgZnVsbCBvZiByYW5kb21uZXNzXG4gKi9cbmZ1bmN0aW9uIHJhbmRvcyhzaXplLCBzdGQgPSBudWxsKSB7XG4gICAgY29uc3QgYXJyYXkgPSBuZXcgRmxvYXQzMkFycmF5KHNpemUpO1xuICAgIGlmIChzdGQgPT09IG51bGwpIHtcbiAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBzaXplOyBpKyspIHtcbiAgICAgICAgICAgIGFycmF5W2ldID0gcmFuZG9tV2VpZ2h0KCk7XG4gICAgICAgIH1cbiAgICB9XG4gICAgZWxzZSB7XG4gICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgc2l6ZTsgaSsrKSB7XG4gICAgICAgICAgICBhcnJheVtpXSA9IHJhbmRvbUZsb2F0KC1zdGQsIHN0ZCk7XG4gICAgICAgIH1cbiAgICB9XG4gICAgcmV0dXJuIGFycmF5O1xufVxuLyoqXG4gKiBSZXR1cm5zIGEgMkQgbWF0cml4IG9mIGdpdmVuIHNpemUsIGZ1bGwgb2YgcmFuZG9tbmVzc1xuICovXG5mdW5jdGlvbiByYW5kb3MyRCh3aWR0aCwgaGVpZ2h0LCBzdGQpIHtcbiAgICBjb25zdCByZXN1bHQgPSBuZXcgQXJyYXkoaGVpZ2h0KTtcbiAgICBmb3IgKGxldCB5ID0gMDsgeSA8IGhlaWdodDsgeSsrKSB7XG4gICAgICAgIHJlc3VsdFt5XSA9IHJhbmRvcyh3aWR0aCwgc3RkKTtcbiAgICB9XG4gICAgcmV0dXJuIHJlc3VsdDtcbn1cbi8qKlxuICogUmV0dXJucyBhIDNEIHRlbnNvciBvZiBnaXZlbiBzaXplLCBmdWxsIG9mIHJhbmRvbW5lc3NcbiAqL1xuZnVuY3Rpb24gcmFuZG9zM0Qod2lkdGgsIGhlaWdodCwgZGVwdGgsIHN0ZCkge1xuICAgIGNvbnN0IHJlc3VsdCA9IG5ldyBBcnJheShkZXB0aCk7XG4gICAgZm9yIChsZXQgeiA9IDA7IHogPCBkZXB0aDsgeisrKSB7XG4gICAgICAgIHJlc3VsdFt6XSA9IHJhbmRvczJEKHdpZHRoLCBoZWlnaHQsIHN0ZCk7XG4gICAgfVxuICAgIHJldHVybiByZXN1bHQ7XG59XG5cbmNvbnN0IGRlZmF1bHRzJDcgPSB7XG4gICAgLi4uYmFzZUxheWVyRGVmYXVsdFNldHRpbmdzLFxuICAgIHN0ZDogbnVsbCxcbn07XG5jbGFzcyBSYW5kb20gZXh0ZW5kcyBNb2RlbCB7XG4gICAgY29uc3RydWN0b3Ioc2V0dGluZ3MpIHtcbiAgICAgICAgc3VwZXIoKTtcbiAgICAgICAgdGhpcy5zZXR0aW5ncyA9IHsgLi4uZGVmYXVsdHMkNywgLi4uc2V0dGluZ3MgfTtcbiAgICAgICAgdGhpcy5zZXR1cFByYXhpcygpO1xuICAgICAgICB0aGlzLnZhbGlkYXRlKCk7XG4gICAgICAgIGlmICghdGhpcy53ZWlnaHRzKSB7XG4gICAgICAgICAgICB0aGlzLndlaWdodHMgPSByYW5kb3MyRCh0aGlzLndpZHRoLCB0aGlzLmhlaWdodCwgc2V0dGluZ3Muc3RkKTtcbiAgICAgICAgfVxuICAgICAgICBpZiAoIXRoaXMuZGVsdGFzKSB7XG4gICAgICAgICAgICB0aGlzLmRlbHRhcyA9IHplcm9zMkQodGhpcy53aWR0aCwgdGhpcy5oZWlnaHQpO1xuICAgICAgICB9XG4gICAgfVxuICAgIHByZWRpY3QoKSB7IH1cbiAgICBjb21wYXJlKCkgeyB9XG59XG5mdW5jdGlvbiByYW5kb20oc2V0dGluZ3MpIHtcbiAgICByZXR1cm4gbmV3IFJhbmRvbShzZXR0aW5ncyk7XG59XG5cbmZ1bmN0aW9uIHByZWRpY3QkNyh3ZWlnaHRzMSwgd2VpZ2h0czIpIHtcbiAgICBsZXQgc3VtID0gMDtcbiAgICBmb3IgKGxldCBpID0gMDsgaSA8IHRoaXMuY29uc3RhbnRzLnNpemU7IGkrKykge1xuICAgICAgICBzdW0gKz0gd2VpZ2h0czFbdGhpcy50aHJlYWQueV1baV0gKiB3ZWlnaHRzMltpXVt0aGlzLnRocmVhZC54XTtcbiAgICB9XG4gICAgcmV0dXJuIHN1bTtcbn1cbmZ1bmN0aW9uIGNvbXBhcmVGcm9tWChkZWx0YXMsIGlucHV0RGVsdGFzLCBpbnB1dFdlaWdodHMpIHtcbiAgICBsZXQgc3VtID0gaW5wdXREZWx0YXNbdGhpcy50aHJlYWQueV1bdGhpcy50aHJlYWQueF07XG4gICAgZm9yIChsZXQgaSA9IDA7IGkgPCB0aGlzLmNvbnN0YW50cy5zaXplOyBpKyspIHtcbiAgICAgICAgc3VtICs9IGRlbHRhc1t0aGlzLnRocmVhZC55XVtpXSAqIGlucHV0V2VpZ2h0c1t0aGlzLnRocmVhZC54XVtpXTtcbiAgICB9XG4gICAgcmV0dXJuIHN1bTtcbn1cbmZ1bmN0aW9uIGNvbXBhcmVGcm9tWShkZWx0YXMsIGlucHV0RGVsdGFzLCBpbnB1dFdlaWdodHMpIHtcbiAgICBsZXQgc3VtID0gaW5wdXREZWx0YXNbdGhpcy50aHJlYWQueV1bdGhpcy50aHJlYWQueF07XG4gICAgZm9yIChsZXQgaSA9IDA7IGkgPCB0aGlzLmNvbnN0YW50cy5zaXplOyBpKyspIHtcbiAgICAgICAgc3VtICs9IGRlbHRhc1tpXVt0aGlzLnRocmVhZC54XSAqIGlucHV0V2VpZ2h0c1tpXVt0aGlzLnRocmVhZC55XTtcbiAgICB9XG4gICAgcmV0dXJuIHN1bTtcbn1cbmNsYXNzIE11bHRpcGx5IGV4dGVuZHMgT3BlcmF0b3Ige1xuICAgIGNvbnN0cnVjdG9yKCkge1xuICAgICAgICBzdXBlciguLi5hcmd1bWVudHMpO1xuICAgICAgICB0aGlzLmNvbXBhcmVLZXJuZWwxID0gbnVsbDtcbiAgICAgICAgdGhpcy5jb21wYXJlS2VybmVsMiA9IG51bGw7XG4gICAgfVxuICAgIGdldCB3aWR0aCgpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuaW5wdXRMYXllcjIud2lkdGg7XG4gICAgfVxuICAgIHNldCB3aWR0aCh3aWR0aCkge1xuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ0Nhbm5vdCBzZXQgd2lkdGggb24gTXVsdGlwbHknKTtcbiAgICB9XG4gICAgZ2V0IGhlaWdodCgpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuaW5wdXRMYXllcjEuaGVpZ2h0O1xuICAgIH1cbiAgICBzZXQgaGVpZ2h0KGhlaWdodCkge1xuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ0Nhbm5vdCBzZXQgaGVpZ2h0IG9uIE11bHRpcGx5Jyk7XG4gICAgfVxuICAgIGdldCBkZXB0aCgpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuaW5wdXRMYXllcjEuZGVwdGg7XG4gICAgfVxuICAgIHNldCBkZXB0aChkZXB0aCkge1xuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ0Nhbm5vdCBzZXQgZGVwdGggb24gTXVsdGlwbHknKTtcbiAgICB9XG4gICAgdmFsaWRhdGUoKSB7XG4gICAgICAgIHN1cGVyLnZhbGlkYXRlKCk7XG4gICAgICAgIGlmICh0aGlzLmlucHV0TGF5ZXIxLndpZHRoICE9PSB0aGlzLmlucHV0TGF5ZXIyLmhlaWdodCkge1xuICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKGBMYXllciB3aWR0aCBtaXNtYXRjaCBvZiAke3RoaXMuaW5wdXRMYXllcjEud2lkdGh9IGFuZCAke3RoaXMuaW5wdXRMYXllcjIuaGVpZ2h0fWApO1xuICAgICAgICB9XG4gICAgfVxuICAgIHNldHVwS2VybmVscygpIHtcbiAgICAgICAgdGhpcy5wcmVkaWN0S2VybmVsID0gbWFrZUtlcm5lbChwcmVkaWN0JDcsIHtcbiAgICAgICAgICAgIG91dHB1dDogW3RoaXMud2lkdGgsIHRoaXMuaGVpZ2h0XSxcbiAgICAgICAgICAgIGNvbnN0YW50czoge1xuICAgICAgICAgICAgICAgIHNpemU6IHRoaXMuaW5wdXRMYXllcjIuaGVpZ2h0LFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIGltbXV0YWJsZTogdHJ1ZSxcbiAgICAgICAgfSk7XG4gICAgICAgIHRoaXMuY29tcGFyZUtlcm5lbDEgPSBtYWtlS2VybmVsKGNvbXBhcmVGcm9tWCwge1xuICAgICAgICAgICAgb3V0cHV0OiBbdGhpcy5pbnB1dExheWVyMS53aWR0aCwgdGhpcy5pbnB1dExheWVyMS5oZWlnaHRdLFxuICAgICAgICAgICAgY29uc3RhbnRzOiB7XG4gICAgICAgICAgICAgICAgc2l6ZTogdGhpcy5pbnB1dExheWVyMi53aWR0aCxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBpbW11dGFibGU6IHRydWUsXG4gICAgICAgIH0pO1xuICAgICAgICB0aGlzLmNvbXBhcmVLZXJuZWwyID0gbWFrZUtlcm5lbChjb21wYXJlRnJvbVksIHtcbiAgICAgICAgICAgIG91dHB1dDogW3RoaXMuaW5wdXRMYXllcjIud2lkdGgsIHRoaXMuaW5wdXRMYXllcjIuaGVpZ2h0XSxcbiAgICAgICAgICAgIGNvbnN0YW50czoge1xuICAgICAgICAgICAgICAgIHNpemU6IHRoaXMuaW5wdXRMYXllcjEuaGVpZ2h0LFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIGltbXV0YWJsZTogdHJ1ZSxcbiAgICAgICAgfSk7XG4gICAgfVxuICAgIHJldXNlS2VybmVscyhsYXllcikge1xuICAgICAgICBzdXBlci5yZXVzZUtlcm5lbHMobGF5ZXIpO1xuICAgICAgICB0aGlzLmNvbXBhcmVLZXJuZWwxID0gbGF5ZXIuY29tcGFyZUtlcm5lbDE7XG4gICAgICAgIHRoaXMuY29tcGFyZUtlcm5lbDIgPSBsYXllci5jb21wYXJlS2VybmVsMjtcbiAgICB9XG4gICAgcHJlZGljdCgpIHtcbiAgICAgICAgcmVsZWFzZSh0aGlzLndlaWdodHMpO1xuICAgICAgICBpZiAoIXRoaXMucHJlZGljdEtlcm5lbClcbiAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcigndGhpcy5wcmVkaWN0S2VybmVsIGlzIG5vdCBzZXQnKTtcbiAgICAgICAgdGhpcy53ZWlnaHRzID0gdGhpcy5wcmVkaWN0S2VybmVsKHRoaXMuaW5wdXRMYXllcjEud2VpZ2h0cywgdGhpcy5pbnB1dExheWVyMi53ZWlnaHRzKTtcbiAgICAgICAgY2xlYXIodGhpcy5kZWx0YXMpO1xuICAgIH1cbiAgICBjb21wYXJlKCkge1xuICAgICAgICBpZiAoIXRoaXMuY29tcGFyZUtlcm5lbDEpXG4gICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ3RoaXMuY29tcGFyZUtlcm5lbDEgbm90IHNldCcpO1xuICAgICAgICBpZiAoIXRoaXMuY29tcGFyZUtlcm5lbDIpXG4gICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ3RoaXMuY29tcGFyZUtlcm5lbDIgbm90IHNldCcpO1xuICAgICAgICBjb25zdCBpbnB1dExheWVyMURlbHRhcyA9IHRoaXMuaW5wdXRMYXllcjEuZGVsdGFzO1xuICAgICAgICBjb25zdCBpbnB1dExheWVyMkRlbHRhcyA9IHRoaXMuaW5wdXRMYXllcjIuZGVsdGFzO1xuICAgICAgICBjb25zdCBuZXdEZWx0YXMxID0gdGhpcy5jb21wYXJlS2VybmVsMSh0aGlzLmRlbHRhcywgdGhpcy5pbnB1dExheWVyMS5kZWx0YXMsIHRoaXMuaW5wdXRMYXllcjIud2VpZ2h0cyk7XG4gICAgICAgIGNvbnN0IG5ld0RlbHRhczIgPSB0aGlzLmNvbXBhcmVLZXJuZWwyKHRoaXMuZGVsdGFzLCB0aGlzLmlucHV0TGF5ZXIyLmRlbHRhcywgdGhpcy5pbnB1dExheWVyMS53ZWlnaHRzKTtcbiAgICAgICAgdGhpcy5pbnB1dExheWVyMi5kZWx0YXMgPSBuZXdEZWx0YXMyO1xuICAgICAgICB0aGlzLmlucHV0TGF5ZXIxLmRlbHRhcyA9IG5ld0RlbHRhczE7XG4gICAgICAgIHJlbGVhc2UoaW5wdXRMYXllcjFEZWx0YXMpO1xuICAgICAgICByZWxlYXNlKGlucHV0TGF5ZXIyRGVsdGFzKTtcbiAgICB9XG4gICAgc2V0dXBQcmF4aXMoKSB7IH1cbiAgICBsZWFybigpIHsgfVxuICAgIHRvSlNPTigpIHtcbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgIC4uLnN1cGVyLnRvSlNPTigpLFxuICAgICAgICAgICAgd2lkdGg6IHRoaXMud2lkdGgsXG4gICAgICAgICAgICBoZWlnaHQ6IHRoaXMuaGVpZ2h0LFxuICAgICAgICB9O1xuICAgIH1cbn1cbmZ1bmN0aW9uIG11bHRpcGx5JDEoaW5wdXRMYXllcjEsIGlucHV0TGF5ZXIyLCBzZXR0aW5ncykge1xuICAgIHJldHVybiBuZXcgTXVsdGlwbHkoaW5wdXRMYXllcjEsIGlucHV0TGF5ZXIyLCBzZXR0aW5ncyk7XG59XG5cbmZ1bmN0aW9uIHByZWRpY3QyRCQ0KGlucHV0cykge1xuICAgIHJldHVybiAxIC8gKDEgKyBNYXRoLmV4cCgtaW5wdXRzW3RoaXMudGhyZWFkLnldW3RoaXMudGhyZWFkLnhdKSk7XG59XG5mdW5jdGlvbiBwcmVkaWN0M0QkNShpbnB1dHMpIHtcbiAgICByZXR1cm4gKDEgLyAoMSArIE1hdGguZXhwKC1pbnB1dHNbdGhpcy50aHJlYWQuel1bdGhpcy50aHJlYWQueV1bdGhpcy50aHJlYWQueF0pKSk7XG59XG5mdW5jdGlvbiBjb21wYXJlMkQkNCh3ZWlnaHRzLCBkZWx0YXMpIHtcbiAgICBjb25zdCB3ZWlnaHQgPSB3ZWlnaHRzW3RoaXMudGhyZWFkLnldW3RoaXMudGhyZWFkLnhdO1xuICAgIGNvbnN0IGRlbHRhID0gZGVsdGFzW3RoaXMudGhyZWFkLnldW3RoaXMudGhyZWFkLnhdO1xuICAgIHJldHVybiB3ZWlnaHQgKiAoMSAtIHdlaWdodCkgKiBkZWx0YTtcbn1cbmZ1bmN0aW9uIGNvbXBhcmUzRCQ0KHdlaWdodHMsIGRlbHRhcykge1xuICAgIGNvbnN0IHdlaWdodCA9IHdlaWdodHNbdGhpcy50aHJlYWQuel1bdGhpcy50aHJlYWQueV1bdGhpcy50aHJlYWQueF07XG4gICAgY29uc3QgZGVsdGEgPSBkZWx0YXNbdGhpcy50aHJlYWQuel1bdGhpcy50aHJlYWQueV1bdGhpcy50aHJlYWQueF07XG4gICAgcmV0dXJuIHdlaWdodCAqICgxIC0gd2VpZ2h0KSAqIGRlbHRhO1xufVxuY2xhc3MgU2lnbW9pZCBleHRlbmRzIEFjdGl2YXRpb24ge1xuICAgIHNldHVwS2VybmVscygpIHtcbiAgICAgICAgaWYgKHRoaXMuZGVwdGggPiAwKSB7XG4gICAgICAgICAgICB0aGlzLnByZWRpY3RLZXJuZWwgPSBtYWtlS2VybmVsKHByZWRpY3QzRCQ1LCB7XG4gICAgICAgICAgICAgICAgb3V0cHV0OiBbdGhpcy53aWR0aCwgdGhpcy5oZWlnaHQsIHRoaXMuZGVwdGhdLFxuICAgICAgICAgICAgICAgIGZ1bmN0aW9uczogW2FjdGl2YXRlJDJdLFxuICAgICAgICAgICAgICAgIGltbXV0YWJsZTogdHJ1ZSxcbiAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgdGhpcy5jb21wYXJlS2VybmVsID0gbWFrZUtlcm5lbChjb21wYXJlM0QkNCwge1xuICAgICAgICAgICAgICAgIG91dHB1dDogW3RoaXMud2lkdGgsIHRoaXMuaGVpZ2h0LCB0aGlzLmRlcHRoXSxcbiAgICAgICAgICAgICAgICBmdW5jdGlvbnM6IFttZWFzdXJlJDJdLFxuICAgICAgICAgICAgICAgIGltbXV0YWJsZTogdHJ1ZSxcbiAgICAgICAgICAgIH0pO1xuICAgICAgICB9XG4gICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgdGhpcy5wcmVkaWN0S2VybmVsID0gbWFrZUtlcm5lbChwcmVkaWN0MkQkNCwge1xuICAgICAgICAgICAgICAgIG91dHB1dDogW3RoaXMud2lkdGgsIHRoaXMuaGVpZ2h0XSxcbiAgICAgICAgICAgICAgICBmdW5jdGlvbnM6IFthY3RpdmF0ZSQyXSxcbiAgICAgICAgICAgICAgICBpbW11dGFibGU6IHRydWUsXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIHRoaXMuY29tcGFyZUtlcm5lbCA9IG1ha2VLZXJuZWwoY29tcGFyZTJEJDQsIHtcbiAgICAgICAgICAgICAgICBvdXRwdXQ6IFt0aGlzLndpZHRoLCB0aGlzLmhlaWdodF0sXG4gICAgICAgICAgICAgICAgZnVuY3Rpb25zOiBbbWVhc3VyZSQyXSxcbiAgICAgICAgICAgICAgICBpbW11dGFibGU6IHRydWUsXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgfVxuICAgIH1cbiAgICBwcmVkaWN0KCkge1xuICAgICAgICByZWxlYXNlKHRoaXMud2VpZ2h0cyk7XG4gICAgICAgIHRoaXMud2VpZ2h0cyA9IHRoaXMucHJlZGljdEtlcm5lbCh0aGlzLmlucHV0TGF5ZXIud2VpZ2h0cyk7XG4gICAgICAgIGNsZWFyKHRoaXMuZGVsdGFzKTtcbiAgICB9XG4gICAgY29tcGFyZSgpIHtcbiAgICAgICAgcmVsZWFzZSh0aGlzLmlucHV0TGF5ZXIuZGVsdGFzKTtcbiAgICAgICAgdGhpcy5pbnB1dExheWVyLmRlbHRhcyA9IHRoaXMuY29tcGFyZUtlcm5lbCh0aGlzLndlaWdodHMsIHRoaXMuZGVsdGFzKTtcbiAgICB9XG59XG5mdW5jdGlvbiBzaWdtb2lkJDEoaW5wdXRMYXllciwgc2V0dGluZ3MpIHtcbiAgICByZXR1cm4gbmV3IFNpZ21vaWQoaW5wdXRMYXllciwgc2V0dGluZ3MpO1xufVxuXG5mdW5jdGlvbiBhcnRodXJGZWVkRm9yd2FyZChzZXR0aW5ncywgaW5wdXRMYXllcikge1xuICAgIGNvbnN0IHsgaGVpZ2h0IH0gPSBzZXR0aW5ncztcbiAgICBmdW5jdGlvbiBpbml0V2VpZ2h0c1ByYXhpcyhsYXllclRlbXBsYXRlLCBzZXR0aW5ncykge1xuICAgICAgICBjb25zdCBwcmF4aXMgPSBhcnRodXJEZXZpYXRpb25XZWlnaHRzKGxheWVyVGVtcGxhdGUsIHNldHRpbmdzKTtcbiAgICAgICAgcHJheGlzLnNldHVwS2VybmVscygpO1xuICAgICAgICByZXR1cm4gcHJheGlzO1xuICAgIH1cbiAgICBmdW5jdGlvbiBpbml0Qmlhc2VzUHJheGlzKGxheWVyVGVtcGxhdGUsIHNldHRpbmdzKSB7XG4gICAgICAgIGNvbnN0IHByYXhpcyA9IGFydGh1ckRldmlhdGlvbkJpYXNlcyhsYXllclRlbXBsYXRlLCBzZXR0aW5ncyk7XG4gICAgICAgIHByYXhpcy5zZXR1cEtlcm5lbHMoKTtcbiAgICAgICAgcmV0dXJuIHByYXhpcztcbiAgICB9XG4gICAgY29uc3Qgd2VpZ2h0c0xheWVyID0gcmFuZG9tKHtcbiAgICAgICAgaWQ6ICd3ZWlnaHRzJyxcbiAgICAgICAgaGVpZ2h0LFxuICAgICAgICB3aWR0aDogaW5wdXRMYXllci5oZWlnaHQsXG4gICAgICAgIGluaXRQcmF4aXM6IGluaXRXZWlnaHRzUHJheGlzLFxuICAgIH0pO1xuICAgIGNvbnN0IGJpYXNlc0xheWVyID0gcmFuZG9tKHtcbiAgICAgICAgaWQ6ICdiaWFzZXMnLFxuICAgICAgICBoZWlnaHQsXG4gICAgICAgIGluaXRQcmF4aXM6IGluaXRCaWFzZXNQcmF4aXMsXG4gICAgfSk7XG4gICAgY29uc3QgbXVsdGlwbHlMYXllciA9IG11bHRpcGx5JDEod2VpZ2h0c0xheWVyLCBpbnB1dExheWVyKTtcbiAgICBjb25zdCBhZGRMYXllciA9IGFkZCQxKG11bHRpcGx5TGF5ZXIsIGJpYXNlc0xheWVyKTtcbiAgICBjb25zdCBzaWdtb2lkTGF5ZXIgPSBzaWdtb2lkJDEoYWRkTGF5ZXIpO1xuICAgIGNvbnN0IHdlaWdodHNQcmF4aXMgPSB3ZWlnaHRzTGF5ZXIucHJheGlzO1xuICAgIHdlaWdodHNQcmF4aXMud2VpZ2h0c0xheWVyID0gd2VpZ2h0c0xheWVyO1xuICAgIHdlaWdodHNQcmF4aXMuaW5jb21pbmdMYXllciA9IGlucHV0TGF5ZXI7XG4gICAgd2VpZ2h0c1ByYXhpcy5kZWx0YUxheWVyID0gc2lnbW9pZExheWVyO1xuICAgIHJldHVybiBzaWdtb2lkTGF5ZXI7XG59XG5cbmZ1bmN0aW9uIGdldFN0cmlkZShzZXR0aW5ncywgZGVmYXVsdHMpIHtcbiAgICBpZiAodHlwZW9mIHNldHRpbmdzLnN0cmlkZSA9PT0gJ251bWJlcicpIHtcbiAgICAgICAgcmV0dXJuIHsgc3RyaWRlWDogc2V0dGluZ3Muc3RyaWRlLCBzdHJpZGVZOiBzZXR0aW5ncy5zdHJpZGUgfTtcbiAgICB9XG4gICAgZWxzZSB7XG4gICAgICAgIGxldCBzdHJpZGVYID0gZGVmYXVsdHMuc3RyaWRlO1xuICAgICAgICBsZXQgc3RyaWRlWSA9IGRlZmF1bHRzLnN0cmlkZTtcbiAgICAgICAgaWYgKHR5cGVvZiBzZXR0aW5ncy5zdHJpZGVYID09PSAnbnVtYmVyJykge1xuICAgICAgICAgICAgc3RyaWRlWCA9IHNldHRpbmdzLnN0cmlkZVg7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKHR5cGVvZiBzZXR0aW5ncy5zdHJpZGVZID09PSAnbnVtYmVyJykge1xuICAgICAgICAgICAgc3RyaWRlWSA9IHNldHRpbmdzLnN0cmlkZVk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHsgc3RyaWRlWCwgc3RyaWRlWSB9O1xuICAgIH1cbn1cbmZ1bmN0aW9uIGdldFBhZGRpbmcoc2V0dGluZ3MsIGRlZmF1bHRzKSB7XG4gICAgaWYgKHR5cGVvZiBzZXR0aW5ncy5wYWRkaW5nID09PSAnbnVtYmVyJykge1xuICAgICAgICByZXR1cm4geyBwYWRkaW5nWDogc2V0dGluZ3MucGFkZGluZywgcGFkZGluZ1k6IHNldHRpbmdzLnBhZGRpbmcgfTtcbiAgICB9XG4gICAgZWxzZSB7XG4gICAgICAgIGxldCBwYWRkaW5nWCA9IGRlZmF1bHRzLnBhZGRpbmc7XG4gICAgICAgIGxldCBwYWRkaW5nWSA9IGRlZmF1bHRzLnBhZGRpbmc7XG4gICAgICAgIGlmICh0eXBlb2Ygc2V0dGluZ3MucGFkZGluZ1ggPT09ICdudW1iZXInKSB7XG4gICAgICAgICAgICBwYWRkaW5nWCA9IHNldHRpbmdzLnBhZGRpbmdYO1xuICAgICAgICB9XG4gICAgICAgIGlmICh0eXBlb2Ygc2V0dGluZ3MucGFkZGluZ1kgPT09ICdudW1iZXInKSB7XG4gICAgICAgICAgICBwYWRkaW5nWSA9IHNldHRpbmdzLnBhZGRpbmdZO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiB7IHBhZGRpbmdYLCBwYWRkaW5nWSB9O1xuICAgIH1cbn1cblxuLyoqXG4gKiBSZXR1cm5zIGFuIGFycmF5IG9mIGEgZ2l2ZW4gc2l6ZSB3aXRoIGVhY2ggZWxlbWVudCBmaWxsZWQgd2l0aCBhIHNpbmdsZSB2YWx1ZVxuICovXG5mdW5jdGlvbiB2YWx1ZXMoc2l6ZSwgdmFsdWUpIHtcbiAgICByZXR1cm4gbmV3IEZsb2F0MzJBcnJheShzaXplKS5maWxsKHZhbHVlKTtcbn1cblxuZnVuY3Rpb24gcHJlZGljdCQ2KGlucHV0cywgZmlsdGVycywgYmlhc2VzKSB7XG4gICAgY29uc3Qgc3RhcnRGaWx0ZXJYID0gdGhpcy5jb25zdGFudHMucGFkZGluZ1ggLSB0aGlzLnRocmVhZC54ICogdGhpcy5jb25zdGFudHMuc3RyaWRlWDtcbiAgICBjb25zdCBzdGFydElucHV0WCA9IHRoaXMudGhyZWFkLnggKiB0aGlzLmNvbnN0YW50cy5zdHJpZGVYIC0gdGhpcy5jb25zdGFudHMucGFkZGluZ1g7XG4gICAgY29uc3QgZW5kRmlsdGVyWCA9IE1hdGgubWluKHRoaXMuY29uc3RhbnRzLmZpbHRlcldpZHRoLCBzdGFydEZpbHRlclggKyB0aGlzLmNvbnN0YW50cy5pbnB1dFdpZHRoKTtcbiAgICBjb25zdCBzdGFydEZpbHRlclkgPSB0aGlzLmNvbnN0YW50cy5wYWRkaW5nWSAtIHRoaXMudGhyZWFkLnkgKiB0aGlzLmNvbnN0YW50cy5zdHJpZGVZO1xuICAgIGNvbnN0IHN0YXJ0SW5wdXRZID0gdGhpcy50aHJlYWQueSAqIHRoaXMuY29uc3RhbnRzLnN0cmlkZVkgLSB0aGlzLmNvbnN0YW50cy5wYWRkaW5nWTtcbiAgICBjb25zdCBlbmRGaWx0ZXJZID0gTWF0aC5taW4odGhpcy5jb25zdGFudHMuZmlsdGVySGVpZ2h0LCBzdGFydEZpbHRlclkgKyB0aGlzLmNvbnN0YW50cy5pbnB1dEhlaWdodCk7XG4gICAgbGV0IHN1bSA9IDA7XG4gICAgZm9yIChsZXQgeiA9IDA7IHogPCB0aGlzLmNvbnN0YW50cy5pbnB1dERlcHRoOyB6KyspIHtcbiAgICAgICAgZm9yIChsZXQgZmlsdGVyWSA9IE1hdGgubWF4KDAsIHN0YXJ0RmlsdGVyWSksIGlucHV0WSA9IE1hdGgubWF4KDAsIHN0YXJ0SW5wdXRZKTsgZmlsdGVyWSA8IGVuZEZpbHRlclk7IGZpbHRlclkrKywgaW5wdXRZKyspIHtcbiAgICAgICAgICAgIGZvciAobGV0IGZpbHRlclggPSBNYXRoLm1heCgwLCBzdGFydEZpbHRlclgpLCBpbnB1dFggPSBNYXRoLm1heCgwLCBzdGFydElucHV0WCk7IGZpbHRlclggPCBlbmRGaWx0ZXJYOyBmaWx0ZXJYKyssIGlucHV0WCsrKSB7XG4gICAgICAgICAgICAgICAgc3VtICs9IGZpbHRlcnNbel1bZmlsdGVyWV1bZmlsdGVyWF0gKiBpbnB1dHNbel1baW5wdXRZXVtpbnB1dFhdO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfVxuICAgIHJldHVybiBzdW0gKyBiaWFzZXNbdGhpcy50aHJlYWQuel07XG59XG5mdW5jdGlvbiBjb21wYXJlRmlsdGVyRGVsdGFzJDEoZmlsdGVyRGVsdGFzLCBpbnB1dHMsIGRlbHRhcykge1xuICAgIGNvbnN0IHN0YXJ0RGVsdGFYID0gTWF0aC5tYXgoMCwgTWF0aC5jZWlsKCh0aGlzLmNvbnN0YW50cy5wYWRkaW5nWCAtIHRoaXMudGhyZWFkLngpIC8gdGhpcy5jb25zdGFudHMuc3RyaWRlWCkpO1xuICAgIGNvbnN0IHN0YXJ0SW5wdXRYID0gc3RhcnREZWx0YVggKiB0aGlzLmNvbnN0YW50cy5zdHJpZGVYICtcbiAgICAgICAgdGhpcy50aHJlYWQueCAtXG4gICAgICAgIHRoaXMuY29uc3RhbnRzLnBhZGRpbmdYO1xuICAgIGNvbnN0IGVuZERlbHRhWCA9IE1hdGgubWluKHRoaXMuY29uc3RhbnRzLmRlbHRhV2lkdGgsIE1hdGguZmxvb3IoKHRoaXMuY29uc3RhbnRzLmlucHV0V2lkdGggLVxuICAgICAgICAxIC1cbiAgICAgICAgdGhpcy50aHJlYWQueCArXG4gICAgICAgIHRoaXMuY29uc3RhbnRzLnBhZGRpbmdYKSAvXG4gICAgICAgIHRoaXMuY29uc3RhbnRzLnN0cmlkZVgpICsgMSk7XG4gICAgY29uc3Qgc3RhcnREZWx0YVkgPSBNYXRoLm1heCgwLCBNYXRoLmNlaWwoKHRoaXMuY29uc3RhbnRzLnBhZGRpbmdZIC0gdGhpcy50aHJlYWQueSkgLyB0aGlzLmNvbnN0YW50cy5zdHJpZGVZKSk7XG4gICAgY29uc3Qgc3RhcnRJbnB1dFkgPSBzdGFydERlbHRhWSAqIHRoaXMuY29uc3RhbnRzLnN0cmlkZVkgK1xuICAgICAgICB0aGlzLnRocmVhZC55IC1cbiAgICAgICAgdGhpcy5jb25zdGFudHMucGFkZGluZ1k7XG4gICAgY29uc3QgZW5kRGVsdGFZID0gTWF0aC5taW4odGhpcy5jb25zdGFudHMuZGVsdGFIZWlnaHQsIE1hdGguZmxvb3IoKHRoaXMuY29uc3RhbnRzLmlucHV0SGVpZ2h0IC1cbiAgICAgICAgMSAtXG4gICAgICAgIHRoaXMudGhyZWFkLnkgK1xuICAgICAgICB0aGlzLmNvbnN0YW50cy5wYWRkaW5nWSkgL1xuICAgICAgICB0aGlzLmNvbnN0YW50cy5zdHJpZGVZKSArIDEpO1xuICAgIGxldCBzdW0gPSBmaWx0ZXJEZWx0YXNbdGhpcy50aHJlYWQuel1bdGhpcy50aHJlYWQueV1bdGhpcy50aHJlYWQueF07XG4gICAgZm9yIChsZXQgZGVsdGFZID0gc3RhcnREZWx0YVksIGlucHV0WSA9IHN0YXJ0SW5wdXRZOyBkZWx0YVkgPCBlbmREZWx0YVk7IGRlbHRhWSsrLCBpbnB1dFkgKz0gdGhpcy5jb25zdGFudHMuc3RyaWRlWSkge1xuICAgICAgICBmb3IgKGxldCBkZWx0YVggPSBzdGFydERlbHRhWCwgaW5wdXRYID0gc3RhcnRJbnB1dFg7IGRlbHRhWCA8IGVuZERlbHRhWDsgZGVsdGFYKyssIGlucHV0WCArPSB0aGlzLmNvbnN0YW50cy5zdHJpZGVYKSB7XG4gICAgICAgICAgICBzdW0gKz1cbiAgICAgICAgICAgICAgICBpbnB1dHNbdGhpcy50aHJlYWQuel1baW5wdXRZXVtpbnB1dFhdICpcbiAgICAgICAgICAgICAgICAgICAgZGVsdGFzW3RoaXMuY29uc3RhbnRzLmRlbHRhWl1bZGVsdGFZXVtkZWx0YVhdO1xuICAgICAgICB9XG4gICAgfVxuICAgIHJldHVybiBzdW07XG59XG5mdW5jdGlvbiBjb21wYXJlSW5wdXREZWx0YXMkMShpbnB1dERlbHRhcywgZmlsdGVycywgZGVsdGFzKSB7XG4gICAgY29uc3QgeCA9IHRoaXMudGhyZWFkLnggKyB0aGlzLmNvbnN0YW50cy5wYWRkaW5nWDtcbiAgICBjb25zdCBzdGFydERlbHRhWCA9IHggPCB0aGlzLmNvbnN0YW50cy5maWx0ZXJXaWR0aFxuICAgICAgICA/IDBcbiAgICAgICAgOiBNYXRoLmZsb29yKCh4IC0gdGhpcy5jb25zdGFudHMuZmlsdGVyV2lkdGggKyB0aGlzLmNvbnN0YW50cy5zdHJpZGVYKSAvXG4gICAgICAgICAgICB0aGlzLmNvbnN0YW50cy5zdHJpZGVYKTtcbiAgICBjb25zdCBzdGFydEZpbHRlclggPSB4IC0gc3RhcnREZWx0YVggKiB0aGlzLmNvbnN0YW50cy5zdHJpZGVYO1xuICAgIGNvbnN0IGVuZERlbHRhWCA9IE1hdGgubWluKHN0YXJ0RGVsdGFYICsgTWF0aC5mbG9vcihzdGFydEZpbHRlclggLyB0aGlzLmNvbnN0YW50cy5zdHJpZGVYKSArIDEsIHRoaXMuY29uc3RhbnRzLmRlbHRhV2lkdGgpO1xuICAgIGNvbnN0IHkgPSB0aGlzLnRocmVhZC55ICsgdGhpcy5jb25zdGFudHMucGFkZGluZ1k7XG4gICAgY29uc3Qgc3RhcnREZWx0YVkgPSB5IDwgdGhpcy5jb25zdGFudHMuZmlsdGVySGVpZ2h0XG4gICAgICAgID8gMFxuICAgICAgICA6IE1hdGguZmxvb3IoKHkgLSB0aGlzLmNvbnN0YW50cy5maWx0ZXJIZWlnaHQgKyB0aGlzLmNvbnN0YW50cy5zdHJpZGVZKSAvXG4gICAgICAgICAgICB0aGlzLmNvbnN0YW50cy5zdHJpZGVZKTtcbiAgICBjb25zdCBzdGFydEZpbHRlclkgPSB5IC0gc3RhcnREZWx0YVkgKiB0aGlzLmNvbnN0YW50cy5zdHJpZGVZO1xuICAgIGNvbnN0IGVuZERlbHRhWSA9IE1hdGgubWluKHN0YXJ0RGVsdGFZICsgTWF0aC5mbG9vcihzdGFydEZpbHRlclkgLyB0aGlzLmNvbnN0YW50cy5zdHJpZGVZKSArIDEsIHRoaXMuY29uc3RhbnRzLmRlbHRhSGVpZ2h0KTtcbiAgICBsZXQgc3VtID0gaW5wdXREZWx0YXNbdGhpcy50aHJlYWQuel1bdGhpcy50aHJlYWQueV1bdGhpcy50aHJlYWQueF07XG4gICAgbGV0IGRlbHRhWSA9IHN0YXJ0RGVsdGFZO1xuICAgIGZvciAobGV0IGZpbHRlclkgPSBzdGFydEZpbHRlclk7IGRlbHRhWSA8IGVuZERlbHRhWTsgZmlsdGVyWSAtPSB0aGlzLmNvbnN0YW50cy5zdHJpZGVZLCBkZWx0YVkrKykge1xuICAgICAgICBsZXQgZGVsdGFYID0gc3RhcnREZWx0YVg7XG4gICAgICAgIGZvciAobGV0IGZpbHRlclggPSBzdGFydEZpbHRlclg7IGRlbHRhWCA8IGVuZERlbHRhWDsgZmlsdGVyWCAtPSB0aGlzLmNvbnN0YW50cy5zdHJpZGVYLCBkZWx0YVgrKykge1xuICAgICAgICAgICAgc3VtICs9XG4gICAgICAgICAgICAgICAgZmlsdGVyc1t0aGlzLnRocmVhZC56XVtmaWx0ZXJZXVtmaWx0ZXJYXSAqXG4gICAgICAgICAgICAgICAgICAgIGRlbHRhc1t0aGlzLmNvbnN0YW50cy5kZWx0YVpdW2RlbHRhWV1bZGVsdGFYXTtcbiAgICAgICAgfVxuICAgIH1cbiAgICByZXR1cm4gc3VtO1xufVxuZnVuY3Rpb24gY29tcGFyZUJpYXNlcyQxKGJpYXNEZWx0YXMsIGRlbHRhcykge1xuICAgIGxldCBzdW0gPSAwO1xuICAgIGZvciAobGV0IHkgPSAwOyB5IDwgdGhpcy5jb25zdGFudHMuZGVsdGFIZWlnaHQ7IHkrKykge1xuICAgICAgICBmb3IgKGxldCB4ID0gMDsgeCA8IHRoaXMuY29uc3RhbnRzLmRlbHRhV2lkdGg7IHgrKykge1xuICAgICAgICAgICAgc3VtICs9IGRlbHRhc1t0aGlzLnRocmVhZC56XVt5XVt4XTtcbiAgICAgICAgfVxuICAgIH1cbiAgICByZXR1cm4gYmlhc0RlbHRhc1t0aGlzLnRocmVhZC56XVt0aGlzLnRocmVhZC55XVt0aGlzLnRocmVhZC54XSArIHN1bTtcbn1cbmNvbnN0IGRlZmF1bHRzJDYgPSB7XG4gICAgc3RyaWRlOiAwLFxuICAgIHBhZGRpbmc6IDAsXG4gICAgYmlhczogMC4xLFxuICAgIGZpbHRlckNvdW50OiAxLFxuICAgIGZpbHRlcldpZHRoOiAwLFxuICAgIGZpbHRlckhlaWdodDogMCxcbn07XG5jbGFzcyBDb252b2x1dGlvbiBleHRlbmRzIEZpbHRlciB7XG4gICAgY29uc3RydWN0b3Ioc2V0dGluZ3MsIGlucHV0TGF5ZXIpIHtcbiAgICAgICAgdmFyIF9hLCBfYiwgX2M7XG4gICAgICAgIHN1cGVyKHNldHRpbmdzLCBpbnB1dExheWVyKTtcbiAgICAgICAgdGhpcy5jb21wYXJlRmlsdGVyRGVsdGFzS2VybmVsID0gbnVsbDtcbiAgICAgICAgdGhpcy5jb21wYXJlSW5wdXREZWx0YXNLZXJuZWwgPSBudWxsO1xuICAgICAgICB0aGlzLmNvbXBhcmVCaWFzZXNLZXJuZWwgPSBudWxsO1xuICAgICAgICB0aGlzLnNldHRpbmdzID0ge1xuICAgICAgICAgICAgLi4uZGVmYXVsdHMkNixcbiAgICAgICAgICAgIC4uLnNldHRpbmdzLFxuICAgICAgICAgICAgLi4uZ2V0UGFkZGluZyhzZXR0aW5ncywgZGVmYXVsdHMkNiksXG4gICAgICAgICAgICAuLi5nZXRTdHJpZGUoc2V0dGluZ3MsIGRlZmF1bHRzJDYpLFxuICAgICAgICB9O1xuICAgICAgICB0aGlzLndlaWdodHMgPSAoX2EgPSBzZXR0aW5ncy53ZWlnaHRzKSAhPT0gbnVsbCAmJiBfYSAhPT0gdm9pZCAwID8gX2EgOiByYW5kb3MzRCh0aGlzLndpZHRoLCB0aGlzLmhlaWdodCwgdGhpcy5kZXB0aCk7XG4gICAgICAgIHRoaXMuZGVsdGFzID0gemVyb3MzRCh0aGlzLndpZHRoLCB0aGlzLmhlaWdodCwgdGhpcy5kZXB0aCk7XG4gICAgICAgIHRoaXMuYmlhc2VzID0gdmFsdWVzKHRoaXMuZGVwdGgsIHRoaXMuYmlhcyk7XG4gICAgICAgIHRoaXMuYmlhc0RlbHRhcyA9IChfYiA9IHNldHRpbmdzLmJpYXNEZWx0YXMpICE9PSBudWxsICYmIF9iICE9PSB2b2lkIDAgPyBfYiA6IHJhbmRvcyh0aGlzLmRlcHRoKTtcbiAgICAgICAgdGhpcy5maWx0ZXJzID0gKF9jID0gc2V0dGluZ3MuZmlsdGVycykgIT09IG51bGwgJiYgX2MgIT09IHZvaWQgMCA/IF9jIDogcmFuZG9zM0QodGhpcy5maWx0ZXJXaWR0aCwgdGhpcy5maWx0ZXJIZWlnaHQsIHRoaXMuZmlsdGVyQ291bnQpO1xuICAgICAgICB0aGlzLmZpbHRlckRlbHRhcyA9IHplcm9zM0QodGhpcy5maWx0ZXJXaWR0aCwgdGhpcy5maWx0ZXJIZWlnaHQsIHRoaXMuZmlsdGVyQ291bnQpO1xuICAgICAgICB0aGlzLnZhbGlkYXRlKCk7XG4gICAgfVxuICAgIGdldCBzdHJpZGVYKCkge1xuICAgICAgICByZXR1cm4gdGhpcy5zZXR0aW5ncy5zdHJpZGVYO1xuICAgIH1cbiAgICBnZXQgc3RyaWRlWSgpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuc2V0dGluZ3Muc3RyaWRlWTtcbiAgICB9XG4gICAgZ2V0IHBhZGRpbmdYKCkge1xuICAgICAgICByZXR1cm4gdGhpcy5zZXR0aW5ncy5wYWRkaW5nWDtcbiAgICB9XG4gICAgZ2V0IHBhZGRpbmdZKCkge1xuICAgICAgICByZXR1cm4gdGhpcy5zZXR0aW5ncy5wYWRkaW5nWDtcbiAgICB9XG4gICAgZ2V0IHdpZHRoKCkge1xuICAgICAgICByZXR1cm4gTWF0aC5mbG9vcigodGhpcy5pbnB1dExheWVyLndpZHRoICsgdGhpcy5wYWRkaW5nWCAqIDIgLSB0aGlzLmZpbHRlcldpZHRoKSAvXG4gICAgICAgICAgICB0aGlzLnN0cmlkZVggK1xuICAgICAgICAgICAgMSk7XG4gICAgfVxuICAgIGdldCBoZWlnaHQoKSB7XG4gICAgICAgIHJldHVybiBNYXRoLmZsb29yKCh0aGlzLmlucHV0TGF5ZXIuaGVpZ2h0ICsgdGhpcy5wYWRkaW5nWSAqIDIgLSB0aGlzLmZpbHRlckhlaWdodCkgL1xuICAgICAgICAgICAgdGhpcy5zdHJpZGVZICtcbiAgICAgICAgICAgIDEpO1xuICAgIH1cbiAgICBnZXQgYmlhcygpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuc2V0dGluZ3MuYmlhcztcbiAgICB9XG4gICAgZ2V0IGRlcHRoKCkge1xuICAgICAgICByZXR1cm4gdGhpcy5maWx0ZXJDb3VudDtcbiAgICB9XG4gICAgZ2V0IGJpYXNlcygpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuc2V0dGluZ3MuYmlhc2VzO1xuICAgIH1cbiAgICBzZXQgYmlhc2VzKGJpYXNlcykge1xuICAgICAgICB0aGlzLnNldHRpbmdzLmJpYXNlcyA9IGJpYXNlcztcbiAgICB9XG4gICAgZ2V0IGJpYXNEZWx0YXMoKSB7XG4gICAgICAgIHJldHVybiB0aGlzLnNldHRpbmdzLmJpYXNEZWx0YXM7XG4gICAgfVxuICAgIHNldCBiaWFzRGVsdGFzKHdlaWdodHMpIHtcbiAgICAgICAgdGhpcy5zZXR0aW5ncy5iaWFzRGVsdGFzID0gd2VpZ2h0cztcbiAgICB9XG4gICAgZ2V0IGZpbHRlcnMoKSB7XG4gICAgICAgIHJldHVybiB0aGlzLnNldHRpbmdzLmZpbHRlcnM7XG4gICAgfVxuICAgIHNldCBmaWx0ZXJzKGZpbHRlcnMpIHtcbiAgICAgICAgdGhpcy5zZXR0aW5ncy5maWx0ZXJzID0gZmlsdGVycztcbiAgICB9XG4gICAgZ2V0IGZpbHRlckRlbHRhcygpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuc2V0dGluZ3MuZmlsdGVyRGVsdGFzO1xuICAgIH1cbiAgICBzZXQgZmlsdGVyRGVsdGFzKGZpbHRlckRlbHRhcykge1xuICAgICAgICB0aGlzLnNldHRpbmdzLmZpbHRlckRlbHRhcyA9IGZpbHRlckRlbHRhcztcbiAgICB9XG4gICAgc2V0dXBLZXJuZWxzKCkge1xuICAgICAgICB0aGlzLnByZWRpY3RLZXJuZWwgPSBtYWtlS2VybmVsKHByZWRpY3QkNiwge1xuICAgICAgICAgICAgY29uc3RhbnRzOiB7XG4gICAgICAgICAgICAgICAgaW5wdXRXaWR0aDogdGhpcy5pbnB1dExheWVyLndpZHRoLFxuICAgICAgICAgICAgICAgIGlucHV0SGVpZ2h0OiB0aGlzLmlucHV0TGF5ZXIuaGVpZ2h0LFxuICAgICAgICAgICAgICAgIGlucHV0RGVwdGg6IHRoaXMuaW5wdXRMYXllci5kZXB0aCxcbiAgICAgICAgICAgICAgICBzdHJpZGVYOiB0aGlzLnN0cmlkZVgsXG4gICAgICAgICAgICAgICAgc3RyaWRlWTogdGhpcy5zdHJpZGVZLFxuICAgICAgICAgICAgICAgIHBhZGRpbmdYOiB0aGlzLnBhZGRpbmdYLFxuICAgICAgICAgICAgICAgIHBhZGRpbmdZOiB0aGlzLnBhZGRpbmdZLFxuICAgICAgICAgICAgICAgIGZpbHRlcldpZHRoOiB0aGlzLmZpbHRlcldpZHRoLFxuICAgICAgICAgICAgICAgIGZpbHRlckhlaWdodDogdGhpcy5maWx0ZXJIZWlnaHQsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgb3V0cHV0OiBbdGhpcy53aWR0aCwgdGhpcy5oZWlnaHQsIHRoaXMuZGVwdGhdLFxuICAgICAgICAgICAgaW1tdXRhYmxlOiB0cnVlLFxuICAgICAgICB9KTtcbiAgICAgICAgdGhpcy5jb21wYXJlRmlsdGVyRGVsdGFzS2VybmVsID0gbWFrZUtlcm5lbChjb21wYXJlRmlsdGVyRGVsdGFzJDEsIHtcbiAgICAgICAgICAgIGNvbnN0YW50czoge1xuICAgICAgICAgICAgICAgIGRlbHRhc1dpZHRoOiB0aGlzLndpZHRoLFxuICAgICAgICAgICAgICAgIGRlbHRhc0hlaWdodDogdGhpcy5oZWlnaHQsXG4gICAgICAgICAgICAgICAgZGVsdGFzRGVwdGg6IHRoaXMuZGVwdGgsXG4gICAgICAgICAgICAgICAgaW5wdXRXaWR0aDogdGhpcy5pbnB1dExheWVyLndpZHRoLFxuICAgICAgICAgICAgICAgIGlucHV0SGVpZ2h0OiB0aGlzLmlucHV0TGF5ZXIuaGVpZ2h0LFxuICAgICAgICAgICAgICAgIGlucHV0RGVwdGg6IHRoaXMuaW5wdXRMYXllci5kZXB0aCxcbiAgICAgICAgICAgICAgICBzdHJpZGVYOiB0aGlzLnN0cmlkZVgsXG4gICAgICAgICAgICAgICAgc3RyaWRlWTogdGhpcy5zdHJpZGVZLFxuICAgICAgICAgICAgICAgIHBhZGRpbmdYOiB0aGlzLnBhZGRpbmdYLFxuICAgICAgICAgICAgICAgIHBhZGRpbmdZOiB0aGlzLnBhZGRpbmdZLFxuICAgICAgICAgICAgICAgIGZpbHRlcldpZHRoOiB0aGlzLmZpbHRlcldpZHRoLFxuICAgICAgICAgICAgICAgIGZpbHRlckhlaWdodDogdGhpcy5maWx0ZXJIZWlnaHQsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgb3V0cHV0OiBbdGhpcy53aWR0aCwgdGhpcy5oZWlnaHQsIHRoaXMuZGVwdGhdLFxuICAgICAgICAgICAgaW1tdXRhYmxlOiB0cnVlLFxuICAgICAgICB9KTtcbiAgICAgICAgdGhpcy5jb21wYXJlSW5wdXREZWx0YXNLZXJuZWwgPSBtYWtlS2VybmVsKGNvbXBhcmVJbnB1dERlbHRhcyQxLCB7XG4gICAgICAgICAgICBjb25zdGFudHM6IHtcbiAgICAgICAgICAgICAgICBmaWx0ZXJDb3VudDogdGhpcy5maWx0ZXJDb3VudCxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBvdXRwdXQ6IFtcbiAgICAgICAgICAgICAgICB0aGlzLmlucHV0TGF5ZXIud2lkdGgsXG4gICAgICAgICAgICAgICAgdGhpcy5pbnB1dExheWVyLmhlaWdodCxcbiAgICAgICAgICAgICAgICB0aGlzLmlucHV0TGF5ZXIuZGVwdGgsXG4gICAgICAgICAgICBdLFxuICAgICAgICAgICAgaW1tdXRhYmxlOiB0cnVlLFxuICAgICAgICB9KTtcbiAgICAgICAgdGhpcy5jb21wYXJlQmlhc2VzS2VybmVsID0gbWFrZUtlcm5lbChjb21wYXJlQmlhc2VzJDEsIHtcbiAgICAgICAgICAgIG91dHB1dDogWzEsIDEsIHRoaXMuZGVwdGhdLFxuICAgICAgICAgICAgY29uc3RhbnRzOiB7XG4gICAgICAgICAgICAgICAgZGVsdGFXaWR0aDogdGhpcy53aWR0aCxcbiAgICAgICAgICAgICAgICBkZWx0YUhlaWdodDogdGhpcy5oZWlnaHQsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgaW1tdXRhYmxlOiB0cnVlLFxuICAgICAgICB9KTtcbiAgICB9XG4gICAgcHJlZGljdCgpIHtcbiAgICAgICAgdGhpcy53ZWlnaHRzID0gdGhpcy5wcmVkaWN0S2VybmVsKHRoaXMuaW5wdXRMYXllci53ZWlnaHRzLCB0aGlzLmZpbHRlcnMsIHRoaXMuYmlhc2VzKTtcbiAgICB9XG4gICAgY29tcGFyZSgpIHtcbiAgICAgICAgY29uc3QgeyBmaWx0ZXJEZWx0YXMsIGJpYXNEZWx0YXMgfSA9IHRoaXM7XG4gICAgICAgIHRoaXMuZmlsdGVyRGVsdGFzID0gdGhpcy5jb21wYXJlRmlsdGVyRGVsdGFzS2VybmVsKGZpbHRlckRlbHRhcywgdGhpcy5pbnB1dExheWVyLndlaWdodHMsIHRoaXMuZGVsdGFzKTtcbiAgICAgICAgcmVsZWFzZShmaWx0ZXJEZWx0YXMpO1xuICAgICAgICB0aGlzLmJpYXNEZWx0YXMgPSB0aGlzLmNvbXBhcmVCaWFzZXNLZXJuZWwoYmlhc0RlbHRhcywgdGhpcy5kZWx0YXMpO1xuICAgICAgICByZWxlYXNlKGJpYXNEZWx0YXMpO1xuICAgICAgICByZWxlYXNlKHRoaXMuZGVsdGFzKTtcbiAgICAgICAgdGhpcy5kZWx0YXMgPSB0aGlzLmNvbXBhcmVJbnB1dERlbHRhc0tlcm5lbCh0aGlzLmZpbHRlcnMsIHRoaXMuaW5wdXRMYXllci5kZWx0YXMpO1xuICAgICAgICByZWxlYXNlKHRoaXMuaW5wdXRMYXllci5kZWx0YXMpO1xuICAgICAgICAvLyBUT0RPOiBkbyB3ZSBuZWVkIHRvIGNsb25lIGhlcmU/XG4gICAgICAgIHRoaXMuaW5wdXRMYXllci5kZWx0YXMgPSBjbG9uZSh0aGlzLmRlbHRhcyk7XG4gICAgfVxuICAgIGxlYXJuKGxlYXJuaW5nUmF0ZSkge1xuICAgICAgICAvLyBUT0RPOiBoYW5kbGUgZmlsdGVyc1xuICAgICAgICAvLyBUT0RPOiBkbyB3ZSBuZWVkIHRvIHJlbGVhc2UgaGVyZT9cbiAgICAgICAgY29uc3QgeyB3ZWlnaHRzOiBvbGRXZWlnaHRzIH0gPSB0aGlzO1xuICAgICAgICB0aGlzLndlaWdodHMgPSB0aGlzLnByYXhpcy5ydW4odGhpcywgbGVhcm5pbmdSYXRlKTtcbiAgICAgICAgcmVsZWFzZShvbGRXZWlnaHRzKTtcbiAgICAgICAgY2xlYXIodGhpcy5kZWx0YXMpO1xuICAgIH1cbn1cbmZ1bmN0aW9uIGNvbnZvbHV0aW9uKHNldHRpbmdzLCBpbnB1dExheWVyKSB7XG4gICAgcmV0dXJuIG5ldyBDb252b2x1dGlvbihzZXR0aW5ncywgaW5wdXRMYXllcik7XG59XG5cbmZ1bmN0aW9uIHNldERyb3BvdXQoZHJvcG91dCkge1xuICAgIHJldHVybiBkcm9wb3V0O1xufVxuZnVuY3Rpb24gdHJhaW5pbmdQcmVkaWN0KGlucHV0cykge1xuICAgIGlmIChzZXREcm9wb3V0KE1hdGgucmFuZG9tKCkpIDwgdGhpcy5jb25zdGFudHMucHJvYmFiaWxpdHkpIHtcbiAgICAgICAgcmV0dXJuIDA7XG4gICAgfVxuICAgIHJldHVybiBpbnB1dHNbdGhpcy50aHJlYWQueV1bdGhpcy50aHJlYWQueF07XG59XG5mdW5jdGlvbiBwcmVkaWN0JDUoaW5wdXRzKSB7XG4gICAgcmV0dXJuIGlucHV0c1t0aGlzLnRocmVhZC55XVt0aGlzLnRocmVhZC54XSAqIHRoaXMuY29uc3RhbnRzLnByb2JhYmlsaXR5O1xufVxuZnVuY3Rpb24gY29tcGFyZSQzKGRyb3BvdXRzLCBkZWx0YXMpIHtcbiAgICBpZiAoZHJvcG91dHNbdGhpcy50aHJlYWQueV1bdGhpcy50aHJlYWQueF0gPT09IDApIHtcbiAgICAgICAgcmV0dXJuIDA7XG4gICAgfVxuICAgIHJldHVybiBkZWx0YXNbdGhpcy50aHJlYWQueV1bdGhpcy50aHJlYWQueF07XG59XG5jb25zdCBkcm9wb3V0RGVmYXVsdHMgPSB7XG4gICAgLi4uYmFzZUxheWVyRGVmYXVsdFNldHRpbmdzLFxuICAgIHByb2JhYmlsaXR5OiAwLjUsXG59O1xuY2xhc3MgRHJvcG91dCBleHRlbmRzIEZpbHRlciB7XG4gICAgY29uc3RydWN0b3IoaW5wdXRMYXllciwgc2V0dGluZ3MpIHtcbiAgICAgICAgc3VwZXIoc2V0dGluZ3MsIGlucHV0TGF5ZXIpO1xuICAgICAgICB0aGlzLnByZWRpY3RLZXJuZWxNYXAgPSBudWxsO1xuICAgICAgICB0aGlzLnNldHRpbmdzID0geyAuLi5kcm9wb3V0RGVmYXVsdHMsIC4uLnNldHRpbmdzIH07XG4gICAgICAgIHRoaXMuZHJvcG91dHMgPSBudWxsO1xuICAgICAgICB0aGlzLnZhbGlkYXRlKCk7XG4gICAgfVxuICAgIHNldHVwS2VybmVscyhpc1RyYWluaW5nKSB7XG4gICAgICAgIGNvbnN0IG91dHB1dCA9IFt0aGlzLndpZHRoLCB0aGlzLmhlaWdodF07XG4gICAgICAgIGlmIChpc1RyYWluaW5nKSB7XG4gICAgICAgICAgICB0aGlzLnByZWRpY3RLZXJuZWxNYXAgPSBtYWtlS2VybmVsTWFwKHsgZHJvcG91dHM6IHNldERyb3BvdXQgfSwgdHJhaW5pbmdQcmVkaWN0LCB7XG4gICAgICAgICAgICAgICAgb3V0cHV0LFxuICAgICAgICAgICAgICAgIGltbXV0YWJsZTogdHJ1ZSxcbiAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgdGhpcy5jb21wYXJlS2VybmVsID0gbWFrZUtlcm5lbChjb21wYXJlJDMsIHsgb3V0cHV0LCBpbW11dGFibGU6IHRydWUgfSk7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICB0aGlzLnByZWRpY3RLZXJuZWxNYXAgPSBtYWtlS2VybmVsTWFwKHt9LCBwcmVkaWN0JDUsIHsgb3V0cHV0LCBpbW11dGFibGU6IHRydWUgfSk7XG4gICAgICAgIH1cbiAgICB9XG4gICAgcHJlZGljdCgpIHtcbiAgICAgICAgcmVsZWFzZSh0aGlzLndlaWdodHMpO1xuICAgICAgICBpZiAodGhpcy5kcm9wb3V0cykge1xuICAgICAgICAgICAgcmVsZWFzZSh0aGlzLmRyb3BvdXRzKTtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCB7IHJlc3VsdCwgZHJvcG91dHMgfSA9IHRoaXNcbiAgICAgICAgICAgIC5wcmVkaWN0S2VybmVsTWFwKHRoaXMuaW5wdXRMYXllci53ZWlnaHRzKTtcbiAgICAgICAgdGhpcy53ZWlnaHRzID0gcmVzdWx0O1xuICAgICAgICB0aGlzLmRyb3BvdXRzID0gZHJvcG91dHM7XG4gICAgfVxuICAgIGNvbXBhcmUoKSB7XG4gICAgICAgIHJlbGVhc2UodGhpcy5kZWx0YXMpO1xuICAgICAgICB0aGlzLmRlbHRhcyA9IHRoaXMuY29tcGFyZUtlcm5lbCh0aGlzLmRyb3BvdXRzLCB0aGlzLmlucHV0TGF5ZXIuZGVsdGFzKTtcbiAgICB9XG59XG5mdW5jdGlvbiBkcm9wb3V0KGlucHV0TGF5ZXIsIHNldHRpbmdzKSB7XG4gICAgcmV0dXJuIG5ldyBEcm9wb3V0KGlucHV0TGF5ZXIsIHNldHRpbmdzKTtcbn1cblxuZnVuY3Rpb24gZmVlZEZvcndhcmQoc2V0dGluZ3MsIGlucHV0KSB7XG4gICAgY29uc3QgeyBoZWlnaHQsIHByYXhpc09wdHMgPSBudWxsIH0gPSBzZXR0aW5ncztcbiAgICBjb25zdCB3ZWlnaHRzID0gcmFuZG9tKHtcbiAgICAgICAgaWQ6ICd3ZWlnaHRzJyxcbiAgICAgICAgaGVpZ2h0LFxuICAgICAgICB3aWR0aDogaW5wdXQuaGVpZ2h0LFxuICAgICAgICBwcmF4aXNPcHRzLFxuICAgIH0pO1xuICAgIGNvbnN0IGJpYXNlcyA9IHJhbmRvbSh7IGlkOiAnYmlhc2VzJywgaGVpZ2h0LCBwcmF4aXNPcHRzIH0pO1xuICAgIHJldHVybiBzaWdtb2lkJDEoYWRkJDEobXVsdGlwbHkkMSh3ZWlnaHRzLCBpbnB1dCwgeyBwcmF4aXNPcHRzIH0pLCBiaWFzZXMsIHsgcHJheGlzT3B0cyB9KSwgeyBwcmF4aXNPcHRzIH0pO1xufVxuXG5mdW5jdGlvbiBwcmVkaWN0JDQoaW5wdXRzLCBmaWx0ZXJzLCBiaWFzZXMpIHtcbiAgICBsZXQgb3V0cHV0ID0gMDtcbiAgICBsZXQgaSA9IDA7XG4gICAgZm9yIChsZXQgeSA9IDA7IHkgPCB0aGlzLmNvbnN0YW50cy5pbnB1dEhlaWdodDsgeSsrKSB7XG4gICAgICAgIGZvciAobGV0IHggPSAwOyB4IDwgdGhpcy5jb25zdGFudHMuaW5wdXRXaWR0aDsgeCsrKSB7XG4gICAgICAgICAgICBvdXRwdXQgKz0gaW5wdXRzW3ldW3hdICogZmlsdGVyc1t0aGlzLnRocmVhZC54XVtpXTtcbiAgICAgICAgICAgIGkrKztcbiAgICAgICAgfVxuICAgIH1cbiAgICByZXR1cm4gb3V0cHV0ICsgYmlhc2VzW3RoaXMudGhyZWFkLnhdO1xufVxuZnVuY3Rpb24gcHJlZGljdDNEJDQoaW5wdXRzLCBmaWx0ZXJzLCBiaWFzZXMpIHtcbiAgICBsZXQgb3V0cHV0ID0gMDtcbiAgICBsZXQgaSA9IDA7XG4gICAgZm9yIChsZXQgeiA9IDA7IHogPCB0aGlzLmNvbnN0YW50cy5pbnB1dERlcHRoOyB6KyspIHtcbiAgICAgICAgZm9yIChsZXQgeSA9IDA7IHkgPCB0aGlzLmNvbnN0YW50cy5pbnB1dEhlaWdodDsgeSsrKSB7XG4gICAgICAgICAgICBmb3IgKGxldCB4ID0gMDsgeCA8IHRoaXMuY29uc3RhbnRzLmlucHV0V2lkdGg7IHgrKykge1xuICAgICAgICAgICAgICAgIG91dHB1dCArPSBpbnB1dHNbel1beV1beF0gKiBmaWx0ZXJzW3RoaXMudGhyZWFkLnhdW2ldO1xuICAgICAgICAgICAgICAgIGkrKztcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIH1cbiAgICByZXR1cm4gb3V0cHV0ICsgYmlhc2VzW3RoaXMudGhyZWFkLnhdO1xufVxuZnVuY3Rpb24gY29tcGFyZUlucHV0RGVsdGFzKGlucHV0RGVsdGFzLCBkZWx0YXMsIGZpbHRlcnMpIHtcbiAgICBsZXQgc3VtID0gMDtcbiAgICBjb25zdCBmaWx0ZXJYID0gdGhpcy50aHJlYWQueCArIHRoaXMudGhyZWFkLnkgKiB0aGlzLm91dHB1dC54O1xuICAgIGZvciAobGV0IGZpbHRlclkgPSAwOyBmaWx0ZXJZIDwgdGhpcy5jb25zdGFudHMuZmlsdGVyQ291bnQ7IGZpbHRlclkrKykge1xuICAgICAgICBzdW0gKz0gZmlsdGVyc1tmaWx0ZXJZXVtmaWx0ZXJYXSAqIGRlbHRhc1swXVtmaWx0ZXJZXTtcbiAgICB9XG4gICAgcmV0dXJuIHN1bSArIGlucHV0RGVsdGFzW3RoaXMudGhyZWFkLnldW3RoaXMudGhyZWFkLnhdO1xufVxuZnVuY3Rpb24gY29tcGFyZUlucHV0RGVsdGFzM0QoaW5wdXREZWx0YXMsIGRlbHRhcywgZmlsdGVycykge1xuICAgIGxldCBzdW0gPSAwO1xuICAgIGNvbnN0IGZpbHRlclggPSB0aGlzLnRocmVhZC54ICsgdGhpcy50aHJlYWQueSAqIHRoaXMub3V0cHV0Lng7XG4gICAgZm9yIChsZXQgZmlsdGVyWSA9IDA7IGZpbHRlclkgPCB0aGlzLmNvbnN0YW50cy5maWx0ZXJDb3VudDsgZmlsdGVyWSsrKSB7XG4gICAgICAgIHN1bSArPSBmaWx0ZXJzW2ZpbHRlclldW2ZpbHRlclhdICogZGVsdGFzWzBdW2ZpbHRlclldO1xuICAgIH1cbiAgICByZXR1cm4gc3VtICsgaW5wdXREZWx0YXNbdGhpcy50aHJlYWQuel1bdGhpcy50aHJlYWQueV1bdGhpcy50aHJlYWQueF07XG59XG5mdW5jdGlvbiBjb21wYXJlQmlhc2VzKGJpYXNlcywgZGVsdGFzKSB7XG4gICAgcmV0dXJuIGJpYXNlc1t0aGlzLnRocmVhZC54XSArIGRlbHRhc1t0aGlzLnRocmVhZC55XVt0aGlzLnRocmVhZC54XTtcbn1cbmZ1bmN0aW9uIGNvbXBhcmVGaWx0ZXJEZWx0YXMoZmlsdGVyRGVsdGFzLCBpbnB1dFdlaWdodHMsIGRlbHRhcykge1xuICAgIHJldHVybiAoZmlsdGVyRGVsdGFzW3RoaXMudGhyZWFkLnldW3RoaXMudGhyZWFkLnhdICtcbiAgICAgICAgaW5wdXRXZWlnaHRzW3RoaXMudGhyZWFkLnldW3RoaXMudGhyZWFkLnhdICpcbiAgICAgICAgICAgIGRlbHRhc1t0aGlzLmNvbnN0YW50cy5kZWx0YVldW3RoaXMuY29uc3RhbnRzLmRlbHRhWF0pO1xufVxuZnVuY3Rpb24gY29tcGFyZUZpbHRlckRlbHRhczNEKGZpbHRlckRlbHRhcywgaW5wdXRXZWlnaHRzLCBkZWx0YXMpIHtcbiAgICBjb25zdCBpbnB1dFogPSBNYXRoLmZsb29yKHRoaXMudGhyZWFkLnggLyAodGhpcy5jb25zdGFudHMuaW5wdXRXaWR0aCAqIHRoaXMuY29uc3RhbnRzLmlucHV0SGVpZ2h0KSk7XG4gICAgY29uc3QgaW5wdXRZID0gTWF0aC5mbG9vcigodGhpcy50aHJlYWQueCAtXG4gICAgICAgIGlucHV0WiAqIHRoaXMuY29uc3RhbnRzLmlucHV0V2lkdGggKiB0aGlzLmNvbnN0YW50cy5pbnB1dEhlaWdodCkgL1xuICAgICAgICB0aGlzLmNvbnN0YW50cy5pbnB1dFdpZHRoKTtcbiAgICBjb25zdCBpbnB1dFggPSB0aGlzLnRocmVhZC54IC1cbiAgICAgICAgdGhpcy5jb25zdGFudHMuaW5wdXRXaWR0aCAqIChpbnB1dFkgKyB0aGlzLmNvbnN0YW50cy5pbnB1dEhlaWdodCAqIGlucHV0Wik7XG4gICAgcmV0dXJuIChmaWx0ZXJEZWx0YXNbdGhpcy50aHJlYWQueV1bdGhpcy50aHJlYWQueF0gK1xuICAgICAgICBpbnB1dFdlaWdodHNbaW5wdXRaXVtpbnB1dFldW2lucHV0WF0gKiBkZWx0YXNbMF1bdGhpcy50aHJlYWQueV0pO1xufVxuY2xhc3MgRnVsbHlDb25uZWN0ZWQgZXh0ZW5kcyBGaWx0ZXIge1xuICAgIGNvbnN0cnVjdG9yKHNldHRpbmdzLCBpbnB1dExheWVyKSB7XG4gICAgICAgIHN1cGVyKHNldHRpbmdzLCBpbnB1dExheWVyKTtcbiAgICAgICAgdGhpcy5jb21wYXJlRmlsdGVyRGVsdGFzS2VybmVsID0gbnVsbDtcbiAgICAgICAgdGhpcy5jb21wYXJlSW5wdXREZWx0YXNLZXJuZWwgPSBudWxsO1xuICAgICAgICB0aGlzLmNvbXBhcmVCaWFzZXNLZXJuZWwgPSBudWxsO1xuICAgICAgICB0aGlzLnNldHRpbmdzID0geyAuLi5zZXR0aW5ncyB9O1xuICAgICAgICB0aGlzLnZhbGlkYXRlKCk7XG4gICAgICAgIGNvbnN0IGNvbm5lY3Rpb25Db3VudCA9IGlucHV0TGF5ZXIud2lkdGggKiBpbnB1dExheWVyLmhlaWdodCAqIGlucHV0TGF5ZXIuZGVwdGg7XG4gICAgICAgIHRoaXMuYmlhc2VzID0gdmFsdWVzKHRoaXMuaGVpZ2h0LCB0aGlzLmJpYXMpO1xuICAgICAgICB0aGlzLmJpYXNEZWx0YXMgPSB6ZXJvcyQxKHRoaXMuaGVpZ2h0KTtcbiAgICAgICAgdGhpcy5maWx0ZXJzID0gcmFuZG9zMkQoY29ubmVjdGlvbkNvdW50LCB0aGlzLmhlaWdodCk7XG4gICAgICAgIHRoaXMuZmlsdGVyRGVsdGFzID0gemVyb3MyRChjb25uZWN0aW9uQ291bnQsIHRoaXMuaGVpZ2h0KTtcbiAgICAgICAgaWYgKHRoaXMuZGVwdGggPiAwKSB7XG4gICAgICAgICAgICB0aGlzLndlaWdodHMgPSByYW5kb3MzRCh0aGlzLndpZHRoLCB0aGlzLmhlaWdodCwgdGhpcy5kZXB0aCk7XG4gICAgICAgICAgICB0aGlzLmRlbHRhcyA9IHplcm9zM0QodGhpcy53aWR0aCwgdGhpcy5oZWlnaHQsIHRoaXMuZGVwdGgpO1xuICAgICAgICB9XG4gICAgICAgIGVsc2UgaWYgKHRoaXMuaGVpZ2h0ID4gMCkge1xuICAgICAgICAgICAgdGhpcy53ZWlnaHRzID0gcmFuZG9zMkQodGhpcy53aWR0aCwgdGhpcy5oZWlnaHQpO1xuICAgICAgICAgICAgdGhpcy5kZWx0YXMgPSB6ZXJvczJEKHRoaXMud2lkdGgsIHRoaXMuaGVpZ2h0KTtcbiAgICAgICAgfVxuICAgIH1cbiAgICBnZXQgYmlhcygpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuc2V0dGluZ3MuYmlhcztcbiAgICB9XG4gICAgZ2V0IGJpYXNlcygpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuc2V0dGluZ3MuYmlhc2VzO1xuICAgIH1cbiAgICBzZXQgYmlhc2VzKGJpYXNlcykge1xuICAgICAgICB0aGlzLnNldHRpbmdzLmJpYXNlcyA9IGJpYXNlcztcbiAgICB9XG4gICAgZ2V0IGJpYXNEZWx0YXMoKSB7XG4gICAgICAgIHJldHVybiB0aGlzLnNldHRpbmdzLmJpYXNlcztcbiAgICB9XG4gICAgc2V0IGJpYXNEZWx0YXMoYmlhc0RlbHRhcykge1xuICAgICAgICB0aGlzLnNldHRpbmdzLmJpYXNEZWx0YXMgPSBiaWFzRGVsdGFzO1xuICAgIH1cbiAgICB2YWxpZGF0ZSgpIHtcbiAgICAgICAgc3VwZXIudmFsaWRhdGUoKTtcbiAgICAgICAgaWYgKHRoaXMuZGVwdGggPiAwKVxuICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdkZXB0aCBub3Qgc3VwcG9ydGVkJyk7XG4gICAgfVxuICAgIHNldHVwS2VybmVscygpIHtcbiAgICAgICAgY29uc3QgeyBpbnB1dExheWVyIH0gPSB0aGlzO1xuICAgICAgICBjb25zdCBjb25uZWN0aW9uQ291bnQgPSBpbnB1dExheWVyLndpZHRoICogaW5wdXRMYXllci5oZWlnaHQgKiBpbnB1dExheWVyLmRlcHRoO1xuICAgICAgICBpZiAoaW5wdXRMYXllci5kZXB0aCA+IDApIHtcbiAgICAgICAgICAgIHRoaXMucHJlZGljdEtlcm5lbCA9IG1ha2VLZXJuZWwocHJlZGljdDNEJDQsIHtcbiAgICAgICAgICAgICAgICBvdXRwdXQ6IFt0aGlzLndpZHRoLCB0aGlzLmhlaWdodF0sXG4gICAgICAgICAgICAgICAgY29uc3RhbnRzOiB7XG4gICAgICAgICAgICAgICAgICAgIGlucHV0SGVpZ2h0OiBpbnB1dExheWVyLmhlaWdodCxcbiAgICAgICAgICAgICAgICAgICAgaW5wdXRXaWR0aDogaW5wdXRMYXllci53aWR0aCxcbiAgICAgICAgICAgICAgICAgICAgaW5wdXREZXB0aDogaW5wdXRMYXllci5kZXB0aCxcbiAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICB0aGlzLmNvbXBhcmVGaWx0ZXJEZWx0YXNLZXJuZWwgPSBtYWtlS2VybmVsKGNvbXBhcmVGaWx0ZXJEZWx0YXMzRCwge1xuICAgICAgICAgICAgICAgIG91dHB1dDogW2Nvbm5lY3Rpb25Db3VudCwgdGhpcy5oZWlnaHRdLFxuICAgICAgICAgICAgICAgIGNvbnN0YW50czoge1xuICAgICAgICAgICAgICAgICAgICBpbnB1dFdpZHRoOiBpbnB1dExheWVyLndpZHRoLFxuICAgICAgICAgICAgICAgICAgICBpbnB1dEhlaWdodDogaW5wdXRMYXllci5oZWlnaHQsXG4gICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICBpbW11dGFibGU6IHRydWUsXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIHRoaXMuY29tcGFyZUlucHV0RGVsdGFzS2VybmVsID0gbWFrZUtlcm5lbChjb21wYXJlSW5wdXREZWx0YXMzRCwge1xuICAgICAgICAgICAgICAgIG91dHB1dDogW2lucHV0TGF5ZXIud2lkdGgsIGlucHV0TGF5ZXIuaGVpZ2h0LCBpbnB1dExheWVyLmRlcHRoXSxcbiAgICAgICAgICAgICAgICBjb25zdGFudHM6IHtcbiAgICAgICAgICAgICAgICAgICAgZmlsdGVyQ291bnQ6IHRoaXMuaGVpZ2h0LFxuICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgaW1tdXRhYmxlOiB0cnVlLFxuICAgICAgICAgICAgfSk7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICB0aGlzLnByZWRpY3RLZXJuZWwgPSBtYWtlS2VybmVsKHByZWRpY3QkNCwge1xuICAgICAgICAgICAgICAgIG91dHB1dDogW3RoaXMud2lkdGgsIHRoaXMuaGVpZ2h0XSxcbiAgICAgICAgICAgICAgICBjb25zdGFudHM6IHtcbiAgICAgICAgICAgICAgICAgICAgaW5wdXRIZWlnaHQ6IGlucHV0TGF5ZXIuaGVpZ2h0LFxuICAgICAgICAgICAgICAgICAgICBpbnB1dFdpZHRoOiBpbnB1dExheWVyLndpZHRoLFxuICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIHRoaXMuY29tcGFyZUZpbHRlckRlbHRhc0tlcm5lbCA9IG1ha2VLZXJuZWwoY29tcGFyZUZpbHRlckRlbHRhcywge1xuICAgICAgICAgICAgICAgIG91dHB1dDogW2Nvbm5lY3Rpb25Db3VudCwgdGhpcy5oZWlnaHRdLFxuICAgICAgICAgICAgICAgIGNvbnN0YW50czoge1xuICAgICAgICAgICAgICAgICAgICBpbnB1dFdpZHRoOiBpbnB1dExheWVyLndpZHRoLFxuICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIHRoaXMuY29tcGFyZUlucHV0RGVsdGFzS2VybmVsID0gbWFrZUtlcm5lbChjb21wYXJlSW5wdXREZWx0YXMsIHtcbiAgICAgICAgICAgICAgICBvdXRwdXQ6IFtpbnB1dExheWVyLndpZHRoLCBpbnB1dExheWVyLmhlaWdodF0sXG4gICAgICAgICAgICAgICAgY29uc3RhbnRzOiB7XG4gICAgICAgICAgICAgICAgICAgIGZpbHRlckNvdW50OiB0aGlzLmhlaWdodCxcbiAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgfSk7XG4gICAgICAgIH1cbiAgICAgICAgdGhpcy5jb21wYXJlQmlhc2VzS2VybmVsID0gbWFrZUtlcm5lbChjb21wYXJlQmlhc2VzLCB7XG4gICAgICAgICAgICBvdXRwdXQ6IFt0aGlzLndpZHRoLCB0aGlzLmhlaWdodF0sXG4gICAgICAgIH0pO1xuICAgIH1cbiAgICBwcmVkaWN0KCkge1xuICAgICAgICB0aGlzLndlaWdodHMgPSB0aGlzLnByZWRpY3RLZXJuZWwodGhpcy5pbnB1dExheWVyLndlaWdodHMsIHRoaXMuZmlsdGVycywgdGhpcy5iaWFzZXMpO1xuICAgIH1cbiAgICBjb21wYXJlKCkge1xuICAgICAgICBjb25zdCBpbnB1dExheWVyRGVsdGFzID0gdGhpcy5pbnB1dExheWVyLmRlbHRhcztcbiAgICAgICAgdGhpcy5pbnB1dExheWVyLmRlbHRhcyA9IHRoaXNcbiAgICAgICAgICAgIC5jb21wYXJlSW5wdXREZWx0YXNLZXJuZWwoaW5wdXRMYXllckRlbHRhcywgdGhpcy5kZWx0YXMsIHRoaXMuZmlsdGVycyk7XG4gICAgICAgIHJlbGVhc2UoaW5wdXRMYXllckRlbHRhcyk7XG4gICAgICAgIGNvbnN0IHsgYmlhc0RlbHRhcywgZmlsdGVyRGVsdGFzIH0gPSB0aGlzO1xuICAgICAgICAvLyBUT0RPOiBoYW5kbGUgYmlhc0RlbHRhcyBsZWFyblxuICAgICAgICB0aGlzLmJpYXNEZWx0YXMgPSB0aGlzLmNvbXBhcmVCaWFzZXNLZXJuZWwodGhpcy5iaWFzZXMsIHRoaXMuZGVsdGFzKTtcbiAgICAgICAgLy8gVE9ETzogaGFuZGxlIGZpbHRlckRlbHRhcyBsZWFyblxuICAgICAgICB0aGlzLmZpbHRlckRlbHRhcyA9IHRoaXMuY29tcGFyZUZpbHRlckRlbHRhc0tlcm5lbChmaWx0ZXJEZWx0YXMsIHRoaXMuaW5wdXRMYXllci53ZWlnaHRzLCB0aGlzLmRlbHRhcyk7XG4gICAgICAgIHJlbGVhc2UoYmlhc0RlbHRhcyk7XG4gICAgICAgIHJlbGVhc2UoZmlsdGVyRGVsdGFzKTtcbiAgICB9XG59XG5mdW5jdGlvbiBmdWxseUNvbm5lY3RlZChzZXR0aW5ncywgaW5wdXRMYXllcikge1xuICAgIHJldHVybiBuZXcgRnVsbHlDb25uZWN0ZWQoc2V0dGluZ3MsIGlucHV0TGF5ZXIpO1xufVxuXG5mdW5jdGlvbiBwcmVkaWN0JDMod2VpZ2h0cykge1xuICAgIHJldHVybiAtd2VpZ2h0c1t0aGlzLnRocmVhZC55XVt0aGlzLnRocmVhZC54XTtcbn1cbmNsYXNzIE5lZ2F0aXZlIGV4dGVuZHMgTW9kaWZpZXIge1xuICAgIGNvbnN0cnVjdG9yKGlucHV0TGF5ZXIsIHNldHRpbmdzKSB7XG4gICAgICAgIHN1cGVyKGlucHV0TGF5ZXIsIHNldHRpbmdzKTtcbiAgICAgICAgdGhpcy52YWxpZGF0ZSgpO1xuICAgIH1cbiAgICBzZXR1cEtlcm5lbHMoKSB7XG4gICAgICAgIHRoaXMucHJlZGljdEtlcm5lbCA9IG1ha2VLZXJuZWwocHJlZGljdCQzLCB7XG4gICAgICAgICAgICBvdXRwdXQ6IFt0aGlzLndpZHRoLCB0aGlzLmhlaWdodF0sXG4gICAgICAgIH0pO1xuICAgIH1cbiAgICBwcmVkaWN0KCkge1xuICAgICAgICB0aGlzLndlaWdodHMgPSB0aGlzLnByZWRpY3RLZXJuZWwodGhpcy5pbnB1dExheWVyLndlaWdodHMpO1xuICAgIH1cbn1cbmZ1bmN0aW9uIG5lZ2F0aXZlKGlucHV0TGF5ZXIsIHNldHRpbmdzKSB7XG4gICAgcmV0dXJuIG5ldyBOZWdhdGl2ZShpbnB1dExheWVyLCBzZXR0aW5ncyk7XG59XG5cbmZ1bmN0aW9uIHByZWRpY3QkMihpbnB1dExheWVyV2VpZ2h0czEsIGlucHV0TGF5ZXJXZWlnaHRzMikge1xuICAgIHJldHVybiAoaW5wdXRMYXllcldlaWdodHMxW3RoaXMudGhyZWFkLnldW3RoaXMudGhyZWFkLnhdICpcbiAgICAgICAgaW5wdXRMYXllcldlaWdodHMyW3RoaXMudGhyZWFkLnldW3RoaXMudGhyZWFkLnhdKTtcbn1cbmZ1bmN0aW9uIGNvbXBhcmUkMih3ZWlnaHRzLCBkZWx0YXMpIHtcbiAgICByZXR1cm4gKHdlaWdodHNbdGhpcy50aHJlYWQueV1bdGhpcy50aHJlYWQueF0gKiBkZWx0YXNbdGhpcy50aHJlYWQueV1bdGhpcy50aHJlYWQueF0pO1xufVxuY2xhc3MgTXVsdGlwbHlFbGVtZW50IGV4dGVuZHMgT3BlcmF0b3Ige1xuICAgIGdldCB3aWR0aCgpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuaW5wdXRMYXllcjEud2lkdGg7XG4gICAgfVxuICAgIGdldCBoZWlnaHQoKSB7XG4gICAgICAgIHJldHVybiB0aGlzLmlucHV0TGF5ZXIxLmhlaWdodDtcbiAgICB9XG4gICAgZ2V0IGRlcHRoKCkge1xuICAgICAgICByZXR1cm4gdGhpcy5pbnB1dExheWVyMS5kZXB0aDtcbiAgICB9XG4gICAgdmFsaWRhdGUoKSB7XG4gICAgICAgIHN1cGVyLnZhbGlkYXRlKCk7XG4gICAgICAgIGNoZWNrU2FtZVNpemUodGhpcy5pbnB1dExheWVyMSwgdGhpcy5pbnB1dExheWVyMik7XG4gICAgfVxuICAgIHNldHVwS2VybmVscygpIHtcbiAgICAgICAgdGhpcy5wcmVkaWN0S2VybmVsID0gbWFrZUtlcm5lbChwcmVkaWN0JDIsIHtcbiAgICAgICAgICAgIG91dHB1dDogW3RoaXMud2lkdGgsIHRoaXMuaGVpZ2h0XSxcbiAgICAgICAgICAgIGltbXV0YWJsZTogdHJ1ZSxcbiAgICAgICAgfSk7XG4gICAgICAgIHRoaXMuY29tcGFyZUtlcm5lbCA9IG1ha2VLZXJuZWwoY29tcGFyZSQyLCB7XG4gICAgICAgICAgICBvdXRwdXQ6IFt0aGlzLndpZHRoLCB0aGlzLmhlaWdodF0sXG4gICAgICAgICAgICBpbW11dGFibGU6IHRydWUsXG4gICAgICAgIH0pO1xuICAgIH1cbiAgICBwcmVkaWN0KCkge1xuICAgICAgICByZWxlYXNlKHRoaXMud2VpZ2h0cyk7XG4gICAgICAgIHRoaXMud2VpZ2h0cyA9IHRoaXMucHJlZGljdEtlcm5lbCh0aGlzLmlucHV0TGF5ZXIxLndlaWdodHMsIHRoaXMuaW5wdXRMYXllcjIud2VpZ2h0cyk7XG4gICAgICAgIGNsZWFyKHRoaXMuZGVsdGFzKTtcbiAgICB9XG4gICAgY29tcGFyZSgpIHtcbiAgICAgICAgcmVsZWFzZSh0aGlzLmlucHV0TGF5ZXIxLmRlbHRhcyk7XG4gICAgICAgIHJlbGVhc2UodGhpcy5pbnB1dExheWVyMi5kZWx0YXMpO1xuICAgICAgICB0aGlzLmlucHV0TGF5ZXIxLmRlbHRhcyA9IHRoaXMuY29tcGFyZUtlcm5lbCh0aGlzLmlucHV0TGF5ZXIyLndlaWdodHMsIHRoaXMuZGVsdGFzKTtcbiAgICAgICAgdGhpcy5pbnB1dExheWVyMi5kZWx0YXMgPSB0aGlzLmNvbXBhcmVLZXJuZWwodGhpcy5pbnB1dExheWVyMS53ZWlnaHRzLCB0aGlzLmRlbHRhcyk7XG4gICAgfVxufVxuZnVuY3Rpb24gbXVsdGlwbHlFbGVtZW50JDEoaW5wdXRMYXllcjEsIGlucHV0TGF5ZXIyLCBzZXR0aW5ncykge1xuICAgIHJldHVybiBuZXcgTXVsdGlwbHlFbGVtZW50KGlucHV0TGF5ZXIxLCBpbnB1dExheWVyMiwgc2V0dGluZ3MpO1xufVxuXG5mdW5jdGlvbiBvbmVzJDEoc2l6ZSkge1xuICAgIHJldHVybiBuZXcgRmxvYXQzMkFycmF5KHNpemUpLmZpbGwoMSk7XG59XG5mdW5jdGlvbiBvbmVzMkQod2lkdGgsIGhlaWdodCkge1xuICAgIGNvbnN0IHJlc3VsdCA9IG5ldyBBcnJheShoZWlnaHQpO1xuICAgIGZvciAobGV0IHkgPSAwOyB5IDwgaGVpZ2h0OyB5KyspIHtcbiAgICAgICAgcmVzdWx0W3ldID0gb25lcyQxKHdpZHRoKTtcbiAgICB9XG4gICAgcmV0dXJuIHJlc3VsdDtcbn1cblxuY2xhc3MgT25lcyBleHRlbmRzIE1vZGVsIHtcbiAgICBjb25zdHJ1Y3RvcihzZXR0aW5ncykge1xuICAgICAgICBzdXBlcihzZXR0aW5ncyk7XG4gICAgICAgIHRoaXMudmFsaWRhdGUoKTtcbiAgICAgICAgdGhpcy53ZWlnaHRzID0gb25lczJEKHRoaXMud2lkdGgsIHRoaXMuaGVpZ2h0KTtcbiAgICAgICAgdGhpcy5kZWx0YXMgPSB6ZXJvczJEKHRoaXMud2lkdGgsIHRoaXMuaGVpZ2h0KTtcbiAgICB9XG59XG5mdW5jdGlvbiBvbmVzKHNldHRpbmdzKSB7XG4gICAgcmV0dXJuIG5ldyBPbmVzKHNldHRpbmdzKTtcbn1cblxuZnVuY3Rpb24gcHJlZGljdDJEJDMoaW5wdXRzKSB7XG4gICAgcmV0dXJuIGFjdGl2YXRlJDEoaW5wdXRzW3RoaXMudGhyZWFkLnldW3RoaXMudGhyZWFkLnhdKTtcbn1cbmZ1bmN0aW9uIHByZWRpY3QzRCQzKGlucHV0cykge1xuICAgIHJldHVybiBhY3RpdmF0ZSQxKGlucHV0c1t0aGlzLnRocmVhZC56XVt0aGlzLnRocmVhZC55XVt0aGlzLnRocmVhZC54XSk7XG59XG5mdW5jdGlvbiBjb21wYXJlMkQkMyh3ZWlnaHRzLCBlcnJvcnMpIHtcbiAgICByZXR1cm4gbWVhc3VyZSQxKHdlaWdodHNbdGhpcy50aHJlYWQueV1bdGhpcy50aHJlYWQueF0sIGVycm9yc1t0aGlzLnRocmVhZC55XVt0aGlzLnRocmVhZC54XSk7XG59XG5mdW5jdGlvbiBjb21wYXJlM0QkMyh3ZWlnaHRzLCBlcnJvcnMpIHtcbiAgICByZXR1cm4gbWVhc3VyZSQxKHdlaWdodHNbdGhpcy50aHJlYWQuel1bdGhpcy50aHJlYWQueV1bdGhpcy50aHJlYWQueF0sIGVycm9yc1t0aGlzLnRocmVhZC56XVt0aGlzLnRocmVhZC55XVt0aGlzLnRocmVhZC54XSk7XG59XG5jbGFzcyBUYW5oIGV4dGVuZHMgQWN0aXZhdGlvbiB7XG4gICAgc2V0dXBLZXJuZWxzKCkge1xuICAgICAgICBpZiAodGhpcy5kZXB0aCA+IDApIHtcbiAgICAgICAgICAgIHRoaXMucHJlZGljdEtlcm5lbCA9IG1ha2VLZXJuZWwocHJlZGljdDNEJDMsIHtcbiAgICAgICAgICAgICAgICBvdXRwdXQ6IFt0aGlzLndpZHRoLCB0aGlzLmhlaWdodCwgdGhpcy5kZXB0aF0sXG4gICAgICAgICAgICAgICAgZnVuY3Rpb25zOiBbYWN0aXZhdGUkMV0sXG4gICAgICAgICAgICAgICAgaW1tdXRhYmxlOiB0cnVlLFxuICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICB0aGlzLmNvbXBhcmVLZXJuZWwgPSBtYWtlS2VybmVsKGNvbXBhcmUzRCQzLCB7XG4gICAgICAgICAgICAgICAgb3V0cHV0OiBbdGhpcy53aWR0aCwgdGhpcy5oZWlnaHQsIHRoaXMuZGVwdGhdLFxuICAgICAgICAgICAgICAgIGZ1bmN0aW9uczogW21lYXN1cmUkMV0sXG4gICAgICAgICAgICAgICAgaW1tdXRhYmxlOiB0cnVlLFxuICAgICAgICAgICAgfSk7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICB0aGlzLnByZWRpY3RLZXJuZWwgPSBtYWtlS2VybmVsKHByZWRpY3QyRCQzLCB7XG4gICAgICAgICAgICAgICAgb3V0cHV0OiBbdGhpcy53aWR0aCwgdGhpcy5oZWlnaHRdLFxuICAgICAgICAgICAgICAgIGZ1bmN0aW9uczogW2FjdGl2YXRlJDFdLFxuICAgICAgICAgICAgICAgIGltbXV0YWJsZTogdHJ1ZSxcbiAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgdGhpcy5jb21wYXJlS2VybmVsID0gbWFrZUtlcm5lbChjb21wYXJlMkQkMywge1xuICAgICAgICAgICAgICAgIG91dHB1dDogW3RoaXMud2lkdGgsIHRoaXMuaGVpZ2h0XSxcbiAgICAgICAgICAgICAgICBmdW5jdGlvbnM6IFttZWFzdXJlJDFdLFxuICAgICAgICAgICAgICAgIGltbXV0YWJsZTogdHJ1ZSxcbiAgICAgICAgICAgIH0pO1xuICAgICAgICB9XG4gICAgfVxuICAgIHByZWRpY3QoKSB7XG4gICAgICAgIHJlbGVhc2UodGhpcy53ZWlnaHRzKTtcbiAgICAgICAgdGhpcy53ZWlnaHRzID0gdGhpcy5wcmVkaWN0S2VybmVsKHRoaXMuaW5wdXRMYXllci53ZWlnaHRzKTtcbiAgICAgICAgY2xlYXIodGhpcy5kZWx0YXMpO1xuICAgIH1cbiAgICBjb21wYXJlKCkge1xuICAgICAgICByZWxlYXNlKHRoaXMuaW5wdXRMYXllci5kZWx0YXMpO1xuICAgICAgICB0aGlzLmlucHV0TGF5ZXIuZGVsdGFzID0gdGhpcy5jb21wYXJlS2VybmVsKHRoaXMud2VpZ2h0cywgdGhpcy5kZWx0YXMpO1xuICAgIH1cbn1cbmZ1bmN0aW9uIHRhbmgkMShpbnB1dExheWVyLCBzZXR0aW5ncykge1xuICAgIHJldHVybiBuZXcgVGFuaChpbnB1dExheWVyLCBzZXR0aW5ncyk7XG59XG5cbmNsYXNzIFplcm9zIGV4dGVuZHMgTW9kZWwge1xuICAgIGNvbnN0cnVjdG9yKHNldHRpbmdzKSB7XG4gICAgICAgIHN1cGVyKHNldHRpbmdzKTtcbiAgICAgICAgdGhpcy52YWxpZGF0ZSgpO1xuICAgICAgICB0aGlzLndlaWdodHMgPSB6ZXJvczJEKHRoaXMud2lkdGgsIHRoaXMuaGVpZ2h0KTtcbiAgICAgICAgdGhpcy5kZWx0YXMgPSB6ZXJvczJEKHRoaXMud2lkdGgsIHRoaXMuaGVpZ2h0KTtcbiAgICB9XG4gICAgcHJlZGljdCgpIHtcbiAgICAgICAgLy8gdGhyb3cgbmV3IEVycm9yKGAke3RoaXMuY29uc3RydWN0b3IubmFtZX0tcHJlZGljdCBpcyBub3QgeWV0IGltcGxlbWVudGVkYClcbiAgICB9XG4gICAgY29tcGFyZSgpIHtcbiAgICAgICAgLy8gdGhyb3cgbmV3IEVycm9yKGAke3RoaXMuY29uc3RydWN0b3IubmFtZX0tY29tcGFyZSBpcyBub3QgeWV0IGltcGxlbWVudGVkYClcbiAgICB9XG59XG5mdW5jdGlvbiB6ZXJvcyhzZXR0aW5ncykge1xuICAgIHJldHVybiBuZXcgWmVyb3Moc2V0dGluZ3MpO1xufVxuXG5mdW5jdGlvbiBncnUoc2V0dGluZ3MsIHJlY3VycmVudElucHV0LCBpbnB1dCkge1xuICAgIGNvbnN0IHsgaGVpZ2h0IH0gPSBzZXR0aW5ncztcbiAgICBjb25zdCB1cGRhdGVHYXRlV2VpZ2h0cyA9IHJhbmRvbSh7IGhlaWdodCwgd2lkdGg6IGlucHV0LmhlaWdodCB9KTtcbiAgICBjb25zdCB1cGRhdGVHYXRlUGVlcGhvbGVzID0gcmFuZG9tKHsgd2lkdGg6IGhlaWdodCwgaGVpZ2h0IH0pO1xuICAgIGNvbnN0IHVwZGF0ZUdhdGVCaWFzID0gemVyb3MoeyBoZWlnaHQgfSk7XG4gICAgY29uc3QgdXBkYXRlR2F0ZSA9IHNpZ21vaWQkMShhZGQkMShhZGQkMShtdWx0aXBseSQxKHVwZGF0ZUdhdGVXZWlnaHRzLCBpbnB1dCksIG11bHRpcGx5JDEodXBkYXRlR2F0ZVBlZXBob2xlcywgcmVjdXJyZW50SW5wdXQpKSwgdXBkYXRlR2F0ZUJpYXMpKTtcbiAgICBjb25zdCByZXNldEdhdGVXZWlnaHRzID0gcmFuZG9tKHsgaGVpZ2h0LCB3aWR0aDogaW5wdXQuaGVpZ2h0IH0pO1xuICAgIGNvbnN0IHJlc2V0R2F0ZVBlZXBob2xlcyA9IHJhbmRvbSh7IHdpZHRoOiBoZWlnaHQsIGhlaWdodCB9KTtcbiAgICBjb25zdCByZXNldEdhdGVCaWFzID0gemVyb3MoeyBoZWlnaHQgfSk7XG4gICAgY29uc3QgcmVzZXRHYXRlID0gc2lnbW9pZCQxKGFkZCQxKGFkZCQxKG11bHRpcGx5JDEocmVzZXRHYXRlV2VpZ2h0cywgaW5wdXQpLCBtdWx0aXBseSQxKHJlc2V0R2F0ZVBlZXBob2xlcywgcmVjdXJyZW50SW5wdXQpKSwgcmVzZXRHYXRlQmlhcykpO1xuICAgIGNvbnN0IGNlbGxXZWlnaHRzID0gcmFuZG9tKHsgaGVpZ2h0LCB3aWR0aDogaW5wdXQuaGVpZ2h0IH0pO1xuICAgIGNvbnN0IGNlbGxQZWVwaG9sZXMgPSByYW5kb20oeyB3aWR0aDogaGVpZ2h0LCBoZWlnaHQgfSk7XG4gICAgY29uc3QgY2VsbEJpYXMgPSB6ZXJvcyh7IGhlaWdodCB9KTtcbiAgICBjb25zdCBjZWxsID0gdGFuaCQxKGFkZCQxKGFkZCQxKG11bHRpcGx5JDEoY2VsbFdlaWdodHMsIGlucHV0KSwgbXVsdGlwbHkkMShjZWxsUGVlcGhvbGVzLCBtdWx0aXBseUVsZW1lbnQkMShyZXNldEdhdGUsIHJlY3VycmVudElucHV0KSkpLCBjZWxsQmlhcykpO1xuICAgIC8vIGNvbXB1dGUgaGlkZGVuIHN0YXRlIGFzIGdhdGVkLCBzYXR1cmF0ZWQgY2VsbCBhY3RpdmF0aW9uc1xuICAgIC8vIG5lZ2F0ZSB1cGRhdGVHYXRlXG4gICAgcmV0dXJuIGFkZCQxKG11bHRpcGx5RWxlbWVudCQxKGFkZCQxKG9uZXMoeyB3aWR0aDogdXBkYXRlR2F0ZS53aWR0aCwgaGVpZ2h0OiB1cGRhdGVHYXRlLmhlaWdodCB9KSwgbmVnYXRpdmUodXBkYXRlR2F0ZSkpLCBjZWxsKSwgbXVsdGlwbHlFbGVtZW50JDEocmVjdXJyZW50SW5wdXQsIHVwZGF0ZUdhdGUpKTtcbn1cblxuY29uc3QgZGVmYXVsdHMkNSA9IHtcbiAgICB3ZWlnaHRzOiBudWxsLFxufTtcbmNsYXNzIElucHV0IGV4dGVuZHMgRW50cnlQb2ludCB7XG4gICAgY29uc3RydWN0b3Ioc2V0dGluZ3MpIHtcbiAgICAgICAgc3VwZXIoeyAuLi5kZWZhdWx0cyQ1LCAuLi5zZXR0aW5ncyB9KTtcbiAgICAgICAgdGhpcy5yZXNoYXBlSW5wdXQgPSBudWxsO1xuICAgICAgICB0aGlzLnZhbGlkYXRlKCk7XG4gICAgICAgIHRoaXMucmVzaGFwZUlucHV0ID0gbnVsbDtcbiAgICAgICAgdGhpcy5kZWx0YXMgPSB6ZXJvczJEKHRoaXMud2lkdGgsIHRoaXMuaGVpZ2h0KTtcbiAgICB9XG4gICAgc2V0dXBLZXJuZWxzKCkge1xuICAgICAgICBpZiAodGhpcy53aWR0aCA9PT0gMSkge1xuICAgICAgICAgICAgdGhpcy5wcmVkaWN0ID0gdGhpcy5wcmVkaWN0MUQ7XG4gICAgICAgICAgICB0aGlzLnJlc2hhcGVJbnB1dCA9IG1ha2VLZXJuZWwoZnVuY3Rpb24gKHZhbHVlKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIHZhbHVlW3RoaXMudGhyZWFkLnldO1xuICAgICAgICAgICAgfSwge1xuICAgICAgICAgICAgICAgIG91dHB1dDogWzEsIHRoaXMuaGVpZ2h0XSxcbiAgICAgICAgICAgICAgICBpbW11dGFibGU6IHRydWUsXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgfVxuICAgIH1cbiAgICByZXVzZUtlcm5lbHMobGF5ZXIpIHtcbiAgICAgICAgLy8gc3VwZXIucmV1c2VLZXJuZWxzKGxheWVyKTtcbiAgICAgICAgdGhpcy5yZXNoYXBlSW5wdXQgPSBsYXllci5yZXNoYXBlSW5wdXQ7XG4gICAgfVxuICAgIHByZWRpY3QoaW5wdXRzKSB7XG4gICAgICAgIGlmICgoQXJyYXkuaXNBcnJheShpbnB1dHMpIHx8IGlucHV0cyBpbnN0YW5jZW9mIEZsb2F0MzJBcnJheSkgJiZcbiAgICAgICAgICAgIHR5cGVvZiBpbnB1dHNbMF0gPT09ICdudW1iZXInICYmXG4gICAgICAgICAgICBpbnB1dHMubGVuZ3RoID09PSB0aGlzLmhlaWdodCAqIHRoaXMud2lkdGgpIHtcbiAgICAgICAgICAgIHJlbGVhc2UodGhpcy53ZWlnaHRzKTtcbiAgICAgICAgICAgIHRoaXMud2VpZ2h0cyA9IGtlcm5lbElucHV0KGlucHV0cywgW3RoaXMud2lkdGgsIHRoaXMuaGVpZ2h0XSk7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSBpZiAoQXJyYXkuaXNBcnJheShpbnB1dHMpICYmXG4gICAgICAgICAgICBpbnB1dHMubGVuZ3RoID09PSB0aGlzLmhlaWdodCAmJlxuICAgICAgICAgICAgKEFycmF5LmlzQXJyYXkoaW5wdXRzWzBdKSB8fCBpbnB1dHNbMF0gaW5zdGFuY2VvZiBGbG9hdDMyQXJyYXkpICYmXG4gICAgICAgICAgICBpbnB1dHNbMF0ubGVuZ3RoID09PSB0aGlzLndpZHRoKSB7XG4gICAgICAgICAgICB0aGlzLndlaWdodHMgPSBjbG9uZShpbnB1dHMpO1xuICAgICAgICB9XG4gICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdJbnB1dHMgYXJlIG5vdCBvZiBzaXplZCBjb3JyZWN0bHknKTtcbiAgICAgICAgfVxuICAgICAgICBjbGVhcih0aGlzLmRlbHRhcyk7XG4gICAgfVxuICAgIHByZWRpY3QxRChpbnB1dHMpIHtcbiAgICAgICAgaWYgKHRoaXMud2VpZ2h0cylcbiAgICAgICAgICAgIHJlbGVhc2UodGhpcy53ZWlnaHRzKTtcbiAgICAgICAgaWYgKHRoaXMucmVzaGFwZUlucHV0KSB7XG4gICAgICAgICAgICB0aGlzLndlaWdodHMgPSB0aGlzLnJlc2hhcGVJbnB1dChpbnB1dHMpO1xuICAgICAgICB9XG4gICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgdGhpcy53ZWlnaHRzID0gaW5wdXRzO1xuICAgICAgICB9XG4gICAgICAgIGNsZWFyKHRoaXMuZGVsdGFzKTtcbiAgICB9XG4gICAgY29tcGFyZSgpIHtcbiAgICAgICAgLy8gdGhyb3cgbmV3IEVycm9yKGAke3RoaXMuY29uc3RydWN0b3IubmFtZX0tY29tcGFyZSBpcyBub3QgeWV0IGltcGxlbWVudGVkYClcbiAgICB9XG59XG5mdW5jdGlvbiBpbnB1dChzZXR0aW5ncykge1xuICAgIHJldHVybiBuZXcgSW5wdXQoc2V0dGluZ3MpO1xufVxuXG5mdW5jdGlvbiBwcmVkaWN0MkQkMihpbnB1dHMpIHtcbiAgICByZXR1cm4gYWN0aXZhdGUoaW5wdXRzW3RoaXMudGhyZWFkLnldW3RoaXMudGhyZWFkLnhdKTtcbn1cbmZ1bmN0aW9uIHByZWRpY3QzRCQyKGlucHV0cykge1xuICAgIHJldHVybiBhY3RpdmF0ZShpbnB1dHNbdGhpcy50aHJlYWQuel1bdGhpcy50aHJlYWQueV1bdGhpcy50aHJlYWQueF0pO1xufVxuZnVuY3Rpb24gY29tcGFyZTJEJDIod2VpZ2h0cywgZGVsdGFzKSB7XG4gICAgcmV0dXJuIG1lYXN1cmUod2VpZ2h0c1t0aGlzLnRocmVhZC55XVt0aGlzLnRocmVhZC54XSwgZGVsdGFzW3RoaXMudGhyZWFkLnldW3RoaXMudGhyZWFkLnhdKTtcbn1cbmZ1bmN0aW9uIGNvbXBhcmUzRCQyKHdlaWdodHMsIGRlbHRhcykge1xuICAgIHJldHVybiBtZWFzdXJlKHdlaWdodHNbdGhpcy50aHJlYWQuel1bdGhpcy50aHJlYWQueV1bdGhpcy50aHJlYWQueF0sIGRlbHRhc1t0aGlzLnRocmVhZC56XVt0aGlzLnRocmVhZC55XVt0aGlzLnRocmVhZC54XSk7XG59XG5jbGFzcyBMZWFreVJlbHUgZXh0ZW5kcyBBY3RpdmF0aW9uIHtcbiAgICBzZXR1cEtlcm5lbHMoKSB7XG4gICAgICAgIGNvbnN0IHsgd2lkdGgsIGhlaWdodCwgZGVwdGggfSA9IHRoaXMuaW5wdXRMYXllcjtcbiAgICAgICAgaWYgKHRoaXMuZGVwdGggPiAwKSB7XG4gICAgICAgICAgICB0aGlzLnByZWRpY3RLZXJuZWwgPSBtYWtlS2VybmVsKHByZWRpY3QzRCQyLCB7XG4gICAgICAgICAgICAgICAgb3V0cHV0OiBbd2lkdGgsIGhlaWdodCwgZGVwdGhdLFxuICAgICAgICAgICAgICAgIGZ1bmN0aW9uczogW2FjdGl2YXRlXSxcbiAgICAgICAgICAgICAgICBpbW11dGFibGU6IHRydWUsXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIHRoaXMuY29tcGFyZUtlcm5lbCA9IG1ha2VLZXJuZWwoY29tcGFyZTNEJDIsIHtcbiAgICAgICAgICAgICAgICBvdXRwdXQ6IFt3aWR0aCwgaGVpZ2h0LCBkZXB0aF0sXG4gICAgICAgICAgICAgICAgZnVuY3Rpb25zOiBbbWVhc3VyZV0sXG4gICAgICAgICAgICAgICAgaW1tdXRhYmxlOiB0cnVlLFxuICAgICAgICAgICAgfSk7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICB0aGlzLnByZWRpY3RLZXJuZWwgPSBtYWtlS2VybmVsKHByZWRpY3QyRCQyLCB7XG4gICAgICAgICAgICAgICAgb3V0cHV0OiBbd2lkdGgsIGhlaWdodF0sXG4gICAgICAgICAgICAgICAgZnVuY3Rpb25zOiBbYWN0aXZhdGVdLFxuICAgICAgICAgICAgICAgIGltbXV0YWJsZTogdHJ1ZSxcbiAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgdGhpcy5jb21wYXJlS2VybmVsID0gbWFrZUtlcm5lbChjb21wYXJlMkQkMiwge1xuICAgICAgICAgICAgICAgIG91dHB1dDogW3dpZHRoLCBoZWlnaHRdLFxuICAgICAgICAgICAgICAgIGZ1bmN0aW9uczogW21lYXN1cmVdLFxuICAgICAgICAgICAgICAgIGltbXV0YWJsZTogdHJ1ZSxcbiAgICAgICAgICAgIH0pO1xuICAgICAgICB9XG4gICAgfVxuICAgIHByZWRpY3QoKSB7XG4gICAgICAgIHJlbGVhc2UodGhpcy53ZWlnaHRzKTtcbiAgICAgICAgdGhpcy53ZWlnaHRzID0gdGhpcy5wcmVkaWN0S2VybmVsKHRoaXMuaW5wdXRMYXllci53ZWlnaHRzKTtcbiAgICAgICAgY2xlYXIodGhpcy5kZWx0YXMpO1xuICAgIH1cbiAgICBjb21wYXJlKCkge1xuICAgICAgICBjb25zdCB7IGRlbHRhcyB9ID0gdGhpcztcbiAgICAgICAgdGhpcy5kZWx0YXMgPSB0aGlzLmNvbXBhcmVLZXJuZWwodGhpcy53ZWlnaHRzLCBkZWx0YXMpO1xuICAgICAgICByZWxlYXNlKGRlbHRhcyk7XG4gICAgfVxufVxuZnVuY3Rpb24gbGVha3lSZWx1KGlucHV0TGF5ZXIsIHNldHRpbmdzKSB7XG4gICAgcmV0dXJuIG5ldyBMZWFreVJlbHUoaW5wdXRMYXllciwgc2V0dGluZ3MpO1xufVxuXG5mdW5jdGlvbiBsc3RtQ2VsbChzZXR0aW5ncywgaW5wdXQsIHJlY3VycmVudElucHV0KSB7XG4gICAgY29uc3QgeyBoZWlnaHQgfSA9IHNldHRpbmdzO1xuICAgIGlmICh0eXBlb2YgaGVpZ2h0ICE9PSAnbnVtYmVyJykge1xuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ25vIHNldHRpbmdzLmhlaWdodCBnaXZlbicpO1xuICAgIH1cbiAgICBpZiAocmVjdXJyZW50SW5wdXQuc2V0RGltZW5zaW9ucykge1xuICAgICAgICByZWN1cnJlbnRJbnB1dC5zZXREaW1lbnNpb25zKDEsIGhlaWdodCk7XG4gICAgfVxuICAgIGNvbnN0IGlucHV0R2F0ZVdlaWdodHMgPSByYW5kb20oe1xuICAgICAgICBoZWlnaHQsXG4gICAgICAgIHdpZHRoOiBpbnB1dC5oZWlnaHQsXG4gICAgICAgIHN0ZDogMC4wOCxcbiAgICAgICAgaWQ6ICdpbnB1dEdhdGVXZWlnaHRzJyxcbiAgICB9KTtcbiAgICBjb25zdCBpbnB1dEdhdGVQZWVwaG9sZXMgPSByYW5kb20oe1xuICAgICAgICB3aWR0aDogaGVpZ2h0LFxuICAgICAgICBoZWlnaHQsXG4gICAgICAgIHN0ZDogMC4wOCxcbiAgICAgICAgaWQ6ICdpbnB1dEdhdGVQZWVwaG9sZXMnLFxuICAgIH0pO1xuICAgIGNvbnN0IGlucHV0R2F0ZUJpYXMgPSB6ZXJvcyh7IGhlaWdodCwgaWQ6ICdpbnB1dEdhdGVCaWFzJyB9KTtcbiAgICBjb25zdCBpbnB1dEdhdGUgPSBzaWdtb2lkJDEoYWRkJDEoYWRkJDEobXVsdGlwbHkkMShpbnB1dEdhdGVXZWlnaHRzLCBpbnB1dCksIG11bHRpcGx5JDEoaW5wdXRHYXRlUGVlcGhvbGVzLCByZWN1cnJlbnRJbnB1dCkpLCBpbnB1dEdhdGVCaWFzKSwgeyBpZDogJ2lucHV0R2F0ZScgfSk7XG4gICAgY29uc3QgZm9yZ2V0R2F0ZVdlaWdodHMgPSByYW5kb20oe1xuICAgICAgICBoZWlnaHQsXG4gICAgICAgIHdpZHRoOiBpbnB1dC5oZWlnaHQsXG4gICAgICAgIHN0ZDogMC4wOCxcbiAgICAgICAgaWQ6ICdmb3JnZXRHYXRlV2VpZ2h0cycsXG4gICAgfSk7XG4gICAgY29uc3QgZm9yZ2V0R2F0ZVBlZXBob2xlcyA9IHJhbmRvbSh7XG4gICAgICAgIHdpZHRoOiBoZWlnaHQsXG4gICAgICAgIGhlaWdodCxcbiAgICAgICAgc3RkOiAwLjA4LFxuICAgICAgICBpZDogJ2ZvcmdldEdhdGVQZWVwaG9sZXMnLFxuICAgIH0pO1xuICAgIGNvbnN0IGZvcmdldEdhdGVCaWFzID0gemVyb3MoeyBoZWlnaHQsIGlkOiAnZm9yZ2V0R2F0ZUJpYXMnIH0pO1xuICAgIGNvbnN0IGZvcmdldEdhdGUgPSBzaWdtb2lkJDEoYWRkJDEoYWRkJDEobXVsdGlwbHkkMShmb3JnZXRHYXRlV2VpZ2h0cywgaW5wdXQpLCBtdWx0aXBseSQxKGZvcmdldEdhdGVQZWVwaG9sZXMsIHJlY3VycmVudElucHV0KSksIGZvcmdldEdhdGVCaWFzKSwgeyBpZDogJ2ZvcmdldEdhdGUnIH0pO1xuICAgIGNvbnN0IG91dHB1dEdhdGVXZWlnaHRzID0gcmFuZG9tKHtcbiAgICAgICAgaGVpZ2h0LFxuICAgICAgICB3aWR0aDogaW5wdXQuaGVpZ2h0LFxuICAgICAgICBzdGQ6IDAuMDgsXG4gICAgICAgIGlkOiAnb3V0cHV0R2F0ZVdlaWdodHMnLFxuICAgIH0pO1xuICAgIGNvbnN0IG91dHB1dEdhdGVQZWVwaG9sZXMgPSByYW5kb20oe1xuICAgICAgICB3aWR0aDogaGVpZ2h0LFxuICAgICAgICBoZWlnaHQsXG4gICAgICAgIHN0ZDogMC4wOCxcbiAgICAgICAgaWQ6ICdvdXRwdXRHYXRlUGVlcGhvbGVzJyxcbiAgICB9KTtcbiAgICBjb25zdCBvdXRwdXRHYXRlQmlhcyA9IHplcm9zKHsgaGVpZ2h0LCBpZDogJ291dHB1dEdhdGVCaWFzJyB9KTtcbiAgICBjb25zdCBvdXRwdXRHYXRlID0gc2lnbW9pZCQxKGFkZCQxKGFkZCQxKG11bHRpcGx5JDEob3V0cHV0R2F0ZVdlaWdodHMsIGlucHV0KSwgbXVsdGlwbHkkMShvdXRwdXRHYXRlUGVlcGhvbGVzLCByZWN1cnJlbnRJbnB1dCkpLCBvdXRwdXRHYXRlQmlhcyksIHsgaWQ6ICdvdXRwdXRHYXRlJyB9KTtcbiAgICBjb25zdCBtZW1vcnlXZWlnaHRzID0gcmFuZG9tKHtcbiAgICAgICAgaGVpZ2h0LFxuICAgICAgICB3aWR0aDogaW5wdXQuaGVpZ2h0LFxuICAgICAgICBzdGQ6IDAuMDgsXG4gICAgICAgIGlkOiAnbWVtb3J5V2VpZ2h0cycsXG4gICAgfSk7XG4gICAgY29uc3QgbWVtb3J5UGVlcGhvbGVzID0gcmFuZG9tKHtcbiAgICAgICAgd2lkdGg6IGhlaWdodCxcbiAgICAgICAgaGVpZ2h0LFxuICAgICAgICBzdGQ6IDAuMDgsXG4gICAgICAgIGlkOiAnbWVtb3J5UGVlcGhvbGVzJyxcbiAgICB9KTtcbiAgICBjb25zdCBtZW1vcnlCaWFzID0gemVyb3MoeyBoZWlnaHQsIGlkOiAnbWVtb3J5QmlhcycgfSk7XG4gICAgY29uc3QgbWVtb3J5ID0gdGFuaCQxKGFkZCQxKGFkZCQxKG11bHRpcGx5JDEobWVtb3J5V2VpZ2h0cywgaW5wdXQpLCBtdWx0aXBseSQxKG1lbW9yeVBlZXBob2xlcywgcmVjdXJyZW50SW5wdXQpKSwgbWVtb3J5QmlhcyksIHsgaWQ6ICdtZW1vcnknIH0pO1xuICAgIC8vIGNvbXB1dGUgbmV3IGNlbGwgYWN0aXZhdGlvblxuICAgIGNvbnN0IHJldGFpbkNlbGwgPSBtdWx0aXBseUVsZW1lbnQkMShmb3JnZXRHYXRlLCByZWN1cnJlbnRJbnB1dCwge1xuICAgICAgICBpZDogJ3JldGFpbkNlbGwnLFxuICAgIH0pOyAvLyB3aGF0IGRvIHdlIGtlZXAgZnJvbSBjZWxsXG4gICAgY29uc3Qgd3JpdGVDZWxsID0gbXVsdGlwbHlFbGVtZW50JDEoaW5wdXRHYXRlLCBtZW1vcnksIHsgaWQ6ICd3cml0ZUNlbGwnIH0pOyAvLyB3aGF0IGRvIHdlIHdyaXRlIHRvIGNlbGxcbiAgICBjb25zdCBjZWxsID0gYWRkJDEocmV0YWluQ2VsbCwgd3JpdGVDZWxsLCB7IGlkOiAnY2VsbCcgfSk7IC8vIG5ldyBjZWxsIGNvbnRlbnRzXG4gICAgLy8gY29tcHV0ZSBoaWRkZW4gc3RhdGUgYXMgZ2F0ZWQsIHNhdHVyYXRlZCBjZWxsIGFjdGl2YXRpb25zXG4gICAgcmV0dXJuIG11bHRpcGx5RWxlbWVudCQxKG91dHB1dEdhdGUsIHRhbmgkMShjZWxsKSwgeyBpZDogJ2FjdGl2YXRpb25zJyB9KTtcbn1cblxuZnVuY3Rpb24gb3V0cHV0KHNldHRpbmdzLCBpbnB1dExheWVyKSB7XG4gICAgY29uc3QgeyBoZWlnaHQgfSA9IHNldHRpbmdzO1xuICAgIGNvbnN0IG91dHB1dEdhdGUgPSByYW5kb20oe1xuICAgICAgICBoZWlnaHQsXG4gICAgICAgIHdpZHRoOiBpbnB1dExheWVyLmhlaWdodCxcbiAgICAgICAgaWQ6ICdvdXRwdXRHYXRlJyxcbiAgICAgICAgc3RkOiAwLjA4LFxuICAgIH0pO1xuICAgIGNvbnN0IG91dHB1dCA9IHJhbmRvbSh7IGhlaWdodCwgaWQ6ICdvdXRwdXQnLCBzdGQ6IDAuMDggfSk7XG4gICAgY29uc3Qgb3V0cHV0R2F0ZUNvbm5lY3RvciA9IG11bHRpcGx5JDEob3V0cHV0R2F0ZSwgaW5wdXRMYXllciwge1xuICAgICAgICBpZDogJ291dHB1dEdhdGVDb25uZWN0ZWQnLFxuICAgIH0pO1xuICAgIHJldHVybiB0YXJnZXQoeyBpZDogJ3RhcmdldCcsIC4uLnNldHRpbmdzIH0sIGFkZCQxKG91dHB1dEdhdGVDb25uZWN0b3IsIG91dHB1dCkpO1xufVxuXG5mdW5jdGlvbiBzZXRTd2l0Y2hZKHZhbHVlKSB7XG4gICAgcmV0dXJuIHZhbHVlO1xufVxuZnVuY3Rpb24gc2V0U3dpdGNoWCh2YWx1ZSkge1xuICAgIHJldHVybiB2YWx1ZTtcbn1cbmZ1bmN0aW9uIHByZWRpY3QkMShpbnB1dHMpIHtcbiAgICBjb25zdCBzdGFydEZpbHRlclggPSB0aGlzLmNvbnN0YW50cy5wYWRkaW5nWCAtIHRoaXMudGhyZWFkLnggKiB0aGlzLmNvbnN0YW50cy5zdHJpZGVYO1xuICAgIGNvbnN0IHN0YXJ0SW5wdXRYID0gdGhpcy50aHJlYWQueCAqIHRoaXMuY29uc3RhbnRzLnN0cmlkZVggLSB0aGlzLmNvbnN0YW50cy5wYWRkaW5nWDtcbiAgICBjb25zdCBlbmRGaWx0ZXJYID0gTWF0aC5taW4odGhpcy5jb25zdGFudHMuZmlsdGVyV2lkdGgsIHN0YXJ0RmlsdGVyWCArIHRoaXMuY29uc3RhbnRzLmlucHV0V2lkdGgpO1xuICAgIGNvbnN0IHN0YXJ0RmlsdGVyWSA9IHRoaXMuY29uc3RhbnRzLnBhZGRpbmdZIC0gdGhpcy50aHJlYWQueSAqIHRoaXMuY29uc3RhbnRzLnN0cmlkZVk7XG4gICAgY29uc3Qgc3RhcnRJbnB1dFkgPSB0aGlzLnRocmVhZC55ICogdGhpcy5jb25zdGFudHMuc3RyaWRlWSAtIHRoaXMuY29uc3RhbnRzLnBhZGRpbmdZO1xuICAgIGNvbnN0IGVuZEZpbHRlclkgPSBNYXRoLm1pbih0aGlzLmNvbnN0YW50cy5maWx0ZXJIZWlnaHQsIHN0YXJ0RmlsdGVyWSArIHRoaXMuY29uc3RhbnRzLmlucHV0SGVpZ2h0KTtcbiAgICBsZXQgbGFyZ2VzdFZhbHVlID0gLTk5OTk5O1xuICAgIC8vIGNvbnZvbHZlIGNlbnRlcmVkIGF0IHRoaXMgcGFydGljdWxhciBsb2NhdGlvblxuICAgIGZvciAobGV0IGZpbHRlclkgPSBNYXRoLm1heCgwLCBzdGFydEZpbHRlclkpLCBpbnB1dFkgPSBNYXRoLm1heCgwLCBzdGFydElucHV0WSk7IGZpbHRlclkgPCBlbmRGaWx0ZXJZOyBmaWx0ZXJZKyssIGlucHV0WSsrKSB7XG4gICAgICAgIGZvciAobGV0IGZpbHRlclggPSBNYXRoLm1heCgwLCBzdGFydEZpbHRlclgpLCBpbnB1dFggPSBNYXRoLm1heCgwLCBzdGFydElucHV0WCk7IGZpbHRlclggPCBlbmRGaWx0ZXJYOyBmaWx0ZXJYKyssIGlucHV0WCsrKSB7XG4gICAgICAgICAgICBpZiAoaW5wdXRZID49IDAgJiZcbiAgICAgICAgICAgICAgICBpbnB1dFkgPCB0aGlzLmNvbnN0YW50cy5pbnB1dEhlaWdodCAmJlxuICAgICAgICAgICAgICAgIGlucHV0WCA+PSAwICYmXG4gICAgICAgICAgICAgICAgaW5wdXRYIDwgdGhpcy5jb25zdGFudHMuaW5wdXRXaWR0aCkge1xuICAgICAgICAgICAgICAgIGNvbnN0IGlucHV0ID0gaW5wdXRzW3RoaXMudGhyZWFkLnpdW2lucHV0WV1baW5wdXRYXTtcbiAgICAgICAgICAgICAgICBpZiAoaW5wdXQgPiBsYXJnZXN0VmFsdWUpIHtcbiAgICAgICAgICAgICAgICAgICAgbGFyZ2VzdFZhbHVlID0gaW5wdXQ7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfVxuICAgIHJldHVybiBsYXJnZXN0VmFsdWU7XG59XG5mdW5jdGlvbiBjb21wYXJlJDEoZGVsdGFzLCBzd2l0Y2hZLCBzd2l0Y2hYKSB7XG4gICAgY29uc3QgeCA9IE1hdGguZmxvb3IoKHRoaXMudGhyZWFkLnggLyB0aGlzLm91dHB1dC54KSAqIHRoaXMuY29uc3RhbnRzLm91dHB1dFdpZHRoKTtcbiAgICBjb25zdCB5ID0gTWF0aC5mbG9vcigodGhpcy50aHJlYWQueSAvIHRoaXMub3V0cHV0LnkpICogdGhpcy5jb25zdGFudHMub3V0cHV0SGVpZ2h0KTtcbiAgICBsZXQgdmFsdWUgPSAwO1xuICAgIGZvciAobGV0IGRlbHRhc1kgPSAwOyBkZWx0YXNZIDwgdGhpcy5jb25zdGFudHMuaW5wdXRIZWlnaHQ7IGRlbHRhc1krKykge1xuICAgICAgICBmb3IgKGxldCBkZWx0YXNYID0gMDsgZGVsdGFzWCA8IHRoaXMuY29uc3RhbnRzLmlucHV0V2lkdGg7IGRlbHRhc1grKykge1xuICAgICAgICAgICAgY29uc3Qgc3dpdGNoWFZhbHVlID0gc3dpdGNoWFtkZWx0YXNZXVtkZWx0YXNYXTtcbiAgICAgICAgICAgIGNvbnN0IHN3aXRjaFlWYWx1ZSA9IHN3aXRjaFlbZGVsdGFzWV1bZGVsdGFzWF07XG4gICAgICAgICAgICBpZiAoc3dpdGNoWFZhbHVlID09PSB4ICYmIHN3aXRjaFlWYWx1ZSA9PT0geSkge1xuICAgICAgICAgICAgICAgIHZhbHVlICs9IGRlbHRhc1tkZWx0YXNZXVtkZWx0YXNYXTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIH1cbiAgICByZXR1cm4gdmFsdWU7XG59XG5jb25zdCBkZWZhdWx0cyQ0ID0ge1xuICAgIHBhZGRpbmc6IDAsXG4gICAgc3RyaWRlOiAwLFxuICAgIGZpbHRlcldpZHRoOiAwLFxuICAgIGZpbHRlckhlaWdodDogMCxcbiAgICBmaWx0ZXJDb3VudDogMCxcbn07XG5jbGFzcyBQb29sIGV4dGVuZHMgRmlsdGVyIHtcbiAgICBjb25zdHJ1Y3RvcihzZXR0aW5ncywgaW5wdXRMYXllcikge1xuICAgICAgICBzdXBlcihzZXR0aW5ncywgaW5wdXRMYXllcik7XG4gICAgICAgIHRoaXMucHJlZGljdEtlcm5lbE1hcCA9IG51bGw7XG4gICAgICAgIHRoaXMuc2V0dGluZ3MgPSB7XG4gICAgICAgICAgICAuLi5zZXR0aW5ncyxcbiAgICAgICAgICAgIC4uLmdldFN0cmlkZShzZXR0aW5ncywgZGVmYXVsdHMkNCksXG4gICAgICAgICAgICAuLi5nZXRQYWRkaW5nKHNldHRpbmdzLCBkZWZhdWx0cyQ0KSxcbiAgICAgICAgfTtcbiAgICAgICAgdGhpcy53ZWlnaHRzID0gcmFuZG9zM0QodGhpcy53aWR0aCwgdGhpcy5oZWlnaHQsIHRoaXMuZGVwdGgpO1xuICAgICAgICB0aGlzLmRlbHRhcyA9IHplcm9zM0QodGhpcy53aWR0aCwgdGhpcy5oZWlnaHQsIHRoaXMuZGVwdGgpO1xuICAgICAgICB0aGlzLmZpbHRlcnMgPSByYW5kb3MzRCh0aGlzLmZpbHRlcldpZHRoLCB0aGlzLmZpbHRlckhlaWdodCwgdGhpcy5maWx0ZXJDb3VudCk7XG4gICAgICAgIHRoaXMuZmlsdGVyRGVsdGFzID0gemVyb3MzRCh0aGlzLmZpbHRlcldpZHRoLCB0aGlzLmZpbHRlckhlaWdodCwgdGhpcy5maWx0ZXJDb3VudCk7XG4gICAgICAgIHRoaXMudmFsaWRhdGUoKTtcbiAgICB9XG4gICAgZ2V0IHN0cmlkZVgoKSB7XG4gICAgICAgIHJldHVybiB0aGlzLnNldHRpbmdzLnN0cmlkZVg7XG4gICAgfVxuICAgIGdldCBzdHJpZGVZKCkge1xuICAgICAgICByZXR1cm4gdGhpcy5zZXR0aW5ncy5zdHJpZGVZO1xuICAgIH1cbiAgICBnZXQgcGFkZGluZ1goKSB7XG4gICAgICAgIHJldHVybiB0aGlzLnNldHRpbmdzLnBhZGRpbmdYO1xuICAgIH1cbiAgICBnZXQgcGFkZGluZ1koKSB7XG4gICAgICAgIHJldHVybiB0aGlzLnNldHRpbmdzLnBhZGRpbmdZO1xuICAgIH1cbiAgICBnZXQgd2lkdGgoKSB7XG4gICAgICAgIHJldHVybiBNYXRoLmZsb29yKCh0aGlzLmlucHV0TGF5ZXIud2lkdGggKyB0aGlzLnBhZGRpbmdYICogMiAtIHRoaXMuZmlsdGVyV2lkdGgpIC9cbiAgICAgICAgICAgIHRoaXMuc3RyaWRlWCArXG4gICAgICAgICAgICAxKTtcbiAgICB9XG4gICAgZ2V0IGhlaWdodCgpIHtcbiAgICAgICAgcmV0dXJuIE1hdGguZmxvb3IoKHRoaXMuaW5wdXRMYXllci5oZWlnaHQgKyB0aGlzLnBhZGRpbmdZICogMiAtIHRoaXMuZmlsdGVySGVpZ2h0KSAvXG4gICAgICAgICAgICB0aGlzLnN0cmlkZVkgK1xuICAgICAgICAgICAgMSk7XG4gICAgfVxuICAgIGdldCBkZXB0aCgpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuc2V0dGluZ3MuZmlsdGVyQ291bnQ7XG4gICAgfVxuICAgIGdldCBmaWx0ZXJDb3VudCgpIHtcbiAgICAgICAgLy8gVE9ETzogaGFuZGxlIDEgZGVwdGg/XG4gICAgICAgIHJldHVybiB0aGlzLnNldHRpbmdzLmZpbHRlckNvdW50O1xuICAgIH1cbiAgICBnZXQgc3dpdGNoWCgpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuc2V0dGluZ3Muc3dpdGNoWDtcbiAgICB9XG4gICAgc2V0IHN3aXRjaFgoc3dpdGNoWCkge1xuICAgICAgICB0aGlzLnNldHRpbmdzLnN3aXRjaFggPSBzd2l0Y2hYO1xuICAgIH1cbiAgICBnZXQgc3dpdGNoWSgpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuc2V0dGluZ3Muc3dpdGNoWTtcbiAgICB9XG4gICAgc2V0IHN3aXRjaFkoc3dpdGNoWSkge1xuICAgICAgICB0aGlzLnNldHRpbmdzLnN3aXRjaFkgPSBzd2l0Y2hZO1xuICAgIH1cbiAgICBzZXR1cEtlcm5lbHMoKSB7XG4gICAgICAgIHRoaXMucHJlZGljdEtlcm5lbE1hcCA9IG1ha2VLZXJuZWxNYXAoe1xuICAgICAgICAgICAgc3dpdGNoWDogc2V0U3dpdGNoWCxcbiAgICAgICAgICAgIHN3aXRjaFk6IHNldFN3aXRjaFksXG4gICAgICAgIH0sIHByZWRpY3QkMSwge1xuICAgICAgICAgICAgb3V0cHV0OiBbdGhpcy53aWR0aCwgdGhpcy5oZWlnaHQsIHRoaXMuZGVwdGhdLFxuICAgICAgICAgICAgY29uc3RhbnRzOiB7XG4gICAgICAgICAgICAgICAgaW5wdXRXaWR0aDogdGhpcy5pbnB1dExheWVyLndpZHRoLFxuICAgICAgICAgICAgICAgIGlucHV0SGVpZ2h0OiB0aGlzLmlucHV0TGF5ZXIuaGVpZ2h0LFxuICAgICAgICAgICAgICAgIHBhZGRpbmdYOiB0aGlzLnBhZGRpbmdYLFxuICAgICAgICAgICAgICAgIHBhZGRpbmdZOiB0aGlzLnBhZGRpbmdZLFxuICAgICAgICAgICAgICAgIGZpbHRlckhlaWdodDogdGhpcy5maWx0ZXJIZWlnaHQsXG4gICAgICAgICAgICAgICAgZmlsdGVyV2lkdGg6IHRoaXMuZmlsdGVyV2lkdGgsXG4gICAgICAgICAgICB9LFxuICAgICAgICB9KTtcbiAgICAgICAgdGhpcy5jb21wYXJlS2VybmVsID0gbWFrZUtlcm5lbChjb21wYXJlJDEsIHtcbiAgICAgICAgICAgIG91dHB1dDogW1xuICAgICAgICAgICAgICAgIHRoaXMuaW5wdXRMYXllci53aWR0aCxcbiAgICAgICAgICAgICAgICB0aGlzLmlucHV0TGF5ZXIuaGVpZ2h0LFxuICAgICAgICAgICAgICAgIHRoaXMuaW5wdXRMYXllci5kZXB0aCxcbiAgICAgICAgICAgIF0sXG4gICAgICAgICAgICBjb25zdGFudHM6IHtcbiAgICAgICAgICAgICAgICBpbnB1dFdpZHRoOiB0aGlzLmlucHV0TGF5ZXIud2lkdGgsXG4gICAgICAgICAgICAgICAgaW5wdXRIZWlnaHQ6IHRoaXMuaW5wdXRMYXllci5oZWlnaHQsXG4gICAgICAgICAgICAgICAgb3V0cHV0V2lkdGg6IHRoaXMud2lkdGgsXG4gICAgICAgICAgICAgICAgb3V0cHV0SGVpZ2h0OiB0aGlzLmhlaWdodCxcbiAgICAgICAgICAgIH0sXG4gICAgICAgIH0pO1xuICAgIH1cbiAgICBwcmVkaWN0KCkge1xuICAgICAgICBjb25zdCB7IHJlc3VsdDogd2VpZ2h0cywgc3dpdGNoWCwgc3dpdGNoWSB9ID0gdGhpc1xuICAgICAgICAgICAgLnByZWRpY3RLZXJuZWxNYXAodGhpcy5pbnB1dExheWVyLndlaWdodHMpO1xuICAgICAgICB0aGlzLnN3aXRjaFggPSBzd2l0Y2hYO1xuICAgICAgICB0aGlzLnN3aXRjaFkgPSBzd2l0Y2hZO1xuICAgICAgICB0aGlzLndlaWdodHMgPSB3ZWlnaHRzO1xuICAgIH1cbiAgICBjb21wYXJlKCkge1xuICAgICAgICAvLyBkZWJ1Z2dlcjtcbiAgICAgICAgLy8gY29uc3QgZGVwdGggPSB0aGlzLmlucHV0TGF5ZXIuZGVsdGFzLmxlbmd0aDtcbiAgICAgICAgLy8gY29uc3QgaGVpZ2h0ID0gdGhpcy5pbnB1dExheWVyLmRlbHRhc1swXS5sZW5ndGg7XG4gICAgICAgIC8vIGNvbnN0IHdpZHRoID0gdGhpcy5pbnB1dExheWVyLmRlbHRhc1swXVswXS5sZW5ndGg7XG4gICAgICAgIC8vIGNvbnN0IHR5cGUgPSB0eXBlb2YgdGhpcy5pbnB1dExheWVyLmRlbHRhc1swXVswXVswXTtcbiAgICAgICAgY29uc3QgaW5wdXRMYXllckRlbHRhcyA9IHRoaXMuaW5wdXRMYXllci5kZWx0YXM7XG4gICAgICAgIHRoaXMuaW5wdXRMYXllci5kZWx0YXMgPSB0aGlzLmNvbXBhcmVLZXJuZWwodGhpcy5kZWx0YXMsIHRoaXMuc3dpdGNoWCwgdGhpcy5zd2l0Y2hZKTtcbiAgICAgICAgcmVsZWFzZShpbnB1dExheWVyRGVsdGFzKTtcbiAgICAgICAgLy8gZGVidWdnZXI7XG4gICAgICAgIC8vIGlmIChkZXB0aCAhPT0gdGhpcy5pbnB1dExheWVyLmRlbHRhcy5sZW5ndGgpIGRlYnVnZ2VyO1xuICAgICAgICAvLyBpZiAoaGVpZ2h0ICE9PSB0aGlzLmlucHV0TGF5ZXIuZGVsdGFzWzBdLmxlbmd0aCkgZGVidWdnZXI7XG4gICAgICAgIC8vIGlmICh3aWR0aCAhPT0gdGhpcy5pbnB1dExheWVyLmRlbHRhc1swXVswXS5sZW5ndGgpIGRlYnVnZ2VyO1xuICAgICAgICAvLyBpZiAodHlwZSAhPT0gdHlwZW9mIHRoaXMuaW5wdXRMYXllci5kZWx0YXNbMF1bMF1bMF0pIGRlYnVnZ2VyO1xuICAgIH1cbn1cbmZ1bmN0aW9uIHBvb2woc2V0dGluZ3MsIGlucHV0TGF5ZXIpIHtcbiAgICByZXR1cm4gbmV3IFBvb2woc2V0dGluZ3MsIGlucHV0TGF5ZXIpO1xufVxuXG5jbGFzcyBSZWN1cnJlbnRJbnB1dCBleHRlbmRzIEludGVybmFsIHtcbiAgICBjb25zdHJ1Y3RvcihyZWN1cnJlbnRJbnB1dCkge1xuICAgICAgICBzdXBlcigpO1xuICAgICAgICB0aGlzLnByYXhpcyA9IG51bGw7XG4gICAgICAgIHRoaXMucHJlZGljdEtlcm5lbCA9IG51bGw7XG4gICAgICAgIHRoaXMuY29tcGFyZUtlcm5lbCA9IG51bGw7XG4gICAgICAgIHRoaXMuc2V0dGluZ3MgPSB7fTtcbiAgICAgICAgdGhpcy5yZWN1cnJlbnRJbnB1dCA9IHJlY3VycmVudElucHV0O1xuICAgICAgICB0aGlzLnZhbGlkYXRlKCk7XG4gICAgfVxuICAgIGdldCB3aWR0aCgpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMucmVjdXJyZW50SW5wdXQud2lkdGg7XG4gICAgfVxuICAgIGdldCBoZWlnaHQoKSB7XG4gICAgICAgIHJldHVybiB0aGlzLnJlY3VycmVudElucHV0LmhlaWdodDtcbiAgICB9XG4gICAgZ2V0IGRlcHRoKCkge1xuICAgICAgICByZXR1cm4gdGhpcy5yZWN1cnJlbnRJbnB1dC5kZXB0aDtcbiAgICB9XG4gICAgZ2V0IGRlbHRhcygpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMucmVjdXJyZW50SW5wdXQuZGVsdGFzO1xuICAgIH1cbiAgICBzZXQgZGVsdGFzKGRlbHRhcykge1xuICAgICAgICBjb25zdCByZWN1cnJlbnRJbnB1dERlbHRhcyA9IHRoaXMucmVjdXJyZW50SW5wdXQuZGVsdGFzO1xuICAgICAgICB0aGlzLnJlY3VycmVudElucHV0LmRlbHRhcyA9IGRlbHRhcztcbiAgICAgICAgcmVsZWFzZShyZWN1cnJlbnRJbnB1dERlbHRhcyk7XG4gICAgfVxuICAgIGdldCB3ZWlnaHRzKCkge1xuICAgICAgICByZXR1cm4gdGhpcy5yZWN1cnJlbnRJbnB1dC53ZWlnaHRzO1xuICAgIH1cbiAgICBzZXQgd2VpZ2h0cyh3ZWlnaHRzKSB7XG4gICAgICAgIGNvbnN0IHJlY3VycmVudElucHV0V2VpZ2h0cyA9IHRoaXMucmVjdXJyZW50SW5wdXQud2VpZ2h0cztcbiAgICAgICAgdGhpcy5yZWN1cnJlbnRJbnB1dC53ZWlnaHRzID0gd2VpZ2h0cztcbiAgICAgICAgcmVsZWFzZShyZWN1cnJlbnRJbnB1dFdlaWdodHMpO1xuICAgIH1cbiAgICB2YWxpZGF0ZSgpIHtcbiAgICAgICAgQmFzZUxheWVyLnByb3RvdHlwZS52YWxpZGF0ZS5jYWxsKHRoaXMpO1xuICAgICAgICBpZiAodGhpcy53aWR0aCAhPT0gdGhpcy5yZWN1cnJlbnRJbnB1dC53aWR0aCkge1xuICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKGAke3RoaXMuY29uc3RydWN0b3IubmFtZX0gbGF5ZXIgd2lkdGggJHt0aGlzLndpZHRofSBhbmQgJHt0aGlzLnJlY3VycmVudElucHV0LmNvbnN0cnVjdG9yLm5hbWV9IHdpZHRoICgke3RoaXMucmVjdXJyZW50SW5wdXQud2lkdGh9KSBhcmUgbm90IHNhbWVgKTtcbiAgICAgICAgfVxuICAgICAgICBpZiAodGhpcy5oZWlnaHQgIT09IHRoaXMucmVjdXJyZW50SW5wdXQuaGVpZ2h0KSB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoYCR7dGhpcy5jb25zdHJ1Y3Rvci5uYW1lfSBsYXllciBoZWlnaHQgJHt0aGlzLmhlaWdodH0gYW5kICR7dGhpcy5yZWN1cnJlbnRJbnB1dC5jb25zdHJ1Y3Rvci5uYW1lfSB3aWR0aCAoJHt0aGlzLnJlY3VycmVudElucHV0LmhlaWdodH0pIGFyZSBub3Qgc2FtZWApO1xuICAgICAgICB9XG4gICAgfVxuICAgIHNldERpbWVuc2lvbnMod2lkdGgsIGhlaWdodCkge1xuICAgICAgICB0aGlzLnJlY3VycmVudElucHV0LndpZHRoID0gd2lkdGg7XG4gICAgICAgIHRoaXMucmVjdXJyZW50SW5wdXQuaGVpZ2h0ID0gaGVpZ2h0O1xuICAgIH1cbiAgICBwcmVkaWN0KCkge1xuICAgICAgICAvLyB0aHJvdyBuZXcgRXJyb3IoYCR7dGhpcy5jb25zdHJ1Y3Rvci5uYW1lfS1wcmVkaWN0IGlzIG5vdCB5ZXQgaW1wbGVtZW50ZWRgKVxuICAgIH1cbiAgICBjb21wYXJlKCkge1xuICAgICAgICAvLyB0aHJvdyBuZXcgRXJyb3IoYCR7dGhpcy5jb25zdHJ1Y3Rvci5uYW1lfS1jb21wYXJlIGlzIG5vdCB5ZXQgaW1wbGVtZW50ZWRgKVxuICAgIH1cbiAgICBsZWFybigpIHtcbiAgICAgICAgLy8gdGhyb3cgbmV3IEVycm9yKGAke3RoaXMuY29uc3RydWN0b3IubmFtZX0tbGVhcm4gaXMgbm90IHlldCBpbXBsZW1lbnRlZGApXG4gICAgfVxuICAgIHNldHVwS2VybmVscygpIHtcbiAgICAgICAgLy8gdGhyb3cgbmV3IEVycm9yKFxuICAgICAgICAvLyAgIGAke3RoaXMuY29uc3RydWN0b3IubmFtZX0tc2V0dXBLZXJuZWxzIGlzIG5vdCB5ZXQgaW1wbGVtZW50ZWRgXG4gICAgICAgIC8vIClcbiAgICB9XG4gICAgcmV1c2VLZXJuZWxzKCkge1xuICAgICAgICAvLyB0aHJvdyBuZXcgRXJyb3IoXG4gICAgICAgIC8vICAgYCR7dGhpcy5jb25zdHJ1Y3Rvci5uYW1lfS1yZXVzZUtlcm5lbHMgaXMgbm90IHlldCBpbXBsZW1lbnRlZGBcbiAgICAgICAgLy8gKVxuICAgIH1cbn1cblxuY2xhc3MgUmVjdXJyZW50WmVyb3MgZXh0ZW5kcyBJbnRlcm5hbCB7XG4gICAgY29uc3RydWN0b3Ioc2V0dGluZ3MpIHtcbiAgICAgICAgc3VwZXIoKTtcbiAgICAgICAgdGhpcy5wcmF4aXMgPSBudWxsO1xuICAgICAgICB0aGlzLnNldHRpbmdzID0ge307XG4gICAgICAgIHRoaXMucHJlZGljdEtlcm5lbCA9IG51bGw7XG4gICAgICAgIHRoaXMuY29tcGFyZUtlcm5lbCA9IG51bGw7XG4gICAgICAgIGlmIChzZXR0aW5ncykge1xuICAgICAgICAgICAgdGhpcy5zZXR0aW5ncyA9IHsgLi4uc2V0dGluZ3MgfTtcbiAgICAgICAgfVxuICAgIH1cbiAgICBzZXREaW1lbnNpb25zKHdpZHRoLCBoZWlnaHQpIHtcbiAgICAgICAgdGhpcy5wcmF4aXMgPSBudWxsO1xuICAgICAgICB0aGlzLnNldHRpbmdzID0ge1xuICAgICAgICAgICAgLi4udGhpcy5zZXR0aW5ncyxcbiAgICAgICAgICAgIHdpZHRoLFxuICAgICAgICAgICAgaGVpZ2h0LFxuICAgICAgICAgICAgd2VpZ2h0czogemVyb3MyRCh3aWR0aCwgaGVpZ2h0KSxcbiAgICAgICAgICAgIGRlbHRhczogemVyb3MyRCh3aWR0aCwgaGVpZ2h0KSxcbiAgICAgICAgfTtcbiAgICB9XG4gICAgc2V0dXBLZXJuZWxzKCkge1xuICAgICAgICAvLyB0aHJvdyBuZXcgRXJyb3IoXG4gICAgICAgIC8vICAgYCR7dGhpcy5jb25zdHJ1Y3Rvci5uYW1lfS1zZXR1cEtlcm5lbHMgaXMgbm90IHlldCBpbXBsZW1lbnRlZGBcbiAgICAgICAgLy8gKVxuICAgIH1cbiAgICByZXVzZUtlcm5lbHMoKSB7XG4gICAgICAgIC8vIHRocm93IG5ldyBFcnJvcihcbiAgICAgICAgLy8gICBgJHt0aGlzLmNvbnN0cnVjdG9yLm5hbWV9LXJldXNlS2VybmVscyBpcyBub3QgeWV0IGltcGxlbWVudGVkYFxuICAgICAgICAvLyApXG4gICAgfVxuICAgIHByZWRpY3QoKSB7XG4gICAgICAgIC8vIHRocm93IG5ldyBFcnJvcihgJHt0aGlzLmNvbnN0cnVjdG9yLm5hbWV9LXByZWRpY3QgaXMgbm90IHlldCBpbXBsZW1lbnRlZGApXG4gICAgfVxuICAgIGNvbXBhcmUoKSB7XG4gICAgICAgIC8vIHRocm93IG5ldyBFcnJvcihgJHt0aGlzLmNvbnN0cnVjdG9yLm5hbWV9LWNvbXBhcmUgaXMgbm90IHlldCBpbXBsZW1lbnRlZGApXG4gICAgfVxuICAgIGxlYXJuKGxlYXJuaW5nUmF0ZSkge1xuICAgICAgICBjb25zdCB7IHdlaWdodHM6IG9sZFdlaWdodHMgfSA9IHRoaXM7XG4gICAgICAgIHRoaXMud2VpZ2h0cyA9IHRoaXMucHJheGlzLnJ1bih0aGlzLCBsZWFybmluZ1JhdGUpO1xuICAgICAgICAvLyB0aGlzLmRlbHRhcyA9IGRlbHRhcztcbiAgICAgICAgcmVsZWFzZShvbGRXZWlnaHRzKTtcbiAgICAgICAgY2xlYXIodGhpcy5kZWx0YXMpO1xuICAgIH1cbn1cbmZ1bmN0aW9uIHJlY3VycmVudFplcm9zKCkge1xuICAgIHJldHVybiBuZXcgUmVjdXJyZW50WmVyb3MoKTtcbn1cblxuZnVuY3Rpb24gcHJlZGljdDJEJDEoaW5wdXRzKSB7XG4gICAgcmV0dXJuIGFjdGl2YXRlJDMoaW5wdXRzW3RoaXMudGhyZWFkLnldW3RoaXMudGhyZWFkLnhdKTtcbn1cbmZ1bmN0aW9uIGNvbXBhcmUyRCQxKHdlaWdodHMsIGRlbHRhcykge1xuICAgIHJldHVybiBtZWFzdXJlJDMod2VpZ2h0c1t0aGlzLnRocmVhZC55XVt0aGlzLnRocmVhZC54XSwgZGVsdGFzW3RoaXMudGhyZWFkLnldW3RoaXMudGhyZWFkLnhdKTtcbn1cbmZ1bmN0aW9uIHByZWRpY3QzRCQxKGlucHV0cykge1xuICAgIHJldHVybiBhY3RpdmF0ZSQzKGlucHV0c1t0aGlzLnRocmVhZC56XVt0aGlzLnRocmVhZC55XVt0aGlzLnRocmVhZC54XSk7XG59XG5mdW5jdGlvbiBjb21wYXJlM0QkMSh3ZWlnaHRzLCBkZWx0YXMpIHtcbiAgICByZXR1cm4gbWVhc3VyZSQzKHdlaWdodHNbdGhpcy50aHJlYWQuel1bdGhpcy50aHJlYWQueV1bdGhpcy50aHJlYWQueF0sIGRlbHRhc1t0aGlzLnRocmVhZC56XVt0aGlzLnRocmVhZC55XVt0aGlzLnRocmVhZC54XSk7XG59XG5jbGFzcyBSZWx1IGV4dGVuZHMgQWN0aXZhdGlvbiB7XG4gICAgc2V0dXBLZXJuZWxzKCkge1xuICAgICAgICBjb25zdCB7IHdpZHRoLCBoZWlnaHQsIGRlcHRoIH0gPSB0aGlzLmlucHV0TGF5ZXI7XG4gICAgICAgIGlmIChkZXB0aCA+IDApIHtcbiAgICAgICAgICAgIHRoaXMucHJlZGljdEtlcm5lbCA9IG1ha2VLZXJuZWwocHJlZGljdDNEJDEsIHtcbiAgICAgICAgICAgICAgICBvdXRwdXQ6IFt3aWR0aCwgaGVpZ2h0LCBkZXB0aF0sXG4gICAgICAgICAgICAgICAgZnVuY3Rpb25zOiBbYWN0aXZhdGUkM10sXG4gICAgICAgICAgICAgICAgaW1tdXRhYmxlOiB0cnVlLFxuICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICB0aGlzLmNvbXBhcmVLZXJuZWwgPSBtYWtlS2VybmVsKGNvbXBhcmUzRCQxLCB7XG4gICAgICAgICAgICAgICAgb3V0cHV0OiBbd2lkdGgsIGhlaWdodCwgZGVwdGhdLFxuICAgICAgICAgICAgICAgIGZ1bmN0aW9uczogW21lYXN1cmUkM10sXG4gICAgICAgICAgICAgICAgaW1tdXRhYmxlOiB0cnVlLFxuICAgICAgICAgICAgfSk7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICB0aGlzLnByZWRpY3RLZXJuZWwgPSBtYWtlS2VybmVsKHByZWRpY3QyRCQxLCB7XG4gICAgICAgICAgICAgICAgb3V0cHV0OiBbd2lkdGgsIGhlaWdodF0sXG4gICAgICAgICAgICAgICAgZnVuY3Rpb25zOiBbYWN0aXZhdGUkM10sXG4gICAgICAgICAgICAgICAgaW1tdXRhYmxlOiB0cnVlLFxuICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICB0aGlzLmNvbXBhcmVLZXJuZWwgPSBtYWtlS2VybmVsKGNvbXBhcmUyRCQxLCB7XG4gICAgICAgICAgICAgICAgb3V0cHV0OiBbd2lkdGgsIGhlaWdodF0sXG4gICAgICAgICAgICAgICAgZnVuY3Rpb25zOiBbbWVhc3VyZSQzXSxcbiAgICAgICAgICAgICAgICBpbW11dGFibGU6IHRydWUsXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgfVxuICAgIH1cbiAgICBwcmVkaWN0KCkge1xuICAgICAgICByZWxlYXNlKHRoaXMud2VpZ2h0cyk7XG4gICAgICAgIHRoaXMud2VpZ2h0cyA9IHRoaXMucHJlZGljdEtlcm5lbCh0aGlzLmlucHV0TGF5ZXIud2VpZ2h0cyk7XG4gICAgICAgIGNsZWFyKHRoaXMuZGVsdGFzKTtcbiAgICB9XG4gICAgY29tcGFyZSgpIHtcbiAgICAgICAgcmVsZWFzZSh0aGlzLmlucHV0TGF5ZXIuZGVsdGFzKTtcbiAgICAgICAgdGhpcy5pbnB1dExheWVyLmRlbHRhcyA9IHRoaXMuY29tcGFyZUtlcm5lbCh0aGlzLndlaWdodHMsIHRoaXMuZGVsdGFzKTtcbiAgICB9XG59XG5mdW5jdGlvbiByZWx1JDEoaW5wdXRMYXllciwgc2V0dGluZ3MpIHtcbiAgICByZXR1cm4gbmV3IFJlbHUoaW5wdXRMYXllciwgc2V0dGluZ3MpO1xufVxuXG5mdW5jdGlvbiBybm5DZWxsKHNldHRpbmdzLCBpbnB1dCwgcmVjdXJyZW50SW5wdXQpIHtcbiAgICBjb25zdCB7IGhlaWdodCB9ID0gc2V0dGluZ3M7XG4gICAgaWYgKHR5cGVvZiBoZWlnaHQgIT09ICdudW1iZXInKVxuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ2hlaWdodCBub3Qgc2V0Jyk7XG4gICAgaWYgKHJlY3VycmVudElucHV0LnNldERpbWVuc2lvbnMpIHtcbiAgICAgICAgcmVjdXJyZW50SW5wdXQuc2V0RGltZW5zaW9ucygxLCBoZWlnaHQpO1xuICAgIH1cbiAgICAvLyB3eGhcbiAgICBjb25zdCB3ZWlnaHQgPSByYW5kb20oe1xuICAgICAgICBpZDogJ3dlaWdodCcsXG4gICAgICAgIGhlaWdodCxcbiAgICAgICAgd2lkdGg6IGlucHV0LmhlaWdodCxcbiAgICAgICAgc3RkOiAwLjA4LFxuICAgIH0pO1xuICAgIC8vIHdoaFxuICAgIGNvbnN0IHRyYW5zaXRpb24gPSByYW5kb20oe1xuICAgICAgICBpZDogJ3RyYW5zaXRpb24nLFxuICAgICAgICBoZWlnaHQsXG4gICAgICAgIHdpZHRoOiBoZWlnaHQsXG4gICAgICAgIHN0ZDogMC4wOCxcbiAgICB9KTtcbiAgICAvLyBiaGhcbiAgICBjb25zdCBiaWFzID0gemVyb3MoeyBpZDogJ2JpYXMnLCBoZWlnaHQgfSk7XG4gICAgcmV0dXJuIHJlbHUkMShhZGQkMShhZGQkMShtdWx0aXBseSQxKHdlaWdodCwgaW5wdXQpLCBtdWx0aXBseSQxKHRyYW5zaXRpb24sIHJlY3VycmVudElucHV0KSksIGJpYXMpKTtcbn1cblxuY2xhc3MgUmVncmVzc2lvbiBleHRlbmRzIEJhc2VMYXllciB7XG4gICAgY29uc3RydWN0b3Ioc2V0dGluZ3MsIGlucHV0TGF5ZXIpIHtcbiAgICAgICAgc3VwZXIoc2V0dGluZ3MpO1xuICAgICAgICB0aGlzLmlucHV0TGF5ZXIgPSBpbnB1dExheWVyO1xuICAgICAgICB0aGlzLnZhbGlkYXRlKCk7XG4gICAgfVxuICAgIHByZWRpY3QoKSB7XG4gICAgICAgIHJlbGVhc2UodGhpcy53ZWlnaHRzKTtcbiAgICAgICAgdGhpcy53ZWlnaHRzID0gY2xvbmUodGhpcy5pbnB1dExheWVyLndlaWdodHMpO1xuICAgIH1cbiAgICBsZWFybigpIHtcbiAgICAgICAgLy8gdGhyb3cgbmV3IEVycm9yKGAke3RoaXMuY29uc3RydWN0b3IubmFtZX0tbGVhcm4gaXMgbm90IHlldCBpbXBsZW1lbnRlZGApXG4gICAgfVxufVxuLy8gVE9ETzogaGFuZGxlIGBsb3NzICs9IDAuNSpkeSpkeTtgIHRvdGFsIGFuZCBzdW0gaW4gbGVhcm5cbmZ1bmN0aW9uIHJlZ3Jlc3Npb24oc2V0dGluZ3MsIGlucHV0TGF5ZXIpIHtcbiAgICByZXR1cm4gbmV3IFJlZ3Jlc3Npb24oc2V0dGluZ3MsIGlucHV0TGF5ZXIpO1xufVxuXG5mdW5jdGlvbiBnZXRNYXhWYWx1ZTJEKGlucHV0cykge1xuICAgIGxldCBtYXhJbnB1dCA9IC1JbmZpbml0eTtcbiAgICBmb3IgKGxldCB5ID0gMDsgeSA8IHRoaXMuY29uc3RhbnRzLmlucHV0SGVpZ2h0OyB5KyspIHtcbiAgICAgICAgZm9yIChsZXQgeCA9IDA7IHggPCB0aGlzLmNvbnN0YW50cy5pbnB1dFdpZHRoOyB4KyspIHtcbiAgICAgICAgICAgIGNvbnN0IGlucHV0ID0gaW5wdXRzW3ldW3hdO1xuICAgICAgICAgICAgaWYgKGlucHV0ID4gbWF4SW5wdXQpIHtcbiAgICAgICAgICAgICAgICBtYXhJbnB1dCA9IGlucHV0O1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfVxuICAgIHJldHVybiBtYXhJbnB1dDtcbn1cbmZ1bmN0aW9uIGdldE1heFZhbHVlM0QoaW5wdXRzKSB7XG4gICAgbGV0IG1heElucHV0ID0gLUluZmluaXR5O1xuICAgIGZvciAobGV0IHogPSAwOyB6IDwgdGhpcy5jb25zdGFudHMuaW5wdXREZXB0aDsgeisrKSB7XG4gICAgICAgIGZvciAobGV0IHkgPSAwOyB5IDwgdGhpcy5jb25zdGFudHMuaW5wdXRIZWlnaHQ7IHkrKykge1xuICAgICAgICAgICAgZm9yIChsZXQgeCA9IDA7IHggPCB0aGlzLmNvbnN0YW50cy5pbnB1dFdpZHRoOyB4KyspIHtcbiAgICAgICAgICAgICAgICBjb25zdCBpbnB1dCA9IGlucHV0c1t6XVt5XVt4XTtcbiAgICAgICAgICAgICAgICBpZiAoaW5wdXQgPiBtYXhJbnB1dCkge1xuICAgICAgICAgICAgICAgICAgICBtYXhJbnB1dCA9IGlucHV0O1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIH1cbiAgICByZXR1cm4gbWF4SW5wdXQ7XG59XG5mdW5jdGlvbiBnZXRTdW0yRChpbnB1dHMpIHtcbiAgICBsZXQgc3VtID0gMDtcbiAgICBmb3IgKGxldCB5ID0gMDsgeSA8IHRoaXMuY29uc3RhbnRzLmlucHV0SGVpZ2h0OyB5KyspIHtcbiAgICAgICAgZm9yIChsZXQgeCA9IDA7IHggPCB0aGlzLmNvbnN0YW50cy5pbnB1dFdpZHRoOyB4KyspIHtcbiAgICAgICAgICAgIHN1bSArPSBpbnB1dHNbeV1beF07XG4gICAgICAgIH1cbiAgICB9XG4gICAgcmV0dXJuIHN1bTtcbn1cbmZ1bmN0aW9uIGdldFN1bTNEKGlucHV0cykge1xuICAgIGxldCBzdW0gPSAwO1xuICAgIGZvciAobGV0IHogPSAwOyB6IDwgdGhpcy5jb25zdGFudHMuaW5wdXREZXB0aDsgeisrKSB7XG4gICAgICAgIGZvciAobGV0IHkgPSAwOyB5IDwgdGhpcy5jb25zdGFudHMuaW5wdXRIZWlnaHQ7IHkrKykge1xuICAgICAgICAgICAgZm9yIChsZXQgeCA9IDA7IHggPCB0aGlzLmNvbnN0YW50cy5pbnB1dFdpZHRoOyB4KyspIHtcbiAgICAgICAgICAgICAgICBzdW0gKz0gaW5wdXRzW3pdW3ldW3hdO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfVxuICAgIHJldHVybiBzdW07XG59XG5mdW5jdGlvbiBnZXRFeHBvbmVudGlhbHMoaW5wdXRzLCBtYXhJbnB1dCkge1xuICAgIHJldHVybiBNYXRoLmV4cChpbnB1dHNbdGhpcy50aHJlYWQueF0gLSBtYXhJbnB1dFswXSk7XG59XG5mdW5jdGlvbiBnZXRFeHBvbmVudGlhbHMzRChpbnB1dHMsIG1heElucHV0KSB7XG4gICAgcmV0dXJuIE1hdGguZXhwKGlucHV0c1t0aGlzLnRocmVhZC56XVt0aGlzLnRocmVhZC55XVt0aGlzLnRocmVhZC54XSAtIG1heElucHV0WzBdKTtcbn1cbmZ1bmN0aW9uIHByZWRpY3QyRChleHBvbmVudGlhbHMsIGV4cG9uZW50aWFsc1N1bSkge1xuICAgIHJldHVybiBleHBvbmVudGlhbHNbdGhpcy50aHJlYWQueV1bdGhpcy50aHJlYWQueF0gLyBleHBvbmVudGlhbHNTdW1bMF07XG59XG5mdW5jdGlvbiBwcmVkaWN0M0QoZXhwb25lbnRpYWxzLCBleHBvbmVudGlhbHNTdW0pIHtcbiAgICByZXR1cm4gKGV4cG9uZW50aWFsc1t0aGlzLnRocmVhZC56XVt0aGlzLnRocmVhZC55XVt0aGlzLnRocmVhZC54XSAvXG4gICAgICAgIGV4cG9uZW50aWFsc1N1bVswXSk7XG59XG5mdW5jdGlvbiBjb21wYXJlMkQodGFyZ2V0LCBleHBvbmVudGlhbHMpIHtcbiAgICBsZXQgaW5kaWNhdG9yID0gMDtcbiAgICBjb25zdCBpbmRleCA9IHRoaXMudGhyZWFkLnggKyB0aGlzLnRocmVhZC55ICogdGhpcy5vdXRwdXQueDtcbiAgICBpZiAoaW5kZXggPT09IHRhcmdldCkge1xuICAgICAgICBpbmRpY2F0b3IgPSAxO1xuICAgIH1cbiAgICByZXR1cm4gLShpbmRpY2F0b3IgLSBleHBvbmVudGlhbHNbdGhpcy50aHJlYWQueV1bdGhpcy50aHJlYWQueF0pO1xufVxuZnVuY3Rpb24gY29tcGFyZTNEKHRhcmdldCwgZXhwb25lbnRpYWxzKSB7XG4gICAgbGV0IGluZGljYXRvciA9IDA7XG4gICAgY29uc3QgaW5kZXggPSB0aGlzLnRocmVhZC54ICtcbiAgICAgICAgdGhpcy50aHJlYWQueSAqIHRoaXMub3V0cHV0LnggK1xuICAgICAgICB0aGlzLnRocmVhZC56ICogdGhpcy5vdXRwdXQueCAqIHRoaXMub3V0cHV0Lnk7XG4gICAgaWYgKGluZGV4ID09PSB0YXJnZXQpIHtcbiAgICAgICAgaW5kaWNhdG9yID0gMTtcbiAgICB9XG4gICAgcmV0dXJuIC0oaW5kaWNhdG9yIC0gZXhwb25lbnRpYWxzW3RoaXMudGhyZWFkLnpdW3RoaXMudGhyZWFkLnldW3RoaXMudGhyZWFkLnhdKTtcbn1cbi8vIFRPRE86IGhhbmRsZTogYHJldHVybiAtTWF0aC5sb2codGhpcy5lc1t5XSk7YCBpbiBsZWFyblxuY2xhc3MgU29mdE1heCBleHRlbmRzIE1vZGlmaWVyIHtcbiAgICBjb25zdHJ1Y3RvcihpbnB1dExheWVyLCBzZXR0aW5ncykge1xuICAgICAgICBzdXBlcihpbnB1dExheWVyLCBzZXR0aW5ncyk7XG4gICAgICAgIHRoaXMuZXJyb3JzID0gbnVsbDtcbiAgICAgICAgdGhpcy5nZXRFeHBvbmVudGlhbHNLZXJuZWwgPSBudWxsO1xuICAgICAgICB0aGlzLmdldE1heFZhbHVlS2VybmVsID0gbnVsbDtcbiAgICAgICAgdGhpcy5nZXRTdW1LZXJuZWwgPSBudWxsO1xuICAgICAgICB0aGlzLnZhbGlkYXRlKCk7XG4gICAgICAgIGlmICh0aGlzLmRlcHRoID4gMCkge1xuICAgICAgICAgICAgdGhpcy53ZWlnaHRzID0gcmFuZG9zM0QodGhpcy53aWR0aCwgdGhpcy5oZWlnaHQsIHRoaXMuZGVwdGgpO1xuICAgICAgICAgICAgdGhpcy5kZWx0YXMgPSB6ZXJvczNEKHRoaXMud2lkdGgsIHRoaXMuaGVpZ2h0LCB0aGlzLmRlcHRoKTtcbiAgICAgICAgfVxuICAgICAgICBlbHNlIGlmICh0aGlzLmhlaWdodCA+IDApIHtcbiAgICAgICAgICAgIHRoaXMud2VpZ2h0cyA9IHJhbmRvczJEKHRoaXMud2lkdGgsIHRoaXMuaGVpZ2h0KTtcbiAgICAgICAgICAgIHRoaXMuZGVsdGFzID0gemVyb3MyRCh0aGlzLndpZHRoLCB0aGlzLmhlaWdodCk7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICB0aGlzLndlaWdodHMgPSByYW5kb3ModGhpcy53aWR0aCk7XG4gICAgICAgICAgICB0aGlzLmRlbHRhcyA9IHplcm9zJDEodGhpcy53aWR0aCk7XG4gICAgICAgIH1cbiAgICB9XG4gICAgc2V0dXBLZXJuZWxzKCkge1xuICAgICAgICBjb25zdCB7IHdpZHRoLCBoZWlnaHQsIGRlcHRoIH0gPSB0aGlzO1xuICAgICAgICBpZiAoZGVwdGggPiAwKSB7XG4gICAgICAgICAgICB0aGlzLmdldEV4cG9uZW50aWFsc0tlcm5lbCA9IG1ha2VLZXJuZWwoZ2V0RXhwb25lbnRpYWxzM0QsIHtcbiAgICAgICAgICAgICAgICBvdXRwdXQ6IFt3aWR0aCwgaGVpZ2h0LCBkZXB0aF0sXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIHRoaXMuZ2V0TWF4VmFsdWVLZXJuZWwgPSBtYWtlS2VybmVsKGdldE1heFZhbHVlM0QsIHtcbiAgICAgICAgICAgICAgICBvdXRwdXQ6IFsxLCAxLCAxXSxcbiAgICAgICAgICAgICAgICBjb25zdGFudHM6IHtcbiAgICAgICAgICAgICAgICAgICAgaW5wdXRXaWR0aDogd2lkdGgsXG4gICAgICAgICAgICAgICAgICAgIGlucHV0SGVpZ2h0OiBoZWlnaHQsXG4gICAgICAgICAgICAgICAgICAgIGlucHV0RGVwdGg6IGRlcHRoLFxuICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIHRoaXMuZ2V0U3VtS2VybmVsID0gbWFrZUtlcm5lbChnZXRTdW0zRCwge1xuICAgICAgICAgICAgICAgIG91dHB1dDogWzEsIDEsIDFdLFxuICAgICAgICAgICAgICAgIGNvbnN0YW50czoge1xuICAgICAgICAgICAgICAgICAgICBpbnB1dFdpZHRoOiB3aWR0aCxcbiAgICAgICAgICAgICAgICAgICAgaW5wdXRIZWlnaHQ6IGhlaWdodCxcbiAgICAgICAgICAgICAgICAgICAgaW5wdXREZXB0aDogZGVwdGgsXG4gICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgdGhpcy5wcmVkaWN0S2VybmVsID0gbWFrZUtlcm5lbChwcmVkaWN0M0QsIHtcbiAgICAgICAgICAgICAgICBvdXRwdXQ6IFt3aWR0aCwgaGVpZ2h0LCBkZXB0aF0sXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIHRoaXMuY29tcGFyZUtlcm5lbCA9IG1ha2VLZXJuZWwoY29tcGFyZTNELCB7XG4gICAgICAgICAgICAgICAgb3V0cHV0OiBbd2lkdGgsIGhlaWdodCwgZGVwdGhdLFxuICAgICAgICAgICAgICAgIGltbXV0YWJsZTogdHJ1ZSxcbiAgICAgICAgICAgIH0pO1xuICAgICAgICB9XG4gICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgdGhpcy5nZXRFeHBvbmVudGlhbHNLZXJuZWwgPSBtYWtlS2VybmVsKGdldEV4cG9uZW50aWFscywge1xuICAgICAgICAgICAgICAgIG91dHB1dDogW3dpZHRoLCBoZWlnaHRdLFxuICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICB0aGlzLmdldE1heFZhbHVlS2VybmVsID0gbWFrZUtlcm5lbChnZXRNYXhWYWx1ZTJELCB7XG4gICAgICAgICAgICAgICAgb3V0cHV0OiBbMSwgMV0sXG4gICAgICAgICAgICAgICAgY29uc3RhbnRzOiB7XG4gICAgICAgICAgICAgICAgICAgIGlucHV0V2lkdGg6IHdpZHRoLFxuICAgICAgICAgICAgICAgICAgICBpbnB1dEhlaWdodDogaGVpZ2h0LFxuICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIHRoaXMuZ2V0U3VtS2VybmVsID0gbWFrZUtlcm5lbChnZXRTdW0yRCwge1xuICAgICAgICAgICAgICAgIG91dHB1dDogWzEsIDFdLFxuICAgICAgICAgICAgICAgIGNvbnN0YW50czoge1xuICAgICAgICAgICAgICAgICAgICBpbnB1dFdpZHRoOiB3aWR0aCxcbiAgICAgICAgICAgICAgICAgICAgaW5wdXRIZWlnaHQ6IGhlaWdodCxcbiAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICB0aGlzLnByZWRpY3RLZXJuZWwgPSBtYWtlS2VybmVsKHByZWRpY3QyRCwge1xuICAgICAgICAgICAgICAgIG91dHB1dDogW3dpZHRoLCBoZWlnaHRdLFxuICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICB0aGlzLmNvbXBhcmVLZXJuZWwgPSBtYWtlS2VybmVsKGNvbXBhcmUyRCwge1xuICAgICAgICAgICAgICAgIG91dHB1dDogW3dpZHRoLCBoZWlnaHRdLFxuICAgICAgICAgICAgICAgIGltbXV0YWJsZTogdHJ1ZSxcbiAgICAgICAgICAgIH0pO1xuICAgICAgICB9XG4gICAgfVxuICAgIHByZWRpY3QoKSB7XG4gICAgICAgIGNvbnN0IG1heFZhbHVlID0gdGhpcy5nZXRNYXhWYWx1ZUtlcm5lbCh0aGlzLmlucHV0TGF5ZXIud2VpZ2h0cyk7XG4gICAgICAgIGNvbnN0IGV4cG9uZW50aWFscyA9IHRoaXMuZ2V0RXhwb25lbnRpYWxzS2VybmVsKHRoaXMuaW5wdXRMYXllci53ZWlnaHRzLCBtYXhWYWx1ZSk7XG4gICAgICAgIGNvbnN0IGV4cG9uZW50aWFsc1N1bSA9IHRoaXMuZ2V0U3VtS2VybmVsKGV4cG9uZW50aWFscyk7XG4gICAgICAgIHRoaXMud2VpZ2h0cyA9IHRoaXMucHJlZGljdEtlcm5lbChleHBvbmVudGlhbHMsIGV4cG9uZW50aWFsc1N1bSk7XG4gICAgfVxuICAgIGNvbXBhcmUodGFyZ2V0VmFsdWVzKSB7XG4gICAgICAgIGNvbnN0IHsgZGVsdGFzLCBlcnJvcnMgfSA9IHRoaXM7XG4gICAgICAgIHRoaXMuZXJyb3JzID0gdGhpcy5jb21wYXJlS2VybmVsKHRhcmdldFZhbHVlc1swXSwgZGVsdGFzKTtcbiAgICAgICAgdGhpcy5kZWx0YXMgPSBjbG9uZSh0aGlzLmVycm9ycyk7XG4gICAgICAgIHJlbGVhc2UoZGVsdGFzKTtcbiAgICAgICAgcmVsZWFzZShlcnJvcnMpO1xuICAgICAgICBjb25zdCBpbnB1dExheWVyRGVsdGFzID0gdGhpcy5pbnB1dExheWVyLmRlbHRhcztcbiAgICAgICAgdGhpcy5pbnB1dExheWVyLmRlbHRhcyA9IGNsb25lKHRoaXMuZGVsdGFzKTtcbiAgICAgICAgcmVsZWFzZShpbnB1dExheWVyRGVsdGFzKTtcbiAgICB9XG59XG5mdW5jdGlvbiBzb2Z0TWF4KGlucHV0TGF5ZXIsIHNldHRpbmdzKSB7XG4gICAgcmV0dXJuIG5ldyBTb2Z0TWF4KGlucHV0TGF5ZXIsIHNldHRpbmdzKTtcbn1cblxuY2xhc3MgU1ZNIGV4dGVuZHMgQmFzZUxheWVyIHtcbiAgICBjb25zdHJ1Y3RvcihpbnB1dExheWVyLCBzZXR0aW5ncykge1xuICAgICAgICBzdXBlcihzZXR0aW5ncyk7XG4gICAgICAgIHRoaXMuaW5wdXRMYXllciA9IGlucHV0TGF5ZXI7XG4gICAgfVxuICAgIHByZWRpY3QoKSB7XG4gICAgICAgIHJlbGVhc2UodGhpcy53ZWlnaHRzKTtcbiAgICAgICAgdGhpcy53ZWlnaHRzID0gY2xvbmUodGhpcy5pbnB1dExheWVyLndlaWdodHMpO1xuICAgICAgICB0aGlzLnZhbGlkYXRlKCk7XG4gICAgfVxuICAgIGxlYXJuKCkge1xuICAgICAgICAvLyB0aHJvdyBuZXcgRXJyb3IoYCR7dGhpcy5jb25zdHJ1Y3Rvci5uYW1lfS1sZWFybiBpcyBub3QgeWV0IGltcGxlbWVudGVkYClcbiAgICB9XG59XG4vLyBmdW5jdGlvbiBsZWFybih0YXJnZXQpIHtcbi8vICAgaWYgKHkgPT09IGkpIHtcbi8vICAgICBjb250aW51ZTtcbi8vICAgfVxuLy8gICBjb25zdCB5ZGlmZiA9IC15c2NvcmUgKyB4LndbaV0gKyBtYXJnaW47XG4vLyAgIGlmICh5ZGlmZiA+IDApIHtcbi8vICAgICAvLyB2aW9sYXRpbmcgZGltZW5zaW9uLCBhcHBseSBsb3NzXG4vLyAgICAgeC5kd1tpXSArPSAxO1xuLy8gICAgIHguZHdbeV0gLT0gMTtcbi8vICAgICBsb3NzICs9IHlkaWZmO1xuLy8gICB9XG4vLyB9XG5mdW5jdGlvbiBzdm0oaW5wdXRMYXllciwgc2V0dGluZ3MpIHtcbiAgICByZXR1cm4gbmV3IFNWTShpbnB1dExheWVyLCBzZXR0aW5ncyk7XG59XG5cbmZ1bmN0aW9uIHByZWRpY3QodmFsdWUpIHtcbiAgICByZXR1cm4gdmFsdWVbdGhpcy50aHJlYWQueF1bdGhpcy50aHJlYWQueV07XG59XG5jb25zdCBjb21wYXJlID0gcHJlZGljdDtcbmNsYXNzIFRyYW5zcG9zZSBleHRlbmRzIE1vZGlmaWVyIHtcbiAgICBnZXQgd2lkdGgoKSB7XG4gICAgICAgIHJldHVybiB0aGlzLmlucHV0TGF5ZXIuaGVpZ2h0O1xuICAgIH1cbiAgICBnZXQgaGVpZ2h0KCkge1xuICAgICAgICByZXR1cm4gdGhpcy5pbnB1dExheWVyLndpZHRoO1xuICAgIH1cbiAgICBjb25zdHJ1Y3RvcihpbnB1dExheWVyKSB7XG4gICAgICAgIHN1cGVyKGlucHV0TGF5ZXIpO1xuICAgICAgICB0aGlzLnZhbGlkYXRlKCk7XG4gICAgfVxuICAgIHNldHVwS2VybmVscygpIHtcbiAgICAgICAgdGhpcy5wcmVkaWN0S2VybmVsID0gbWFrZUtlcm5lbChwcmVkaWN0LCB7XG4gICAgICAgICAgICBvdXRwdXQ6IFt0aGlzLmhlaWdodCwgdGhpcy53aWR0aF0sXG4gICAgICAgIH0pO1xuICAgICAgICB0aGlzLmNvbXBhcmVLZXJuZWwgPSBtYWtlS2VybmVsKGNvbXBhcmUsIHtcbiAgICAgICAgICAgIG91dHB1dDogW3RoaXMud2lkdGgsIHRoaXMuaGVpZ2h0XSxcbiAgICAgICAgfSk7XG4gICAgfVxuICAgIHByZWRpY3QoKSB7XG4gICAgICAgIHRoaXMud2VpZ2h0cyA9IHRoaXMucHJlZGljdEtlcm5lbCh0aGlzLmlucHV0TGF5ZXIud2VpZ2h0cyk7XG4gICAgICAgIGNsZWFyKHRoaXMuZGVsdGFzKTtcbiAgICB9XG4gICAgY29tcGFyZSgpIHtcbiAgICAgICAgdGhpcy5pbnB1dExheWVyLmRlbHRhcyA9IHRoaXMuY29tcGFyZUtlcm5lbCh0aGlzLmRlbHRhcyk7XG4gICAgfVxufVxuZnVuY3Rpb24gdHJhbnNwb3NlKGlucHV0TGF5ZXIpIHtcbiAgICByZXR1cm4gbmV3IFRyYW5zcG9zZShpbnB1dExheWVyKTtcbn1cblxuY29uc3QgbGF5ZXJUeXBlcyA9IHtcbiAgICBBY3RpdmF0aW9uLFxuICAgIEludGVybmFsLFxuICAgIEludGVybmFsTW9kZWwsXG4gICAgRW50cnlQb2ludCxcbiAgICBGaWx0ZXIsXG4gICAgTW9kZWwsXG4gICAgTW9kaWZpZXIsXG4gICAgT3BlcmF0b3IsXG4gICAgVGFyZ2V0LFxufTtcblxudmFyIGxheWVyID0gLyojX19QVVJFX18qL09iamVjdC5mcmVlemUoe1xuICAgIF9fcHJvdG9fXzogbnVsbCxcbiAgICBsYXllclR5cGVzOiBsYXllclR5cGVzLFxuICAgIEFkZDogQWRkLFxuICAgIGFkZDogYWRkJDEsXG4gICAgYXJ0aHVyRmVlZEZvcndhcmQ6IGFydGh1ckZlZWRGb3J3YXJkLFxuICAgIEJhc2VMYXllcjogQmFzZUxheWVyLFxuICAgIGJhc2VMYXllckRlZmF1bHRTZXR0aW5nczogYmFzZUxheWVyRGVmYXVsdFNldHRpbmdzLFxuICAgIENvbnZvbHV0aW9uOiBDb252b2x1dGlvbixcbiAgICBjb252b2x1dGlvbjogY29udm9sdXRpb24sXG4gICAgRHJvcG91dDogRHJvcG91dCxcbiAgICBkcm9wb3V0OiBkcm9wb3V0LFxuICAgIGZlZWRGb3J3YXJkOiBmZWVkRm9yd2FyZCxcbiAgICBGdWxseUNvbm5lY3RlZDogRnVsbHlDb25uZWN0ZWQsXG4gICAgZnVsbHlDb25uZWN0ZWQ6IGZ1bGx5Q29ubmVjdGVkLFxuICAgIGdydTogZ3J1LFxuICAgIElucHV0OiBJbnB1dCxcbiAgICBpbnB1dDogaW5wdXQsXG4gICAgTGVha3lSZWx1OiBMZWFreVJlbHUsXG4gICAgbGVha3lSZWx1OiBsZWFreVJlbHUsXG4gICAgbHN0bUNlbGw6IGxzdG1DZWxsLFxuICAgIE11bHRpcGx5OiBNdWx0aXBseSxcbiAgICBtdWx0aXBseTogbXVsdGlwbHkkMSxcbiAgICBNdWx0aXBseUVsZW1lbnQ6IE11bHRpcGx5RWxlbWVudCxcbiAgICBtdWx0aXBseUVsZW1lbnQ6IG11bHRpcGx5RWxlbWVudCQxLFxuICAgIE5lZ2F0aXZlOiBOZWdhdGl2ZSxcbiAgICBuZWdhdGl2ZTogbmVnYXRpdmUsXG4gICAgT25lczogT25lcyxcbiAgICBvbmVzOiBvbmVzLFxuICAgIG91dHB1dDogb3V0cHV0LFxuICAgIFBvb2w6IFBvb2wsXG4gICAgcG9vbDogcG9vbCxcbiAgICBSYW5kb206IFJhbmRvbSxcbiAgICByYW5kb206IHJhbmRvbSxcbiAgICBSZWN1cnJlbnRJbnB1dDogUmVjdXJyZW50SW5wdXQsXG4gICAgUmVjdXJyZW50WmVyb3M6IFJlY3VycmVudFplcm9zLFxuICAgIHJubkNlbGw6IHJubkNlbGwsXG4gICAgUmVncmVzc2lvbjogUmVncmVzc2lvbixcbiAgICByZWdyZXNzaW9uOiByZWdyZXNzaW9uLFxuICAgIFJlbHU6IFJlbHUsXG4gICAgcmVsdTogcmVsdSQxLFxuICAgIFNpZ21vaWQ6IFNpZ21vaWQsXG4gICAgc2lnbW9pZDogc2lnbW9pZCQxLFxuICAgIFNvZnRNYXg6IFNvZnRNYXgsXG4gICAgc29mdE1heDogc29mdE1heCxcbiAgICBTVk06IFNWTSxcbiAgICBzdm06IHN2bSxcbiAgICBUYW5oOiBUYW5oLFxuICAgIHRhbmg6IHRhbmgkMSxcbiAgICBUYXJnZXQ6IFRhcmdldCxcbiAgICB0YXJnZXQ6IHRhcmdldCxcbiAgICBUcmFuc3Bvc2U6IFRyYW5zcG9zZSxcbiAgICB0cmFuc3Bvc2U6IHRyYW5zcG9zZSxcbiAgICBaZXJvczogWmVyb3MsXG4gICAgemVyb3M6IHplcm9zXG59KTtcblxuY29uc3QgbGF5ZXJOYW1lVHlwZXMgPSBPYmplY3Qua2V5cyhsYXllcik7XG5mdW5jdGlvbiBsYXllckZyb21KU09OKGpzb25MYXllciwgaW5wdXRMYXllcjEsIGlucHV0TGF5ZXIyKSB7XG4gICAgaWYgKCFsYXllck5hbWVUeXBlcy5maW5kKChsYXllck5hbWVUeXBlKSA9PiBsYXllck5hbWVUeXBlID09PSBqc29uTGF5ZXIudHlwZSkpIHtcbiAgICAgICAgcmV0dXJuIG51bGw7XG4gICAgfVxuICAgIGNvbnN0IExheWVyID0gbGF5ZXJbanNvbkxheWVyLnR5cGVdO1xuICAgIGlmIChMYXllci5wcm90b3R5cGUgaW5zdGFuY2VvZiBsYXllclR5cGVzLkZpbHRlcikge1xuICAgICAgICBpZiAoIWlucHV0TGF5ZXIxKVxuICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdpbnB1dExheWVyIG1pc3NpbmcnKTtcbiAgICAgICAgcmV0dXJuIG5ldyBMYXllcihqc29uTGF5ZXIsIGlucHV0TGF5ZXIxKTtcbiAgICB9XG4gICAgZWxzZSBpZiAoTGF5ZXIucHJvdG90eXBlIGluc3RhbmNlb2YgbGF5ZXJUeXBlcy5BY3RpdmF0aW9uIHx8XG4gICAgICAgIExheWVyLnByb3RvdHlwZSBpbnN0YW5jZW9mIGxheWVyVHlwZXMuTW9kaWZpZXIpIHtcbiAgICAgICAgaWYgKCFpbnB1dExheWVyMSlcbiAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcignaW5wdXRMYXllciBtaXNzaW5nJyk7XG4gICAgICAgIHJldHVybiBuZXcgTGF5ZXIoaW5wdXRMYXllcjEsIGpzb25MYXllcik7XG4gICAgfVxuICAgIGVsc2UgaWYgKExheWVyLnByb3RvdHlwZSBpbnN0YW5jZW9mIGxheWVyVHlwZXMuSW50ZXJuYWwpIHtcbiAgICAgICAgcmV0dXJuIG5ldyBMYXllcihqc29uTGF5ZXIpO1xuICAgIH1cbiAgICBlbHNlIGlmIChMYXllci5wcm90b3R5cGUgaW5zdGFuY2VvZiBsYXllclR5cGVzLk9wZXJhdG9yKSB7XG4gICAgICAgIGlmICghaW5wdXRMYXllcjEpXG4gICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ2lucHV0TGF5ZXIxIG1pc3NpbmcnKTtcbiAgICAgICAgaWYgKCFpbnB1dExheWVyMilcbiAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcignaW5wdXRMYXllcjIgbWlzc2luZycpO1xuICAgICAgICByZXR1cm4gbmV3IExheWVyKGlucHV0TGF5ZXIxLCBpbnB1dExheWVyMiwganNvbkxheWVyKTtcbiAgICB9XG4gICAgZWxzZSBpZiAoTGF5ZXIucHJvdG90eXBlIGluc3RhbmNlb2YgbGF5ZXJUeXBlcy5JbnRlcm5hbE1vZGVsIHx8XG4gICAgICAgIExheWVyLnByb3RvdHlwZSBpbnN0YW5jZW9mIGxheWVyVHlwZXMuRW50cnlQb2ludCB8fFxuICAgICAgICBMYXllci5wcm90b3R5cGUgaW5zdGFuY2VvZiBsYXllclR5cGVzLk1vZGVsKSB7XG4gICAgICAgIHJldHVybiBuZXcgTGF5ZXIoanNvbkxheWVyKTtcbiAgICB9XG4gICAgZWxzZSBpZiAoTGF5ZXIgPT09IFRhcmdldCkge1xuICAgICAgICBpZiAoIWlucHV0TGF5ZXIxKVxuICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdpbnB1dExheWVyIG1pc3NpbmcnKTtcbiAgICAgICAgcmV0dXJuIG5ldyBMYXllcihqc29uTGF5ZXIsIGlucHV0TGF5ZXIxKTtcbiAgICB9XG4gICAgcmV0dXJuIG51bGw7XG59XG5cbmNsYXNzIExvb2t1cFRhYmxlIHtcbiAgICBjb25zdHJ1Y3RvcihkYXRhLCBwcm9wKSB7XG4gICAgICAgIHRoaXMucHJvcCA9IG51bGw7XG4gICAgICAgIHRoaXMudGFibGUgPSB7fTtcbiAgICAgICAgdGhpcy5sZW5ndGggPSAwO1xuICAgICAgICBjb25zdCB0YWJsZSA9IHRoaXMudGFibGU7XG4gICAgICAgIGlmIChwcm9wKSB7XG4gICAgICAgICAgICB0aGlzLnByb3AgPSBwcm9wO1xuICAgICAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBkYXRhLmxlbmd0aDsgaSsrKSB7XG4gICAgICAgICAgICAgICAgY29uc3QgZGF0dW0gPSBkYXRhW2ldO1xuICAgICAgICAgICAgICAgIGNvbnN0IG9iamVjdCA9IGRhdHVtW3Byb3BdO1xuICAgICAgICAgICAgICAgIGZvciAoY29uc3QgcCBpbiBvYmplY3QpIHtcbiAgICAgICAgICAgICAgICAgICAgaWYgKCFvYmplY3QuaGFzT3duUHJvcGVydHkocCkpXG4gICAgICAgICAgICAgICAgICAgICAgICBjb250aW51ZTtcbiAgICAgICAgICAgICAgICAgICAgaWYgKHRhYmxlLmhhc093blByb3BlcnR5KHApKVxuICAgICAgICAgICAgICAgICAgICAgICAgY29udGludWU7XG4gICAgICAgICAgICAgICAgICAgIHRhYmxlW3BdID0gdGhpcy5sZW5ndGgrKztcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSBpZiAoQXJyYXkuaXNBcnJheShkYXRhKSAmJiBBcnJheS5pc0FycmF5KGRhdGFbMF0pKSB7XG4gICAgICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IGRhdGEubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgICAgICAgICBjb25zdCBhcnJheSA9IGRhdGFbaV07XG4gICAgICAgICAgICAgICAgZm9yIChsZXQgaiA9IDA7IGogPCBhcnJheS5sZW5ndGg7IGorKykge1xuICAgICAgICAgICAgICAgICAgICBjb25zdCBvYmplY3QgPSBhcnJheVtqXTtcbiAgICAgICAgICAgICAgICAgICAgZm9yIChjb25zdCBwIGluIG9iamVjdCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKCFvYmplY3QuaGFzT3duUHJvcGVydHkocCkpXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY29udGludWU7XG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAodGFibGUuaGFzT3duUHJvcGVydHkocCkpXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY29udGludWU7XG4gICAgICAgICAgICAgICAgICAgICAgICB0YWJsZVtwXSA9IHRoaXMubGVuZ3RoKys7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IGRhdGEubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgICAgICAgICBjb25zdCBvYmplY3QgPSBkYXRhW2ldO1xuICAgICAgICAgICAgICAgIGZvciAoY29uc3QgcCBpbiBvYmplY3QpIHtcbiAgICAgICAgICAgICAgICAgICAgaWYgKCFvYmplY3QuaGFzT3duUHJvcGVydHkocCkpXG4gICAgICAgICAgICAgICAgICAgICAgICBjb250aW51ZTtcbiAgICAgICAgICAgICAgICAgICAgaWYgKHRhYmxlLmhhc093blByb3BlcnR5KHApKVxuICAgICAgICAgICAgICAgICAgICAgICAgY29udGludWU7XG4gICAgICAgICAgICAgICAgICAgIHRhYmxlW3BdID0gdGhpcy5sZW5ndGgrKztcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9XG59XG5cbmNvbnN0IGRlZmF1bHRzJDMgPSB7XG4gICAgbGVhcm5pbmdSYXRlOiAwLjMsXG4gICAgYmluYXJ5VGhyZXNoOiAwLjUsXG4gICAgaW5pdFByYXhpczogKGxheWVyVGVtcGxhdGUsIHNldHRpbmdzKSA9PiB7XG4gICAgICAgIHZhciBfYTtcbiAgICAgICAgcmV0dXJuIG1vbWVudHVtUm9vdE1lYW5TcXVhcmVkUHJvcGFnYXRpb24obGF5ZXJUZW1wbGF0ZSwgKF9hID0gbGF5ZXJUZW1wbGF0ZS5zZXR0aW5ncy5wcmF4aXNPcHRzKSAhPT0gbnVsbCAmJiBfYSAhPT0gdm9pZCAwID8gX2EgOiBzZXR0aW5ncyk7XG4gICAgfSxcbn07XG5jb25zdCB0cmFpbkRlZmF1bHRzJDMgPSB7XG4gICAgaXRlcmF0aW9uczogMjAwMDAsXG4gICAgZXJyb3JUaHJlc2g6IDAuMDA1LFxuICAgIGxvZzogZmFsc2UsXG4gICAgbG9nUGVyaW9kOiAxMCxcbiAgICBsZWFybmluZ1JhdGU6IDAuMyxcbiAgICBjYWxsYmFja1BlcmlvZDogMTAsXG4gICAgZXJyb3JDaGVja0ludGVydmFsOiAxMDAsXG4gICAgdGltZW91dDogSW5maW5pdHksXG59O1xuY2xhc3MgRmVlZEZvcndhcmQge1xuICAgIGNvbnN0cnVjdG9yKG9wdGlvbnMgPSB7fSkge1xuICAgICAgICB0aGlzLnRyYWluT3B0cyA9IHt9O1xuICAgICAgICB0aGlzLmxheWVycyA9IG51bGw7XG4gICAgICAgIHRoaXMuX2lucHV0TGF5ZXIgPSBudWxsO1xuICAgICAgICB0aGlzLl9oaWRkZW5MYXllcnMgPSBudWxsO1xuICAgICAgICB0aGlzLl9vdXRwdXRMYXllciA9IG51bGw7XG4gICAgICAgIHRoaXMuX21vZGVsID0gbnVsbDtcbiAgICAgICAgdGhpcy5tZWFuU3F1YXJlZEVycm9yID0gbnVsbDtcbiAgICAgICAgdGhpcy5pbnB1dExvb2t1cCA9IG51bGw7XG4gICAgICAgIHRoaXMuaW5wdXRMb29rdXBMZW5ndGggPSBudWxsO1xuICAgICAgICB0aGlzLm91dHB1dExvb2t1cCA9IG51bGw7XG4gICAgICAgIHRoaXMub3V0cHV0TG9va3VwTGVuZ3RoID0gbnVsbDtcbiAgICAgICAgdGhpcy5vcHRpb25zID0geyAuLi5kZWZhdWx0cyQzLCAuLi5vcHRpb25zIH07XG4gICAgICAgIHRoaXMuX3VwZGF0ZVRyYWluaW5nT3B0aW9ucyh7XG4gICAgICAgICAgICAuLi50cmFpbkRlZmF1bHRzJDMsXG4gICAgICAgICAgICAuLi5vcHRpb25zLFxuICAgICAgICB9KTtcbiAgICB9XG4gICAgc3RhdGljIF92YWxpZGF0ZVRyYWluaW5nT3B0aW9ucyhvcHRpb25zKSB7XG4gICAgICAgIGNvbnN0IHsgaXRlcmF0aW9ucywgZXJyb3JUaHJlc2gsIGxvZywgbG9nUGVyaW9kLCBsZWFybmluZ1JhdGUsIGNhbGxiYWNrLCBjYWxsYmFja1BlcmlvZCwgdGltZW91dCwgfSA9IG9wdGlvbnM7XG4gICAgICAgIGNvbnN0IHZhbGlkYXRpb25zID0ge1xuICAgICAgICAgICAgaXRlcmF0aW9uczogKCkgPT4gdHlwZW9mIGl0ZXJhdGlvbnMgPT09ICdudW1iZXInICYmIGl0ZXJhdGlvbnMgPiAwLFxuICAgICAgICAgICAgZXJyb3JUaHJlc2g6ICgpID0+IHR5cGVvZiBlcnJvclRocmVzaCA9PT0gJ251bWJlcicgJiYgZXJyb3JUaHJlc2ggPiAwICYmIGVycm9yVGhyZXNoIDwgMSxcbiAgICAgICAgICAgIGxvZzogKCkgPT4gdHlwZW9mIGxvZyA9PT0gJ2Z1bmN0aW9uJyB8fCB0eXBlb2YgbG9nID09PSAnYm9vbGVhbicsXG4gICAgICAgICAgICBsb2dQZXJpb2Q6ICgpID0+IHR5cGVvZiBsb2dQZXJpb2QgPT09ICdudW1iZXInICYmIGxvZ1BlcmlvZCA+IDAsXG4gICAgICAgICAgICBsZWFybmluZ1JhdGU6ICgpID0+IHR5cGVvZiBsZWFybmluZ1JhdGUgPT09ICdudW1iZXInICYmXG4gICAgICAgICAgICAgICAgbGVhcm5pbmdSYXRlID4gMCAmJlxuICAgICAgICAgICAgICAgIGxlYXJuaW5nUmF0ZSA8IDEsXG4gICAgICAgICAgICBjYWxsYmFjazogKCkgPT4gdHlwZW9mIGNhbGxiYWNrID09PSAnZnVuY3Rpb24nIHx8IGNhbGxiYWNrID09PSBudWxsLFxuICAgICAgICAgICAgY2FsbGJhY2tQZXJpb2Q6ICgpID0+IHR5cGVvZiBjYWxsYmFja1BlcmlvZCA9PT0gJ251bWJlcicgJiYgY2FsbGJhY2tQZXJpb2QgPiAwLFxuICAgICAgICAgICAgdGltZW91dDogKCkgPT4gdHlwZW9mIHRpbWVvdXQgPT09ICdudW1iZXInICYmIHRpbWVvdXQgPiAwLFxuICAgICAgICB9O1xuICAgICAgICBPYmplY3Qua2V5cyh0cmFpbkRlZmF1bHRzJDMpLmZvckVhY2goKGtleSkgPT4ge1xuICAgICAgICAgICAgaWYgKHZhbGlkYXRpb25zLmhhc093blByb3BlcnR5KGtleSkgJiYgIXZhbGlkYXRpb25zW2tleV0oKSkge1xuICAgICAgICAgICAgICAgIGNvbnN0IHZhbCA9IG9wdGlvbnNba2V5XTtcbiAgICAgICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoYFske2tleX0sICR7KHZhbCAhPT0gbnVsbCAmJiB2YWwgIT09IHZvaWQgMCA/IHZhbCA6ICd1bmRlZmluZWQnKS50b1N0cmluZygpfV0gaXMgb3V0IG9mIG5vcm1hbCB0cmFpbmluZyByYW5nZSwgeW91ciBuZXR3b3JrIHdpbGwgcHJvYmFibHkgbm90IHRyYWluLmApO1xuICAgICAgICAgICAgfVxuICAgICAgICB9KTtcbiAgICB9XG4gICAgLyoqXG4gICAgICogaWYgYSBtZXRob2QgaXMgcGFzc2VkIGluIG1ldGhvZCBpcyB1c2VkXG4gICAgICogaWYgZmFsc2UgcGFzc2VkIGluIG5vdGhpbmcgaXMgbG9nZ2VkXG4gICAgICovXG4gICAgX3NldExvZ01ldGhvZChsb2cpIHtcbiAgICAgICAgaWYgKHR5cGVvZiBsb2cgPT09ICdmdW5jdGlvbicpIHtcbiAgICAgICAgICAgIHRoaXMudHJhaW5PcHRzLmxvZyA9IGxvZztcbiAgICAgICAgfVxuICAgICAgICBlbHNlIGlmIChsb2cpIHtcbiAgICAgICAgICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZVxuICAgICAgICAgICAgdGhpcy50cmFpbk9wdHMubG9nID0gY29uc29sZS5sb2c7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICB0aGlzLnRyYWluT3B0cy5sb2cgPSBmYWxzZTtcbiAgICAgICAgfVxuICAgIH1cbiAgICBfdXBkYXRlVHJhaW5pbmdPcHRpb25zKG9wdHMpIHtcbiAgICAgICAgdmFyIF9hO1xuICAgICAgICB0aGlzLnRyYWluT3B0cyA9IHsgLi4udHJhaW5EZWZhdWx0cyQzLCAuLi50aGlzLnRyYWluT3B0cywgLi4ub3B0cyB9O1xuICAgICAgICBGZWVkRm9yd2FyZC5fdmFsaWRhdGVUcmFpbmluZ09wdGlvbnModGhpcy50cmFpbk9wdHMpO1xuICAgICAgICB0aGlzLl9zZXRMb2dNZXRob2QoKF9hID0gb3B0cy5sb2cpICE9PSBudWxsICYmIF9hICE9PSB2b2lkIDAgPyBfYSA6IHRoaXMudHJhaW5PcHRzLmxvZyk7XG4gICAgICAgIGNvbnN0IHsgY2FsbGJhY2ssIGNhbGxiYWNrUGVyaW9kLCBlcnJvckNoZWNrSW50ZXJ2YWwgfSA9IHRoaXMudHJhaW5PcHRzO1xuICAgICAgICBpZiAoY2FsbGJhY2sgJiYgY2FsbGJhY2tQZXJpb2QgIT09IGVycm9yQ2hlY2tJbnRlcnZhbCkge1xuICAgICAgICAgICAgY29uc29sZS53YXJuKGBvcHRpb25zLmNhbGxiYWNrUGVyaW9kIHdpdGggdmFsdWUgb2YgJHsoY2FsbGJhY2tQZXJpb2QgIT09IG51bGwgJiYgY2FsbGJhY2tQZXJpb2QgIT09IHZvaWQgMCA/IGNhbGxiYWNrUGVyaW9kIDogJ3VuZGVmaW5lZCcpLnRvU3RyaW5nKCl9IGRvZXMgbm90IG1hdGNoIG9wdGlvbnMuZXJyb3JDaGVja0ludGVydmFsIHdpdGggdmFsdWUgb2YgJHsoZXJyb3JDaGVja0ludGVydmFsICE9PSBudWxsICYmIGVycm9yQ2hlY2tJbnRlcnZhbCAhPT0gdm9pZCAwID8gZXJyb3JDaGVja0ludGVydmFsIDogJ3VuZGVmaW5lZCcpLnRvU3RyaW5nKCl9LCBpZiBsb2dnaW5nIGVycm9yLCBpdCB3aWxsIHJlcGVhdC4gIFRoZXNlIHZhbHVlcyBtYXkgbmVlZCB0byBtYXRjaGApO1xuICAgICAgICB9XG4gICAgfVxuICAgIF9jb25uZWN0T3B0aW9uc0xheWVycygpIHtcbiAgICAgICAgY29uc3QgeyBpbnB1dExheWVySW5kZXgsIG91dHB1dExheWVySW5kZXgsIGxheWVycyB9ID0gdGhpcy5vcHRpb25zO1xuICAgICAgICBpZiAoIWxheWVycylcbiAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcigndGhpcy5vcHRpb25zLmxheWVycyBpbiB1bmV4cGVjdGVkIHN0YXRlJyk7XG4gICAgICAgIGlmICh0eXBlb2YgaW5wdXRMYXllckluZGV4ICE9PSAnbnVtYmVyJylcbiAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcignaW5wdXRMYXllckluZGV4IG5vdCBhIG51bWJlcicpO1xuICAgICAgICBpZiAodHlwZW9mIG91dHB1dExheWVySW5kZXggIT09ICdudW1iZXInKVxuICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdpbnB1dExheWVySW5kZXggbm90IGEgbnVtYmVyJyk7XG4gICAgICAgIGNvbnN0IGlucHV0TGF5ZXIgPSBsYXllcnNbaW5wdXRMYXllckluZGV4XTtcbiAgICAgICAgaWYgKCFpbnB1dExheWVyKSB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ2lucHV0TGF5ZXIgbm90IGZvdW5kIGluIHRoaXMub3B0aW9ucy5sYXllcnMnKTtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCBvdXRwdXRMYXllciA9IGxheWVyc1tvdXRwdXRMYXllckluZGV4XTtcbiAgICAgICAgaWYgKCFvdXRwdXRMYXllcikge1xuICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdvdXRwdXRMYXllciBub3QgZm91bmQgaW4gdGhpcy5vcHRpb25zLmxheWVycycpO1xuICAgICAgICB9XG4gICAgICAgIHRoaXMuX2lucHV0TGF5ZXIgPSBpbnB1dExheWVyO1xuICAgICAgICB0aGlzLl9oaWRkZW5MYXllcnMgPSBsYXllcnMuc2xpY2UoaW5wdXRMYXllckluZGV4LCBvdXRwdXRMYXllckluZGV4IC0gaW5wdXRMYXllckluZGV4KTtcbiAgICAgICAgdGhpcy5fb3V0cHV0TGF5ZXIgPSBvdXRwdXRMYXllcjtcbiAgICAgICAgcmV0dXJuIGxheWVycztcbiAgICB9XG4gICAgX2Nvbm5lY3ROZXdMYXllcnMoKSB7XG4gICAgICAgIGNvbnN0IHsgaW5wdXRMYXllciwgb3V0cHV0TGF5ZXIgfSA9IHRoaXMub3B0aW9ucztcbiAgICAgICAgaWYgKCFpbnB1dExheWVyKVxuICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdpbnB1dExheWVyIG5vdCBkZWZpbmVkJyk7XG4gICAgICAgIGNvbnN0IGxheWVycyA9IFtdO1xuICAgICAgICB0aGlzLl9pbnB1dExheWVyID0gaW5wdXRMYXllcigpO1xuICAgICAgICBjb25zdCBoaWRkZW5MYXllcnMgPSB0aGlzLl9jb25uZWN0SGlkZGVuTGF5ZXJzKHRoaXMuX2lucHV0TGF5ZXIpO1xuICAgICAgICBpZiAoIW91dHB1dExheWVyKVxuICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdvdXRwdXRMYXllciBub3QgZGVmaW5lZCcpO1xuICAgICAgICB0aGlzLl9vdXRwdXRMYXllciA9IG91dHB1dExheWVyKGhpZGRlbkxheWVyc1toaWRkZW5MYXllcnMubGVuZ3RoIC0gMV0sIGhpZGRlbkxheWVycy5sZW5ndGgpO1xuICAgICAgICBsYXllcnMucHVzaCh0aGlzLl9pbnB1dExheWVyKTtcbiAgICAgICAgbGF5ZXJzLnB1c2goLi4uaGlkZGVuTGF5ZXJzKTtcbiAgICAgICAgbGF5ZXJzLnB1c2godGhpcy5fb3V0cHV0TGF5ZXIpO1xuICAgICAgICByZXR1cm4gZmxhdHRlbkxheWVycyhsYXllcnMpO1xuICAgIH1cbiAgICBfY29ubmVjdEhpZGRlbkxheWVycyhwcmV2aW91c0xheWVyKSB7XG4gICAgICAgIHRoaXMuX2hpZGRlbkxheWVycyA9IFtdO1xuICAgICAgICBjb25zdCByZXN1bHQgPSBbXTtcbiAgICAgICAgY29uc3QgeyBoaWRkZW5MYXllcnMgfSA9IHRoaXMub3B0aW9ucztcbiAgICAgICAgaWYgKCFoaWRkZW5MYXllcnMpXG4gICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ2hpZGRlbkxheWVycyBub3QgZGVmaW5lZCcpO1xuICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IGhpZGRlbkxheWVycy5sZW5ndGg7IGkrKykge1xuICAgICAgICAgICAgY29uc3QgaGlkZGVuTGF5ZXIgPSBoaWRkZW5MYXllcnNbaV0ocHJldmlvdXNMYXllciwgaSk7XG4gICAgICAgICAgICByZXN1bHQucHVzaChoaWRkZW5MYXllcik7XG4gICAgICAgICAgICB0aGlzLl9oaWRkZW5MYXllcnMucHVzaChoaWRkZW5MYXllcik7XG4gICAgICAgICAgICBwcmV2aW91c0xheWVyID0gaGlkZGVuTGF5ZXI7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHJlc3VsdDtcbiAgICB9XG4gICAgaW5pdGlhbGl6ZSgpIHtcbiAgICAgICAgdGhpcy5sYXllcnMgPSB0aGlzLm9wdGlvbnMubGF5ZXJzXG4gICAgICAgICAgICA/IHRoaXMuX2Nvbm5lY3RPcHRpb25zTGF5ZXJzKClcbiAgICAgICAgICAgIDogdGhpcy5fY29ubmVjdE5ld0xheWVycygpO1xuICAgICAgICB0aGlzLmluaXRpYWxpemVMYXllcnModGhpcy5sYXllcnMpO1xuICAgICAgICB0aGlzLl9tb2RlbCA9IHRoaXMubGF5ZXJzLmZpbHRlcigobCkgPT4gbCBpbnN0YW5jZW9mIE1vZGVsKTtcbiAgICB9XG4gICAgaW5pdGlhbGl6ZUxheWVycyhsYXllcnMpIHtcbiAgICAgICAgdmFyIF9hLCBfYjtcbiAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBsYXllcnMubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgICAgIGNvbnN0IGxheWVyID0gbGF5ZXJzW2ldO1xuICAgICAgICAgICAgLy8gVE9ETzogb3B0aW1pemUgZm9yIHdoZW4gdHJhaW5pbmcgb3IganVzdCBydW5uaW5nXG4gICAgICAgICAgICBsYXllci5zZXR1cEtlcm5lbHModHJ1ZSk7XG4gICAgICAgICAgICBpZiAobGF5ZXIgaW5zdGFuY2VvZiBNb2RlbCAmJlxuICAgICAgICAgICAgICAgIGxheWVyLnByYXhpcyA9PT0gbnVsbCAmJlxuICAgICAgICAgICAgICAgIHR5cGVvZiB0aGlzLm9wdGlvbnMuaW5pdFByYXhpcyA9PT0gJ2Z1bmN0aW9uJykge1xuICAgICAgICAgICAgICAgIGxheWVyLnByYXhpcyA9IHRoaXMub3B0aW9ucy5pbml0UHJheGlzKGxheWVyLCAoX2IgPSAoX2EgPSBsYXllci5zZXR0aW5ncy5wcmF4aXNPcHRzKSAhPT0gbnVsbCAmJiBfYSAhPT0gdm9pZCAwID8gX2EgOiB0aGlzLm9wdGlvbnMucHJheGlzT3B0cykgIT09IG51bGwgJiYgX2IgIT09IHZvaWQgMCA/IF9iIDoge30pO1xuICAgICAgICAgICAgICAgIGxheWVyLnByYXhpcy5zZXR1cEtlcm5lbHMoKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBjb25zdCBsYXN0TGF5ZXIgPSBsYXllcnNbbGF5ZXJzLmxlbmd0aCAtIDFdO1xuICAgICAgICB0aGlzLm1lYW5TcXVhcmVkRXJyb3IgPSBuZXcgTWVhblNxdWFyZWRFcnJvcih7XG4gICAgICAgICAgICB3aWR0aDogbGFzdExheWVyLndpZHRoLFxuICAgICAgICAgICAgaGVpZ2h0OiBsYXN0TGF5ZXIuaGVpZ2h0LFxuICAgICAgICB9KTtcbiAgICB9XG4gICAgcnVuKGlucHV0KSB7XG4gICAgICAgIGxldCB0eXBlU2FmZUlucHV0O1xuICAgICAgICBpZiAoQXJyYXkuaXNBcnJheShpbnB1dCkgfHwgaW5wdXQuYnVmZmVyKSB7XG4gICAgICAgICAgICB0eXBlU2FmZUlucHV0ID0gaW5wdXQ7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICBpZiAodGhpcy5pbnB1dExvb2t1cCkge1xuICAgICAgICAgICAgICAgIHR5cGVTYWZlSW5wdXQgPSBsb29rdXAudG9BcnJheSh0aGlzLmlucHV0TG9va3VwLCBpbnB1dCwgdGhpcy5pbnB1dExvb2t1cExlbmd0aCk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ2lucHV0IGlzIGluY29tcGF0aWJsZSB3aXRoIG5ldCcpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIGxldCBvdXRwdXQgPSB0aGlzLnJ1bklucHV0KHR5cGVTYWZlSW5wdXQpO1xuICAgICAgICBpZiAob3V0cHV0IGluc3RhbmNlb2YgZ3B1X2pzLlRleHR1cmUpIHtcbiAgICAgICAgICAgIG91dHB1dCA9IG91dHB1dC50b0FycmF5KCk7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKHRoaXMub3V0cHV0TG9va3VwKSB7XG4gICAgICAgICAgICByZXR1cm4gbG9va3VwLnRvT2JqZWN0KHRoaXMub3V0cHV0TG9va3VwLCBvdXRwdXQpO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBvdXRwdXQ7XG4gICAgfVxuICAgIHJ1bklucHV0KGlucHV0KSB7XG4gICAgICAgIGlmICghdGhpcy5sYXllcnMpXG4gICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ25vdCBpbml0aWFsaXplZCcpO1xuICAgICAgICB0aGlzLmxheWVyc1swXS5wcmVkaWN0KGlucHV0KTtcbiAgICAgICAgZm9yIChsZXQgaSA9IDE7IGkgPCB0aGlzLmxheWVycy5sZW5ndGg7IGkrKykge1xuICAgICAgICAgICAgdGhpcy5sYXllcnNbaV0ucHJlZGljdCgpO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiB0aGlzLmxheWVyc1t0aGlzLmxheWVycy5sZW5ndGggLSAxXS53ZWlnaHRzO1xuICAgIH1cbiAgICB0cmFpbihkYXRhLCBvcHRpb25zID0ge30pIHtcbiAgICAgICAgY29uc3QgeyBwcmVwYXJlZERhdGEsIHN0YXR1cywgZW5kVGltZSB9ID0gdGhpcy5fcHJlcFRyYWluaW5nKGRhdGEsIG9wdGlvbnMpO1xuICAgICAgICBsZXQgY29udGludWVUaWNraW5nID0gdHJ1ZTtcbiAgICAgICAgY29uc3QgY2FsY3VsYXRlRXJyb3IgPSAoKSA9PiB0aGlzLl9jYWxjdWxhdGVUcmFpbmluZ0Vycm9yKHByZXBhcmVkRGF0YSk7XG4gICAgICAgIGNvbnN0IHRyYWluUGF0dGVycyA9ICgpID0+IHRoaXMuX3RyYWluUGF0dGVybnMocHJlcGFyZWREYXRhKTtcbiAgICAgICAgd2hpbGUgKGNvbnRpbnVlVGlja2luZykge1xuICAgICAgICAgICAgY29udGludWVUaWNraW5nID0gdGhpcy5fdHJhaW5pbmdUaWNrKHN0YXR1cywgZW5kVGltZSwgY2FsY3VsYXRlRXJyb3IsIHRyYWluUGF0dGVycyk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHN0YXR1cztcbiAgICB9XG4gICAgX3RyYWluaW5nVGljayhzdGF0dXMsIGVuZFRpbWUsIGNhbGN1bGF0ZUVycm9yLCB0cmFpblBhdHRlcm5zKSB7XG4gICAgICAgIGNvbnN0IHsgdHJhaW5PcHRzIH0gPSB0aGlzO1xuICAgICAgICBpZiAoc3RhdHVzLml0ZXJhdGlvbnMgPj0gdHJhaW5PcHRzLml0ZXJhdGlvbnMgfHxcbiAgICAgICAgICAgIHN0YXR1cy5lcnJvciA8PSB0cmFpbk9wdHMuZXJyb3JUaHJlc2ggfHxcbiAgICAgICAgICAgIERhdGUubm93KCkgPj0gZW5kVGltZSkge1xuICAgICAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgICAgICB9XG4gICAgICAgIGlmICh0eXBlb2YgdHJhaW5PcHRzLmxvZyA9PT0gJ2Z1bmN0aW9uJyAmJlxuICAgICAgICAgICAgc3RhdHVzLml0ZXJhdGlvbnMgJSB0cmFpbk9wdHMubG9nUGVyaW9kID09PSAwKSB7XG4gICAgICAgICAgICBzdGF0dXMuZXJyb3IgPSBjYWxjdWxhdGVFcnJvcigpO1xuICAgICAgICAgICAgdHJhaW5PcHRzLmxvZyhgaXRlcmF0aW9uczogJHtzdGF0dXMuaXRlcmF0aW9uc30sIHRyYWluaW5nIGVycm9yOiAke3N0YXR1cy5lcnJvcn1gKTtcbiAgICAgICAgfVxuICAgICAgICBlbHNlIGlmIChzdGF0dXMuaXRlcmF0aW9ucyAlIHRyYWluT3B0cy5lcnJvckNoZWNrSW50ZXJ2YWwgPT09XG4gICAgICAgICAgICAwKSB7XG4gICAgICAgICAgICBzdGF0dXMuZXJyb3IgPSBjYWxjdWxhdGVFcnJvcigpO1xuICAgICAgICB9XG4gICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgdHJhaW5QYXR0ZXJucygpO1xuICAgICAgICB9XG4gICAgICAgIGlmICh0cmFpbk9wdHMuY2FsbGJhY2sgJiZcbiAgICAgICAgICAgIHN0YXR1cy5pdGVyYXRpb25zICUgdHJhaW5PcHRzLmNhbGxiYWNrUGVyaW9kID09PSAwKSB7XG4gICAgICAgICAgICB0cmFpbk9wdHMuY2FsbGJhY2soT2JqZWN0LmFzc2lnbihzdGF0dXMpKTtcbiAgICAgICAgfVxuICAgICAgICBzdGF0dXMuaXRlcmF0aW9ucysrO1xuICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICB9XG4gICAgX3ByZXBUcmFpbmluZyhkYXRhLCBvcHRpb25zKSB7XG4gICAgICAgIHRoaXMuX3VwZGF0ZVRyYWluaW5nT3B0aW9ucyhvcHRpb25zKTtcbiAgICAgICAgY29uc3QgZm9ybWF0dGVkRGF0YSA9IHRoaXMuZm9ybWF0RGF0YShkYXRhKTtcbiAgICAgICAgY29uc3QgZW5kVGltZSA9IHRoaXMudHJhaW5PcHRzLnRpbWVvdXRcbiAgICAgICAgICAgID8gRGF0ZS5ub3coKSArIHRoaXMudHJhaW5PcHRzLnRpbWVvdXRcbiAgICAgICAgICAgIDogMDtcbiAgICAgICAgY29uc3Qgc3RhdHVzID0ge1xuICAgICAgICAgICAgZXJyb3I6IDEsXG4gICAgICAgICAgICBpdGVyYXRpb25zOiAwLFxuICAgICAgICB9O1xuICAgICAgICB0aGlzLnZlcmlmeUlzSW5pdGlhbGl6ZWQoKTtcbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgIHByZXBhcmVkRGF0YTogdGhpcy50cmFuc2ZlckRhdGEoZm9ybWF0dGVkRGF0YSksXG4gICAgICAgICAgICBzdGF0dXMsXG4gICAgICAgICAgICBlbmRUaW1lLFxuICAgICAgICB9O1xuICAgIH1cbiAgICB2ZXJpZnlJc0luaXRpYWxpemVkKCkge1xuICAgICAgICBpZiAoIXRoaXMuX21vZGVsKSB7XG4gICAgICAgICAgICB0aGlzLmluaXRpYWxpemUoKTtcbiAgICAgICAgfVxuICAgIH1cbiAgICBfY2FsY3VsYXRlVHJhaW5pbmdFcnJvcihwcmVwYXJlZERhdGEpIHtcbiAgICAgICAgbGV0IHN1bSA9IG5ldyBGbG9hdDMyQXJyYXkoWzBdKTtcbiAgICAgICAgY29uc3QgbWVhblNxdWFyZWRFcnJvciA9IHRoaXMubWVhblNxdWFyZWRFcnJvcjtcbiAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBwcmVwYXJlZERhdGEubGVuZ3RoOyArK2kpIHtcbiAgICAgICAgICAgIGNvbnN0IHByZXZTdW0gPSBzdW07XG4gICAgICAgICAgICBjb25zdCBlcnJvciA9IHRoaXMuX3RyYWluUGF0dGVybihwcmVwYXJlZERhdGFbaV0uaW5wdXQsIHByZXBhcmVkRGF0YVtpXS5vdXRwdXQsIHRydWUpO1xuICAgICAgICAgICAgc3VtID0gbWVhblNxdWFyZWRFcnJvci5hZGQoc3VtLCBlcnJvcik7XG4gICAgICAgICAgICByZWxlYXNlKGVycm9yKTtcbiAgICAgICAgICAgIHJlbGVhc2UocHJldlN1bSk7XG4gICAgICAgIH1cbiAgICAgICAgY29uc3QgcmVzdWx0ID0gbWVhblNxdWFyZWRFcnJvci5kaXZpZGUocHJlcGFyZWREYXRhLmxlbmd0aCwgc3VtKTtcbiAgICAgICAgcmVsZWFzZShzdW0pO1xuICAgICAgICBpZiAocmVzdWx0IGluc3RhbmNlb2YgZ3B1X2pzLlRleHR1cmUpIHtcbiAgICAgICAgICAgIGNvbnN0IHJlc3VsdEFycmF5ID0gcmVzdWx0LnRvQXJyYXkoKTtcbiAgICAgICAgICAgIHJlbGVhc2UocmVzdWx0KTtcbiAgICAgICAgICAgIHJldHVybiByZXN1bHRBcnJheVswXTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gcmVzdWx0WzBdO1xuICAgIH1cbiAgICAvKipcbiAgICAgKiBAcGFyYW0gZGF0YVxuICAgICAqIEBwcml2YXRlXG4gICAgICovXG4gICAgX3RyYWluUGF0dGVybnMoZGF0YSkge1xuICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IGRhdGEubGVuZ3RoOyArK2kpIHtcbiAgICAgICAgICAgIHRoaXMuX3RyYWluUGF0dGVybihkYXRhW2ldLmlucHV0LCBkYXRhW2ldLm91dHB1dCwgZmFsc2UpO1xuICAgICAgICB9XG4gICAgfVxuICAgIF90cmFpblBhdHRlcm4oaW5wdXQsIHRhcmdldCwgbG9nRXJyb3JSYXRlKSB7XG4gICAgICAgIHZhciBfYTtcbiAgICAgICAgLy8gZm9yd2FyZCBwcm9wYWdhdGVcbiAgICAgICAgdGhpcy5ydW5JbnB1dChpbnB1dCk7XG4gICAgICAgIC8vIGJhY2sgcHJvcGFnYXRlXG4gICAgICAgIHRoaXMuX2NhbGN1bGF0ZURlbHRhcyh0YXJnZXQpO1xuICAgICAgICB0aGlzLmFkanVzdFdlaWdodHMoKTtcbiAgICAgICAgaWYgKGxvZ0Vycm9yUmF0ZSkge1xuICAgICAgICAgICAgaWYgKCEoKF9hID0gdGhpcy5fb3V0cHV0TGF5ZXIpID09PSBudWxsIHx8IF9hID09PSB2b2lkIDAgPyB2b2lkIDAgOiBfYS5lcnJvcnMpKSB7XG4gICAgICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdvdXRwdXRMYXllci5lcnJvcnMgbm90IGRlZmluZWQnKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHJldHVybiB0aGlzLm1lYW5TcXVhcmVkRXJyb3IuY2FsY3VsYXRlKHRoaXMuX291dHB1dExheWVyLmVycm9ycyk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIG51bGw7XG4gICAgfVxuICAgIF9jYWxjdWxhdGVEZWx0YXModGFyZ2V0KSB7XG4gICAgICAgIGNvbnN0IGxheWVycyA9IHRoaXMubGF5ZXJzO1xuICAgICAgICBmb3IgKGxldCBpID0gbGF5ZXJzLmxlbmd0aCAtIDE7IGkgPiAtMTsgaS0tKSB7XG4gICAgICAgICAgICBsYXllcnNbaV0uY29tcGFyZSh0YXJnZXQpO1xuICAgICAgICB9XG4gICAgfVxuICAgIC8qKlxuICAgICAqXG4gICAgICovXG4gICAgYWRqdXN0V2VpZ2h0cygpIHtcbiAgICAgICAgY29uc3QgX21vZGVsID0gdGhpcy5fbW9kZWw7XG4gICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgX21vZGVsLmxlbmd0aDsgaSsrKSB7XG4gICAgICAgICAgICBfbW9kZWxbaV0ubGVhcm4odGhpcy50cmFpbk9wdHMubGVhcm5pbmdSYXRlKTtcbiAgICAgICAgfVxuICAgIH1cbiAgICAvKipcbiAgICAgKlxuICAgICAqIEBwYXJhbSBkYXRhXG4gICAgICogQHJldHVybnMgeyp9XG4gICAgICovXG4gICAgZm9ybWF0RGF0YShkYXRhKSB7XG4gICAgICAgIGlmICghQXJyYXkuaXNBcnJheShkYXRhKSkge1xuICAgICAgICAgICAgLy8gdHVybiBzdHJlYW0gZGF0dW0gaW50byBhcnJheVxuICAgICAgICAgICAgY29uc3QgdG1wID0gW107XG4gICAgICAgICAgICB0bXAucHVzaChkYXRhKTtcbiAgICAgICAgICAgIGRhdGEgPSB0bXA7XG4gICAgICAgIH1cbiAgICAgICAgLy8gdHVybiBzcGFyc2UgaGFzaCBpbnB1dCBpbnRvIGFycmF5cyB3aXRoIDBzIGFzIGZpbGxlclxuICAgICAgICBjb25zdCBpbnB1dERhdHVtQ2hlY2sgPSBkYXRhWzBdLmlucHV0O1xuICAgICAgICBsZXQgZm9ybWF0dGVkRGF0YTtcbiAgICAgICAgaWYgKEFycmF5LmlzQXJyYXkoZGF0YSkgJiZcbiAgICAgICAgICAgICFBcnJheS5pc0FycmF5KGlucHV0RGF0dW1DaGVjaykgJiZcbiAgICAgICAgICAgICEoaW5wdXREYXR1bUNoZWNrIGluc3RhbmNlb2YgRmxvYXQzMkFycmF5KSkge1xuICAgICAgICAgICAgaWYgKCF0aGlzLmlucHV0TG9va3VwKSB7XG4gICAgICAgICAgICAgICAgY29uc3QgbG9va3VwVGFibGUgPSBuZXcgTG9va3VwVGFibGUoZGF0YSwgJ2lucHV0Jyk7XG4gICAgICAgICAgICAgICAgdGhpcy5pbnB1dExvb2t1cCA9IGxvb2t1cFRhYmxlLnRhYmxlO1xuICAgICAgICAgICAgICAgIHRoaXMuaW5wdXRMb29rdXBMZW5ndGggPSBsb29rdXBUYWJsZS5sZW5ndGg7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBmb3JtYXR0ZWREYXRhID0gZGF0YS5tYXAoKGRhdHVtUGFyYW0pID0+IHtcbiAgICAgICAgICAgICAgICBjb25zdCBhcnJheSA9IGxvb2t1cC50b0FycmF5KHRoaXMuaW5wdXRMb29rdXAsIGRhdHVtUGFyYW0uaW5wdXQsIHRoaXMuaW5wdXRMb29rdXBMZW5ndGgpO1xuICAgICAgICAgICAgICAgIHJldHVybiB7IGlucHV0OiBhcnJheSB9O1xuICAgICAgICAgICAgfSwgdGhpcyk7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICBmb3JtYXR0ZWREYXRhID0gZGF0YTtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCBvdXRwdXREYXR1bUNoZWNrID0gZGF0YVswXS5vdXRwdXQ7XG4gICAgICAgIGlmICghQXJyYXkuaXNBcnJheShvdXRwdXREYXR1bUNoZWNrKSAmJlxuICAgICAgICAgICAgIShvdXRwdXREYXR1bUNoZWNrIGluc3RhbmNlb2YgRmxvYXQzMkFycmF5KSkge1xuICAgICAgICAgICAgaWYgKCF0aGlzLm91dHB1dExvb2t1cCkge1xuICAgICAgICAgICAgICAgIGNvbnN0IGxvb2t1cFRhYmxlID0gbmV3IExvb2t1cFRhYmxlKGRhdGEsICdvdXRwdXQnKTtcbiAgICAgICAgICAgICAgICB0aGlzLm91dHB1dExvb2t1cCA9IGxvb2t1cFRhYmxlLnRhYmxlO1xuICAgICAgICAgICAgICAgIHRoaXMub3V0cHV0TG9va3VwTGVuZ3RoID0gbG9va3VwVGFibGUubGVuZ3RoO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZm9ybWF0dGVkRGF0YSA9IGRhdGEubWFwKChkYXR1bVBhcmFtLCBpbmRleCkgPT4ge1xuICAgICAgICAgICAgICAgIGNvbnN0IGFycmF5ID0gbG9va3VwLnRvQXJyYXkodGhpcy5vdXRwdXRMb29rdXAsIGRhdHVtUGFyYW0ub3V0cHV0LCB0aGlzLmlucHV0TG9va3VwTGVuZ3RoKTtcbiAgICAgICAgICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgICAgICAgICBpbnB1dDogZm9ybWF0dGVkRGF0YVtpbmRleF0uaW5wdXQsXG4gICAgICAgICAgICAgICAgICAgIG91dHB1dDogYXJyYXksXG4gICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgIH0sIHRoaXMpO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBmb3JtYXR0ZWREYXRhO1xuICAgIH1cbiAgICB0cmFuc2ZlckRhdGEoZm9ybWF0dGVkRGF0YSkge1xuICAgICAgICBjb25zdCB0cmFuc2ZlcnJlZERhdGEgPSBuZXcgQXJyYXkoZm9ybWF0dGVkRGF0YS5sZW5ndGgpO1xuICAgICAgICBjb25zdCB0cmFuc2ZlcklucHV0ID0gbWFrZUtlcm5lbChmdW5jdGlvbiAodmFsdWUpIHtcbiAgICAgICAgICAgIHJldHVybiB2YWx1ZVt0aGlzLnRocmVhZC54XTtcbiAgICAgICAgfSwge1xuICAgICAgICAgICAgb3V0cHV0OiBbZm9ybWF0dGVkRGF0YVswXS5pbnB1dC5sZW5ndGhdLFxuICAgICAgICAgICAgaW1tdXRhYmxlOiB0cnVlLFxuICAgICAgICB9KTtcbiAgICAgICAgY29uc3QgdHJhbnNmZXJPdXRwdXQgPSBtYWtlS2VybmVsKGZ1bmN0aW9uICh2YWx1ZSkge1xuICAgICAgICAgICAgcmV0dXJuIHZhbHVlW3RoaXMudGhyZWFkLnhdO1xuICAgICAgICB9LCB7XG4gICAgICAgICAgICBvdXRwdXQ6IFtmb3JtYXR0ZWREYXRhWzBdLm91dHB1dC5sZW5ndGhdLFxuICAgICAgICAgICAgaW1tdXRhYmxlOiB0cnVlLFxuICAgICAgICB9KTtcbiAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBmb3JtYXR0ZWREYXRhLmxlbmd0aDsgaSsrKSB7XG4gICAgICAgICAgICBjb25zdCBmb3JtYXR0ZWREYXR1bSA9IGZvcm1hdHRlZERhdGFbaV07XG4gICAgICAgICAgICB0cmFuc2ZlcnJlZERhdGFbaV0gPSB7XG4gICAgICAgICAgICAgICAgaW5wdXQ6IHRyYW5zZmVySW5wdXQoZm9ybWF0dGVkRGF0dW0uaW5wdXQpLFxuICAgICAgICAgICAgICAgIG91dHB1dDogdHJhbnNmZXJPdXRwdXQoZm9ybWF0dGVkRGF0dW0ub3V0cHV0KSxcbiAgICAgICAgICAgIH07XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHRyYW5zZmVycmVkRGF0YTtcbiAgICB9XG4gICAgLyoqXG4gICAgICpcbiAgICAgKiBAcGFyYW0gZGF0YVxuICAgICAqIEByZXR1cm5zIHtcbiAgICAgKiAge1xuICAgICAqICAgIGVycm9yOiBudW1iZXIsXG4gICAgICogICAgbWlzY2xhc3NlczogQXJyYXlcbiAgICAgKiAgfVxuICAgICAqIH1cbiAgICAgKi9cbiAgICB0ZXN0KCkge1xuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoYCR7dGhpcy5jb25zdHJ1Y3Rvci5uYW1lfS10ZXN0IGlzIG5vdCB5ZXQgaW1wbGVtZW50ZWRgKTtcbiAgICB9XG4gICAgLyoqXG4gICAgICpcbiAgICAgKi9cbiAgICB0b0pTT04oKSB7XG4gICAgICAgIHZhciBfYTtcbiAgICAgICAgaWYgKCF0aGlzLmxheWVycykge1xuICAgICAgICAgICAgdGhpcy5pbml0aWFsaXplKCk7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKCF0aGlzLl9tb2RlbCB8fFxuICAgICAgICAgICAgIXRoaXMubGF5ZXJzIHx8XG4gICAgICAgICAgICAhdGhpcy5faW5wdXRMYXllciB8fFxuICAgICAgICAgICAgIXRoaXMuX2hpZGRlbkxheWVycyB8fFxuICAgICAgICAgICAgIXRoaXMuX291dHB1dExheWVyKSB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ25ldHdvcmsgaXMgbm90IGluaXRpYWxpemVkJyk7XG4gICAgICAgIH1cbiAgICAgICAgY29uc3QganNvbkxheWVycyA9IFtdO1xuICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IHRoaXMubGF5ZXJzLmxlbmd0aDsgaSsrKSB7XG4gICAgICAgICAgICBjb25zdCBsYXllciA9IHRoaXMubGF5ZXJzW2ldO1xuICAgICAgICAgICAgY29uc3QganNvbkxheWVyID0gbGF5ZXIudG9KU09OKCk7XG4gICAgICAgICAgICBpZiAobGF5ZXIuaGFzT3duUHJvcGVydHkoJ2lucHV0TGF5ZXInKSkge1xuICAgICAgICAgICAgICAgIGpzb25MYXllci5pbnB1dExheWVySW5kZXggPSB0aGlzLmxheWVycy5pbmRleE9mKGxheWVyLmlucHV0TGF5ZXIpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZWxzZSBpZiAobGF5ZXIuaGFzT3duUHJvcGVydHkoJ2lucHV0TGF5ZXIxJykgJiZcbiAgICAgICAgICAgICAgICBsYXllci5oYXNPd25Qcm9wZXJ0eSgnaW5wdXRMYXllcjInKSkge1xuICAgICAgICAgICAgICAgIGpzb25MYXllci5pbnB1dExheWVyMUluZGV4ID0gdGhpcy5sYXllcnMuaW5kZXhPZihsYXllci5pbnB1dExheWVyMSk7XG4gICAgICAgICAgICAgICAganNvbkxheWVyLmlucHV0TGF5ZXIySW5kZXggPSB0aGlzLmxheWVycy5pbmRleE9mKGxheWVyLmlucHV0TGF5ZXIyKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGpzb25MYXllcnMucHVzaChqc29uTGF5ZXIpO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICB0eXBlOiB0aGlzLmNvbnN0cnVjdG9yLm5hbWUsXG4gICAgICAgICAgICBzaXplczogKF9hID0gdGhpcy5vcHRpb25zLnNpemVzKSAhPT0gbnVsbCAmJiBfYSAhPT0gdm9pZCAwID8gX2EgOiBbdGhpcy5faW5wdXRMYXllci5oZWlnaHRdXG4gICAgICAgICAgICAgICAgLmNvbmNhdCh0aGlzLl9oaWRkZW5MYXllcnMubWFwKChsKSA9PiBsLmhlaWdodCkpXG4gICAgICAgICAgICAgICAgLmNvbmNhdChbdGhpcy5fb3V0cHV0TGF5ZXIuaGVpZ2h0XSksXG4gICAgICAgICAgICBvdXRwdXRMYXllckluZGV4OiB0aGlzLmxheWVycy5pbmRleE9mKHRoaXMuX291dHB1dExheWVyKSxcbiAgICAgICAgICAgIGxheWVyczoganNvbkxheWVycyxcbiAgICAgICAgICAgIGlucHV0TGF5ZXJJbmRleDogdGhpcy5sYXllcnMuaW5kZXhPZih0aGlzLl9pbnB1dExheWVyKSxcbiAgICAgICAgfTtcbiAgICB9XG4gICAgc3RhdGljIGZyb21KU09OKGpzb24sIGdldExheWVyKSB7XG4gICAgICAgIHZhciBfYSwgX2IsIF9jLCBfZDtcbiAgICAgICAgY29uc3QganNvbkxheWVycyA9IGpzb24ubGF5ZXJzO1xuICAgICAgICBjb25zdCBsYXllcnMgPSBbXTtcbiAgICAgICAgY29uc3QgaW5wdXRMYXllciA9IGdldExheWVyXG4gICAgICAgICAgICA/IChfYSA9IGxheWVyRnJvbUpTT04oanNvbkxheWVyc1swXSkpICE9PSBudWxsICYmIF9hICE9PSB2b2lkIDAgPyBfYSA6IGdldExheWVyKGpzb25MYXllcnNbMF0pIDogbGF5ZXJGcm9tSlNPTihqc29uTGF5ZXJzWzBdKTtcbiAgICAgICAgaWYgKCFpbnB1dExheWVyKVxuICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKCd1bmFibGUgdG8gZmluZCBsYXllcicpO1xuICAgICAgICBsYXllcnMucHVzaChpbnB1dExheWVyKTtcbiAgICAgICAgZm9yIChsZXQgaSA9IDE7IGkgPCBqc29uTGF5ZXJzLmxlbmd0aDsgaSsrKSB7XG4gICAgICAgICAgICBjb25zdCBqc29uTGF5ZXIgPSBqc29uTGF5ZXJzW2ldO1xuICAgICAgICAgICAgaWYgKHR5cGVvZiBqc29uTGF5ZXIuaW5wdXRMYXllckluZGV4ID09PSAndW5kZWZpbmVkJyAmJlxuICAgICAgICAgICAgICAgIHR5cGVvZiBqc29uTGF5ZXIuaW5wdXRMYXllcjFJbmRleCA9PT0gJ3VuZGVmaW5lZCcgJiZcbiAgICAgICAgICAgICAgICB0eXBlb2YganNvbkxheWVyLmlucHV0TGF5ZXIySW5kZXggPT09ICd1bmRlZmluZWQnKSB7XG4gICAgICAgICAgICAgICAgY29uc3QgbGF5ZXIgPSBnZXRMYXllclxuICAgICAgICAgICAgICAgICAgICA/IChfYiA9IGxheWVyRnJvbUpTT04oanNvbkxheWVyKSkgIT09IG51bGwgJiYgX2IgIT09IHZvaWQgMCA/IF9iIDogZ2V0TGF5ZXIoanNvbkxheWVyKSA6IGxheWVyRnJvbUpTT04oanNvbkxheWVyKTtcbiAgICAgICAgICAgICAgICBpZiAoIWxheWVyKVxuICAgICAgICAgICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ3VuYWJsZSB0byBmaW5kIGxheWVyJyk7XG4gICAgICAgICAgICAgICAgbGF5ZXJzLnB1c2gobGF5ZXIpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZWxzZSBpZiAodHlwZW9mIGpzb25MYXllci5pbnB1dExheWVySW5kZXggPT09ICdudW1iZXInKSB7XG4gICAgICAgICAgICAgICAgY29uc3QgaW5wdXRMYXllciA9IGxheWVyc1tqc29uTGF5ZXIuaW5wdXRMYXllckluZGV4XTtcbiAgICAgICAgICAgICAgICBpZiAoIWlucHV0TGF5ZXIpIHtcbiAgICAgICAgICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdpbnB1dExheWVyMSBub3QgZm91bmQnKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgY29uc3QgbGF5ZXIgPSBnZXRMYXllclxuICAgICAgICAgICAgICAgICAgICA/IChfYyA9IGxheWVyRnJvbUpTT04oanNvbkxheWVyLCBpbnB1dExheWVyKSkgIT09IG51bGwgJiYgX2MgIT09IHZvaWQgMCA/IF9jIDogZ2V0TGF5ZXIoanNvbkxheWVyLCBpbnB1dExheWVyKSA6IGxheWVyRnJvbUpTT04oanNvbkxheWVyLCBpbnB1dExheWVyKTtcbiAgICAgICAgICAgICAgICBpZiAoIWxheWVyKVxuICAgICAgICAgICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ3VuYWJsZSB0byBmaW5kIGxheWVyJyk7XG4gICAgICAgICAgICAgICAgbGF5ZXJzLnB1c2gobGF5ZXIpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgICAgaWYgKHR5cGVvZiBqc29uTGF5ZXIuaW5wdXRMYXllcjFJbmRleCAhPT0gJ251bWJlcicpIHtcbiAgICAgICAgICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdDYW5ub3QgY3JlYXRlIG5ldHdvcmsgZnJvbSBwcm92aWRlZCBKU09OLiBpbnB1dExheWVyMUluZGV4IG5vdCBkZWZpbmVkLicpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBpZiAodHlwZW9mIGpzb25MYXllci5pbnB1dExheWVyMkluZGV4ICE9PSAnbnVtYmVyJykge1xuICAgICAgICAgICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ0Nhbm5vdCBjcmVhdGUgbmV0d29yayBmcm9tIHByb3ZpZGVkIEpTT04uIGlucHV0TGF5ZXIySW5kZXggbm90IGRlZmluZWQuJyk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGNvbnN0IGlucHV0TGF5ZXIxID0gbGF5ZXJzW2pzb25MYXllci5pbnB1dExheWVyMUluZGV4XTtcbiAgICAgICAgICAgICAgICBjb25zdCBpbnB1dExheWVyMiA9IGxheWVyc1tqc29uTGF5ZXIuaW5wdXRMYXllcjJJbmRleF07XG4gICAgICAgICAgICAgICAgaWYgKGlucHV0TGF5ZXIxID09PSB1bmRlZmluZWQpXG4gICAgICAgICAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcihgQ2Fubm90IGNyZWF0ZSBuZXR3b3JrIGZyb20gcHJvdmlkZWQgSlNPTi4gbGF5ZXIgb2YgaW5kZXggJHtqc29uTGF5ZXIuaW5wdXRMYXllcjFJbmRleH0gbm90IGZvdW5kLmApO1xuICAgICAgICAgICAgICAgIGlmIChpbnB1dExheWVyMiA9PT0gdW5kZWZpbmVkKVxuICAgICAgICAgICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoYENhbm5vdCBjcmVhdGUgbmV0d29yayBmcm9tIHByb3ZpZGVkIEpTT04uIGxheWVyIG9mIGluZGV4ICR7anNvbkxheWVyLmlucHV0TGF5ZXIySW5kZXh9IG5vdCBmb3VuZC5gKTtcbiAgICAgICAgICAgICAgICBjb25zdCBsYXllciA9IGdldExheWVyXG4gICAgICAgICAgICAgICAgICAgID8gKF9kID0gbGF5ZXJGcm9tSlNPTihqc29uTGF5ZXIsIGlucHV0TGF5ZXIxLCBpbnB1dExheWVyMikpICE9PSBudWxsICYmIF9kICE9PSB2b2lkIDAgPyBfZCA6IGdldExheWVyKGpzb25MYXllciwgaW5wdXRMYXllcjEsIGlucHV0TGF5ZXIyKSA6IGxheWVyRnJvbUpTT04oanNvbkxheWVyLCBpbnB1dExheWVyMSwgaW5wdXRMYXllcjIpO1xuICAgICAgICAgICAgICAgIGlmICghbGF5ZXIpXG4gICAgICAgICAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcigndW5hYmxlIHRvIGZpbmQgbGF5ZXInKTtcbiAgICAgICAgICAgICAgICBsYXllcnMucHVzaChsYXllcik7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIG5ldyB0aGlzKHsgLi4uanNvbiwgbGF5ZXJzIH0pO1xuICAgIH1cbiAgICAvKipcbiAgICAgKlxuICAgICAqIEByZXR1cm5zIHtGdW5jdGlvbn1cbiAgICAgKi9cbiAgICB0b0Z1bmN0aW9uKCkge1xuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoYCR7dGhpcy5jb25zdHJ1Y3Rvci5uYW1lfS10b0Z1bmN0aW9uIGlzIG5vdCB5ZXQgaW1wbGVtZW50ZWRgKTtcbiAgICB9XG4gICAgLyoqXG4gICAgICogVGhpcyB3aWxsIGNyZWF0ZSBhIFRyYWluU3RyZWFtIChXcml0ZVN0cmVhbSkgZm9yIHVzIHRvIHNlbmQgdGhlIHRyYWluaW5nIGRhdGEgdG8uXG4gICAgICogQHBhcmFtIG9wdHMgdHJhaW5pbmcgb3B0aW9uc1xuICAgICAqIEByZXR1cm5zIHtUcmFpblN0cmVhbXwqfVxuICAgICAqL1xuICAgIGNyZWF0ZVRyYWluU3RyZWFtKCkge1xuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoYCR7dGhpcy5jb25zdHJ1Y3Rvci5uYW1lfS1jcmVhdGVUcmFpblN0cmVhbSBpcyBub3QgeWV0IGltcGxlbWVudGVkYCk7XG4gICAgfVxufVxuXG5mdW5jdGlvbiBsaWtlbHkoaW5wdXQsIG5ldCkge1xuICAgIGlmICghbmV0KSB7XG4gICAgICAgIHRocm93IG5ldyBUeXBlRXJyb3IoYFJlcXVpcmVkIHBhcmFtZXRlciAnbmV0JyBpcyBvZiB0eXBlICR7dHlwZW9mIG5ldH0uIE11c3QgYmUgb2YgdHlwZSAnYnJhaW4uTmV1cmFsTmV0d29yaydgKTtcbiAgICB9XG4gICAgY29uc3Qgb3V0cHV0ID0gbmV0LnJ1bihpbnB1dCk7XG4gICAgbGV0IG1heFByb3AgPSBudWxsO1xuICAgIGxldCBtYXhWYWx1ZSA9IC0xO1xuICAgIE9iamVjdC5lbnRyaWVzKG91dHB1dCkuZm9yRWFjaCgoW2tleSwgdmFsdWVdKSA9PiB7XG4gICAgICAgIGlmICh0eXBlb2YgdmFsdWUgIT09ICd1bmRlZmluZWQnICYmXG4gICAgICAgICAgICB0eXBlb2YgdmFsdWUgPT09ICdudW1iZXInICYmXG4gICAgICAgICAgICB2YWx1ZSA+IG1heFZhbHVlKSB7XG4gICAgICAgICAgICBtYXhQcm9wID0ga2V5O1xuICAgICAgICAgICAgbWF4VmFsdWUgPSB2YWx1ZTtcbiAgICAgICAgfVxuICAgIH0pO1xuICAgIHJldHVybiBtYXhQcm9wO1xufVxuXG52YXIgY29tbW9uanNHbG9iYWwgPSB0eXBlb2YgZ2xvYmFsVGhpcyAhPT0gJ3VuZGVmaW5lZCcgPyBnbG9iYWxUaGlzIDogdHlwZW9mIHdpbmRvdyAhPT0gJ3VuZGVmaW5lZCcgPyB3aW5kb3cgOiB0eXBlb2YgZ2xvYmFsICE9PSAndW5kZWZpbmVkJyA/IGdsb2JhbCA6IHR5cGVvZiBzZWxmICE9PSAndW5kZWZpbmVkJyA/IHNlbGYgOiB7fTtcblxuZnVuY3Rpb24gY3JlYXRlQ29tbW9uanNNb2R1bGUoZm4sIGJhc2VkaXIsIG1vZHVsZSkge1xuXHRyZXR1cm4gbW9kdWxlID0ge1xuXHRcdHBhdGg6IGJhc2VkaXIsXG5cdFx0ZXhwb3J0czoge30sXG5cdFx0cmVxdWlyZTogZnVuY3Rpb24gKHBhdGgsIGJhc2UpIHtcblx0XHRcdHJldHVybiBjb21tb25qc1JlcXVpcmUocGF0aCwgKGJhc2UgPT09IHVuZGVmaW5lZCB8fCBiYXNlID09PSBudWxsKSA/IG1vZHVsZS5wYXRoIDogYmFzZSk7XG5cdFx0fVxuXHR9LCBmbihtb2R1bGUsIG1vZHVsZS5leHBvcnRzKSwgbW9kdWxlLmV4cG9ydHM7XG59XG5cbmZ1bmN0aW9uIGNvbW1vbmpzUmVxdWlyZSAoKSB7XG5cdHRocm93IG5ldyBFcnJvcignRHluYW1pYyByZXF1aXJlcyBhcmUgbm90IGN1cnJlbnRseSBzdXBwb3J0ZWQgYnkgQHJvbGx1cC9wbHVnaW4tY29tbW9uanMnKTtcbn1cblxudmFyIHRoYXdfMSA9IGNyZWF0ZUNvbW1vbmpzTW9kdWxlKGZ1bmN0aW9uIChtb2R1bGUsIGV4cG9ydHMpIHtcbnZhciBfX2Fzc2lnbiA9IChjb21tb25qc0dsb2JhbCAmJiBjb21tb25qc0dsb2JhbC5fX2Fzc2lnbikgfHwgZnVuY3Rpb24gKCkge1xuICAgIF9fYXNzaWduID0gT2JqZWN0LmFzc2lnbiB8fCBmdW5jdGlvbih0KSB7XG4gICAgICAgIGZvciAodmFyIHMsIGkgPSAxLCBuID0gYXJndW1lbnRzLmxlbmd0aDsgaSA8IG47IGkrKykge1xuICAgICAgICAgICAgcyA9IGFyZ3VtZW50c1tpXTtcbiAgICAgICAgICAgIGZvciAodmFyIHAgaW4gcykgaWYgKE9iamVjdC5wcm90b3R5cGUuaGFzT3duUHJvcGVydHkuY2FsbChzLCBwKSlcbiAgICAgICAgICAgICAgICB0W3BdID0gc1twXTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gdDtcbiAgICB9O1xuICAgIHJldHVybiBfX2Fzc2lnbi5hcHBseSh0aGlzLCBhcmd1bWVudHMpO1xufTtcbk9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCBcIl9fZXNNb2R1bGVcIiwgeyB2YWx1ZTogdHJ1ZSB9KTtcbmV4cG9ydHMudGhhdyA9IGV4cG9ydHMuVGhhdyA9IHZvaWQgMDtcbi8qKlxuICogdGhhdyBhbiBhcnJheSBvZiBpdGVtc1xuICovXG52YXIgVGhhdyA9IC8qKiBAY2xhc3MgKi8gKGZ1bmN0aW9uICgpIHtcbiAgICBmdW5jdGlvbiBUaGF3KGl0ZW1zLCBvcHRpb25zKSB7XG4gICAgICAgIHZhciBfdGhpcyA9IHRoaXM7XG4gICAgICAgIGlmIChvcHRpb25zID09PSB2b2lkIDApIHsgb3B0aW9ucyA9IHt9OyB9XG4gICAgICAgIHZhciBfYSA9IF9fYXNzaWduKF9fYXNzaWduKHt9LCBUaGF3LmRlZmF1bHRTZXR0aW5ncyksIG9wdGlvbnMpLCBlYWNoID0gX2EuZWFjaCwgZG9uZSA9IF9hLmRvbmU7XG4gICAgICAgIHRoaXMuaSA9IDA7XG4gICAgICAgIHRoaXMuaXNTdG9wcGVkID0gZmFsc2U7XG4gICAgICAgIHRoaXMuaXRlbXMgPSBpdGVtcztcbiAgICAgICAgdGhpcy5vcHRpb25zID0gb3B0aW9ucztcbiAgICAgICAgdGhpcy50aWNrID0gZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgaWYgKF90aGlzLmlzU3RvcHBlZClcbiAgICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICBfdGhpcy50aW1lb3V0ID0gc2V0VGltZW91dChfdGhpcy50aWNrLCAwKTtcbiAgICAgICAgICAgIGlmIChUaGF3LnRoYXdpbmcpXG4gICAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgdmFyIGl0ZW0gPSBfdGhpcy5pdGVtc1tfdGhpcy5pXTtcbiAgICAgICAgICAgIGlmIChfdGhpcy5pID49IF90aGlzLml0ZW1zLmxlbmd0aCkge1xuICAgICAgICAgICAgICAgIGlmIChkb25lICE9PSBudWxsKSB7XG4gICAgICAgICAgICAgICAgICAgIFRoYXcudGhhd2luZyA9IHRydWU7XG4gICAgICAgICAgICAgICAgICAgIGRvbmUoKTtcbiAgICAgICAgICAgICAgICAgICAgVGhhdy50aGF3aW5nID0gZmFsc2U7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIF90aGlzLmlzU3RvcHBlZCA9IHRydWU7XG4gICAgICAgICAgICAgICAgY2xlYXJUaW1lb3V0KF90aGlzLnRpbWVvdXQpO1xuICAgICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGlmIChlYWNoICE9PSBudWxsKSB7XG4gICAgICAgICAgICAgICAgVGhhdy50aGF3aW5nID0gdHJ1ZTtcbiAgICAgICAgICAgICAgICBlYWNoKGl0ZW0sIF90aGlzLmkpO1xuICAgICAgICAgICAgICAgIFRoYXcudGhhd2luZyA9IGZhbHNlO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZWxzZSBpZiAoaXRlbSAhPT0gdW5kZWZpbmVkKSB7XG4gICAgICAgICAgICAgICAgaXRlbSgpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgX3RoaXMuaSsrO1xuICAgICAgICB9O1xuICAgICAgICBUaGF3LnRoYXdzLnB1c2godGhpcyk7XG4gICAgICAgIGlmICghb3B0aW9ucy5kZWxheSkge1xuICAgICAgICAgICAgdGhpcy50aWNrKCk7XG4gICAgICAgIH1cbiAgICB9XG4gICAgT2JqZWN0LmRlZmluZVByb3BlcnR5KFRoYXcsIFwiaXNUaGF3aW5nXCIsIHtcbiAgICAgICAgLyoqXG4gICAgICAgICAqIHJldHVybnMgaWYgVGhhdy5qcyBpcyB0aGF3aW5nXG4gICAgICAgICAqL1xuICAgICAgICBnZXQ6IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgIHJldHVybiBUaGF3LnRoYXdpbmc7XG4gICAgICAgIH0sXG4gICAgICAgIGVudW1lcmFibGU6IGZhbHNlLFxuICAgICAgICBjb25maWd1cmFibGU6IHRydWVcbiAgICB9KTtcbiAgICAvKipcbiAgICAgKiBTdG9wcyBhbGwgVGhhdyBpbnN0YW5jZXNcbiAgICAgKi9cbiAgICBUaGF3LnN0b3BBbGwgPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgIGZvciAodmFyIGkgPSAwOyBpIDwgVGhhdy50aGF3cy5sZW5ndGg7IGkrKykge1xuICAgICAgICAgICAgVGhhdy50aGF3c1tpXS5zdG9wKCk7XG4gICAgICAgIH1cbiAgICB9O1xuICAgIC8qKlxuICAgICAqIHJlYWRpZXMgdGhhdyB0byBjb250aW51ZVxuICAgICAqL1xuICAgIFRoYXcucHJvdG90eXBlLm1ha2VSZWFkeSA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgaWYgKHRoaXMuaXNTdG9wcGVkKSB7XG4gICAgICAgICAgICB0aGlzLmlzU3RvcHBlZCA9IGZhbHNlO1xuICAgICAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIH07XG4gICAgLyoqXG4gICAgICogQWRkcyBhbiBpdGVtIHRvIHRoZSBlbmQgb2YgdGhpcyBpbnN0YW5jZSBvZiBUaGF3IGFuZCByZWFkaWVzIFRoYXcgdG8gcHJvY2VzcyBpdFxuICAgICAqL1xuICAgIFRoYXcucHJvdG90eXBlLmFkZCA9IGZ1bmN0aW9uIChpdGVtKSB7XG4gICAgICAgIHRoaXMuaXRlbXMucHVzaChpdGVtKTtcbiAgICAgICAgaWYgKHRoaXMubWFrZVJlYWR5KCkpIHtcbiAgICAgICAgICAgIHRoaXMudGljaygpO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiB0aGlzO1xuICAgIH07XG4gICAgLyoqXG4gICAgICogSW5zZXJ0cyBhbiBpdGVtIGp1c3QgYWZ0ZXIgdGhlIGN1cnJlbnQgaXRlbSBiZWluZyBwcm9jZXNzZWQgaW4gVGhhdyBhbmQgcmVhZGllcyBUaGF3IHRvIHByb2Nlc3MgaXRcbiAgICAgKi9cbiAgICBUaGF3LnByb3RvdHlwZS5pbnNlcnQgPSBmdW5jdGlvbiAoaXRlbSkge1xuICAgICAgICB0aGlzLml0ZW1zLnNwbGljZSh0aGlzLmksIDAsIGl0ZW0pO1xuICAgICAgICBpZiAodGhpcy5tYWtlUmVhZHkoKSkge1xuICAgICAgICAgICAgdGhpcy50aWNrKCk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHRoaXM7XG4gICAgfTtcbiAgICAvKipcbiAgICAgKiBBZGRzIGFuIEFycmF5IHRvIHRoZSBlbmQgb2YgdGhpcyBpbnN0YW5jZSBvZiBUaGF3IGFuZCByZWFkaWVzIFRoYXcgdG8gcHJvY2VzcyBpdFxuICAgICAqL1xuICAgIFRoYXcucHJvdG90eXBlLmFkZEFycmF5ID0gZnVuY3Rpb24gKGl0ZW1zKSB7XG4gICAgICAgIHRoaXMuaXRlbXMgPSB0aGlzLml0ZW1zLmNvbmNhdChpdGVtcyk7XG4gICAgICAgIGlmICh0aGlzLm1ha2VSZWFkeSgpKSB7XG4gICAgICAgICAgICB0aGlzLnRpY2soKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gdGhpcztcbiAgICB9O1xuICAgIC8qKlxuICAgICAqIEluc2VydHMgYW4gQXJyYXkganVzdCBhZnRlciB0aGUgY3VycmVudCBpdGVtIGJlaW5nIHByb2Nlc3NlZCBpbiBUaGF3IGFuZCByZWFkaWVzIFRoYXcgdG8gcHJvY2VzcyB0aGVtXG4gICAgICovXG4gICAgVGhhdy5wcm90b3R5cGUuaW5zZXJ0QXJyYXkgPSBmdW5jdGlvbiAoaXRlbXMpIHtcbiAgICAgICAgdmFyIGJlZm9yZSA9IHRoaXMuaXRlbXMuc3BsaWNlKDAsIHRoaXMuaSk7XG4gICAgICAgIHZhciBhZnRlciA9IHRoaXMuaXRlbXM7XG4gICAgICAgIHRoaXMuaXRlbXMgPSBiZWZvcmUuY29uY2F0KGl0ZW1zLCBhZnRlcik7XG4gICAgICAgIGlmICh0aGlzLm1ha2VSZWFkeSgpKSB7XG4gICAgICAgICAgICB0aGlzLnRpY2soKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gdGhpcztcbiAgICB9O1xuICAgIC8qKlxuICAgICAqIFN0b3BzIHRoaXMgaW5zdGFuY2Ugb2YgVGhhd1xuICAgICAqL1xuICAgIFRoYXcucHJvdG90eXBlLnN0b3AgPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgIHRoaXMuaXNTdG9wcGVkID0gdHJ1ZTtcbiAgICAgICAgY2xlYXJUaW1lb3V0KHRoaXMudGltZW91dCk7XG4gICAgICAgIGlmICh0aGlzLm9wdGlvbnMuZG9uZSkge1xuICAgICAgICAgICAgdGhpcy5vcHRpb25zLmRvbmUoKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gdGhpcztcbiAgICB9O1xuICAgIFRoYXcudGhhd2luZyA9IGZhbHNlO1xuICAgIFRoYXcudGhhd3MgPSBbXTtcbiAgICBUaGF3LmRlZmF1bHRTZXR0aW5ncyA9IHtcbiAgICAgICAgZWFjaDogbnVsbCxcbiAgICAgICAgZG9uZTogbnVsbFxuICAgIH07XG4gICAgcmV0dXJuIFRoYXc7XG59KCkpO1xuZXhwb3J0cy5UaGF3ID0gVGhhdztcbi8qKlxuICogc2ltcGxlIHRoYXdcbiAqL1xuZnVuY3Rpb24gdGhhdyhpdGVtcywgb3B0aW9ucykge1xuICAgIHJldHVybiBuZXcgVGhhdyhpdGVtcywgb3B0aW9ucyk7XG59XG5leHBvcnRzLnRoYXcgPSB0aGF3O1xuXG59KTtcblxudmFyIGJsb2NrID0gY3JlYXRlQ29tbW9uanNNb2R1bGUoZnVuY3Rpb24gKG1vZHVsZSwgZXhwb3J0cykge1xuT2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsIFwiX19lc01vZHVsZVwiLCB7IHZhbHVlOiB0cnVlIH0pO1xuZXhwb3J0cy5CbG9jayA9IHZvaWQgMDtcblxudmFyIEJsb2NrID0gLyoqIEBjbGFzcyAqLyAoZnVuY3Rpb24gKCkge1xuICAgIGZ1bmN0aW9uIEJsb2NrKG9wdGlvbnMsIGNvdW50KSB7XG4gICAgICAgIGlmIChjb3VudCA9PT0gdm9pZCAwKSB7IGNvdW50ID0gMjAwOyB9XG4gICAgICAgIHRoaXMuaW5kZXggPSAwO1xuICAgICAgICB0aGlzLnRoYXdzID0gW107XG4gICAgICAgIHRoaXMuY291bnQgPSBjb3VudDtcbiAgICAgICAgdGhpcy5vcHRpb25zID0gb3B0aW9ucztcbiAgICB9XG4gICAgLyoqXG4gICAgICogYWRkIGFuIGl0ZW0gdG8gdGhlIGVuZCBvZiBpdGVtc1xuICAgICAqL1xuICAgIEJsb2NrLnByb3RvdHlwZS5hZGQgPSBmdW5jdGlvbiAoaXRlbSkge1xuICAgICAgICB2YXIgbmV4dCA9IHRoaXMubmV4dCgpO1xuICAgICAgICBuZXh0LmFkZChpdGVtKTtcbiAgICAgICAgcmV0dXJuIHRoaXM7XG4gICAgfTtcbiAgICAvKipcbiAgICAgKiBhZGQgYW4gQXJyYXkgdG8gdGhlIGVuZCBvZiBpdGVtc1xuICAgICAqL1xuICAgIEJsb2NrLnByb3RvdHlwZS5hZGRBcnJheSA9IGZ1bmN0aW9uIChpdGVtcykge1xuICAgICAgICB2YXIgbmV4dCA9IHRoaXMubmV4dCgpO1xuICAgICAgICBuZXh0LmFkZEFycmF5KGl0ZW1zKTtcbiAgICAgICAgcmV0dXJuIHRoaXM7XG4gICAgfTtcbiAgICAvKipcbiAgICAgKiBpbnNlcnQgYW4gaXRlbSBpbnRvIGl0ZW1zIEAgY3VycmVudCBwb3NpdGlvblxuICAgICAqL1xuICAgIEJsb2NrLnByb3RvdHlwZS5pbnNlcnQgPSBmdW5jdGlvbiAoaXRlbSkge1xuICAgICAgICB2YXIgbmV4dCA9IHRoaXMubmV4dCgpO1xuICAgICAgICBuZXh0Lmluc2VydChpdGVtKTtcbiAgICAgICAgcmV0dXJuIHRoaXM7XG4gICAgfTtcbiAgICAvKipcbiAgICAgKiBpbnNlcnQgYW5kIGFycmF5IGludG8gaXRlbXMgQCBjdXJyZW50IHBvc2l0aW9uXG4gICAgICovXG4gICAgQmxvY2sucHJvdG90eXBlLmluc2VydEFycmF5ID0gZnVuY3Rpb24gKGl0ZW1zKSB7XG4gICAgICAgIHZhciBuZXh0ID0gdGhpcy5uZXh0KCk7XG4gICAgICAgIG5leHQuaW5zZXJ0QXJyYXkoaXRlbXMpO1xuICAgICAgICByZXR1cm4gdGhpcztcbiAgICB9O1xuICAgIC8qKlxuICAgICAqIFN0b3BzIGFsbCB0aGF3cyBpbiB0aGlzIGJsb2NrXG4gICAgICovXG4gICAgQmxvY2sucHJvdG90eXBlLnN0b3AgPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgIGZvciAodmFyIGkgPSAwOyBpIDwgdGhpcy50aGF3cy5sZW5ndGg7IGkrKykge1xuICAgICAgICAgICAgdGhpcy50aGF3c1tpXS5zdG9wKCk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHRoaXM7XG4gICAgfTtcbiAgICAvKipcbiAgICAgKiBHZXQgbmV4dCBhdmFpbGFibGUgaW4gYmxvY2tcbiAgICAgKi9cbiAgICBCbG9jay5wcm90b3R5cGUubmV4dCA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgdmFyIHRoYXc7XG4gICAgICAgIHZhciB0aGF3cyA9IHRoaXMudGhhd3M7XG4gICAgICAgIGlmICh0aGF3cy5sZW5ndGggPCB0aGlzLmNvdW50KSB7XG4gICAgICAgICAgICB0aGF3ID0gbmV3IHRoYXdfMS5UaGF3KFtdLCB0aGlzLm9wdGlvbnMpO1xuICAgICAgICAgICAgdGhhd3MucHVzaCh0aGF3KTtcbiAgICAgICAgfVxuICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgIHRoYXcgPSB0aGF3c1t0aGlzLmluZGV4XSB8fCBudWxsO1xuICAgICAgICB9XG4gICAgICAgIHRoaXMuaW5kZXgrKztcbiAgICAgICAgaWYgKHRoaXMuaW5kZXggPj0gdGhpcy5jb3VudCkge1xuICAgICAgICAgICAgdGhpcy5pbmRleCA9IDA7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHRoYXc7XG4gICAgfTtcbiAgICByZXR1cm4gQmxvY2s7XG59KCkpO1xuZXhwb3J0cy5CbG9jayA9IEJsb2NrO1xuXG59KTtcblxudmFyIGRpc3QgPSBjcmVhdGVDb21tb25qc01vZHVsZShmdW5jdGlvbiAobW9kdWxlLCBleHBvcnRzKSB7XG5PYmplY3QuZGVmaW5lUHJvcGVydHkoZXhwb3J0cywgXCJfX2VzTW9kdWxlXCIsIHsgdmFsdWU6IHRydWUgfSk7XG5leHBvcnRzLkJsb2NrID0gZXhwb3J0cy50aGF3ID0gZXhwb3J0cy5UaGF3ID0gdm9pZCAwO1xuXG5PYmplY3QuZGVmaW5lUHJvcGVydHkoZXhwb3J0cywgXCJUaGF3XCIsIHsgZW51bWVyYWJsZTogdHJ1ZSwgZ2V0OiBmdW5jdGlvbiAoKSB7IHJldHVybiB0aGF3XzEuVGhhdzsgfSB9KTtcbk9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCBcInRoYXdcIiwgeyBlbnVtZXJhYmxlOiB0cnVlLCBnZXQ6IGZ1bmN0aW9uICgpIHsgcmV0dXJuIHRoYXdfMS50aGF3OyB9IH0pO1xuXG5PYmplY3QuZGVmaW5lUHJvcGVydHkoZXhwb3J0cywgXCJCbG9ja1wiLCB7IGVudW1lcmFibGU6IHRydWUsIGdldDogZnVuY3Rpb24gKCkgeyByZXR1cm4gYmxvY2suQmxvY2s7IH0gfSk7XG5pZiAodHlwZW9mIHdpbmRvdyAhPT0gJ3VuZGVmaW5lZCcpIHtcbiAgICAvLyBAdHMtaWdub3JlXG4gICAgd2luZG93LlRoYXcgPSB0aGF3XzEuVGhhdztcbiAgICAvLyBAdHMtaWdub3JlXG4gICAgd2luZG93LnRoYXcgPSB0aGF3XzEudGhhdztcbiAgICAvLyBAdHMtaWdub3JlXG4gICAgd2luZG93LlRoYXcuQmxvY2sgPSBibG9jay5CbG9jaztcbn1cblxufSk7XG5cbmZ1bmN0aW9uIGFycmF5c1RvRmxvYXQzMkFycmF5cyhhcnJheXMpIHtcbiAgICBjb25zdCByZXN1bHQgPSBbXTtcbiAgICBmb3IgKGxldCBpID0gMDsgaSA8IGFycmF5cy5sZW5ndGg7IGkrKykge1xuICAgICAgICByZXN1bHQucHVzaChGbG9hdDMyQXJyYXkuZnJvbShhcnJheXNbaV0pKTtcbiAgICB9XG4gICAgcmV0dXJuIHJlc3VsdDtcbn1cbmZ1bmN0aW9uIGlucHV0T3V0cHV0QXJyYXlzVG9GbG9hdDMyQXJyYXlzKGlucHV0LCBvdXRwdXQpIHtcbiAgICBjb25zdCByZXN1bHQgPSBbXTtcbiAgICBmb3IgKGxldCBpID0gMDsgaSA8IGlucHV0Lmxlbmd0aDsgaSsrKSB7XG4gICAgICAgIHJlc3VsdC5wdXNoKEZsb2F0MzJBcnJheS5mcm9tKGlucHV0W2ldKSk7XG4gICAgfVxuICAgIGZvciAobGV0IGkgPSAwOyBpIDwgb3V0cHV0Lmxlbmd0aDsgaSsrKSB7XG4gICAgICAgIHJlc3VsdC5wdXNoKEZsb2F0MzJBcnJheS5mcm9tKG91dHB1dFtpXSkpO1xuICAgIH1cbiAgICByZXR1cm4gcmVzdWx0O1xufVxuZnVuY3Rpb24gYXJyYXlUb0Zsb2F0MzJBcnJheXMoYXJyYXkpIHtcbiAgICBjb25zdCByZXN1bHQgPSBbXTtcbiAgICBmb3IgKGxldCBpID0gMDsgaSA8IGFycmF5Lmxlbmd0aDsgaSsrKSB7XG4gICAgICAgIHJlc3VsdC5wdXNoKEZsb2F0MzJBcnJheS5mcm9tKFthcnJheVtpXV0pKTtcbiAgICB9XG4gICAgcmV0dXJuIHJlc3VsdDtcbn1cbmZ1bmN0aW9uIGlucHV0T3V0cHV0QXJyYXlUb0Zsb2F0MzJBcnJheXMoaW5wdXQsIG91dHB1dCkge1xuICAgIGNvbnN0IHJlc3VsdCA9IFtdO1xuICAgIGZvciAobGV0IGkgPSAwOyBpIDwgaW5wdXQubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgcmVzdWx0LnB1c2goRmxvYXQzMkFycmF5LmZyb20oW2lucHV0W2ldXSkpO1xuICAgIH1cbiAgICBmb3IgKGxldCBpID0gMDsgaSA8IG91dHB1dC5sZW5ndGg7IGkrKykge1xuICAgICAgICByZXN1bHQucHVzaChGbG9hdDMyQXJyYXkuZnJvbShbb3V0cHV0W2ldXSkpO1xuICAgIH1cbiAgICByZXR1cm4gcmVzdWx0O1xufVxuZnVuY3Rpb24gYXJyYXlUb0Zsb2F0MzJBcnJheShhcnJheSkge1xuICAgIHJldHVybiBGbG9hdDMyQXJyYXkuZnJvbShhcnJheSk7XG59XG5mdW5jdGlvbiBpbnB1dE91dHB1dE9iamVjdHNUb0Zsb2F0MzJBcnJheXMoaW5wdXQsIG91dHB1dCwgaW5wdXRUYWJsZSwgb3V0cHV0VGFibGUsIGlucHV0TGVuZ3RoLCBvdXRwdXRMZW5ndGgpIHtcbiAgICBjb25zdCByZXN1bHRzID0gW107XG4gICAgZm9yIChsZXQgaSA9IDA7IGkgPCBpbnB1dC5sZW5ndGg7IGkrKykge1xuICAgICAgICBjb25zdCBvYmplY3QgPSBpbnB1dFtpXTtcbiAgICAgICAgY29uc3QgcmVzdWx0ID0gbmV3IEZsb2F0MzJBcnJheShpbnB1dExlbmd0aCk7XG4gICAgICAgIGZvciAoY29uc3QgcCBpbiBvYmplY3QpIHtcbiAgICAgICAgICAgIGlmIChvYmplY3QuaGFzT3duUHJvcGVydHkocCkpIHtcbiAgICAgICAgICAgICAgICByZXN1bHRbaW5wdXRUYWJsZVtwXV0gPSBvYmplY3RbcF07XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgcmVzdWx0cy5wdXNoKHJlc3VsdCk7XG4gICAgfVxuICAgIGZvciAobGV0IGkgPSAwOyBpIDwgb3V0cHV0Lmxlbmd0aDsgaSsrKSB7XG4gICAgICAgIGNvbnN0IG9iamVjdCA9IG91dHB1dFtpXTtcbiAgICAgICAgY29uc3QgcmVzdWx0ID0gbmV3IEZsb2F0MzJBcnJheShvdXRwdXRMZW5ndGgpO1xuICAgICAgICBmb3IgKGNvbnN0IHAgaW4gb2JqZWN0KSB7XG4gICAgICAgICAgICBpZiAob2JqZWN0Lmhhc093blByb3BlcnR5KHApKSB7XG4gICAgICAgICAgICAgICAgcmVzdWx0W291dHB1dFRhYmxlW3BdXSA9IG9iamVjdFtwXTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICByZXN1bHRzLnB1c2gocmVzdWx0KTtcbiAgICB9XG4gICAgcmV0dXJuIHJlc3VsdHM7XG59XG5mdW5jdGlvbiBvYmplY3RUb0Zsb2F0MzJBcnJheXMob2JqZWN0KSB7XG4gICAgY29uc3QgcmVzdWx0ID0gW107XG4gICAgZm9yIChjb25zdCBwIGluIG9iamVjdCkge1xuICAgICAgICBpZiAoIW9iamVjdC5oYXNPd25Qcm9wZXJ0eShwKSlcbiAgICAgICAgICAgIGNvbnRpbnVlO1xuICAgICAgICByZXN1bHQucHVzaChGbG9hdDMyQXJyYXkuZnJvbShbb2JqZWN0W3BdXSkpO1xuICAgIH1cbiAgICByZXR1cm4gcmVzdWx0O1xufVxuZnVuY3Rpb24gaW5wdXRPdXRwdXRPYmplY3RUb0Zsb2F0MzJBcnJheXMoaW5wdXQsIG91dHB1dCkge1xuICAgIGNvbnN0IHJlc3VsdCA9IFtdO1xuICAgIGZvciAoY29uc3QgcCBpbiBpbnB1dCkge1xuICAgICAgICBpZiAoIWlucHV0Lmhhc093blByb3BlcnR5KHApKVxuICAgICAgICAgICAgY29udGludWU7XG4gICAgICAgIHJlc3VsdC5wdXNoKEZsb2F0MzJBcnJheS5mcm9tKFtpbnB1dFtwXV0pKTtcbiAgICB9XG4gICAgZm9yIChjb25zdCBwIGluIG91dHB1dCkge1xuICAgICAgICBpZiAoIW91dHB1dC5oYXNPd25Qcm9wZXJ0eShwKSlcbiAgICAgICAgICAgIGNvbnRpbnVlO1xuICAgICAgICByZXN1bHQucHVzaChGbG9hdDMyQXJyYXkuZnJvbShbb3V0cHV0W3BdXSkpO1xuICAgIH1cbiAgICByZXR1cm4gcmVzdWx0O1xufVxuZnVuY3Rpb24gb2JqZWN0VG9GbG9hdDMyQXJyYXkob2JqZWN0LCB0YWJsZSwgbGVuZ3RoKSB7XG4gICAgY29uc3QgcmVzdWx0ID0gbmV3IEZsb2F0MzJBcnJheShsZW5ndGgpO1xuICAgIGZvciAoY29uc3QgcCBpbiBvYmplY3QpIHtcbiAgICAgICAgaWYgKG9iamVjdC5oYXNPd25Qcm9wZXJ0eShwKSkge1xuICAgICAgICAgICAgcmVzdWx0W3RhYmxlW3BdXSA9IG9iamVjdFtwXTtcbiAgICAgICAgfVxuICAgIH1cbiAgICByZXR1cm4gcmVzdWx0O1xufVxuXG5mdW5jdGlvbiBtYXgodmFsdWVzKSB7XG4gICAgaWYgKEFycmF5LmlzQXJyYXkodmFsdWVzKSB8fCB2YWx1ZXMgaW5zdGFuY2VvZiBGbG9hdDMyQXJyYXkpIHtcbiAgICAgICAgcmV0dXJuIE1hdGgubWF4KC4uLnZhbHVlcyk7XG4gICAgfVxuICAgIGVsc2Uge1xuICAgICAgICByZXR1cm4gTWF0aC5tYXgoLi4uT2JqZWN0LnZhbHVlcyh2YWx1ZXMpKTtcbiAgICB9XG59XG5cbmZ1bmN0aW9uIG1zZSQxKGVycm9ycykge1xuICAgIC8vIG1lYW4gc3F1YXJlZCBlcnJvclxuICAgIGxldCBzdW0gPSAwO1xuICAgIGZvciAobGV0IGkgPSAwOyBpIDwgZXJyb3JzLmxlbmd0aDsgaSsrKSB7XG4gICAgICAgIHN1bSArPSBlcnJvcnNbaV0gKiogMjtcbiAgICB9XG4gICAgcmV0dXJuIHN1bSAvIGVycm9ycy5sZW5ndGg7XG59XG5cbmZ1bmN0aW9uIGdldFR5cGVkQXJyYXlGbih2YWx1ZSwgdGFibGUpIHtcbiAgICBpZiAodmFsdWUuYnVmZmVyIGluc3RhbmNlb2YgQXJyYXlCdWZmZXIpIHtcbiAgICAgICAgcmV0dXJuIG51bGw7XG4gICAgfVxuICAgIGlmIChBcnJheS5pc0FycmF5KHZhbHVlKSkge1xuICAgICAgICByZXR1cm4gYXJyYXlUb0Zsb2F0MzJBcnJheTtcbiAgICB9XG4gICAgaWYgKCF0YWJsZSlcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKCd0YWJsZSBpcyBub3QgT2JqZWN0Jyk7XG4gICAgY29uc3QgeyBsZW5ndGggfSA9IE9iamVjdC5rZXlzKHRhYmxlKTtcbiAgICByZXR1cm4gKHYpID0+IHtcbiAgICAgICAgY29uc3QgYXJyYXkgPSBuZXcgRmxvYXQzMkFycmF5KGxlbmd0aCk7XG4gICAgICAgIGZvciAoY29uc3QgcCBpbiB0YWJsZSkge1xuICAgICAgICAgICAgaWYgKCF0YWJsZS5oYXNPd25Qcm9wZXJ0eShwKSlcbiAgICAgICAgICAgICAgICBjb250aW51ZTtcbiAgICAgICAgICAgIGFycmF5W3RhYmxlW3BdXSA9IHZbcF0gfHwgMDtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gYXJyYXk7XG4gICAgfTtcbn1cbmZ1bmN0aW9uIGRlZmF1bHRzJDIoKSB7XG4gICAgcmV0dXJuIHtcbiAgICAgICAgaW5wdXRTaXplOiAwLFxuICAgICAgICBvdXRwdXRTaXplOiAwLFxuICAgICAgICBiaW5hcnlUaHJlc2g6IDAuNSxcbiAgICB9O1xufVxuZnVuY3Rpb24gdHJhaW5EZWZhdWx0cyQyKCkge1xuICAgIHJldHVybiB7XG4gICAgICAgIGFjdGl2YXRpb246ICdzaWdtb2lkJyxcbiAgICAgICAgaXRlcmF0aW9uczogMjAwMDAsXG4gICAgICAgIGVycm9yVGhyZXNoOiAwLjAwNSxcbiAgICAgICAgbG9nOiBmYWxzZSxcbiAgICAgICAgbG9nUGVyaW9kOiAxMCxcbiAgICAgICAgbGVha3lSZWx1QWxwaGE6IDAuMDEsXG4gICAgICAgIGxlYXJuaW5nUmF0ZTogMC4zLFxuICAgICAgICBtb21lbnR1bTogMC4xLFxuICAgICAgICBjYWxsYmFja1BlcmlvZDogMTAsXG4gICAgICAgIHRpbWVvdXQ6IEluZmluaXR5LFxuICAgICAgICBiZXRhMTogMC45LFxuICAgICAgICBiZXRhMjogMC45OTksXG4gICAgICAgIGVwc2lsb246IDFlLTgsXG4gICAgfTtcbn1cbmNsYXNzIE5ldXJhbE5ldHdvcmsge1xuICAgIGNvbnN0cnVjdG9yKG9wdGlvbnMgPSB7fSkge1xuICAgICAgICB0aGlzLm9wdGlvbnMgPSBkZWZhdWx0cyQyKCk7XG4gICAgICAgIHRoaXMudHJhaW5PcHRzID0gdHJhaW5EZWZhdWx0cyQyKCk7XG4gICAgICAgIHRoaXMuc2l6ZXMgPSBbXTtcbiAgICAgICAgdGhpcy5vdXRwdXRMYXllciA9IC0xO1xuICAgICAgICB0aGlzLmJpYXNlcyA9IFtdO1xuICAgICAgICB0aGlzLndlaWdodHMgPSBbXTsgLy8gd2VpZ2h0cyBmb3IgYmlhcyBub2Rlc1xuICAgICAgICB0aGlzLm91dHB1dHMgPSBbXTtcbiAgICAgICAgLy8gc3RhdGUgZm9yIHRyYWluaW5nXG4gICAgICAgIHRoaXMuZGVsdGFzID0gW107XG4gICAgICAgIHRoaXMuY2hhbmdlcyA9IFtdOyAvLyBmb3IgbW9tZW50dW1cbiAgICAgICAgdGhpcy5lcnJvcnMgPSBbXTtcbiAgICAgICAgdGhpcy5lcnJvckNoZWNrSW50ZXJ2YWwgPSAxO1xuICAgICAgICB0aGlzLmlucHV0TG9va3VwID0gbnVsbDtcbiAgICAgICAgdGhpcy5pbnB1dExvb2t1cExlbmd0aCA9IDA7XG4gICAgICAgIHRoaXMub3V0cHV0TG9va3VwID0gbnVsbDtcbiAgICAgICAgdGhpcy5vdXRwdXRMb29rdXBMZW5ndGggPSAwO1xuICAgICAgICB0aGlzLl9mb3JtYXRJbnB1dCA9IG51bGw7XG4gICAgICAgIHRoaXMuX2Zvcm1hdE91dHB1dCA9IG51bGw7XG4gICAgICAgIHRoaXMucnVuSW5wdXQgPSAoaW5wdXQpID0+IHtcbiAgICAgICAgICAgIHRoaXMuc2V0QWN0aXZhdGlvbigpO1xuICAgICAgICAgICAgcmV0dXJuIHRoaXMucnVuSW5wdXQoaW5wdXQpO1xuICAgICAgICB9O1xuICAgICAgICB0aGlzLmNhbGN1bGF0ZURlbHRhcyA9IChvdXRwdXQpID0+IHtcbiAgICAgICAgICAgIHRoaXMuc2V0QWN0aXZhdGlvbigpO1xuICAgICAgICAgICAgcmV0dXJuIHRoaXMuY2FsY3VsYXRlRGVsdGFzKG91dHB1dCk7XG4gICAgICAgIH07XG4gICAgICAgIC8vIGFkYW1cbiAgICAgICAgdGhpcy5iaWFzQ2hhbmdlc0xvdyA9IFtdO1xuICAgICAgICB0aGlzLmJpYXNDaGFuZ2VzSGlnaCA9IFtdO1xuICAgICAgICB0aGlzLmNoYW5nZXNMb3cgPSBbXTtcbiAgICAgICAgdGhpcy5jaGFuZ2VzSGlnaCA9IFtdO1xuICAgICAgICB0aGlzLml0ZXJhdGlvbnMgPSAwO1xuICAgICAgICB0aGlzLm9wdGlvbnMgPSB7IC4uLnRoaXMub3B0aW9ucywgLi4ub3B0aW9ucyB9O1xuICAgICAgICB0aGlzLnVwZGF0ZVRyYWluaW5nT3B0aW9ucyhvcHRpb25zKTtcbiAgICAgICAgY29uc3QgeyBpbnB1dFNpemUsIGhpZGRlbkxheWVycywgb3V0cHV0U2l6ZSB9ID0gdGhpcy5vcHRpb25zO1xuICAgICAgICBpZiAoaW5wdXRTaXplICYmIG91dHB1dFNpemUpIHtcbiAgICAgICAgICAgIHRoaXMuc2l6ZXMgPSBbaW5wdXRTaXplXS5jb25jYXQoaGlkZGVuTGF5ZXJzICE9PSBudWxsICYmIGhpZGRlbkxheWVycyAhPT0gdm9pZCAwID8gaGlkZGVuTGF5ZXJzIDogW10pLmNvbmNhdChbb3V0cHV0U2l6ZV0pO1xuICAgICAgICB9XG4gICAgfVxuICAgIC8qKlxuICAgICAqXG4gICAgICogRXhwZWN0cyB0aGlzLnNpemVzIHRvIGhhdmUgYmVlbiBzZXRcbiAgICAgKi9cbiAgICBpbml0aWFsaXplKCkge1xuICAgICAgICBpZiAoIXRoaXMuc2l6ZXMubGVuZ3RoKSB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ1NpemVzIG11c3QgYmUgc2V0IGJlZm9yZSBpbml0aWFsaXppbmcnKTtcbiAgICAgICAgfVxuICAgICAgICB0aGlzLm91dHB1dExheWVyID0gdGhpcy5zaXplcy5sZW5ndGggLSAxO1xuICAgICAgICB0aGlzLmJpYXNlcyA9IG5ldyBBcnJheSh0aGlzLm91dHB1dExheWVyKTsgLy8gd2VpZ2h0cyBmb3IgYmlhcyBub2Rlc1xuICAgICAgICB0aGlzLndlaWdodHMgPSBuZXcgQXJyYXkodGhpcy5vdXRwdXRMYXllcik7XG4gICAgICAgIHRoaXMub3V0cHV0cyA9IG5ldyBBcnJheSh0aGlzLm91dHB1dExheWVyKTtcbiAgICAgICAgLy8gc3RhdGUgZm9yIHRyYWluaW5nXG4gICAgICAgIHRoaXMuZGVsdGFzID0gbmV3IEFycmF5KHRoaXMub3V0cHV0TGF5ZXIpO1xuICAgICAgICB0aGlzLmNoYW5nZXMgPSBuZXcgQXJyYXkodGhpcy5vdXRwdXRMYXllcik7IC8vIGZvciBtb21lbnR1bVxuICAgICAgICB0aGlzLmVycm9ycyA9IG5ldyBBcnJheSh0aGlzLm91dHB1dExheWVyKTtcbiAgICAgICAgZm9yIChsZXQgbGF5ZXJJbmRleCA9IDA7IGxheWVySW5kZXggPD0gdGhpcy5vdXRwdXRMYXllcjsgbGF5ZXJJbmRleCsrKSB7XG4gICAgICAgICAgICBjb25zdCBzaXplID0gdGhpcy5zaXplc1tsYXllckluZGV4XTtcbiAgICAgICAgICAgIHRoaXMuZGVsdGFzW2xheWVySW5kZXhdID0gemVyb3MkMShzaXplKTtcbiAgICAgICAgICAgIHRoaXMuZXJyb3JzW2xheWVySW5kZXhdID0gemVyb3MkMShzaXplKTtcbiAgICAgICAgICAgIHRoaXMub3V0cHV0c1tsYXllckluZGV4XSA9IHplcm9zJDEoc2l6ZSk7XG4gICAgICAgICAgICBpZiAobGF5ZXJJbmRleCA+IDApIHtcbiAgICAgICAgICAgICAgICB0aGlzLmJpYXNlc1tsYXllckluZGV4XSA9IHJhbmRvcyhzaXplKTtcbiAgICAgICAgICAgICAgICB0aGlzLndlaWdodHNbbGF5ZXJJbmRleF0gPSBuZXcgQXJyYXkoc2l6ZSk7XG4gICAgICAgICAgICAgICAgdGhpcy5jaGFuZ2VzW2xheWVySW5kZXhdID0gbmV3IEFycmF5KHNpemUpO1xuICAgICAgICAgICAgICAgIGZvciAobGV0IG5vZGVJbmRleCA9IDA7IG5vZGVJbmRleCA8IHNpemU7IG5vZGVJbmRleCsrKSB7XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IHByZXZTaXplID0gdGhpcy5zaXplc1tsYXllckluZGV4IC0gMV07XG4gICAgICAgICAgICAgICAgICAgIHRoaXMud2VpZ2h0c1tsYXllckluZGV4XVtub2RlSW5kZXhdID0gcmFuZG9zKHByZXZTaXplKTtcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5jaGFuZ2VzW2xheWVySW5kZXhdW25vZGVJbmRleF0gPSB6ZXJvcyQxKHByZXZTaXplKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgdGhpcy5zZXRBY3RpdmF0aW9uKCk7XG4gICAgICAgIGlmICh0aGlzLnRyYWluT3B0cy5wcmF4aXMgPT09ICdhZGFtJykge1xuICAgICAgICAgICAgdGhpcy5fc2V0dXBBZGFtKCk7XG4gICAgICAgIH1cbiAgICB9XG4gICAgc2V0QWN0aXZhdGlvbihhY3RpdmF0aW9uKSB7XG4gICAgICAgIGNvbnN0IHZhbHVlID0gYWN0aXZhdGlvbiAhPT0gbnVsbCAmJiBhY3RpdmF0aW9uICE9PSB2b2lkIDAgPyBhY3RpdmF0aW9uIDogdGhpcy50cmFpbk9wdHMuYWN0aXZhdGlvbjtcbiAgICAgICAgc3dpdGNoICh2YWx1ZSkge1xuICAgICAgICAgICAgY2FzZSAnc2lnbW9pZCc6XG4gICAgICAgICAgICAgICAgdGhpcy5ydW5JbnB1dCA9IHRoaXMuX3J1bklucHV0U2lnbW9pZDtcbiAgICAgICAgICAgICAgICB0aGlzLmNhbGN1bGF0ZURlbHRhcyA9IHRoaXMuX2NhbGN1bGF0ZURlbHRhc1NpZ21vaWQ7XG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICBjYXNlICdyZWx1JzpcbiAgICAgICAgICAgICAgICB0aGlzLnJ1bklucHV0ID0gdGhpcy5fcnVuSW5wdXRSZWx1O1xuICAgICAgICAgICAgICAgIHRoaXMuY2FsY3VsYXRlRGVsdGFzID0gdGhpcy5fY2FsY3VsYXRlRGVsdGFzUmVsdTtcbiAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgIGNhc2UgJ2xlYWt5LXJlbHUnOlxuICAgICAgICAgICAgICAgIHRoaXMucnVuSW5wdXQgPSB0aGlzLl9ydW5JbnB1dExlYWt5UmVsdTtcbiAgICAgICAgICAgICAgICB0aGlzLmNhbGN1bGF0ZURlbHRhcyA9IHRoaXMuX2NhbGN1bGF0ZURlbHRhc0xlYWt5UmVsdTtcbiAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgIGNhc2UgJ3RhbmgnOlxuICAgICAgICAgICAgICAgIHRoaXMucnVuSW5wdXQgPSB0aGlzLl9ydW5JbnB1dFRhbmg7XG4gICAgICAgICAgICAgICAgdGhpcy5jYWxjdWxhdGVEZWx0YXMgPSB0aGlzLl9jYWxjdWxhdGVEZWx0YXNUYW5oO1xuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgZGVmYXVsdDpcbiAgICAgICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoYFVua25vd24gYWN0aXZhdGlvbiAke3ZhbHVlfS4gQXZhaWxhYmxlIGFjdGl2YXRpb25zIGFyZTogJ3NpZ21vaWQnLCAncmVsdScsICdsZWFreS1yZWx1JywgJ3RhbmgnYCk7XG4gICAgICAgIH1cbiAgICB9XG4gICAgZ2V0IGlzUnVubmFibGUoKSB7XG4gICAgICAgIHJldHVybiB0aGlzLnNpemVzLmxlbmd0aCA+IDA7XG4gICAgfVxuICAgIHJ1bihpbnB1dCkge1xuICAgICAgICBpZiAoIXRoaXMuaXNSdW5uYWJsZSkge1xuICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKCduZXR3b3JrIG5vdCBydW5uYWJsZScpO1xuICAgICAgICB9XG4gICAgICAgIGxldCBmb3JtYXR0ZWRJbnB1dDtcbiAgICAgICAgaWYgKHRoaXMuaW5wdXRMb29rdXApIHtcbiAgICAgICAgICAgIGZvcm1hdHRlZElucHV0ID0gbG9va3VwLnRvQXJyYXkodGhpcy5pbnB1dExvb2t1cCwgaW5wdXQsIHRoaXMuaW5wdXRMb29rdXBMZW5ndGgpO1xuICAgICAgICB9XG4gICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgZm9ybWF0dGVkSW5wdXQgPSBpbnB1dDtcbiAgICAgICAgfVxuICAgICAgICBpZiAoZm9ybWF0dGVkSW5wdXQubGVuZ3RoICE9PSB0aGlzLnNpemVzWzBdKSB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoYGlucHV0IGlzIG5vdCBpbiBjb3JyZWN0IGxlbmd0aCBvZiAke3RoaXMuc2l6ZXNbMF19YCk7XG4gICAgICAgIH1cbiAgICAgICAgY29uc3Qgb3V0cHV0ID0gdGhpcy5ydW5JbnB1dChmb3JtYXR0ZWRJbnB1dCkuc2xpY2UoMCk7XG4gICAgICAgIGlmICh0aGlzLm91dHB1dExvb2t1cCkge1xuICAgICAgICAgICAgcmV0dXJuIGxvb2t1cC50b09iamVjdCh0aGlzLm91dHB1dExvb2t1cCwgb3V0cHV0KTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gb3V0cHV0O1xuICAgIH1cbiAgICBfcnVuSW5wdXRTaWdtb2lkKGlucHV0KSB7XG4gICAgICAgIHRoaXMub3V0cHV0c1swXSA9IGlucHV0OyAvLyBzZXQgb3V0cHV0IHN0YXRlIG9mIGlucHV0IGxheWVyXG4gICAgICAgIGxldCBvdXRwdXQgPSBudWxsO1xuICAgICAgICBmb3IgKGxldCBsYXllciA9IDE7IGxheWVyIDw9IHRoaXMub3V0cHV0TGF5ZXI7IGxheWVyKyspIHtcbiAgICAgICAgICAgIGNvbnN0IGFjdGl2ZUxheWVyID0gdGhpcy5zaXplc1tsYXllcl07XG4gICAgICAgICAgICBjb25zdCBhY3RpdmVXZWlnaHRzID0gdGhpcy53ZWlnaHRzW2xheWVyXTtcbiAgICAgICAgICAgIGNvbnN0IGFjdGl2ZUJpYXNlcyA9IHRoaXMuYmlhc2VzW2xheWVyXTtcbiAgICAgICAgICAgIGNvbnN0IGFjdGl2ZU91dHB1dHMgPSB0aGlzLm91dHB1dHNbbGF5ZXJdO1xuICAgICAgICAgICAgZm9yIChsZXQgbm9kZSA9IDA7IG5vZGUgPCBhY3RpdmVMYXllcjsgbm9kZSsrKSB7XG4gICAgICAgICAgICAgICAgY29uc3Qgd2VpZ2h0cyA9IGFjdGl2ZVdlaWdodHNbbm9kZV07XG4gICAgICAgICAgICAgICAgbGV0IHN1bSA9IGFjdGl2ZUJpYXNlc1tub2RlXTtcbiAgICAgICAgICAgICAgICBmb3IgKGxldCBrID0gMDsgayA8IHdlaWdodHMubGVuZ3RoOyBrKyspIHtcbiAgICAgICAgICAgICAgICAgICAgc3VtICs9IHdlaWdodHNba10gKiBpbnB1dFtrXTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgLy8gc2lnbW9pZFxuICAgICAgICAgICAgICAgIGFjdGl2ZU91dHB1dHNbbm9kZV0gPSAxIC8gKDEgKyBNYXRoLmV4cCgtc3VtKSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBvdXRwdXQgPSBpbnB1dCA9IGFjdGl2ZU91dHB1dHM7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKCFvdXRwdXQpIHtcbiAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcignb3V0cHV0IHdhcyBlbXB0eScpO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBvdXRwdXQ7XG4gICAgfVxuICAgIF9ydW5JbnB1dFJlbHUoaW5wdXQpIHtcbiAgICAgICAgdGhpcy5vdXRwdXRzWzBdID0gaW5wdXQ7IC8vIHNldCBvdXRwdXQgc3RhdGUgb2YgaW5wdXQgbGF5ZXJcbiAgICAgICAgbGV0IG91dHB1dCA9IG51bGw7XG4gICAgICAgIGZvciAobGV0IGxheWVyID0gMTsgbGF5ZXIgPD0gdGhpcy5vdXRwdXRMYXllcjsgbGF5ZXIrKykge1xuICAgICAgICAgICAgY29uc3QgYWN0aXZlU2l6ZSA9IHRoaXMuc2l6ZXNbbGF5ZXJdO1xuICAgICAgICAgICAgY29uc3QgYWN0aXZlV2VpZ2h0cyA9IHRoaXMud2VpZ2h0c1tsYXllcl07XG4gICAgICAgICAgICBjb25zdCBhY3RpdmVCaWFzZXMgPSB0aGlzLmJpYXNlc1tsYXllcl07XG4gICAgICAgICAgICBjb25zdCBhY3RpdmVPdXRwdXRzID0gdGhpcy5vdXRwdXRzW2xheWVyXTtcbiAgICAgICAgICAgIGZvciAobGV0IG5vZGUgPSAwOyBub2RlIDwgYWN0aXZlU2l6ZTsgbm9kZSsrKSB7XG4gICAgICAgICAgICAgICAgY29uc3Qgd2VpZ2h0cyA9IGFjdGl2ZVdlaWdodHNbbm9kZV07XG4gICAgICAgICAgICAgICAgbGV0IHN1bSA9IGFjdGl2ZUJpYXNlc1tub2RlXTtcbiAgICAgICAgICAgICAgICBmb3IgKGxldCBrID0gMDsgayA8IHdlaWdodHMubGVuZ3RoOyBrKyspIHtcbiAgICAgICAgICAgICAgICAgICAgc3VtICs9IHdlaWdodHNba10gKiBpbnB1dFtrXTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgLy8gcmVsdVxuICAgICAgICAgICAgICAgIGFjdGl2ZU91dHB1dHNbbm9kZV0gPSBzdW0gPCAwID8gMCA6IHN1bTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIG91dHB1dCA9IGlucHV0ID0gYWN0aXZlT3V0cHV0cztcbiAgICAgICAgfVxuICAgICAgICBpZiAoIW91dHB1dCkge1xuICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdvdXRwdXQgd2FzIGVtcHR5Jyk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIG91dHB1dDtcbiAgICB9XG4gICAgX3J1bklucHV0TGVha3lSZWx1KGlucHV0KSB7XG4gICAgICAgIHRoaXMub3V0cHV0c1swXSA9IGlucHV0OyAvLyBzZXQgb3V0cHV0IHN0YXRlIG9mIGlucHV0IGxheWVyXG4gICAgICAgIGNvbnN0IHsgbGVha3lSZWx1QWxwaGEgfSA9IHRoaXMudHJhaW5PcHRzO1xuICAgICAgICBsZXQgb3V0cHV0ID0gbnVsbDtcbiAgICAgICAgZm9yIChsZXQgbGF5ZXIgPSAxOyBsYXllciA8PSB0aGlzLm91dHB1dExheWVyOyBsYXllcisrKSB7XG4gICAgICAgICAgICBjb25zdCBhY3RpdmVTaXplID0gdGhpcy5zaXplc1tsYXllcl07XG4gICAgICAgICAgICBjb25zdCBhY3RpdmVXZWlnaHRzID0gdGhpcy53ZWlnaHRzW2xheWVyXTtcbiAgICAgICAgICAgIGNvbnN0IGFjdGl2ZUJpYXNlcyA9IHRoaXMuYmlhc2VzW2xheWVyXTtcbiAgICAgICAgICAgIGNvbnN0IGFjdGl2ZU91dHB1dHMgPSB0aGlzLm91dHB1dHNbbGF5ZXJdO1xuICAgICAgICAgICAgZm9yIChsZXQgbm9kZSA9IDA7IG5vZGUgPCBhY3RpdmVTaXplOyBub2RlKyspIHtcbiAgICAgICAgICAgICAgICBjb25zdCB3ZWlnaHRzID0gYWN0aXZlV2VpZ2h0c1tub2RlXTtcbiAgICAgICAgICAgICAgICBsZXQgc3VtID0gYWN0aXZlQmlhc2VzW25vZGVdO1xuICAgICAgICAgICAgICAgIGZvciAobGV0IGsgPSAwOyBrIDwgd2VpZ2h0cy5sZW5ndGg7IGsrKykge1xuICAgICAgICAgICAgICAgICAgICBzdW0gKz0gd2VpZ2h0c1trXSAqIGlucHV0W2tdO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAvLyBsZWFreSByZWx1XG4gICAgICAgICAgICAgICAgYWN0aXZlT3V0cHV0c1tub2RlXSA9IE1hdGgubWF4KHN1bSwgbGVha3lSZWx1QWxwaGEgKiBzdW0pO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgb3V0cHV0ID0gaW5wdXQgPSBhY3RpdmVPdXRwdXRzO1xuICAgICAgICB9XG4gICAgICAgIGlmICghb3V0cHV0KSB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ291dHB1dCB3YXMgZW1wdHknKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gb3V0cHV0O1xuICAgIH1cbiAgICBfcnVuSW5wdXRUYW5oKGlucHV0KSB7XG4gICAgICAgIHRoaXMub3V0cHV0c1swXSA9IGlucHV0OyAvLyBzZXQgb3V0cHV0IHN0YXRlIG9mIGlucHV0IGxheWVyXG4gICAgICAgIGxldCBvdXRwdXQgPSBudWxsO1xuICAgICAgICBmb3IgKGxldCBsYXllciA9IDE7IGxheWVyIDw9IHRoaXMub3V0cHV0TGF5ZXI7IGxheWVyKyspIHtcbiAgICAgICAgICAgIGNvbnN0IGFjdGl2ZVNpemUgPSB0aGlzLnNpemVzW2xheWVyXTtcbiAgICAgICAgICAgIGNvbnN0IGFjdGl2ZVdlaWdodHMgPSB0aGlzLndlaWdodHNbbGF5ZXJdO1xuICAgICAgICAgICAgY29uc3QgYWN0aXZlQmlhc2VzID0gdGhpcy5iaWFzZXNbbGF5ZXJdO1xuICAgICAgICAgICAgY29uc3QgYWN0aXZlT3V0cHV0cyA9IHRoaXMub3V0cHV0c1tsYXllcl07XG4gICAgICAgICAgICBmb3IgKGxldCBub2RlID0gMDsgbm9kZSA8IGFjdGl2ZVNpemU7IG5vZGUrKykge1xuICAgICAgICAgICAgICAgIGNvbnN0IHdlaWdodHMgPSBhY3RpdmVXZWlnaHRzW25vZGVdO1xuICAgICAgICAgICAgICAgIGxldCBzdW0gPSBhY3RpdmVCaWFzZXNbbm9kZV07XG4gICAgICAgICAgICAgICAgZm9yIChsZXQgayA9IDA7IGsgPCB3ZWlnaHRzLmxlbmd0aDsgaysrKSB7XG4gICAgICAgICAgICAgICAgICAgIHN1bSArPSB3ZWlnaHRzW2tdICogaW5wdXRba107XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIC8vIHRhbmhcbiAgICAgICAgICAgICAgICBhY3RpdmVPdXRwdXRzW25vZGVdID0gTWF0aC50YW5oKHN1bSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBvdXRwdXQgPSBpbnB1dCA9IGFjdGl2ZU91dHB1dHM7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKCFvdXRwdXQpIHtcbiAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcignb3V0cHV0IHdhcyBlbXB0eScpO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBvdXRwdXQ7XG4gICAgfVxuICAgIC8qKlxuICAgICAqXG4gICAgICogVmVyaWZpZXMgbmV0d29yayBzaXplcyBhcmUgaW5pdGlhbGl6ZWRcbiAgICAgKiBJZiB0aGV5IGFyZSBub3QgaXQgd2lsbCBpbml0aWFsaXplIHRoZW0gYmFzZWQgb2ZmIHRoZSBkYXRhIHNldC5cbiAgICAgKi9cbiAgICB2ZXJpZnlJc0luaXRpYWxpemVkKHByZXBhcmVkRGF0YSkge1xuICAgICAgICBpZiAodGhpcy5zaXplcy5sZW5ndGgpXG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIHRoaXMuc2l6ZXMgPSBbXTtcbiAgICAgICAgdGhpcy5zaXplcy5wdXNoKHByZXBhcmVkRGF0YVswXS5pbnB1dC5sZW5ndGgpO1xuICAgICAgICBpZiAoIXRoaXMub3B0aW9ucy5oaWRkZW5MYXllcnMpIHtcbiAgICAgICAgICAgIHRoaXMuc2l6ZXMucHVzaChNYXRoLm1heCgzLCBNYXRoLmZsb29yKHByZXBhcmVkRGF0YVswXS5pbnB1dC5sZW5ndGggLyAyKSkpO1xuICAgICAgICB9XG4gICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgdGhpcy5vcHRpb25zLmhpZGRlbkxheWVycy5mb3JFYWNoKChzaXplKSA9PiB7XG4gICAgICAgICAgICAgICAgdGhpcy5zaXplcy5wdXNoKHNpemUpO1xuICAgICAgICAgICAgfSk7XG4gICAgICAgIH1cbiAgICAgICAgdGhpcy5zaXplcy5wdXNoKHByZXBhcmVkRGF0YVswXS5vdXRwdXQubGVuZ3RoKTtcbiAgICAgICAgdGhpcy5pbml0aWFsaXplKCk7XG4gICAgfVxuICAgIHVwZGF0ZVRyYWluaW5nT3B0aW9ucyh0cmFpbk9wdHMpIHtcbiAgICAgICAgY29uc3QgbWVyZ2VkID0geyAuLi50aGlzLnRyYWluT3B0cywgLi4udHJhaW5PcHRzIH07XG4gICAgICAgIHRoaXMudmFsaWRhdGVUcmFpbmluZ09wdGlvbnMobWVyZ2VkKTtcbiAgICAgICAgdGhpcy50cmFpbk9wdHMgPSBtZXJnZWQ7XG4gICAgICAgIHRoaXMuc2V0TG9nTWV0aG9kKHRoaXMudHJhaW5PcHRzLmxvZyk7XG4gICAgfVxuICAgIHZhbGlkYXRlVHJhaW5pbmdPcHRpb25zKG9wdGlvbnMpIHtcbiAgICAgICAgY29uc3QgdmFsaWRhdGlvbnMgPSB7XG4gICAgICAgICAgICBhY3RpdmF0aW9uOiAoKSA9PiB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIFsnc2lnbW9pZCcsICdyZWx1JywgJ2xlYWt5LXJlbHUnLCAndGFuaCddLmluY2x1ZGVzKG9wdGlvbnMuYWN0aXZhdGlvbik7XG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgaXRlcmF0aW9uczogKCkgPT4ge1xuICAgICAgICAgICAgICAgIGNvbnN0IHZhbCA9IG9wdGlvbnMuaXRlcmF0aW9ucztcbiAgICAgICAgICAgICAgICByZXR1cm4gdHlwZW9mIHZhbCA9PT0gJ251bWJlcicgJiYgdmFsID4gMDtcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBlcnJvclRocmVzaDogKCkgPT4ge1xuICAgICAgICAgICAgICAgIGNvbnN0IHZhbCA9IG9wdGlvbnMuZXJyb3JUaHJlc2g7XG4gICAgICAgICAgICAgICAgcmV0dXJuIHR5cGVvZiB2YWwgPT09ICdudW1iZXInICYmIHZhbCA+IDAgJiYgdmFsIDwgMTtcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBsb2c6ICgpID0+IHtcbiAgICAgICAgICAgICAgICBjb25zdCB2YWwgPSBvcHRpb25zLmxvZztcbiAgICAgICAgICAgICAgICByZXR1cm4gdHlwZW9mIHZhbCA9PT0gJ2Z1bmN0aW9uJyB8fCB0eXBlb2YgdmFsID09PSAnYm9vbGVhbic7XG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgbG9nUGVyaW9kOiAoKSA9PiB7XG4gICAgICAgICAgICAgICAgY29uc3QgdmFsID0gb3B0aW9ucy5sb2dQZXJpb2Q7XG4gICAgICAgICAgICAgICAgcmV0dXJuIHR5cGVvZiB2YWwgPT09ICdudW1iZXInICYmIHZhbCA+IDA7XG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgbGVha3lSZWx1QWxwaGE6ICgpID0+IHtcbiAgICAgICAgICAgICAgICBjb25zdCB2YWwgPSBvcHRpb25zLmxlYWt5UmVsdUFscGhhO1xuICAgICAgICAgICAgICAgIHJldHVybiB0eXBlb2YgdmFsID09PSAnbnVtYmVyJyAmJiB2YWwgPiAwICYmIHZhbCA8IDE7XG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgbGVhcm5pbmdSYXRlOiAoKSA9PiB7XG4gICAgICAgICAgICAgICAgY29uc3QgdmFsID0gb3B0aW9ucy5sZWFybmluZ1JhdGU7XG4gICAgICAgICAgICAgICAgcmV0dXJuIHR5cGVvZiB2YWwgPT09ICdudW1iZXInICYmIHZhbCA+IDAgJiYgdmFsIDwgMTtcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBtb21lbnR1bTogKCkgPT4ge1xuICAgICAgICAgICAgICAgIGNvbnN0IHZhbCA9IG9wdGlvbnMubW9tZW50dW07XG4gICAgICAgICAgICAgICAgcmV0dXJuIHR5cGVvZiB2YWwgPT09ICdudW1iZXInICYmIHZhbCA+IDAgJiYgdmFsIDwgMTtcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBjYWxsYmFjazogKCkgPT4ge1xuICAgICAgICAgICAgICAgIGNvbnN0IHZhbCA9IG9wdGlvbnMuY2FsbGJhY2s7XG4gICAgICAgICAgICAgICAgcmV0dXJuIHR5cGVvZiB2YWwgPT09ICdmdW5jdGlvbicgfHwgdmFsID09PSB1bmRlZmluZWQ7XG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgY2FsbGJhY2tQZXJpb2Q6ICgpID0+IHtcbiAgICAgICAgICAgICAgICBjb25zdCB2YWwgPSBvcHRpb25zLmNhbGxiYWNrUGVyaW9kO1xuICAgICAgICAgICAgICAgIHJldHVybiB0eXBlb2YgdmFsID09PSAnbnVtYmVyJyAmJiB2YWwgPiAwO1xuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIHRpbWVvdXQ6ICgpID0+IHtcbiAgICAgICAgICAgICAgICBjb25zdCB2YWwgPSBvcHRpb25zLnRpbWVvdXQ7XG4gICAgICAgICAgICAgICAgcmV0dXJuIHR5cGVvZiB2YWwgPT09ICdudW1iZXInICYmIHZhbCA+IDA7XG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgcHJheGlzOiAoKSA9PiB7XG4gICAgICAgICAgICAgICAgY29uc3QgdmFsID0gb3B0aW9ucy5wcmF4aXM7XG4gICAgICAgICAgICAgICAgcmV0dXJuICF2YWwgfHwgdmFsID09PSAnYWRhbSc7XG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgYmV0YTE6ICgpID0+IHtcbiAgICAgICAgICAgICAgICBjb25zdCB2YWwgPSBvcHRpb25zLmJldGExO1xuICAgICAgICAgICAgICAgIHJldHVybiB2YWwgPiAwICYmIHZhbCA8IDE7XG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgYmV0YTI6ICgpID0+IHtcbiAgICAgICAgICAgICAgICBjb25zdCB2YWwgPSBvcHRpb25zLmJldGEyO1xuICAgICAgICAgICAgICAgIHJldHVybiB2YWwgPiAwICYmIHZhbCA8IDE7XG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgZXBzaWxvbjogKCkgPT4ge1xuICAgICAgICAgICAgICAgIGNvbnN0IHZhbCA9IG9wdGlvbnMuZXBzaWxvbjtcbiAgICAgICAgICAgICAgICByZXR1cm4gdmFsID4gMCAmJiB2YWwgPCAxO1xuICAgICAgICAgICAgfSxcbiAgICAgICAgfTtcbiAgICAgICAgZm9yIChjb25zdCBwIGluIHZhbGlkYXRpb25zKSB7XG4gICAgICAgICAgICBjb25zdCB2ID0gb3B0aW9ucztcbiAgICAgICAgICAgIGlmICghdmFsaWRhdGlvbnNbcF0oKSkge1xuICAgICAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcihgWyR7cH0sICR7dltwXX1dIGlzIG91dCBvZiBub3JtYWwgdHJhaW5pbmcgcmFuZ2UsIHlvdXIgbmV0d29yayB3aWxsIHByb2JhYmx5IG5vdCB0cmFpbi5gKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIH1cbiAgICAvKipcbiAgICAgKlxuICAgICAqICBHZXRzIEpTT04gb2YgdHJhaW5PcHRzIG9iamVjdFxuICAgICAqICAgIE5PVEU6IEFjdGl2YXRpb24gaXMgc3RvcmVkIGRpcmVjdGx5IG9uIEpTT04gb2JqZWN0IGFuZCBub3QgaW4gdGhlIHRyYWluaW5nIG9wdGlvbnNcbiAgICAgKi9cbiAgICBnZXRUcmFpbk9wdHNKU09OKCkge1xuICAgICAgICBjb25zdCB7IGFjdGl2YXRpb24sIGl0ZXJhdGlvbnMsIGVycm9yVGhyZXNoLCBsb2csIGxvZ1BlcmlvZCwgbGVha3lSZWx1QWxwaGEsIGxlYXJuaW5nUmF0ZSwgbW9tZW50dW0sIGNhbGxiYWNrUGVyaW9kLCB0aW1lb3V0LCBwcmF4aXMsIGJldGExLCBiZXRhMiwgZXBzaWxvbiwgfSA9IHRoaXMudHJhaW5PcHRzO1xuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgYWN0aXZhdGlvbixcbiAgICAgICAgICAgIGl0ZXJhdGlvbnMsXG4gICAgICAgICAgICBlcnJvclRocmVzaCxcbiAgICAgICAgICAgIGxvZzogdHlwZW9mIGxvZyA9PT0gJ2Z1bmN0aW9uJ1xuICAgICAgICAgICAgICAgID8gdHJ1ZVxuICAgICAgICAgICAgICAgIDogdHlwZW9mIGxvZyA9PT0gJ2Jvb2xlYW4nXG4gICAgICAgICAgICAgICAgICAgID8gbG9nXG4gICAgICAgICAgICAgICAgICAgIDogZmFsc2UsXG4gICAgICAgICAgICBsb2dQZXJpb2QsXG4gICAgICAgICAgICBsZWFreVJlbHVBbHBoYSxcbiAgICAgICAgICAgIGxlYXJuaW5nUmF0ZSxcbiAgICAgICAgICAgIG1vbWVudHVtLFxuICAgICAgICAgICAgY2FsbGJhY2tQZXJpb2QsXG4gICAgICAgICAgICB0aW1lb3V0OiB0aW1lb3V0ID09PSBJbmZpbml0eSA/ICdJbmZpbml0eScgOiB0aW1lb3V0LFxuICAgICAgICAgICAgcHJheGlzLFxuICAgICAgICAgICAgYmV0YTEsXG4gICAgICAgICAgICBiZXRhMixcbiAgICAgICAgICAgIGVwc2lsb24sXG4gICAgICAgIH07XG4gICAgfVxuICAgIHNldExvZ01ldGhvZChsb2cpIHtcbiAgICAgICAgaWYgKHR5cGVvZiBsb2cgPT09ICdmdW5jdGlvbicpIHtcbiAgICAgICAgICAgIHRoaXMudHJhaW5PcHRzLmxvZyA9IGxvZztcbiAgICAgICAgfVxuICAgICAgICBlbHNlIGlmIChsb2cpIHtcbiAgICAgICAgICAgIHRoaXMudHJhaW5PcHRzLmxvZyA9IHRoaXMubG9nVHJhaW5pbmdTdGF0dXM7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICB0aGlzLnRyYWluT3B0cy5sb2cgPSBmYWxzZTtcbiAgICAgICAgfVxuICAgIH1cbiAgICBsb2dUcmFpbmluZ1N0YXR1cyhzdGF0dXMpIHtcbiAgICAgICAgY29uc29sZS5sb2coYGl0ZXJhdGlvbnM6ICR7c3RhdHVzLml0ZXJhdGlvbnN9LCB0cmFpbmluZyBlcnJvcjogJHtzdGF0dXMuZXJyb3J9YCk7XG4gICAgfVxuICAgIGNhbGN1bGF0ZVRyYWluaW5nRXJyb3IoZGF0YSkge1xuICAgICAgICBsZXQgc3VtID0gMDtcbiAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBkYXRhLmxlbmd0aDsgKytpKSB7XG4gICAgICAgICAgICBzdW0gKz0gdGhpcy50cmFpblBhdHRlcm4oZGF0YVtpXSwgdHJ1ZSk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHN1bSAvIGRhdGEubGVuZ3RoO1xuICAgIH1cbiAgICB0cmFpblBhdHRlcm5zKGRhdGEpIHtcbiAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBkYXRhLmxlbmd0aDsgKytpKSB7XG4gICAgICAgICAgICB0aGlzLnRyYWluUGF0dGVybihkYXRhW2ldKTtcbiAgICAgICAgfVxuICAgIH1cbiAgICB0cmFpbmluZ1RpY2soZGF0YSwgc3RhdHVzLCBlbmRUaW1lKSB7XG4gICAgICAgIGNvbnN0IHsgY2FsbGJhY2ssIGNhbGxiYWNrUGVyaW9kLCBlcnJvclRocmVzaCwgaXRlcmF0aW9ucywgbG9nLCBsb2dQZXJpb2QsIH0gPSB0aGlzLnRyYWluT3B0cztcbiAgICAgICAgaWYgKHN0YXR1cy5pdGVyYXRpb25zID49IGl0ZXJhdGlvbnMgfHxcbiAgICAgICAgICAgIHN0YXR1cy5lcnJvciA8PSBlcnJvclRocmVzaCB8fFxuICAgICAgICAgICAgRGF0ZS5ub3coKSA+PSBlbmRUaW1lKSB7XG4gICAgICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgICAgIH1cbiAgICAgICAgc3RhdHVzLml0ZXJhdGlvbnMrKztcbiAgICAgICAgaWYgKGxvZyAmJiBzdGF0dXMuaXRlcmF0aW9ucyAlIGxvZ1BlcmlvZCA9PT0gMCkge1xuICAgICAgICAgICAgc3RhdHVzLmVycm9yID0gdGhpcy5jYWxjdWxhdGVUcmFpbmluZ0Vycm9yKGRhdGEpO1xuICAgICAgICAgICAgbG9nKHN0YXR1cyk7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSBpZiAoc3RhdHVzLml0ZXJhdGlvbnMgJSB0aGlzLmVycm9yQ2hlY2tJbnRlcnZhbCA9PT0gMCkge1xuICAgICAgICAgICAgc3RhdHVzLmVycm9yID0gdGhpcy5jYWxjdWxhdGVUcmFpbmluZ0Vycm9yKGRhdGEpO1xuICAgICAgICB9XG4gICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgdGhpcy50cmFpblBhdHRlcm5zKGRhdGEpO1xuICAgICAgICB9XG4gICAgICAgIGlmIChjYWxsYmFjayAmJiBzdGF0dXMuaXRlcmF0aW9ucyAlIGNhbGxiYWNrUGVyaW9kID09PSAwKSB7XG4gICAgICAgICAgICBjYWxsYmFjayh7XG4gICAgICAgICAgICAgICAgaXRlcmF0aW9uczogc3RhdHVzLml0ZXJhdGlvbnMsXG4gICAgICAgICAgICAgICAgZXJyb3I6IHN0YXR1cy5lcnJvcixcbiAgICAgICAgICAgIH0pO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiB0cnVlO1xuICAgIH1cbiAgICBwcmVwVHJhaW5pbmcoZGF0YSwgb3B0aW9ucyA9IHt9KSB7XG4gICAgICAgIHRoaXMudXBkYXRlVHJhaW5pbmdPcHRpb25zKG9wdGlvbnMpO1xuICAgICAgICBjb25zdCBwcmVwYXJlZERhdGEgPSB0aGlzLmZvcm1hdERhdGEoZGF0YSk7XG4gICAgICAgIGNvbnN0IGVuZFRpbWUgPSBEYXRlLm5vdygpICsgdGhpcy50cmFpbk9wdHMudGltZW91dDtcbiAgICAgICAgY29uc3Qgc3RhdHVzID0ge1xuICAgICAgICAgICAgZXJyb3I6IDEsXG4gICAgICAgICAgICBpdGVyYXRpb25zOiAwLFxuICAgICAgICB9O1xuICAgICAgICB0aGlzLnZlcmlmeUlzSW5pdGlhbGl6ZWQocHJlcGFyZWREYXRhKTtcbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgIHByZXBhcmVkRGF0YSxcbiAgICAgICAgICAgIHN0YXR1cyxcbiAgICAgICAgICAgIGVuZFRpbWUsXG4gICAgICAgIH07XG4gICAgfVxuICAgIHRyYWluKGRhdGEsIG9wdGlvbnMgPSB7fSkge1xuICAgICAgICBjb25zdCB7IHByZXBhcmVkRGF0YSwgc3RhdHVzLCBlbmRUaW1lIH0gPSB0aGlzLnByZXBUcmFpbmluZyhkYXRhLCBvcHRpb25zKTtcbiAgICAgICAgd2hpbGUgKHRydWUpIHtcbiAgICAgICAgICAgIGlmICghdGhpcy50cmFpbmluZ1RpY2socHJlcGFyZWREYXRhLCBzdGF0dXMsIGVuZFRpbWUpKSB7XG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHN0YXR1cztcbiAgICB9XG4gICAgYXN5bmMgdHJhaW5Bc3luYyhkYXRhLCBvcHRpb25zID0ge30pIHtcbiAgICAgICAgY29uc3QgeyBwcmVwYXJlZERhdGEsIHN0YXR1cywgZW5kVGltZSB9ID0gdGhpcy5wcmVwVHJhaW5pbmcoZGF0YSwgb3B0aW9ucyk7XG4gICAgICAgIHJldHVybiBhd2FpdCBuZXcgUHJvbWlzZSgocmVzb2x2ZSwgcmVqZWN0KSA9PiB7XG4gICAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgICAgIGNvbnN0IHRoYXdlZFRyYWluID0gbmV3IGRpc3QuVGhhdyhuZXcgQXJyYXkodGhpcy50cmFpbk9wdHMuaXRlcmF0aW9ucyksIHtcbiAgICAgICAgICAgICAgICAgICAgZGVsYXk6IHRydWUsXG4gICAgICAgICAgICAgICAgICAgIGVhY2g6ICgpID0+IHRoaXMudHJhaW5pbmdUaWNrKHByZXBhcmVkRGF0YSwgc3RhdHVzLCBlbmRUaW1lKSB8fFxuICAgICAgICAgICAgICAgICAgICAgICAgdGhhd2VkVHJhaW4uc3RvcCgpLFxuICAgICAgICAgICAgICAgICAgICBkb25lOiAoKSA9PiByZXNvbHZlKHN0YXR1cyksXG4gICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgdGhhd2VkVHJhaW4udGljaygpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgY2F0Y2ggKHRyYWluRXJyb3IpIHtcbiAgICAgICAgICAgICAgICByZWplY3QodHJhaW5FcnJvcik7XG4gICAgICAgICAgICB9XG4gICAgICAgIH0pO1xuICAgIH1cbiAgICB0cmFpblBhdHRlcm4odmFsdWUsIGxvZ0Vycm9yUmF0ZSkge1xuICAgICAgICAvLyBmb3J3YXJkIHByb3BhZ2F0ZVxuICAgICAgICB0aGlzLnJ1bklucHV0KHZhbHVlLmlucHV0KTtcbiAgICAgICAgLy8gYmFjayBwcm9wYWdhdGVcbiAgICAgICAgdGhpcy5jYWxjdWxhdGVEZWx0YXModmFsdWUub3V0cHV0KTtcbiAgICAgICAgdGhpcy5hZGp1c3RXZWlnaHRzKCk7XG4gICAgICAgIGlmIChsb2dFcnJvclJhdGUpIHtcbiAgICAgICAgICAgIHJldHVybiBtc2UkMSh0aGlzLmVycm9yc1t0aGlzLm91dHB1dExheWVyXSk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIG51bGw7XG4gICAgfVxuICAgIF9jYWxjdWxhdGVEZWx0YXNTaWdtb2lkKHRhcmdldCkge1xuICAgICAgICBmb3IgKGxldCBsYXllciA9IHRoaXMub3V0cHV0TGF5ZXI7IGxheWVyID49IDA7IGxheWVyLS0pIHtcbiAgICAgICAgICAgIGNvbnN0IGFjdGl2ZVNpemUgPSB0aGlzLnNpemVzW2xheWVyXTtcbiAgICAgICAgICAgIGNvbnN0IGFjdGl2ZU91dHB1dCA9IHRoaXMub3V0cHV0c1tsYXllcl07XG4gICAgICAgICAgICBjb25zdCBhY3RpdmVFcnJvciA9IHRoaXMuZXJyb3JzW2xheWVyXTtcbiAgICAgICAgICAgIGNvbnN0IGFjdGl2ZURlbHRhcyA9IHRoaXMuZGVsdGFzW2xheWVyXTtcbiAgICAgICAgICAgIGNvbnN0IG5leHRMYXllciA9IHRoaXMud2VpZ2h0c1tsYXllciArIDFdO1xuICAgICAgICAgICAgZm9yIChsZXQgbm9kZSA9IDA7IG5vZGUgPCBhY3RpdmVTaXplOyBub2RlKyspIHtcbiAgICAgICAgICAgICAgICBjb25zdCBvdXRwdXQgPSBhY3RpdmVPdXRwdXRbbm9kZV07XG4gICAgICAgICAgICAgICAgbGV0IGVycm9yID0gMDtcbiAgICAgICAgICAgICAgICBpZiAobGF5ZXIgPT09IHRoaXMub3V0cHV0TGF5ZXIpIHtcbiAgICAgICAgICAgICAgICAgICAgZXJyb3IgPSB0YXJnZXRbbm9kZV0gLSBvdXRwdXQ7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICBjb25zdCBkZWx0YXMgPSB0aGlzLmRlbHRhc1tsYXllciArIDFdO1xuICAgICAgICAgICAgICAgICAgICBmb3IgKGxldCBrID0gMDsgayA8IGRlbHRhcy5sZW5ndGg7IGsrKykge1xuICAgICAgICAgICAgICAgICAgICAgICAgZXJyb3IgKz0gZGVsdGFzW2tdICogbmV4dExheWVyW2tdW25vZGVdO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGFjdGl2ZUVycm9yW25vZGVdID0gZXJyb3I7XG4gICAgICAgICAgICAgICAgYWN0aXZlRGVsdGFzW25vZGVdID0gZXJyb3IgKiBvdXRwdXQgKiAoMSAtIG91dHB1dCk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9XG4gICAgX2NhbGN1bGF0ZURlbHRhc1JlbHUodGFyZ2V0KSB7XG4gICAgICAgIGZvciAobGV0IGxheWVyID0gdGhpcy5vdXRwdXRMYXllcjsgbGF5ZXIgPj0gMDsgbGF5ZXItLSkge1xuICAgICAgICAgICAgY29uc3QgY3VycmVudFNpemUgPSB0aGlzLnNpemVzW2xheWVyXTtcbiAgICAgICAgICAgIGNvbnN0IGN1cnJlbnRPdXRwdXRzID0gdGhpcy5vdXRwdXRzW2xheWVyXTtcbiAgICAgICAgICAgIGNvbnN0IG5leHRXZWlnaHRzID0gdGhpcy53ZWlnaHRzW2xheWVyICsgMV07XG4gICAgICAgICAgICBjb25zdCBuZXh0RGVsdGFzID0gdGhpcy5kZWx0YXNbbGF5ZXIgKyAxXTtcbiAgICAgICAgICAgIGNvbnN0IGN1cnJlbnRFcnJvcnMgPSB0aGlzLmVycm9yc1tsYXllcl07XG4gICAgICAgICAgICBjb25zdCBjdXJyZW50RGVsdGFzID0gdGhpcy5kZWx0YXNbbGF5ZXJdO1xuICAgICAgICAgICAgZm9yIChsZXQgbm9kZSA9IDA7IG5vZGUgPCBjdXJyZW50U2l6ZTsgbm9kZSsrKSB7XG4gICAgICAgICAgICAgICAgY29uc3Qgb3V0cHV0ID0gY3VycmVudE91dHB1dHNbbm9kZV07XG4gICAgICAgICAgICAgICAgbGV0IGVycm9yID0gMDtcbiAgICAgICAgICAgICAgICBpZiAobGF5ZXIgPT09IHRoaXMub3V0cHV0TGF5ZXIpIHtcbiAgICAgICAgICAgICAgICAgICAgZXJyb3IgPSB0YXJnZXRbbm9kZV0gLSBvdXRwdXQ7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICBmb3IgKGxldCBrID0gMDsgayA8IG5leHREZWx0YXMubGVuZ3RoOyBrKyspIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGVycm9yICs9IG5leHREZWx0YXNba10gKiBuZXh0V2VpZ2h0c1trXVtub2RlXTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBjdXJyZW50RXJyb3JzW25vZGVdID0gZXJyb3I7XG4gICAgICAgICAgICAgICAgY3VycmVudERlbHRhc1tub2RlXSA9IG91dHB1dCA+IDAgPyBlcnJvciA6IDA7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9XG4gICAgX2NhbGN1bGF0ZURlbHRhc0xlYWt5UmVsdSh0YXJnZXQpIHtcbiAgICAgICAgY29uc3QgYWxwaGEgPSB0aGlzLnRyYWluT3B0cy5sZWFreVJlbHVBbHBoYTtcbiAgICAgICAgZm9yIChsZXQgbGF5ZXIgPSB0aGlzLm91dHB1dExheWVyOyBsYXllciA+PSAwOyBsYXllci0tKSB7XG4gICAgICAgICAgICBjb25zdCBjdXJyZW50U2l6ZSA9IHRoaXMuc2l6ZXNbbGF5ZXJdO1xuICAgICAgICAgICAgY29uc3QgY3VycmVudE91dHB1dHMgPSB0aGlzLm91dHB1dHNbbGF5ZXJdO1xuICAgICAgICAgICAgY29uc3QgbmV4dERlbHRhcyA9IHRoaXMuZGVsdGFzW2xheWVyICsgMV07XG4gICAgICAgICAgICBjb25zdCBuZXh0V2VpZ2h0cyA9IHRoaXMud2VpZ2h0c1tsYXllciArIDFdO1xuICAgICAgICAgICAgY29uc3QgY3VycmVudEVycm9ycyA9IHRoaXMuZXJyb3JzW2xheWVyXTtcbiAgICAgICAgICAgIGNvbnN0IGN1cnJlbnREZWx0YXMgPSB0aGlzLmRlbHRhc1tsYXllcl07XG4gICAgICAgICAgICBmb3IgKGxldCBub2RlID0gMDsgbm9kZSA8IGN1cnJlbnRTaXplOyBub2RlKyspIHtcbiAgICAgICAgICAgICAgICBjb25zdCBvdXRwdXQgPSBjdXJyZW50T3V0cHV0c1tub2RlXTtcbiAgICAgICAgICAgICAgICBsZXQgZXJyb3IgPSAwO1xuICAgICAgICAgICAgICAgIGlmIChsYXllciA9PT0gdGhpcy5vdXRwdXRMYXllcikge1xuICAgICAgICAgICAgICAgICAgICBlcnJvciA9IHRhcmdldFtub2RlXSAtIG91dHB1dDtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgIGZvciAobGV0IGsgPSAwOyBrIDwgbmV4dERlbHRhcy5sZW5ndGg7IGsrKykge1xuICAgICAgICAgICAgICAgICAgICAgICAgZXJyb3IgKz0gbmV4dERlbHRhc1trXSAqIG5leHRXZWlnaHRzW2tdW25vZGVdO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGN1cnJlbnRFcnJvcnNbbm9kZV0gPSBlcnJvcjtcbiAgICAgICAgICAgICAgICBjdXJyZW50RGVsdGFzW25vZGVdID0gb3V0cHV0ID4gMCA/IGVycm9yIDogYWxwaGEgKiBlcnJvcjtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIH1cbiAgICBfY2FsY3VsYXRlRGVsdGFzVGFuaCh0YXJnZXQpIHtcbiAgICAgICAgZm9yIChsZXQgbGF5ZXIgPSB0aGlzLm91dHB1dExheWVyOyBsYXllciA+PSAwOyBsYXllci0tKSB7XG4gICAgICAgICAgICBjb25zdCBjdXJyZW50U2l6ZSA9IHRoaXMuc2l6ZXNbbGF5ZXJdO1xuICAgICAgICAgICAgY29uc3QgY3VycmVudE91dHB1dHMgPSB0aGlzLm91dHB1dHNbbGF5ZXJdO1xuICAgICAgICAgICAgY29uc3QgbmV4dERlbHRhcyA9IHRoaXMuZGVsdGFzW2xheWVyICsgMV07XG4gICAgICAgICAgICBjb25zdCBuZXh0V2VpZ2h0cyA9IHRoaXMud2VpZ2h0c1tsYXllciArIDFdO1xuICAgICAgICAgICAgY29uc3QgY3VycmVudEVycm9ycyA9IHRoaXMuZXJyb3JzW2xheWVyXTtcbiAgICAgICAgICAgIGNvbnN0IGN1cnJlbnREZWx0YXMgPSB0aGlzLmRlbHRhc1tsYXllcl07XG4gICAgICAgICAgICBmb3IgKGxldCBub2RlID0gMDsgbm9kZSA8IGN1cnJlbnRTaXplOyBub2RlKyspIHtcbiAgICAgICAgICAgICAgICBjb25zdCBvdXRwdXQgPSBjdXJyZW50T3V0cHV0c1tub2RlXTtcbiAgICAgICAgICAgICAgICBsZXQgZXJyb3IgPSAwO1xuICAgICAgICAgICAgICAgIGlmIChsYXllciA9PT0gdGhpcy5vdXRwdXRMYXllcikge1xuICAgICAgICAgICAgICAgICAgICBlcnJvciA9IHRhcmdldFtub2RlXSAtIG91dHB1dDtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgIGZvciAobGV0IGsgPSAwOyBrIDwgbmV4dERlbHRhcy5sZW5ndGg7IGsrKykge1xuICAgICAgICAgICAgICAgICAgICAgICAgZXJyb3IgKz0gbmV4dERlbHRhc1trXSAqIG5leHRXZWlnaHRzW2tdW25vZGVdO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGN1cnJlbnRFcnJvcnNbbm9kZV0gPSBlcnJvcjtcbiAgICAgICAgICAgICAgICBjdXJyZW50RGVsdGFzW25vZGVdID0gKDEgLSBvdXRwdXQgKiBvdXRwdXQpICogZXJyb3I7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9XG4gICAgLyoqXG4gICAgICpcbiAgICAgKiBDaGFuZ2VzIHdlaWdodHMgb2YgbmV0d29ya3NcbiAgICAgKi9cbiAgICBhZGp1c3RXZWlnaHRzKCkge1xuICAgICAgICBjb25zdCB7IGxlYXJuaW5nUmF0ZSwgbW9tZW50dW0gfSA9IHRoaXMudHJhaW5PcHRzO1xuICAgICAgICBmb3IgKGxldCBsYXllciA9IDE7IGxheWVyIDw9IHRoaXMub3V0cHV0TGF5ZXI7IGxheWVyKyspIHtcbiAgICAgICAgICAgIGNvbnN0IGluY29taW5nID0gdGhpcy5vdXRwdXRzW2xheWVyIC0gMV07XG4gICAgICAgICAgICBjb25zdCBhY3RpdmVTaXplID0gdGhpcy5zaXplc1tsYXllcl07XG4gICAgICAgICAgICBjb25zdCBhY3RpdmVEZWx0YSA9IHRoaXMuZGVsdGFzW2xheWVyXTtcbiAgICAgICAgICAgIGNvbnN0IGFjdGl2ZUNoYW5nZXMgPSB0aGlzLmNoYW5nZXNbbGF5ZXJdO1xuICAgICAgICAgICAgY29uc3QgYWN0aXZlV2VpZ2h0cyA9IHRoaXMud2VpZ2h0c1tsYXllcl07XG4gICAgICAgICAgICBjb25zdCBhY3RpdmVCaWFzZXMgPSB0aGlzLmJpYXNlc1tsYXllcl07XG4gICAgICAgICAgICBmb3IgKGxldCBub2RlID0gMDsgbm9kZSA8IGFjdGl2ZVNpemU7IG5vZGUrKykge1xuICAgICAgICAgICAgICAgIGNvbnN0IGRlbHRhID0gYWN0aXZlRGVsdGFbbm9kZV07XG4gICAgICAgICAgICAgICAgZm9yIChsZXQgayA9IDA7IGsgPCBpbmNvbWluZy5sZW5ndGg7IGsrKykge1xuICAgICAgICAgICAgICAgICAgICBsZXQgY2hhbmdlID0gYWN0aXZlQ2hhbmdlc1tub2RlXVtrXTtcbiAgICAgICAgICAgICAgICAgICAgY2hhbmdlID0gbGVhcm5pbmdSYXRlICogZGVsdGEgKiBpbmNvbWluZ1trXSArIG1vbWVudHVtICogY2hhbmdlO1xuICAgICAgICAgICAgICAgICAgICBhY3RpdmVDaGFuZ2VzW25vZGVdW2tdID0gY2hhbmdlO1xuICAgICAgICAgICAgICAgICAgICBhY3RpdmVXZWlnaHRzW25vZGVdW2tdICs9IGNoYW5nZTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgYWN0aXZlQmlhc2VzW25vZGVdICs9IGxlYXJuaW5nUmF0ZSAqIGRlbHRhO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfVxuICAgIF9zZXR1cEFkYW0oKSB7XG4gICAgICAgIHRoaXMuYmlhc0NoYW5nZXNMb3cgPSBbXTtcbiAgICAgICAgdGhpcy5iaWFzQ2hhbmdlc0hpZ2ggPSBbXTtcbiAgICAgICAgdGhpcy5jaGFuZ2VzTG93ID0gW107XG4gICAgICAgIHRoaXMuY2hhbmdlc0hpZ2ggPSBbXTtcbiAgICAgICAgdGhpcy5pdGVyYXRpb25zID0gMDtcbiAgICAgICAgZm9yIChsZXQgbGF5ZXIgPSAwOyBsYXllciA8PSB0aGlzLm91dHB1dExheWVyOyBsYXllcisrKSB7XG4gICAgICAgICAgICBjb25zdCBzaXplID0gdGhpcy5zaXplc1tsYXllcl07XG4gICAgICAgICAgICBpZiAobGF5ZXIgPiAwKSB7XG4gICAgICAgICAgICAgICAgdGhpcy5iaWFzQ2hhbmdlc0xvd1tsYXllcl0gPSB6ZXJvcyQxKHNpemUpO1xuICAgICAgICAgICAgICAgIHRoaXMuYmlhc0NoYW5nZXNIaWdoW2xheWVyXSA9IHplcm9zJDEoc2l6ZSk7XG4gICAgICAgICAgICAgICAgdGhpcy5jaGFuZ2VzTG93W2xheWVyXSA9IG5ldyBBcnJheShzaXplKTtcbiAgICAgICAgICAgICAgICB0aGlzLmNoYW5nZXNIaWdoW2xheWVyXSA9IG5ldyBBcnJheShzaXplKTtcbiAgICAgICAgICAgICAgICBmb3IgKGxldCBub2RlID0gMDsgbm9kZSA8IHNpemU7IG5vZGUrKykge1xuICAgICAgICAgICAgICAgICAgICBjb25zdCBwcmV2U2l6ZSA9IHRoaXMuc2l6ZXNbbGF5ZXIgLSAxXTtcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5jaGFuZ2VzTG93W2xheWVyXVtub2RlXSA9IHplcm9zJDEocHJldlNpemUpO1xuICAgICAgICAgICAgICAgICAgICB0aGlzLmNoYW5nZXNIaWdoW2xheWVyXVtub2RlXSA9IHplcm9zJDEocHJldlNpemUpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICB0aGlzLmFkanVzdFdlaWdodHMgPSB0aGlzLl9hZGp1c3RXZWlnaHRzQWRhbTtcbiAgICB9XG4gICAgX2FkanVzdFdlaWdodHNBZGFtKCkge1xuICAgICAgICB0aGlzLml0ZXJhdGlvbnMrKztcbiAgICAgICAgY29uc3QgeyBpdGVyYXRpb25zIH0gPSB0aGlzO1xuICAgICAgICBjb25zdCB7IGJldGExLCBiZXRhMiwgZXBzaWxvbiwgbGVhcm5pbmdSYXRlIH0gPSB0aGlzLnRyYWluT3B0cztcbiAgICAgICAgZm9yIChsZXQgbGF5ZXIgPSAxOyBsYXllciA8PSB0aGlzLm91dHB1dExheWVyOyBsYXllcisrKSB7XG4gICAgICAgICAgICBjb25zdCBpbmNvbWluZyA9IHRoaXMub3V0cHV0c1tsYXllciAtIDFdO1xuICAgICAgICAgICAgY29uc3QgY3VycmVudFNpemUgPSB0aGlzLnNpemVzW2xheWVyXTtcbiAgICAgICAgICAgIGNvbnN0IGN1cnJlbnREZWx0YXMgPSB0aGlzLmRlbHRhc1tsYXllcl07XG4gICAgICAgICAgICBjb25zdCBjdXJyZW50Q2hhbmdlc0xvdyA9IHRoaXMuY2hhbmdlc0xvd1tsYXllcl07XG4gICAgICAgICAgICBjb25zdCBjdXJyZW50Q2hhbmdlc0hpZ2ggPSB0aGlzLmNoYW5nZXNIaWdoW2xheWVyXTtcbiAgICAgICAgICAgIGNvbnN0IGN1cnJlbnRXZWlnaHRzID0gdGhpcy53ZWlnaHRzW2xheWVyXTtcbiAgICAgICAgICAgIGNvbnN0IGN1cnJlbnRCaWFzZXMgPSB0aGlzLmJpYXNlc1tsYXllcl07XG4gICAgICAgICAgICBjb25zdCBjdXJyZW50Qmlhc0NoYW5nZXNMb3cgPSB0aGlzLmJpYXNDaGFuZ2VzTG93W2xheWVyXTtcbiAgICAgICAgICAgIGNvbnN0IGN1cnJlbnRCaWFzQ2hhbmdlc0hpZ2ggPSB0aGlzLmJpYXNDaGFuZ2VzSGlnaFtsYXllcl07XG4gICAgICAgICAgICBmb3IgKGxldCBub2RlID0gMDsgbm9kZSA8IGN1cnJlbnRTaXplOyBub2RlKyspIHtcbiAgICAgICAgICAgICAgICBjb25zdCBkZWx0YSA9IGN1cnJlbnREZWx0YXNbbm9kZV07XG4gICAgICAgICAgICAgICAgZm9yIChsZXQgayA9IDA7IGsgPCBpbmNvbWluZy5sZW5ndGg7IGsrKykge1xuICAgICAgICAgICAgICAgICAgICBjb25zdCBncmFkaWVudCA9IGRlbHRhICogaW5jb21pbmdba107XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IGNoYW5nZUxvdyA9IGN1cnJlbnRDaGFuZ2VzTG93W25vZGVdW2tdICogYmV0YTEgKyAoMSAtIGJldGExKSAqIGdyYWRpZW50O1xuICAgICAgICAgICAgICAgICAgICBjb25zdCBjaGFuZ2VIaWdoID0gY3VycmVudENoYW5nZXNIaWdoW25vZGVdW2tdICogYmV0YTIgK1xuICAgICAgICAgICAgICAgICAgICAgICAgKDEgLSBiZXRhMikgKiBncmFkaWVudCAqIGdyYWRpZW50O1xuICAgICAgICAgICAgICAgICAgICBjb25zdCBtb21lbnR1bUNvcnJlY3Rpb24gPSBjaGFuZ2VMb3cgLyAoMSAtIE1hdGgucG93KGJldGExLCBpdGVyYXRpb25zKSk7XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IGdyYWRpZW50Q29ycmVjdGlvbiA9IGNoYW5nZUhpZ2ggLyAoMSAtIE1hdGgucG93KGJldGEyLCBpdGVyYXRpb25zKSk7XG4gICAgICAgICAgICAgICAgICAgIGN1cnJlbnRDaGFuZ2VzTG93W25vZGVdW2tdID0gY2hhbmdlTG93O1xuICAgICAgICAgICAgICAgICAgICBjdXJyZW50Q2hhbmdlc0hpZ2hbbm9kZV1ba10gPSBjaGFuZ2VIaWdoO1xuICAgICAgICAgICAgICAgICAgICBjdXJyZW50V2VpZ2h0c1tub2RlXVtrXSArPVxuICAgICAgICAgICAgICAgICAgICAgICAgKGxlYXJuaW5nUmF0ZSAqIG1vbWVudHVtQ29ycmVjdGlvbikgL1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIChNYXRoLnNxcnQoZ3JhZGllbnRDb3JyZWN0aW9uKSArIGVwc2lsb24pO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBjb25zdCBiaWFzR3JhZGllbnQgPSBjdXJyZW50RGVsdGFzW25vZGVdO1xuICAgICAgICAgICAgICAgIGNvbnN0IGJpYXNDaGFuZ2VMb3cgPSBjdXJyZW50Qmlhc0NoYW5nZXNMb3dbbm9kZV0gKiBiZXRhMSArICgxIC0gYmV0YTEpICogYmlhc0dyYWRpZW50O1xuICAgICAgICAgICAgICAgIGNvbnN0IGJpYXNDaGFuZ2VIaWdoID0gY3VycmVudEJpYXNDaGFuZ2VzSGlnaFtub2RlXSAqIGJldGEyICtcbiAgICAgICAgICAgICAgICAgICAgKDEgLSBiZXRhMikgKiBiaWFzR3JhZGllbnQgKiBiaWFzR3JhZGllbnQ7XG4gICAgICAgICAgICAgICAgY29uc3QgYmlhc01vbWVudHVtQ29ycmVjdGlvbiA9IGN1cnJlbnRCaWFzQ2hhbmdlc0xvd1tub2RlXSAvICgxIC0gTWF0aC5wb3coYmV0YTEsIGl0ZXJhdGlvbnMpKTtcbiAgICAgICAgICAgICAgICBjb25zdCBiaWFzR3JhZGllbnRDb3JyZWN0aW9uID0gY3VycmVudEJpYXNDaGFuZ2VzSGlnaFtub2RlXSAvICgxIC0gTWF0aC5wb3coYmV0YTIsIGl0ZXJhdGlvbnMpKTtcbiAgICAgICAgICAgICAgICBjdXJyZW50Qmlhc0NoYW5nZXNMb3dbbm9kZV0gPSBiaWFzQ2hhbmdlTG93O1xuICAgICAgICAgICAgICAgIGN1cnJlbnRCaWFzQ2hhbmdlc0hpZ2hbbm9kZV0gPSBiaWFzQ2hhbmdlSGlnaDtcbiAgICAgICAgICAgICAgICBjdXJyZW50Qmlhc2VzW25vZGVdICs9XG4gICAgICAgICAgICAgICAgICAgIChsZWFybmluZ1JhdGUgKiBiaWFzTW9tZW50dW1Db3JyZWN0aW9uKSAvXG4gICAgICAgICAgICAgICAgICAgICAgICAoTWF0aC5zcXJ0KGJpYXNHcmFkaWVudENvcnJlY3Rpb24pICsgZXBzaWxvbik7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9XG4gICAgZm9ybWF0RGF0YShkYXRhKSB7XG4gICAgICAgIGlmICghQXJyYXkuaXNBcnJheShkYXRhWzBdLmlucHV0KSkge1xuICAgICAgICAgICAgaWYgKHRoaXMuaW5wdXRMb29rdXApIHtcbiAgICAgICAgICAgICAgICB0aGlzLmlucHV0TG9va3VwTGVuZ3RoID0gT2JqZWN0LmtleXModGhpcy5pbnB1dExvb2t1cCkubGVuZ3RoO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgICAgY29uc3QgaW5wdXRMb29rdXAgPSBuZXcgTG9va3VwVGFibGUoZGF0YSwgJ2lucHV0Jyk7XG4gICAgICAgICAgICAgICAgdGhpcy5pbnB1dExvb2t1cCA9IGlucHV0TG9va3VwLnRhYmxlO1xuICAgICAgICAgICAgICAgIHRoaXMuaW5wdXRMb29rdXBMZW5ndGggPSBpbnB1dExvb2t1cC5sZW5ndGg7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgaWYgKCFBcnJheS5pc0FycmF5KGRhdGFbMF0ub3V0cHV0KSkge1xuICAgICAgICAgICAgaWYgKHRoaXMub3V0cHV0TG9va3VwKSB7XG4gICAgICAgICAgICAgICAgdGhpcy5vdXRwdXRMb29rdXBMZW5ndGggPSBPYmplY3Qua2V5cyh0aGlzLm91dHB1dExvb2t1cCkubGVuZ3RoO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgICAgY29uc3QgbG9va3VwID0gbmV3IExvb2t1cFRhYmxlKGRhdGEsICdvdXRwdXQnKTtcbiAgICAgICAgICAgICAgICB0aGlzLm91dHB1dExvb2t1cCA9IGxvb2t1cC50YWJsZTtcbiAgICAgICAgICAgICAgICB0aGlzLm91dHB1dExvb2t1cExlbmd0aCA9IGxvb2t1cC5sZW5ndGg7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgaWYgKCF0aGlzLl9mb3JtYXRJbnB1dCkge1xuICAgICAgICAgICAgdGhpcy5fZm9ybWF0SW5wdXQgPSBnZXRUeXBlZEFycmF5Rm4oZGF0YVswXS5pbnB1dCwgdGhpcy5pbnB1dExvb2t1cCk7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKCF0aGlzLl9mb3JtYXRPdXRwdXQpIHtcbiAgICAgICAgICAgIHRoaXMuX2Zvcm1hdE91dHB1dCA9IGdldFR5cGVkQXJyYXlGbihkYXRhWzBdLm91dHB1dCwgdGhpcy5vdXRwdXRMb29rdXApO1xuICAgICAgICB9XG4gICAgICAgIC8vIHR1cm4gc3BhcnNlIGhhc2ggaW5wdXQgaW50byBhcnJheXMgd2l0aCAwcyBhcyBmaWxsZXJcbiAgICAgICAgaWYgKHRoaXMuX2Zvcm1hdElucHV0ICYmIHRoaXMuX2Zvcm1hdE91dHB1dCkge1xuICAgICAgICAgICAgY29uc3QgcmVzdWx0ID0gW107XG4gICAgICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IGRhdGEubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgICAgICAgICByZXN1bHQucHVzaCh7XG4gICAgICAgICAgICAgICAgICAgIGlucHV0OiB0aGlzLl9mb3JtYXRJbnB1dChkYXRhW2ldLmlucHV0KSxcbiAgICAgICAgICAgICAgICAgICAgb3V0cHV0OiB0aGlzLl9mb3JtYXRPdXRwdXQoZGF0YVtpXS5vdXRwdXQpLFxuICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgcmV0dXJuIHJlc3VsdDtcbiAgICAgICAgfVxuICAgICAgICBpZiAodGhpcy5fZm9ybWF0SW5wdXQpIHtcbiAgICAgICAgICAgIGNvbnN0IHJlc3VsdCA9IFtdO1xuICAgICAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBkYXRhLmxlbmd0aDsgaSsrKSB7XG4gICAgICAgICAgICAgICAgcmVzdWx0LnB1c2goe1xuICAgICAgICAgICAgICAgICAgICBpbnB1dDogdGhpcy5fZm9ybWF0SW5wdXQoZGF0YVtpXS5pbnB1dCksXG4gICAgICAgICAgICAgICAgICAgIG91dHB1dDogZGF0YVtpXS5vdXRwdXQsXG4gICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICByZXR1cm4gcmVzdWx0O1xuICAgICAgICB9XG4gICAgICAgIGlmICh0aGlzLl9mb3JtYXRPdXRwdXQpIHtcbiAgICAgICAgICAgIGNvbnN0IHJlc3VsdCA9IFtdO1xuICAgICAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBkYXRhLmxlbmd0aDsgaSsrKSB7XG4gICAgICAgICAgICAgICAgcmVzdWx0LnB1c2goe1xuICAgICAgICAgICAgICAgICAgICBpbnB1dDogZGF0YVtpXS5pbnB1dCxcbiAgICAgICAgICAgICAgICAgICAgb3V0cHV0OiB0aGlzLl9mb3JtYXRPdXRwdXQoZGF0YVtpXS5vdXRwdXQpLFxuICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgcmV0dXJuIHJlc3VsdDtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gZGF0YTtcbiAgICB9XG4gICAgYWRkRm9ybWF0KGRhdGEpIHtcbiAgICAgICAgdmFyIF9hLCBfYjtcbiAgICAgICAgaWYgKCFBcnJheS5pc0FycmF5KGRhdGEuaW5wdXQpIHx8IHR5cGVvZiBkYXRhLmlucHV0WzBdICE9PSAnbnVtYmVyJykge1xuICAgICAgICAgICAgdGhpcy5pbnB1dExvb2t1cCA9IGxvb2t1cC5hZGRLZXlzKGRhdGEuaW5wdXQsIChfYSA9IHRoaXMuaW5wdXRMb29rdXApICE9PSBudWxsICYmIF9hICE9PSB2b2lkIDAgPyBfYSA6IHt9KTtcbiAgICAgICAgICAgIGlmICh0aGlzLmlucHV0TG9va3VwKSB7XG4gICAgICAgICAgICAgICAgdGhpcy5pbnB1dExvb2t1cExlbmd0aCA9IE9iamVjdC5rZXlzKHRoaXMuaW5wdXRMb29rdXApLmxlbmd0aDtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBpZiAoIUFycmF5LmlzQXJyYXkoZGF0YS5vdXRwdXQpIHx8IHR5cGVvZiBkYXRhLm91dHB1dFswXSAhPT0gJ251bWJlcicpIHtcbiAgICAgICAgICAgIHRoaXMub3V0cHV0TG9va3VwID0gbG9va3VwLmFkZEtleXMoZGF0YS5vdXRwdXQsIChfYiA9IHRoaXMub3V0cHV0TG9va3VwKSAhPT0gbnVsbCAmJiBfYiAhPT0gdm9pZCAwID8gX2IgOiB7fSk7XG4gICAgICAgICAgICBpZiAodGhpcy5vdXRwdXRMb29rdXApIHtcbiAgICAgICAgICAgICAgICB0aGlzLm91dHB1dExvb2t1cExlbmd0aCA9IE9iamVjdC5rZXlzKHRoaXMub3V0cHV0TG9va3VwKS5sZW5ndGg7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9XG4gICAgdGVzdChkYXRhKSB7XG4gICAgICAgIGNvbnN0IHsgcHJlcGFyZWREYXRhIH0gPSB0aGlzLnByZXBUcmFpbmluZyhkYXRhKTtcbiAgICAgICAgLy8gZm9yIGJpbmFyeSBjbGFzc2lmaWNhdGlvbiBwcm9ibGVtcyB3aXRoIG9uZSBvdXRwdXQgbm9kZVxuICAgICAgICBjb25zdCBpc0JpbmFyeSA9IHByZXBhcmVkRGF0YVswXS5vdXRwdXQubGVuZ3RoID09PSAxO1xuICAgICAgICAvLyBmb3IgY2xhc3NpZmljYXRpb24gcHJvYmxlbXNcbiAgICAgICAgY29uc3QgbWlzY2xhc3NlcyA9IFtdO1xuICAgICAgICAvLyBydW4gZWFjaCBwYXR0ZXJuIHRocm91Z2ggdGhlIHRyYWluZWQgbmV0d29yayBhbmQgY29sbGVjdFxuICAgICAgICAvLyBlcnJvciBhbmQgbWlzY2xhc3NpZmljYXRpb24gc3RhdGlzdGljc1xuICAgICAgICBsZXQgZXJyb3JTdW0gPSAwO1xuICAgICAgICBpZiAoaXNCaW5hcnkpIHtcbiAgICAgICAgICAgIGxldCBmYWxzZVBvcyA9IDA7XG4gICAgICAgICAgICBsZXQgZmFsc2VOZWcgPSAwO1xuICAgICAgICAgICAgbGV0IHRydWVQb3MgPSAwO1xuICAgICAgICAgICAgbGV0IHRydWVOZWcgPSAwO1xuICAgICAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBwcmVwYXJlZERhdGEubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgICAgICAgICBjb25zdCBvdXRwdXQgPSB0aGlzLnJ1bklucHV0KHByZXBhcmVkRGF0YVtpXS5pbnB1dCk7XG4gICAgICAgICAgICAgICAgY29uc3QgdGFyZ2V0ID0gcHJlcGFyZWREYXRhW2ldLm91dHB1dDtcbiAgICAgICAgICAgICAgICBjb25zdCBhY3R1YWwgPSBvdXRwdXRbMF0gPiB0aGlzLm9wdGlvbnMuYmluYXJ5VGhyZXNoID8gMSA6IDA7XG4gICAgICAgICAgICAgICAgY29uc3QgZXhwZWN0ZWQgPSB0YXJnZXRbMF07XG4gICAgICAgICAgICAgICAgaWYgKGFjdHVhbCAhPT0gZXhwZWN0ZWQpIHtcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgbWlzY2xhc3MgPSBwcmVwYXJlZERhdGFbaV07XG4gICAgICAgICAgICAgICAgICAgIG1pc2NsYXNzZXMucHVzaCh7XG4gICAgICAgICAgICAgICAgICAgICAgICBpbnB1dDogbWlzY2xhc3MuaW5wdXQsXG4gICAgICAgICAgICAgICAgICAgICAgICBvdXRwdXQ6IG1pc2NsYXNzLm91dHB1dCxcbiAgICAgICAgICAgICAgICAgICAgICAgIGFjdHVhbCxcbiAgICAgICAgICAgICAgICAgICAgICAgIGV4cGVjdGVkLFxuICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgaWYgKGFjdHVhbCA9PT0gMCAmJiBleHBlY3RlZCA9PT0gMCkge1xuICAgICAgICAgICAgICAgICAgICB0cnVlTmVnKys7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGVsc2UgaWYgKGFjdHVhbCA9PT0gMSAmJiBleHBlY3RlZCA9PT0gMSkge1xuICAgICAgICAgICAgICAgICAgICB0cnVlUG9zKys7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGVsc2UgaWYgKGFjdHVhbCA9PT0gMCAmJiBleHBlY3RlZCA9PT0gMSkge1xuICAgICAgICAgICAgICAgICAgICBmYWxzZU5lZysrO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBlbHNlIGlmIChhY3R1YWwgPT09IDEgJiYgZXhwZWN0ZWQgPT09IDApIHtcbiAgICAgICAgICAgICAgICAgICAgZmFsc2VQb3MrKztcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgZXJyb3JTdW0gKz0gbXNlJDEob3V0cHV0Lm1hcCgodmFsdWUsIGkpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHRhcmdldFtpXSAtIHZhbHVlO1xuICAgICAgICAgICAgICAgIH0pKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICAgICAgZXJyb3I6IGVycm9yU3VtIC8gcHJlcGFyZWREYXRhLmxlbmd0aCxcbiAgICAgICAgICAgICAgICBtaXNjbGFzc2VzLFxuICAgICAgICAgICAgICAgIHRvdGFsOiBwcmVwYXJlZERhdGEubGVuZ3RoLFxuICAgICAgICAgICAgICAgIHRydWVOZWcsXG4gICAgICAgICAgICAgICAgdHJ1ZVBvcyxcbiAgICAgICAgICAgICAgICBmYWxzZU5lZyxcbiAgICAgICAgICAgICAgICBmYWxzZVBvcyxcbiAgICAgICAgICAgICAgICBwcmVjaXNpb246IHRydWVQb3MgPiAwID8gdHJ1ZVBvcyAvICh0cnVlUG9zICsgZmFsc2VQb3MpIDogMCxcbiAgICAgICAgICAgICAgICByZWNhbGw6IHRydWVQb3MgPiAwID8gdHJ1ZVBvcyAvICh0cnVlUG9zICsgZmFsc2VOZWcpIDogMCxcbiAgICAgICAgICAgICAgICBhY2N1cmFjeTogKHRydWVOZWcgKyB0cnVlUG9zKSAvIHByZXBhcmVkRGF0YS5sZW5ndGgsXG4gICAgICAgICAgICB9O1xuICAgICAgICB9XG4gICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgcHJlcGFyZWREYXRhLmxlbmd0aDsgaSsrKSB7XG4gICAgICAgICAgICBjb25zdCBvdXRwdXQgPSB0aGlzLnJ1bklucHV0KHByZXBhcmVkRGF0YVtpXS5pbnB1dCk7XG4gICAgICAgICAgICBjb25zdCB0YXJnZXQgPSBwcmVwYXJlZERhdGFbaV0ub3V0cHV0O1xuICAgICAgICAgICAgY29uc3QgYWN0dWFsID0gb3V0cHV0LmluZGV4T2YobWF4KG91dHB1dCkpO1xuICAgICAgICAgICAgY29uc3QgZXhwZWN0ZWQgPSB0YXJnZXQuaW5kZXhPZihtYXgodGFyZ2V0KSk7XG4gICAgICAgICAgICBpZiAoYWN0dWFsICE9PSBleHBlY3RlZCkge1xuICAgICAgICAgICAgICAgIGNvbnN0IG1pc2NsYXNzID0gcHJlcGFyZWREYXRhW2ldO1xuICAgICAgICAgICAgICAgIG1pc2NsYXNzZXMucHVzaCh7XG4gICAgICAgICAgICAgICAgICAgIGlucHV0OiBtaXNjbGFzcy5pbnB1dCxcbiAgICAgICAgICAgICAgICAgICAgb3V0cHV0OiBtaXNjbGFzcy5vdXRwdXQsXG4gICAgICAgICAgICAgICAgICAgIGFjdHVhbCxcbiAgICAgICAgICAgICAgICAgICAgZXhwZWN0ZWQsXG4gICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBlcnJvclN1bSArPSBtc2UkMShvdXRwdXQubWFwKCh2YWx1ZSwgaSkgPT4ge1xuICAgICAgICAgICAgICAgIHJldHVybiB0YXJnZXRbaV0gLSB2YWx1ZTtcbiAgICAgICAgICAgIH0pKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgZXJyb3I6IGVycm9yU3VtIC8gcHJlcGFyZWREYXRhLmxlbmd0aCxcbiAgICAgICAgICAgIG1pc2NsYXNzZXMsXG4gICAgICAgICAgICB0b3RhbDogcHJlcGFyZWREYXRhLmxlbmd0aCxcbiAgICAgICAgfTtcbiAgICB9XG4gICAgdG9KU09OKCkge1xuICAgICAgICB2YXIgX2EsIF9iO1xuICAgICAgICBpZiAoIXRoaXMuaXNSdW5uYWJsZSkge1xuICAgICAgICAgICAgdGhpcy5pbml0aWFsaXplKCk7XG4gICAgICAgIH1cbiAgICAgICAgLy8gdXNlIEFycmF5LmZyb20sIGtlZXBpbmcganNvbiBzbWFsbFxuICAgICAgICBjb25zdCBqc29uTGF5ZXJXZWlnaHRzID0gdGhpcy53ZWlnaHRzLm1hcCgobGF5ZXJXZWlnaHRzKSA9PiB7XG4gICAgICAgICAgICByZXR1cm4gbGF5ZXJXZWlnaHRzLm1hcCgobGF5ZXJXZWlnaHRzKSA9PiBBcnJheS5mcm9tKGxheWVyV2VpZ2h0cykpO1xuICAgICAgICB9KTtcbiAgICAgICAgY29uc3QganNvbkxheWVyQmlhc2VzID0gdGhpcy5iaWFzZXMubWFwKChsYXllckJpYXNlcykgPT4gQXJyYXkuZnJvbShsYXllckJpYXNlcykpO1xuICAgICAgICBjb25zdCBqc29uTGF5ZXJzID0gW107XG4gICAgICAgIGNvbnN0IG91dHB1dExlbmd0aCA9IHRoaXMuc2l6ZXMubGVuZ3RoIC0gMTtcbiAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPD0gb3V0cHV0TGVuZ3RoOyBpKyspIHtcbiAgICAgICAgICAgIGpzb25MYXllcnMucHVzaCh7XG4gICAgICAgICAgICAgICAgd2VpZ2h0czogKF9hID0ganNvbkxheWVyV2VpZ2h0c1tpXSkgIT09IG51bGwgJiYgX2EgIT09IHZvaWQgMCA/IF9hIDogW10sXG4gICAgICAgICAgICAgICAgYmlhc2VzOiAoX2IgPSBqc29uTGF5ZXJCaWFzZXNbaV0pICE9PSBudWxsICYmIF9iICE9PSB2b2lkIDAgPyBfYiA6IFtdLFxuICAgICAgICAgICAgfSk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgIHR5cGU6ICdOZXVyYWxOZXR3b3JrJyxcbiAgICAgICAgICAgIHNpemVzOiBbLi4udGhpcy5zaXplc10sXG4gICAgICAgICAgICBsYXllcnM6IGpzb25MYXllcnMsXG4gICAgICAgICAgICBpbnB1dExvb2t1cDogdGhpcy5pbnB1dExvb2t1cCA/IHsgLi4udGhpcy5pbnB1dExvb2t1cCB9IDogbnVsbCxcbiAgICAgICAgICAgIGlucHV0TG9va3VwTGVuZ3RoOiB0aGlzLmlucHV0TG9va3VwTGVuZ3RoLFxuICAgICAgICAgICAgb3V0cHV0TG9va3VwOiB0aGlzLm91dHB1dExvb2t1cCA/IHsgLi4udGhpcy5vdXRwdXRMb29rdXAgfSA6IG51bGwsXG4gICAgICAgICAgICBvdXRwdXRMb29rdXBMZW5ndGg6IHRoaXMub3V0cHV0TG9va3VwTGVuZ3RoLFxuICAgICAgICAgICAgb3B0aW9uczogeyAuLi50aGlzLm9wdGlvbnMgfSxcbiAgICAgICAgICAgIHRyYWluT3B0czogdGhpcy5nZXRUcmFpbk9wdHNKU09OKCksXG4gICAgICAgIH07XG4gICAgfVxuICAgIGZyb21KU09OKGpzb24pIHtcbiAgICAgICAgdGhpcy5vcHRpb25zID0geyAuLi5kZWZhdWx0cyQyKCksIC4uLmpzb24ub3B0aW9ucyB9O1xuICAgICAgICBpZiAoanNvbi5oYXNPd25Qcm9wZXJ0eSgndHJhaW5PcHRzJykpIHtcbiAgICAgICAgICAgIGNvbnN0IHRyYWluT3B0cyA9IHtcbiAgICAgICAgICAgICAgICAuLi5qc29uLnRyYWluT3B0cyxcbiAgICAgICAgICAgICAgICB0aW1lb3V0OiBqc29uLnRyYWluT3B0cy50aW1lb3V0ID09PSAnSW5maW5pdHknXG4gICAgICAgICAgICAgICAgICAgID8gSW5maW5pdHlcbiAgICAgICAgICAgICAgICAgICAgOiBqc29uLnRyYWluT3B0cy50aW1lb3V0LFxuICAgICAgICAgICAgfTtcbiAgICAgICAgICAgIHRoaXMudXBkYXRlVHJhaW5pbmdPcHRpb25zKHRyYWluT3B0cyk7XG4gICAgICAgIH1cbiAgICAgICAgdGhpcy5zaXplcyA9IGpzb24uc2l6ZXM7XG4gICAgICAgIHRoaXMuaW5pdGlhbGl6ZSgpO1xuICAgICAgICB0aGlzLmlucHV0TG9va3VwID0ganNvbi5pbnB1dExvb2t1cCA/IHsgLi4uanNvbi5pbnB1dExvb2t1cCB9IDogbnVsbDtcbiAgICAgICAgdGhpcy5pbnB1dExvb2t1cExlbmd0aCA9IGpzb24uaW5wdXRMb29rdXBMZW5ndGg7XG4gICAgICAgIHRoaXMub3V0cHV0TG9va3VwID0ganNvbi5vdXRwdXRMb29rdXAgPyB7IC4uLmpzb24ub3V0cHV0TG9va3VwIH0gOiBudWxsO1xuICAgICAgICB0aGlzLm91dHB1dExvb2t1cExlbmd0aCA9IGpzb24ub3V0cHV0TG9va3VwTGVuZ3RoO1xuICAgICAgICBjb25zdCBqc29uTGF5ZXJzID0ganNvbi5sYXllcnM7XG4gICAgICAgIGNvbnN0IGxheWVyV2VpZ2h0cyA9IHRoaXMud2VpZ2h0cy5tYXAoKGxheWVyV2VpZ2h0cywgbGF5ZXJJbmRleCkgPT4ge1xuICAgICAgICAgICAgcmV0dXJuIGpzb25MYXllcnNbbGF5ZXJJbmRleF0ud2VpZ2h0cy5tYXAoKGxheWVyV2VpZ2h0cykgPT4gRmxvYXQzMkFycmF5LmZyb20obGF5ZXJXZWlnaHRzKSk7XG4gICAgICAgIH0pO1xuICAgICAgICBjb25zdCBsYXllckJpYXNlcyA9IHRoaXMuYmlhc2VzLm1hcCgobGF5ZXJCaWFzZXMsIGxheWVySW5kZXgpID0+IEZsb2F0MzJBcnJheS5mcm9tKGpzb25MYXllcnNbbGF5ZXJJbmRleF0uYmlhc2VzKSk7XG4gICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDw9IHRoaXMub3V0cHV0TGF5ZXI7IGkrKykge1xuICAgICAgICAgICAgdGhpcy53ZWlnaHRzW2ldID0gbGF5ZXJXZWlnaHRzW2ldIHx8IFtdO1xuICAgICAgICAgICAgdGhpcy5iaWFzZXNbaV0gPSBsYXllckJpYXNlc1tpXSB8fCBbXTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gdGhpcztcbiAgICB9XG4gICAgdG9GdW5jdGlvbihjYikge1xuICAgICAgICBjb25zdCB7IGFjdGl2YXRpb24sIGxlYWt5UmVsdUFscGhhIH0gPSB0aGlzLnRyYWluT3B0cztcbiAgICAgICAgbGV0IG5lZWRzVmFyID0gZmFsc2U7XG4gICAgICAgIGNvbnN0IG5vZGVIYW5kbGUgPSAobGF5ZXJJbmRleCwgbm9kZUluZGV4KSA9PiB7XG4gICAgICAgICAgICBpZiAobGF5ZXJJbmRleCA9PT0gMCkge1xuICAgICAgICAgICAgICAgIHJldHVybiBgKGlucHV0WyR7bm9kZUluZGV4fV18fDApYDtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGNvbnN0IHdlaWdodHMgPSB0aGlzLndlaWdodHNbbGF5ZXJJbmRleF1bbm9kZUluZGV4XTtcbiAgICAgICAgICAgIGNvbnN0IGJpYXMgPSB0aGlzLmJpYXNlc1tsYXllckluZGV4XVtub2RlSW5kZXhdO1xuICAgICAgICAgICAgaWYgKCF3ZWlnaHRzKSB7XG4gICAgICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKGB3ZWlnaHRzIGF0IGxheWVySW5kZXggJHtsYXllckluZGV4fSAmIG5vZGVJbmRleCAke25vZGVJbmRleH0gbm90IGZvdW5kYCk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBpZiAoIWJpYXMpIHtcbiAgICAgICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoYGJpYXMgYXMgbGF5ZXJJbmRleCAke2xheWVySW5kZXh9ICYgbm9kZUluZGV4ICR7bm9kZUluZGV4fSBub3QgZm91bmRgKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGNvbnN0IHdlaWdodHNBcnJheSA9IFtdO1xuICAgICAgICAgICAgd2VpZ2h0cy5mb3JFYWNoKCh3ZWlnaHQsIHN1Yk5vZGVJbmRleCkgPT4ge1xuICAgICAgICAgICAgICAgIGlmICh3ZWlnaHQgPCAwKSB7XG4gICAgICAgICAgICAgICAgICAgIHdlaWdodHNBcnJheS5wdXNoKGAke3dlaWdodH0qJHtub2RlSGFuZGxlKGxheWVySW5kZXggLSAxLCBzdWJOb2RlSW5kZXgpfWApO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgd2VpZ2h0c0FycmF5LnB1c2goYCske3dlaWdodH0qJHtub2RlSGFuZGxlKGxheWVySW5kZXggLSAxLCBzdWJOb2RlSW5kZXgpfWApO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgY29uc3QgcmVzdWx0ID0gYCgke2JpYXMudG9TdHJpbmcoKX0ke3dlaWdodHNBcnJheS5qb2luKCcnKX0pYDtcbiAgICAgICAgICAgIHN3aXRjaCAoYWN0aXZhdGlvbikge1xuICAgICAgICAgICAgICAgIGNhc2UgJ3NpZ21vaWQnOlxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gYDEvKDErMS9NYXRoLmV4cCgke3Jlc3VsdH0pKWA7XG4gICAgICAgICAgICAgICAgY2FzZSAncmVsdSc6IHtcbiAgICAgICAgICAgICAgICAgICAgbmVlZHNWYXIgPSB0cnVlO1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gYCgodj0ke3Jlc3VsdH0pPDA/MDp2KWA7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGNhc2UgJ2xlYWt5LXJlbHUnOiB7XG4gICAgICAgICAgICAgICAgICAgIG5lZWRzVmFyID0gdHJ1ZTtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGBNYXRoLm1heCgodj0ke3Jlc3VsdH0pLCR7bGVha3lSZWx1QWxwaGF9KnYpYDtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgY2FzZSAndGFuaCc6XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBgTWF0aC50YW5oKCR7cmVzdWx0fSlgO1xuICAgICAgICAgICAgICAgIGRlZmF1bHQ6XG4gICAgICAgICAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcihgVW5rbm93biBhY3RpdmF0aW9uICR7YWN0aXZhdGlvbn0uIEF2YWlsYWJsZSBhY3RpdmF0aW9ucyBhcmU6ICdzaWdtb2lkJywgJ3JlbHUnLCAnbGVha3ktcmVsdScsICd0YW5oJ2ApO1xuICAgICAgICAgICAgfVxuICAgICAgICB9O1xuICAgICAgICBmdW5jdGlvbiBjaGVja0tleXMoa2V5cykge1xuICAgICAgICAgICAgaWYgKGtleXMuZmluZCgodikgPT4gdi5pbmNsdWRlcygnXCInKSkpIHtcbiAgICAgICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoYGtleSBjb250YWlucyAnXCInLCB3aGljaCBpcyBub3QgY29tcGF0aWJsZWApO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIGNvbnN0IGxheWVyc0FzTWF0aCA9IFtdO1xuICAgICAgICBsZXQgcmVzdWx0O1xuICAgICAgICBsZXQgaW5wdXRMb29rdXAgPSAnJztcbiAgICAgICAgaWYgKHRoaXMuaW5wdXRMb29rdXApIHtcbiAgICAgICAgICAgIGNvbnN0IGtleXMgPSBPYmplY3Qua2V5cyh0aGlzLmlucHV0TG9va3VwKTtcbiAgICAgICAgICAgIGNoZWNrS2V5cyhrZXlzKTtcbiAgICAgICAgICAgIGlucHV0TG9va3VwID0gYGlucHV0ID0gbmV3IEZsb2F0MzJBcnJheShbJHtPYmplY3Qua2V5cyh0aGlzLmlucHV0TG9va3VwKVxuICAgICAgICAgICAgICAgIC5tYXAoKGtleSkgPT4gYGlucHV0W1wiJHtrZXl9XCJdYClcbiAgICAgICAgICAgICAgICAuam9pbignLCcpfV0pO2A7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKHRoaXMuc2l6ZXMubGVuZ3RoIDwgMSlcbiAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcignTm8gbGF5ZXJzJyk7XG4gICAgICAgIGZvciAobGV0IG5vZGVJbmRleCA9IDA7IG5vZGVJbmRleCA8IHRoaXMuc2l6ZXNbdGhpcy5vdXRwdXRMYXllcl07IG5vZGVJbmRleCsrKSB7XG4gICAgICAgICAgICBsYXllcnNBc01hdGgucHVzaChub2RlSGFuZGxlKHRoaXMub3V0cHV0TGF5ZXIsIG5vZGVJbmRleCkpO1xuICAgICAgICB9XG4gICAgICAgIGlmICh0aGlzLm91dHB1dExvb2t1cCkge1xuICAgICAgICAgICAgY29uc3Qga2V5cyA9IE9iamVjdC5rZXlzKHRoaXMub3V0cHV0TG9va3VwKTtcbiAgICAgICAgICAgIGNoZWNrS2V5cyhrZXlzKTtcbiAgICAgICAgICAgIGNvbnN0IHZhbHVlcyA9IGtleXNcbiAgICAgICAgICAgICAgICAubWFwKChrZXksIGkpID0+IGBcIiR7a2V5fVwiOiR7bGF5ZXJzQXNNYXRoW2ldfWApXG4gICAgICAgICAgICAgICAgLmpvaW4oJywnKTtcbiAgICAgICAgICAgIHJlc3VsdCA9IGB7JHt2YWx1ZXN9fWA7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICByZXN1bHQgPSBgWyR7bGF5ZXJzQXNNYXRoLmpvaW4oJywnKX1dYDtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCBzb3VyY2UgPSBgJHtpbnB1dExvb2t1cH0ke25lZWRzVmFyID8gJ3ZhciB2OycgOiAnJ31yZXR1cm4gJHtyZXN1bHR9O2A7XG4gICAgICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBAdHlwZXNjcmlwdC1lc2xpbnQvbm8taW1wbGllZC1ldmFsLG5vLW5ldy1mdW5jXG4gICAgICAgIHJldHVybiBuZXcgRnVuY3Rpb24oJ2lucHV0JywgY2IgPyBjYihzb3VyY2UpIDogc291cmNlKTtcbiAgICB9XG59XG5cbmZ1bmN0aW9uIHdlaWdodGVkU3VtU2lnbW9pZCh3ZWlnaHRzLCBiaWFzZXMsIGlucHV0cykge1xuICAgIGxldCBzdW0gPSBiaWFzZXNbdGhpcy50aHJlYWQueF07XG4gICAgZm9yIChsZXQgayA9IDA7IGsgPCB0aGlzLmNvbnN0YW50cy5zaXplOyBrKyspIHtcbiAgICAgICAgc3VtICs9IHdlaWdodHNbdGhpcy50aHJlYWQueF1ba10gKiBpbnB1dHNba107XG4gICAgfVxuICAgIC8vIHNpZ21vaWRcbiAgICByZXR1cm4gMSAvICgxICsgTWF0aC5leHAoLXN1bSkpO1xufVxuZnVuY3Rpb24gd2VpZ2h0ZWRTdW1SZWx1KHdlaWdodHMsIGJpYXNlcywgaW5wdXRzKSB7XG4gICAgbGV0IHN1bSA9IGJpYXNlc1t0aGlzLnRocmVhZC54XTtcbiAgICBmb3IgKGxldCBrID0gMDsgayA8IHRoaXMuY29uc3RhbnRzLnNpemU7IGsrKykge1xuICAgICAgICBzdW0gKz0gd2VpZ2h0c1t0aGlzLnRocmVhZC54XVtrXSAqIGlucHV0c1trXTtcbiAgICB9XG4gICAgLy8gcmVsdVxuICAgIHJldHVybiBzdW0gPCAwID8gMCA6IHN1bTtcbn1cbmZ1bmN0aW9uIHdlaWdodGVkU3VtTGVha3lSZWx1KHdlaWdodHMsIGJpYXNlcywgaW5wdXRzKSB7XG4gICAgbGV0IHN1bSA9IGJpYXNlc1t0aGlzLnRocmVhZC54XTtcbiAgICBmb3IgKGxldCBrID0gMDsgayA8IHRoaXMuY29uc3RhbnRzLnNpemU7IGsrKykge1xuICAgICAgICBzdW0gKz0gd2VpZ2h0c1t0aGlzLnRocmVhZC54XVtrXSAqIGlucHV0c1trXTtcbiAgICB9XG4gICAgLy8gbGVha3kgcmVsdVxuICAgIHJldHVybiBzdW0gPCAwID8gMCA6IDAuMDEgKiBzdW07XG59XG5mdW5jdGlvbiB3ZWlnaHRlZFN1bVRhbmgod2VpZ2h0cywgYmlhc2VzLCBpbnB1dHMpIHtcbiAgICBsZXQgc3VtID0gYmlhc2VzW3RoaXMudGhyZWFkLnhdO1xuICAgIGZvciAobGV0IGsgPSAwOyBrIDwgdGhpcy5jb25zdGFudHMuc2l6ZTsgaysrKSB7XG4gICAgICAgIHN1bSArPSB3ZWlnaHRzW3RoaXMudGhyZWFkLnhdW2tdICogaW5wdXRzW2tdO1xuICAgIH1cbiAgICAvLyB0YW5oXG4gICAgcmV0dXJuIE1hdGgudGFuaChzdW0pO1xufVxuZnVuY3Rpb24gY2FsY0Vycm9yT3V0cHV0KG91dHB1dCwgdGFyZ2V0KSB7XG4gICAgcmV0dXJuIHRhcmdldCAtIG91dHB1dDtcbn1cbmZ1bmN0aW9uIGNhbGNEZWx0YXNTaWdtb2lkKGVycm9yLCBvdXRwdXQpIHtcbiAgICAvLyBzaWdtb2lkIGRlcml2YXRpdmVcbiAgICByZXR1cm4gZXJyb3IgKiBvdXRwdXQgKiAoMSAtIG91dHB1dCk7XG59XG5mdW5jdGlvbiBjYWxjRGVsdGFzUmVsdShlcnJvciwgb3V0cHV0KSB7XG4gICAgLy8gcmVsdSBkZXJpdmF0aXZlXG4gICAgcmV0dXJuIG91dHB1dCA+IDAgPyBlcnJvciA6IDA7XG59XG5mdW5jdGlvbiBjYWxjRGVsdGFzTGVha3lSZWx1KGVycm9yLCBvdXRwdXQpIHtcbiAgICAvLyBsZWFreSByZWx1IGRlcml2YXRpdmVcbiAgICByZXR1cm4gb3V0cHV0ID4gMCA/IGVycm9yIDogMC4wMSAqIGVycm9yO1xufVxuZnVuY3Rpb24gY2FsY0RlbHRhc1RhbmgoZXJyb3IsIG91dHB1dCkge1xuICAgIC8vIHRhbmggZGVyaXZhdGl2ZVxuICAgIHJldHVybiAoMSAtIG91dHB1dCAqIG91dHB1dCkgKiBlcnJvcjtcbn1cbmZ1bmN0aW9uIGNhbGNFcnJvcih4LCBzaXplLCBuZXh0V2VpZ2h0cywgbmV4dERlbHRhcykge1xuICAgIGxldCBlcnJvciA9IDA7XG4gICAgZm9yIChsZXQgayA9IDA7IGsgPCBzaXplOyBrKyspIHtcbiAgICAgICAgZXJyb3IgKz0gbmV4dERlbHRhc1trXSAqIG5leHRXZWlnaHRzW2tdW3hdO1xuICAgIH1cbiAgICByZXR1cm4gZXJyb3I7XG59XG5mdW5jdGlvbiBjYWxjQ2hhbmdlcyhsZWFybmluZ1JhdGUsIG1vbWVudHVtLCBwcmV2aW91c0NoYW5nZSwgZGVsdGEsIHByZXZpb3VzT3V0cHV0KSB7XG4gICAgcmV0dXJuIGxlYXJuaW5nUmF0ZSAqIGRlbHRhICogcHJldmlvdXNPdXRwdXQgKyBtb21lbnR1bSAqIHByZXZpb3VzQ2hhbmdlO1xufVxuZnVuY3Rpb24gYWRkV2VpZ2h0cyhjaGFuZ2UsIHdlaWdodCkge1xuICAgIHJldHVybiBjaGFuZ2UgKyB3ZWlnaHQ7XG59XG5mdW5jdGlvbiBhZGRCaWFzZXMoYmlhc2VzLCBkZWx0YXMpIHtcbiAgICByZXR1cm4gKGJpYXNlc1t0aGlzLnRocmVhZC54XSArIGRlbHRhc1t0aGlzLnRocmVhZC54XSAqIHRoaXMuY29uc3RhbnRzLmxlYXJuaW5nUmF0ZSk7XG59XG4vLyBtZWFuIHNxdWFyZWQgZXJyb3IsIHJlaW1wbGVtZW50ZWQgZm9yIEdQVVxuZnVuY3Rpb24gbXNlKGVycm9ycykge1xuICAgIGxldCBzdW0gPSAwO1xuICAgIGZvciAobGV0IGkgPSAwOyBpIDwgdGhpcy5jb25zdGFudHMuc2l6ZTsgaSsrKSB7XG4gICAgICAgIHN1bSArPSBlcnJvcnNbaV0gKiogMjtcbiAgICB9XG4gICAgcmV0dXJuIHN1bSAvIHRoaXMuY29uc3RhbnRzLnNpemU7XG59XG5jbGFzcyBOZXVyYWxOZXR3b3JrR1BVIGV4dGVuZHMgTmV1cmFsTmV0d29yayB7XG4gICAgY29uc3RydWN0b3Iob3B0aW9ucyA9IHt9KSB7XG4gICAgICAgIHN1cGVyKG9wdGlvbnMpO1xuICAgICAgICB0aGlzLnRleHR1cml6ZUlucHV0RGF0YSA9ICgpID0+IHtcbiAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcignbm90IHlldCBzZXR1cCcpO1xuICAgICAgICB9O1xuICAgICAgICB0aGlzLmZvcndhcmRQcm9wYWdhdGUgPSBbXTtcbiAgICAgICAgdGhpcy5iYWNrd2FyZFByb3BhZ2F0ZSA9IFtdO1xuICAgICAgICB0aGlzLmNoYW5nZXNQcm9wYWdhdGUgPSBbXTtcbiAgICAgICAgdGhpcy5iaWFzZXNQcm9wYWdhdGUgPSBbXTtcbiAgICAgICAgdGhpcy5nZXRNU0UgPSAoKSA9PiB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ25vdCB5ZXQgc2V0dXAnKTtcbiAgICAgICAgfTtcbiAgICAgICAgdGhpcy5fYWRkTVNFID0gKCkgPT4ge1xuICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdub3QgeWV0IHNldHVwJyk7XG4gICAgICAgIH07XG4gICAgICAgIHRoaXMuX2RpdmlkZU1TRVN1bSA9ICgpID0+IHtcbiAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcignbm90IHlldCBzZXR1cCcpO1xuICAgICAgICB9O1xuICAgICAgICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgQHR5cGVzY3JpcHQtZXNsaW50L2Jhbi10cy1jb21tZW50XG4gICAgICAgIC8vIEB0cy1leHBlY3QtZXJyb3JcbiAgICAgICAgdGhpcy5vdXRwdXRzID0gW107XG4gICAgICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBAdHlwZXNjcmlwdC1lc2xpbnQvYmFuLXRzLWNvbW1lbnRcbiAgICAgICAgLy8gQHRzLWV4cGVjdC1lcnJvclxuICAgICAgICB0aGlzLmRlbHRhcyA9IFtdO1xuICAgICAgICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgQHR5cGVzY3JpcHQtZXNsaW50L2Jhbi10cy1jb21tZW50XG4gICAgICAgIC8vIEB0cy1leHBlY3QtZXJyb3JcbiAgICAgICAgdGhpcy5lcnJvcnMgPSBbXTtcbiAgICAgICAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIEB0eXBlc2NyaXB0LWVzbGludC9iYW4tdHMtY29tbWVudFxuICAgICAgICAvLyBAdHMtZXhwZWN0LWVycm9yXG4gICAgICAgIHRoaXMud2VpZ2h0cyA9IFtdO1xuICAgICAgICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgQHR5cGVzY3JpcHQtZXNsaW50L2Jhbi10cy1jb21tZW50XG4gICAgICAgIC8vIEB0cy1leHBlY3QtZXJyb3JcbiAgICAgICAgdGhpcy5jaGFuZ2VzID0gW107XG4gICAgICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBAdHlwZXNjcmlwdC1lc2xpbnQvYmFuLXRzLWNvbW1lbnRcbiAgICAgICAgLy8gQHRzLWV4cGVjdC1lcnJvclxuICAgICAgICB0aGlzLmJpYXNlcyA9IFtdO1xuICAgICAgICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgQHR5cGVzY3JpcHQtZXNsaW50L2Jhbi10cy1jb21tZW50XG4gICAgICAgIC8vIEB0cy1leHBlY3QtZXJyb3JcbiAgICAgICAgdGhpcy5ydW5JbnB1dCA9IChpbnB1dCkgPT4ge1xuICAgICAgICAgICAgbGV0IG91dHB1dDtcbiAgICAgICAgICAgIHRoaXMub3V0cHV0c1swXSA9IGlucHV0O1xuICAgICAgICAgICAgZm9yIChsZXQgbGF5ZXIgPSAxOyBsYXllciA8PSB0aGlzLm91dHB1dExheWVyOyBsYXllcisrKSB7XG4gICAgICAgICAgICAgICAgcmVsZWFzZSh0aGlzLm91dHB1dHNbbGF5ZXJdKTtcbiAgICAgICAgICAgICAgICB0aGlzLm91dHB1dHNbbGF5ZXJdID0gdGhpcy5mb3J3YXJkUHJvcGFnYXRlW2xheWVyXSh0aGlzLndlaWdodHNbbGF5ZXJdLCB0aGlzLmJpYXNlc1tsYXllcl0sIGlucHV0KTtcbiAgICAgICAgICAgICAgICBvdXRwdXQgPSBpbnB1dCA9IHRoaXMub3V0cHV0c1tsYXllcl07XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICByZXR1cm4gb3V0cHV0O1xuICAgICAgICB9O1xuICAgICAgICB0aGlzLmNhbGN1bGF0ZURlbHRhcyA9ICh0YXJnZXQpID0+IHtcbiAgICAgICAgICAgIGZvciAobGV0IGxheWVyID0gdGhpcy5vdXRwdXRMYXllcjsgbGF5ZXIgPiAwOyBsYXllci0tKSB7XG4gICAgICAgICAgICAgICAgcmVsZWFzZSh0aGlzLmRlbHRhc1tsYXllcl0pO1xuICAgICAgICAgICAgICAgIHJlbGVhc2UodGhpcy5lcnJvcnNbbGF5ZXJdKTtcbiAgICAgICAgICAgICAgICBsZXQgb3V0cHV0O1xuICAgICAgICAgICAgICAgIGlmIChsYXllciA9PT0gdGhpcy5vdXRwdXRMYXllcikge1xuICAgICAgICAgICAgICAgICAgICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgQHR5cGVzY3JpcHQtZXNsaW50L2Jhbi10cy1jb21tZW50XG4gICAgICAgICAgICAgICAgICAgIC8vIEB0cy1leHBlY3QtZXJyb3JcbiAgICAgICAgICAgICAgICAgICAgb3V0cHV0ID0gdGhpcy5iYWNrd2FyZFByb3BhZ2F0ZVtsYXllcl0odGhpcy5vdXRwdXRzW2xheWVyXSwgdGFyZ2V0KTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBAdHlwZXNjcmlwdC1lc2xpbnQvYmFuLXRzLWNvbW1lbnRcbiAgICAgICAgICAgICAgICAgICAgLy8gQHRzLWV4cGVjdC1lcnJvclxuICAgICAgICAgICAgICAgICAgICBvdXRwdXQgPSB0aGlzLmJhY2t3YXJkUHJvcGFnYXRlW2xheWVyXSh0aGlzLndlaWdodHNbbGF5ZXIgKyAxXSwgdGhpcy5vdXRwdXRzW2xheWVyXSwgdGhpcy5kZWx0YXNbbGF5ZXIgKyAxXSk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIHRoaXMuZGVsdGFzW2xheWVyXSA9IG91dHB1dC5yZXN1bHQ7XG4gICAgICAgICAgICAgICAgdGhpcy5lcnJvcnNbbGF5ZXJdID0gb3V0cHV0LmVycm9yO1xuICAgICAgICAgICAgfVxuICAgICAgICB9O1xuICAgICAgICB0aGlzLmVycm9yQ2hlY2tJbnRlcnZhbCA9IDEwMDtcbiAgICAgICAgdGhpcy5ncHUgPSBuZXcgZ3B1X2pzLkdQVSh7IG1vZGU6IG9wdGlvbnMubW9kZSB9KTtcbiAgICB9XG4gICAgaW5pdGlhbGl6ZSgpIHtcbiAgICAgICAgc3VwZXIuaW5pdGlhbGl6ZSgpO1xuICAgICAgICB0aGlzLmJ1aWxkUnVuSW5wdXQoKTtcbiAgICAgICAgdGhpcy5idWlsZENhbGN1bGF0ZURlbHRhcygpO1xuICAgICAgICB0aGlzLmJ1aWxkR2V0Q2hhbmdlcygpO1xuICAgICAgICB0aGlzLmJ1aWxkQ2hhbmdlQmlhc2VzKCk7XG4gICAgICAgIHRoaXMuYnVpbGRHZXRNU0UoKTtcbiAgICB9XG4gICAgc2V0QWN0aXZhdGlvbigpIHsgfVxuICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBAdHlwZXNjcmlwdC1lc2xpbnQvYmFuLXRzLWNvbW1lbnRcbiAgICAvLyBAdHMtZXhwZWN0LWVycm9yXG4gICAgdHJhaW5QYXR0ZXJuKHZhbHVlLCBsb2dFcnJvclJhdGUpIHtcbiAgICAgICAgLy8gZm9yd2FyZCBwcm9wYWdhdGVcbiAgICAgICAgdGhpcy5ydW5JbnB1dCh2YWx1ZS5pbnB1dCk7XG4gICAgICAgIC8vIGJhY2sgcHJvcGFnYXRlXG4gICAgICAgIHRoaXMuY2FsY3VsYXRlRGVsdGFzKHZhbHVlLm91dHB1dCk7XG4gICAgICAgIHRoaXMuYWRqdXN0V2VpZ2h0cygpO1xuICAgICAgICBpZiAobG9nRXJyb3JSYXRlKSB7XG4gICAgICAgICAgICByZXR1cm4gdGhpcy5nZXRNU0UodGhpcy5lcnJvcnNbdGhpcy5vdXRwdXRMYXllcl0pO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBudWxsO1xuICAgIH1cbiAgICBjYWxjdWxhdGVUcmFpbmluZ0Vycm9yKGRhdGEpIHtcbiAgICAgICAgbGV0IHN1bSA9IG5ldyBGbG9hdDMyQXJyYXkoWzBdKTtcbiAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBkYXRhLmxlbmd0aDsgKytpKSB7XG4gICAgICAgICAgICBjb25zdCBwcmV2U3VtID0gc3VtO1xuICAgICAgICAgICAgY29uc3QgZXJyb3IgPSB0aGlzLnRyYWluUGF0dGVybihkYXRhW2ldLCB0cnVlKTtcbiAgICAgICAgICAgIHN1bSA9IHRoaXMuX2FkZE1TRShzdW0sIGVycm9yKTtcbiAgICAgICAgICAgIHJlbGVhc2UoZXJyb3IpO1xuICAgICAgICAgICAgcmVsZWFzZShwcmV2U3VtKTtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCByZXN1bHQgPSB0aGlzLl9kaXZpZGVNU0VTdW0oZGF0YS5sZW5ndGgsIHN1bSk7XG4gICAgICAgIHJlbGVhc2Uoc3VtKTtcbiAgICAgICAgcmV0dXJuIChyZXN1bHQgaW5zdGFuY2VvZiBncHVfanMuVGV4dHVyZVxuICAgICAgICAgICAgPyByZXN1bHQudG9BcnJheSgpXG4gICAgICAgICAgICA6IHJlc3VsdClbMF07XG4gICAgfVxuICAgIGFkanVzdFdlaWdodHMoKSB7XG4gICAgICAgIHRoaXMuZ2V0Q2hhbmdlcygpO1xuICAgICAgICB0aGlzLmNoYW5nZUJpYXNlcygpO1xuICAgIH1cbiAgICBidWlsZFJ1bklucHV0KCkge1xuICAgICAgICBsZXQgd2VpZ2h0ZWRTdW0gPSBudWxsO1xuICAgICAgICBzd2l0Y2ggKHRoaXMudHJhaW5PcHRzLmFjdGl2YXRpb24pIHtcbiAgICAgICAgICAgIGNhc2UgJ3NpZ21vaWQnOlxuICAgICAgICAgICAgICAgIHdlaWdodGVkU3VtID0gd2VpZ2h0ZWRTdW1TaWdtb2lkO1xuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgY2FzZSAncmVsdSc6XG4gICAgICAgICAgICAgICAgd2VpZ2h0ZWRTdW0gPSB3ZWlnaHRlZFN1bVJlbHU7XG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICBjYXNlICdsZWFreS1yZWx1JzpcbiAgICAgICAgICAgICAgICB3ZWlnaHRlZFN1bSA9IHdlaWdodGVkU3VtTGVha3lSZWx1O1xuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgY2FzZSAndGFuaCc6XG4gICAgICAgICAgICAgICAgd2VpZ2h0ZWRTdW0gPSB3ZWlnaHRlZFN1bVRhbmg7XG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICBkZWZhdWx0OlxuICAgICAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcihgVW5rbm93biBhY3RpdmF0aW9uICR7dGhpcy50cmFpbk9wdHMuYWN0aXZhdGlvbn0uIEF2YWlsYWJsZSBhY3RpdmF0aW9ucyBhcmU6ICdzaWdtb2lkJywgJ3JlbHUnLCAnbGVha3ktcmVsdScsICd0YW5oJ2ApO1xuICAgICAgICB9XG4gICAgICAgIGZvciAobGV0IGxheWVyID0gMTsgbGF5ZXIgPD0gdGhpcy5vdXRwdXRMYXllcjsgbGF5ZXIrKykge1xuICAgICAgICAgICAgdGhpcy5mb3J3YXJkUHJvcGFnYXRlW2xheWVyXSA9IHRoaXMuZ3B1LmNyZWF0ZUtlcm5lbCh3ZWlnaHRlZFN1bSwge1xuICAgICAgICAgICAgICAgIG91dHB1dDogW3RoaXMuc2l6ZXNbbGF5ZXJdXSxcbiAgICAgICAgICAgICAgICBwaXBlbGluZTogdHJ1ZSxcbiAgICAgICAgICAgICAgICBjb25zdGFudHM6IHtcbiAgICAgICAgICAgICAgICAgICAgc2l6ZTogdGhpcy5zaXplc1tsYXllciAtIDFdLFxuICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgaW1tdXRhYmxlOiB0cnVlLFxuICAgICAgICAgICAgfSk7XG4gICAgICAgIH1cbiAgICAgICAgdGhpcy50ZXh0dXJpemVJbnB1dERhdGEgPSB0aGlzLmdwdS5jcmVhdGVLZXJuZWwoZnVuY3Rpb24gKHZhbHVlKSB7XG4gICAgICAgICAgICByZXR1cm4gdmFsdWVbdGhpcy50aHJlYWQueF07XG4gICAgICAgIH0sIHtcbiAgICAgICAgICAgIG91dHB1dDogW3RoaXMuc2l6ZXNbMV1dLFxuICAgICAgICAgICAgcGlwZWxpbmU6IHRydWUsXG4gICAgICAgICAgICBpbW11dGFibGU6IHRydWUsXG4gICAgICAgIH0pO1xuICAgIH1cbiAgICBidWlsZENhbGN1bGF0ZURlbHRhcygpIHtcbiAgICAgICAgbGV0IGNhbGNEZWx0YXM7XG4gICAgICAgIHN3aXRjaCAodGhpcy50cmFpbk9wdHMuYWN0aXZhdGlvbikge1xuICAgICAgICAgICAgY2FzZSAnc2lnbW9pZCc6XG4gICAgICAgICAgICAgICAgY2FsY0RlbHRhcyA9IGNhbGNEZWx0YXNTaWdtb2lkO1xuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgY2FzZSAncmVsdSc6XG4gICAgICAgICAgICAgICAgY2FsY0RlbHRhcyA9IGNhbGNEZWx0YXNSZWx1O1xuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgY2FzZSAnbGVha3ktcmVsdSc6XG4gICAgICAgICAgICAgICAgY2FsY0RlbHRhcyA9IGNhbGNEZWx0YXNMZWFreVJlbHU7XG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICBjYXNlICd0YW5oJzpcbiAgICAgICAgICAgICAgICBjYWxjRGVsdGFzID0gY2FsY0RlbHRhc1Rhbmg7XG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICBkZWZhdWx0OlxuICAgICAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcihgVW5rbm93biBhY3RpdmF0aW9uICR7dGhpcy50cmFpbk9wdHMuYWN0aXZhdGlvbn0uIEF2YWlsYWJsZSBhY3RpdmF0aW9ucyBhcmU6ICdzaWdtb2lkJywgJ3JlbHUnLCAnbGVha3ktcmVsdScsICd0YW5oJ2ApO1xuICAgICAgICB9XG4gICAgICAgIGNhbGNEZWx0YXMgPSBncHVfanMuYWxpYXMoZ3B1X2pzLnV0aWxzLmdldE1pbmlmeVNhZmVOYW1lKCgpID0+IGNhbGNEZWx0YXMpLCBjYWxjRGVsdGFzKTtcbiAgICAgICAgdGhpcy5ncHUuYWRkRnVuY3Rpb24oY2FsY0RlbHRhcyk7XG4gICAgICAgIGZvciAobGV0IGxheWVyID0gdGhpcy5vdXRwdXRMYXllcjsgbGF5ZXIgPiAwOyBsYXllci0tKSB7XG4gICAgICAgICAgICBpZiAobGF5ZXIgPT09IHRoaXMub3V0cHV0TGF5ZXIpIHtcbiAgICAgICAgICAgICAgICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgQHR5cGVzY3JpcHQtZXNsaW50L2Jhbi10cy1jb21tZW50XG4gICAgICAgICAgICAgICAgLy8gQHRzLWV4cGVjdC1lcnJvclxuICAgICAgICAgICAgICAgIHRoaXMuYmFja3dhcmRQcm9wYWdhdGVbdGhpcy5vdXRwdXRMYXllcl0gPSB0aGlzLmdwdS5jcmVhdGVLZXJuZWxNYXAoe1xuICAgICAgICAgICAgICAgICAgICBlcnJvcjogY2FsY0Vycm9yT3V0cHV0LFxuICAgICAgICAgICAgICAgIH0sIGZ1bmN0aW9uIChvdXRwdXRzLCB0YXJnZXRzKSB7XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IG91dHB1dCA9IG91dHB1dHNbdGhpcy50aHJlYWQueF07XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IHRhcmdldCA9IHRhcmdldHNbdGhpcy50aHJlYWQueF07XG4gICAgICAgICAgICAgICAgICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBAdHlwZXNjcmlwdC1lc2xpbnQvYmFuLXRzLWNvbW1lbnRcbiAgICAgICAgICAgICAgICAgICAgLy8gQHRzLWV4cGVjdC1lcnJvclxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gY2FsY0RlbHRhcyhjYWxjRXJyb3JPdXRwdXQob3V0cHV0LCB0YXJnZXQpLCBvdXRwdXQpO1xuICAgICAgICAgICAgICAgIH0sIHtcbiAgICAgICAgICAgICAgICAgICAgb3V0cHV0OiBbdGhpcy5zaXplc1t0aGlzLm91dHB1dExheWVyXV0sXG4gICAgICAgICAgICAgICAgICAgIHBpcGVsaW5lOiB0cnVlLFxuICAgICAgICAgICAgICAgICAgICBpbW11dGFibGU6IHRydWUsXG4gICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgICAgICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgQHR5cGVzY3JpcHQtZXNsaW50L2Jhbi10cy1jb21tZW50XG4gICAgICAgICAgICAgICAgLy8gQHRzLWV4cGVjdC1lcnJvclxuICAgICAgICAgICAgICAgIHRoaXMuYmFja3dhcmRQcm9wYWdhdGVbbGF5ZXJdID0gdGhpcy5ncHUuY3JlYXRlS2VybmVsTWFwKHtcbiAgICAgICAgICAgICAgICAgICAgZXJyb3I6IGNhbGNFcnJvcixcbiAgICAgICAgICAgICAgICB9LCBmdW5jdGlvbiAobmV4dFdlaWdodHMsIG91dHB1dHMsIG5leHREZWx0YXMpIHtcbiAgICAgICAgICAgICAgICAgICAgY29uc3Qgb3V0cHV0ID0gb3V0cHV0c1t0aGlzLnRocmVhZC54XTtcbiAgICAgICAgICAgICAgICAgICAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIEB0eXBlc2NyaXB0LWVzbGludC9iYW4tdHMtY29tbWVudFxuICAgICAgICAgICAgICAgICAgICAvLyBAdHMtZXhwZWN0LWVycm9yXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBjYWxjRGVsdGFzKGNhbGNFcnJvcih0aGlzLnRocmVhZC54LCB0aGlzLmNvbnN0YW50cy5zaXplLCBuZXh0V2VpZ2h0cywgbmV4dERlbHRhcyksIG91dHB1dCk7XG4gICAgICAgICAgICAgICAgfSwge1xuICAgICAgICAgICAgICAgICAgICBvdXRwdXQ6IFt0aGlzLnNpemVzW2xheWVyXV0sXG4gICAgICAgICAgICAgICAgICAgIHBpcGVsaW5lOiB0cnVlLFxuICAgICAgICAgICAgICAgICAgICBjb25zdGFudHM6IHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHNpemU6IHRoaXMuc2l6ZXNbbGF5ZXIgKyAxXSxcbiAgICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICAgICAgaW1tdXRhYmxlOiB0cnVlLFxuICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfVxuICAgIGJ1aWxkR2V0Q2hhbmdlcygpIHtcbiAgICAgICAgZm9yIChsZXQgbGF5ZXIgPSAxOyBsYXllciA8PSB0aGlzLm91dHB1dExheWVyOyBsYXllcisrKSB7XG4gICAgICAgICAgICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgQHR5cGVzY3JpcHQtZXNsaW50L2Jhbi10cy1jb21tZW50XG4gICAgICAgICAgICAvLyBAdHMtZXhwZWN0LWVycm9yXG4gICAgICAgICAgICB0aGlzLmNoYW5nZXNQcm9wYWdhdGVbbGF5ZXJdID0gdGhpcy5ncHUuY3JlYXRlS2VybmVsTWFwKHtcbiAgICAgICAgICAgICAgICB3ZWlnaHRzOiBhZGRXZWlnaHRzLFxuICAgICAgICAgICAgICAgIGNoYW5nZXM6IGNhbGNDaGFuZ2VzLFxuICAgICAgICAgICAgfSwgZnVuY3Rpb24gKHByZXZpb3VzT3V0cHV0cywgZGVsdGFzLCB3ZWlnaHRzLCBwcmV2aW91c0NoYW5nZXMpIHtcbiAgICAgICAgICAgICAgICBjb25zdCBjaGFuZ2UgPSBjYWxjQ2hhbmdlcyh0aGlzLmNvbnN0YW50cy5sZWFybmluZ1JhdGUsIHRoaXMuY29uc3RhbnRzLm1vbWVudHVtLCBwcmV2aW91c0NoYW5nZXNbdGhpcy50aHJlYWQueV1bdGhpcy50aHJlYWQueF0sIGRlbHRhc1t0aGlzLnRocmVhZC55XSwgcHJldmlvdXNPdXRwdXRzW3RoaXMudGhyZWFkLnhdKTtcbiAgICAgICAgICAgICAgICByZXR1cm4gYWRkV2VpZ2h0cyhjaGFuZ2UsIHdlaWdodHNbdGhpcy50aHJlYWQueV1bdGhpcy50aHJlYWQueF0pO1xuICAgICAgICAgICAgfSwge1xuICAgICAgICAgICAgICAgIG91dHB1dDogW3RoaXMuc2l6ZXNbbGF5ZXIgLSAxXSwgdGhpcy5zaXplc1tsYXllcl1dLFxuICAgICAgICAgICAgICAgIHBpcGVsaW5lOiB0cnVlLFxuICAgICAgICAgICAgICAgIGNvbnN0YW50czoge1xuICAgICAgICAgICAgICAgICAgICBzaXplOiB0aGlzLnNpemVzW2xheWVyIC0gMV0sXG4gICAgICAgICAgICAgICAgICAgIGxlYXJuaW5nUmF0ZTogdGhpcy50cmFpbk9wdHMubGVhcm5pbmdSYXRlLFxuICAgICAgICAgICAgICAgICAgICBtb21lbnR1bTogdGhpcy50cmFpbk9wdHMubW9tZW50dW0sXG4gICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICBpbW11dGFibGU6IHRydWUsXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgfVxuICAgIH1cbiAgICBnZXRDaGFuZ2VzKCkge1xuICAgICAgICBmb3IgKGxldCBsYXllciA9IDE7IGxheWVyIDw9IHRoaXMub3V0cHV0TGF5ZXI7IGxheWVyKyspIHtcbiAgICAgICAgICAgIGNvbnN0IHdlaWdodHMgPSB0aGlzLndlaWdodHNbbGF5ZXJdO1xuICAgICAgICAgICAgY29uc3QgY2hhbmdlcyA9IHRoaXMuY2hhbmdlc1tsYXllcl07XG4gICAgICAgICAgICBjb25zdCBvdXRwdXQgPSB0aGlzLmNoYW5nZXNQcm9wYWdhdGVbbGF5ZXJdKHRoaXMub3V0cHV0c1tsYXllciAtIDFdLCB0aGlzLmRlbHRhc1tsYXllcl0sIHdlaWdodHMsIGNoYW5nZXMpO1xuICAgICAgICAgICAgcmVsZWFzZSh3ZWlnaHRzKTtcbiAgICAgICAgICAgIHJlbGVhc2UoY2hhbmdlcyk7XG4gICAgICAgICAgICB0aGlzLndlaWdodHNbbGF5ZXJdID0gb3V0cHV0LndlaWdodHM7XG4gICAgICAgICAgICB0aGlzLmNoYW5nZXNbbGF5ZXJdID0gb3V0cHV0LmNoYW5nZXM7XG4gICAgICAgICAgICByZWxlYXNlKG91dHB1dC5yZXN1bHQpO1xuICAgICAgICB9XG4gICAgfVxuICAgIGJ1aWxkQ2hhbmdlQmlhc2VzKCkge1xuICAgICAgICBmb3IgKGxldCBsYXllciA9IDE7IGxheWVyIDw9IHRoaXMub3V0cHV0TGF5ZXI7IGxheWVyKyspIHtcbiAgICAgICAgICAgIHRoaXMuYmlhc2VzUHJvcGFnYXRlW2xheWVyXSA9IHRoaXMuZ3B1LmNyZWF0ZUtlcm5lbChhZGRCaWFzZXMsIHtcbiAgICAgICAgICAgICAgICBvdXRwdXQ6IFt0aGlzLnNpemVzW2xheWVyXV0sXG4gICAgICAgICAgICAgICAgcGlwZWxpbmU6IHRydWUsXG4gICAgICAgICAgICAgICAgY29uc3RhbnRzOiB7XG4gICAgICAgICAgICAgICAgICAgIGxlYXJuaW5nUmF0ZTogdGhpcy50cmFpbk9wdHMubGVhcm5pbmdSYXRlLFxuICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgaW1tdXRhYmxlOiB0cnVlLFxuICAgICAgICAgICAgfSk7XG4gICAgICAgIH1cbiAgICB9XG4gICAgY2hhbmdlQmlhc2VzKCkge1xuICAgICAgICBmb3IgKGxldCBsYXllciA9IDE7IGxheWVyIDw9IHRoaXMub3V0cHV0TGF5ZXI7IGxheWVyKyspIHtcbiAgICAgICAgICAgIGNvbnN0IGJpYXNlcyA9IHRoaXMuYmlhc2VzW2xheWVyXTtcbiAgICAgICAgICAgIHRoaXMuYmlhc2VzW2xheWVyXSA9IHRoaXMuYmlhc2VzUHJvcGFnYXRlW2xheWVyXShiaWFzZXMsIHRoaXMuZGVsdGFzW2xheWVyXSk7XG4gICAgICAgICAgICByZWxlYXNlKGJpYXNlcyk7XG4gICAgICAgIH1cbiAgICB9XG4gICAgYnVpbGRHZXRNU0UoKSB7XG4gICAgICAgIHRoaXMuZ2V0TVNFID0gdGhpcy5ncHUuY3JlYXRlS2VybmVsKG1zZSwge1xuICAgICAgICAgICAgb3V0cHV0OiBbMV0sXG4gICAgICAgICAgICBjb25zdGFudHM6IHtcbiAgICAgICAgICAgICAgICBzaXplOiB0aGlzLnNpemVzW3RoaXMub3V0cHV0TGF5ZXJdLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIHBpcGVsaW5lOiB0cnVlLFxuICAgICAgICAgICAgaW1tdXRhYmxlOiB0cnVlLFxuICAgICAgICB9KTtcbiAgICAgICAgdGhpcy5fYWRkTVNFID0gdGhpcy5ncHUuY3JlYXRlS2VybmVsKGZ1bmN0aW9uICh2YWx1ZTEsIHZhbHVlMikge1xuICAgICAgICAgICAgcmV0dXJuIHZhbHVlMVswXSArIHZhbHVlMlswXTtcbiAgICAgICAgfSwge1xuICAgICAgICAgICAgb3V0cHV0OiBbMV0sXG4gICAgICAgICAgICBwaXBlbGluZTogdHJ1ZSxcbiAgICAgICAgICAgIGltbXV0YWJsZTogdHJ1ZSxcbiAgICAgICAgfSk7XG4gICAgICAgIHRoaXMuX2RpdmlkZU1TRVN1bSA9IHRoaXMuZ3B1LmNyZWF0ZUtlcm5lbChmdW5jdGlvbiAobGVuZ3RoLCBtc2VTdW0pIHtcbiAgICAgICAgICAgIGNvbnN0IHZhbHVlID0gbXNlU3VtWzBdO1xuICAgICAgICAgICAgaWYgKHZhbHVlID4gMCkge1xuICAgICAgICAgICAgICAgIHJldHVybiB2YWx1ZSAvIGxlbmd0aDtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHJldHVybiAwO1xuICAgICAgICB9LCB7XG4gICAgICAgICAgICBvdXRwdXQ6IFsxXSxcbiAgICAgICAgfSk7XG4gICAgfVxuICAgIHJ1bihpbnB1dCkge1xuICAgICAgICBpZiAoIXRoaXMuaXNSdW5uYWJsZSkge1xuICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKCduZXR3b3JrIG5vdCBydW5uYWJsZScpO1xuICAgICAgICB9XG4gICAgICAgIGxldCBmb3JtYXR0ZWRJbnB1dDtcbiAgICAgICAgaWYgKHRoaXMuaW5wdXRMb29rdXApIHtcbiAgICAgICAgICAgIGZvcm1hdHRlZElucHV0ID0gbG9va3VwLnRvQXJyYXkodGhpcy5pbnB1dExvb2t1cCwgaW5wdXQsIHRoaXMuaW5wdXRMb29rdXBMZW5ndGgpO1xuICAgICAgICB9XG4gICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgZm9ybWF0dGVkSW5wdXQgPSBpbnB1dDtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCBvdXRwdXRUZXh0dXJlcyA9IHRoaXMucnVuSW5wdXQoZm9ybWF0dGVkSW5wdXQpO1xuICAgICAgICBjb25zdCBvdXRwdXQgPSBvdXRwdXRUZXh0dXJlcyBpbnN0YW5jZW9mIGdwdV9qcy5UZXh0dXJlXG4gICAgICAgICAgICA/IG91dHB1dFRleHR1cmVzLnRvQXJyYXkoKVxuICAgICAgICAgICAgOiBvdXRwdXRUZXh0dXJlcztcbiAgICAgICAgaWYgKHRoaXMub3V0cHV0TG9va3VwKSB7XG4gICAgICAgICAgICByZXR1cm4gbG9va3VwLnRvT2JqZWN0KHRoaXMub3V0cHV0TG9va3VwLCBvdXRwdXQpO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBvdXRwdXQ7XG4gICAgfVxuICAgIC8vIEB0cy1leHBlY3QtZXJyb3IgdGhlIHVuZGVybHlpbmcgbmV0d29yayB3b3JrcyBhcyBub3JtYWwsIGJ1dCB3ZSBhcmUgd29ya2luZyBvbiB0aGUgR1BVXG4gICAgcHJlcFRyYWluaW5nKGRhdGEsIG9wdGlvbnMgPSB7fSkge1xuICAgICAgICB0aGlzLnVwZGF0ZVRyYWluaW5nT3B0aW9ucyhvcHRpb25zKTtcbiAgICAgICAgY29uc3QgcHJlcGFyZWREYXRhID0gdGhpcy5mb3JtYXREYXRhKGRhdGEpO1xuICAgICAgICBjb25zdCBlbmRUaW1lID0gRGF0ZS5ub3coKSArIHRoaXMudHJhaW5PcHRzLnRpbWVvdXQ7XG4gICAgICAgIGNvbnN0IHN0YXR1cyA9IHtcbiAgICAgICAgICAgIGVycm9yOiAxLFxuICAgICAgICAgICAgaXRlcmF0aW9uczogMCxcbiAgICAgICAgfTtcbiAgICAgICAgdGhpcy52ZXJpZnlJc0luaXRpYWxpemVkKHByZXBhcmVkRGF0YSk7XG4gICAgICAgIGNvbnN0IHRleHR1cml6ZU91dHB1dERhdGEgPSB0aGlzLmdwdS5jcmVhdGVLZXJuZWwoZnVuY3Rpb24gKHZhbHVlKSB7XG4gICAgICAgICAgICByZXR1cm4gdmFsdWVbdGhpcy50aHJlYWQueF07XG4gICAgICAgIH0sIHtcbiAgICAgICAgICAgIG91dHB1dDogW3ByZXBhcmVkRGF0YVswXS5vdXRwdXQubGVuZ3RoXSxcbiAgICAgICAgICAgIHBpcGVsaW5lOiB0cnVlLFxuICAgICAgICAgICAgaW1tdXRhYmxlOiB0cnVlLFxuICAgICAgICB9KTtcbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgIHByZXBhcmVkRGF0YTogcHJlcGFyZWREYXRhLm1hcCgoc2V0KSA9PiAoe1xuICAgICAgICAgICAgICAgIGlucHV0OiB0aGlzLnRleHR1cml6ZUlucHV0RGF0YShzZXQuaW5wdXQpLFxuICAgICAgICAgICAgICAgIG91dHB1dDogdGV4dHVyaXplT3V0cHV0RGF0YShzZXQub3V0cHV0KSxcbiAgICAgICAgICAgIH0pKSxcbiAgICAgICAgICAgIHN0YXR1cyxcbiAgICAgICAgICAgIGVuZFRpbWUsXG4gICAgICAgIH07XG4gICAgfVxuICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBAdHlwZXNjcmlwdC1lc2xpbnQvYmFuLXRzLWNvbW1lbnRcbiAgICAvLyBAdHMtZXhwZWN0LWVycm9yXG4gICAgdG9GdW5jdGlvbigpIHtcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKGAke3RoaXMuY29uc3RydWN0b3IubmFtZX0tdG9GdW5jdGlvbiBpcyBub3QgeWV0IGltcGxlbWVudGVkYCk7XG4gICAgfVxuICAgIHRvSlNPTigpIHtcbiAgICAgICAgdmFyIF9hLCBfYjtcbiAgICAgICAgaWYgKHRoaXMuc2l6ZXMgPT09IG51bGwpIHtcbiAgICAgICAgICAgIHRoaXMuaW5pdGlhbGl6ZSgpO1xuICAgICAgICB9XG4gICAgICAgIC8vIHVzZSBBcnJheS5mcm9tLCBrZWVwaW5nIGpzb24gc21hbGxcbiAgICAgICAgY29uc3QganNvbkxheWVyV2VpZ2h0cyA9IHRoaXMud2VpZ2h0cy5tYXAoKGxheWVyV2VpZ2h0cykgPT4ge1xuICAgICAgICAgICAgcmV0dXJuIChsYXllcldlaWdodHMgaW5zdGFuY2VvZiBncHVfanMuVGV4dHVyZVxuICAgICAgICAgICAgICAgID8gbGF5ZXJXZWlnaHRzLnRvQXJyYXkoKVxuICAgICAgICAgICAgICAgIDogbGF5ZXJXZWlnaHRzKS5tYXAoKGxheWVyV2VpZ2h0cykgPT4gQXJyYXkuZnJvbShsYXllcldlaWdodHMpKTtcbiAgICAgICAgfSk7XG4gICAgICAgIGNvbnN0IGpzb25MYXllckJpYXNlcyA9IHRoaXMuYmlhc2VzLm1hcCgobGF5ZXJCaWFzZXMpID0+IEFycmF5LmZyb20obGF5ZXJCaWFzZXMgaW5zdGFuY2VvZiBncHVfanMuVGV4dHVyZVxuICAgICAgICAgICAgPyBsYXllckJpYXNlcy50b0FycmF5KClcbiAgICAgICAgICAgIDogbGF5ZXJCaWFzZXMpKTtcbiAgICAgICAgY29uc3QganNvbkxheWVycyA9IFtdO1xuICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8PSB0aGlzLm91dHB1dExheWVyOyBpKyspIHtcbiAgICAgICAgICAgIGpzb25MYXllcnMucHVzaCh7XG4gICAgICAgICAgICAgICAgd2VpZ2h0czogKF9hID0ganNvbkxheWVyV2VpZ2h0c1tpXSkgIT09IG51bGwgJiYgX2EgIT09IHZvaWQgMCA/IF9hIDogW10sXG4gICAgICAgICAgICAgICAgYmlhc2VzOiAoX2IgPSBqc29uTGF5ZXJCaWFzZXNbaV0pICE9PSBudWxsICYmIF9iICE9PSB2b2lkIDAgPyBfYiA6IFtdLFxuICAgICAgICAgICAgfSk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgIHR5cGU6ICdOZXVyYWxOZXR3b3JrR1BVJyxcbiAgICAgICAgICAgIHNpemVzOiBbLi4udGhpcy5zaXplc10sXG4gICAgICAgICAgICBsYXllcnM6IGpzb25MYXllcnMsXG4gICAgICAgICAgICBpbnB1dExvb2t1cDogdGhpcy5pbnB1dExvb2t1cCA/IHsgLi4udGhpcy5pbnB1dExvb2t1cCB9IDogbnVsbCxcbiAgICAgICAgICAgIGlucHV0TG9va3VwTGVuZ3RoOiB0aGlzLmlucHV0TG9va3VwTGVuZ3RoLFxuICAgICAgICAgICAgb3V0cHV0TG9va3VwOiB0aGlzLm91dHB1dExvb2t1cCA/IHsgLi4udGhpcy5vdXRwdXRMb29rdXAgfSA6IG51bGwsXG4gICAgICAgICAgICBvdXRwdXRMb29rdXBMZW5ndGg6IHRoaXMub3V0cHV0TG9va3VwTGVuZ3RoLFxuICAgICAgICAgICAgb3B0aW9uczogeyAuLi50aGlzLm9wdGlvbnMgfSxcbiAgICAgICAgICAgIHRyYWluT3B0czogdGhpcy5nZXRUcmFpbk9wdHNKU09OKCksXG4gICAgICAgIH07XG4gICAgfVxufVxuXG5jbGFzcyBSZWN1cnJlbnRDb25uZWN0aW9uIGV4dGVuZHMgSW50ZXJuYWwge1xuICAgIGNvbnN0cnVjdG9yKCkge1xuICAgICAgICBzdXBlciguLi5hcmd1bWVudHMpO1xuICAgICAgICB0aGlzLnNldHRpbmdzID0ge307XG4gICAgICAgIHRoaXMubGF5ZXIgPSBudWxsO1xuICAgIH1cbiAgICBzZXRMYXllcihsYXllcikge1xuICAgICAgICB0aGlzLmxheWVyID0gbGF5ZXI7XG4gICAgfVxuICAgIGdldCB3aWR0aCgpIHtcbiAgICAgICAgaWYgKCF0aGlzLmxheWVyKVxuICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdsYXllciBub3Qgc2V0Jyk7XG4gICAgICAgIHJldHVybiB0aGlzLmxheWVyLndpZHRoO1xuICAgIH1cbiAgICBzZXQgd2lkdGgodmFsdWUpIHtcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKGAke3RoaXMuY29uc3RydWN0b3IubmFtZX0td2lkdGggaXMgbm90IHlldCBpbXBsZW1lbnRlZGApO1xuICAgIH1cbiAgICBnZXQgaGVpZ2h0KCkge1xuICAgICAgICBpZiAoIXRoaXMubGF5ZXIpXG4gICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ2xheWVyIG5vdCBzZXQnKTtcbiAgICAgICAgcmV0dXJuIHRoaXMubGF5ZXIuaGVpZ2h0O1xuICAgIH1cbiAgICBzZXQgaGVpZ2h0KHZhbHVlKSB7XG4gICAgICAgIHRocm93IG5ldyBFcnJvcihgJHt0aGlzLmNvbnN0cnVjdG9yLm5hbWV9LWhlaWdodCBpcyBub3QgeWV0IGltcGxlbWVudGVkYCk7XG4gICAgfVxuICAgIGdldCBkZWx0YXMoKSB7XG4gICAgICAgIGlmICghdGhpcy5sYXllcilcbiAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcignbGF5ZXIgbm90IHNldCcpO1xuICAgICAgICByZXR1cm4gdGhpcy5sYXllci5kZWx0YXM7XG4gICAgfVxuICAgIHNldCBkZWx0YXMoZGVsdGFzKSB7XG4gICAgICAgIGlmICghdGhpcy5sYXllcilcbiAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcignbGF5ZXIgbm90IHNldCcpO1xuICAgICAgICByZWxlYXNlKHRoaXMubGF5ZXIuZGVsdGFzKTtcbiAgICAgICAgdGhpcy5sYXllci5kZWx0YXMgPSBkZWx0YXM7XG4gICAgfVxuICAgIGdldCB3ZWlnaHRzKCkge1xuICAgICAgICBpZiAoIXRoaXMubGF5ZXIpXG4gICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ2xheWVyIG5vdCBzZXQnKTtcbiAgICAgICAgcmV0dXJuIHRoaXMubGF5ZXIud2VpZ2h0cztcbiAgICB9XG4gICAgc2V0IHdlaWdodHMod2VpZ2h0cykge1xuICAgICAgICBpZiAoIXRoaXMubGF5ZXIpXG4gICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ2xheWVyIG5vdCBzZXQnKTtcbiAgICAgICAgcmVsZWFzZSh0aGlzLmxheWVyLndlaWdodHMpO1xuICAgICAgICB0aGlzLmxheWVyLndlaWdodHMgPSB3ZWlnaHRzO1xuICAgIH1cbiAgICBwcmVkaWN0KCkge1xuICAgICAgICAvLyB0aHJvdyBuZXcgRXJyb3IoYCR7dGhpcy5jb25zdHJ1Y3Rvci5uYW1lfS1wcmVkaWN0IGlzIG5vdCB5ZXQgaW1wbGVtZW50ZWRgKVxuICAgIH1cbiAgICBjb21wYXJlKCkge1xuICAgICAgICAvLyB0aHJvdyBuZXcgRXJyb3IoYCR7dGhpcy5jb25zdHJ1Y3Rvci5uYW1lfS1jb21wYXJlIGlzIG5vdCB5ZXQgaW1wbGVtZW50ZWRgKVxuICAgIH1cbiAgICBsZWFybigpIHtcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdubyBsb25nZXIgdXNpbmcnKTtcbiAgICB9XG4gICAgc2V0dXBLZXJuZWxzKCkge1xuICAgICAgICAvLyB0aHJvdyBuZXcgRXJyb3IoXG4gICAgICAgIC8vICAgYCR7dGhpcy5jb25zdHJ1Y3Rvci5uYW1lfS1zZXR1cEtlcm5lbHMgaXMgbm90IHlldCBpbXBsZW1lbnRlZGBcbiAgICAgICAgLy8gKVxuICAgIH1cbiAgICByZXVzZUtlcm5lbHMoKSB7XG4gICAgICAgIC8vIHRocm93IG5ldyBFcnJvcihcbiAgICAgICAgLy8gICBgJHt0aGlzLmNvbnN0cnVjdG9yLm5hbWV9LXJldXNlS2VybmVscyBpcyBub3QgeWV0IGltcGxlbWVudGVkYFxuICAgICAgICAvLyApXG4gICAgfVxufVxuXG5jbGFzcyBSZWN1cnJlbnQgZXh0ZW5kcyBGZWVkRm9yd2FyZCB7XG4gICAgLy8gVE9ETzogdXNlIGdlbmVyaWNzIGluIGV4dGVuZFxuICAgIGNvbnN0cnVjdG9yKG9wdGlvbnMgPSB7fSkge1xuICAgICAgICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgQHR5cGVzY3JpcHQtZXNsaW50L2Jhbi10cy1jb21tZW50XG4gICAgICAgIC8vIEB0cy1leHBlY3QtZXJyb3JcbiAgICAgICAgc3VwZXIob3B0aW9ucyk7XG4gICAgICAgIHRoaXMudHJhaW5PcHRzID0ge307XG4gICAgICAgIHRoaXMuX291dHB1dENvbm5lY3Rpb24gPSBudWxsO1xuICAgICAgICB0aGlzLl9sYXllclNldHMgPSBbXTtcbiAgICAgICAgdGhpcy5faGlkZGVuTGF5ZXJPdXRwdXRJbmRpY2VzID0gW107XG4gICAgICAgIHRoaXMuX21vZGVsID0gbnVsbDtcbiAgICB9XG4gICAgX2Nvbm5lY3RMYXllcnMoKSB7XG4gICAgICAgIGlmICghdGhpcy5vcHRpb25zLmlucHV0TGF5ZXIpIHtcbiAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcignaW5wdXRMYXllciBub3QgZm91bmQnKTtcbiAgICAgICAgfVxuICAgICAgICBpZiAoIXRoaXMub3B0aW9ucy5vdXRwdXRMYXllcikge1xuICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdvdXRwdXRMYXllciBub3QgZm91bmQnKTtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCBpbnB1dExheWVyID0gdGhpcy5vcHRpb25zLmlucHV0TGF5ZXIoKTtcbiAgICAgICAgY29uc3QgaGlkZGVuTGF5ZXJzID0gdGhpcy5fY29ubmVjdEhpZGRlbkxheWVycyhpbnB1dExheWVyKTtcbiAgICAgICAgY29uc3Qgb3V0cHV0TGF5ZXIgPSB0aGlzLm9wdGlvbnMub3V0cHV0TGF5ZXIoaGlkZGVuTGF5ZXJzW2hpZGRlbkxheWVycy5sZW5ndGggLSAxXSwgLTEpO1xuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgaW5wdXRMYXllcixcbiAgICAgICAgICAgIGhpZGRlbkxheWVycyxcbiAgICAgICAgICAgIG91dHB1dExheWVyLFxuICAgICAgICB9O1xuICAgIH1cbiAgICBfY29ubmVjdExheWVyc0RlZXAoKSB7XG4gICAgICAgIGNvbnN0IGxheWVycyA9IFtdO1xuICAgICAgICBjb25zdCBwcmV2aW91c0xheWVycyA9IHRoaXMuX2xheWVyU2V0c1t0aGlzLl9sYXllclNldHMubGVuZ3RoIC0gMV07XG4gICAgICAgIGxldCB1c2VkSGlkZGVuTGF5ZXJPdXRwdXRJbmRleCA9IDA7XG4gICAgICAgIGZ1bmN0aW9uIGZpbmRJbnB1dExheWVyKGlucHV0TGF5ZXIpIHtcbiAgICAgICAgICAgIGNvbnN0IGluZGV4ID0gcHJldmlvdXNMYXllcnMuaW5kZXhPZihpbnB1dExheWVyKTtcbiAgICAgICAgICAgIGlmIChpbmRleCA8IDApXG4gICAgICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKCd1bmFibGUgdG8gZmluZCBsYXllcicpO1xuICAgICAgICAgICAgcmV0dXJuIGxheWVyc1tpbmRleF07XG4gICAgICAgIH1cbiAgICAgICAgZnVuY3Rpb24gbGF5ZXJTZXR0aW5ncyhsYXllcikge1xuICAgICAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgICAgICAuLi5sYXllci5zZXR0aW5ncyxcbiAgICAgICAgICAgICAgICB3ZWlnaHRzOiBudWxsLFxuICAgICAgICAgICAgICAgIGRlbHRhczogbnVsbCxcbiAgICAgICAgICAgICAgICBwcmF4aXM6IG51bGwsXG4gICAgICAgICAgICB9O1xuICAgICAgICB9XG4gICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgcHJldmlvdXNMYXllcnMubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgICAgIGNvbnN0IHByZXZpb3VzTGF5ZXIgPSBwcmV2aW91c0xheWVyc1tpXTtcbiAgICAgICAgICAgIGxldCBsYXllcjtcbiAgICAgICAgICAgIGlmIChwcmV2aW91c0xheWVyIGluc3RhbmNlb2YgQWN0aXZhdGlvbikge1xuICAgICAgICAgICAgICAgIGxheWVyID0gbmV3IHByZXZpb3VzTGF5ZXIuY29uc3RydWN0b3IoZmluZElucHV0TGF5ZXIocHJldmlvdXNMYXllci5pbnB1dExheWVyKSwgbGF5ZXJTZXR0aW5ncyhwcmV2aW91c0xheWVyKSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBlbHNlIGlmIChwcmV2aW91c0xheWVyIGluc3RhbmNlb2YgRW50cnlQb2ludCkge1xuICAgICAgICAgICAgICAgIGxheWVyID0gbmV3IHByZXZpb3VzTGF5ZXIuY29uc3RydWN0b3IobGF5ZXJTZXR0aW5ncyhwcmV2aW91c0xheWVyKSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBlbHNlIGlmIChwcmV2aW91c0xheWVyIGluc3RhbmNlb2YgRmlsdGVyKSB7XG4gICAgICAgICAgICAgICAgbGF5ZXIgPSBuZXcgcHJldmlvdXNMYXllci5jb25zdHJ1Y3RvcihsYXllclNldHRpbmdzKHByZXZpb3VzTGF5ZXIuaW5wdXRMYXllciksIGZpbmRJbnB1dExheWVyKHByZXZpb3VzTGF5ZXIuaW5wdXRMYXllcikpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZWxzZSBpZiAocHJldmlvdXNMYXllciBpbnN0YW5jZW9mIEludGVybmFsKSB7XG4gICAgICAgICAgICAgICAgY29uc3QgcHJldmlvdXNIaWRkZW5MYXllck91dHB1dCA9IHByZXZpb3VzTGF5ZXJzW3RoaXMuX2hpZGRlbkxheWVyT3V0cHV0SW5kaWNlc1t1c2VkSGlkZGVuTGF5ZXJPdXRwdXRJbmRleCsrXV07XG4gICAgICAgICAgICAgICAgaWYgKHByZXZpb3VzTGF5ZXIgaW5zdGFuY2VvZiBSZWN1cnJlbnRDb25uZWN0aW9uKSB7XG4gICAgICAgICAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcigndW5maW5pc2hlZCcpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBlbHNlIGlmIChwcmV2aW91c0xheWVyIGluc3RhbmNlb2YgUmVjdXJyZW50SW5wdXQpIHtcbiAgICAgICAgICAgICAgICAgICAgbGF5ZXIgPSBuZXcgUmVjdXJyZW50SW5wdXQocHJldmlvdXNIaWRkZW5MYXllck91dHB1dCk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGVsc2UgaWYgKHByZXZpb3VzTGF5ZXIgaW5zdGFuY2VvZiBSZWN1cnJlbnRaZXJvcykge1xuICAgICAgICAgICAgICAgICAgICBsYXllciA9IG5ldyBSZWN1cnJlbnRJbnB1dChwcmV2aW91c0hpZGRlbkxheWVyT3V0cHV0KTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcihgaGlkZGVuIGxheWVyICR7cHJldmlvdXNMYXllci5jb25zdHJ1Y3Rvci5uYW1lfSBleHRlbmRzIHVua25vd24gaGlkZGVuIGxheWVyYCk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZWxzZSBpZiAocHJldmlvdXNMYXllciBpbnN0YW5jZW9mIEludGVybmFsTW9kZWwgfHxcbiAgICAgICAgICAgICAgICBwcmV2aW91c0xheWVyIGluc3RhbmNlb2YgTW9kZWwpIHtcbiAgICAgICAgICAgICAgICBsYXllciA9IHByZXZpb3VzTGF5ZXI7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBlbHNlIGlmIChwcmV2aW91c0xheWVyIGluc3RhbmNlb2YgTW9kaWZpZXIpIHtcbiAgICAgICAgICAgICAgICBsYXllciA9IG5ldyBwcmV2aW91c0xheWVyLmNvbnN0cnVjdG9yKGZpbmRJbnB1dExheWVyKHByZXZpb3VzTGF5ZXIuaW5wdXRMYXllciksIGxheWVyU2V0dGluZ3MocHJldmlvdXNMYXllci5pbnB1dExheWVyKSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBlbHNlIGlmIChwcmV2aW91c0xheWVyIGluc3RhbmNlb2YgT3BlcmF0b3IpIHtcbiAgICAgICAgICAgICAgICBsYXllciA9IG5ldyBwcmV2aW91c0xheWVyLmNvbnN0cnVjdG9yKGZpbmRJbnB1dExheWVyKHByZXZpb3VzTGF5ZXIuaW5wdXRMYXllcjEpLCBmaW5kSW5wdXRMYXllcihwcmV2aW91c0xheWVyLmlucHV0TGF5ZXIyKSwgbGF5ZXJTZXR0aW5ncyhwcmV2aW91c0xheWVyKSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBlbHNlIGlmIChwcmV2aW91c0xheWVyIGluc3RhbmNlb2YgVGFyZ2V0KSB7XG4gICAgICAgICAgICAgICAgbGF5ZXIgPSBuZXcgcHJldmlvdXNMYXllci5jb25zdHJ1Y3RvcihsYXllclNldHRpbmdzKHByZXZpb3VzTGF5ZXIpLCBmaW5kSW5wdXRMYXllcihwcmV2aW91c0xheWVyLmlucHV0TGF5ZXIpKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcihgaGlkZGVuIGxheWVyICR7cHJldmlvdXNMYXllci5jb25zdHJ1Y3Rvci5uYW1lfSBleHRlbmRzIHVua25vd24gaGlkZGVuIGxheWVyYCk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBsYXllcnMucHVzaChsYXllcik7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIGxheWVycztcbiAgICB9XG4gICAgX2Nvbm5lY3RIaWRkZW5MYXllcnMocHJldmlvdXNMYXllcikge1xuICAgICAgICBjb25zdCBoaWRkZW5MYXllcnMgPSBbXTtcbiAgICAgICAgaWYgKCF0aGlzLm9wdGlvbnMuaGlkZGVuTGF5ZXJzKVxuICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdoaWRkZW5MYXllcnMgbm90IGRlZmluZWQnKTtcbiAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCB0aGlzLm9wdGlvbnMuaGlkZGVuTGF5ZXJzLmxlbmd0aDsgaSsrKSB7XG4gICAgICAgICAgICBjb25zdCByZWN1cnJlbnRJbnB1dCA9IG5ldyBSZWN1cnJlbnRaZXJvcygpO1xuICAgICAgICAgICAgY29uc3QgaGlkZGVuTGF5ZXIgPSB0aGlzLm9wdGlvbnMuaGlkZGVuTGF5ZXJzW2ldKHByZXZpb3VzTGF5ZXIsIHJlY3VycmVudElucHV0LCBpKTtcbiAgICAgICAgICAgIHByZXZpb3VzTGF5ZXIgPSBoaWRkZW5MYXllcjtcbiAgICAgICAgICAgIGhpZGRlbkxheWVycy5wdXNoKGhpZGRlbkxheWVyKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gaGlkZGVuTGF5ZXJzO1xuICAgIH1cbiAgICBpbml0aWFsaXplKCkge1xuICAgICAgICB0aGlzLl9vdXRwdXRDb25uZWN0aW9uID0gbmV3IFJlY3VycmVudENvbm5lY3Rpb24oKTtcbiAgICAgICAgbGV0IGxheWVyU2V0O1xuICAgICAgICBpZiAodGhpcy5vcHRpb25zLmxheWVycykge1xuICAgICAgICAgICAgbGF5ZXJTZXQgPSB0aGlzLl9jb25uZWN0T3B0aW9uc0xheWVycygpO1xuICAgICAgICB9XG4gICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgY29uc3QgeyBpbnB1dExheWVyLCBoaWRkZW5MYXllcnMsIG91dHB1dExheWVyIH0gPSB0aGlzLl9jb25uZWN0TGF5ZXJzKCk7XG4gICAgICAgICAgICBsYXllclNldCA9IGZsYXR0ZW5MYXllcnMoW2lucHV0TGF5ZXIsIC4uLmhpZGRlbkxheWVycywgb3V0cHV0TGF5ZXJdKTtcbiAgICAgICAgICAgIHRoaXMuX2hpZGRlbkxheWVyT3V0cHV0SW5kaWNlcyA9IGhpZGRlbkxheWVycy5tYXAoKGwpID0+IGxheWVyU2V0LmluZGV4T2YobCkpO1xuICAgICAgICAgICAgdGhpcy5faW5wdXRMYXllciA9IGlucHV0TGF5ZXI7XG4gICAgICAgICAgICB0aGlzLl9oaWRkZW5MYXllcnMgPSBoaWRkZW5MYXllcnM7XG4gICAgICAgICAgICB0aGlzLl9vdXRwdXRMYXllciA9IG91dHB1dExheWVyO1xuICAgICAgICB9XG4gICAgICAgIHRoaXMubGF5ZXJzID0gbGF5ZXJTZXQ7XG4gICAgICAgIHRoaXMuX2xheWVyU2V0cyA9IFtsYXllclNldF07XG4gICAgICAgIHRoaXMuX21vZGVsID0gbGF5ZXJTZXQuZmlsdGVyKChsKSA9PiBsIGluc3RhbmNlb2YgTW9kZWwgfHwgbCBpbnN0YW5jZW9mIEludGVybmFsTW9kZWwpO1xuICAgICAgICB0aGlzLmluaXRpYWxpemVMYXllcnMobGF5ZXJTZXQpO1xuICAgIH1cbiAgICBpbml0aWFsaXplRGVlcCgpIHtcbiAgICAgICAgY29uc3QgbGF5ZXJzID0gdGhpcy5fY29ubmVjdExheWVyc0RlZXAoKTtcbiAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBsYXllcnMubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgICAgIGNvbnN0IGxheWVyID0gbGF5ZXJzW2ldO1xuICAgICAgICAgICAgbGF5ZXIuc2V0dXBLZXJuZWxzKHRydWUpO1xuICAgICAgICAgICAgLy8gVE9ETzogZW5hYmxlIHRoaXM/XG4gICAgICAgICAgICAvLyBsYXllci5yZXVzZUtlcm5lbHModGhpcy5fbGF5ZXJTZXRzWzBdW2ldKTtcbiAgICAgICAgfVxuICAgICAgICB0aGlzLl9sYXllclNldHMucHVzaChsYXllcnMpO1xuICAgIH1cbiAgICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgQHR5cGVzY3JpcHQtZXNsaW50L2Jhbi10cy1jb21tZW50XG4gICAgLy8gQHRzLWV4cGVjdC1lcnJvclxuICAgIHJ1bihpbnB1dHMpIHtcbiAgICAgICAgd2hpbGUgKHRoaXMuX2xheWVyU2V0cy5sZW5ndGggPD0gaW5wdXRzLmxlbmd0aCkge1xuICAgICAgICAgICAgdGhpcy5pbml0aWFsaXplRGVlcCgpO1xuICAgICAgICB9XG4gICAgICAgIGNvbnN0IHJlc3VsdCA9IHRoaXMucnVuSW5wdXRzKGlucHV0cyk7XG4gICAgICAgIGlmIChyZXN1bHQgaW5zdGFuY2VvZiBncHVfanMuVGV4dHVyZSlcbiAgICAgICAgICAgIHJldHVybiByZXN1bHQudG9BcnJheSgpO1xuICAgICAgICByZXR1cm4gcmVzdWx0O1xuICAgIH1cbiAgICBydW5JbnB1dChpbnB1dCkge1xuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ3VzZSAucnVuSW5wdXRzKCknKTtcbiAgICB9XG4gICAgcnVuSW5wdXRzKGlucHV0cykge1xuICAgICAgICB3aGlsZSAodGhpcy5fbGF5ZXJTZXRzLmxlbmd0aCA8IGlucHV0cy5sZW5ndGgpIHtcbiAgICAgICAgICAgIHRoaXMuaW5pdGlhbGl6ZURlZXAoKTtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCBtYXggPSBpbnB1dHMubGVuZ3RoIC0gMTsgLy8gbGFzdCBvdXRwdXQgd2lsbCBiZSBjb21wYXJlZCB3aXRoIGxhc3QgaW5kZXhcbiAgICAgICAgZm9yIChsZXQgeCA9IDA7IHggPD0gbWF4OyB4KyspIHtcbiAgICAgICAgICAgIGNvbnN0IGxheWVyU2V0ID0gdGhpcy5fbGF5ZXJTZXRzW3hdO1xuICAgICAgICAgICAgbGF5ZXJTZXRbMF0ucHJlZGljdChpbnB1dHNbeF0pO1xuICAgICAgICAgICAgZm9yIChsZXQgaSA9IDE7IGkgPCBsYXllclNldC5sZW5ndGg7IGkrKykge1xuICAgICAgICAgICAgICAgIGxheWVyU2V0W2ldLnByZWRpY3QoKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBjb25zdCBsYXN0TGF5ZXJVc2VkID0gdGhpcy5fbGF5ZXJTZXRzW21heF07XG4gICAgICAgIGNvbnN0IHJlc3VsdCA9IGxhc3RMYXllclVzZWRbbGFzdExheWVyVXNlZC5sZW5ndGggLSAxXS53ZWlnaHRzO1xuICAgICAgICB0aGlzLmVuZCgpO1xuICAgICAgICByZXR1cm4gcmVzdWx0O1xuICAgIH1cbiAgICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgQHR5cGVzY3JpcHQtZXNsaW50L2Jhbi10cy1jb21tZW50XG4gICAgLy8gQHRzLWV4cGVjdC1lcnJvclxuICAgIHRyYWluKGRhdGEsIG9wdGlvbnMgPSB7fSkge1xuICAgICAgICBjb25zdCB7IHByZXBhcmVkRGF0YSwgc3RhdHVzLCBlbmRUaW1lIH0gPSB0aGlzLl9wcmVwVHJhaW5pbmcoZGF0YSwgb3B0aW9ucyk7XG4gICAgICAgIGxldCBjb250aW51ZVRpY2tpbmcgPSB0cnVlO1xuICAgICAgICBjb25zdCBjYWxjdWxhdGVFcnJvciA9ICgpID0+IHRoaXMuX2NhbGN1bGF0ZVRyYWluaW5nRXJyb3IocHJlcGFyZWREYXRhKTtcbiAgICAgICAgY29uc3QgdHJhaW5QYXR0ZXJzID0gKCkgPT4gdGhpcy5fdHJhaW5QYXR0ZXJucyhwcmVwYXJlZERhdGEpO1xuICAgICAgICB3aGlsZSAoY29udGludWVUaWNraW5nKSB7XG4gICAgICAgICAgICBjb250aW51ZVRpY2tpbmcgPSB0aGlzLl90cmFpbmluZ1RpY2soc3RhdHVzLCBlbmRUaW1lLCBjYWxjdWxhdGVFcnJvciwgdHJhaW5QYXR0ZXJzKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gc3RhdHVzO1xuICAgIH1cbiAgICBlbmQoKSB7XG4gICAgICAgIGNvbnN0IHggPSB0aGlzLl9sYXllclNldHMubGVuZ3RoIC0gMTtcbiAgICAgICAgY29uc3QgbGFzdExheWVyU2V0ID0gdGhpcy5fbGF5ZXJTZXRzW3hdO1xuICAgICAgICBsYXN0TGF5ZXJTZXRbMF0ucHJlZGljdChbbmV3IEZsb2F0MzJBcnJheShbMF0pXSk7XG4gICAgICAgIGZvciAobGV0IGkgPSAxOyBpIDwgbGFzdExheWVyU2V0Lmxlbmd0aDsgaSsrKSB7XG4gICAgICAgICAgICBsYXN0TGF5ZXJTZXRbaV0ucHJlZGljdCgpO1xuICAgICAgICB9XG4gICAgfVxuICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBAdHlwZXNjcmlwdC1lc2xpbnQvYmFuLXRzLWNvbW1lbnRcbiAgICAvLyBAdHMtZXhwZWN0LWVycm9yXG4gICAgdHJhbnNmZXJEYXRhKGZvcm1hdHRlZERhdGEpIHtcbiAgICAgICAgcmV0dXJuIGZvcm1hdHRlZERhdGE7XG4gICAgfVxuICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBAdHlwZXNjcmlwdC1lc2xpbnQvYmFuLXRzLWNvbW1lbnRcbiAgICAvLyBAdHMtZXhwZWN0LWVycm9yXG4gICAgX3ByZXBUcmFpbmluZyhkYXRhLCBvcHRpb25zKSB7XG4gICAgICAgIHRoaXMuX3VwZGF0ZVRyYWluaW5nT3B0aW9ucyhvcHRpb25zKTtcbiAgICAgICAgY29uc3QgZW5kVGltZSA9IHRoaXMudHJhaW5PcHRzLnRpbWVvdXRcbiAgICAgICAgICAgID8gRGF0ZS5ub3coKSArIHRoaXMudHJhaW5PcHRzLnRpbWVvdXRcbiAgICAgICAgICAgIDogMDtcbiAgICAgICAgY29uc3Qgc3RhdHVzID0ge1xuICAgICAgICAgICAgZXJyb3I6IDEsXG4gICAgICAgICAgICBpdGVyYXRpb25zOiAwLFxuICAgICAgICB9O1xuICAgICAgICB0aGlzLnZlcmlmeUlzSW5pdGlhbGl6ZWQoKTtcbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgIHByZXBhcmVkRGF0YTogdGhpcy50cmFuc2ZlckRhdGEoZGF0YSksXG4gICAgICAgICAgICBzdGF0dXMsXG4gICAgICAgICAgICBlbmRUaW1lLFxuICAgICAgICB9O1xuICAgIH1cbiAgICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgQHR5cGVzY3JpcHQtZXNsaW50L2Jhbi10cy1jb21tZW50XG4gICAgLy8gQHRzLWV4cGVjdC1lcnJvclxuICAgIF9jYWxjdWxhdGVUcmFpbmluZ0Vycm9yKGRhdGEpIHtcbiAgICAgICAgaWYgKCF0aGlzLm1lYW5TcXVhcmVkRXJyb3IpIHtcbiAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcigndGhpcy5tZWFuU3F1YXJlZEVycm9yIG5vdCBzZXR1cCcpO1xuICAgICAgICB9XG4gICAgICAgIGxldCBzdW0gPSBuZXcgRmxvYXQzMkFycmF5KDEpO1xuICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IGRhdGEubGVuZ3RoOyArK2kpIHtcbiAgICAgICAgICAgIGNvbnN0IHByZXZTdW0gPSBzdW07XG4gICAgICAgICAgICBjb25zdCBlcnJvciA9IHRoaXMuX3RyYWluUGF0dGVybihkYXRhW2ldLCB0cnVlKTtcbiAgICAgICAgICAgIHN1bSA9IHRoaXMubWVhblNxdWFyZWRFcnJvci5hZGQoc3VtLCBlcnJvcik7XG4gICAgICAgICAgICByZWxlYXNlKGVycm9yKTtcbiAgICAgICAgICAgIHJlbGVhc2UocHJldlN1bSk7XG4gICAgICAgIH1cbiAgICAgICAgY29uc3QgcmVzdWx0ID0gdGhpcy5tZWFuU3F1YXJlZEVycm9yLmRpdmlkZShkYXRhLmxlbmd0aCwgc3VtKTtcbiAgICAgICAgcmVsZWFzZShzdW0pO1xuICAgICAgICBpZiAocmVzdWx0IGluc3RhbmNlb2YgZ3B1X2pzLlRleHR1cmUpIHtcbiAgICAgICAgICAgIGNvbnN0IHJlc3VsdEFycmF5ID0gcmVzdWx0LnRvQXJyYXkoKTtcbiAgICAgICAgICAgIHJldHVybiByZXN1bHRBcnJheVswXTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gcmVzdWx0WzBdO1xuICAgIH1cbiAgICAvLyBUT0RPOiBtb3JlIHR5cGVzXG4gICAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIEB0eXBlc2NyaXB0LWVzbGludC9iYW4tdHMtY29tbWVudFxuICAgIC8vIEB0cy1leHBlY3QtZXJyb3JcbiAgICBmb3JtYXREYXRhKGRhdGEpIHtcbiAgICAgICAgcmV0dXJuIGRhdGE7XG4gICAgfVxuICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBAdHlwZXNjcmlwdC1lc2xpbnQvYmFuLXRzLWNvbW1lbnRcbiAgICAvLyBAdHMtZXhwZWN0LWVycm9yXG4gICAgX2NhbGN1bGF0ZURlbHRhcyh0YXJnZXQpIHtcbiAgICAgICAgY29uc3QgbGFzdExheWVyU2V0ID0gdGhpcy5fbGF5ZXJTZXRzW3RoaXMuX2xheWVyU2V0cy5sZW5ndGggLSAxXTtcbiAgICAgICAgLy8gSXRlcmF0ZSBmcm9tIHRoZSBzZWNvbmQgdG8gbGFzdCBsYXllciBiYWNrd2FyZHMsIHByb3BhZ2F0aW5nIDAnc1xuICAgICAgICBmb3IgKGxldCBpID0gbGFzdExheWVyU2V0Lmxlbmd0aCAtIDI7IGkgPj0gMDsgaS0tKSB7XG4gICAgICAgICAgICBsYXN0TGF5ZXJTZXRbaV0uY29tcGFyZSgpO1xuICAgICAgICB9XG4gICAgICAgIGZvciAobGV0IHggPSB0YXJnZXQubGVuZ3RoIC0gMjsgeCA+PSAwOyB4LS0pIHtcbiAgICAgICAgICAgIGNvbnN0IGxheWVyU2V0ID0gdGhpcy5fbGF5ZXJTZXRzW3hdO1xuICAgICAgICAgICAgbGF5ZXJTZXRbbGF5ZXJTZXQubGVuZ3RoIC0gMV0uY29tcGFyZSh0YXJnZXRbeCArIDFdKTtcbiAgICAgICAgICAgIGZvciAobGV0IGkgPSBsYXllclNldC5sZW5ndGggLSAyOyBpID49IDA7IGktLSkge1xuICAgICAgICAgICAgICAgIGxheWVyU2V0W2ldLmNvbXBhcmUoKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIH1cbiAgICBhZGp1c3RXZWlnaHRzKCkge1xuICAgICAgICB2YXIgX2E7XG4gICAgICAgIGNvbnN0IF9tb2RlbCA9IHRoaXMuX21vZGVsO1xuICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IF9tb2RlbC5sZW5ndGg7IGkrKykge1xuICAgICAgICAgICAgX21vZGVsW2ldLmxlYXJuKChfYSA9IHRoaXMub3B0aW9ucy5sZWFybmluZ1JhdGUpICE9PSBudWxsICYmIF9hICE9PSB2b2lkIDAgPyBfYSA6IDApO1xuICAgICAgICB9XG4gICAgfVxuICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBAdHlwZXNjcmlwdC1lc2xpbnQvYmFuLXRzLWNvbW1lbnRcbiAgICAvLyBAdHMtZXhwZWN0LWVycm9yXG4gICAgX3RyYWluUGF0dGVybnMoZGF0YSkge1xuICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IGRhdGEubGVuZ3RoOyArK2kpIHtcbiAgICAgICAgICAgIHRoaXMuX3RyYWluUGF0dGVybihkYXRhW2ldLCBmYWxzZSk7XG4gICAgICAgIH1cbiAgICB9XG4gICAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIEB0eXBlc2NyaXB0LWVzbGludC9iYW4tdHMtY29tbWVudFxuICAgIC8vIEB0cy1leHBlY3QtZXJyb3JcbiAgICBfdHJhaW5QYXR0ZXJuKGlucHV0cywgbG9nRXJyb3JSYXRlKSB7XG4gICAgICAgIC8vIGZvcndhcmQgcHJvcGFnYXRlXG4gICAgICAgIHRoaXMucnVuSW5wdXRzKGlucHV0cyk7XG4gICAgICAgIC8vIGJhY2sgcHJvcGFnYXRlXG4gICAgICAgIHRoaXMuX2NhbGN1bGF0ZURlbHRhcyhpbnB1dHMpO1xuICAgICAgICB0aGlzLmFkanVzdFdlaWdodHMoKTtcbiAgICAgICAgaWYgKGxvZ0Vycm9yUmF0ZSkge1xuICAgICAgICAgICAgaWYgKCF0aGlzLm1lYW5TcXVhcmVkRXJyb3IpIHtcbiAgICAgICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ3RoaXMubWVhblNxdWFyZWRFcnJvciBub3Qgc2V0dXAnKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGxldCBlcnJvciA9IG5ldyBGbG9hdDMyQXJyYXkoMSk7XG4gICAgICAgICAgICBmb3IgKGxldCBpID0gMCwgbWF4ID0gaW5wdXRzLmxlbmd0aCAtIDE7IGkgPD0gbWF4OyBpKyspIHtcbiAgICAgICAgICAgICAgICBjb25zdCBsYXllclNldCA9IHRoaXMuX2xheWVyU2V0c1tpXTtcbiAgICAgICAgICAgICAgICBjb25zdCBsYXN0TGF5ZXIgPSBsYXllclNldFtsYXllclNldC5sZW5ndGggLSAxXTtcbiAgICAgICAgICAgICAgICBjb25zdCBwcmV2RXJyb3IgPSBlcnJvcjtcbiAgICAgICAgICAgICAgICBlcnJvciA9IHRoaXMubWVhblNxdWFyZWRFcnJvci5hZGRBYnNvbHV0ZShwcmV2RXJyb3IsIGxhc3RMYXllci5lcnJvcnMpO1xuICAgICAgICAgICAgICAgIHJlbGVhc2UocHJldkVycm9yKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHJldHVybiBjbG9uZSh0aGlzLm1lYW5TcXVhcmVkRXJyb3IuZGl2aWRlKGlucHV0cy5sZW5ndGgsIGVycm9yKSk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIG51bGw7XG4gICAgfVxufVxuXG4vKipcbiAqIEEgbWF0cml4XG4gKi9cbmNsYXNzIE1hdHJpeCB7XG4gICAgY29uc3RydWN0b3Iocm93cywgY29sdW1ucykge1xuICAgICAgICB0aGlzLnJvd3MgPSAwO1xuICAgICAgICB0aGlzLmNvbHVtbnMgPSAwO1xuICAgICAgICBpZiAocm93cylcbiAgICAgICAgICAgIHRoaXMucm93cyA9IHJvd3M7XG4gICAgICAgIGlmIChjb2x1bW5zKVxuICAgICAgICAgICAgdGhpcy5jb2x1bW5zID0gY29sdW1ucztcbiAgICAgICAgdGhpcy53ZWlnaHRzID0gemVyb3MkMSh0aGlzLnJvd3MgKiB0aGlzLmNvbHVtbnMpO1xuICAgICAgICB0aGlzLmRlbHRhcyA9IHplcm9zJDEodGhpcy5yb3dzICogdGhpcy5jb2x1bW5zKTtcbiAgICB9XG4gICAgZ2V0V2VpZ2h0KHJvdywgY29sKSB7XG4gICAgICAgIC8vIHNsb3cgYnV0IGNhcmVmdWwgYWNjZXNzb3IgZnVuY3Rpb25cbiAgICAgICAgLy8gd2Ugd2FudCByb3ctbWFqb3Igb3JkZXJcbiAgICAgICAgY29uc3QgaXggPSB0aGlzLmNvbHVtbnMgKiByb3cgKyBjb2w7XG4gICAgICAgIGlmIChpeCA8IDAgfHwgaXggPj0gdGhpcy53ZWlnaHRzLmxlbmd0aCkge1xuICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdnZXQgYWNjZXNzb3IgaXMgc2tld2VkJyk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHRoaXMud2VpZ2h0c1tpeF07XG4gICAgfVxuICAgIHNldFdlaWdodChyb3csIGNvbCwgdikge1xuICAgICAgICAvLyBzbG93IGJ1dCBjYXJlZnVsIGFjY2Vzc29yIGZ1bmN0aW9uXG4gICAgICAgIGNvbnN0IGl4ID0gdGhpcy5jb2x1bW5zICogcm93ICsgY29sO1xuICAgICAgICBpZiAoaXggPCAwIHx8IGl4ID49IHRoaXMud2VpZ2h0cy5sZW5ndGgpIHtcbiAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcignc2V0IGFjY2Vzc29yIGlzIHNrZXdlZCcpO1xuICAgICAgICB9XG4gICAgICAgIHRoaXMud2VpZ2h0c1tpeF0gPSB2O1xuICAgICAgICByZXR1cm4gdGhpcztcbiAgICB9XG4gICAgZ2V0RGVsdGEocm93LCBjb2wpIHtcbiAgICAgICAgLy8gc2xvdyBidXQgY2FyZWZ1bCBhY2Nlc3NvciBmdW5jdGlvblxuICAgICAgICAvLyB3ZSB3YW50IHJvdy1tYWpvciBvcmRlclxuICAgICAgICBjb25zdCBpeCA9IHRoaXMuY29sdW1ucyAqIHJvdyArIGNvbDtcbiAgICAgICAgaWYgKGl4IDwgMCB8fCBpeCA+PSB0aGlzLmRlbHRhcy5sZW5ndGgpIHtcbiAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcignZ2V0IGFjY2Vzc29yIGlzIHNrZXdlZCcpO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiB0aGlzLmRlbHRhc1tpeF07XG4gICAgfVxuICAgIHNldERlbHRhKHJvdywgY29sLCB2KSB7XG4gICAgICAgIC8vIHNsb3cgYnV0IGNhcmVmdWwgYWNjZXNzb3IgZnVuY3Rpb25cbiAgICAgICAgY29uc3QgaXggPSB0aGlzLmNvbHVtbnMgKiByb3cgKyBjb2w7XG4gICAgICAgIGlmIChpeCA8IDAgfHwgaXggPj0gdGhpcy53ZWlnaHRzLmxlbmd0aCkge1xuICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdzZXQgYWNjZXNzb3IgaXMgc2tld2VkJyk7XG4gICAgICAgIH1cbiAgICAgICAgdGhpcy5kZWx0YXNbaXhdID0gdjtcbiAgICAgICAgcmV0dXJuIHRoaXM7XG4gICAgfVxuICAgIHRvSlNPTigpIHtcbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgIHJvd3M6IHRoaXMucm93cyxcbiAgICAgICAgICAgIGNvbHVtbnM6IHRoaXMuY29sdW1ucyxcbiAgICAgICAgICAgIHdlaWdodHM6IEFycmF5LmZyb20odGhpcy53ZWlnaHRzLnNsaWNlKDApKSxcbiAgICAgICAgfTtcbiAgICB9XG4gICAgc3RhdGljIGZyb21KU09OKGpzb24pIHtcbiAgICAgICAgY29uc3QgbWF0cml4ID0gbmV3IE1hdHJpeChqc29uLnJvd3MsIGpzb24uY29sdW1ucyk7XG4gICAgICAgIGZvciAobGV0IGkgPSAwLCBtYXggPSBqc29uLnJvd3MgKiBqc29uLmNvbHVtbnM7IGkgPCBtYXg7IGkrKykge1xuICAgICAgICAgICAgbWF0cml4LndlaWdodHNbaV0gPSBqc29uLndlaWdodHNbaV07IC8vIGNvcHkgb3ZlciB3ZWlnaHRzXG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIG1hdHJpeDtcbiAgICB9XG4gICAgc3RhdGljIGZyb21BcnJheSh3ZWlnaHRzKSB7XG4gICAgICAgIGNvbnN0IG1hdHJpeCA9IG5ldyBNYXRyaXgod2VpZ2h0cy5sZW5ndGgsIHdlaWdodHNbMF0ubGVuZ3RoKTtcbiAgICAgICAgbWF0cml4LmZyb21BcnJheSh3ZWlnaHRzKTtcbiAgICAgICAgcmV0dXJuIG1hdHJpeDtcbiAgICB9XG4gICAgZGVsdGFzVG9BcnJheSgpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMudG9BcnJheSgnZGVsdGFzJyk7XG4gICAgfVxuICAgIHdlaWdodHNUb0FycmF5KCkge1xuICAgICAgICByZXR1cm4gdGhpcy50b0FycmF5KCd3ZWlnaHRzJyk7XG4gICAgfVxuICAgIHRvQXJyYXkocHJvcCA9ICd3ZWlnaHRzJykge1xuICAgICAgICBjb25zdCByZXN1bHQgPSBuZXcgQXJyYXkodGhpcy5yb3dzKTtcbiAgICAgICAgdGhpcy5pdGVyYXRlKHtcbiAgICAgICAgICAgIHJvdzogKHJvd0luZGV4KSA9PiB7XG4gICAgICAgICAgICAgICAgcmVzdWx0W3Jvd0luZGV4XSA9IG5ldyBBcnJheSh0aGlzLmNvbHVtbnMpO1xuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIGNvbHVtbjogKHJvd0luZGV4LCBjb2x1bW5JbmRleCkgPT4ge1xuICAgICAgICAgICAgICAgIGlmIChwcm9wID09PSAnd2VpZ2h0cycpIHtcbiAgICAgICAgICAgICAgICAgICAgcmVzdWx0W3Jvd0luZGV4XVtjb2x1bW5JbmRleF0gPSB0aGlzLmdldFdlaWdodChyb3dJbmRleCwgY29sdW1uSW5kZXgpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBlbHNlIGlmIChwcm9wID09PSAnZGVsdGFzJykge1xuICAgICAgICAgICAgICAgICAgICByZXN1bHRbcm93SW5kZXhdW2NvbHVtbkluZGV4XSA9IHRoaXMuZ2V0RGVsdGEocm93SW5kZXgsIGNvbHVtbkluZGV4KTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9LFxuICAgICAgICB9KTtcbiAgICAgICAgcmV0dXJuIHJlc3VsdDtcbiAgICB9XG4gICAgZnJvbUFycmF5KGFycmF5LCBwcm9wID0gJ3dlaWdodHMnKSB7XG4gICAgICAgIGlmIChhcnJheS5sZW5ndGggIT09IHRoaXMucm93cykge1xuICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdyb3dzIGRvIG5vdCBtYXRjaCcpO1xuICAgICAgICB9XG4gICAgICAgIGlmIChhcnJheVswXS5sZW5ndGggIT09IHRoaXMuY29sdW1ucykge1xuICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdjb2x1bW5zIGRvIG5vdCBtYXRjaCcpO1xuICAgICAgICB9XG4gICAgICAgIHRoaXMuaXRlcmF0ZSh7XG4gICAgICAgICAgICBjb2x1bW46IChyb3dJbmRleCwgY29sdW1uSW5kZXgpID0+IHtcbiAgICAgICAgICAgICAgICBjb25zdCB2YWx1ZSA9IGFycmF5W3Jvd0luZGV4XVtjb2x1bW5JbmRleF07XG4gICAgICAgICAgICAgICAgaWYgKHR5cGVvZiB2YWx1ZSAhPT0gJ251bWJlcicpIHtcbiAgICAgICAgICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKCd2YWx1ZSBub3QgbnVtYmVyJyk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGlmIChwcm9wID09PSAnd2VpZ2h0cycpIHtcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5zZXRXZWlnaHQocm93SW5kZXgsIGNvbHVtbkluZGV4LCB2YWx1ZSk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGVsc2UgaWYgKHByb3AgPT09ICdkZWx0YXMnKSB7XG4gICAgICAgICAgICAgICAgICAgIHRoaXMuc2V0RGVsdGEocm93SW5kZXgsIGNvbHVtbkluZGV4LCB2YWx1ZSk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSxcbiAgICAgICAgfSk7XG4gICAgICAgIHJldHVybiB0aGlzO1xuICAgIH1cbiAgICBpdGVyYXRlKGNhbGxiYWNrcykge1xuICAgICAgICBjb25zdCByb3dzID0gdGhpcy5yb3dzO1xuICAgICAgICBjb25zdCBjb2x1bW5zID0gdGhpcy5jb2x1bW5zO1xuICAgICAgICBmb3IgKGxldCByb3dJbmRleCA9IDA7IHJvd0luZGV4IDwgcm93czsgcm93SW5kZXgrKykge1xuICAgICAgICAgICAgaWYgKGNhbGxiYWNrcy5yb3cpIHtcbiAgICAgICAgICAgICAgICBjYWxsYmFja3Mucm93KHJvd0luZGV4KTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGZvciAobGV0IGNvbHVtbkluZGV4ID0gMDsgY29sdW1uSW5kZXggPCBjb2x1bW5zOyBjb2x1bW5JbmRleCsrKSB7XG4gICAgICAgICAgICAgICAgaWYgKGNhbGxiYWNrcy5jb2x1bW4pIHtcbiAgICAgICAgICAgICAgICAgICAgY2FsbGJhY2tzLmNvbHVtbihyb3dJbmRleCwgY29sdW1uSW5kZXgpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gdGhpcztcbiAgICB9XG59XG5cbi8qKiByZXR1cm4gTWF0cml4IGJ1dCBmaWxsZWQgd2l0aCByYW5kb20gbnVtYmVycyBmcm9tIGdhdXNzaWFuXG4gKi9cbmNsYXNzIFJhbmRvbU1hdHJpeCBleHRlbmRzIE1hdHJpeCB7XG4gICAgY29uc3RydWN0b3Iocm93cywgY29sdW1ucywgc3RkKSB7XG4gICAgICAgIHN1cGVyKHJvd3MsIGNvbHVtbnMpO1xuICAgICAgICB0aGlzLnN0ZCA9IHN0ZDtcbiAgICAgICAgZm9yIChsZXQgaSA9IDAsIG1heCA9IHRoaXMud2VpZ2h0cy5sZW5ndGg7IGkgPCBtYXg7IGkrKykge1xuICAgICAgICAgICAgdGhpcy53ZWlnaHRzW2ldID0gcmFuZG9tRmxvYXQoLXN0ZCwgc3RkKTtcbiAgICAgICAgfVxuICAgIH1cbn1cblxuY2xhc3MgRGF0YUZvcm1hdHRlciB7XG4gICAgY29uc3RydWN0b3IodmFsdWVzLCBtYXhUaHJlc2hvbGQgPSAwKSB7XG4gICAgICAgIHRoaXMudmFsdWVzID0gdmFsdWVzO1xuICAgICAgICB0aGlzLmluZGV4VGFibGUgPSB7fTtcbiAgICAgICAgdGhpcy5jaGFyYWN0ZXJUYWJsZSA9IHt9O1xuICAgICAgICB0aGlzLmNoYXJhY3RlcnMgPSBbXTtcbiAgICAgICAgdGhpcy5zcGVjaWFsSW5kZXhlcyA9IFtdO1xuICAgICAgICB0aGlzLmlzU2V0dXAgPSBmYWxzZTtcbiAgICAgICAgaWYgKHZhbHVlcyA9PT0gdW5kZWZpbmVkKVxuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB0aGlzLnNldHVwKHZhbHVlcywgbWF4VGhyZXNob2xkKTtcbiAgICB9XG4gICAgc2V0dXAodmFsdWVzLCBtYXhUaHJlc2hvbGQgPSAwKSB7XG4gICAgICAgIGlmICh0aGlzLmlzU2V0dXApXG4gICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ0RhdGFGb3JtYXR0ZXIgaXMgYWxyZWFkeSBzZXR1cCcpO1xuICAgICAgICB0aGlzLnZhbHVlcyA9IHZhbHVlcztcbiAgICAgICAgLy8gZ28gb3ZlciBhbGwgY2hhcmFjdGVycyBhbmQga2VlcCB0cmFjayBvZiBhbGwgdW5pcXVlIG9uZXMgc2VlblxuICAgICAgICAvLyBjb3VudCB1cCBhbGwgY2hhcmFjdGVyc1xuICAgICAgICB0aGlzLmJ1aWxkQ2hhcmFjdGVyc0Zyb21JdGVyYWJsZSh2YWx1ZXMpO1xuICAgICAgICB0aGlzLmJ1aWxkVGFibGVzKG1heFRocmVzaG9sZCk7XG4gICAgICAgIGlmICh2YWx1ZXNbMF0uaW5wdXQpIHtcbiAgICAgICAgICAgIHRoaXMuYWRkSW5wdXRPdXRwdXQoKTtcbiAgICAgICAgfVxuICAgICAgICB0aGlzLmFkZFVucmVjb2duaXplZCgpO1xuICAgICAgICB0aGlzLmlzU2V0dXAgPSB0cnVlO1xuICAgIH1cbiAgICBidWlsZENoYXJhY3RlcnNGcm9tSXRlcmFibGUodmFsdWVzKSB7XG4gICAgICAgIGNvbnN0IHRlbXBDaGFyYWN0ZXJzVGFibGUgPSB7fTtcbiAgICAgICAgZm9yIChsZXQgZGF0YUZvcm1hdHRlckluZGV4ID0gMCwgZGF0YUZvcm1hdHRlckxlbmd0aCA9IHZhbHVlcy5sZW5ndGg7IGRhdGFGb3JtYXR0ZXJJbmRleCA8IGRhdGFGb3JtYXR0ZXJMZW5ndGg7IGRhdGFGb3JtYXR0ZXJJbmRleCsrKSB7XG4gICAgICAgICAgICBjb25zdCBjaGFyYWN0ZXJzID0gdmFsdWVzW2RhdGFGb3JtYXR0ZXJJbmRleF07XG4gICAgICAgICAgICAvLyBpZiAodHlwZW9mIGNoYXJhY3RlcnMgPT09ICdzdHJpbmcnKSB7XG4gICAgICAgICAgICAvLyAgIGNvbnN0IGNoYXJhY3RlciA9IGNoYXJhY3RlcnM7XG4gICAgICAgICAgICAvLyAgIGlmICh0ZW1wQ2hhcmFjdGVyc1RhYmxlLmhhc093blByb3BlcnR5KGNoYXJhY3RlcikpIGNvbnRpbnVlO1xuICAgICAgICAgICAgLy8gICB0ZW1wQ2hhcmFjdGVyc1RhYmxlW2NoYXJhY3Rlcl0gPSB0cnVlO1xuICAgICAgICAgICAgLy8gICB0aGlzLmNoYXJhY3RlcnMucHVzaChjaGFyYWN0ZXIpO1xuICAgICAgICAgICAgaWYgKGNoYXJhY3RlcnMuaGFzT3duUHJvcGVydHkoJ2xlbmd0aCcpKSB7XG4gICAgICAgICAgICAgICAgY29uc3QgaXRlcmF0YWJsZSA9IGNoYXJhY3RlcnM7XG4gICAgICAgICAgICAgICAgZm9yIChsZXQgY2hhcmFjdGVySW5kZXggPSAwLCBjaGFyYWN0ZXJzTGVuZ3RoID0gaXRlcmF0YWJsZS5sZW5ndGg7IGNoYXJhY3RlckluZGV4IDwgY2hhcmFjdGVyc0xlbmd0aDsgY2hhcmFjdGVySW5kZXgrKykge1xuICAgICAgICAgICAgICAgICAgICBjb25zdCBjaGFyYWN0ZXIgPSBpdGVyYXRhYmxlW2NoYXJhY3RlckluZGV4XTtcbiAgICAgICAgICAgICAgICAgICAgaWYgKHRlbXBDaGFyYWN0ZXJzVGFibGUuaGFzT3duUHJvcGVydHkoY2hhcmFjdGVyKSlcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnRpbnVlO1xuICAgICAgICAgICAgICAgICAgICB0ZW1wQ2hhcmFjdGVyc1RhYmxlW2NoYXJhY3Rlcl0gPSB0cnVlO1xuICAgICAgICAgICAgICAgICAgICB0aGlzLmNoYXJhY3RlcnMucHVzaChjaGFyYWN0ZXIpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGVsc2UgaWYgKHR5cGVvZiBjaGFyYWN0ZXJzID09PSAnbnVtYmVyJykge1xuICAgICAgICAgICAgICAgIGlmICh0ZW1wQ2hhcmFjdGVyc1RhYmxlLmhhc093blByb3BlcnR5KGNoYXJhY3RlcnMpKVxuICAgICAgICAgICAgICAgICAgICBjb250aW51ZTtcbiAgICAgICAgICAgICAgICB0ZW1wQ2hhcmFjdGVyc1RhYmxlW2NoYXJhY3RlcnNdID0gdHJ1ZTtcbiAgICAgICAgICAgICAgICB0aGlzLmNoYXJhY3RlcnMucHVzaChjaGFyYWN0ZXJzKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGVsc2UgaWYgKHR5cGVvZiBjaGFyYWN0ZXJzID09PSAnYm9vbGVhbicpIHtcbiAgICAgICAgICAgICAgICBjb25zdCBjaGFyYWN0ZXIgPSBjaGFyYWN0ZXJzLnRvU3RyaW5nKCk7XG4gICAgICAgICAgICAgICAgaWYgKHRlbXBDaGFyYWN0ZXJzVGFibGUuaGFzT3duUHJvcGVydHkoY2hhcmFjdGVyKSlcbiAgICAgICAgICAgICAgICAgICAgY29udGludWU7XG4gICAgICAgICAgICAgICAgdGVtcENoYXJhY3RlcnNUYWJsZVtjaGFyYWN0ZXJdID0gdHJ1ZTtcbiAgICAgICAgICAgICAgICB0aGlzLmNoYXJhY3RlcnMucHVzaChjaGFyYWN0ZXIpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZWxzZSBpZiAoQXJyYXkuaXNBcnJheShjaGFyYWN0ZXJzKSAmJlxuICAgICAgICAgICAgICAgIHR5cGVvZiBjaGFyYWN0ZXJzWzBdID09PSAnc3RyaW5nJykge1xuICAgICAgICAgICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgY2hhcmFjdGVycy5sZW5ndGg7IGkrKykge1xuICAgICAgICAgICAgICAgICAgICBjb25zdCBjaGFyYWN0ZXIgPSBjaGFyYWN0ZXJzW2ldO1xuICAgICAgICAgICAgICAgICAgICBpZiAodGVtcENoYXJhY3RlcnNUYWJsZS5oYXNPd25Qcm9wZXJ0eShjaGFyYWN0ZXIpKVxuICAgICAgICAgICAgICAgICAgICAgICAgY29udGludWU7XG4gICAgICAgICAgICAgICAgICAgIHRlbXBDaGFyYWN0ZXJzVGFibGVbY2hhcmFjdGVyXSA9IHRydWU7XG4gICAgICAgICAgICAgICAgICAgIHRoaXMuY2hhcmFjdGVycy5wdXNoKGNoYXJhY3Rlcik7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZWxzZSBpZiAoQXJyYXkuaXNBcnJheShjaGFyYWN0ZXJzKSAmJlxuICAgICAgICAgICAgICAgICh0eXBlb2YgY2hhcmFjdGVyc1swXSA9PT0gJ251bWJlcicgfHxcbiAgICAgICAgICAgICAgICAgICAgdHlwZW9mIGNoYXJhY3RlcnNbMF0gPT09ICdib29sZWFuJykpIHtcbiAgICAgICAgICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IGNoYXJhY3RlcnMubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgY2hhcmFjdGVyID0gY2hhcmFjdGVyc1tpXS50b1N0cmluZygpO1xuICAgICAgICAgICAgICAgICAgICBpZiAodGVtcENoYXJhY3RlcnNUYWJsZS5oYXNPd25Qcm9wZXJ0eShkYXRhRm9ybWF0dGVySW5kZXgpKVxuICAgICAgICAgICAgICAgICAgICAgICAgY29udGludWU7XG4gICAgICAgICAgICAgICAgICAgIHRlbXBDaGFyYWN0ZXJzVGFibGVbY2hhcmFjdGVyXSA9IHRydWU7XG4gICAgICAgICAgICAgICAgICAgIHRoaXMuY2hhcmFjdGVycy5wdXNoKGNoYXJhY3Rlcik7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZWxzZSBpZiAoY2hhcmFjdGVycy5oYXNPd25Qcm9wZXJ0eSgnaW5wdXQnKSAmJlxuICAgICAgICAgICAgICAgIGNoYXJhY3RlcnMuaGFzT3duUHJvcGVydHkoJ291dHB1dCcpKSB7XG4gICAgICAgICAgICAgICAgY29uc3QgeyBpbnB1dCwgb3V0cHV0IH0gPSBjaGFyYWN0ZXJzO1xuICAgICAgICAgICAgICAgIGlmIChBcnJheS5pc0FycmF5KGlucHV0KSkge1xuICAgICAgICAgICAgICAgICAgICB0aGlzLmFkZENoYXJhY3RlcnMoaW5wdXQsIHRlbXBDaGFyYWN0ZXJzVGFibGUpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5hZGRDaGFyYWN0ZXJzKGlucHV0LnRvU3RyaW5nKCksIHRlbXBDaGFyYWN0ZXJzVGFibGUpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBpZiAoQXJyYXkuaXNBcnJheShvdXRwdXQpKSB7XG4gICAgICAgICAgICAgICAgICAgIHRoaXMuYWRkQ2hhcmFjdGVycyhvdXRwdXQsIHRlbXBDaGFyYWN0ZXJzVGFibGUpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5hZGRDaGFyYWN0ZXJzKG91dHB1dC50b1N0cmluZygpLCB0ZW1wQ2hhcmFjdGVyc1RhYmxlKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ1VuaGFuZGxlZCB2YWx1ZScpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfVxuICAgIGFkZENoYXJhY3RlcnMoY2hhcmFjdGVycywgY2hhcmFjdGVyc1RhYmxlKSB7XG4gICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgY2hhcmFjdGVycy5sZW5ndGg7IGkrKykge1xuICAgICAgICAgICAgY29uc3QgY2hhcmFjdGVyID0gY2hhcmFjdGVyc1tpXS50b1N0cmluZygpO1xuICAgICAgICAgICAgaWYgKGNoYXJhY3RlcnNUYWJsZS5oYXNPd25Qcm9wZXJ0eShjaGFyYWN0ZXIpKVxuICAgICAgICAgICAgICAgIGNvbnRpbnVlO1xuICAgICAgICAgICAgY2hhcmFjdGVyc1RhYmxlW2NoYXJhY3Rlcl0gPSB0cnVlO1xuICAgICAgICAgICAgdGhpcy5jaGFyYWN0ZXJzLnB1c2goY2hhcmFjdGVyKTtcbiAgICAgICAgfVxuICAgIH1cbiAgICBidWlsZFRhYmxlcyhtYXhUaHJlc2hvbGQpIHtcbiAgICAgICAgLy8gZmlsdGVyIGJ5IGNvdW50IHRocmVzaG9sZCBhbmQgY3JlYXRlIHBvaW50ZXJzXG4gICAgICAgIGNvbnN0IGNoYXJhY3RlcnNMZW5ndGggPSB0aGlzLmNoYXJhY3RlcnMubGVuZ3RoO1xuICAgICAgICBmb3IgKGxldCBjaGFyYWN0ZXJJbmRleCA9IDA7IGNoYXJhY3RlckluZGV4IDwgY2hhcmFjdGVyc0xlbmd0aDsgY2hhcmFjdGVySW5kZXgrKykge1xuICAgICAgICAgICAgY29uc3QgY2hhcmFjdGVyID0gdGhpcy5jaGFyYWN0ZXJzW2NoYXJhY3RlckluZGV4XTtcbiAgICAgICAgICAgIGlmIChjaGFyYWN0ZXJJbmRleCA+PSBtYXhUaHJlc2hvbGQpIHtcbiAgICAgICAgICAgICAgICAvLyBhZGQgY2hhcmFjdGVyIHRvIGRhdGFGb3JtYXR0ZXJcbiAgICAgICAgICAgICAgICB0aGlzLmluZGV4VGFibGVbY2hhcmFjdGVyXSA9IGNoYXJhY3RlckluZGV4O1xuICAgICAgICAgICAgICAgIHRoaXMuY2hhcmFjdGVyVGFibGVbY2hhcmFjdGVySW5kZXhdID0gY2hhcmFjdGVyO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfVxuICAgIHRvSW5kZXhlcyh2YWx1ZSwgbWF4VGhyZXNob2xkID0gMCkge1xuICAgICAgICBjb25zdCByZXN1bHQgPSBbXTtcbiAgICAgICAgY29uc3QgeyBpbmRleFRhYmxlIH0gPSB0aGlzO1xuICAgICAgICBzd2l0Y2ggKHR5cGVvZiB2YWx1ZSkge1xuICAgICAgICAgICAgY2FzZSAnbnVtYmVyJzpcbiAgICAgICAgICAgIGNhc2UgJ2Jvb2xlYW4nOlxuICAgICAgICAgICAgICAgIHZhbHVlID0gdmFsdWUudG9TdHJpbmcoKTtcbiAgICAgICAgfVxuICAgICAgICBmb3IgKGxldCBpID0gMCwgbWF4ID0gdmFsdWUubGVuZ3RoOyBpIDwgbWF4OyBpKyspIHtcbiAgICAgICAgICAgIGNvbnN0IGNoYXJhY3RlciA9IHZhbHVlW2ldLnRvU3RyaW5nKCk7XG4gICAgICAgICAgICBsZXQgaW5kZXggPSBpbmRleFRhYmxlW2NoYXJhY3Rlcl07XG4gICAgICAgICAgICBpZiAoaW5kZXggPT09IHVuZGVmaW5lZCkge1xuICAgICAgICAgICAgICAgIGlmIChpbmRleFRhYmxlLnVucmVjb2duaXplZCkge1xuICAgICAgICAgICAgICAgICAgICBpbmRleCA9IGluZGV4VGFibGUudW5yZWNvZ25pemVkO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKGB1bnJlY29nbml6ZWQgY2hhcmFjdGVyIFwiJHtjaGFyYWN0ZXJ9XCJgKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBpZiAoaW5kZXggPCBtYXhUaHJlc2hvbGQpXG4gICAgICAgICAgICAgICAgY29udGludWU7XG4gICAgICAgICAgICByZXN1bHQucHVzaChpbmRleCk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHJlc3VsdDtcbiAgICB9XG4gICAgdG9JbmRleGVzSW5wdXRPdXRwdXQoaW5wdXQsIG91dHB1dCwgbWF4VGhyZXNob2xkID0gMCkge1xuICAgICAgICBjb25zdCByZXN1bHQgPSB0aGlzLnRvSW5kZXhlc1ZhbHVlKGlucHV0LCBtYXhUaHJlc2hvbGQsIHRydWUpO1xuICAgICAgICBpZiAodHlwZW9mIG91dHB1dCA9PT0gJ3VuZGVmaW5lZCcpXG4gICAgICAgICAgICByZXR1cm4gcmVzdWx0O1xuICAgICAgICByZXR1cm4gcmVzdWx0LmNvbmNhdCh0aGlzLnRvSW5kZXhlc1ZhbHVlKG91dHB1dCwgbWF4VGhyZXNob2xkLCBmYWxzZSkpO1xuICAgIH1cbiAgICB0b0luZGV4ZXNWYWx1ZSh2YWx1ZSwgbWF4VGhyZXNob2xkLCBpc0lucHV0KSB7XG4gICAgICAgIGlmICh0eXBlb2YgdmFsdWUgPT09ICdzdHJpbmcnKSB7XG4gICAgICAgICAgICB2YWx1ZSA9IHZhbHVlLnNwbGl0KCcnKTtcbiAgICAgICAgfVxuICAgICAgICBlbHNlIGlmICh0eXBlb2YgdmFsdWUgPT09ICdudW1iZXInIHx8IHR5cGVvZiB2YWx1ZSA9PT0gJ2Jvb2xlYW4nKSB7XG4gICAgICAgICAgICB2YWx1ZSA9IHZhbHVlLnRvU3RyaW5nKCkuc3BsaXQoJycpO1xuICAgICAgICB9XG4gICAgICAgIGVsc2UgaWYgKEFycmF5LmlzQXJyYXkodmFsdWUpICYmXG4gICAgICAgICAgICAodHlwZW9mIHZhbHVlWzBdID09PSAnbnVtYmVyJyB8fFxuICAgICAgICAgICAgICAgIHR5cGVvZiB2YWx1ZVswXSA9PT0gJ2Jvb2xlYW4nIHx8XG4gICAgICAgICAgICAgICAgdHlwZW9mIHZhbHVlWzBdID09PSAnc3RyaW5nJykpIHtcbiAgICAgICAgICAgIHZhbHVlID0gdmFsdWUubWFwKCh2KSA9PiB2LnRvU3RyaW5nKCkpO1xuICAgICAgICB9XG4gICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKCd1bnJlY29nbml6ZWQgdmFsdWUnKTtcbiAgICAgICAgfVxuICAgICAgICBpZiAoaXNJbnB1dCkge1xuICAgICAgICAgICAgdmFsdWUgPSB2YWx1ZS5jb25jYXQoWydzdG9wLWlucHV0JywgJ3N0YXJ0LW91dHB1dCddKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gdGhpcy50b0luZGV4ZXModmFsdWUsIG1heFRocmVzaG9sZCk7XG4gICAgfVxuICAgIHRvQ2hhcmFjdGVycyhpbmRpY2VzLCBtYXhUaHJlc2hvbGQgPSAwKSB7XG4gICAgICAgIGNvbnN0IHJlc3VsdCA9IFtdO1xuICAgICAgICBjb25zdCB7IGluZGV4VGFibGUsIGNoYXJhY3RlclRhYmxlIH0gPSB0aGlzO1xuICAgICAgICBmb3IgKGxldCBpID0gMCwgbWF4ID0gaW5kaWNlcy5sZW5ndGg7IGkgPCBtYXg7IGkrKykge1xuICAgICAgICAgICAgY29uc3QgaW5kZXggPSBpbmRpY2VzW2ldO1xuICAgICAgICAgICAgaWYgKGluZGV4IDwgbWF4VGhyZXNob2xkKVxuICAgICAgICAgICAgICAgIGNvbnRpbnVlO1xuICAgICAgICAgICAgbGV0IGNoYXJhY3RlciA9IGNoYXJhY3RlclRhYmxlW2luZGV4XTtcbiAgICAgICAgICAgIGlmIChjaGFyYWN0ZXIgPT09IHVuZGVmaW5lZCkge1xuICAgICAgICAgICAgICAgIGlmIChpbmRleFRhYmxlLnVucmVjb2duaXplZCkge1xuICAgICAgICAgICAgICAgICAgICBjaGFyYWN0ZXIgPSBjaGFyYWN0ZXJUYWJsZVtpbmRleFRhYmxlLnVucmVjb2duaXplZF07XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoYHVucmVjb2duaXplZCBpbmRleCBcIiR7aW5kZXh9XCJgKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBlbHNlIGlmIChjaGFyYWN0ZXIgIT09IG51bGwpIHtcbiAgICAgICAgICAgICAgICByZXN1bHQucHVzaChjaGFyYWN0ZXIudG9TdHJpbmcoKSk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHJlc3VsdDtcbiAgICB9XG4gICAgdG9TdHJpbmcoaW5kaWNlcywgbWF4VGhyZXNob2xkKSB7XG4gICAgICAgIHJldHVybiB0aGlzLnRvQ2hhcmFjdGVycyhpbmRpY2VzLCBtYXhUaHJlc2hvbGQpLmpvaW4oJycpO1xuICAgIH1cbiAgICBhZGRJbnB1dE91dHB1dCgpIHtcbiAgICAgICAgdGhpcy5hZGRTcGVjaWFsKCdzdG9wLWlucHV0Jyk7XG4gICAgICAgIHRoaXMuYWRkU3BlY2lhbCgnc3RhcnQtb3V0cHV0Jyk7XG4gICAgfVxuICAgIGFkZFVucmVjb2duaXplZCgpIHtcbiAgICAgICAgdGhpcy5hZGRTcGVjaWFsKCd1bnJlY29nbml6ZWQnKTtcbiAgICB9XG4gICAgc3RhdGljIGZyb21BbGxQcmludGFibGUobWF4VGhyZXNob2xkLCB2YWx1ZXMgPSBbJ1xcbiddKSB7XG4gICAgICAgIGZvciAobGV0IGkgPSAzMjsgaSA8PSAxMjY7IGkrKykge1xuICAgICAgICAgICAgdmFsdWVzLnB1c2goU3RyaW5nLmZyb21DaGFyQ29kZShpKSk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIG5ldyBEYXRhRm9ybWF0dGVyKHZhbHVlcywgbWF4VGhyZXNob2xkKTtcbiAgICB9XG4gICAgc3RhdGljIGZyb21BbGxQcmludGFibGVJbnB1dE91dHB1dChtYXhUaHJlc2hvbGQsIHZhbHVlcyA9IFsnXFxuJ10pIHtcbiAgICAgICAgY29uc3QgZGF0YUZvcm1hdHRlciA9IERhdGFGb3JtYXR0ZXIuZnJvbUFsbFByaW50YWJsZShtYXhUaHJlc2hvbGQsIHZhbHVlcyk7XG4gICAgICAgIGRhdGFGb3JtYXR0ZXIuYWRkSW5wdXRPdXRwdXQoKTtcbiAgICAgICAgZGF0YUZvcm1hdHRlci5hZGRVbnJlY29nbml6ZWQoKTtcbiAgICAgICAgcmV0dXJuIGRhdGFGb3JtYXR0ZXI7XG4gICAgfVxuICAgIHN0YXRpYyBmcm9tU3RyaW5nSW5wdXRPdXRwdXQoc3RyaW5nLCBtYXhUaHJlc2hvbGQpIHtcbiAgICAgICAgY29uc3QgdmFsdWVzID0gQXJyYXkuZnJvbShuZXcgU2V0KHN0cmluZykpLmpvaW4oJycpO1xuICAgICAgICBjb25zdCBkYXRhRm9ybWF0dGVyID0gbmV3IERhdGFGb3JtYXR0ZXIodmFsdWVzLnNwbGl0KCcnKSwgbWF4VGhyZXNob2xkKTtcbiAgICAgICAgZGF0YUZvcm1hdHRlci5hZGRJbnB1dE91dHB1dCgpO1xuICAgICAgICBkYXRhRm9ybWF0dGVyLmFkZFVucmVjb2duaXplZCgpO1xuICAgICAgICBkYXRhRm9ybWF0dGVyLmlzU2V0dXAgPSB0cnVlO1xuICAgICAgICByZXR1cm4gZGF0YUZvcm1hdHRlcjtcbiAgICB9XG4gICAgc3RhdGljIGZyb21BcnJheUlucHV0T3V0cHV0KGRhdGEsIG1heFRocmVzaG9sZCkge1xuICAgICAgICBjb25zdCB2YWx1ZXMgPSBbXTtcbiAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBkYXRhLmxlbmd0aDsgaSsrKSB7XG4gICAgICAgICAgICBjb25zdCBkYXR1bSA9IGRhdGFbaV07XG4gICAgICAgICAgICB2YWx1ZXMucHVzaCh2YWxpZGF0ZUFuZENhc3QoZGF0dW0uaW5wdXQpLCB2YWxpZGF0ZUFuZENhc3QoZGF0dW0ub3V0cHV0KSk7XG4gICAgICAgIH1cbiAgICAgICAgY29uc3QgZmxhdEFycmF5ID0gQXJyYXkuaXNBcnJheSh2YWx1ZXMpXG4gICAgICAgICAgICA/IHZhbHVlcy5mbGF0KClcbiAgICAgICAgICAgIDogdmFsdWVzO1xuICAgICAgICBjb25zdCBkYXRhRm9ybWF0dGVyID0gbmV3IERhdGFGb3JtYXR0ZXIoQXJyYXkuZnJvbShuZXcgU2V0KGZsYXRBcnJheSkpLCBtYXhUaHJlc2hvbGQpO1xuICAgICAgICBkYXRhRm9ybWF0dGVyLmFkZElucHV0T3V0cHV0KCk7XG4gICAgICAgIGRhdGFGb3JtYXR0ZXIuYWRkVW5yZWNvZ25pemVkKCk7XG4gICAgICAgIGRhdGFGb3JtYXR0ZXIuaXNTZXR1cCA9IHRydWU7XG4gICAgICAgIHJldHVybiBkYXRhRm9ybWF0dGVyO1xuICAgIH1cbiAgICBzdGF0aWMgZnJvbVN0cmluZyhzdHJpbmcsIG1heFRocmVzaG9sZCA9IDApIHtcbiAgICAgICAgY29uc3QgdmFsdWVzID0gQXJyYXkuZnJvbShuZXcgU2V0KHN0cmluZykpLmpvaW4oJycpO1xuICAgICAgICByZXR1cm4gbmV3IERhdGFGb3JtYXR0ZXIodmFsdWVzLnNwbGl0KCcnKSwgbWF4VGhyZXNob2xkKTtcbiAgICB9XG4gICAgdG9KU09OKCkge1xuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgaW5kZXhUYWJsZTogdGhpcy5pbmRleFRhYmxlLFxuICAgICAgICAgICAgY2hhcmFjdGVyVGFibGU6IHRoaXMuY2hhcmFjdGVyVGFibGUsXG4gICAgICAgICAgICB2YWx1ZXM6IHRoaXMudmFsdWVzLFxuICAgICAgICAgICAgY2hhcmFjdGVyczogdGhpcy5jaGFyYWN0ZXJzLFxuICAgICAgICAgICAgc3BlY2lhbEluZGV4ZXM6IHRoaXMuc3BlY2lhbEluZGV4ZXMsXG4gICAgICAgIH07XG4gICAgfVxuICAgIC8qKiBUT0RPOiBUeXBlIGJldHRlciwgVGhlIHR5cGUgb2YganNvbiBpcyBub3QgXCJzdHJpbmcgdGhhdCBpcyBhIHZhbGlkIEpTT05cIiwgaXQgaXMgYSBQT0pPIGluIHRoZSBzaGFwZSBvZiBEYXRhRm9ybWF0dGVyLlxuICAgICAqIHRoaXMgbWV0aG9kIHJlLWh5ZHJhdGVzIHRoZSB0aGUgZGF0YSBhcyBhbiBpbnN0YW5jZSBvZiBEYXRhRm9ybWF0dGVyLlxuICAgICAqL1xuICAgIHN0YXRpYyBmcm9tSlNPTihqc29uKSB7XG4gICAgICAgIGNvbnN0IGRhdGFGb3JtYXR0ZXIgPSBuZXcgRGF0YUZvcm1hdHRlcigpO1xuICAgICAgICBkYXRhRm9ybWF0dGVyLmluZGV4VGFibGUgPSBqc29uLmluZGV4VGFibGU7XG4gICAgICAgIGRhdGFGb3JtYXR0ZXIuY2hhcmFjdGVyVGFibGUgPSBqc29uLmNoYXJhY3RlclRhYmxlO1xuICAgICAgICBkYXRhRm9ybWF0dGVyLnZhbHVlcyA9IGpzb24udmFsdWVzO1xuICAgICAgICBkYXRhRm9ybWF0dGVyLmNoYXJhY3RlcnMgPSBqc29uLmNoYXJhY3RlcnM7XG4gICAgICAgIGRhdGFGb3JtYXR0ZXIuc3BlY2lhbEluZGV4ZXMgPSBqc29uLnNwZWNpYWxJbmRleGVzO1xuICAgICAgICByZXR1cm4gZGF0YUZvcm1hdHRlcjtcbiAgICB9XG4gICAgYWRkU3BlY2lhbChzcGVjaWFsLCBjaGFyYWN0ZXIgPSBudWxsKSB7XG4gICAgICAgIGNvbnN0IHNwZWNpYWxJbmRleCA9ICh0aGlzLmluZGV4VGFibGVbc3BlY2lhbF0gPSB0aGlzLmNoYXJhY3RlcnMubGVuZ3RoKTtcbiAgICAgICAgdGhpcy5jaGFyYWN0ZXJUYWJsZVtzcGVjaWFsSW5kZXhdID0gY2hhcmFjdGVyO1xuICAgICAgICB0aGlzLnNwZWNpYWxJbmRleGVzLnB1c2godGhpcy5jaGFyYWN0ZXJzLmxlbmd0aCk7XG4gICAgICAgIHRoaXMuY2hhcmFjdGVycy5wdXNoKHNwZWNpYWwpO1xuICAgIH1cbiAgICB0b0Z1bmN0aW9uU3RyaW5nKCkge1xuICAgICAgICByZXR1cm4gYFxudmFyIGNoYXJhY3RlclRhYmxlID0gJHtKU09OLnN0cmluZ2lmeSh0aGlzLmNoYXJhY3RlclRhYmxlKX07XG52YXIgaW5kZXhUYWJsZSA9ICR7SlNPTi5zdHJpbmdpZnkodGhpcy5pbmRleFRhYmxlKX07XG52YXIgY2hhcmFjdGVycyA9ICR7SlNPTi5zdHJpbmdpZnkodGhpcy5jaGFyYWN0ZXJzKX07XG52YXIgZGF0YUZvcm1hdHRlciA9IHtcbiAgdG9JbmRleGVzOiBmdW5jdGlvbiAke3RoaXMudG9JbmRleGVzLnRvU3RyaW5nKCl9LFxuICB0b0luZGV4ZXNJbnB1dE91dHB1dDogZnVuY3Rpb24gJHt0aGlzLnRvSW5kZXhlc0lucHV0T3V0cHV0LnRvU3RyaW5nKCl9LFxuICB0b0NoYXJhY3RlcnM6IGZ1bmN0aW9uICR7dGhpcy50b0NoYXJhY3RlcnMudG9TdHJpbmcoKX0sXG4gIHRvSW5kZXhlc1ZhbHVlOiBmdW5jdGlvbiAke3RoaXMudG9JbmRleGVzVmFsdWUudG9TdHJpbmcoKX0sXG59O2A7XG4gICAgfVxuICAgIGZvcm1hdERhdGFJbihpbnB1dCwgb3V0cHV0KSB7XG4gICAgICAgIHZhciBfYTtcbiAgICAgICAgaWYgKGlucHV0ID09PSB1bmRlZmluZWQpXG4gICAgICAgICAgICByZXR1cm4gW107XG4gICAgICAgIGlmIChBcnJheS5pc0FycmF5KGlucHV0KSAmJiB0eXBlb2YgaW5wdXRbMF0gPT09ICdudW1iZXInKSB7XG4gICAgICAgICAgICByZXR1cm4gaW5wdXQ7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKChfYSA9IHRoaXMuaW5kZXhUYWJsZSkgPT09IG51bGwgfHwgX2EgPT09IHZvaWQgMCA/IHZvaWQgMCA6IF9hLmhhc093blByb3BlcnR5KCdzdG9wLWlucHV0JykpIHtcbiAgICAgICAgICAgIHJldHVybiB0aGlzLnRvSW5kZXhlc0lucHV0T3V0cHV0KGlucHV0LCBvdXRwdXQpO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiB0aGlzLnRvSW5kZXhlcyhpbnB1dCk7XG4gICAgfVxuICAgIGZvcm1hdERhdGFPdXQoaW5wdXQsIG91dHB1dCkge1xuICAgICAgICByZXR1cm4gdGhpcy50b0NoYXJhY3RlcnMob3V0cHV0KS5qb2luKCcnKTtcbiAgICB9XG4gICAgZm9ybWF0KGRhdGEpIHtcbiAgICAgICAgaWYgKHR5cGVvZiBkYXRhWzBdID09PSAnbnVtYmVyJyAmJlxuICAgICAgICAgICAgIUFycmF5LmlzQXJyYXkoZGF0YVswXSkgJiZcbiAgICAgICAgICAgICghZGF0YVswXS5oYXNPd25Qcm9wZXJ0eSgnaW5wdXQnKSB8fCAhZGF0YVswXS5oYXNPd25Qcm9wZXJ0eSgnb3V0cHV0JykpKSB7XG4gICAgICAgICAgICByZXR1cm4gZGF0YTtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCByZXN1bHQgPSBbXTtcbiAgICAgICAgaWYgKHR5cGVvZiBkYXRhWzBdID09PSAnc3RyaW5nJyB8fFxuICAgICAgICAgICAgdHlwZW9mIGRhdGFbMF0gPT09ICdudW1iZXInIHx8XG4gICAgICAgICAgICBBcnJheS5pc0FycmF5KGRhdGFbMF0pKSB7XG4gICAgICAgICAgICBpZiAoIXRoaXMuaXNTZXR1cCkge1xuICAgICAgICAgICAgICAgIHRoaXMuc2V0dXAoZGF0YSk7XG4gICAgICAgICAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBkYXRhLmxlbmd0aDsgaSsrKSB7XG4gICAgICAgICAgICAgICAgICAgIHJlc3VsdC5wdXNoKHRoaXMuZm9ybWF0RGF0YUluKHZhbGlkYXRlQW5kQ2FzdChkYXRhW2ldKSkpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgIGZvciAobGV0IGkgPSAwLCBtYXggPSBkYXRhLmxlbmd0aDsgaSA8IG1heDsgaSsrKSB7XG4gICAgICAgICAgICAgICAgICAgIHJlc3VsdC5wdXNoKHRoaXMuZm9ybWF0RGF0YUluKGRhdGFbaV0pKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSBpZiAoZGF0YVswXS5pbnB1dCAmJiBkYXRhWzBdLm91dHB1dCkge1xuICAgICAgICAgICAgaWYgKCF0aGlzLmlzU2V0dXApIHtcbiAgICAgICAgICAgICAgICB0aGlzLnNldHVwKGRhdGEpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZm9yIChsZXQgaSA9IDAsIG1heCA9IGRhdGEubGVuZ3RoOyBpIDwgbWF4OyBpKyspIHtcbiAgICAgICAgICAgICAgICByZXN1bHQucHVzaCh0aGlzLmZvcm1hdERhdGFJbih2YWxpZGF0ZUFuZENhc3QoZGF0YVtpXS5pbnB1dCksIHZhbGlkYXRlQW5kQ2FzdChkYXRhW2ldLm91dHB1dCkpKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcigndW5yZWNvZ25pemVkIGRhdGEnKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gcmVzdWx0O1xuICAgIH1cbn1cbmZ1bmN0aW9uIHZhbGlkYXRlQW5kQ2FzdCh2YWx1ZSkge1xuICAgIGlmICh0eXBlb2YgdmFsdWUgPT09ICdzdHJpbmcnKVxuICAgICAgICByZXR1cm4gdmFsdWU7XG4gICAgaWYgKHR5cGVvZiB2YWx1ZSA9PT0gJ251bWJlcicpXG4gICAgICAgIHJldHVybiB2YWx1ZS50b1N0cmluZygpO1xuICAgIGlmICh0eXBlb2YgdmFsdWUgPT09ICdib29sZWFuJylcbiAgICAgICAgcmV0dXJuIHZhbHVlLnRvU3RyaW5nKCk7XG4gICAgaWYgKEFycmF5LmlzQXJyYXkodmFsdWUpICYmIHR5cGVvZiB2YWx1ZVswXSA9PT0gJ3N0cmluZycpXG4gICAgICAgIHJldHVybiB2YWx1ZTtcbiAgICBpZiAodHlwZW9mIHZhbHVlWzBdID09PSAnYm9vbGVhbicpIHtcbiAgICAgICAgcmV0dXJuIHZhbHVlLm1hcCgodikgPT4gdi50b1N0cmluZygpKTtcbiAgICB9XG4gICAgaWYgKHR5cGVvZiB2YWx1ZVswXSA9PT0gJ251bWJlcicpIHtcbiAgICAgICAgcmV0dXJuIHZhbHVlLm1hcCgodikgPT4gdi50b1N0cmluZygpKTtcbiAgICB9XG4gICAgdGhyb3cgbmV3IEVycm9yKCd1bnJlY29nbml6ZWQgdmFsdWUsIGV4cGVjdGVkIHN0cmluZ1tdLCBzdHJpbmcsIG51bWJlcltdLCBudW1iZXIsIGJvb2xlYW5bXSwgb3IgYm9vbGVhbicpO1xufVxuXG5mdW5jdGlvbiBjb3B5KHByb2R1Y3QsIGxlZnQpIHtcbiAgICBwcm9kdWN0LnJvd3MgPSBsZWZ0LnJvd3M7XG4gICAgcHJvZHVjdC5jb2x1bW5zID0gbGVmdC5jb2x1bW5zO1xuICAgIHByb2R1Y3Qud2VpZ2h0cyA9IGxlZnQud2VpZ2h0cy5zbGljZSgwKTtcbiAgICBwcm9kdWN0LmRlbHRhcyA9IGxlZnQuZGVsdGFzLnNsaWNlKDApO1xufVxuXG4vKipcbiAqIGFkZCB7bGVmdH0gYW5kIHtyaWdodH0gbWF0cml4IHdlaWdodHMgaW50byB7aW50b31cbiAqL1xuZnVuY3Rpb24gYWRkKHByb2R1Y3QsIGxlZnQsIHJpZ2h0KSB7XG4gICAgZm9yIChsZXQgaSA9IDA7IGkgPCBsZWZ0LndlaWdodHMubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgcHJvZHVjdC53ZWlnaHRzW2ldID0gbGVmdC53ZWlnaHRzW2ldICsgcmlnaHQud2VpZ2h0c1tpXTtcbiAgICAgICAgcHJvZHVjdC5kZWx0YXNbaV0gPSAwO1xuICAgIH1cbn1cblxuLyoqXG4gKiBhZGRzIHtmcm9tfSBkZWx0YXMgdG8ge2xlZnR9IGFuZCB7cmlnaHR9IGRlbHRhc1xuICovXG5mdW5jdGlvbiBhZGRCKHByb2R1Y3QsIGxlZnQsIHJpZ2h0KSB7XG4gICAgZm9yIChsZXQgaSA9IDA7IGkgPCBwcm9kdWN0LmRlbHRhcy5sZW5ndGg7IGkrKykge1xuICAgICAgICBsZWZ0LmRlbHRhc1tpXSA9IHByb2R1Y3QuZGVsdGFzW2ldO1xuICAgICAgICByaWdodC5kZWx0YXNbaV0gPSBwcm9kdWN0LmRlbHRhc1tpXTtcbiAgICB9XG59XG5cbi8qKlxuICogbWFrZXMgbWF0cml4IHdlaWdodHMgYW5kIGRlbHRhcyBhbGwgb25lc1xuICovXG5mdW5jdGlvbiBhbGxPbmVzKHByb2R1Y3QpIHtcbiAgICBmb3IgKGxldCBpID0gMDsgaSA8IHByb2R1Y3Qud2VpZ2h0cy5sZW5ndGg7IGkrKykge1xuICAgICAgICBwcm9kdWN0LndlaWdodHNbaV0gPSAxO1xuICAgICAgICBwcm9kdWN0LmRlbHRhc1tpXSA9IDA7XG4gICAgfVxufVxuXG5mdW5jdGlvbiBjbG9uZU5lZ2F0aXZlKHByb2R1Y3QsIGxlZnQpIHtcbiAgICBwcm9kdWN0LnJvd3MgPSBsZWZ0LnJvd3M7XG4gICAgcHJvZHVjdC5jb2x1bW5zID0gbGVmdC5jb2x1bW5zO1xuICAgIHByb2R1Y3Qud2VpZ2h0cyA9IGxlZnQud2VpZ2h0cy5zbGljZSgwKTtcbiAgICBwcm9kdWN0LmRlbHRhcyA9IGxlZnQuZGVsdGFzLnNsaWNlKDApO1xuICAgIGZvciAobGV0IGkgPSAwOyBpIDwgbGVmdC53ZWlnaHRzLmxlbmd0aDsgaSsrKSB7XG4gICAgICAgIHByb2R1Y3Qud2VpZ2h0c1tpXSA9IC1sZWZ0LndlaWdodHNbaV07XG4gICAgICAgIHByb2R1Y3QuZGVsdGFzW2ldID0gMDtcbiAgICB9XG59XG5cbi8qKlxuICogbXVsdGlwbHkge2xlZnR9IGFuZCB7cmlnaHR9IG1hdHJpeCB3ZWlnaHRzIHRvIHtpbnRvfVxuICovXG5mdW5jdGlvbiBtdWx0aXBseShwcm9kdWN0LCBsZWZ0LCByaWdodCkge1xuICAgIGNvbnN0IGxlZnRSb3dzID0gbGVmdC5yb3dzO1xuICAgIGNvbnN0IGxlZnRDb2x1bW5zID0gbGVmdC5jb2x1bW5zO1xuICAgIGNvbnN0IHJpZ2h0Q29sdW1ucyA9IHJpZ2h0LmNvbHVtbnM7XG4gICAgLy8gbG9vcCBvdmVyIHJvd3Mgb2YgbGVmdFxuICAgIGZvciAobGV0IGxlZnRSb3cgPSAwOyBsZWZ0Um93IDwgbGVmdFJvd3M7IGxlZnRSb3crKykge1xuICAgICAgICBjb25zdCBsZWZ0Um93QmFzZSA9IGxlZnRDb2x1bW5zICogbGVmdFJvdztcbiAgICAgICAgY29uc3QgcmlnaHRSb3dCYXNlID0gcmlnaHRDb2x1bW5zICogbGVmdFJvdztcbiAgICAgICAgLy8gbG9vcCBvdmVyIGNvbHMgb2YgcmlnaHRcbiAgICAgICAgZm9yIChsZXQgcmlnaHRDb2x1bW4gPSAwOyByaWdodENvbHVtbiA8IHJpZ2h0Q29sdW1uczsgcmlnaHRDb2x1bW4rKykge1xuICAgICAgICAgICAgLy8gZG90IHByb2R1Y3QgbG9vcFxuICAgICAgICAgICAgbGV0IGRvdCA9IDA7XG4gICAgICAgICAgICAvLyBsb29wIG92ZXIgY29sdW1ucyBvZiBsZWZ0XG4gICAgICAgICAgICBmb3IgKGxldCBsZWZ0Q29sdW1uID0gMDsgbGVmdENvbHVtbiA8IGxlZnRDb2x1bW5zOyBsZWZ0Q29sdW1uKyspIHtcbiAgICAgICAgICAgICAgICBjb25zdCByaWdodENvbHVtbkJhc2UgPSByaWdodENvbHVtbnMgKiBsZWZ0Q29sdW1uO1xuICAgICAgICAgICAgICAgIGNvbnN0IGxlZnRJbmRleCA9IGxlZnRSb3dCYXNlICsgbGVmdENvbHVtbjtcbiAgICAgICAgICAgICAgICBjb25zdCByaWdodEluZGV4ID0gcmlnaHRDb2x1bW5CYXNlICsgcmlnaHRDb2x1bW47XG4gICAgICAgICAgICAgICAgZG90ICs9IGxlZnQud2VpZ2h0c1tsZWZ0SW5kZXhdICogcmlnaHQud2VpZ2h0c1tyaWdodEluZGV4XTtcbiAgICAgICAgICAgICAgICBsZWZ0LmRlbHRhc1tsZWZ0SW5kZXhdID0gMDtcbiAgICAgICAgICAgICAgICByaWdodC5kZWx0YXNbcmlnaHRJbmRleF0gPSAwO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgcHJvZHVjdC53ZWlnaHRzW3JpZ2h0Um93QmFzZSArIHJpZ2h0Q29sdW1uXSA9IGRvdDtcbiAgICAgICAgfVxuICAgIH1cbn1cblxuLyoqXG4gKiBtdWx0aXBsaWVzIHtmcm9tfSBkZWx0YXMgdG8ge2xlZnR9IGFuZCB7cmlnaHR9XG4gKi9cbmZ1bmN0aW9uIG11bHRpcGx5Qihwcm9kdWN0LCBsZWZ0LCByaWdodCkge1xuICAgIGNvbnN0IGxlZnRSb3dzID0gbGVmdC5yb3dzO1xuICAgIGNvbnN0IGxlZnRDb2x1bW5zID0gbGVmdC5jb2x1bW5zO1xuICAgIGNvbnN0IHJpZ2h0Q29sdW1ucyA9IHJpZ2h0LmNvbHVtbnM7XG4gICAgLy8gbG9vcCBvdmVyIHJvd3Mgb2YgbGVmdFxuICAgIGZvciAobGV0IGxlZnRSb3dSb290ID0gMDsgbGVmdFJvd1Jvb3QgPCBsZWZ0Um93czsgbGVmdFJvd1Jvb3QrKykge1xuICAgICAgICBjb25zdCBsZWZ0Um93QmFzZSA9IGxlZnRDb2x1bW5zICogbGVmdFJvd1Jvb3Q7XG4gICAgICAgIGNvbnN0IHJpZ2h0Um93QmFzZSA9IHJpZ2h0Q29sdW1ucyAqIGxlZnRSb3dSb290O1xuICAgICAgICAvLyBsb29wIG92ZXIgY29scyBvZiByaWdodFxuICAgICAgICBmb3IgKGxldCByaWdodENvbHVtbiA9IDA7IHJpZ2h0Q29sdW1uIDwgcmlnaHRDb2x1bW5zOyByaWdodENvbHVtbisrKSB7XG4gICAgICAgICAgICAvLyBsb29wIG92ZXIgY29sdW1ucyBvZiBsZWZ0XG4gICAgICAgICAgICBmb3IgKGxldCBsZWZ0Q29sdW1uID0gMDsgbGVmdENvbHVtbiA8IGxlZnRDb2x1bW5zOyBsZWZ0Q29sdW1uKyspIHtcbiAgICAgICAgICAgICAgICBjb25zdCByaWdodENvbHVtbkJhc2UgPSByaWdodENvbHVtbnMgKiBsZWZ0Q29sdW1uO1xuICAgICAgICAgICAgICAgIGNvbnN0IGxlZnRSb3cgPSBsZWZ0Um93QmFzZSArIGxlZnRDb2x1bW47XG4gICAgICAgICAgICAgICAgY29uc3QgcmlnaHRSb3cgPSByaWdodENvbHVtbkJhc2UgKyByaWdodENvbHVtbjtcbiAgICAgICAgICAgICAgICBjb25zdCBiYWNrUHJvcGFnYXRlVmFsdWUgPSBwcm9kdWN0LmRlbHRhc1tyaWdodFJvd0Jhc2UgKyByaWdodENvbHVtbl07XG4gICAgICAgICAgICAgICAgbGVmdC5kZWx0YXNbbGVmdFJvd10gKz0gcmlnaHQud2VpZ2h0c1tyaWdodFJvd10gKiBiYWNrUHJvcGFnYXRlVmFsdWU7XG4gICAgICAgICAgICAgICAgcmlnaHQuZGVsdGFzW3JpZ2h0Um93XSArPSBsZWZ0LndlaWdodHNbbGVmdFJvd10gKiBiYWNrUHJvcGFnYXRlVmFsdWU7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9XG59XG5cbmZ1bmN0aW9uIG11bHRpcGx5RWxlbWVudChwcm9kdWN0LCBsZWZ0LCByaWdodCkge1xuICAgIGNvbnN0IHsgd2VpZ2h0cyB9ID0gbGVmdDtcbiAgICBmb3IgKGxldCBpID0gMDsgaSA8IHdlaWdodHMubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgcHJvZHVjdC53ZWlnaHRzW2ldID0gbGVmdC53ZWlnaHRzW2ldICogcmlnaHQud2VpZ2h0c1tpXTtcbiAgICAgICAgcHJvZHVjdC5kZWx0YXNbaV0gPSAwO1xuICAgIH1cbn1cblxuLyoqXG4gKiBtdWx0aXBsaWVzIHtsZWZ0fSBhbmQge3JpZ2h0fSB3ZWlnaHQgYnkge2Zyb219IGRlbHRhcyBpbnRvIHtsZWZ0fSBhbmQge3JpZ2h0fSBkZWx0YXNcbiAqL1xuZnVuY3Rpb24gbXVsdGlwbHlFbGVtZW50Qihwcm9kdWN0LCBsZWZ0LCByaWdodCkge1xuICAgIGZvciAobGV0IGkgPSAwOyBpIDwgbGVmdC53ZWlnaHRzLmxlbmd0aDsgaSsrKSB7XG4gICAgICAgIGxlZnQuZGVsdGFzW2ldID0gcmlnaHQud2VpZ2h0c1tpXSAqIHByb2R1Y3QuZGVsdGFzW2ldO1xuICAgICAgICByaWdodC5kZWx0YXNbaV0gPSBsZWZ0LndlaWdodHNbaV0gKiBwcm9kdWN0LmRlbHRhc1tpXTtcbiAgICB9XG59XG5cbi8qKlxuICpcbiAqIHJlbHUge219IHdlaWdodHMgdG8ge2ludG99IHdlaWdodHNcbiAqL1xuZnVuY3Rpb24gcmVsdShwcm9kdWN0LCBsZWZ0KSB7XG4gICAgZm9yIChsZXQgaSA9IDA7IGkgPCBsZWZ0LndlaWdodHMubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgcHJvZHVjdC53ZWlnaHRzW2ldID0gTWF0aC5tYXgoMCwgbGVmdC53ZWlnaHRzW2ldKTsgLy8gcmVsdVxuICAgICAgICBwcm9kdWN0LmRlbHRhc1tpXSA9IDA7XG4gICAgfVxufVxuXG4vKipcbiAqIGFkZHMge2Zyb219IGRlbHRhcyB0byB7bX0gZGVsdGFzIHdoZW4ge219IHdlaWdodHMgYXJlIGFib3ZlIG90aGVyIGEgdGhyZXNob2xkIG9mIDBcbiAqL1xuZnVuY3Rpb24gcmVsdUIocHJvZHVjdCwgbGVmdCkge1xuICAgIGZvciAobGV0IGkgPSAwOyBpIDwgcHJvZHVjdC5kZWx0YXMubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgbGVmdC5kZWx0YXNbaV0gPSBsZWZ0LndlaWdodHNbaV0gPiAwID8gcHJvZHVjdC5kZWx0YXNbaV0gOiAwO1xuICAgIH1cbn1cblxuZnVuY3Rpb24gcm93UGx1Y2socHJvZHVjdCwgbGVmdCwgcm93UGx1Y2tJbmRleCkge1xuICAgIGNvbnN0IHsgY29sdW1ucyB9ID0gbGVmdDtcbiAgICBjb25zdCByb3dCYXNlID0gY29sdW1ucyAqIHJvd1BsdWNrSW5kZXg7XG4gICAgZm9yIChsZXQgY29sdW1uID0gMDsgY29sdW1uIDwgY29sdW1uczsgY29sdW1uKyspIHtcbiAgICAgICAgcHJvZHVjdC53ZWlnaHRzW2NvbHVtbl0gPSBsZWZ0LndlaWdodHNbcm93QmFzZSArIGNvbHVtbl07XG4gICAgICAgIHByb2R1Y3QuZGVsdGFzW2NvbHVtbl0gPSAwO1xuICAgIH1cbn1cblxuLyoqXG4gKiBhZGRzIHtmcm9tfSBkZWx0YXMgaW50byB7bX0gZGVsdGFzXG4gKi9cbmZ1bmN0aW9uIHJvd1BsdWNrQihwcm9kdWN0LCBsZWZ0LCByb3dJbmRleCkge1xuICAgIGNvbnN0IHsgY29sdW1ucyB9ID0gbGVmdDtcbiAgICBjb25zdCByb3dCYXNlID0gY29sdW1ucyAqIHJvd0luZGV4O1xuICAgIGZvciAobGV0IGNvbHVtbiA9IDA7IGNvbHVtbiA8IGNvbHVtbnM7IGNvbHVtbisrKSB7XG4gICAgICAgIGxlZnQuZGVsdGFzW3Jvd0Jhc2UgKyBjb2x1bW5dID0gcHJvZHVjdC5kZWx0YXNbY29sdW1uXTtcbiAgICB9XG59XG5cbmZ1bmN0aW9uIHNpZ21vaWQocHJvZHVjdCwgbGVmdCkge1xuICAgIC8vIHNpZ21vaWQgbm9ubGluZWFyaXR5XG4gICAgZm9yIChsZXQgaSA9IDA7IGkgPCBsZWZ0LndlaWdodHMubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgcHJvZHVjdC53ZWlnaHRzW2ldID0gMSAvICgxICsgTWF0aC5leHAoLWxlZnQud2VpZ2h0c1tpXSkpO1xuICAgICAgICBwcm9kdWN0LmRlbHRhc1tpXSA9IDA7XG4gICAgfVxufVxuLy8gZnVuY3Rpb24gc2lnKHgpIHtcbi8vICAgLy8gaGVscGVyIGZ1bmN0aW9uIGZvciBjb21wdXRpbmcgc2lnbW9pZFxuLy8gICByZXR1cm4gMSAvICgxICsgTWF0aC5leHAoLXgpKTtcbi8vIH1cblxuZnVuY3Rpb24gc2lnbW9pZEIocHJvZHVjdCwgbGVmdCkge1xuICAgIGZvciAobGV0IGkgPSAwOyBpIDwgcHJvZHVjdC5kZWx0YXMubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgY29uc3QgbXdpID0gcHJvZHVjdC53ZWlnaHRzW2ldO1xuICAgICAgICBsZWZ0LmRlbHRhc1tpXSA9IG13aSAqICgxIC0gbXdpKSAqIHByb2R1Y3QuZGVsdGFzW2ldO1xuICAgIH1cbn1cblxuZnVuY3Rpb24gc29mdG1heChtYXRyaXgpIHtcbiAgICAvLyBwcm9iYWJpbGl0eSB2b2x1bWVcbiAgICBjb25zdCByZXN1bHQgPSBuZXcgTWF0cml4KG1hdHJpeC5yb3dzLCBtYXRyaXguY29sdW1ucyk7XG4gICAgbGV0IG1heFZhbCA9IC05OTk5OTk7XG4gICAgZm9yIChsZXQgaSA9IDA7IGkgPCBtYXRyaXgud2VpZ2h0cy5sZW5ndGg7IGkrKykge1xuICAgICAgICBpZiAobWF0cml4LndlaWdodHNbaV0gPiBtYXhWYWwpIHtcbiAgICAgICAgICAgIG1heFZhbCA9IG1hdHJpeC53ZWlnaHRzW2ldO1xuICAgICAgICB9XG4gICAgfVxuICAgIGxldCBzID0gMDtcbiAgICBmb3IgKGxldCBpID0gMDsgaSA8IG1hdHJpeC53ZWlnaHRzLmxlbmd0aDsgaSsrKSB7XG4gICAgICAgIHJlc3VsdC53ZWlnaHRzW2ldID0gTWF0aC5leHAobWF0cml4LndlaWdodHNbaV0gLSBtYXhWYWwpO1xuICAgICAgICBzICs9IHJlc3VsdC53ZWlnaHRzW2ldO1xuICAgIH1cbiAgICBmb3IgKGxldCBpID0gMDsgaSA8IG1hdHJpeC53ZWlnaHRzLmxlbmd0aDsgaSsrKSB7XG4gICAgICAgIHJlc3VsdC53ZWlnaHRzW2ldIC89IHM7XG4gICAgfVxuICAgIC8vIG5vIGJhY2t3YXJkIHBhc3MgaGVyZSBuZWVkZWRcbiAgICAvLyBzaW5jZSB3ZSB3aWxsIHVzZSB0aGUgY29tcHV0ZWQgcHJvYmFiaWxpdGllcyBvdXRzaWRlXG4gICAgLy8gdG8gc2V0IGdyYWRpZW50cyBkaXJlY3RseSBvbiBtXG4gICAgcmV0dXJuIHJlc3VsdDtcbn1cblxuZnVuY3Rpb24gdGFuaChwcm9kdWN0LCBsZWZ0KSB7XG4gICAgLy8gdGFuaCBub25saW5lYXJpdHlcbiAgICBmb3IgKGxldCBpID0gMDsgaSA8IGxlZnQud2VpZ2h0cy5sZW5ndGg7IGkrKykge1xuICAgICAgICBwcm9kdWN0LndlaWdodHNbaV0gPSBNYXRoLnRhbmgobGVmdC53ZWlnaHRzW2ldKTtcbiAgICAgICAgcHJvZHVjdC5kZWx0YXNbaV0gPSAwO1xuICAgIH1cbn1cblxuZnVuY3Rpb24gdGFuaEIocHJvZHVjdCwgbGVmdCkge1xuICAgIGZvciAobGV0IGkgPSAwOyBpIDwgcHJvZHVjdC5kZWx0YXMubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgLy8gZ3JhZCBmb3IgeiA9IHRhbmgoeCkgaXMgKDEgLSB6XjIpXG4gICAgICAgIGNvbnN0IG13aSA9IHByb2R1Y3Qud2VpZ2h0c1tpXTtcbiAgICAgICAgbGVmdC5kZWx0YXNbaV0gPSAoMSAtIG13aSAqIG13aSkgKiBwcm9kdWN0LmRlbHRhc1tpXTtcbiAgICB9XG59XG5cbmNsYXNzIEVxdWF0aW9uIHtcbiAgICBjb25zdHJ1Y3RvcigpIHtcbiAgICAgICAgdGhpcy5zdGF0ZXMgPSBbXTtcbiAgICAgICAgdGhpcy5pbnB1dFJvdyA9IDA7XG4gICAgfVxuICAgIGFkZChsZWZ0LCByaWdodCkge1xuICAgICAgICBpZiAobGVmdC53ZWlnaHRzLmxlbmd0aCAhPT0gcmlnaHQud2VpZ2h0cy5sZW5ndGgpIHtcbiAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcignbWlzYWxpZ25lZCBtYXRyaWNlcycpO1xuICAgICAgICB9XG4gICAgICAgIGNvbnN0IHByb2R1Y3QgPSBuZXcgTWF0cml4KGxlZnQucm93cywgbGVmdC5jb2x1bW5zKTtcbiAgICAgICAgdGhpcy5zdGF0ZXMucHVzaCh7XG4gICAgICAgICAgICBuYW1lOiAnYWRkJyxcbiAgICAgICAgICAgIHByb2R1Y3QsXG4gICAgICAgICAgICBsZWZ0LFxuICAgICAgICAgICAgcmlnaHQsXG4gICAgICAgICAgICBmb3J3YXJkRm46IGFkZCxcbiAgICAgICAgICAgIGJhY2twcm9wYWdhdGlvbkZuOiBhZGRCLFxuICAgICAgICB9KTtcbiAgICAgICAgcmV0dXJuIHByb2R1Y3Q7XG4gICAgfVxuICAgIGFsbE9uZXMocm93cywgY29sdW1ucykge1xuICAgICAgICBjb25zdCBwcm9kdWN0ID0gbmV3IE1hdHJpeChyb3dzLCBjb2x1bW5zKTtcbiAgICAgICAgdGhpcy5zdGF0ZXMucHVzaCh7XG4gICAgICAgICAgICBuYW1lOiAnYWxsT25lcycsXG4gICAgICAgICAgICBwcm9kdWN0LFxuICAgICAgICAgICAgbGVmdDogcHJvZHVjdCxcbiAgICAgICAgICAgIGZvcndhcmRGbjogYWxsT25lcyxcbiAgICAgICAgICAgIGJhY2twcm9wYWdhdGlvbkZuOiAoKSA9PiB7IH0sXG4gICAgICAgIH0pO1xuICAgICAgICByZXR1cm4gcHJvZHVjdDtcbiAgICB9XG4gICAgY2xvbmVOZWdhdGl2ZShtYXRyaXgpIHtcbiAgICAgICAgY29uc3QgcHJvZHVjdCA9IG5ldyBNYXRyaXgobWF0cml4LnJvd3MsIG1hdHJpeC5jb2x1bW5zKTtcbiAgICAgICAgdGhpcy5zdGF0ZXMucHVzaCh7XG4gICAgICAgICAgICBuYW1lOiAnY2xvbmVOZWdhdGl2ZScsXG4gICAgICAgICAgICBwcm9kdWN0LFxuICAgICAgICAgICAgbGVmdDogbWF0cml4LFxuICAgICAgICAgICAgZm9yd2FyZEZuOiBjbG9uZU5lZ2F0aXZlLFxuICAgICAgICAgICAgYmFja3Byb3BhZ2F0aW9uRm46ICgpID0+IHsgfSxcbiAgICAgICAgfSk7XG4gICAgICAgIHJldHVybiBwcm9kdWN0O1xuICAgIH1cbiAgICAvKipcbiAgICAgKiBjb25uZWN0cyB0d28gbWF0cmljZXMgdG9nZXRoZXIgYnkgc3VidHJhY3RcbiAgICAgKi9cbiAgICBzdWJ0cmFjdChsZWZ0LCByaWdodCkge1xuICAgICAgICBpZiAobGVmdC53ZWlnaHRzLmxlbmd0aCAhPT0gcmlnaHQud2VpZ2h0cy5sZW5ndGgpIHtcbiAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcignbWlzYWxpZ25lZCBtYXRyaWNlcycpO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiB0aGlzLmFkZCh0aGlzLmFkZCh0aGlzLmFsbE9uZXMobGVmdC5yb3dzLCBsZWZ0LmNvbHVtbnMpLCB0aGlzLmNsb25lTmVnYXRpdmUobGVmdCkpLCByaWdodCk7XG4gICAgfVxuICAgIC8qKlxuICAgICAqIGNvbm5lY3RzIHR3byBtYXRyaWNlcyB0b2dldGhlciBieSBtdWx0aXBseVxuICAgICAqL1xuICAgIG11bHRpcGx5KGxlZnQsIHJpZ2h0KSB7XG4gICAgICAgIGlmIChsZWZ0LmNvbHVtbnMgIT09IHJpZ2h0LnJvd3MpIHtcbiAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcignbWlzYWxpZ25lZCBtYXRyaWNlcycpO1xuICAgICAgICB9XG4gICAgICAgIGNvbnN0IHByb2R1Y3QgPSBuZXcgTWF0cml4KGxlZnQucm93cywgcmlnaHQuY29sdW1ucyk7XG4gICAgICAgIHRoaXMuc3RhdGVzLnB1c2goe1xuICAgICAgICAgICAgbmFtZTogJ211bHRpcGx5JyxcbiAgICAgICAgICAgIHByb2R1Y3QsXG4gICAgICAgICAgICBsZWZ0LFxuICAgICAgICAgICAgcmlnaHQsXG4gICAgICAgICAgICBmb3J3YXJkRm46IG11bHRpcGx5LFxuICAgICAgICAgICAgYmFja3Byb3BhZ2F0aW9uRm46IG11bHRpcGx5QixcbiAgICAgICAgfSk7XG4gICAgICAgIHJldHVybiBwcm9kdWN0O1xuICAgIH1cbiAgICAvKipcbiAgICAgKiBjb25uZWN0cyB0d28gbWF0cmljZXMgdG9nZXRoZXIgYnkgbXVsdGlwbHlFbGVtZW50XG4gICAgICovXG4gICAgbXVsdGlwbHlFbGVtZW50KGxlZnQsIHJpZ2h0KSB7XG4gICAgICAgIGlmIChsZWZ0LndlaWdodHMubGVuZ3RoICE9PSByaWdodC53ZWlnaHRzLmxlbmd0aCkge1xuICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdtaXNhbGlnbmVkIG1hdHJpY2VzJyk7XG4gICAgICAgIH1cbiAgICAgICAgY29uc3QgcHJvZHVjdCA9IG5ldyBNYXRyaXgobGVmdC5yb3dzLCBsZWZ0LmNvbHVtbnMpO1xuICAgICAgICB0aGlzLnN0YXRlcy5wdXNoKHtcbiAgICAgICAgICAgIG5hbWU6ICdtdWx0aXBseUVsZW1lbnQnLFxuICAgICAgICAgICAgcHJvZHVjdCxcbiAgICAgICAgICAgIGxlZnQsXG4gICAgICAgICAgICByaWdodCxcbiAgICAgICAgICAgIGZvcndhcmRGbjogbXVsdGlwbHlFbGVtZW50LFxuICAgICAgICAgICAgYmFja3Byb3BhZ2F0aW9uRm46IG11bHRpcGx5RWxlbWVudEIsXG4gICAgICAgIH0pO1xuICAgICAgICByZXR1cm4gcHJvZHVjdDtcbiAgICB9XG4gICAgLyoqXG4gICAgICogY29ubmVjdHMgYSBtYXRyaXggdG8gcmVsdVxuICAgICAqL1xuICAgIHJlbHUobWF0cml4KSB7XG4gICAgICAgIGNvbnN0IHByb2R1Y3QgPSBuZXcgTWF0cml4KG1hdHJpeC5yb3dzLCBtYXRyaXguY29sdW1ucyk7XG4gICAgICAgIHRoaXMuc3RhdGVzLnB1c2goe1xuICAgICAgICAgICAgbmFtZTogJ3JlbHUnLFxuICAgICAgICAgICAgcHJvZHVjdCxcbiAgICAgICAgICAgIGxlZnQ6IG1hdHJpeCxcbiAgICAgICAgICAgIGZvcndhcmRGbjogcmVsdSxcbiAgICAgICAgICAgIGJhY2twcm9wYWdhdGlvbkZuOiByZWx1QixcbiAgICAgICAgfSk7XG4gICAgICAgIHJldHVybiBwcm9kdWN0O1xuICAgIH1cbiAgICAvKipcbiAgICAgKiBpbnB1dCBhIG1hdHJpeFxuICAgICAqL1xuICAgIGlucHV0KGlucHV0KSB7XG4gICAgICAgIHRoaXMuc3RhdGVzLnB1c2goe1xuICAgICAgICAgICAgbmFtZTogJ2lucHV0JyxcbiAgICAgICAgICAgIHByb2R1Y3Q6IGlucHV0LFxuICAgICAgICAgICAgZm9yd2FyZEZuOiAocHJvZHVjdCkgPT4ge1xuICAgICAgICAgICAgICAgIGlmICghdGhpcy5pbnB1dFZhbHVlKVxuICAgICAgICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICAgICAgaWYgKHRoaXMuaW5wdXRWYWx1ZS5sZW5ndGggIT09IHByb2R1Y3Qud2VpZ2h0cy5sZW5ndGgpIHtcbiAgICAgICAgICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKCd0aGlzLmlucHV0VmFsdWUgaXMgb2Ygd3JvbmcgZGltZW5zaW9ucycpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBwcm9kdWN0LndlaWdodHMgPSBpbnB1dC53ZWlnaHRzID0gdGhpcy5pbnB1dFZhbHVlO1xuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIGJhY2twcm9wYWdhdGlvbkZuOiAoKSA9PiB7IH0sXG4gICAgICAgIH0pO1xuICAgICAgICByZXR1cm4gaW5wdXQ7XG4gICAgfVxuICAgIC8qKlxuICAgICAqIGNvbm5lY3RzIGEgbWF0cml4IHZpYSBhIHJvd1xuICAgICAqL1xuICAgIGlucHV0TWF0cml4VG9Sb3cobWF0cml4KSB7XG4gICAgICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBAdHlwZXNjcmlwdC1lc2xpbnQvbm8tdGhpcy1hbGlhc1xuICAgICAgICBjb25zdCBzZWxmID0gdGhpcztcbiAgICAgICAgY29uc3QgcHJvZHVjdCA9IG5ldyBNYXRyaXgobWF0cml4LmNvbHVtbnMsIDEpO1xuICAgICAgICB0aGlzLnN0YXRlcy5wdXNoKHtcbiAgICAgICAgICAgIG5hbWU6ICdpbnB1dE1hdHJpeFRvUm93JyxcbiAgICAgICAgICAgIHByb2R1Y3QsXG4gICAgICAgICAgICBsZWZ0OiBtYXRyaXgsXG4gICAgICAgICAgICBnZXQgcmlnaHQoKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIHNlbGYuaW5wdXRSb3c7XG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgZm9yd2FyZEZuOiByb3dQbHVjayxcbiAgICAgICAgICAgIGJhY2twcm9wYWdhdGlvbkZuOiByb3dQbHVja0IsXG4gICAgICAgIH0pO1xuICAgICAgICByZXR1cm4gcHJvZHVjdDtcbiAgICB9XG4gICAgLyoqXG4gICAgICogY29ubmVjdHMgYSBtYXRyaXggdG8gc2lnbW9pZFxuICAgICAqL1xuICAgIHNpZ21vaWQobWF0cml4KSB7XG4gICAgICAgIGNvbnN0IHByb2R1Y3QgPSBuZXcgTWF0cml4KG1hdHJpeC5yb3dzLCBtYXRyaXguY29sdW1ucyk7XG4gICAgICAgIHRoaXMuc3RhdGVzLnB1c2goe1xuICAgICAgICAgICAgbmFtZTogJ3NpZ21vaWQnLFxuICAgICAgICAgICAgcHJvZHVjdCxcbiAgICAgICAgICAgIGxlZnQ6IG1hdHJpeCxcbiAgICAgICAgICAgIGZvcndhcmRGbjogc2lnbW9pZCxcbiAgICAgICAgICAgIGJhY2twcm9wYWdhdGlvbkZuOiBzaWdtb2lkQixcbiAgICAgICAgfSk7XG4gICAgICAgIHJldHVybiBwcm9kdWN0O1xuICAgIH1cbiAgICAvKipcbiAgICAgKiBjb25uZWN0cyBhIG1hdHJpeCB0byB0YW5oXG4gICAgICovXG4gICAgdGFuaChtYXRyaXgpIHtcbiAgICAgICAgY29uc3QgcHJvZHVjdCA9IG5ldyBNYXRyaXgobWF0cml4LnJvd3MsIG1hdHJpeC5jb2x1bW5zKTtcbiAgICAgICAgdGhpcy5zdGF0ZXMucHVzaCh7XG4gICAgICAgICAgICBuYW1lOiAndGFuaCcsXG4gICAgICAgICAgICBwcm9kdWN0LFxuICAgICAgICAgICAgbGVmdDogbWF0cml4LFxuICAgICAgICAgICAgZm9yd2FyZEZuOiB0YW5oLFxuICAgICAgICAgICAgYmFja3Byb3BhZ2F0aW9uRm46IHRhbmhCLFxuICAgICAgICB9KTtcbiAgICAgICAgcmV0dXJuIHByb2R1Y3Q7XG4gICAgfVxuICAgIC8qKlxuICAgICAqXG4gICAgICogT2JzZXJ2ZSBhIG1hdHJpeCBmb3IgZGVidWdnaW5nXG4gICAgICovXG4gICAgb2JzZXJ2ZShtYXRyaXgpIHtcbiAgICAgICAgdGhpcy5zdGF0ZXMucHVzaCh7XG4gICAgICAgICAgICBuYW1lOiAnb2JzZXJ2ZScsXG4gICAgICAgICAgICBwcm9kdWN0OiBuZXcgTWF0cml4KCksXG4gICAgICAgICAgICBmb3J3YXJkRm46ICgpID0+IHsgfSxcbiAgICAgICAgICAgIGJhY2twcm9wYWdhdGlvbkZuOiAoKSA9PiB7IH0sXG4gICAgICAgIH0pO1xuICAgICAgICByZXR1cm4gbWF0cml4O1xuICAgIH1cbiAgICAvKipcbiAgICAgKiBSdW4gaW5kZXggdGhyb3VnaCBlcXVhdGlvbnMgdmlhIGZvcndhcmQgcHJvcGFnYXRpb25cbiAgICAgKi9cbiAgICBydW5JbmRleChyb3dJbmRleCA9IDApIHtcbiAgICAgICAgdGhpcy5pbnB1dFJvdyA9IHJvd0luZGV4O1xuICAgICAgICBsZXQgc3RhdGUgPSB0aGlzLnN0YXRlc1swXTtcbiAgICAgICAgZm9yIChsZXQgaSA9IDAsIG1heCA9IHRoaXMuc3RhdGVzLmxlbmd0aDsgaSA8IG1heDsgaSsrKSB7XG4gICAgICAgICAgICBzdGF0ZSA9IHRoaXMuc3RhdGVzW2ldO1xuICAgICAgICAgICAgaWYgKCFzdGF0ZS5oYXNPd25Qcm9wZXJ0eSgnZm9yd2FyZEZuJykpXG4gICAgICAgICAgICAgICAgY29udGludWU7XG4gICAgICAgICAgICBzdGF0ZS5mb3J3YXJkRm4oc3RhdGUucHJvZHVjdCwgc3RhdGUubGVmdCwgc3RhdGUucmlnaHQpO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBzdGF0ZS5wcm9kdWN0O1xuICAgIH1cbiAgICAvKipcbiAgICAgKiBSdW4gdmFsdWUgdGhyb3VnaCBlcXVhdGlvbnMgdmlhIGZvcndhcmQgcHJvcGFnYXRpb25cbiAgICAgKi9cbiAgICBydW5JbnB1dChpbnB1dFZhbHVlKSB7XG4gICAgICAgIHRoaXMuaW5wdXRWYWx1ZSA9IGlucHV0VmFsdWU7XG4gICAgICAgIGxldCBzdGF0ZSA9IHRoaXMuc3RhdGVzWzBdO1xuICAgICAgICBmb3IgKGxldCBpID0gMCwgbWF4ID0gdGhpcy5zdGF0ZXMubGVuZ3RoOyBpIDwgbWF4OyBpKyspIHtcbiAgICAgICAgICAgIHN0YXRlID0gdGhpcy5zdGF0ZXNbaV07XG4gICAgICAgICAgICBpZiAoIXN0YXRlLmhhc093blByb3BlcnR5KCdmb3J3YXJkRm4nKSlcbiAgICAgICAgICAgICAgICBjb250aW51ZTtcbiAgICAgICAgICAgIHN0YXRlLmZvcndhcmRGbihzdGF0ZS5wcm9kdWN0LCBzdGF0ZS5sZWZ0LCBzdGF0ZS5yaWdodCk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHN0YXRlLnByb2R1Y3Q7XG4gICAgfVxuICAgIC8qKlxuICAgICAqIFJ1biB2YWx1ZSB0aHJvdWdoIGVxdWF0aW9ucyB2aWEgYmFjayBwcm9wYWdhdGlvblxuICAgICAqL1xuICAgIGJhY2twcm9wYWdhdGUoKSB7XG4gICAgICAgIGxldCBpID0gdGhpcy5zdGF0ZXMubGVuZ3RoO1xuICAgICAgICBsZXQgc3RhdGUgPSB0aGlzLnN0YXRlc1swXTtcbiAgICAgICAgd2hpbGUgKGktLSA+IDApIHtcbiAgICAgICAgICAgIHN0YXRlID0gdGhpcy5zdGF0ZXNbaV07XG4gICAgICAgICAgICBpZiAoIXN0YXRlLmhhc093blByb3BlcnR5KCdiYWNrcHJvcGFnYXRpb25GbicpKVxuICAgICAgICAgICAgICAgIGNvbnRpbnVlO1xuICAgICAgICAgICAgc3RhdGUuYmFja3Byb3BhZ2F0aW9uRm4oc3RhdGUucHJvZHVjdCwgc3RhdGUubGVmdCwgc3RhdGUucmlnaHQpO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBzdGF0ZS5wcm9kdWN0O1xuICAgIH1cbiAgICAvKipcbiAgICAgKiBSdW4gaW5kZXggdGhyb3VnaCBlcXVhdGlvbnMgdmlhIGJhY2sgcHJvcGFnYXRpb25cbiAgICAgKi9cbiAgICBiYWNrcHJvcGFnYXRlSW5kZXgocm93SW5kZXggPSAwKSB7XG4gICAgICAgIHRoaXMuaW5wdXRSb3cgPSByb3dJbmRleDtcbiAgICAgICAgbGV0IGkgPSB0aGlzLnN0YXRlcy5sZW5ndGg7XG4gICAgICAgIGxldCBzdGF0ZSA9IHRoaXMuc3RhdGVzWzBdO1xuICAgICAgICB3aGlsZSAoaS0tID4gMCkge1xuICAgICAgICAgICAgc3RhdGUgPSB0aGlzLnN0YXRlc1tpXTtcbiAgICAgICAgICAgIGlmICghc3RhdGUuaGFzT3duUHJvcGVydHkoJ2JhY2twcm9wYWdhdGlvbkZuJykpXG4gICAgICAgICAgICAgICAgY29udGludWU7XG4gICAgICAgICAgICBzdGF0ZS5iYWNrcHJvcGFnYXRpb25GbihzdGF0ZS5wcm9kdWN0LCBzdGF0ZS5sZWZ0LCBzdGF0ZS5yaWdodCk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHN0YXRlLnByb2R1Y3Q7XG4gICAgfVxuICAgIC8qKlxuICAgICAqIFByZWRpY3QgYSB0YXJnZXQgdmFsdWUgZnJvbSBlcXVhdGlvblxuICAgICAqL1xuICAgIHByZWRpY3RUYXJnZXQoaW5wdXQsIHRhcmdldCkge1xuICAgICAgICBsZXQgZXJyb3JTdW0gPSAwO1xuICAgICAgICBjb25zdCBvdXRwdXQgPSB0aGlzLnJ1bklucHV0KGlucHV0KTtcbiAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBvdXRwdXQud2VpZ2h0cy5sZW5ndGg7IGkrKykge1xuICAgICAgICAgICAgY29uc3QgZXJyb3IgPSBvdXRwdXQud2VpZ2h0c1tpXSAtIHRhcmdldFtpXTtcbiAgICAgICAgICAgIC8vIHNldCBncmFkaWVudHMgaW50byBsb2cgcHJvYmFiaWxpdGllc1xuICAgICAgICAgICAgZXJyb3JTdW0gKz0gTWF0aC5hYnMoZXJyb3IpO1xuICAgICAgICAgICAgLy8gd3JpdGUgZ3JhZGllbnRzIGludG8gbG9nIHByb2JhYmlsaXRpZXNcbiAgICAgICAgICAgIG91dHB1dC5kZWx0YXNbaV0gPSBlcnJvcjtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gZXJyb3JTdW07XG4gICAgfVxuICAgIC8qKlxuICAgICAqIFByZWRpY3QgYSB0YXJnZXQgaW5kZXggZnJvbSBlcXVhdGlvblxuICAgICAqL1xuICAgIHByZWRpY3RUYXJnZXRJbmRleChpbnB1dCwgdGFyZ2V0KSB7XG4gICAgICAgIGNvbnN0IG91dHB1dCA9IHRoaXMucnVuSW5kZXgoaW5wdXQpO1xuICAgICAgICAvLyBzZXQgZ3JhZGllbnRzIGludG8gbG9nIHByb2JhYmlsaXRpZXNcbiAgICAgICAgY29uc3QgbG9nUHJvYmFiaWxpdGllcyA9IG91dHB1dDsgLy8gaW50ZXJwcmV0IG91dHB1dCBhcyBsb2cgcHJvYmFiaWxpdGllc1xuICAgICAgICBjb25zdCBwcm9iYWJpbGl0aWVzID0gc29mdG1heChvdXRwdXQpOyAvLyBjb21wdXRlIHRoZSBzb2Z0bWF4IHByb2JhYmlsaXRpZXNcbiAgICAgICAgLy8gd3JpdGUgZ3JhZGllbnRzIGludG8gbG9nIHByb2JhYmlsaXRpZXNcbiAgICAgICAgbG9nUHJvYmFiaWxpdGllcy5kZWx0YXMgPSBwcm9iYWJpbGl0aWVzLndlaWdodHMuc2xpY2UoMCk7XG4gICAgICAgIGxvZ1Byb2JhYmlsaXRpZXMuZGVsdGFzW3RhcmdldF0gLT0gMTtcbiAgICAgICAgLy8gYWNjdW11bGF0ZSBiYXNlIDIgbG9nIHByb2IgYW5kIGRvIHNtb290aGluZ1xuICAgICAgICByZXR1cm4gLU1hdGgubG9nMihwcm9iYWJpbGl0aWVzLndlaWdodHNbdGFyZ2V0XSk7XG4gICAgfVxufVxuXG5mdW5jdGlvbiBtYXhJKG1hdHJpeCkge1xuICAgIC8vIGFyZ21heCBvZiBhcnJheSB3XG4gICAgY29uc3QgeyB3ZWlnaHRzIH0gPSBtYXRyaXg7XG4gICAgbGV0IG1heHYgPSB3ZWlnaHRzWzBdO1xuICAgIGxldCBtYXhpeCA9IDA7XG4gICAgZm9yIChsZXQgaSA9IDE7IGkgPCB3ZWlnaHRzLmxlbmd0aDsgaSsrKSB7XG4gICAgICAgIGNvbnN0IHYgPSB3ZWlnaHRzW2ldO1xuICAgICAgICBpZiAodiA8IG1heHYpXG4gICAgICAgICAgICBjb250aW51ZTtcbiAgICAgICAgbWF4aXggPSBpO1xuICAgICAgICBtYXh2ID0gdjtcbiAgICB9XG4gICAgcmV0dXJuIG1heGl4O1xufVxuXG5mdW5jdGlvbiBzYW1wbGVJKG1hdHJpeCkge1xuICAgIC8vIHNhbXBsZSBhcmdtYXggZnJvbSB3LCBhc3N1bWluZyB3IGFyZVxuICAgIC8vIHByb2JhYmlsaXRpZXMgdGhhdCBzdW0gdG8gb25lXG4gICAgY29uc3QgciA9IHJhbmRvbUZsb2F0KDAsIDEpO1xuICAgIGNvbnN0IHcgPSBtYXRyaXgud2VpZ2h0cztcbiAgICBsZXQgeCA9IDA7XG4gICAgbGV0IGkgPSAwO1xuICAgIHdoaWxlICh0cnVlKSB7XG4gICAgICAgIHggKz0gd1tpXTtcbiAgICAgICAgaWYgKHggPiByKSB7XG4gICAgICAgICAgICByZXR1cm4gaTtcbiAgICAgICAgfVxuICAgICAgICBpKys7XG4gICAgfVxufVxuXG5jb25zdCB0cmFpbkRlZmF1bHRzJDEgPSB7XG4gICAgaXRlcmF0aW9uczogMjAwMDAsXG4gICAgZXJyb3JUaHJlc2g6IDAuMDA1LFxuICAgIGxvZzogZmFsc2UsXG4gICAgbG9nUGVyaW9kOiAxMCxcbiAgICBsZWFybmluZ1JhdGU6IDAuMDEsXG4gICAgY2FsbGJhY2tQZXJpb2Q6IDEwLFxuICAgIHRpbWVvdXQ6IEluZmluaXR5LFxufTtcbmNvbnN0IGRlZmF1bHRzJDEgPSAoKSA9PiB7XG4gICAgcmV0dXJuIHtcbiAgICAgICAgaW5wdXRTaXplOiAyMCxcbiAgICAgICAgaW5wdXRSYW5nZTogMjAsXG4gICAgICAgIGhpZGRlbkxheWVyczogWzIwLCAyMF0sXG4gICAgICAgIG91dHB1dFNpemU6IDIwLFxuICAgICAgICBkZWNheVJhdGU6IDAuOTk5LFxuICAgICAgICBzbW9vdGhFcHM6IDFlLTgsXG4gICAgICAgIHJlZ2M6IDAuMDAwMDAxLFxuICAgICAgICBjbGlwdmFsOiA1LFxuICAgICAgICBtYXhQcmVkaWN0aW9uTGVuZ3RoOiAxMDAsXG4gICAgICAgIGRhdGFGb3JtYXR0ZXI6IG5ldyBEYXRhRm9ybWF0dGVyKCksXG4gICAgfTtcbn07XG5jbGFzcyBSTk4ge1xuICAgIGNvbnN0cnVjdG9yKG9wdGlvbnMgPSB7fSkge1xuICAgICAgICB0aGlzLm9wdGlvbnMgPSB7IC4uLmRlZmF1bHRzJDEoKSB9O1xuICAgICAgICB0aGlzLnRyYWluT3B0cyA9IHsgLi4udHJhaW5EZWZhdWx0cyQxIH07XG4gICAgICAgIHRoaXMuc3RlcENhY2hlID0ge307XG4gICAgICAgIHRoaXMucnVucyA9IDA7XG4gICAgICAgIHRoaXMucmF0aW9DbGlwcGVkID0gMDtcbiAgICAgICAgdGhpcy5tb2RlbCA9IE9iamVjdC5zZWFsKHtcbiAgICAgICAgICAgIGlzSW5pdGlhbGl6ZWQ6IGZhbHNlLFxuICAgICAgICAgICAgaW5wdXQ6IG5ldyBNYXRyaXgoMCwgMCksXG4gICAgICAgICAgICBoaWRkZW5MYXllcnM6IFtdLFxuICAgICAgICAgICAgb3V0cHV0OiBuZXcgTWF0cml4KDAsIDApLFxuICAgICAgICAgICAgZXF1YXRpb25zOiBbXSxcbiAgICAgICAgICAgIGFsbE1hdHJpY2VzOiBbXSxcbiAgICAgICAgICAgIGVxdWF0aW9uQ29ubmVjdGlvbnM6IFtdLFxuICAgICAgICAgICAgb3V0cHV0Q29ubmVjdG9yOiBuZXcgUmFuZG9tTWF0cml4KDAsIDAsIDAuMDgpLFxuICAgICAgICB9KTtcbiAgICAgICAgdGhpcy5pbml0aWFsTGF5ZXJJbnB1dHMgPSBbXTtcbiAgICAgICAgdGhpcy5vcHRpb25zID0geyAuLi50aGlzLm9wdGlvbnMsIC4uLm9wdGlvbnMgfTtcbiAgICAgICAgdGhpcy51cGRhdGVUcmFpbmluZ09wdGlvbnMoe1xuICAgICAgICAgICAgLi4udHJhaW5EZWZhdWx0cyQxLFxuICAgICAgICB9KTtcbiAgICAgICAgaWYgKG9wdGlvbnMuanNvbikge1xuICAgICAgICAgICAgdGhpcy5mcm9tSlNPTihvcHRpb25zLmpzb24pO1xuICAgICAgICB9XG4gICAgfVxuICAgIGluaXRpYWxpemUoKSB7XG4gICAgICAgIGNvbnN0IHsgZGF0YUZvcm1hdHRlciB9ID0gdGhpcy5vcHRpb25zO1xuICAgICAgICBpZiAoZGF0YUZvcm1hdHRlciA9PT0gbnVsbCB8fCBkYXRhRm9ybWF0dGVyID09PSB2b2lkIDAgPyB2b2lkIDAgOiBkYXRhRm9ybWF0dGVyLmNoYXJhY3RlcnMubGVuZ3RoKSB7XG4gICAgICAgICAgICB0aGlzLm9wdGlvbnMuaW5wdXRTaXplID0gdGhpcy5vcHRpb25zLmlucHV0UmFuZ2UgPSB0aGlzLm9wdGlvbnMub3V0cHV0U2l6ZSA9XG4gICAgICAgICAgICAgICAgZGF0YUZvcm1hdHRlci5jaGFyYWN0ZXJzLmxlbmd0aDtcbiAgICAgICAgfVxuICAgICAgICB0aGlzLm1vZGVsID0gdGhpcy5tYXBNb2RlbCgpO1xuICAgIH1cbiAgICBjcmVhdGVIaWRkZW5MYXllcnMoKSB7XG4gICAgICAgIGNvbnN0IHsgaGlkZGVuTGF5ZXJzLCBpbnB1dFNpemUgfSA9IHRoaXMub3B0aW9ucztcbiAgICAgICAgY29uc3QgaGlkZGVuTGF5ZXJzTW9kZWwgPSBbXTtcbiAgICAgICAgLy8gMCBpcyBlbmQsIHNvIGFkZCAxIHRvIG9mZnNldFxuICAgICAgICBoaWRkZW5MYXllcnNNb2RlbC5wdXNoKHRoaXMuZ2V0SGlkZGVuTGF5ZXIoaGlkZGVuTGF5ZXJzWzBdLCBpbnB1dFNpemUpKTtcbiAgICAgICAgbGV0IHByZXZTaXplID0gaGlkZGVuTGF5ZXJzWzBdO1xuICAgICAgICBmb3IgKGxldCBkID0gMTsgZCA8IGhpZGRlbkxheWVycy5sZW5ndGg7IGQrKykge1xuICAgICAgICAgICAgLy8gbG9vcCBvdmVyIGRlcHRoc1xuICAgICAgICAgICAgY29uc3QgaGlkZGVuU2l6ZSA9IGhpZGRlbkxheWVyc1tkXTtcbiAgICAgICAgICAgIGhpZGRlbkxheWVyc01vZGVsLnB1c2godGhpcy5nZXRIaWRkZW5MYXllcihoaWRkZW5TaXplLCBwcmV2U2l6ZSkpO1xuICAgICAgICAgICAgcHJldlNpemUgPSBoaWRkZW5TaXplO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBoaWRkZW5MYXllcnNNb2RlbDtcbiAgICB9XG4gICAgZ2V0SGlkZGVuTGF5ZXIoaGlkZGVuU2l6ZSwgcHJldlNpemUpIHtcbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgIC8vIHd4aFxuICAgICAgICAgICAgd2VpZ2h0OiBuZXcgUmFuZG9tTWF0cml4KGhpZGRlblNpemUsIHByZXZTaXplLCAwLjA4KSxcbiAgICAgICAgICAgIC8vIHdoaFxuICAgICAgICAgICAgdHJhbnNpdGlvbjogbmV3IFJhbmRvbU1hdHJpeChoaWRkZW5TaXplLCBoaWRkZW5TaXplLCAwLjA4KSxcbiAgICAgICAgICAgIC8vIGJoaFxuICAgICAgICAgICAgYmlhczogbmV3IE1hdHJpeChoaWRkZW5TaXplLCAxKSxcbiAgICAgICAgfTtcbiAgICB9XG4gICAgZ2V0RXF1YXRpb24oZXF1YXRpb24sIGlucHV0TWF0cml4LCBwcmV2aW91c1Jlc3VsdCwgaGlkZGVuTGF5ZXIpIHtcbiAgICAgICAgaWYgKCFoaWRkZW5MYXllci53ZWlnaHQgfHwgIWhpZGRlbkxheWVyLnRyYW5zaXRpb24gfHwgIWhpZGRlbkxheWVyLmJpYXMpIHtcbiAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcignaGlkZGVuTGF5ZXIgZG9lcyBub3QgaGF2ZSBleHBlY3RlZCBwcm9wZXJ0aWVzJyk7XG4gICAgICAgIH1cbiAgICAgICAgY29uc3QgcmVsdSA9IGVxdWF0aW9uLnJlbHUuYmluZChlcXVhdGlvbik7XG4gICAgICAgIGNvbnN0IGFkZCA9IGVxdWF0aW9uLmFkZC5iaW5kKGVxdWF0aW9uKTtcbiAgICAgICAgY29uc3QgbXVsdGlwbHkgPSBlcXVhdGlvbi5tdWx0aXBseS5iaW5kKGVxdWF0aW9uKTtcbiAgICAgICAgcmV0dXJuIHJlbHUoYWRkKGFkZChtdWx0aXBseShoaWRkZW5MYXllci53ZWlnaHQsIGlucHV0TWF0cml4KSwgbXVsdGlwbHkoaGlkZGVuTGF5ZXIudHJhbnNpdGlvbiwgcHJldmlvdXNSZXN1bHQpKSwgaGlkZGVuTGF5ZXIuYmlhcykpO1xuICAgIH1cbiAgICBjcmVhdGVJbnB1dE1hdHJpeCgpIHtcbiAgICAgICAgY29uc3QgeyBpbnB1dFJhbmdlLCBpbnB1dFNpemUgfSA9IHRoaXMub3B0aW9ucztcbiAgICAgICAgaWYgKGlucHV0UmFuZ2UgPCAxKVxuICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKCd0aGlzLm9wdGlvbnMuaW5wdXRSYW5nZSBub3QgYW4gZXhwZWN0ZWQgbnVtYmVyJyk7XG4gICAgICAgIGlmIChpbnB1dFNpemUgPCAxKVxuICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKCd0aGlzLm9wdGlvbnMuaW5wdXRTaXplIG5vdCBhbiBleHBlY3RlZCBudW1iZXInKTtcbiAgICAgICAgLy8gMCBpcyBlbmQsIHNvIGFkZCAxIHRvIG9mZnNldFxuICAgICAgICByZXR1cm4gbmV3IFJhbmRvbU1hdHJpeChpbnB1dFJhbmdlICsgMSwgaW5wdXRTaXplLCAwLjA4KTtcbiAgICB9XG4gICAgY3JlYXRlT3V0cHV0TWF0cmljZXMoKSB7XG4gICAgICAgIGNvbnN0IHsgb3V0cHV0U2l6ZSwgaGlkZGVuTGF5ZXJzIH0gPSB0aGlzLm9wdGlvbnM7XG4gICAgICAgIGNvbnN0IGxhc3RIaWRkZW5TaXplID0gbGFzdChoaWRkZW5MYXllcnMpO1xuICAgICAgICAvLyAwIGlzIGVuZCwgc28gYWRkIDEgdG8gb2Zmc2V0XG4gICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICAvLyB3aGRcbiAgICAgICAgICAgIG91dHB1dENvbm5lY3RvcjogbmV3IFJhbmRvbU1hdHJpeChvdXRwdXRTaXplICsgMSwgbGFzdEhpZGRlblNpemUsIDAuMDgpLFxuICAgICAgICAgICAgLy8gMCBpcyBlbmQsIHNvIGFkZCAxIHRvIG9mZnNldFxuICAgICAgICAgICAgLy8gYmRcbiAgICAgICAgICAgIG91dHB1dDogbmV3IE1hdHJpeChvdXRwdXRTaXplICsgMSwgMSksXG4gICAgICAgIH07XG4gICAgfVxuICAgIGJpbmRFcXVhdGlvbigpIHtcbiAgICAgICAgY29uc3QgeyBtb2RlbCB9ID0gdGhpcztcbiAgICAgICAgY29uc3QgeyBoaWRkZW5MYXllcnMgfSA9IHRoaXMub3B0aW9ucztcbiAgICAgICAgY29uc3QgZXF1YXRpb24gPSBuZXcgRXF1YXRpb24oKTtcbiAgICAgICAgY29uc3Qgb3V0cHV0cyA9IFtdO1xuICAgICAgICBjb25zdCBlcXVhdGlvbkNvbm5lY3Rpb24gPSBtb2RlbC5lcXVhdGlvbkNvbm5lY3Rpb25zLmxlbmd0aCA+IDBcbiAgICAgICAgICAgID8gbGFzdChtb2RlbC5lcXVhdGlvbkNvbm5lY3Rpb25zKVxuICAgICAgICAgICAgOiB0aGlzLmluaXRpYWxMYXllcklucHV0cztcbiAgICAgICAgLy8gMCBpbmRleFxuICAgICAgICBsZXQgb3V0cHV0ID0gdGhpcy5nZXRFcXVhdGlvbihlcXVhdGlvbiwgZXF1YXRpb24uaW5wdXRNYXRyaXhUb1Jvdyhtb2RlbC5pbnB1dCksIGVxdWF0aW9uQ29ubmVjdGlvblswXSwgbW9kZWwuaGlkZGVuTGF5ZXJzWzBdKTtcbiAgICAgICAgb3V0cHV0cy5wdXNoKG91dHB1dCk7XG4gICAgICAgIC8vIDErIGluZGljZXNcbiAgICAgICAgZm9yIChsZXQgaSA9IDEsIG1heCA9IGhpZGRlbkxheWVycy5sZW5ndGg7IGkgPCBtYXg7IGkrKykge1xuICAgICAgICAgICAgaWYgKCFlcXVhdGlvbkNvbm5lY3Rpb25baV0pIHtcbiAgICAgICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoYENhbm5vdCBmaW5kIGVxdWF0aW9uIGF0IGluZGV4ICR7aX1gKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIG91dHB1dCA9IHRoaXMuZ2V0RXF1YXRpb24oZXF1YXRpb24sIG91dHB1dCwgZXF1YXRpb25Db25uZWN0aW9uW2ldLCBtb2RlbC5oaWRkZW5MYXllcnNbaV0pO1xuICAgICAgICAgICAgb3V0cHV0cy5wdXNoKG91dHB1dCk7XG4gICAgICAgIH1cbiAgICAgICAgbW9kZWwuZXF1YXRpb25Db25uZWN0aW9ucy5wdXNoKG91dHB1dHMpO1xuICAgICAgICBlcXVhdGlvbi5hZGQoZXF1YXRpb24ubXVsdGlwbHkobW9kZWwub3V0cHV0Q29ubmVjdG9yLCBvdXRwdXQpLCBtb2RlbC5vdXRwdXQpO1xuICAgICAgICBtb2RlbC5lcXVhdGlvbnMucHVzaChlcXVhdGlvbik7XG4gICAgfVxuICAgIG1hcE1vZGVsKCkge1xuICAgICAgICBjb25zdCBhbGxNYXRyaWNlcyA9IFtdO1xuICAgICAgICB0aGlzLmluaXRpYWxMYXllcklucHV0cyA9IHRoaXMub3B0aW9ucy5oaWRkZW5MYXllcnMubWFwKChzaXplKSA9PiBuZXcgTWF0cml4KHNpemUsIDEpKTtcbiAgICAgICAgY29uc3QgaW5wdXQgPSB0aGlzLmNyZWF0ZUlucHV0TWF0cml4KCk7XG4gICAgICAgIGFsbE1hdHJpY2VzLnB1c2goaW5wdXQpO1xuICAgICAgICBjb25zdCBoaWRkZW5MYXllcnMgPSB0aGlzLmNyZWF0ZUhpZGRlbkxheWVycygpO1xuICAgICAgICBpZiAoIWhpZGRlbkxheWVycy5sZW5ndGgpXG4gICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ25ldC5oaWRkZW5MYXllcnMgbm90IHNldCcpO1xuICAgICAgICBmb3IgKGxldCBpID0gMCwgbWF4ID0gaGlkZGVuTGF5ZXJzLmxlbmd0aDsgaSA8IG1heDsgaSsrKSB7XG4gICAgICAgICAgICBjb25zdCBoaWRkZW5NYXRyaXggPSBoaWRkZW5MYXllcnNbaV07XG4gICAgICAgICAgICBmb3IgKGNvbnN0IHByb3BlcnR5IGluIGhpZGRlbk1hdHJpeCkge1xuICAgICAgICAgICAgICAgIGlmICghaGlkZGVuTWF0cml4Lmhhc093blByb3BlcnR5KHByb3BlcnR5KSlcbiAgICAgICAgICAgICAgICAgICAgY29udGludWU7XG4gICAgICAgICAgICAgICAgYWxsTWF0cmljZXMucHVzaChoaWRkZW5NYXRyaXhbcHJvcGVydHldKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBjb25zdCB7IG91dHB1dCwgb3V0cHV0Q29ubmVjdG9yIH0gPSB0aGlzLmNyZWF0ZU91dHB1dE1hdHJpY2VzKCk7XG4gICAgICAgIGFsbE1hdHJpY2VzLnB1c2gob3V0cHV0Q29ubmVjdG9yKTtcbiAgICAgICAgYWxsTWF0cmljZXMucHVzaChvdXRwdXQpO1xuICAgICAgICByZXR1cm4gT2JqZWN0LnNlYWwoe1xuICAgICAgICAgICAgaXNJbml0aWFsaXplZDogdHJ1ZSxcbiAgICAgICAgICAgIGlucHV0LFxuICAgICAgICAgICAgaGlkZGVuTGF5ZXJzLFxuICAgICAgICAgICAgb3V0cHV0LFxuICAgICAgICAgICAgZXF1YXRpb25zOiBbXSxcbiAgICAgICAgICAgIGFsbE1hdHJpY2VzLFxuICAgICAgICAgICAgZXF1YXRpb25Db25uZWN0aW9uczogW10sXG4gICAgICAgICAgICBvdXRwdXRDb25uZWN0b3IsXG4gICAgICAgIH0pO1xuICAgIH1cbiAgICB0cmFpbklucHV0KGlucHV0KSB7XG4gICAgICAgIHRoaXMucnVucysrO1xuICAgICAgICBjb25zdCB7IG1vZGVsIH0gPSB0aGlzO1xuICAgICAgICBjb25zdCBtYXggPSBpbnB1dC5sZW5ndGg7XG4gICAgICAgIGxldCBsb2cycHBsID0gMDtcbiAgICAgICAgbGV0IGVxdWF0aW9uO1xuICAgICAgICB3aGlsZSAobW9kZWwuZXF1YXRpb25zLmxlbmd0aCA8PSBpbnB1dC5sZW5ndGggKyAxKSB7XG4gICAgICAgICAgICAvLyBsYXN0IGlzIHplcm9cbiAgICAgICAgICAgIHRoaXMuYmluZEVxdWF0aW9uKCk7XG4gICAgICAgIH1cbiAgICAgICAgZm9yIChsZXQgaW5wdXRJbmRleCA9IC0xLCBpbnB1dE1heCA9IGlucHV0Lmxlbmd0aDsgaW5wdXRJbmRleCA8IGlucHV0TWF4OyBpbnB1dEluZGV4KyspIHtcbiAgICAgICAgICAgIC8vIHN0YXJ0IGFuZCBlbmQgdG9rZW5zIGFyZSB6ZXJvc1xuICAgICAgICAgICAgY29uc3QgZXF1YXRpb25JbmRleCA9IGlucHV0SW5kZXggKyAxO1xuICAgICAgICAgICAgZXF1YXRpb24gPSBtb2RlbC5lcXVhdGlvbnNbZXF1YXRpb25JbmRleF07XG4gICAgICAgICAgICBjb25zdCBzb3VyY2UgPSBpbnB1dEluZGV4ID09PSAtMSA/IDAgOiBpbnB1dFtpbnB1dEluZGV4XSArIDE7IC8vIGZpcnN0IHN0ZXA6IHN0YXJ0IHdpdGggU1RBUlQgdG9rZW5cbiAgICAgICAgICAgIGNvbnN0IHRhcmdldCA9IGlucHV0SW5kZXggPT09IG1heCAtIDEgPyAwIDogaW5wdXRbaW5wdXRJbmRleCArIDFdICsgMTsgLy8gbGFzdCBzdGVwOiBlbmQgd2l0aCBFTkQgdG9rZW5cbiAgICAgICAgICAgIGxvZzJwcGwgKz0gZXF1YXRpb24ucHJlZGljdFRhcmdldEluZGV4KHNvdXJjZSwgdGFyZ2V0KTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gTWF0aC5wb3coMiwgbG9nMnBwbCAvIChtYXggLSAxKSkgLyAxMDA7XG4gICAgfVxuICAgIGJhY2twcm9wYWdhdGUoaW5wdXQpIHtcbiAgICAgICAgbGV0IGkgPSBpbnB1dC5sZW5ndGg7XG4gICAgICAgIGNvbnN0IHsgbW9kZWwgfSA9IHRoaXM7XG4gICAgICAgIGNvbnN0IHsgZXF1YXRpb25zIH0gPSBtb2RlbDtcbiAgICAgICAgd2hpbGUgKGkgPiAwKSB7XG4gICAgICAgICAgICBlcXVhdGlvbnNbaV0uYmFja3Byb3BhZ2F0ZUluZGV4KGlucHV0W2kgLSAxXSArIDEpO1xuICAgICAgICAgICAgaS0tO1xuICAgICAgICB9XG4gICAgICAgIGVxdWF0aW9uc1swXS5iYWNrcHJvcGFnYXRlSW5kZXgoMCk7XG4gICAgfVxuICAgIGFkanVzdFdlaWdodHMoKSB7XG4gICAgICAgIGNvbnN0IHsgcmVnYywgY2xpcHZhbCwgZGVjYXlSYXRlLCBzbW9vdGhFcHMgfSA9IHRoaXMub3B0aW9ucztcbiAgICAgICAgY29uc3QgeyB0cmFpbk9wdHMsIG1vZGVsLCBzdGVwQ2FjaGUgfSA9IHRoaXM7XG4gICAgICAgIGNvbnN0IHsgbGVhcm5pbmdSYXRlIH0gPSB0cmFpbk9wdHM7XG4gICAgICAgIGNvbnN0IHsgYWxsTWF0cmljZXMgfSA9IG1vZGVsO1xuICAgICAgICBsZXQgbnVtQ2xpcHBlZCA9IDA7XG4gICAgICAgIGxldCBudW1Ub3QgPSAwO1xuICAgICAgICBmb3IgKGxldCBtYXRyaXhJbmRleCA9IDA7IG1hdHJpeEluZGV4IDwgYWxsTWF0cmljZXMubGVuZ3RoOyBtYXRyaXhJbmRleCsrKSB7XG4gICAgICAgICAgICBjb25zdCBtYXRyaXggPSBhbGxNYXRyaWNlc1ttYXRyaXhJbmRleF07XG4gICAgICAgICAgICBjb25zdCB7IHdlaWdodHMsIGRlbHRhcyB9ID0gbWF0cml4O1xuICAgICAgICAgICAgaWYgKCEobWF0cml4SW5kZXggaW4gc3RlcENhY2hlKSkge1xuICAgICAgICAgICAgICAgIHN0ZXBDYWNoZVttYXRyaXhJbmRleF0gPSB6ZXJvcyQxKG1hdHJpeC5yb3dzICogbWF0cml4LmNvbHVtbnMpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgY29uc3QgY2FjaGUgPSBzdGVwQ2FjaGVbbWF0cml4SW5kZXhdO1xuICAgICAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCB3ZWlnaHRzLmxlbmd0aDsgaSsrKSB7XG4gICAgICAgICAgICAgICAgbGV0IHIgPSBkZWx0YXNbaV07XG4gICAgICAgICAgICAgICAgY29uc3QgdyA9IHdlaWdodHNbaV07XG4gICAgICAgICAgICAgICAgLy8gcm1zcHJvcCBhZGFwdGl2ZSBsZWFybmluZyByYXRlXG4gICAgICAgICAgICAgICAgY2FjaGVbaV0gPSBjYWNoZVtpXSAqIGRlY2F5UmF0ZSArICgxIC0gZGVjYXlSYXRlKSAqIHIgKiByO1xuICAgICAgICAgICAgICAgIC8vIGdyYWRpZW50IGNsaXBcbiAgICAgICAgICAgICAgICBpZiAociA+IGNsaXB2YWwpIHtcbiAgICAgICAgICAgICAgICAgICAgciA9IGNsaXB2YWw7XG4gICAgICAgICAgICAgICAgICAgIG51bUNsaXBwZWQrKztcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgZWxzZSBpZiAociA8IC1jbGlwdmFsKSB7XG4gICAgICAgICAgICAgICAgICAgIHIgPSAtY2xpcHZhbDtcbiAgICAgICAgICAgICAgICAgICAgbnVtQ2xpcHBlZCsrO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBudW1Ub3QrKztcbiAgICAgICAgICAgICAgICAvLyB1cGRhdGUgKGFuZCByZWd1bGFyaXplKVxuICAgICAgICAgICAgICAgIHdlaWdodHNbaV0gPVxuICAgICAgICAgICAgICAgICAgICB3ICsgKC1sZWFybmluZ1JhdGUgKiByKSAvIE1hdGguc3FydChjYWNoZVtpXSArIHNtb290aEVwcykgLSByZWdjICogdztcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICB0aGlzLnJhdGlvQ2xpcHBlZCA9IG51bUNsaXBwZWQgLyBudW1Ub3Q7XG4gICAgfVxuICAgIGdldCBpc1J1bm5hYmxlKCkge1xuICAgICAgICBpZiAodGhpcy5tb2RlbCAmJiB0aGlzLm1vZGVsLmVxdWF0aW9ucy5sZW5ndGggPT09IDApIHtcbiAgICAgICAgICAgIGNvbnNvbGUuZXJyb3IoYE5vIGVxdWF0aW9ucyBib3VuZCwgZGlkIHlvdSBydW4gdHJhaW4oKT9gKTtcbiAgICAgICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICB9XG4gICAgY2hlY2tSdW5uYWJsZSgpIHtcbiAgICAgICAgaWYgKCF0aGlzLmlzUnVubmFibGUpIHtcbiAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcignTmV0d29yayBub3QgcnVubmFibGUnKTtcbiAgICAgICAgfVxuICAgIH1cbiAgICBydW4ocmF3SW5wdXQgPSBbXSwgaXNTYW1wbGVJID0gZmFsc2UsIHRlbXBlcmF0dXJlID0gMSkge1xuICAgICAgICBjb25zdCBtYXhQcmVkaWN0aW9uTGVuZ3RoID0gdGhpcy5vcHRpb25zLm1heFByZWRpY3Rpb25MZW5ndGggK1xuICAgICAgICAgICAgKHJhd0lucHV0ICE9PSBudWxsID8gcmF3SW5wdXQubGVuZ3RoIDogMCkgK1xuICAgICAgICAgICAgKHRoaXMub3B0aW9ucy5kYXRhRm9ybWF0dGVyXG4gICAgICAgICAgICAgICAgPyB0aGlzLm9wdGlvbnMuZGF0YUZvcm1hdHRlci5zcGVjaWFsSW5kZXhlcy5sZW5ndGhcbiAgICAgICAgICAgICAgICA6IDApO1xuICAgICAgICB0aGlzLmNoZWNrUnVubmFibGUoKTtcbiAgICAgICAgY29uc3QgaW5wdXQgPSB0aGlzLm9wdGlvbnMuZGF0YUZvcm1hdHRlciAmJiByYXdJbnB1dC5sZW5ndGggPiAwXG4gICAgICAgICAgICA/IHRoaXMub3B0aW9ucy5kYXRhRm9ybWF0dGVyLmZvcm1hdERhdGFJbihyYXdJbnB1dClcbiAgICAgICAgICAgIDogcmF3SW5wdXQ7XG4gICAgICAgIGNvbnN0IHsgbW9kZWwgfSA9IHRoaXM7XG4gICAgICAgIGNvbnN0IG91dHB1dCA9IFtdO1xuICAgICAgICBsZXQgaSA9IDA7XG4gICAgICAgIHdoaWxlICh0cnVlKSB7XG4gICAgICAgICAgICBjb25zdCBwcmV2aW91c0luZGV4ID0gaSA9PT0gMCA/IDAgOiBpIDwgaW5wdXQubGVuZ3RoID8gaW5wdXRbaSAtIDFdICsgMSA6IG91dHB1dFtpIC0gMV07XG4gICAgICAgICAgICB3aGlsZSAobW9kZWwuZXF1YXRpb25zLmxlbmd0aCA8PSBpKSB7XG4gICAgICAgICAgICAgICAgdGhpcy5iaW5kRXF1YXRpb24oKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGNvbnN0IGVxdWF0aW9uID0gbW9kZWwuZXF1YXRpb25zW2ldO1xuICAgICAgICAgICAgLy8gc2FtcGxlIHByZWRpY3RlZCBsZXR0ZXJcbiAgICAgICAgICAgIGNvbnN0IG91dHB1dE1hdHJpeCA9IGVxdWF0aW9uLnJ1bkluZGV4KHByZXZpb3VzSW5kZXgpO1xuICAgICAgICAgICAgY29uc3QgbG9nUHJvYmFiaWxpdGllcyA9IG5ldyBNYXRyaXgobW9kZWwub3V0cHV0LnJvd3MsIG1vZGVsLm91dHB1dC5jb2x1bW5zKTtcbiAgICAgICAgICAgIGNvcHkobG9nUHJvYmFiaWxpdGllcywgb3V0cHV0TWF0cml4KTtcbiAgICAgICAgICAgIGlmICh0ZW1wZXJhdHVyZSAhPT0gMSAmJiBpc1NhbXBsZUkpIHtcbiAgICAgICAgICAgICAgICAvKipcbiAgICAgICAgICAgICAgICAgKiBzY2FsZSBsb2cgcHJvYmFiaWxpdGllcyBieSB0ZW1wZXJhdHVyZSBhbmQgcmUtbm9ybWFsaXplXG4gICAgICAgICAgICAgICAgICogaWYgdGVtcGVyYXR1cmUgaXMgaGlnaCwgbG9nUHJvYmFiaWxpdGllcyB3aWxsIGdvIHRvd2FyZHMgemVyb1xuICAgICAgICAgICAgICAgICAqIGFuZCB0aGUgc29mdG1heCBvdXRwdXRzIHdpbGwgYmUgbW9yZSBkaWZmdXNlLiBpZiB0ZW1wZXJhdHVyZSBpc1xuICAgICAgICAgICAgICAgICAqIHZlcnkgbG93LCB0aGUgc29mdG1heCBvdXRwdXRzIHdpbGwgYmUgbW9yZSBwZWFreVxuICAgICAgICAgICAgICAgICAqL1xuICAgICAgICAgICAgICAgIGZvciAobGV0IGogPSAwLCBtYXggPSBsb2dQcm9iYWJpbGl0aWVzLndlaWdodHMubGVuZ3RoOyBqIDwgbWF4OyBqKyspIHtcbiAgICAgICAgICAgICAgICAgICAgbG9nUHJvYmFiaWxpdGllcy53ZWlnaHRzW2pdIC89IHRlbXBlcmF0dXJlO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGNvbnN0IHByb2JzID0gc29mdG1heChsb2dQcm9iYWJpbGl0aWVzKTtcbiAgICAgICAgICAgIGNvbnN0IG5leHRJbmRleCA9IGlzU2FtcGxlSSA/IHNhbXBsZUkocHJvYnMpIDogbWF4SShwcm9icyk7XG4gICAgICAgICAgICBpKys7XG4gICAgICAgICAgICBpZiAobmV4dEluZGV4ID09PSAwKSB7XG4gICAgICAgICAgICAgICAgLy8gRU5EIHRva2VuIHByZWRpY3RlZCwgYnJlYWsgb3V0XG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBpZiAoaSA+PSBtYXhQcmVkaWN0aW9uTGVuZ3RoKSB7XG4gICAgICAgICAgICAgICAgLy8gc29tZXRoaW5nIGlzIHdyb25nXG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBvdXRwdXQucHVzaChuZXh0SW5kZXgpO1xuICAgICAgICB9XG4gICAgICAgIC8qKlxuICAgICAgICAgKiB3ZSBzbGljZSB0aGUgaW5wdXQgbGVuZ3RoIGhlcmUsIG5vdCBiZWNhdXNlIG91dHB1dCBjb250YWlucyBpdCwgYnV0IGl0IHdpbGwgYmUgZXJyb25lb3VzIGFzIHdlIGFyZSBzZW5kaW5nIHRoZVxuICAgICAgICAgKiBuZXR3b3JrIHdoYXQgaXMgY29udGFpbmVkIGluIGlucHV0LCBzbyB0aGUgZGF0YSBpcyBlc3NlbnRpYWxseSBndWVzc2VkIGJ5IHRoZSBuZXR3b3JrIHdoYXQgY291bGQgYmUgbmV4dCwgdGlsbCBpdFxuICAgICAgICAgKiBsb2NrcyBpbiBvbiBhIHZhbHVlLlxuICAgICAgICAgKiBLaW5kIG9mIGxpa2UgdGhpcywgdmFsdWVzIGFyZSBmcm9tIGlucHV0OlxuICAgICAgICAgKiAwIC0+IDQgKG9yIGluIEVuZ2xpc2g6IFwiYmVnaW5uaW5nIG9uIGlucHV0XCIgLT4gXCJJIGhhdmUgbm8gaWRlYT8gSSdsbCBndWVzcyB3aGF0IHRoZXkgd2FudCBuZXh0IVwiKVxuICAgICAgICAgKiAyIC0+IDIgKG9oIGhvdyBpbnRlcmVzdGluZywgSSd2ZSBuYXJyb3dlZCBkb3duIHZhbHVlcy4uLilcbiAgICAgICAgICogMSAtPiA5IChvaCBob3cgaW50ZXJlc3RpbmcsIEkndmUgbm93IGtub3cgd2hhdCB0aGUgdmFsdWVzIGFyZS4uLilcbiAgICAgICAgICogdGhlbiB0aGUgb3V0cHV0IGxvb2tzIGxpa2U6IFs0LCAyLCA5LC4uLl1cbiAgICAgICAgICogc28gd2UgdGhlbiByZW1vdmUgdGhlIGVycm9uZW91cyBkYXRhIHRvIGdldCBvdXIgdHJ1ZSBvdXRwdXRcbiAgICAgICAgICovXG4gICAgICAgIHJldHVybiB0aGlzLm9wdGlvbnMuZGF0YUZvcm1hdHRlci5mb3JtYXREYXRhT3V0KGlucHV0LCBvdXRwdXQuc2xpY2UoaW5wdXQubGVuZ3RoKS5tYXAoKHZhbHVlKSA9PiB2YWx1ZSAtIDEpKTtcbiAgICB9XG4gICAgLyoqXG4gICAgICpcbiAgICAgKiBWZXJpZmllcyBuZXR3b3JrIHNpemVzIGFyZSBpbml0aWFsaXplZFxuICAgICAqIElmIHRoZXkgYXJlIG5vdCBpdCB3aWxsIGluaXRpYWxpemUgdGhlbVxuICAgICAqL1xuICAgIHZlcmlmeUlzSW5pdGlhbGl6ZWQoKSB7XG4gICAgICAgIGlmICghdGhpcy5tb2RlbC5pc0luaXRpYWxpemVkKSB7XG4gICAgICAgICAgICB0aGlzLmluaXRpYWxpemUoKTtcbiAgICAgICAgfVxuICAgIH1cbiAgICAvKipcbiAgICAgKlxuICAgICAqIEBwYXJhbSBvcHRpb25zXG4gICAgICogICAgU3VwcG9ydHMgYWxsIGB0cmFpbkRlZmF1bHRzYCBwcm9wZXJ0aWVzXG4gICAgICogICAgYWxzbyBzdXBwb3J0czpcbiAgICAgKiAgICAgICBsZWFybmluZ1JhdGU6IChudW1iZXIpLFxuICAgICAqICAgICAgIG1vbWVudHVtOiAobnVtYmVyKSxcbiAgICAgKiAgICAgICBhY3RpdmF0aW9uOiAnc2lnbW9pZCcsICdyZWx1JywgJ2xlYWt5LXJlbHUnLCAndGFuaCdcbiAgICAgKi9cbiAgICB1cGRhdGVUcmFpbmluZ09wdGlvbnMob3B0aW9ucykge1xuICAgICAgICB2YXIgX2E7XG4gICAgICAgIHRoaXMudHJhaW5PcHRzID0geyAuLi50cmFpbkRlZmF1bHRzJDEsIC4uLm9wdGlvbnMgfTtcbiAgICAgICAgdGhpcy52YWxpZGF0ZVRyYWluaW5nT3B0aW9ucyh0aGlzLnRyYWluT3B0cyk7XG4gICAgICAgIHRoaXMuc2V0TG9nTWV0aG9kKChfYSA9IG9wdGlvbnMubG9nKSAhPT0gbnVsbCAmJiBfYSAhPT0gdm9pZCAwID8gX2EgOiB0aGlzLnRyYWluT3B0cy5sb2cpO1xuICAgICAgICAvLyBUT0RPOiBSZW1vdmUgdGhpcz9cbiAgICAgICAgLy8gdGhpcy5hY3RpdmF0aW9uID0gb3B0aW9ucy5hY3RpdmF0aW9uIHx8IHRoaXMuYWN0aXZhdGlvbjtcbiAgICB9XG4gICAgdmFsaWRhdGVUcmFpbmluZ09wdGlvbnMob3B0aW9ucykge1xuICAgICAgICBjb25zdCB2YWxpZGF0aW9ucyA9IHtcbiAgICAgICAgICAgIGl0ZXJhdGlvbnM6ICgpID0+IHtcbiAgICAgICAgICAgICAgICBjb25zdCB2YWwgPSBvcHRpb25zLml0ZXJhdGlvbnM7XG4gICAgICAgICAgICAgICAgcmV0dXJuIHR5cGVvZiB2YWwgPT09ICdudW1iZXInICYmIHZhbCA+IDA7XG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgZXJyb3JUaHJlc2g6ICgpID0+IHtcbiAgICAgICAgICAgICAgICBjb25zdCB2YWwgPSBvcHRpb25zLmVycm9yVGhyZXNoO1xuICAgICAgICAgICAgICAgIHJldHVybiB0eXBlb2YgdmFsID09PSAnbnVtYmVyJyAmJiB2YWwgPiAwICYmIHZhbCA8IDE7XG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgbG9nOiAoKSA9PiB7XG4gICAgICAgICAgICAgICAgY29uc3QgdmFsID0gb3B0aW9ucy5sb2c7XG4gICAgICAgICAgICAgICAgcmV0dXJuIHR5cGVvZiB2YWwgPT09ICdmdW5jdGlvbicgfHwgdHlwZW9mIHZhbCA9PT0gJ2Jvb2xlYW4nO1xuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIGxvZ1BlcmlvZDogKCkgPT4ge1xuICAgICAgICAgICAgICAgIGNvbnN0IHZhbCA9IG9wdGlvbnMubG9nUGVyaW9kO1xuICAgICAgICAgICAgICAgIHJldHVybiB0eXBlb2YgdmFsID09PSAnbnVtYmVyJyAmJiB2YWwgPiAwO1xuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIGxlYXJuaW5nUmF0ZTogKCkgPT4ge1xuICAgICAgICAgICAgICAgIGNvbnN0IHZhbCA9IG9wdGlvbnMubGVhcm5pbmdSYXRlO1xuICAgICAgICAgICAgICAgIHJldHVybiB0eXBlb2YgdmFsID09PSAnbnVtYmVyJyAmJiB2YWwgPiAwICYmIHZhbCA8IDE7XG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgY2FsbGJhY2s6ICgpID0+IHtcbiAgICAgICAgICAgICAgICBjb25zdCB2YWwgPSBvcHRpb25zLmNhbGxiYWNrO1xuICAgICAgICAgICAgICAgIHJldHVybiB0eXBlb2YgdmFsID09PSAnZnVuY3Rpb24nIHx8IHZhbCA9PT0gdW5kZWZpbmVkO1xuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIGNhbGxiYWNrUGVyaW9kOiAoKSA9PiB7XG4gICAgICAgICAgICAgICAgY29uc3QgdmFsID0gb3B0aW9ucy5jYWxsYmFja1BlcmlvZDtcbiAgICAgICAgICAgICAgICByZXR1cm4gdHlwZW9mIHZhbCA9PT0gJ251bWJlcicgJiYgdmFsID4gMDtcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICB0aW1lb3V0OiAoKSA9PiB7XG4gICAgICAgICAgICAgICAgY29uc3QgdmFsID0gb3B0aW9ucy50aW1lb3V0O1xuICAgICAgICAgICAgICAgIHJldHVybiB0eXBlb2YgdmFsID09PSAnbnVtYmVyJyAmJiB2YWwgPiAwO1xuICAgICAgICAgICAgfSxcbiAgICAgICAgfTtcbiAgICAgICAgZm9yIChjb25zdCBwIGluIHZhbGlkYXRpb25zKSB7XG4gICAgICAgICAgICBjb25zdCB2ID0gb3B0aW9ucztcbiAgICAgICAgICAgIGlmICghdmFsaWRhdGlvbnNbcF0oKSkge1xuICAgICAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcihgWyR7cH0sICR7dltwXX1dIGlzIG91dCBvZiBub3JtYWwgdHJhaW5pbmcgcmFuZ2UsIHlvdXIgbmV0d29yayB3aWxsIHByb2JhYmx5IG5vdCB0cmFpbi5gKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIH1cbiAgICBzZXRMb2dNZXRob2QobG9nKSB7XG4gICAgICAgIGlmICh0eXBlb2YgbG9nID09PSAnZnVuY3Rpb24nKSB7XG4gICAgICAgICAgICB0aGlzLnRyYWluT3B0cy5sb2cgPSBsb2c7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSBpZiAobG9nKSB7XG4gICAgICAgICAgICB0aGlzLnRyYWluT3B0cy5sb2cgPSBjb25zb2xlLmxvZztcbiAgICAgICAgfVxuICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgIHRoaXMudHJhaW5PcHRzLmxvZyA9IGZhbHNlO1xuICAgICAgICB9XG4gICAgfVxuICAgIHByZXBUcmFpbmluZyhkYXRhLCBvcHRpb25zKSB7XG4gICAgICAgIHZhciBfYTtcbiAgICAgICAgdGhpcy51cGRhdGVUcmFpbmluZ09wdGlvbnMob3B0aW9ucyk7XG4gICAgICAgIGNvbnN0IHByZXBhcmVkRGF0YSA9IHRoaXMub3B0aW9ucy5kYXRhRm9ybWF0dGVyLmZvcm1hdChkYXRhKTtcbiAgICAgICAgY29uc3QgZW5kVGltZSA9IERhdGUubm93KCkgKyAoKF9hID0gdGhpcy50cmFpbk9wdHMudGltZW91dCkgIT09IG51bGwgJiYgX2EgIT09IHZvaWQgMCA/IF9hIDogMCk7XG4gICAgICAgIGNvbnN0IHN0YXR1cyA9IHtcbiAgICAgICAgICAgIGVycm9yOiAxLFxuICAgICAgICAgICAgaXRlcmF0aW9uczogMCxcbiAgICAgICAgfTtcbiAgICAgICAgdGhpcy52ZXJpZnlJc0luaXRpYWxpemVkKCk7XG4gICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICBwcmVwYXJlZERhdGEsXG4gICAgICAgICAgICBzdGF0dXMsXG4gICAgICAgICAgICBlbmRUaW1lLFxuICAgICAgICB9O1xuICAgIH1cbiAgICB0cmFpbihkYXRhLCB0cmFpbk9wdHMgPSB7fSkge1xuICAgICAgICB2YXIgX2E7XG4gICAgICAgIHRoaXMudHJhaW5PcHRzID0gdHJhaW5PcHRzID0ge1xuICAgICAgICAgICAgLi4udHJhaW5EZWZhdWx0cyQxLFxuICAgICAgICAgICAgLi4udHJhaW5PcHRzLFxuICAgICAgICB9O1xuICAgICAgICBjb25zdCB7IGl0ZXJhdGlvbnMsIGVycm9yVGhyZXNoLCBsb2dQZXJpb2QsIGNhbGxiYWNrLCBjYWxsYmFja1BlcmlvZCwgfSA9IHRoaXMudHJhaW5PcHRzO1xuICAgICAgICBjb25zdCBsb2cgPSB0cmFpbk9wdHMubG9nID09PSB0cnVlID8gY29uc29sZS5sb2cgOiB0cmFpbk9wdHMubG9nO1xuICAgICAgICBsZXQgZXJyb3IgPSBJbmZpbml0eTtcbiAgICAgICAgbGV0IGk7XG4gICAgICAgIGxldCBpbnB1dHM7XG4gICAgICAgIGlmICgoX2EgPSB0aGlzLm9wdGlvbnMpID09PSBudWxsIHx8IF9hID09PSB2b2lkIDAgPyB2b2lkIDAgOiBfYS5kYXRhRm9ybWF0dGVyKSB7XG4gICAgICAgICAgICBpbnB1dHMgPSB0aGlzLm9wdGlvbnMuZGF0YUZvcm1hdHRlci5mb3JtYXQoZGF0YSk7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSBpZiAoQXJyYXkuaXNBcnJheShkYXRhKSAmJlxuICAgICAgICAgICAgQXJyYXkuaXNBcnJheShkYXRhWzBdKSAmJlxuICAgICAgICAgICAgdHlwZW9mIGRhdGFbMF1bMF0gPT09ICdudW1iZXInKSB7XG4gICAgICAgICAgICBpbnB1dHMgPSBkYXRhO1xuICAgICAgICB9XG4gICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKCd0cmFpbmluZyBub3QgaW4gZXhwZWN0ZWQgZm9ybWF0IG9mIG51bWJlcltdW10nKTtcbiAgICAgICAgfVxuICAgICAgICB0aGlzLnZlcmlmeUlzSW5pdGlhbGl6ZWQoKTtcbiAgICAgICAgZm9yIChpID0gMDsgaSA8IGl0ZXJhdGlvbnMgJiYgZXJyb3IgPiBlcnJvclRocmVzaDsgaSsrKSB7XG4gICAgICAgICAgICBsZXQgc3VtID0gMDtcbiAgICAgICAgICAgIGZvciAobGV0IGogPSAwOyBqIDwgaW5wdXRzLmxlbmd0aDsgaisrKSB7XG4gICAgICAgICAgICAgICAgY29uc3QgZXJyID0gdGhpcy50cmFpblBhdHRlcm4oaW5wdXRzW2pdLCB0cnVlKTtcbiAgICAgICAgICAgICAgICBzdW0gKz0gZXJyO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZXJyb3IgPSBzdW0gLyBkYXRhLmxlbmd0aDtcbiAgICAgICAgICAgIGlmIChpc05hTihlcnJvcikpIHtcbiAgICAgICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ05ldHdvcmsgZXJyb3IgcmF0ZSBpcyB1bmV4cGVjdGVkIE5hTiwgY2hlY2sgbmV0d29yayBjb25maWd1cmF0aW9ucyBhbmQgdHJ5IGFnYWluLiBNb3N0IHByb2JhYmx5IGlucHV0IGZvcm1hdCBpcyBub3QgY29ycmVjdCBvciB0cmFpbmluZyBkYXRhIGlzIG5vdCBlbm91Z2guICcpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaWYgKGxvZyAmJiBpICUgbG9nUGVyaW9kID09PSAwKSB7XG4gICAgICAgICAgICAgICAgbG9nKGBpdGVyYXRpb25zOiAke2l9LCB0cmFpbmluZyBlcnJvcjogJHtlcnJvcn1gKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGlmIChjYWxsYmFjayAmJiBpICUgY2FsbGJhY2tQZXJpb2QgPT09IDApIHtcbiAgICAgICAgICAgICAgICBjYWxsYmFjayh7IGVycm9yLCBpdGVyYXRpb25zOiBpIH0pO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICBlcnJvcixcbiAgICAgICAgICAgIGl0ZXJhdGlvbnM6IGksXG4gICAgICAgIH07XG4gICAgfVxuICAgIGFkZEZvcm1hdCgpIHtcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdub3QgeWV0IGltcGxlbWVudGVkJyk7XG4gICAgfVxuICAgIHRvSlNPTigpIHtcbiAgICAgICAgaWYgKCF0aGlzLm1vZGVsLmlzSW5pdGlhbGl6ZWQpIHtcbiAgICAgICAgICAgIHRoaXMuaW5pdGlhbGl6ZSgpO1xuICAgICAgICB9XG4gICAgICAgIGNvbnN0IHsgbW9kZWwsIG9wdGlvbnMgfSA9IHRoaXM7XG4gICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICB0eXBlOiB0aGlzLmNvbnN0cnVjdG9yLm5hbWUsXG4gICAgICAgICAgICBvcHRpb25zOiB7IC4uLm9wdGlvbnMsIGRhdGFGb3JtYXR0ZXI6IG9wdGlvbnMuZGF0YUZvcm1hdHRlci50b0pTT04oKSB9LFxuICAgICAgICAgICAgdHJhaW5PcHRzOiB7XG4gICAgICAgICAgICAgICAgLi4udGhpcy50cmFpbk9wdHMsXG4gICAgICAgICAgICAgICAgdGltZW91dDogdGhpcy50cmFpbk9wdHMudGltZW91dCA9PT0gSW5maW5pdHlcbiAgICAgICAgICAgICAgICAgICAgPyAnSW5maW5pdHknXG4gICAgICAgICAgICAgICAgICAgIDogdGhpcy50cmFpbk9wdHMudGltZW91dCxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBpbnB1dDogbW9kZWwuaW5wdXQudG9KU09OKCksXG4gICAgICAgICAgICBoaWRkZW5MYXllcnM6IG1vZGVsLmhpZGRlbkxheWVycy5tYXAoKGhpZGRlbkxheWVyKSA9PiB7XG4gICAgICAgICAgICAgICAgY29uc3QgbGF5ZXJzID0ge307XG4gICAgICAgICAgICAgICAgZm9yIChjb25zdCBwIGluIGhpZGRlbkxheWVyKSB7XG4gICAgICAgICAgICAgICAgICAgIGlmICghaGlkZGVuTGF5ZXIuaGFzT3duUHJvcGVydHkocCkpXG4gICAgICAgICAgICAgICAgICAgICAgICBjb250aW51ZTtcbiAgICAgICAgICAgICAgICAgICAgbGF5ZXJzW3BdID0gaGlkZGVuTGF5ZXJbcF0udG9KU09OKCk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIHJldHVybiBsYXllcnM7XG4gICAgICAgICAgICB9KSxcbiAgICAgICAgICAgIG91dHB1dENvbm5lY3RvcjogdGhpcy5tb2RlbC5vdXRwdXRDb25uZWN0b3IudG9KU09OKCksXG4gICAgICAgICAgICBvdXRwdXQ6IHRoaXMubW9kZWwub3V0cHV0LnRvSlNPTigpLFxuICAgICAgICB9O1xuICAgIH1cbiAgICBmcm9tSlNPTihqc29uKSB7XG4gICAgICAgIGNvbnN0IHsgb3B0aW9ucyB9ID0ganNvbjtcbiAgICAgICAgY29uc3QgYWxsTWF0cmljZXMgPSBbXTtcbiAgICAgICAgY29uc3QgaW5wdXQgPSBNYXRyaXguZnJvbUpTT04oanNvbi5pbnB1dCk7XG4gICAgICAgIGFsbE1hdHJpY2VzLnB1c2goaW5wdXQpO1xuICAgICAgICBjb25zdCBoaWRkZW5MYXllcnMgPSBbXTtcbiAgICAgICAganNvbi5oaWRkZW5MYXllcnMuZm9yRWFjaCgoaGlkZGVuTGF5ZXIpID0+IHtcbiAgICAgICAgICAgIGNvbnN0IGxheWVycyA9IHt9O1xuICAgICAgICAgICAgZm9yIChjb25zdCBwIGluIGhpZGRlbkxheWVyKSB7XG4gICAgICAgICAgICAgICAgbGF5ZXJzW3BdID0gTWF0cml4LmZyb21KU09OKGhpZGRlbkxheWVyW3BdKTtcbiAgICAgICAgICAgICAgICBhbGxNYXRyaWNlcy5wdXNoKGxheWVyc1twXSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBoaWRkZW5MYXllcnMucHVzaChsYXllcnMpO1xuICAgICAgICB9KTtcbiAgICAgICAgY29uc3Qgb3V0cHV0Q29ubmVjdG9yID0gTWF0cml4LmZyb21KU09OKGpzb24ub3V0cHV0Q29ubmVjdG9yKTtcbiAgICAgICAgYWxsTWF0cmljZXMucHVzaChvdXRwdXRDb25uZWN0b3IpO1xuICAgICAgICBjb25zdCBvdXRwdXQgPSBNYXRyaXguZnJvbUpTT04oanNvbi5vdXRwdXQpO1xuICAgICAgICBhbGxNYXRyaWNlcy5wdXNoKG91dHB1dCk7XG4gICAgICAgIGlmIChvcHRpb25zLmRhdGFGb3JtYXR0ZXIpIHtcbiAgICAgICAgICAgIHRoaXMub3B0aW9ucyA9IHtcbiAgICAgICAgICAgICAgICAuLi5kZWZhdWx0cyQxKCksXG4gICAgICAgICAgICAgICAgLi4ub3B0aW9ucyxcbiAgICAgICAgICAgICAgICBkYXRhRm9ybWF0dGVyOiBEYXRhRm9ybWF0dGVyLmZyb21KU09OKG9wdGlvbnMuZGF0YUZvcm1hdHRlciksXG4gICAgICAgICAgICB9O1xuICAgICAgICB9XG4gICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgdGhpcy5vcHRpb25zID0ge1xuICAgICAgICAgICAgICAgIC4uLmRlZmF1bHRzJDEoKSxcbiAgICAgICAgICAgICAgICAuLi5vcHRpb25zLFxuICAgICAgICAgICAgICAgIGRhdGFGb3JtYXR0ZXI6IG5ldyBEYXRhRm9ybWF0dGVyKCksXG4gICAgICAgICAgICB9O1xuICAgICAgICB9XG4gICAgICAgIHRoaXMubW9kZWwgPSBPYmplY3Quc2VhbCh7XG4gICAgICAgICAgICBpc0luaXRpYWxpemVkOiB0cnVlLFxuICAgICAgICAgICAgaW5wdXQsXG4gICAgICAgICAgICBoaWRkZW5MYXllcnMsXG4gICAgICAgICAgICBvdXRwdXQsXG4gICAgICAgICAgICBhbGxNYXRyaWNlcyxcbiAgICAgICAgICAgIG91dHB1dENvbm5lY3RvcixcbiAgICAgICAgICAgIGVxdWF0aW9uczogW10sXG4gICAgICAgICAgICBlcXVhdGlvbkNvbm5lY3Rpb25zOiBbXSxcbiAgICAgICAgfSk7XG4gICAgICAgIHRoaXMuaW5pdGlhbExheWVySW5wdXRzID0gdGhpcy5vcHRpb25zLmhpZGRlbkxheWVycy5tYXAoKHNpemUpID0+IG5ldyBNYXRyaXgoc2l6ZSwgMSkpO1xuICAgICAgICB0aGlzLmJpbmRFcXVhdGlvbigpO1xuICAgICAgICByZXR1cm4gdGhpcztcbiAgICB9XG4gICAgdG9GdW5jdGlvbihjYikge1xuICAgICAgICBjb25zdCB7IG1vZGVsIH0gPSB0aGlzO1xuICAgICAgICBjb25zdCB7IGVxdWF0aW9ucyB9ID0gdGhpcy5tb2RlbDtcbiAgICAgICAgY29uc3QgZXF1YXRpb24gPSBlcXVhdGlvbnNbMV07XG4gICAgICAgIGNvbnN0IHsgc3RhdGVzIH0gPSBlcXVhdGlvbjtcbiAgICAgICAgY29uc3QganNvblN0cmluZyA9IEpTT04uc3RyaW5naWZ5KHRoaXMudG9KU09OKCkpO1xuICAgICAgICBmdW5jdGlvbiBwcmV2aW91c0Nvbm5lY3Rpb25JbmRleChtKSB7XG4gICAgICAgICAgICBjb25zdCBjb25uZWN0aW9uID0gbW9kZWwuZXF1YXRpb25Db25uZWN0aW9uc1swXTtcbiAgICAgICAgICAgIGNvbnN0IHsgc3RhdGVzIH0gPSBlcXVhdGlvbnNbMF07XG4gICAgICAgICAgICBmb3IgKGxldCBpID0gMCwgbWF4ID0gc3RhdGVzLmxlbmd0aDsgaSA8IG1heDsgaSsrKSB7XG4gICAgICAgICAgICAgICAgaWYgKHN0YXRlc1tpXS5wcm9kdWN0ID09PSBtKSB7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHJldHVybiBjb25uZWN0aW9uLmluZGV4T2YobSk7XG4gICAgICAgIH1cbiAgICAgICAgZnVuY3Rpb24gbWF0cml4T3JpZ2luKG0sIHN0YXRlSW5kZXgpIHtcbiAgICAgICAgICAgIGZvciAobGV0IGkgPSAwLCBtYXggPSBzdGF0ZXMubGVuZ3RoOyBpIDwgbWF4OyBpKyspIHtcbiAgICAgICAgICAgICAgICBjb25zdCBzdGF0ZSA9IHN0YXRlc1tpXTtcbiAgICAgICAgICAgICAgICBpZiAoaSA9PT0gc3RhdGVJbmRleCkge1xuICAgICAgICAgICAgICAgICAgICBjb25zdCBqID0gcHJldmlvdXNDb25uZWN0aW9uSW5kZXgobSk7XG4gICAgICAgICAgICAgICAgICAgIGlmIChqID4gLTEgJiYgKG0gPT09IHN0YXRlLmxlZnQgfHwgbSA9PT0gc3RhdGUucmlnaHQpKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gYHR5cGVvZiBwcmV2U3RhdGVzWyR7an1dID09PSAnb2JqZWN0JyA/IHByZXZTdGF0ZXNbJHtqfV0ucHJvZHVjdCA6IG5ldyBNYXRyaXgoJHttLnJvd3N9LCAke20uY29sdW1uc30pYDtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gYG5ldyBNYXRyaXgoJHttLnJvd3N9LCAke20uY29sdW1uc30pYDtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgaWYgKG0gPT09IHN0YXRlLnByb2R1Y3QpXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBgc3RhdGVzWyR7aX1dLnByb2R1Y3RgO1xuICAgICAgICAgICAgICAgIGlmIChtID09PSBzdGF0ZS5yaWdodClcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGBzdGF0ZXNbJHtpfV0ucmlnaHRgO1xuICAgICAgICAgICAgICAgIGlmIChtID09PSBzdGF0ZS5sZWZ0KVxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gYHN0YXRlc1ske2l9XS5sZWZ0YDtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHJldHVybiAnJztcbiAgICAgICAgfVxuICAgICAgICBmdW5jdGlvbiBtYXRyaXhUb1N0cmluZyhtLCBzdGF0ZUluZGV4KSB7XG4gICAgICAgICAgICBpZiAoIW0gfHwgIW0ucm93cyB8fCAhbS5jb2x1bW5zKVxuICAgICAgICAgICAgICAgIHJldHVybiAnbnVsbCc7XG4gICAgICAgICAgICBpZiAobSA9PT0gbW9kZWwuaW5wdXQpXG4gICAgICAgICAgICAgICAgcmV0dXJuIGBqc29uLmlucHV0YDtcbiAgICAgICAgICAgIGlmIChtID09PSBtb2RlbC5vdXRwdXRDb25uZWN0b3IpXG4gICAgICAgICAgICAgICAgcmV0dXJuIGBqc29uLm91dHB1dENvbm5lY3RvcmA7XG4gICAgICAgICAgICBpZiAobSA9PT0gbW9kZWwub3V0cHV0KVxuICAgICAgICAgICAgICAgIHJldHVybiBganNvbi5vdXRwdXRgO1xuICAgICAgICAgICAgZm9yIChsZXQgaSA9IDAsIG1heCA9IG1vZGVsLmhpZGRlbkxheWVycy5sZW5ndGg7IGkgPCBtYXg7IGkrKykge1xuICAgICAgICAgICAgICAgIGNvbnN0IGhpZGRlbkxheWVyID0gbW9kZWwuaGlkZGVuTGF5ZXJzW2ldO1xuICAgICAgICAgICAgICAgIGZvciAoY29uc3QgcCBpbiBoaWRkZW5MYXllcikge1xuICAgICAgICAgICAgICAgICAgICBpZiAoIWhpZGRlbkxheWVyLmhhc093blByb3BlcnR5KHApKVxuICAgICAgICAgICAgICAgICAgICAgICAgY29udGludWU7XG4gICAgICAgICAgICAgICAgICAgIGlmIChoaWRkZW5MYXllcltwXSAhPT0gbSlcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnRpbnVlO1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gYGpzb24uaGlkZGVuTGF5ZXJzWyR7aX1dLiR7cH1gO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHJldHVybiBtYXRyaXhPcmlnaW4obSwgc3RhdGVJbmRleCk7XG4gICAgICAgIH1cbiAgICAgICAgZnVuY3Rpb24gdG9Jbm5lcihmblN0cmluZykge1xuICAgICAgICAgICAgLy8gY3J1ZGUsIGJ1dCBzaG91bGQgYmUgc3VmZmljaWVudCBmb3Igbm93XG4gICAgICAgICAgICAvLyBmdW5jdGlvbigpIHsgYm9keSB9XG4gICAgICAgICAgICBjb25zdCBmblBhcnRzID0gZm5TdHJpbmcudG9TdHJpbmcoKS5zcGxpdCgneycpO1xuICAgICAgICAgICAgZm5QYXJ0cy5zaGlmdCgpO1xuICAgICAgICAgICAgLy8gYm9keSB9XG4gICAgICAgICAgICBjb25zdCBmbkJvZHlTdHJpbmcgPSBmblBhcnRzLmpvaW4oJ3snKTtcbiAgICAgICAgICAgIGNvbnN0IGZuQm9keVBhcnRzID0gZm5Cb2R5U3RyaW5nLnNwbGl0KCd9Jyk7XG4gICAgICAgICAgICBmbkJvZHlQYXJ0cy5wb3AoKTtcbiAgICAgICAgICAgIC8vIGJvZHlcbiAgICAgICAgICAgIHJldHVybiBmbkJvZHlQYXJ0c1xuICAgICAgICAgICAgICAgIC5qb2luKCd9JylcbiAgICAgICAgICAgICAgICAuc3BsaXQoJ1xcbicpXG4gICAgICAgICAgICAgICAgLmpvaW4oJ1xcbiAgICAgICAgJylcbiAgICAgICAgICAgICAgICAucmVwbGFjZSgncHJvZHVjdC5kZWx0YXNbaV0gPSAwOycsICcnKVxuICAgICAgICAgICAgICAgIC5yZXBsYWNlKCdwcm9kdWN0LmRlbHRhc1tjb2x1bW5dID0gMDsnLCAnJylcbiAgICAgICAgICAgICAgICAucmVwbGFjZSgnbGVmdC5kZWx0YXNbbGVmdEluZGV4XSA9IDA7JywgJycpXG4gICAgICAgICAgICAgICAgLnJlcGxhY2UoJ3JpZ2h0LmRlbHRhc1tyaWdodEluZGV4XSA9IDA7JywgJycpXG4gICAgICAgICAgICAgICAgLnJlcGxhY2UoJ3Byb2R1Y3QuZGVsdGFzID0gbGVmdC5kZWx0YXMuc2xpY2UoMCk7JywgJycpO1xuICAgICAgICB9XG4gICAgICAgIGZ1bmN0aW9uIGZpbGVOYW1lKGZuTmFtZSkge1xuICAgICAgICAgICAgcmV0dXJuIGBzcmMvcmVjdXJyZW50L21hdHJpeC8ke2ZuTmFtZS5yZXBsYWNlKC9bQS1aXS9nLCBmdW5jdGlvbiAodmFsdWUpIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gYC0ke3ZhbHVlLnRvTG93ZXJDYXNlKCl9YDtcbiAgICAgICAgICAgIH0pfS5qc2A7XG4gICAgICAgIH1cbiAgICAgICAgY29uc3Qgc3RhdGVzUmF3ID0gW107XG4gICAgICAgIGNvbnN0IHVzZWRGdW5jdGlvbk5hbWVzID0ge307XG4gICAgICAgIGNvbnN0IGlubmVyRnVuY3Rpb25zU3dpdGNoID0gW107XG4gICAgICAgIGZvciAobGV0IGkgPSAwLCBtYXggPSBzdGF0ZXMubGVuZ3RoOyBpIDwgbWF4OyBpKyspIHtcbiAgICAgICAgICAgIGNvbnN0IHN0YXRlID0gc3RhdGVzW2ldO1xuICAgICAgICAgICAgc3RhdGVzUmF3LnB1c2goYHN0YXRlc1ske2l9XSA9IHtcbiAgICAgIG5hbWU6ICcke3N0YXRlLmZvcndhcmRGbi5uYW1lfScsXG4gICAgICBsZWZ0OiAke3N0YXRlLmxlZnQgPyBtYXRyaXhUb1N0cmluZyhzdGF0ZS5sZWZ0LCBpKSA6ICd1bmRlZmluZWQnfSxcbiAgICAgIHJpZ2h0OiAke3N0YXRlLnJpZ2h0ID8gbWF0cml4VG9TdHJpbmcoc3RhdGUucmlnaHQsIGkpIDogJ3VuZGVmaW5lZCd9LFxuICAgICAgcHJvZHVjdDogJHttYXRyaXhUb1N0cmluZyhzdGF0ZS5wcm9kdWN0LCBpKX1cbiAgICB9YCk7XG4gICAgICAgICAgICBjb25zdCBmbk5hbWUgPSBzdGF0ZS5mb3J3YXJkRm4ubmFtZTtcbiAgICAgICAgICAgIGlmICghdXNlZEZ1bmN0aW9uTmFtZXNbZm5OYW1lXSkge1xuICAgICAgICAgICAgICAgIHVzZWRGdW5jdGlvbk5hbWVzW2ZuTmFtZV0gPSB0cnVlO1xuICAgICAgICAgICAgICAgIGlubmVyRnVuY3Rpb25zU3dpdGNoLnB1c2goYCAgICAgICAgY2FzZSAnJHtmbk5hbWV9JzogLy9jb21waWxlZCBmcm9tICR7ZmlsZU5hbWUoZm5OYW1lKX1cbiAgICAgICAgICAke3RvSW5uZXIoc3RhdGUuZm9yd2FyZEZuLnRvU3RyaW5nKCkpfVxuICAgICAgICAgIGJyZWFrO2ApO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIGNvbnN0IHNyYyA9IGBcbiAgaWYgKHR5cGVvZiByYXdJbnB1dCA9PT0gJ3VuZGVmaW5lZCcpIHJhd0lucHV0ID0gW107XG4gIGlmICh0eXBlb2YgaXNTYW1wbGVJID09PSAndW5kZWZpbmVkJykgaXNTYW1wbGVJID0gZmFsc2U7XG4gIGlmICh0eXBlb2YgdGVtcGVyYXR1cmUgPT09ICd1bmRlZmluZWQnKSB0ZW1wZXJhdHVyZSA9IDE7XG4gIHZhciBqc29uID0gJHtqc29uU3RyaW5nfTtcbiAgJHt0aGlzLm9wdGlvbnMuZGF0YUZvcm1hdHRlclxuICAgICAgICAgICAgPyBgJHt0aGlzLm9wdGlvbnMuZGF0YUZvcm1hdHRlci50b0Z1bmN0aW9uU3RyaW5nKCl9O1xuICBPYmplY3QuYXNzaWduKGRhdGFGb3JtYXR0ZXIsIGpzb24ub3B0aW9ucy5kYXRhRm9ybWF0dGVyKTtgXG4gICAgICAgICAgICA6ICcnfVxuICAke3RoaXMub3B0aW9ucy5kYXRhRm9ybWF0dGVyICYmXG4gICAgICAgICAgICB0eXBlb2YgdGhpcy5vcHRpb25zLmRhdGFGb3JtYXR0ZXIuZm9ybWF0RGF0YUluID09PSAnZnVuY3Rpb24nXG4gICAgICAgICAgICA/IGBjb25zdCBmb3JtYXREYXRhSW4gPSBmdW5jdGlvbiAoaW5wdXQsIG91dHB1dCkgeyAke3RvSW5uZXIodGhpcy5vcHRpb25zLmRhdGFGb3JtYXR0ZXIuZm9ybWF0RGF0YUluLnRvU3RyaW5nKCkpfSB9LmJpbmQoZGF0YUZvcm1hdHRlcik7YFxuICAgICAgICAgICAgOiAnJ31cbiAgJHt0aGlzLm9wdGlvbnMuZGF0YUZvcm1hdHRlciAhPT0gbnVsbCAmJlxuICAgICAgICAgICAgdHlwZW9mIHRoaXMub3B0aW9ucy5kYXRhRm9ybWF0dGVyLmZvcm1hdERhdGFPdXQgPT09ICdmdW5jdGlvbidcbiAgICAgICAgICAgID8gYGNvbnN0IGZvcm1hdERhdGFPdXQgPSBmdW5jdGlvbiBmb3JtYXREYXRhT3V0KGlucHV0LCBvdXRwdXQpIHsgJHt0b0lubmVyKHRoaXMub3B0aW9ucy5kYXRhRm9ybWF0dGVyLmZvcm1hdERhdGFPdXQudG9TdHJpbmcoKSl9IH0uYmluZChkYXRhRm9ybWF0dGVyKTtgXG4gICAgICAgICAgICA6ICcnfVxuICB2YXIgbWF4UHJlZGljdGlvbkxlbmd0aCA9XG4gICAgJHt0aGlzLm9wdGlvbnMubWF4UHJlZGljdGlvbkxlbmd0aH0gK1xuICAgIHJhd0lucHV0Lmxlbmd0aCArXG4gICAgJHt0aGlzLm9wdGlvbnMuZGF0YUZvcm1hdHRlclxuICAgICAgICAgICAgPyB0aGlzLm9wdGlvbnMuZGF0YUZvcm1hdHRlci5zcGVjaWFsSW5kZXhlcy5sZW5ndGhcbiAgICAgICAgICAgIDogMH07XG4gIHZhciBpbnB1dCA9ICR7dGhpcy5vcHRpb25zLmRhdGFGb3JtYXR0ZXIgJiZcbiAgICAgICAgICAgIHR5cGVvZiB0aGlzLm9wdGlvbnMuZGF0YUZvcm1hdHRlci5mb3JtYXREYXRhSW4gPT09ICdmdW5jdGlvbidcbiAgICAgICAgICAgID8gJ2Zvcm1hdERhdGFJbihyYXdJbnB1dCknXG4gICAgICAgICAgICA6ICdyYXdJbnB1dCd9O1xuICB2YXIgX2kgPSAwO1xuICB2YXIgb3V0cHV0ID0gW107XG4gIHZhciBzdGF0ZXMgPSBbXTtcbiAgdmFyIHByZXZTdGF0ZXM7XG4gIHdoaWxlICh0cnVlKSB7XG4gICAgdmFyIHByZXZpb3VzSW5kZXggPSAoX2kgPT09IDBcbiAgICAgICAgPyAwXG4gICAgICAgIDogX2kgPCBpbnB1dC5sZW5ndGhcbiAgICAgICAgICA/IGlucHV0W19pIC0gMV0gKyAxXG4gICAgICAgICAgOiBvdXRwdXRbX2kgLSAxXSlcbiAgICAgICAgICA7XG4gICAgdmFyIHJvd1BsdWNrSW5kZXggPSBwcmV2aW91c0luZGV4O1xuICAgIHByZXZTdGF0ZXMgPSBzdGF0ZXM7XG4gICAgc3RhdGVzID0gW107XG4gICAgJHtzdGF0ZXNSYXcuam9pbignO1xcbiAgICAnKX07XG4gICAgZm9yICh2YXIgc3RhdGVJbmRleCA9IDAsIHN0YXRlTWF4ID0gJHtzdGF0ZXNSYXcubGVuZ3RofTsgc3RhdGVJbmRleCA8IHN0YXRlTWF4OyBzdGF0ZUluZGV4KyspIHtcbiAgICAgIHZhciBzdGF0ZSA9IHN0YXRlc1tzdGF0ZUluZGV4XTtcbiAgICAgIHZhciBwcm9kdWN0ID0gc3RhdGUucHJvZHVjdDtcbiAgICAgIHZhciBsZWZ0ID0gc3RhdGUubGVmdDtcbiAgICAgIHZhciByaWdodCA9IHN0YXRlLnJpZ2h0O1xuICAgICAgc3dpdGNoIChzdGF0ZS5uYW1lKSB7XG4ke2lubmVyRnVuY3Rpb25zU3dpdGNoLmpvaW4oJ1xcbicpfVxuICAgICAgfVxuICAgIH1cblxuICAgIHZhciBsb2dQcm9iYWJpbGl0aWVzID0gc3RhdGUucHJvZHVjdDtcbiAgICBpZiAodGVtcGVyYXR1cmUgIT09IDEgJiYgaXNTYW1wbGVJKSB7XG4gICAgICBmb3IgKHZhciBxID0gMCwgbnEgPSBsb2dQcm9iYWJpbGl0aWVzLndlaWdodHMubGVuZ3RoOyBxIDwgbnE7IHErKykge1xuICAgICAgICBsb2dQcm9iYWJpbGl0aWVzLndlaWdodHNbcV0gLz0gdGVtcGVyYXR1cmU7XG4gICAgICB9XG4gICAgfVxuXG4gICAgdmFyIHByb2JzID0gc29mdG1heChsb2dQcm9iYWJpbGl0aWVzKTtcbiAgICB2YXIgbmV4dEluZGV4ID0gaXNTYW1wbGVJID8gc2FtcGxlSShwcm9icykgOiBtYXhJKHByb2JzKTtcblxuICAgIF9pKys7XG4gICAgaWYgKG5leHRJbmRleCA9PT0gMCkge1xuICAgICAgYnJlYWs7XG4gICAgfVxuICAgIGlmIChfaSA+PSBtYXhQcmVkaWN0aW9uTGVuZ3RoKSB7XG4gICAgICBicmVhaztcbiAgICB9XG5cbiAgICBvdXRwdXQucHVzaChuZXh0SW5kZXgpO1xuICB9XG4gICR7dGhpcy5vcHRpb25zLmRhdGFGb3JtYXR0ZXIgJiZcbiAgICAgICAgICAgIHR5cGVvZiB0aGlzLm9wdGlvbnMuZGF0YUZvcm1hdHRlci5mb3JtYXREYXRhT3V0ID09PSAnZnVuY3Rpb24nXG4gICAgICAgICAgICA/ICdyZXR1cm4gZm9ybWF0RGF0YU91dChpbnB1dCwgb3V0cHV0LnNsaWNlKGlucHV0Lmxlbmd0aCkubWFwKGZ1bmN0aW9uKHZhbHVlKSB7IHJldHVybiB2YWx1ZSAtIDE7IH0pKSdcbiAgICAgICAgICAgIDogJ3JldHVybiBvdXRwdXQuc2xpY2UoaW5wdXQubGVuZ3RoKS5tYXAoZnVuY3Rpb24odmFsdWUpIHsgcmV0dXJuIHZhbHVlIC0gMTsgfSknfTtcbiAgZnVuY3Rpb24gTWF0cml4KHJvd3MsIGNvbHVtbnMpIHtcbiAgICB0aGlzLnJvd3MgPSByb3dzO1xuICAgIHRoaXMuY29sdW1ucyA9IGNvbHVtbnM7XG4gICAgdGhpcy53ZWlnaHRzID0gemVyb3Mocm93cyAqIGNvbHVtbnMpO1xuICB9XG4gICR7emVyb3MkMS50b1N0cmluZygpfVxuICAke3NvZnRtYXgudG9TdHJpbmcoKS5yZXBsYWNlKCdfMS5NYXRyaXgnLCAnTWF0cml4Jyl9XG4gICR7cmFuZG9tRmxvYXQudG9TdHJpbmcoKX1cbiAgJHtzYW1wbGVJLnRvU3RyaW5nKCl9XG4gICR7bWF4SS50b1N0cmluZygpfWA7XG4gICAgICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZVxuICAgICAgICByZXR1cm4gbmV3IEZ1bmN0aW9uKCdyYXdJbnB1dCcsICdpc1NhbXBsZUknLCAndGVtcGVyYXR1cmUnLCBjYiA/IGNiKHNyYykgOiBzcmMpO1xuICAgIH1cbiAgICB0cmFpblBhdHRlcm4oaW5wdXQsIGxvZ0Vycm9yUmF0ZSkge1xuICAgICAgICBjb25zdCBlcnJvciA9IHRoaXMudHJhaW5JbnB1dChpbnB1dCk7XG4gICAgICAgIHRoaXMuYmFja3Byb3BhZ2F0ZShpbnB1dCk7XG4gICAgICAgIHRoaXMuYWRqdXN0V2VpZ2h0cygpO1xuICAgICAgICBpZiAobG9nRXJyb3JSYXRlKSB7XG4gICAgICAgICAgICByZXR1cm4gZXJyb3I7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIDA7XG4gICAgfVxufVxuZnVuY3Rpb24gbGFzdCh2YWx1ZXMpIHtcbiAgICByZXR1cm4gdmFsdWVzW3ZhbHVlcy5sZW5ndGggLSAxXTtcbn1cblxuY2xhc3MgR1JVIGV4dGVuZHMgUk5OIHtcbiAgICBnZXRIaWRkZW5MYXllcihoaWRkZW5TaXplLCBwcmV2U2l6ZSkge1xuICAgICAgICByZXR1cm4gZ2V0R1JVSGlkZGVuTGF5ZXIoaGlkZGVuU2l6ZSwgcHJldlNpemUpO1xuICAgIH1cbiAgICBnZXRFcXVhdGlvbihlcXVhdGlvbiwgaW5wdXRNYXRyaXgsIHByZXZpb3VzUmVzdWx0LCBoaWRkZW5MYXllcikge1xuICAgICAgICByZXR1cm4gZ2V0R1JVRXF1YXRpb24oZXF1YXRpb24sIGlucHV0TWF0cml4LCBwcmV2aW91c1Jlc3VsdCwgaGlkZGVuTGF5ZXIpO1xuICAgIH1cbn1cbmZ1bmN0aW9uIGdldEdSVUhpZGRlbkxheWVyKGhpZGRlblNpemUsIHByZXZTaXplKSB7XG4gICAgcmV0dXJuIHtcbiAgICAgICAgLy8gdXBkYXRlIEdhdGVcbiAgICAgICAgLy8gd3p4aFxuICAgICAgICB1cGRhdGVHYXRlSW5wdXRNYXRyaXg6IG5ldyBSYW5kb21NYXRyaXgoaGlkZGVuU2l6ZSwgcHJldlNpemUsIDAuMDgpLFxuICAgICAgICB1cGRhdGVHYXRlSGlkZGVuTWF0cml4OiBuZXcgUmFuZG9tTWF0cml4KGhpZGRlblNpemUsIGhpZGRlblNpemUsIDAuMDgpLFxuICAgICAgICB1cGRhdGVHYXRlQmlhczogbmV3IE1hdHJpeChoaWRkZW5TaXplLCAxKSxcbiAgICAgICAgLy8gcmVzZXQgR2F0ZVxuICAgICAgICAvLyB3cnhoXG4gICAgICAgIHJlc2V0R2F0ZUlucHV0TWF0cml4OiBuZXcgUmFuZG9tTWF0cml4KGhpZGRlblNpemUsIHByZXZTaXplLCAwLjA4KSxcbiAgICAgICAgcmVzZXRHYXRlSGlkZGVuTWF0cml4OiBuZXcgUmFuZG9tTWF0cml4KGhpZGRlblNpemUsIGhpZGRlblNpemUsIDAuMDgpLFxuICAgICAgICByZXNldEdhdGVCaWFzOiBuZXcgTWF0cml4KGhpZGRlblNpemUsIDEpLFxuICAgICAgICAvLyBjZWxsIHdyaXRlIHBhcmFtZXRlcnNcbiAgICAgICAgLy8gd2N4aFxuICAgICAgICBjZWxsV3JpdGVJbnB1dE1hdHJpeDogbmV3IFJhbmRvbU1hdHJpeChoaWRkZW5TaXplLCBwcmV2U2l6ZSwgMC4wOCksXG4gICAgICAgIGNlbGxXcml0ZUhpZGRlbk1hdHJpeDogbmV3IFJhbmRvbU1hdHJpeChoaWRkZW5TaXplLCBoaWRkZW5TaXplLCAwLjA4KSxcbiAgICAgICAgY2VsbFdyaXRlQmlhczogbmV3IE1hdHJpeChoaWRkZW5TaXplLCAxKSxcbiAgICB9O1xufVxuZnVuY3Rpb24gZ2V0R1JVRXF1YXRpb24oZXF1YXRpb24sIGlucHV0TWF0cml4LCBwcmV2aW91c1Jlc3VsdCwgaGlkZGVuTGF5ZXIpIHtcbiAgICBpZiAoIWhpZGRlbkxheWVyLnVwZGF0ZUdhdGVJbnB1dE1hdHJpeCB8fFxuICAgICAgICAhaGlkZGVuTGF5ZXIudXBkYXRlR2F0ZUhpZGRlbk1hdHJpeCB8fFxuICAgICAgICAhaGlkZGVuTGF5ZXIudXBkYXRlR2F0ZUJpYXMgfHxcbiAgICAgICAgIWhpZGRlbkxheWVyLnJlc2V0R2F0ZUlucHV0TWF0cml4IHx8XG4gICAgICAgICFoaWRkZW5MYXllci5yZXNldEdhdGVIaWRkZW5NYXRyaXggfHxcbiAgICAgICAgIWhpZGRlbkxheWVyLnJlc2V0R2F0ZUJpYXMgfHxcbiAgICAgICAgIWhpZGRlbkxheWVyLmNlbGxXcml0ZUlucHV0TWF0cml4IHx8XG4gICAgICAgICFoaWRkZW5MYXllci5jZWxsV3JpdGVIaWRkZW5NYXRyaXggfHxcbiAgICAgICAgIWhpZGRlbkxheWVyLmNlbGxXcml0ZUJpYXMpIHtcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdoaWRkZW5MYXllciBkb2VzIG5vdCBoYXZlIGV4cGVjdGVkIHByb3BlcnRpZXMnKTtcbiAgICB9XG4gICAgY29uc3Qgc2lnbW9pZCA9IGVxdWF0aW9uLnNpZ21vaWQuYmluZChlcXVhdGlvbik7XG4gICAgY29uc3QgYWRkID0gZXF1YXRpb24uYWRkLmJpbmQoZXF1YXRpb24pO1xuICAgIGNvbnN0IG11bHRpcGx5ID0gZXF1YXRpb24ubXVsdGlwbHkuYmluZChlcXVhdGlvbik7XG4gICAgY29uc3QgbXVsdGlwbHlFbGVtZW50ID0gZXF1YXRpb24ubXVsdGlwbHlFbGVtZW50LmJpbmQoZXF1YXRpb24pO1xuICAgIGNvbnN0IHRhbmggPSBlcXVhdGlvbi50YW5oLmJpbmQoZXF1YXRpb24pO1xuICAgIGNvbnN0IGFsbE9uZXMgPSBlcXVhdGlvbi5hbGxPbmVzLmJpbmQoZXF1YXRpb24pO1xuICAgIGNvbnN0IGNsb25lTmVnYXRpdmUgPSBlcXVhdGlvbi5jbG9uZU5lZ2F0aXZlLmJpbmQoZXF1YXRpb24pO1xuICAgIC8vIHVwZGF0ZSBnYXRlXG4gICAgY29uc3QgdXBkYXRlR2F0ZSA9IHNpZ21vaWQoYWRkKGFkZChtdWx0aXBseShoaWRkZW5MYXllci51cGRhdGVHYXRlSW5wdXRNYXRyaXgsIGlucHV0TWF0cml4KSwgbXVsdGlwbHkoaGlkZGVuTGF5ZXIudXBkYXRlR2F0ZUhpZGRlbk1hdHJpeCwgcHJldmlvdXNSZXN1bHQpKSwgaGlkZGVuTGF5ZXIudXBkYXRlR2F0ZUJpYXMpKTtcbiAgICAvLyByZXNldCBnYXRlXG4gICAgY29uc3QgcmVzZXRHYXRlID0gc2lnbW9pZChhZGQoYWRkKG11bHRpcGx5KGhpZGRlbkxheWVyLnJlc2V0R2F0ZUlucHV0TWF0cml4LCBpbnB1dE1hdHJpeCksIG11bHRpcGx5KGhpZGRlbkxheWVyLnJlc2V0R2F0ZUhpZGRlbk1hdHJpeCwgcHJldmlvdXNSZXN1bHQpKSwgaGlkZGVuTGF5ZXIucmVzZXRHYXRlQmlhcykpO1xuICAgIC8vIGNlbGxcbiAgICBjb25zdCBjZWxsID0gdGFuaChhZGQoYWRkKG11bHRpcGx5KGhpZGRlbkxheWVyLmNlbGxXcml0ZUlucHV0TWF0cml4LCBpbnB1dE1hdHJpeCksIG11bHRpcGx5KGhpZGRlbkxheWVyLmNlbGxXcml0ZUhpZGRlbk1hdHJpeCwgbXVsdGlwbHlFbGVtZW50KHJlc2V0R2F0ZSwgcHJldmlvdXNSZXN1bHQpKSksIGhpZGRlbkxheWVyLmNlbGxXcml0ZUJpYXMpKTtcbiAgICAvLyBjb21wdXRlIGhpZGRlbiBzdGF0ZSBhcyBnYXRlZCwgc2F0dXJhdGVkIGNlbGwgYWN0aXZhdGlvbnNcbiAgICAvLyBuZWdhdGUgdXBkYXRlR2F0ZVxuICAgIHJldHVybiBhZGQobXVsdGlwbHlFbGVtZW50KGFkZChhbGxPbmVzKHVwZGF0ZUdhdGUucm93cywgdXBkYXRlR2F0ZS5jb2x1bW5zKSwgY2xvbmVOZWdhdGl2ZSh1cGRhdGVHYXRlKSksIGNlbGwpLCBtdWx0aXBseUVsZW1lbnQocHJldmlvdXNSZXN1bHQsIHVwZGF0ZUdhdGUpKTtcbn1cblxuY2xhc3MgQXJyYXlMb29rdXBUYWJsZSB7XG4gICAgY29uc3RydWN0b3IoZGF0YSwgcHJvcCkge1xuICAgICAgICB0aGlzLnByb3AgPSBwcm9wO1xuICAgICAgICB0aGlzLmxlbmd0aCA9IDA7XG4gICAgICAgIHRoaXMudGFibGUgPSB7fTtcbiAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBkYXRhLmxlbmd0aDsgaSsrKSB7XG4gICAgICAgICAgICBjb25zdCBkYXR1bSA9IGRhdGFbaV07XG4gICAgICAgICAgICBjb25zdCBpb1ZhbHVlID0gZGF0dW1bcHJvcF07XG4gICAgICAgICAgICBmb3IgKGxldCBqID0gMDsgaiA8IGlvVmFsdWUubGVuZ3RoOyBqKyspIHtcbiAgICAgICAgICAgICAgICBjb25zdCB2YWx1ZSA9IGlvVmFsdWVbal07XG4gICAgICAgICAgICAgICAgZm9yIChjb25zdCBwIGluIHZhbHVlKSB7XG4gICAgICAgICAgICAgICAgICAgIGlmICghdmFsdWUuaGFzT3duUHJvcGVydHkocCkpXG4gICAgICAgICAgICAgICAgICAgICAgICBjb250aW51ZTtcbiAgICAgICAgICAgICAgICAgICAgaWYgKHRoaXMudGFibGUuaGFzT3duUHJvcGVydHkocCkpXG4gICAgICAgICAgICAgICAgICAgICAgICBjb250aW51ZTtcbiAgICAgICAgICAgICAgICAgICAgdGhpcy50YWJsZVtwXSA9IHRoaXMubGVuZ3RoKys7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfVxufVxuXG5jb25zdCBkZWZhdWx0cyA9ICgpID0+IHtcbiAgICByZXR1cm4ge1xuICAgICAgICAuLi5kZWZhdWx0cyQxKCksXG4gICAgICAgIGlucHV0U2l6ZTogMSxcbiAgICAgICAgaGlkZGVuTGF5ZXJzOiBbMjBdLFxuICAgICAgICBvdXRwdXRTaXplOiAxLFxuICAgICAgICBpbnB1dFJhbmdlOiAwLFxuICAgIH07XG59O1xuY2xhc3MgUk5OVGltZVN0ZXAgZXh0ZW5kcyBSTk4ge1xuICAgIGNvbnN0cnVjdG9yKG9wdGlvbnMgPSB7fSkge1xuICAgICAgICBzdXBlcigpO1xuICAgICAgICB0aGlzLmlucHV0TG9va3VwTGVuZ3RoID0gMDtcbiAgICAgICAgdGhpcy5pbnB1dExvb2t1cCA9IG51bGw7XG4gICAgICAgIHRoaXMub3V0cHV0TG9va3VwID0gbnVsbDtcbiAgICAgICAgdGhpcy5vdXRwdXRMb29rdXBMZW5ndGggPSAwO1xuICAgICAgICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgQHR5cGVzY3JpcHQtZXNsaW50L2Jhbi10cy1jb21tZW50XG4gICAgICAgIC8vIEB0cy1leHBlY3QtZXJyb3JcbiAgICAgICAgdGhpcy5tb2RlbCA9IE9iamVjdC5zZWFsKHtcbiAgICAgICAgICAgIGlzSW5pdGlhbGl6ZWQ6IGZhbHNlLFxuICAgICAgICAgICAgaGlkZGVuTGF5ZXJzOiBbXSxcbiAgICAgICAgICAgIG91dHB1dDogbmV3IE1hdHJpeCgwLCAwKSxcbiAgICAgICAgICAgIGVxdWF0aW9uczogW10sXG4gICAgICAgICAgICBhbGxNYXRyaWNlczogW10sXG4gICAgICAgICAgICBlcXVhdGlvbkNvbm5lY3Rpb25zOiBbXSxcbiAgICAgICAgICAgIG91dHB1dENvbm5lY3RvcjogbmV3IFJhbmRvbU1hdHJpeCgwLCAwLCAwLjA4KSxcbiAgICAgICAgfSk7XG4gICAgICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBAdHlwZXNjcmlwdC1lc2xpbnQvYmFuLXRzLWNvbW1lbnRcbiAgICAgICAgLy8gQHRzLWV4cGVjdC1lcnJvclxuICAgICAgICB0aGlzLm9wdGlvbnMgPSBkZWZhdWx0cygpO1xuICAgICAgICB0aGlzLm9wdGlvbnMgPSB7IC4uLnRoaXMub3B0aW9ucywgLi4ub3B0aW9ucyB9O1xuICAgICAgICB0aGlzLnVwZGF0ZVRyYWluaW5nT3B0aW9ucyh7XG4gICAgICAgICAgICAuLi50cmFpbkRlZmF1bHRzLFxuICAgICAgICAgICAgLi4ub3B0aW9ucyxcbiAgICAgICAgfSk7XG4gICAgICAgIGlmIChvcHRpb25zLmpzb24pIHtcbiAgICAgICAgICAgIHRoaXMuZnJvbUpTT04ob3B0aW9ucy5qc29uKTtcbiAgICAgICAgfVxuICAgIH1cbiAgICBjcmVhdGVJbnB1dE1hdHJpeCgpIHtcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdJbnB1dCBNYXRyaWNlcyBkbyBub3QgZXhpc3Qgb24gUk5OVGltZVN0ZXAnKTtcbiAgICB9XG4gICAgY3JlYXRlT3V0cHV0TWF0cmljZXMoKSB7XG4gICAgICAgIGNvbnN0IHsgb3V0cHV0U2l6ZSB9ID0gdGhpcy5vcHRpb25zO1xuICAgICAgICBjb25zdCBsYXN0SGlkZGVuU2l6ZSA9IGxhc3QodGhpcy5vcHRpb25zLmhpZGRlbkxheWVycyk7XG4gICAgICAgIC8vIHdoZFxuICAgICAgICBjb25zdCBvdXRwdXRDb25uZWN0b3IgPSBuZXcgUmFuZG9tTWF0cml4KG91dHB1dFNpemUsIGxhc3RIaWRkZW5TaXplLCAwLjA4KTtcbiAgICAgICAgLy8gYmRcbiAgICAgICAgY29uc3Qgb3V0cHV0ID0gbmV3IFJhbmRvbU1hdHJpeChvdXRwdXRTaXplLCAxLCAwLjA4KTtcbiAgICAgICAgcmV0dXJuIHsgb3V0cHV0LCBvdXRwdXRDb25uZWN0b3IgfTtcbiAgICB9XG4gICAgYmluZEVxdWF0aW9uKCkge1xuICAgICAgICBjb25zdCB7IG1vZGVsLCBvcHRpb25zIH0gPSB0aGlzO1xuICAgICAgICBjb25zdCB7IGhpZGRlbkxheWVycywgaW5wdXRTaXplIH0gPSBvcHRpb25zO1xuICAgICAgICBjb25zdCBsYXllcnMgPSBtb2RlbC5oaWRkZW5MYXllcnM7XG4gICAgICAgIGNvbnN0IGVxdWF0aW9uID0gbmV3IEVxdWF0aW9uKCk7XG4gICAgICAgIGNvbnN0IG91dHB1dHMgPSBbXTtcbiAgICAgICAgY29uc3QgZXF1YXRpb25Db25uZWN0aW9uID0gbW9kZWwuZXF1YXRpb25Db25uZWN0aW9ucy5sZW5ndGggPiAwXG4gICAgICAgICAgICA/IG1vZGVsLmVxdWF0aW9uQ29ubmVjdGlvbnNbbW9kZWwuZXF1YXRpb25Db25uZWN0aW9ucy5sZW5ndGggLSAxXVxuICAgICAgICAgICAgOiB0aGlzLmluaXRpYWxMYXllcklucHV0cztcbiAgICAgICAgLy8gMCBpbmRleFxuICAgICAgICBsZXQgb3V0cHV0ID0gdGhpcy5nZXRFcXVhdGlvbihlcXVhdGlvbiwgZXF1YXRpb24uaW5wdXQobmV3IE1hdHJpeChpbnB1dFNpemUsIDEpKSwgZXF1YXRpb25Db25uZWN0aW9uWzBdLCBsYXllcnNbMF0pO1xuICAgICAgICBvdXRwdXRzLnB1c2gob3V0cHV0KTtcbiAgICAgICAgLy8gMSsgaW5kaWNlc1xuICAgICAgICBmb3IgKGxldCBpID0gMSwgbWF4ID0gaGlkZGVuTGF5ZXJzLmxlbmd0aDsgaSA8IG1heDsgaSsrKSB7XG4gICAgICAgICAgICBvdXRwdXQgPSB0aGlzLmdldEVxdWF0aW9uKGVxdWF0aW9uLCBvdXRwdXQsIGVxdWF0aW9uQ29ubmVjdGlvbltpXSwgbGF5ZXJzW2ldKTtcbiAgICAgICAgICAgIG91dHB1dHMucHVzaChvdXRwdXQpO1xuICAgICAgICB9XG4gICAgICAgIG1vZGVsLmVxdWF0aW9uQ29ubmVjdGlvbnMucHVzaChvdXRwdXRzKTtcbiAgICAgICAgZXF1YXRpb24uYWRkKGVxdWF0aW9uLm11bHRpcGx5KG1vZGVsLm91dHB1dENvbm5lY3Rvciwgb3V0cHV0KSwgbW9kZWwub3V0cHV0KTtcbiAgICAgICAgbW9kZWwuZXF1YXRpb25zLnB1c2goZXF1YXRpb24pO1xuICAgIH1cbiAgICBpbml0aWFsaXplKCkge1xuICAgICAgICB0aGlzLm1vZGVsID0gdGhpcy5tYXBNb2RlbCgpO1xuICAgIH1cbiAgICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgQHR5cGVzY3JpcHQtZXNsaW50L2Jhbi10cy1jb21tZW50XG4gICAgLy8gQHRzLWV4cGVjdC1lcnJvclxuICAgIG1hcE1vZGVsKCkge1xuICAgICAgICBjb25zdCBhbGxNYXRyaWNlcyA9IFtdO1xuICAgICAgICB0aGlzLmluaXRpYWxMYXllcklucHV0cyA9IHRoaXMub3B0aW9ucy5oaWRkZW5MYXllcnMubWFwKChzaXplKSA9PiBuZXcgTWF0cml4KHNpemUsIDEpKTtcbiAgICAgICAgY29uc3QgaGlkZGVuTGF5ZXJzID0gdGhpcy5jcmVhdGVIaWRkZW5MYXllcnMoKTtcbiAgICAgICAgZm9yIChsZXQgaSA9IDAsIG1heCA9IGhpZGRlbkxheWVycy5sZW5ndGg7IGkgPCBtYXg7IGkrKykge1xuICAgICAgICAgICAgY29uc3QgaGlkZGVuTWF0cml4ID0gaGlkZGVuTGF5ZXJzW2ldO1xuICAgICAgICAgICAgZm9yIChjb25zdCBwcm9wZXJ0eSBpbiBoaWRkZW5NYXRyaXgpIHtcbiAgICAgICAgICAgICAgICBpZiAoIWhpZGRlbk1hdHJpeC5oYXNPd25Qcm9wZXJ0eShwcm9wZXJ0eSkpXG4gICAgICAgICAgICAgICAgICAgIGNvbnRpbnVlO1xuICAgICAgICAgICAgICAgIGFsbE1hdHJpY2VzLnB1c2goaGlkZGVuTWF0cml4W3Byb3BlcnR5XSk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgY29uc3QgeyBvdXRwdXRDb25uZWN0b3IsIG91dHB1dCB9ID0gdGhpcy5jcmVhdGVPdXRwdXRNYXRyaWNlcygpO1xuICAgICAgICBhbGxNYXRyaWNlcy5wdXNoKG91dHB1dENvbm5lY3Rvcik7XG4gICAgICAgIGFsbE1hdHJpY2VzLnB1c2gob3V0cHV0KTtcbiAgICAgICAgcmV0dXJuIE9iamVjdC5zZWFsKHtcbiAgICAgICAgICAgIGlzSW5pdGlhbGl6ZWQ6IHRydWUsXG4gICAgICAgICAgICBoaWRkZW5MYXllcnMsXG4gICAgICAgICAgICBvdXRwdXQsXG4gICAgICAgICAgICBlcXVhdGlvbnM6IFtdLFxuICAgICAgICAgICAgYWxsTWF0cmljZXMsXG4gICAgICAgICAgICBlcXVhdGlvbkNvbm5lY3Rpb25zOiBbXSxcbiAgICAgICAgICAgIG91dHB1dENvbm5lY3RvcixcbiAgICAgICAgfSk7XG4gICAgfVxuICAgIGJhY2twcm9wYWdhdGUoKSB7XG4gICAgICAgIGZvciAobGV0IGkgPSB0aGlzLm1vZGVsLmVxdWF0aW9ucy5sZW5ndGggLSAxOyBpID4gLTE7IGktLSkge1xuICAgICAgICAgICAgdGhpcy5tb2RlbC5lcXVhdGlvbnNbaV0uYmFja3Byb3BhZ2F0ZSgpO1xuICAgICAgICB9XG4gICAgfVxuICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBAdHlwZXNjcmlwdC1lc2xpbnQvYmFuLXRzLWNvbW1lbnRcbiAgICAvLyBAdHMtZXhwZWN0LWVycm9yXG4gICAgcnVuKHJhd0lucHV0KSB7XG4gICAgICAgIGNvbnN0IHNoYXBlID0gbG9va3VwLmRhdGFTaGFwZShyYXdJbnB1dCkuam9pbignLCcpO1xuICAgICAgICBzd2l0Y2ggKHNoYXBlKSB7XG4gICAgICAgICAgICBjYXNlICdhcnJheSxudW1iZXInOlxuICAgICAgICAgICAgICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBAdHlwZXNjcmlwdC1lc2xpbnQvYmFuLXRzLWNvbW1lbnRcbiAgICAgICAgICAgICAgICAvLyBAdHMtZXhwZWN0LWVycm9yXG4gICAgICAgICAgICAgICAgcmV0dXJuIHRoaXMucnVuQXJyYXkocmF3SW5wdXQpO1xuICAgICAgICAgICAgY2FzZSAnYXJyYXksYXJyYXksbnVtYmVyJzpcbiAgICAgICAgICAgICAgICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgQHR5cGVzY3JpcHQtZXNsaW50L2Jhbi10cy1jb21tZW50XG4gICAgICAgICAgICAgICAgLy8gQHRzLWV4cGVjdC1lcnJvclxuICAgICAgICAgICAgICAgIHJldHVybiB0aGlzLnJ1bkFycmF5T2ZBcnJheShyYXdJbnB1dCk7XG4gICAgICAgICAgICBjYXNlICdvYmplY3QsbnVtYmVyJzpcbiAgICAgICAgICAgICAgICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgQHR5cGVzY3JpcHQtZXNsaW50L2Jhbi10cy1jb21tZW50XG4gICAgICAgICAgICAgICAgLy8gQHRzLWV4cGVjdC1lcnJvclxuICAgICAgICAgICAgICAgIHJldHVybiB0aGlzLnJ1bk9iamVjdChyYXdJbnB1dCk7IC8vIEJhY2t3YXJkIGNvbXBhdGliaWxpdHksIHdpbGwgYmUgcmVzdWx0IG9mIGB1bmtub3duYCBhbmQgbmVlZCBjYXN0aW5nLiAgQmV0dGVyIHRvIGp1c3QgdXNlIG5ldC5ydW5PYmplY3QoKSBkaXJlY3RseVxuICAgICAgICAgICAgY2FzZSAnYXJyYXksb2JqZWN0LG51bWJlcic6XG4gICAgICAgICAgICAgICAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIEB0eXBlc2NyaXB0LWVzbGludC9iYW4tdHMtY29tbWVudFxuICAgICAgICAgICAgICAgIC8vIEB0cy1leHBlY3QtZXJyb3JcbiAgICAgICAgICAgICAgICByZXR1cm4gdGhpcy5ydW5BcnJheU9mT2JqZWN0KHJhd0lucHV0KTtcbiAgICAgICAgICAgIGRlZmF1bHQ6XG4gICAgICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKGBVbnJlY29nbml6ZWQgZGF0YSBzaGFwZSAke3NoYXBlfWApO1xuICAgICAgICB9XG4gICAgfVxuICAgIGZvcmVjYXN0KHJhd0lucHV0LCBjb3VudCA9IDEpIHtcbiAgICAgICAgY29uc3Qgc2hhcGUgPSBsb29rdXAuZGF0YVNoYXBlKHJhd0lucHV0KS5qb2luKCcsJyk7XG4gICAgICAgIHN3aXRjaCAoc2hhcGUpIHtcbiAgICAgICAgICAgIGNhc2UgJ2FycmF5LG51bWJlcic6XG4gICAgICAgICAgICAgICAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIEB0eXBlc2NyaXB0LWVzbGludC9iYW4tdHMtY29tbWVudFxuICAgICAgICAgICAgICAgIC8vIEB0cy1leHBlY3QtZXJyb3JcbiAgICAgICAgICAgICAgICByZXR1cm4gdGhpcy5mb3JlY2FzdEFycmF5KHJhd0lucHV0LCBjb3VudCk7XG4gICAgICAgICAgICBjYXNlICdhcnJheSxhcnJheSxudW1iZXInOlxuICAgICAgICAgICAgICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBAdHlwZXNjcmlwdC1lc2xpbnQvYmFuLXRzLWNvbW1lbnRcbiAgICAgICAgICAgICAgICAvLyBAdHMtZXhwZWN0LWVycm9yXG4gICAgICAgICAgICAgICAgcmV0dXJuIHRoaXMuZm9yZWNhc3RBcnJheU9mQXJyYXkocmF3SW5wdXQsIGNvdW50KTtcbiAgICAgICAgICAgIGNhc2UgJ29iamVjdCxudW1iZXInOlxuICAgICAgICAgICAgICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBAdHlwZXNjcmlwdC1lc2xpbnQvYmFuLXRzLWNvbW1lbnRcbiAgICAgICAgICAgICAgICAvLyBAdHMtZXhwZWN0LWVycm9yXG4gICAgICAgICAgICAgICAgcmV0dXJuIHRoaXMucnVuT2JqZWN0KHJhd0lucHV0KTtcbiAgICAgICAgICAgIGNhc2UgJ2FycmF5LG9iamVjdCxudW1iZXInOlxuICAgICAgICAgICAgICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBAdHlwZXNjcmlwdC1lc2xpbnQvYmFuLXRzLWNvbW1lbnRcbiAgICAgICAgICAgICAgICAvLyBAdHMtZXhwZWN0LWVycm9yXG4gICAgICAgICAgICAgICAgcmV0dXJuIHRoaXMuZm9yZWNhc3RBcnJheU9mT2JqZWN0KHJhd0lucHV0LCBjb3VudCk7XG4gICAgICAgICAgICBkZWZhdWx0OlxuICAgICAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcihgVW5yZWNvZ25pemVkIGRhdGEgc2hhcGUgJHtzaGFwZX1gKTtcbiAgICAgICAgfVxuICAgIH1cbiAgICBmb3JlY2FzdEFycmF5KGlucHV0LCBjb3VudCA9IDEpIHtcbiAgICAgICAgdGhpcy5jaGVja1J1bm5hYmxlKCk7XG4gICAgICAgIGNvbnN0IHsgbW9kZWwgfSA9IHRoaXM7XG4gICAgICAgIGNvbnN0IHsgZXF1YXRpb25zIH0gPSBtb2RlbDtcbiAgICAgICAgY29uc3QgbGVuZ3RoID0gaW5wdXQubGVuZ3RoICsgY291bnQ7XG4gICAgICAgIHdoaWxlIChlcXVhdGlvbnMubGVuZ3RoIDw9IGxlbmd0aCkge1xuICAgICAgICAgICAgdGhpcy5iaW5kRXF1YXRpb24oKTtcbiAgICAgICAgfVxuICAgICAgICBsZXQgbGFzdE91dHB1dDtcbiAgICAgICAgbGV0IGVxdWF0aW9uSW5kZXggPSAwO1xuICAgICAgICBpZiAodGhpcy5vcHRpb25zLmlucHV0U2l6ZSA9PT0gMSkge1xuICAgICAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBpbnB1dC5sZW5ndGg7IGkrKykge1xuICAgICAgICAgICAgICAgIGxhc3RPdXRwdXQgPSBlcXVhdGlvbnNbZXF1YXRpb25JbmRleCsrXS5ydW5JbnB1dChGbG9hdDMyQXJyYXkuZnJvbShbaW5wdXRbaV1dKSk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IGlucHV0Lmxlbmd0aDsgaSsrKSB7XG4gICAgICAgICAgICAgICAgbGFzdE91dHB1dCA9IGVxdWF0aW9uc1tlcXVhdGlvbkluZGV4KytdLnJ1bklucHV0KEZsb2F0MzJBcnJheS5mcm9tKFtdKSk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgaWYgKCFsYXN0T3V0cHV0KSB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ2xhc3RPdXRwdXQgbm90IHNldCcpO1xuICAgICAgICB9XG4gICAgICAgIGNvbnN0IHJlc3VsdCA9IFtsYXN0T3V0cHV0LndlaWdodHNbMF1dO1xuICAgICAgICBmb3IgKGxldCBpID0gMCwgbWF4ID0gY291bnQgLSAxOyBpIDwgbWF4OyBpKyspIHtcbiAgICAgICAgICAgIGxhc3RPdXRwdXQgPSBlcXVhdGlvbnNbZXF1YXRpb25JbmRleCsrXS5ydW5JbnB1dChsYXN0T3V0cHV0LndlaWdodHMpO1xuICAgICAgICAgICAgcmVzdWx0LnB1c2gobGFzdE91dHB1dC53ZWlnaHRzWzBdKTtcbiAgICAgICAgfVxuICAgICAgICB0aGlzLmVuZCgpO1xuICAgICAgICByZXR1cm4gRmxvYXQzMkFycmF5LmZyb20ocmVzdWx0KTtcbiAgICB9XG4gICAgZm9yZWNhc3RBcnJheU9mQXJyYXkoaW5wdXQsIGNvdW50ID0gMSkge1xuICAgICAgICB0aGlzLmNoZWNrUnVubmFibGUoKTtcbiAgICAgICAgY29uc3QgeyBtb2RlbCB9ID0gdGhpcztcbiAgICAgICAgY29uc3QgeyBlcXVhdGlvbnMgfSA9IG1vZGVsO1xuICAgICAgICBjb25zdCBsZW5ndGggPSBpbnB1dC5sZW5ndGggKyBjb3VudDtcbiAgICAgICAgd2hpbGUgKGVxdWF0aW9ucy5sZW5ndGggPD0gbGVuZ3RoKSB7XG4gICAgICAgICAgICB0aGlzLmJpbmRFcXVhdGlvbigpO1xuICAgICAgICB9XG4gICAgICAgIGxldCBsYXN0T3V0cHV0O1xuICAgICAgICBsZXQgZXF1YXRpb25JbmRleCA9IDA7XG4gICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgaW5wdXQubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgICAgIGxhc3RPdXRwdXQgPSBlcXVhdGlvbnNbZXF1YXRpb25JbmRleCsrXS5ydW5JbnB1dChpbnB1dFtpXSk7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKCFsYXN0T3V0cHV0KSB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ2xhc3RPdXRwdXQgbm90IHNldCcpO1xuICAgICAgICB9XG4gICAgICAgIGNvbnN0IHJlc3VsdCA9IFtGbG9hdDMyQXJyYXkuZnJvbShsYXN0T3V0cHV0LndlaWdodHMpXTtcbiAgICAgICAgZm9yIChsZXQgaSA9IDAsIG1heCA9IGNvdW50IC0gMTsgaSA8IG1heDsgaSsrKSB7XG4gICAgICAgICAgICBsYXN0T3V0cHV0ID0gZXF1YXRpb25zW2VxdWF0aW9uSW5kZXgrK10ucnVuSW5wdXQobGFzdE91dHB1dC53ZWlnaHRzKTtcbiAgICAgICAgICAgIHJlc3VsdC5wdXNoKEZsb2F0MzJBcnJheS5mcm9tKGxhc3RPdXRwdXQud2VpZ2h0cy5zbGljZSgwKSkpO1xuICAgICAgICB9XG4gICAgICAgIHRoaXMuZW5kKCk7XG4gICAgICAgIHJldHVybiByZXN1bHQ7XG4gICAgfVxuICAgIGZvcmVjYXN0QXJyYXlPZk9iamVjdChpbnB1dCwgY291bnQgPSAxKSB7XG4gICAgICAgIGlmICghdGhpcy5pbnB1dExvb2t1cCkge1xuICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKCd0aGlzLmlucHV0TG9va3VwIG5vdCBzZXQnKTtcbiAgICAgICAgfVxuICAgICAgICBpZiAoIXRoaXMub3V0cHV0TG9va3VwKSB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ3RoaXMub3V0cHV0TG9va3VwIG5vdCBzZXQnKTtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCBmb3JtYXR0ZWREYXRhID0gaW5wdXQubWFwKCh2YWx1ZSkgPT4gbG9va3VwLnRvQXJyYXkodGhpcy5pbnB1dExvb2t1cCwgdmFsdWUsIHRoaXMuaW5wdXRMb29rdXBMZW5ndGgpKTtcbiAgICAgICAgcmV0dXJuIHRoaXMuZm9yZWNhc3RBcnJheU9mQXJyYXkoZm9ybWF0dGVkRGF0YSwgY291bnQpLm1hcCgodmFsdWUpID0+IGxvb2t1cC50b09iamVjdCh0aGlzLm91dHB1dExvb2t1cCwgdmFsdWUpKTtcbiAgICB9XG4gICAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIEB0eXBlc2NyaXB0LWVzbGludC9iYW4tdHMtY29tbWVudFxuICAgIC8vIEB0cy1leHBlY3QtZXJyb3JcbiAgICB0cmFpbihkYXRhLCB0cmFpbk9wdHMgPSB7fSkge1xuICAgICAgICB0aGlzLnRyYWluT3B0cyA9IHRyYWluT3B0cyA9IHtcbiAgICAgICAgICAgIC4uLnRyYWluRGVmYXVsdHMkMSxcbiAgICAgICAgICAgIC4uLnRyYWluT3B0cyxcbiAgICAgICAgfTtcbiAgICAgICAgLy8gRG9uJ3QgZGVzdHJ1Y3R1cmUgaGVyZSBiZWNhdXNlIHRoaXMuc2V0U2l6ZSgpIGNhbiByZXNldCB0aGlzLm9wdGlvbnMuXG4gICAgICAgIGlmICh0aGlzLm9wdGlvbnMuaW5wdXRTaXplID09PSAxICYmIHRoaXMub3B0aW9ucy5vdXRwdXRTaXplID09PSAxKSB7XG4gICAgICAgICAgICB0aGlzLnNldFNpemUoZGF0YSk7XG4gICAgICAgIH1cbiAgICAgICAgdGhpcy52ZXJpZnlTaXplKCk7XG4gICAgICAgIGNvbnN0IGZvcm1hdHRlZERhdGEgPSB0aGlzLmZvcm1hdERhdGEoZGF0YSk7XG4gICAgICAgIGxldCBlcnJvciA9IEluZmluaXR5O1xuICAgICAgICBsZXQgaTtcbiAgICAgICAgdGhpcy52ZXJpZnlJc0luaXRpYWxpemVkKCk7XG4gICAgICAgIGNvbnN0IHsgaXRlcmF0aW9ucywgZXJyb3JUaHJlc2gsIGxvZ1BlcmlvZCwgY2FsbGJhY2ssIGNhbGxiYWNrUGVyaW9kLCB9ID0gdGhpcy50cmFpbk9wdHM7XG4gICAgICAgIGNvbnN0IGxvZyA9IHRyYWluT3B0cy5sb2cgPT09IHRydWUgPyBjb25zb2xlLmxvZyA6IHRyYWluT3B0cy5sb2c7XG4gICAgICAgIGZvciAoaSA9IDA7IGkgPCBpdGVyYXRpb25zICYmIGVycm9yID4gZXJyb3JUaHJlc2g7IGkrKykge1xuICAgICAgICAgICAgbGV0IHN1bSA9IDA7XG4gICAgICAgICAgICBmb3IgKGxldCBqID0gMDsgaiA8IGZvcm1hdHRlZERhdGEubGVuZ3RoOyBqKyspIHtcbiAgICAgICAgICAgICAgICBjb25zdCBlcnIgPSB0aGlzLnRyYWluUGF0dGVybihmb3JtYXR0ZWREYXRhW2pdLCB0cnVlKTtcbiAgICAgICAgICAgICAgICBzdW0gKz0gZXJyO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZXJyb3IgPSBzdW0gLyBmb3JtYXR0ZWREYXRhLmxlbmd0aDtcbiAgICAgICAgICAgIGlmIChpc05hTihlcnJvcikpXG4gICAgICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdOZXR3b3JrIGVycm9yIHJhdGUgaXMgdW5leHBlY3RlZCBOYU4sIGNoZWNrIG5ldHdvcmsgY29uZmlndXJhdGlvbnMgYW5kIHRyeSBhZ2Fpbi4gTW9zdCBwcm9iYWJseSBpbnB1dCBmb3JtYXQgaXMgbm90IGNvcnJlY3Qgb3IgdHJhaW5pbmcgZGF0YSBpcyBub3QgZW5vdWdoLiAnKTtcbiAgICAgICAgICAgIGlmIChsb2cgJiYgaSAlIGxvZ1BlcmlvZCA9PT0gMCkge1xuICAgICAgICAgICAgICAgIGxvZyhgaXRlcmF0aW9uczogJHtpfSwgdHJhaW5pbmcgZXJyb3I6ICR7ZXJyb3J9YCk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBpZiAoY2FsbGJhY2sgJiYgaSAlIGNhbGxiYWNrUGVyaW9kID09PSAwKSB7XG4gICAgICAgICAgICAgICAgY2FsbGJhY2soeyBlcnJvciwgaXRlcmF0aW9uczogaSB9KTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgZXJyb3IsXG4gICAgICAgICAgICBpdGVyYXRpb25zOiBpLFxuICAgICAgICB9O1xuICAgIH1cbiAgICB0cmFpbkFycmF5T2ZBcnJheShpbnB1dCkge1xuICAgICAgICBpZiAoaW5wdXQubGVuZ3RoIDwgMikge1xuICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdpbnB1dCBtdXN0IGJlIGFuIGFycmF5IG9mIDIgb3IgbW9yZScpO1xuICAgICAgICB9XG4gICAgICAgIGNvbnN0IHsgZXF1YXRpb25zIH0gPSB0aGlzLm1vZGVsO1xuICAgICAgICB3aGlsZSAoZXF1YXRpb25zLmxlbmd0aCA8IGlucHV0Lmxlbmd0aCkge1xuICAgICAgICAgICAgdGhpcy5iaW5kRXF1YXRpb24oKTtcbiAgICAgICAgfVxuICAgICAgICBsZXQgZXJyb3JTdW0gPSAwO1xuICAgICAgICBmb3IgKGxldCBpID0gMCwgbWF4ID0gaW5wdXQubGVuZ3RoIC0gMTsgaSA8IG1heDsgaSsrKSB7XG4gICAgICAgICAgICBlcnJvclN1bSArPSBlcXVhdGlvbnNbaV0ucHJlZGljdFRhcmdldChpbnB1dFtpXSwgaW5wdXRbaSArIDFdKTtcbiAgICAgICAgfVxuICAgICAgICB0aGlzLmVuZCgpO1xuICAgICAgICByZXR1cm4gZXJyb3JTdW0gLyBpbnB1dC5sZW5ndGg7XG4gICAgfVxuICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBAdHlwZXNjcmlwdC1lc2xpbnQvYmFuLXRzLWNvbW1lbnRcbiAgICAvLyBAdHMtZXhwZWN0LWVycm9yXG4gICAgdHJhaW5QYXR0ZXJuKGlucHV0LCBsb2dFcnJvclJhdGUpIHtcbiAgICAgICAgY29uc3QgZXJyb3IgPSB0aGlzLnRyYWluQXJyYXlPZkFycmF5KGlucHV0KTtcbiAgICAgICAgdGhpcy5iYWNrcHJvcGFnYXRlKCk7XG4gICAgICAgIHRoaXMuYWRqdXN0V2VpZ2h0cygpO1xuICAgICAgICBpZiAobG9nRXJyb3JSYXRlKSB7XG4gICAgICAgICAgICByZXR1cm4gZXJyb3I7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIDA7XG4gICAgfVxuICAgIHNldFNpemUoZGF0YSkge1xuICAgICAgICBsZXQgc2l6ZSA9IDA7XG4gICAgICAgIGNvbnN0IGRhdGFTaGFwZSA9IGxvb2t1cC5kYXRhU2hhcGUoZGF0YSkuam9pbignLCcpO1xuICAgICAgICBzd2l0Y2ggKGRhdGFTaGFwZSkge1xuICAgICAgICAgICAgY2FzZSAnYXJyYXksYXJyYXksbnVtYmVyJzpcbiAgICAgICAgICAgIGNhc2UgJ2FycmF5LG9iamVjdCxudW1iZXInOlxuICAgICAgICAgICAgY2FzZSAnYXJyYXksZGF0dW0sYXJyYXksbnVtYmVyJzpcbiAgICAgICAgICAgIGNhc2UgJ2FycmF5LGRhdHVtLG9iamVjdCxudW1iZXInOlxuICAgICAgICAgICAgICAgIHNpemUgPSAxO1xuICAgICAgICAgICAgICAgIC8vIHByb2JhYmx5IDFcbiAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgIGNhc2UgJ2FycmF5LGFycmF5LGFycmF5LG51bWJlcic6XG4gICAgICAgICAgICAgICAgc2l6ZSA9IGRhdGFbMF1bMF0ubGVuZ3RoO1xuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgY2FzZSAnYXJyYXksYXJyYXksb2JqZWN0LG51bWJlcic6XG4gICAgICAgICAgICAgICAgLy8gaW5wdXRzIGFuZCBvdXRwdXRzIHNob3VsZCBtYXRjaFxuICAgICAgICAgICAgICAgIHNpemUgPSBPYmplY3Qua2V5cyhsb29rdXAudG9UYWJsZTJEKGRhdGEpKS5sZW5ndGg7XG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICBjYXNlICdhcnJheSxkYXR1bSxhcnJheSxhcnJheSxudW1iZXInOlxuICAgICAgICAgICAgICAgIHNpemUgPSBkYXRhWzBdLmlucHV0WzBdLmxlbmd0aDtcbiAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgIGNhc2UgJ2FycmF5LGRhdHVtLGFycmF5LG9iamVjdCxudW1iZXInOlxuICAgICAgICAgICAgICAgIHNpemUgPSBPYmplY3Qua2V5cyhsb29rdXAudG9JbnB1dFRhYmxlMkQoZGF0YSkpLmxlbmd0aDtcbiAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgIGRlZmF1bHQ6XG4gICAgICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKCd1bmtub3duIGRhdGEgc2hhcGUgb3IgY29uZmlndXJhdGlvbicpO1xuICAgICAgICB9XG4gICAgICAgIHRoaXMub3B0aW9ucyA9IE9iamVjdC5zZWFsKHtcbiAgICAgICAgICAgIC4uLnRoaXMub3B0aW9ucyxcbiAgICAgICAgICAgIGlucHV0U2l6ZTogc2l6ZSxcbiAgICAgICAgICAgIG91dHB1dFNpemU6IHNpemUsXG4gICAgICAgIH0pO1xuICAgIH1cbiAgICB2ZXJpZnlTaXplKCkge1xuICAgICAgICBpZiAodGhpcy5vcHRpb25zLmlucHV0U2l6ZSB8fCB0aGlzLm9wdGlvbnMub3V0cHV0U2l6ZSkge1xuICAgICAgICAgICAgaWYgKHRoaXMub3B0aW9ucy5pbnB1dFNpemUgIT09IHRoaXMub3B0aW9ucy5vdXRwdXRTaXplKSB7XG4gICAgICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdtYW51YWxseSBzZXQgaW5wdXRTaXplIGFuZCBvdXRwdXRTaXplIG1pc21hdGNoJyk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9XG4gICAgcnVuQXJyYXkoaW5wdXQpIHtcbiAgICAgICAgdGhpcy5jaGVja1J1bm5hYmxlKCk7XG4gICAgICAgIGNvbnN0IHsgZXF1YXRpb25zIH0gPSB0aGlzLm1vZGVsO1xuICAgICAgICB3aGlsZSAoZXF1YXRpb25zLmxlbmd0aCA8PSBpbnB1dC5sZW5ndGgpIHtcbiAgICAgICAgICAgIHRoaXMuYmluZEVxdWF0aW9uKCk7XG4gICAgICAgIH1cbiAgICAgICAgbGV0IGxhc3RPdXRwdXQ7XG4gICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgaW5wdXQubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgICAgIGxhc3RPdXRwdXQgPSBlcXVhdGlvbnNbaV0ucnVuSW5wdXQobmV3IEZsb2F0MzJBcnJheShbaW5wdXRbaV1dKSk7XG4gICAgICAgIH1cbiAgICAgICAgdGhpcy5lbmQoKTtcbiAgICAgICAgcmV0dXJuIGxhc3RPdXRwdXQud2VpZ2h0c1swXTtcbiAgICB9XG4gICAgcnVuQXJyYXlPZkFycmF5KGlucHV0KSB7XG4gICAgICAgIHRoaXMuY2hlY2tSdW5uYWJsZSgpO1xuICAgICAgICBjb25zdCB7IG1vZGVsIH0gPSB0aGlzO1xuICAgICAgICBjb25zdCB7IGVxdWF0aW9ucyB9ID0gbW9kZWw7XG4gICAgICAgIHdoaWxlIChlcXVhdGlvbnMubGVuZ3RoIDw9IGlucHV0Lmxlbmd0aCkge1xuICAgICAgICAgICAgdGhpcy5iaW5kRXF1YXRpb24oKTtcbiAgICAgICAgfVxuICAgICAgICBsZXQgbGFzdE91dHB1dDtcbiAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBpbnB1dC5sZW5ndGg7IGkrKykge1xuICAgICAgICAgICAgY29uc3Qgb3V0cHV0TWF0cml4ID0gZXF1YXRpb25zW2ldLnJ1bklucHV0KGlucHV0W2ldKTtcbiAgICAgICAgICAgIGxhc3RPdXRwdXQgPSBvdXRwdXRNYXRyaXgud2VpZ2h0cztcbiAgICAgICAgfVxuICAgICAgICB0aGlzLmVuZCgpO1xuICAgICAgICByZXR1cm4gbGFzdE91dHB1dCAhPT0gbnVsbCAmJiBsYXN0T3V0cHV0ICE9PSB2b2lkIDAgPyBsYXN0T3V0cHV0IDogRmxvYXQzMkFycmF5LmZyb20oW10pO1xuICAgIH1cbiAgICBydW5PYmplY3QoaW5wdXQpIHtcbiAgICAgICAgaWYgKCF0aGlzLmlucHV0TG9va3VwKSB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ3RoaXMuaW5wdXRMb29rdXAgbm90IHNldCcpO1xuICAgICAgICB9XG4gICAgICAgIGlmICghdGhpcy5vdXRwdXRMb29rdXApIHtcbiAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcigndGhpcy5vdXRwdXRMb29rdXAgbm90IHNldCcpO1xuICAgICAgICB9XG4gICAgICAgIGlmICghdGhpcy5vdXRwdXRMb29rdXBMZW5ndGgpIHtcbiAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcigndGhpcy5vdXRwdXRMb29rdXBMZW5ndGggbm90IHNldCcpO1xuICAgICAgICB9XG4gICAgICAgIGlmICh0aGlzLmlucHV0TG9va3VwID09PSB0aGlzLm91dHB1dExvb2t1cCkge1xuICAgICAgICAgICAgY29uc3QgaW5wdXRBcnJheSA9IGxvb2t1cC50b0FycmF5U2hvcnQodGhpcy5pbnB1dExvb2t1cCwgaW5wdXQpO1xuICAgICAgICAgICAgcmV0dXJuIGxvb2t1cC50b09iamVjdFBhcnRpYWwodGhpcy5vdXRwdXRMb29rdXAsIHRoaXMuZm9yZWNhc3RBcnJheShpbnB1dEFycmF5LCB0aGlzLm91dHB1dExvb2t1cExlbmd0aCAtIGlucHV0QXJyYXkubGVuZ3RoKSwgaW5wdXRBcnJheS5sZW5ndGgpO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBsb29rdXAudG9PYmplY3QodGhpcy5vdXRwdXRMb29rdXAsIHRoaXMuZm9yZWNhc3RBcnJheShsb29rdXAudG9BcnJheSh0aGlzLmlucHV0TG9va3VwLCBpbnB1dCwgdGhpcy5pbnB1dExvb2t1cExlbmd0aCksIHRoaXMub3V0cHV0TG9va3VwTGVuZ3RoKSk7XG4gICAgfVxuICAgIHJ1bkFycmF5T2ZPYmplY3QoaW5wdXQpIHtcbiAgICAgICAgaWYgKHRoaXMuaW5wdXRMb29rdXAgPT09IG51bGwpIHtcbiAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcigndGhpcy5pbnB1dExvb2t1cCBub3Qgc2V0Jyk7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKHRoaXMub3V0cHV0TG9va3VwID09PSBudWxsKSB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ3RoaXMub3V0cHV0TG9va3VwIG5vdCBzZXQnKTtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCBmb3JtYXR0ZWRJbnB1dCA9IGlucHV0Lm1hcCgodmFsdWUpID0+IGxvb2t1cC50b0FycmF5KHRoaXMuaW5wdXRMb29rdXAsIHZhbHVlLCB0aGlzLmlucHV0TG9va3VwTGVuZ3RoKSk7XG4gICAgICAgIHJldHVybiB0aGlzLmZvcmVjYXN0QXJyYXlPZkFycmF5KGZvcm1hdHRlZElucHV0LCAxKS5tYXAoKHZhbHVlKSA9PiBsb29rdXAudG9PYmplY3QodGhpcy5vdXRwdXRMb29rdXAsIHZhbHVlKSlbMF07XG4gICAgfVxuICAgIHJ1bkFycmF5T2ZPYmplY3RPZkFycmF5KGlucHV0KSB7XG4gICAgICAgIGlmICghdGhpcy5pbnB1dExvb2t1cCkge1xuICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKCd0aGlzLmlucHV0TG9va3VwIG5vdCBzZXQnKTtcbiAgICAgICAgfVxuICAgICAgICBpZiAoIXRoaXMub3V0cHV0TG9va3VwKSB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ3RoaXMub3V0cHV0TG9va3VwIG5vdCBzZXQnKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gbG9va3VwLnRvT2JqZWN0KHRoaXMub3V0cHV0TG9va3VwLCB0aGlzLnJ1bkFycmF5T2ZBcnJheShsb29rdXAudG9BcnJheXModGhpcy5pbnB1dExvb2t1cCwgaW5wdXQsIHRoaXMuaW5wdXRMb29rdXBMZW5ndGgpKSk7XG4gICAgfVxuICAgIGVuZCgpIHtcbiAgICAgICAgdGhpcy5tb2RlbC5lcXVhdGlvbnNbdGhpcy5tb2RlbC5lcXVhdGlvbnMubGVuZ3RoIC0gMV0ucnVuSW5wdXQobmV3IEZsb2F0MzJBcnJheSh0aGlzLm9wdGlvbnMub3V0cHV0U2l6ZSkpO1xuICAgIH1cbiAgICByZXF1aXJlSW5wdXRPdXRwdXRPZk9uZSgpIHtcbiAgICAgICAgaWYgKHRoaXMub3B0aW9ucy5pbnB1dFNpemUgIT09IDEpIHtcbiAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcignaW5wdXRTaXplIG11c3QgYmUgMSBmb3IgdGhpcyBkYXRhIHNpemUnKTtcbiAgICAgICAgfVxuICAgICAgICBpZiAodGhpcy5vcHRpb25zLm91dHB1dFNpemUgIT09IDEpIHtcbiAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcignb3V0cHV0U2l6ZSBtdXN0IGJlIDEgZm9yIHRoaXMgZGF0YSBzaXplJyk7XG4gICAgICAgIH1cbiAgICB9XG4gICAgLy8gSGFuZGxlcyBkYXRhIHNoYXBlIG9mICdhcnJheSxudW1iZXInXG4gICAgZm9ybWF0QXJyYXkoZGF0YSkge1xuICAgICAgICBjb25zdCByZXN1bHQgPSBbXTtcbiAgICAgICAgdGhpcy5yZXF1aXJlSW5wdXRPdXRwdXRPZk9uZSgpO1xuICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IGRhdGEubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgICAgIHJlc3VsdC5wdXNoKEZsb2F0MzJBcnJheS5mcm9tKFtkYXRhW2ldXSkpO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBbcmVzdWx0XTtcbiAgICB9XG4gICAgLy8gSGFuZGxlcyBkYXRhIHNoYXBlIG9mICdhcnJheSxhcnJheSxudW1iZXInXG4gICAgZm9ybWF0QXJyYXlPZkFycmF5KGRhdGEpIHtcbiAgICAgICAgY29uc3QgcmVzdWx0ID0gW107XG4gICAgICAgIGNvbnN0IHsgaW5wdXRTaXplLCBvdXRwdXRTaXplIH0gPSB0aGlzLm9wdGlvbnM7XG4gICAgICAgIGlmIChpbnB1dFNpemUgPT09IDEgJiYgb3V0cHV0U2l6ZSA9PT0gMSkge1xuICAgICAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBkYXRhLmxlbmd0aDsgaSsrKSB7XG4gICAgICAgICAgICAgICAgcmVzdWx0LnB1c2goYXJyYXlUb0Zsb2F0MzJBcnJheXMoZGF0YVtpXSkpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgcmV0dXJuIHJlc3VsdDtcbiAgICAgICAgfVxuICAgICAgICBpZiAoaW5wdXRTaXplICE9PSBkYXRhWzBdLmxlbmd0aCkge1xuICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdpbnB1dFNpemUgbXVzdCBtYXRjaCBkYXRhIGlucHV0IHNpemUnKTtcbiAgICAgICAgfVxuICAgICAgICBpZiAob3V0cHV0U2l6ZSAhPT0gZGF0YVswXS5sZW5ndGgpIHtcbiAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcignb3V0cHV0U2l6ZSBtdXN0IG1hdGNoIGRhdGEgb3V0cHV0IHNpemUnKTtcbiAgICAgICAgfVxuICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IGRhdGEubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgICAgIHJlc3VsdC5wdXNoKEZsb2F0MzJBcnJheS5mcm9tKGRhdGFbaV0pKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gW3Jlc3VsdF07XG4gICAgfVxuICAgIC8vIEhhbmRsZXMgZGF0YSBzaGFwZSBvZiAnYXJyYXksb2JqZWN0LG51bWJlcidcbiAgICBmb3JtYXRBcnJheU9mT2JqZWN0KGRhdGEpIHtcbiAgICAgICAgdGhpcy5yZXF1aXJlSW5wdXRPdXRwdXRPZk9uZSgpO1xuICAgICAgICBpZiAoIXRoaXMuaW5wdXRMb29rdXApIHtcbiAgICAgICAgICAgIGNvbnN0IGxvb2t1cFRhYmxlID0gbmV3IExvb2t1cFRhYmxlKGRhdGEpO1xuICAgICAgICAgICAgdGhpcy5pbnB1dExvb2t1cCA9IHRoaXMub3V0cHV0TG9va3VwID0gbG9va3VwVGFibGUudGFibGU7XG4gICAgICAgICAgICB0aGlzLmlucHV0TG9va3VwTGVuZ3RoID0gdGhpcy5vdXRwdXRMb29rdXBMZW5ndGggPSBsb29rdXBUYWJsZS5sZW5ndGg7XG4gICAgICAgIH1cbiAgICAgICAgY29uc3QgcmVzdWx0ID0gW107XG4gICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgZGF0YS5sZW5ndGg7IGkrKykge1xuICAgICAgICAgICAgcmVzdWx0LnB1c2gob2JqZWN0VG9GbG9hdDMyQXJyYXlzKGRhdGFbaV0pKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gcmVzdWx0O1xuICAgIH1cbiAgICAvLyBIYW5kbGVzIGRhdGEgc2hhcGUgb2YgJ2FycmF5LG9iamVjdCxudW1iZXInIHdoZW4gdGhpcy5vcHRpb25zLmlucHV0U2l6ZSA+IDFcbiAgICBmb3JtYXRBcnJheU9mT2JqZWN0TXVsdGkoZGF0YSkge1xuICAgICAgICBpZiAoIXRoaXMuaW5wdXRMb29rdXApIHtcbiAgICAgICAgICAgIGNvbnN0IGxvb2t1cFRhYmxlID0gbmV3IExvb2t1cFRhYmxlKGRhdGEpO1xuICAgICAgICAgICAgdGhpcy5pbnB1dExvb2t1cCA9IHRoaXMub3V0cHV0TG9va3VwID0gbG9va3VwVGFibGUudGFibGU7XG4gICAgICAgICAgICB0aGlzLmlucHV0TG9va3VwTGVuZ3RoID0gdGhpcy5vdXRwdXRMb29rdXBMZW5ndGggPSBsb29rdXBUYWJsZS5sZW5ndGg7XG4gICAgICAgIH1cbiAgICAgICAgY29uc3QgcmVzdWx0ID0gW107XG4gICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgZGF0YS5sZW5ndGg7IGkrKykge1xuICAgICAgICAgICAgcmVzdWx0LnB1c2goW1xuICAgICAgICAgICAgICAgIG9iamVjdFRvRmxvYXQzMkFycmF5KGRhdGFbaV0sIHRoaXMuaW5wdXRMb29rdXAsIHRoaXMuaW5wdXRMb29rdXBMZW5ndGgpLFxuICAgICAgICAgICAgXSk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHJlc3VsdDtcbiAgICB9XG4gICAgLy8gSGFuZGxlcyBkYXRhIHNoYXBlIG9mICdhcnJheSxkYXR1bSxhcnJheSxudW1iZXInXG4gICAgZm9ybWF0QXJyYXlPZkRhdHVtT2ZBcnJheShkYXRhKSB7XG4gICAgICAgIGNvbnN0IHJlc3VsdCA9IFtdO1xuICAgICAgICB0aGlzLnJlcXVpcmVJbnB1dE91dHB1dE9mT25lKCk7XG4gICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgZGF0YS5sZW5ndGg7IGkrKykge1xuICAgICAgICAgICAgY29uc3QgZGF0dW0gPSBkYXRhW2ldO1xuICAgICAgICAgICAgcmVzdWx0LnB1c2goaW5wdXRPdXRwdXRBcnJheVRvRmxvYXQzMkFycmF5cyhkYXR1bS5pbnB1dCwgZGF0dW0ub3V0cHV0KSk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHJlc3VsdDtcbiAgICB9XG4gICAgLy8gSGFuZGxlcyBkYXRhIHNoYXBlIG9mICdhcnJheSxkYXR1bSxvYmplY3QsbnVtYmVyJ1xuICAgIGZvcm1hdEFycmF5T2ZEYXR1bU9mT2JqZWN0KGRhdGEpIHtcbiAgICAgICAgdGhpcy5yZXF1aXJlSW5wdXRPdXRwdXRPZk9uZSgpO1xuICAgICAgICBpZiAoIXRoaXMuaW5wdXRMb29rdXApIHtcbiAgICAgICAgICAgIGNvbnN0IGlucHV0TG9va3VwID0gbmV3IExvb2t1cFRhYmxlKGRhdGEsICdpbnB1dCcpO1xuICAgICAgICAgICAgdGhpcy5pbnB1dExvb2t1cCA9IGlucHV0TG9va3VwLnRhYmxlO1xuICAgICAgICAgICAgdGhpcy5pbnB1dExvb2t1cExlbmd0aCA9IGlucHV0TG9va3VwLmxlbmd0aDtcbiAgICAgICAgfVxuICAgICAgICBpZiAoIXRoaXMub3V0cHV0TG9va3VwKSB7XG4gICAgICAgICAgICBjb25zdCBvdXRwdXRMb29rdXAgPSBuZXcgTG9va3VwVGFibGUoZGF0YSwgJ291dHB1dCcpO1xuICAgICAgICAgICAgdGhpcy5vdXRwdXRMb29rdXAgPSBvdXRwdXRMb29rdXAudGFibGU7XG4gICAgICAgICAgICB0aGlzLm91dHB1dExvb2t1cExlbmd0aCA9IG91dHB1dExvb2t1cC5sZW5ndGg7XG4gICAgICAgIH1cbiAgICAgICAgY29uc3QgcmVzdWx0ID0gW107XG4gICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgZGF0YS5sZW5ndGg7IGkrKykge1xuICAgICAgICAgICAgY29uc3QgZGF0dW0gPSBkYXRhW2ldO1xuICAgICAgICAgICAgcmVzdWx0LnB1c2goaW5wdXRPdXRwdXRPYmplY3RUb0Zsb2F0MzJBcnJheXMoZGF0dW0uaW5wdXQsIGRhdHVtLm91dHB1dCkpO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiByZXN1bHQ7XG4gICAgfVxuICAgIC8vIEhhbmRsZXMgZGF0YSBzaGFwZSBvZiAnYXJyYXksYXJyYXksYXJyYXksbnVtYmVyJ1xuICAgIGZvcm1hdEFycmF5T2ZBcnJheU9mQXJyYXkoZGF0YSkge1xuICAgICAgICBjb25zdCByZXN1bHQgPSBbXTtcbiAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBkYXRhLmxlbmd0aDsgaSsrKSB7XG4gICAgICAgICAgICByZXN1bHQucHVzaChhcnJheXNUb0Zsb2F0MzJBcnJheXMoZGF0YVtpXSkpO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiByZXN1bHQ7XG4gICAgfVxuICAgIC8vIEhhbmRsZXMgZGF0YSBzaGFwZSBvZiAnYXJyYXksYXJyYXksb2JqZWN0LG51bWJlcidcbiAgICBmb3JtYXRBcnJheU9mQXJyYXlPZk9iamVjdChkYXRhKSB7XG4gICAgICAgIGlmICghdGhpcy5pbnB1dExvb2t1cCkge1xuICAgICAgICAgICAgY29uc3QgbG9va3VwVGFibGUgPSBuZXcgTG9va3VwVGFibGUoZGF0YSk7XG4gICAgICAgICAgICB0aGlzLmlucHV0TG9va3VwID0gdGhpcy5vdXRwdXRMb29rdXAgPSBsb29rdXBUYWJsZS50YWJsZTtcbiAgICAgICAgICAgIHRoaXMuaW5wdXRMb29rdXBMZW5ndGggPSB0aGlzLm91dHB1dExvb2t1cExlbmd0aCA9IGxvb2t1cFRhYmxlLmxlbmd0aDtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCByZXN1bHQgPSBbXTtcbiAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBkYXRhLmxlbmd0aDsgaSsrKSB7XG4gICAgICAgICAgICBjb25zdCBhcnJheSA9IFtdO1xuICAgICAgICAgICAgZm9yIChsZXQgaiA9IDA7IGogPCBkYXRhW2ldLmxlbmd0aDsgaisrKSB7XG4gICAgICAgICAgICAgICAgYXJyYXkucHVzaChvYmplY3RUb0Zsb2F0MzJBcnJheShkYXRhW2ldW2pdLCB0aGlzLmlucHV0TG9va3VwLCB0aGlzLmlucHV0TG9va3VwTGVuZ3RoKSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICByZXN1bHQucHVzaChhcnJheSk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHJlc3VsdDtcbiAgICB9XG4gICAgLy8gSGFuZGxlcyBkYXRhIHNoYXBlIG9mICdhcnJheSxkYXR1bSxhcnJheSxhcnJheSxudW1iZXInXG4gICAgZm9ybWF0QXJyYXlPZkRhdHVtT2ZBcnJheU9mQXJyYXkoZGF0YSkge1xuICAgICAgICBjb25zdCByZXN1bHQgPSBbXTtcbiAgICAgICAgY29uc3QgeyBpbnB1dFNpemUsIG91dHB1dFNpemUgfSA9IHRoaXMub3B0aW9ucztcbiAgICAgICAgaWYgKGlucHV0U2l6ZSAhPT0gZGF0YVswXS5pbnB1dFswXS5sZW5ndGgpIHtcbiAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcignaW5wdXRTaXplIG11c3QgbWF0Y2ggZGF0YSBpbnB1dCBzaXplJyk7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKG91dHB1dFNpemUgIT09IGRhdGFbMF0ub3V0cHV0WzBdLmxlbmd0aCkge1xuICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdvdXRwdXRTaXplIG11c3QgbWF0Y2ggZGF0YSBvdXRwdXQgc2l6ZScpO1xuICAgICAgICB9XG4gICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgZGF0YS5sZW5ndGg7IGkrKykge1xuICAgICAgICAgICAgY29uc3QgZGF0dW0gPSBkYXRhW2ldO1xuICAgICAgICAgICAgcmVzdWx0LnB1c2goaW5wdXRPdXRwdXRBcnJheXNUb0Zsb2F0MzJBcnJheXMoZGF0dW0uaW5wdXQsIGRhdHVtLm91dHB1dCkpO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiByZXN1bHQ7XG4gICAgfVxuICAgIC8vICdIYW5kbGVzIGRhdGEgc2hhcGUgb2YgYXJyYXksZGF0dW0sYXJyYXksb2JqZWN0LG51bWJlcidcbiAgICBmb3JtYXRBcnJheU9mRGF0dW1PZkFycmF5T2ZPYmplY3QoZGF0YSkge1xuICAgICAgICBpZiAoIXRoaXMuaW5wdXRMb29rdXApIHtcbiAgICAgICAgICAgIGNvbnN0IGlucHV0TG9va3VwID0gbmV3IEFycmF5TG9va3VwVGFibGUoZGF0YSwgJ2lucHV0Jyk7XG4gICAgICAgICAgICB0aGlzLmlucHV0TG9va3VwID0gaW5wdXRMb29rdXAudGFibGU7XG4gICAgICAgICAgICB0aGlzLmlucHV0TG9va3VwTGVuZ3RoID0gaW5wdXRMb29rdXAubGVuZ3RoO1xuICAgICAgICB9XG4gICAgICAgIGlmICghdGhpcy5vdXRwdXRMb29rdXApIHtcbiAgICAgICAgICAgIGNvbnN0IG91dHB1dExvb2t1cCA9IG5ldyBBcnJheUxvb2t1cFRhYmxlKGRhdGEsICdvdXRwdXQnKTtcbiAgICAgICAgICAgIHRoaXMub3V0cHV0TG9va3VwID0gb3V0cHV0TG9va3VwLnRhYmxlO1xuICAgICAgICAgICAgdGhpcy5vdXRwdXRMb29rdXBMZW5ndGggPSBvdXRwdXRMb29rdXAubGVuZ3RoO1xuICAgICAgICB9XG4gICAgICAgIGlmICghdGhpcy5vdXRwdXRMb29rdXBMZW5ndGgpIHtcbiAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcigndGhpcy5vdXRwdXRMb29rdXBMZW5ndGggbm90IHNldCB0byB1c2FibGUgbnVtYmVyJyk7XG4gICAgICAgIH1cbiAgICAgICAgY29uc3QgcmVzdWx0ID0gW107XG4gICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgZGF0YS5sZW5ndGg7IGkrKykge1xuICAgICAgICAgICAgY29uc3QgZGF0dW0gPSBkYXRhW2ldO1xuICAgICAgICAgICAgcmVzdWx0LnB1c2goaW5wdXRPdXRwdXRPYmplY3RzVG9GbG9hdDMyQXJyYXlzKGRhdHVtLmlucHV0LCBkYXR1bS5vdXRwdXQsIHRoaXMuaW5wdXRMb29rdXAsIHRoaXMub3V0cHV0TG9va3VwLCB0aGlzLmlucHV0TG9va3VwTGVuZ3RoLCB0aGlzLm91dHB1dExvb2t1cExlbmd0aCkpO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiByZXN1bHQ7XG4gICAgfVxuICAgIGZvcm1hdERhdGEoZGF0YSkge1xuICAgICAgICBjb25zdCBkYXRhU2hhcGUgPSBsb29rdXAuZGF0YVNoYXBlKGRhdGEpLmpvaW4oJywnKTtcbiAgICAgICAgc3dpdGNoIChkYXRhU2hhcGUpIHtcbiAgICAgICAgICAgIGNhc2UgJ2FycmF5LG51bWJlcic6XG4gICAgICAgICAgICAgICAgcmV0dXJuIHRoaXMuZm9ybWF0QXJyYXkoZGF0YSk7XG4gICAgICAgICAgICBjYXNlICdhcnJheSxhcnJheSxudW1iZXInOlxuICAgICAgICAgICAgICAgIHJldHVybiB0aGlzLmZvcm1hdEFycmF5T2ZBcnJheShkYXRhKTtcbiAgICAgICAgICAgIGNhc2UgJ2FycmF5LG9iamVjdCxudW1iZXInOlxuICAgICAgICAgICAgICAgIGlmICh0aGlzLm9wdGlvbnMuaW5wdXRTaXplID09PSAxKSB7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiB0aGlzLmZvcm1hdEFycmF5T2ZPYmplY3QoZGF0YSk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gdGhpcy5mb3JtYXRBcnJheU9mT2JqZWN0TXVsdGkoZGF0YSk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgY2FzZSAnYXJyYXksZGF0dW0sYXJyYXksbnVtYmVyJzpcbiAgICAgICAgICAgICAgICByZXR1cm4gdGhpcy5mb3JtYXRBcnJheU9mRGF0dW1PZkFycmF5KGRhdGEpO1xuICAgICAgICAgICAgY2FzZSAnYXJyYXksZGF0dW0sb2JqZWN0LG51bWJlcic6XG4gICAgICAgICAgICAgICAgcmV0dXJuIHRoaXMuZm9ybWF0QXJyYXlPZkRhdHVtT2ZPYmplY3QoZGF0YSk7XG4gICAgICAgICAgICBjYXNlICdhcnJheSxhcnJheSxhcnJheSxudW1iZXInOlxuICAgICAgICAgICAgICAgIHJldHVybiB0aGlzLmZvcm1hdEFycmF5T2ZBcnJheU9mQXJyYXkoZGF0YSk7XG4gICAgICAgICAgICBjYXNlICdhcnJheSxhcnJheSxvYmplY3QsbnVtYmVyJzpcbiAgICAgICAgICAgICAgICByZXR1cm4gdGhpcy5mb3JtYXRBcnJheU9mQXJyYXlPZk9iamVjdChkYXRhKTtcbiAgICAgICAgICAgIGNhc2UgJ2FycmF5LGRhdHVtLGFycmF5LGFycmF5LG51bWJlcic6XG4gICAgICAgICAgICAgICAgcmV0dXJuIHRoaXMuZm9ybWF0QXJyYXlPZkRhdHVtT2ZBcnJheU9mQXJyYXkoZGF0YSk7XG4gICAgICAgICAgICBjYXNlICdhcnJheSxkYXR1bSxhcnJheSxvYmplY3QsbnVtYmVyJzpcbiAgICAgICAgICAgICAgICByZXR1cm4gdGhpcy5mb3JtYXRBcnJheU9mRGF0dW1PZkFycmF5T2ZPYmplY3QoZGF0YSk7XG4gICAgICAgICAgICBkZWZhdWx0OlxuICAgICAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcigndW5rbm93biBkYXRhIHNoYXBlIG9yIGNvbmZpZ3VyYXRpb24nKTtcbiAgICAgICAgfVxuICAgIH1cbiAgICB0ZXN0KGRhdGEpIHtcbiAgICAgICAgLy8gZm9yIGNsYXNzaWZpY2F0aW9uIHByb2JsZW1zXG4gICAgICAgIGNvbnN0IG1pc2NsYXNzZXMgPSBbXTtcbiAgICAgICAgLy8gcnVuIGVhY2ggcGF0dGVybiB0aHJvdWdoIHRoZSB0cmFpbmVkIG5ldHdvcmsgYW5kIGNvbGxlY3RcbiAgICAgICAgLy8gZXJyb3IgYW5kIG1pc2NsYXNzaWZpY2F0aW9uIHN0YXRpc3RpY3NcbiAgICAgICAgbGV0IGVycm9yU3VtID0gMDtcbiAgICAgICAgY29uc3QgZm9ybWF0dGVkRGF0YSA9IHRoaXMuZm9ybWF0RGF0YShkYXRhKTtcbiAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBmb3JtYXR0ZWREYXRhLmxlbmd0aDsgaSsrKSB7XG4gICAgICAgICAgICBjb25zdCBpbnB1dCA9IGZvcm1hdHRlZERhdGFbaV07XG4gICAgICAgICAgICBjb25zdCBvdXRwdXQgPSB0aGlzLnJ1bihpbnB1dC5zcGxpY2UoMCwgaW5wdXQubGVuZ3RoIC0gMSkpO1xuICAgICAgICAgICAgY29uc3QgdGFyZ2V0ID0gaW5wdXRbaW5wdXQubGVuZ3RoIC0gMV07XG4gICAgICAgICAgICBsZXQgZXJyb3JzID0gMDtcbiAgICAgICAgICAgIGxldCBlcnJvckNvdW50ID0gMDtcbiAgICAgICAgICAgIGZvciAobGV0IGogPSAwOyBqIDwgb3V0cHV0Lmxlbmd0aDsgaisrKSB7XG4gICAgICAgICAgICAgICAgZXJyb3JDb3VudCsrO1xuICAgICAgICAgICAgICAgIGNvbnN0IGVycm9yID0gdGFyZ2V0W2pdIC0gb3V0cHV0W2pdO1xuICAgICAgICAgICAgICAgIC8vIG1zZVxuICAgICAgICAgICAgICAgIGVycm9ycyArPSBlcnJvciAqIGVycm9yO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZXJyb3JTdW0gKz0gZXJyb3JzIC8gZXJyb3JDb3VudDtcbiAgICAgICAgICAgIGNvbnN0IGVycm9yc0FicyA9IE1hdGguYWJzKGVycm9ycyk7XG4gICAgICAgICAgICBpZiAoZXJyb3JzQWJzID4gdGhpcy50cmFpbk9wdHMuZXJyb3JUaHJlc2gpIHtcbiAgICAgICAgICAgICAgICBjb25zdCBtaXNjbGFzcyA9IGRhdGFbaV07XG4gICAgICAgICAgICAgICAgbWlzY2xhc3Nlcy5wdXNoKHtcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU6IG1pc2NsYXNzLFxuICAgICAgICAgICAgICAgICAgICBhY3R1YWw6IG91dHB1dCxcbiAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgZXJyb3I6IGVycm9yU3VtIC8gZm9ybWF0dGVkRGF0YS5sZW5ndGgsXG4gICAgICAgICAgICBtaXNjbGFzc2VzLFxuICAgICAgICAgICAgdG90YWw6IGZvcm1hdHRlZERhdGEubGVuZ3RoLFxuICAgICAgICB9O1xuICAgIH1cbiAgICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgQHR5cGVzY3JpcHQtZXNsaW50L2Jhbi10cy1jb21tZW50XG4gICAgLy8gQHRzLWV4cGVjdC1lcnJvclxuICAgIGFkZEZvcm1hdCh2YWx1ZSkge1xuICAgICAgICB2YXIgX2EsIF9iLCBfYywgX2QsIF9lLCBfZjtcbiAgICAgICAgY29uc3QgZGF0YVNoYXBlID0gbG9va3VwLmRhdGFTaGFwZSh2YWx1ZSkuam9pbignLCcpO1xuICAgICAgICBzd2l0Y2ggKGRhdGFTaGFwZSkge1xuICAgICAgICAgICAgY2FzZSAnYXJyYXksYXJyYXksbnVtYmVyJzpcbiAgICAgICAgICAgIGNhc2UgJ2RhdHVtLGFycmF5LGFycmF5LG51bWJlcic6XG4gICAgICAgICAgICBjYXNlICdhcnJheSxudW1iZXInOlxuICAgICAgICAgICAgY2FzZSAnZGF0dW0sYXJyYXksbnVtYmVyJzpcbiAgICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICBjYXNlICdkYXR1bSxvYmplY3QsbnVtYmVyJzoge1xuICAgICAgICAgICAgICAgIHRoaXMuaW5wdXRMb29rdXAgPSBsb29rdXAuYWRkS2V5cyh2YWx1ZS5pbnB1dCwgKF9hID0gdGhpcy5pbnB1dExvb2t1cCkgIT09IG51bGwgJiYgX2EgIT09IHZvaWQgMCA/IF9hIDoge30pO1xuICAgICAgICAgICAgICAgIGlmICh0aGlzLmlucHV0TG9va3VwKSB7XG4gICAgICAgICAgICAgICAgICAgIHRoaXMuaW5wdXRMb29rdXBMZW5ndGggPSBPYmplY3Qua2V5cyh0aGlzLmlucHV0TG9va3VwKS5sZW5ndGg7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIHRoaXMub3V0cHV0TG9va3VwID0gbG9va3VwLmFkZEtleXModmFsdWUub3V0cHV0LCAoX2IgPSB0aGlzLm91dHB1dExvb2t1cCkgIT09IG51bGwgJiYgX2IgIT09IHZvaWQgMCA/IF9iIDoge30pO1xuICAgICAgICAgICAgICAgIGlmICh0aGlzLm91dHB1dExvb2t1cCkge1xuICAgICAgICAgICAgICAgICAgICB0aGlzLm91dHB1dExvb2t1cExlbmd0aCA9IE9iamVjdC5rZXlzKHRoaXMub3V0cHV0TG9va3VwKS5sZW5ndGg7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgY2FzZSAnb2JqZWN0LG51bWJlcic6IHtcbiAgICAgICAgICAgICAgICB0aGlzLmlucHV0TG9va3VwID0gdGhpcy5vdXRwdXRMb29rdXAgPSBsb29rdXAuYWRkS2V5cyh2YWx1ZSwgKF9jID0gdGhpcy5pbnB1dExvb2t1cCkgIT09IG51bGwgJiYgX2MgIT09IHZvaWQgMCA/IF9jIDoge30pO1xuICAgICAgICAgICAgICAgIGlmICh0aGlzLmlucHV0TG9va3VwKSB7XG4gICAgICAgICAgICAgICAgICAgIHRoaXMuaW5wdXRMb29rdXBMZW5ndGggPSB0aGlzLm91dHB1dExvb2t1cExlbmd0aCA9IE9iamVjdC5rZXlzKHRoaXMuaW5wdXRMb29rdXApLmxlbmd0aDtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBjYXNlICdhcnJheSxvYmplY3QsbnVtYmVyJzoge1xuICAgICAgICAgICAgICAgIGNvbnN0IHR5cGVkVmFsdWUgPSB2YWx1ZTtcbiAgICAgICAgICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IHR5cGVkVmFsdWUubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5pbnB1dExvb2t1cCA9IHRoaXMub3V0cHV0TG9va3VwID0gbG9va3VwLmFkZEtleXModHlwZWRWYWx1ZVtpXSwgKF9kID0gdGhpcy5pbnB1dExvb2t1cCkgIT09IG51bGwgJiYgX2QgIT09IHZvaWQgMCA/IF9kIDoge30pO1xuICAgICAgICAgICAgICAgICAgICBpZiAodGhpcy5pbnB1dExvb2t1cCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5pbnB1dExvb2t1cExlbmd0aCA9IHRoaXMub3V0cHV0TG9va3VwTGVuZ3RoID0gT2JqZWN0LmtleXModGhpcy5pbnB1dExvb2t1cCkubGVuZ3RoO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgY2FzZSAnZGF0dW0sYXJyYXksb2JqZWN0LG51bWJlcic6IHtcbiAgICAgICAgICAgICAgICBjb25zdCB0eXBlZFZhbHVlID0gdmFsdWU7XG4gICAgICAgICAgICAgICAgY29uc3QgdHlwZWRJbnB1dCA9IHR5cGVkVmFsdWUuaW5wdXQ7XG4gICAgICAgICAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCB0eXBlZElucHV0Lmxlbmd0aDsgaSsrKSB7XG4gICAgICAgICAgICAgICAgICAgIHRoaXMuaW5wdXRMb29rdXAgPSBsb29rdXAuYWRkS2V5cyh0eXBlZElucHV0W2ldLCAoX2UgPSB0aGlzLmlucHV0TG9va3VwKSAhPT0gbnVsbCAmJiBfZSAhPT0gdm9pZCAwID8gX2UgOiB7fSk7XG4gICAgICAgICAgICAgICAgICAgIGlmICh0aGlzLmlucHV0TG9va3VwKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLmlucHV0TG9va3VwTGVuZ3RoID0gT2JqZWN0LmtleXModGhpcy5pbnB1dExvb2t1cCkubGVuZ3RoO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGNvbnN0IHR5cGVkT3V0cHV0ID0gdHlwZWRWYWx1ZS5vdXRwdXQ7XG4gICAgICAgICAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCB0eXBlZE91dHB1dC5sZW5ndGg7IGkrKykge1xuICAgICAgICAgICAgICAgICAgICB0aGlzLm91dHB1dExvb2t1cCA9IGxvb2t1cC5hZGRLZXlzKHR5cGVkT3V0cHV0W2ldLCAoX2YgPSB0aGlzLm91dHB1dExvb2t1cCkgIT09IG51bGwgJiYgX2YgIT09IHZvaWQgMCA/IF9mIDoge30pO1xuICAgICAgICAgICAgICAgICAgICBpZiAodGhpcy5vdXRwdXRMb29rdXApIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMub3V0cHV0TG9va3VwTGVuZ3RoID0gT2JqZWN0LmtleXModGhpcy5vdXRwdXRMb29rdXApLmxlbmd0aDtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGRlZmF1bHQ6XG4gICAgICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKCd1bmtub3duIGRhdGEgc2hhcGUgb3IgY29uZmlndXJhdGlvbicpO1xuICAgICAgICB9XG4gICAgfVxuICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBAdHlwZXNjcmlwdC1lc2xpbnQvYmFuLXRzLWNvbW1lbnRcbiAgICAvLyBAdHMtZXhwZWN0LWVycm9yXG4gICAgdG9KU09OKCkge1xuICAgICAgICBpZiAoIXRoaXMubW9kZWwpIHtcbiAgICAgICAgICAgIHRoaXMuaW5pdGlhbGl6ZSgpO1xuICAgICAgICB9XG4gICAgICAgIGNvbnN0IHsgbW9kZWwgfSA9IHRoaXM7XG4gICAgICAgIGNvbnN0IG9wdGlvbnMgPSB7IC4uLnRoaXMub3B0aW9ucywgLi4uZGVmYXVsdHMkMSB9O1xuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgdHlwZTogdGhpcy5jb25zdHJ1Y3Rvci5uYW1lLFxuICAgICAgICAgICAgb3B0aW9ucyxcbiAgICAgICAgICAgIGhpZGRlbkxheWVyczogbW9kZWwuaGlkZGVuTGF5ZXJzLm1hcCgoaGlkZGVuTGF5ZXIpID0+IHtcbiAgICAgICAgICAgICAgICBjb25zdCBsYXllcnMgPSB7fTtcbiAgICAgICAgICAgICAgICBmb3IgKGNvbnN0IHAgaW4gaGlkZGVuTGF5ZXIpIHtcbiAgICAgICAgICAgICAgICAgICAgaWYgKCFoaWRkZW5MYXllci5oYXNPd25Qcm9wZXJ0eShwKSlcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnRpbnVlO1xuICAgICAgICAgICAgICAgICAgICBsYXllcnNbcF0gPSBoaWRkZW5MYXllcltwXS50b0pTT04oKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgcmV0dXJuIGxheWVycztcbiAgICAgICAgICAgIH0pLFxuICAgICAgICAgICAgb3V0cHV0Q29ubmVjdG9yOiBtb2RlbC5vdXRwdXRDb25uZWN0b3IudG9KU09OKCksXG4gICAgICAgICAgICBvdXRwdXQ6IG1vZGVsLm91dHB1dC50b0pTT04oKSxcbiAgICAgICAgICAgIGlucHV0TG9va3VwOiB0aGlzLmlucHV0TG9va3VwLFxuICAgICAgICAgICAgaW5wdXRMb29rdXBMZW5ndGg6IHRoaXMuaW5wdXRMb29rdXBMZW5ndGgsXG4gICAgICAgICAgICBvdXRwdXRMb29rdXA6IHRoaXMub3V0cHV0TG9va3VwLFxuICAgICAgICAgICAgb3V0cHV0TG9va3VwTGVuZ3RoOiB0aGlzLm91dHB1dExvb2t1cExlbmd0aCxcbiAgICAgICAgfTtcbiAgICB9XG4gICAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIEB0eXBlc2NyaXB0LWVzbGludC9iYW4tdHMtY29tbWVudFxuICAgIC8vIEB0cy1leHBlY3QtZXJyb3JcbiAgICBmcm9tSlNPTihqc29uKSB7XG4gICAgICAgIGNvbnN0IHsgb3B0aW9ucyB9ID0ganNvbjtcbiAgICAgICAgY29uc3QgYWxsTWF0cmljZXMgPSBbXTtcbiAgICAgICAgY29uc3QgaGlkZGVuTGF5ZXJzID0gW107XG4gICAgICAgIC8vIGJhY2t3YXJkIGNvbXBhdGliaWxpdHkgZm9yIGhpZGRlblNpemVzXG4gICAgICAgIGpzb24uaGlkZGVuTGF5ZXJzLmZvckVhY2goKGhpZGRlbkxheWVyKSA9PiB7XG4gICAgICAgICAgICBjb25zdCBsYXllcnMgPSB7fTtcbiAgICAgICAgICAgIGZvciAoY29uc3QgcCBpbiBoaWRkZW5MYXllcikge1xuICAgICAgICAgICAgICAgIGxheWVyc1twXSA9IE1hdHJpeC5mcm9tSlNPTihoaWRkZW5MYXllcltwXSk7XG4gICAgICAgICAgICAgICAgYWxsTWF0cmljZXMucHVzaChsYXllcnNbcF0pO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaGlkZGVuTGF5ZXJzLnB1c2gobGF5ZXJzKTtcbiAgICAgICAgfSk7XG4gICAgICAgIGNvbnN0IG91dHB1dENvbm5lY3RvciA9IE1hdHJpeC5mcm9tSlNPTihqc29uLm91dHB1dENvbm5lY3Rvcik7XG4gICAgICAgIGFsbE1hdHJpY2VzLnB1c2gob3V0cHV0Q29ubmVjdG9yKTtcbiAgICAgICAgY29uc3Qgb3V0cHV0ID0gTWF0cml4LmZyb21KU09OKGpzb24ub3V0cHV0KTtcbiAgICAgICAgYWxsTWF0cmljZXMucHVzaChvdXRwdXQpO1xuICAgICAgICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgQHR5cGVzY3JpcHQtZXNsaW50L2Jhbi10cy1jb21tZW50XG4gICAgICAgIC8vIEB0cy1leHBlY3QtZXJyb3JcbiAgICAgICAgdGhpcy5vcHRpb25zID0geyAuLi5kZWZhdWx0cygpLCAuLi5vcHRpb25zIH07XG4gICAgICAgIHRoaXMuaW5wdXRMb29rdXAgPSBqc29uLmlucHV0TG9va3VwO1xuICAgICAgICB0aGlzLmlucHV0TG9va3VwTGVuZ3RoID0ganNvbi5pbnB1dExvb2t1cExlbmd0aDtcbiAgICAgICAgdGhpcy5vdXRwdXRMb29rdXAgPSBqc29uLm91dHB1dExvb2t1cDtcbiAgICAgICAgdGhpcy5vdXRwdXRMb29rdXBMZW5ndGggPSBqc29uLm91dHB1dExvb2t1cExlbmd0aDtcbiAgICAgICAgdGhpcy5tb2RlbCA9IE9iamVjdC5zZWFsKHtcbiAgICAgICAgICAgIGlzSW5pdGlhbGl6ZWQ6IHRydWUsXG4gICAgICAgICAgICBoaWRkZW5MYXllcnMsXG4gICAgICAgICAgICBvdXRwdXQsXG4gICAgICAgICAgICBhbGxNYXRyaWNlcyxcbiAgICAgICAgICAgIG91dHB1dENvbm5lY3RvcixcbiAgICAgICAgICAgIGVxdWF0aW9uczogW10sXG4gICAgICAgICAgICBlcXVhdGlvbkNvbm5lY3Rpb25zOiBbXSxcbiAgICAgICAgfSk7XG4gICAgICAgIHRoaXMuaW5pdGlhbExheWVySW5wdXRzID0gb3B0aW9ucy5oaWRkZW5MYXllcnMubWFwKChzaXplKSA9PiBuZXcgTWF0cml4KHNpemUsIDEpKTtcbiAgICAgICAgdGhpcy5iaW5kRXF1YXRpb24oKTtcbiAgICAgICAgcmV0dXJuIHRoaXM7XG4gICAgfVxuICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBAdHlwZXNjcmlwdC1lc2xpbnQvYmFuLXRzLWNvbW1lbnRcbiAgICAvLyBAdHMtZXhwZWN0LWVycm9yXG4gICAgdG9GdW5jdGlvbihjYikge1xuICAgICAgICBjb25zdCB7IG1vZGVsLCBpbnB1dExvb2t1cCwgaW5wdXRMb29rdXBMZW5ndGgsIG91dHB1dExvb2t1cCwgb3V0cHV0TG9va3VwTGVuZ3RoLCB9ID0gdGhpcztcbiAgICAgICAgY29uc3QgeyBpbnB1dFNpemUgfSA9IHRoaXMub3B0aW9ucztcbiAgICAgICAgY29uc3QgeyBlcXVhdGlvbnMgfSA9IG1vZGVsO1xuICAgICAgICBjb25zdCBlcXVhdGlvbiA9IGVxdWF0aW9uc1sxXTtcbiAgICAgICAgY29uc3QgeyBzdGF0ZXMgfSA9IGVxdWF0aW9uO1xuICAgICAgICBjb25zdCBqc29uU3RyaW5nID0gSlNPTi5zdHJpbmdpZnkodGhpcy50b0pTT04oKSk7XG4gICAgICAgIGZ1bmN0aW9uIHByZXZpb3VzQ29ubmVjdGlvbkluZGV4KG0pIHtcbiAgICAgICAgICAgIGNvbnN0IGNvbm5lY3Rpb24gPSBtb2RlbC5lcXVhdGlvbkNvbm5lY3Rpb25zWzBdO1xuICAgICAgICAgICAgY29uc3QgeyBzdGF0ZXMgfSA9IGVxdWF0aW9uc1swXTtcbiAgICAgICAgICAgIGZvciAobGV0IGkgPSAwLCBtYXggPSBzdGF0ZXMubGVuZ3RoOyBpIDwgbWF4OyBpKyspIHtcbiAgICAgICAgICAgICAgICBpZiAoc3RhdGVzW2ldLnByb2R1Y3QgPT09IG0pIHtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgcmV0dXJuIGNvbm5lY3Rpb24uaW5kZXhPZihtKTtcbiAgICAgICAgfVxuICAgICAgICBmdW5jdGlvbiBtYXRyaXhPcmlnaW4obSwgc3RhdGVJbmRleCkge1xuICAgICAgICAgICAgZm9yIChsZXQgaSA9IDAsIG1heCA9IHN0YXRlcy5sZW5ndGg7IGkgPCBtYXg7IGkrKykge1xuICAgICAgICAgICAgICAgIGNvbnN0IHN0YXRlID0gc3RhdGVzW2ldO1xuICAgICAgICAgICAgICAgIGlmIChpID09PSBzdGF0ZUluZGV4KSB7XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IGogPSBwcmV2aW91c0Nvbm5lY3Rpb25JbmRleChtKTtcbiAgICAgICAgICAgICAgICAgICAgc3dpdGNoIChtKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBjYXNlIHN0YXRlLmxlZnQ6XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGogPiAtMSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gYHR5cGVvZiBwcmV2U3RhdGVzWyR7an1dID09PSAnb2JqZWN0JyA/IHByZXZTdGF0ZXNbJHtqfV0ucHJvZHVjdCA6IG5ldyBNYXRyaXgoJHttLnJvd3N9LCAke20uY29sdW1uc30pYDtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgbm8tZmFsbHRocm91Z2hcbiAgICAgICAgICAgICAgICAgICAgICAgIGNhc2Ugc3RhdGUucmlnaHQ6XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGogPiAtMSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gYHR5cGVvZiBwcmV2U3RhdGVzWyR7an1dID09PSAnb2JqZWN0JyA/IHByZXZTdGF0ZXNbJHtqfV0ucHJvZHVjdCA6IG5ldyBNYXRyaXgoJHttLnJvd3N9LCAke20uY29sdW1uc30pYDtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgbm8tZmFsbHRocm91Z2hcbiAgICAgICAgICAgICAgICAgICAgICAgIGNhc2Ugc3RhdGUucHJvZHVjdDpcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gYG5ldyBNYXRyaXgoJHttLnJvd3N9LCAke20uY29sdW1uc30pYDtcbiAgICAgICAgICAgICAgICAgICAgICAgIGRlZmF1bHQ6XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdGhyb3cgRXJyb3IoJ3Vua25vd24gc3RhdGUnKTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBpZiAobSA9PT0gc3RhdGUucHJvZHVjdClcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGBzdGF0ZXNbJHtpfV0ucHJvZHVjdGA7XG4gICAgICAgICAgICAgICAgaWYgKG0gPT09IHN0YXRlLnJpZ2h0KVxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gYHN0YXRlc1ske2l9XS5yaWdodGA7XG4gICAgICAgICAgICAgICAgaWYgKG0gPT09IHN0YXRlLmxlZnQpXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBgc3RhdGVzWyR7aX1dLmxlZnRgO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgcmV0dXJuICcnO1xuICAgICAgICB9XG4gICAgICAgIGZ1bmN0aW9uIG1hdHJpeFRvU3RyaW5nKG0sIHN0YXRlSW5kZXgpIHtcbiAgICAgICAgICAgIGlmICghbSB8fCAhbS5yb3dzIHx8ICFtLmNvbHVtbnMpXG4gICAgICAgICAgICAgICAgcmV0dXJuICdudWxsJztcbiAgICAgICAgICAgIGlmIChtID09PSBtb2RlbC5vdXRwdXRDb25uZWN0b3IpXG4gICAgICAgICAgICAgICAgcmV0dXJuIGBqc29uLm91dHB1dENvbm5lY3RvcmA7XG4gICAgICAgICAgICBpZiAobSA9PT0gbW9kZWwub3V0cHV0KVxuICAgICAgICAgICAgICAgIHJldHVybiBganNvbi5vdXRwdXRgO1xuICAgICAgICAgICAgZm9yIChsZXQgaSA9IDAsIG1heCA9IG1vZGVsLmhpZGRlbkxheWVycy5sZW5ndGg7IGkgPCBtYXg7IGkrKykge1xuICAgICAgICAgICAgICAgIGNvbnN0IGhpZGRlbkxheWVyID0gbW9kZWwuaGlkZGVuTGF5ZXJzW2ldO1xuICAgICAgICAgICAgICAgIGZvciAoY29uc3QgcCBpbiBoaWRkZW5MYXllcikge1xuICAgICAgICAgICAgICAgICAgICBpZiAoIWhpZGRlbkxheWVyLmhhc093blByb3BlcnR5KHApKVxuICAgICAgICAgICAgICAgICAgICAgICAgY29udGludWU7XG4gICAgICAgICAgICAgICAgICAgIGlmIChoaWRkZW5MYXllcltwXSAhPT0gbSlcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnRpbnVlO1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gYGpzb24uaGlkZGVuTGF5ZXJzWyR7aX1dLiR7cH1gO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHJldHVybiBtYXRyaXhPcmlnaW4obSwgc3RhdGVJbmRleCk7XG4gICAgICAgIH1cbiAgICAgICAgZnVuY3Rpb24gZm9ybWF0SW5wdXREYXRhKCkge1xuICAgICAgICAgICAgaWYgKCFpbnB1dExvb2t1cClcbiAgICAgICAgICAgICAgICByZXR1cm4gJyc7XG4gICAgICAgICAgICBpZiAoaW5wdXRTaXplID09PSAxKSB7XG4gICAgICAgICAgICAgICAgaWYgKGlucHV0TG9va3VwID09PSBvdXRwdXRMb29rdXApIHtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGBmdW5jdGlvbiBsb29rdXBJbnB1dChpbnB1dCkge1xuICAgICAgICAgICAgdmFyIHRhYmxlID0gJHtKU09OLnN0cmluZ2lmeShpbnB1dExvb2t1cCl9O1xuICAgICAgICAgICAgdmFyIHJlc3VsdCA9IFtdO1xuICAgICAgICAgICAgZm9yICh2YXIgcCBpbiB0YWJsZSkge1xuICAgICAgICAgICAgICBpZiAoIWlucHV0Lmhhc093blByb3BlcnR5KHApKSBicmVhaztcbiAgICAgICAgICAgICAgcmVzdWx0LnB1c2goRmxvYXQzMkFycmF5LmZyb20oW2lucHV0W3BdXSkpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgcmV0dXJuIHJlc3VsdDtcbiAgICAgICAgICB9YDtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgcmV0dXJuIGBmdW5jdGlvbiBsb29rdXBJbnB1dChpbnB1dCkge1xuICAgICAgICAgIHZhciB0YWJsZSA9ICR7SlNPTi5zdHJpbmdpZnkoaW5wdXRMb29rdXApfTtcbiAgICAgICAgICB2YXIgcmVzdWx0ID0gW107XG4gICAgICAgICAgZm9yICh2YXIgcCBpbiB0YWJsZSkge1xuICAgICAgICAgICAgcmVzdWx0LnB1c2goRmxvYXQzMkFycmF5LmZyb20oW2lucHV0W3BdXSkpO1xuICAgICAgICAgIH1cbiAgICAgICAgICByZXR1cm4gcmVzdWx0O1xuICAgICAgICB9YDtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHJldHVybiBgZnVuY3Rpb24gbG9va3VwSW5wdXQocmF3SW5wdXRzKSB7XG4gICAgICAgIHZhciB0YWJsZSA9ICR7SlNPTi5zdHJpbmdpZnkoaW5wdXRMb29rdXApfTtcbiAgICAgICAgdmFyIHJlc3VsdCA9IFtdO1xuICAgICAgICBmb3IgKHZhciBpID0gMDsgaSA8IHJhd0lucHV0cy5sZW5ndGg7IGkrKykge1xuICAgICAgICAgIHZhciByYXdJbnB1dCA9IHJhd0lucHV0c1tpXTtcbiAgICAgICAgICB2YXIgaW5wdXQgPSBuZXcgRmxvYXQzMkFycmF5KCR7aW5wdXRMb29rdXBMZW5ndGh9KTtcbiAgICAgICAgICBmb3IgKHZhciBwIGluIHRhYmxlKSB7XG4gICAgICAgICAgICBpbnB1dFt0YWJsZVtwXV0gPSByYXdJbnB1dC5oYXNPd25Qcm9wZXJ0eShwKSA/IHJhd0lucHV0W3BdIDogMDtcbiAgICAgICAgICB9XG4gICAgICAgICAgcmVzdWx0LnB1c2goaW5wdXQpO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiByZXN1bHQ7XG4gICAgICB9YDtcbiAgICAgICAgfVxuICAgICAgICBmdW5jdGlvbiBmb3JtYXRPdXRwdXREYXRhKCkge1xuICAgICAgICAgICAgaWYgKCFvdXRwdXRMb29rdXApXG4gICAgICAgICAgICAgICAgcmV0dXJuICcnO1xuICAgICAgICAgICAgaWYgKGlucHV0U2l6ZSA9PT0gMSkge1xuICAgICAgICAgICAgICAgIGlmIChpbnB1dExvb2t1cCA9PT0gb3V0cHV0TG9va3VwKSB7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBgZnVuY3Rpb24gbG9va3VwT3V0cHV0UGFydGlhbChvdXRwdXQsIGlucHV0KSB7XG4gICAgICAgICAgICB2YXIgdGFibGUgPSAke0pTT04uc3RyaW5naWZ5KG91dHB1dExvb2t1cCl9O1xuICAgICAgICAgICAgdmFyIG9mZnNldCA9IGlucHV0Lmxlbmd0aDtcbiAgICAgICAgICAgIHZhciByZXN1bHQgPSB7fTtcbiAgICAgICAgICAgIHZhciBpID0gMDtcbiAgICAgICAgICAgIGZvciAodmFyIHAgaW4gdGFibGUpIHtcbiAgICAgICAgICAgICAgaWYgKGkrKyA8IG9mZnNldCkgY29udGludWU7XG4gICAgICAgICAgICAgIHJlc3VsdFtwXSA9IG91dHB1dFt0YWJsZVtwXSAtIG9mZnNldF1bMF07XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICByZXR1cm4gcmVzdWx0O1xuICAgICAgICAgIH1gO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICByZXR1cm4gYGZ1bmN0aW9uIGxvb2t1cE91dHB1dChvdXRwdXQpIHtcbiAgICAgICAgICB2YXIgdGFibGUgPSAke0pTT04uc3RyaW5naWZ5KG91dHB1dExvb2t1cCl9O1xuICAgICAgICAgIHZhciByZXN1bHQgPSB7fTtcbiAgICAgICAgICBmb3IgKHZhciBwIGluIHRhYmxlKSB7XG4gICAgICAgICAgICByZXN1bHRbcF0gPSBvdXRwdXRbdGFibGVbcF1dWzBdO1xuICAgICAgICAgIH1cbiAgICAgICAgICByZXR1cm4gcmVzdWx0O1xuICAgICAgICB9YDtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHJldHVybiBgZnVuY3Rpb24gbG9va3VwT3V0cHV0KG91dHB1dCkge1xuICAgICAgICB2YXIgdGFibGUgPSAke0pTT04uc3RyaW5naWZ5KG91dHB1dExvb2t1cCl9O1xuICAgICAgICB2YXIgcmVzdWx0ID0ge307XG4gICAgICAgIGZvciAodmFyIHAgaW4gdGFibGUpIHtcbiAgICAgICAgICByZXN1bHRbcF0gPSBvdXRwdXRbdGFibGVbcF1dO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiByZXN1bHQ7XG4gICAgICB9YDtcbiAgICAgICAgfVxuICAgICAgICBmdW5jdGlvbiB0b0lubmVyKGZuU3RyaW5nKSB7XG4gICAgICAgICAgICAvLyBjcnVkZSwgYnV0IHNob3VsZCBiZSBzdWZmaWNpZW50IGZvciBub3dcbiAgICAgICAgICAgIC8vIGZ1bmN0aW9uKCkgeyBib2R5IH1cbiAgICAgICAgICAgIC8vIGNydWRlLCBidXQgc2hvdWxkIGJlIHN1ZmZpY2llbnQgZm9yIG5vd1xuICAgICAgICAgICAgLy8gZnVuY3Rpb24oKSB7IGJvZHkgfVxuICAgICAgICAgICAgY29uc3QgZm5QYXJ0cyA9IGZuU3RyaW5nLnRvU3RyaW5nKCkuc3BsaXQoJ3snKTtcbiAgICAgICAgICAgIGZuUGFydHMuc2hpZnQoKTtcbiAgICAgICAgICAgIC8vIGJvZHkgfVxuICAgICAgICAgICAgY29uc3QgZm5Cb2R5U3RyaW5nID0gZm5QYXJ0cy5qb2luKCd7Jyk7XG4gICAgICAgICAgICBjb25zdCBmbkJvZHlQYXJ0cyA9IGZuQm9keVN0cmluZy5zcGxpdCgnfScpO1xuICAgICAgICAgICAgZm5Cb2R5UGFydHMucG9wKCk7XG4gICAgICAgICAgICAvLyBib2R5XG4gICAgICAgICAgICByZXR1cm4gZm5Cb2R5UGFydHNcbiAgICAgICAgICAgICAgICAuam9pbignfScpXG4gICAgICAgICAgICAgICAgLnNwbGl0KCdcXG4nKVxuICAgICAgICAgICAgICAgIC5qb2luKCdcXG4gICAgICAgICcpXG4gICAgICAgICAgICAgICAgLnJlcGxhY2UoJ3Byb2R1Y3QuZGVsdGFzW2ldID0gMDsnLCAnJylcbiAgICAgICAgICAgICAgICAucmVwbGFjZSgncHJvZHVjdC5kZWx0YXNbY29sdW1uXSA9IDA7JywgJycpXG4gICAgICAgICAgICAgICAgLnJlcGxhY2UoJ2xlZnQuZGVsdGFzW2xlZnRJbmRleF0gPSAwOycsICcnKVxuICAgICAgICAgICAgICAgIC5yZXBsYWNlKCdyaWdodC5kZWx0YXNbcmlnaHRJbmRleF0gPSAwOycsICcnKVxuICAgICAgICAgICAgICAgIC5yZXBsYWNlKCdwcm9kdWN0LmRlbHRhcyA9IGxlZnQuZGVsdGFzLnNsaWNlKDApOycsICcnKTtcbiAgICAgICAgfVxuICAgICAgICBmdW5jdGlvbiBmaWxlTmFtZShmbk5hbWUpIHtcbiAgICAgICAgICAgIHJldHVybiBgc3JjL3JlY3VycmVudC9tYXRyaXgvJHtmbk5hbWUucmVwbGFjZSgvW0EtWl0vZywgZnVuY3Rpb24gKHZhbHVlKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIGAtJHt2YWx1ZS50b0xvd2VyQ2FzZSgpfWA7XG4gICAgICAgICAgICB9KX0uanNgO1xuICAgICAgICB9XG4gICAgICAgIGNvbnN0IHN0YXRlc1JhdyA9IFtdO1xuICAgICAgICBjb25zdCB1c2VkRnVuY3Rpb25OYW1lcyA9IHt9O1xuICAgICAgICBjb25zdCBpbm5lckZ1bmN0aW9uc1N3aXRjaCA9IFtdO1xuICAgICAgICBmb3IgKGxldCBpID0gMCwgbWF4ID0gc3RhdGVzLmxlbmd0aDsgaSA8IG1heDsgaSsrKSB7XG4gICAgICAgICAgICBjb25zdCBzdGF0ZSA9IHN0YXRlc1tpXTtcbiAgICAgICAgICAgIHN0YXRlc1Jhdy5wdXNoKGBzdGF0ZXNbJHtpfV0gPSB7XG4gICAgICBuYW1lOiAnJHtzdGF0ZS5mb3J3YXJkRm4ubmFtZX0nLFxuICAgICAgbGVmdDogJHtzdGF0ZS5sZWZ0ID8gbWF0cml4VG9TdHJpbmcoc3RhdGUubGVmdCwgaSkgOiAndW5kZWZpbmVkJ30sXG4gICAgICByaWdodDogJHtzdGF0ZS5yaWdodCA/IG1hdHJpeFRvU3RyaW5nKHN0YXRlLnJpZ2h0LCBpKSA6ICd1bmRlZmluZWQnfSxcbiAgICAgIHByb2R1Y3Q6ICR7bWF0cml4VG9TdHJpbmcoc3RhdGUucHJvZHVjdCwgaSl9XG4gICAgfWApO1xuICAgICAgICAgICAgY29uc3QgZm5OYW1lID0gc3RhdGUuZm9yd2FyZEZuLm5hbWU7XG4gICAgICAgICAgICBpZiAoIXVzZWRGdW5jdGlvbk5hbWVzW2ZuTmFtZV0pIHtcbiAgICAgICAgICAgICAgICB1c2VkRnVuY3Rpb25OYW1lc1tmbk5hbWVdID0gdHJ1ZTtcbiAgICAgICAgICAgICAgICBpZiAoc3RhdGUubmFtZSA9PT0gJ2lucHV0Jykge1xuICAgICAgICAgICAgICAgICAgICBpbm5lckZ1bmN0aW9uc1N3aXRjaC5wdXNoKGBjYXNlICcke2ZuTmFtZX0nOmApO1xuICAgICAgICAgICAgICAgICAgICBpbm5lckZ1bmN0aW9uc1N3aXRjaC5wdXNoKGlucHV0TG9va3VwICYmIGlucHV0U2l6ZSA9PT0gMVxuICAgICAgICAgICAgICAgICAgICAgICAgPyAncHJvZHVjdC53ZWlnaHRzID0gX2kgPCBpbnB1dC5sZW5ndGggPyBpbnB1dFtfaV06IHByZXZTdGF0ZXNbcHJldlN0YXRlcy5sZW5ndGggLSAxXS5wcm9kdWN0LndlaWdodHM7J1xuICAgICAgICAgICAgICAgICAgICAgICAgOiBpbnB1dFNpemUgPT09IDFcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA/ICdwcm9kdWN0LndlaWdodHMgPSBbaW5wdXRbX2ldXTsnXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgOiAncHJvZHVjdC53ZWlnaHRzID0gaW5wdXRbX2ldOycpO1xuICAgICAgICAgICAgICAgICAgICBpbm5lckZ1bmN0aW9uc1N3aXRjaC5wdXNoKCdicmVhazsnKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgIGlubmVyRnVuY3Rpb25zU3dpdGNoLnB1c2goYCAgICAgICAgY2FzZSAnJHtmbk5hbWV9Jzoke2ZuTmFtZSAhPT0gJ2ZvcndhcmRGbidcbiAgICAgICAgICAgICAgICAgICAgICAgID8gYCAvL2NvbXBpbGVkIGZyb20gJHtmaWxlTmFtZShmbk5hbWUpfWBcbiAgICAgICAgICAgICAgICAgICAgICAgIDogJyd9XG4gICAgICAgICAgJHt0b0lubmVyKHN0YXRlLmZvcndhcmRGbi50b1N0cmluZygpKX1cbiAgICAgICAgICBicmVhaztgKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgY29uc3QgZm9yY2VGb3JlY2FzdCA9IGlucHV0U2l6ZSA9PT0gMSAmJiB0aGlzLm91dHB1dExvb2t1cDtcbiAgICAgICAgY29uc3Qgc3JjID0gYFxuICB2YXIgaW5wdXQgPSAke3RoaXMuaW5wdXRMb29rdXAgPyAnbG9va3VwSW5wdXQocmF3SW5wdXQpJyA6ICdyYXdJbnB1dCd9O1xuICB2YXIganNvbiA9ICR7anNvblN0cmluZ307XG4gIHZhciBvdXRwdXQgPSBbXTtcbiAgdmFyIHN0YXRlcyA9IFtdO1xuICB2YXIgcHJldlN0YXRlcztcbiAgdmFyIHN0YXRlO1xuICB2YXIgbWF4ID0gJHtmb3JjZUZvcmVjYXN0XG4gICAgICAgICAgICA/IGlucHV0TG9va3VwID09PSBvdXRwdXRMb29rdXBcbiAgICAgICAgICAgICAgICA/IGlucHV0TG9va3VwTGVuZ3RoXG4gICAgICAgICAgICAgICAgOiBgaW5wdXQubGVuZ3RoICsgJHtvdXRwdXRMb29rdXBMZW5ndGggLSAxfWBcbiAgICAgICAgICAgIDogJ2lucHV0Lmxlbmd0aCd9O1xuICBmb3IgKHZhciBfaSA9IDA7IF9pIDwgbWF4OyBfaSsrKSB7XG4gICAgcHJldlN0YXRlcyA9IHN0YXRlcztcbiAgICBzdGF0ZXMgPSBbXTtcbiAgICAke3N0YXRlc1Jhdy5qb2luKCc7XFxuICAgICcpfTtcbiAgICBmb3IgKHZhciBzdGF0ZUluZGV4ID0gMCwgc3RhdGVNYXggPSAke3N0YXRlc1Jhdy5sZW5ndGh9OyBzdGF0ZUluZGV4IDwgc3RhdGVNYXg7IHN0YXRlSW5kZXgrKykge1xuICAgICAgc3RhdGUgPSBzdGF0ZXNbc3RhdGVJbmRleF07XG4gICAgICB2YXIgcHJvZHVjdCA9IHN0YXRlLnByb2R1Y3Q7XG4gICAgICB2YXIgbGVmdCA9IHN0YXRlLmxlZnQ7XG4gICAgICB2YXIgcmlnaHQgPSBzdGF0ZS5yaWdodDtcblxuICAgICAgc3dpdGNoIChzdGF0ZS5uYW1lKSB7XG4ke2lubmVyRnVuY3Rpb25zU3dpdGNoLmpvaW4oJ1xcbicpfVxuICAgICAgfVxuICAgIH1cbiAgICAke2lucHV0U2l6ZSA9PT0gMSAmJiBpbnB1dExvb2t1cFxuICAgICAgICAgICAgPyAnaWYgKF9pID49IGlucHV0Lmxlbmd0aCAtIDEpIHsgb3V0cHV0LnB1c2goc3RhdGUucHJvZHVjdC53ZWlnaHRzKTsgfSdcbiAgICAgICAgICAgIDogJ291dHB1dCA9IHN0YXRlLnByb2R1Y3Qud2VpZ2h0czsnfVxuICB9XG4gICR7b3V0cHV0TG9va3VwXG4gICAgICAgICAgICA/IG91dHB1dExvb2t1cCA9PT0gaW5wdXRMb29rdXBcbiAgICAgICAgICAgICAgICA/ICdyZXR1cm4gbG9va3VwT3V0cHV0UGFydGlhbChvdXRwdXQsIGlucHV0KSdcbiAgICAgICAgICAgICAgICA6ICdyZXR1cm4gbG9va3VwT3V0cHV0KG91dHB1dCknXG4gICAgICAgICAgICA6IGlucHV0U2l6ZSA9PT0gMVxuICAgICAgICAgICAgICAgID8gJ3JldHVybiBvdXRwdXRbMF0nXG4gICAgICAgICAgICAgICAgOiAncmV0dXJuIG91dHB1dCd9O1xuICAke2Zvcm1hdElucHV0RGF0YSgpfVxuICAke2Zvcm1hdE91dHB1dERhdGEoKX1cblxuICBmdW5jdGlvbiBNYXRyaXgocm93cywgY29sdW1ucykge1xuICAgIHRoaXMucm93cyA9IHJvd3M7XG4gICAgdGhpcy5jb2x1bW5zID0gY29sdW1ucztcbiAgICB0aGlzLndlaWdodHMgPSB6ZXJvcyhyb3dzICogY29sdW1ucyk7XG4gIH1cbiAgJHt6ZXJvcyQxLnRvU3RyaW5nKCl9XG4gICR7c29mdG1heC50b1N0cmluZygpLnJlcGxhY2UoJ18yLmRlZmF1bHQnLCAnTWF0cml4Jyl9XG4gICR7cmFuZG9tRmxvYXQudG9TdHJpbmcoKX1cbiAgJHtzYW1wbGVJLnRvU3RyaW5nKCl9XG4gICR7bWF4SS50b1N0cmluZygpfWA7XG4gICAgICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZVxuICAgICAgICByZXR1cm4gbmV3IEZ1bmN0aW9uKCdyYXdJbnB1dCcsIGNiID8gY2Ioc3JjKSA6IHNyYyk7XG4gICAgfVxufVxuY29uc3QgdHJhaW5EZWZhdWx0cyA9IHsgLi4udHJhaW5EZWZhdWx0cyQxIH07XG5cbmNsYXNzIEdSVVRpbWVTdGVwIGV4dGVuZHMgUk5OVGltZVN0ZXAge1xuICAgIGdldEhpZGRlbkxheWVyKGhpZGRlblNpemUsIHByZXZTaXplKSB7XG4gICAgICAgIHJldHVybiBnZXRHUlVIaWRkZW5MYXllcihoaWRkZW5TaXplLCBwcmV2U2l6ZSk7XG4gICAgfVxuICAgIGdldEVxdWF0aW9uKGVxdWF0aW9uLCBpbnB1dE1hdHJpeCwgcHJldmlvdXNSZXN1bHQsIGhpZGRlbkxheWVyKSB7XG4gICAgICAgIHJldHVybiBnZXRHUlVFcXVhdGlvbihlcXVhdGlvbiwgaW5wdXRNYXRyaXgsIHByZXZpb3VzUmVzdWx0LCBoaWRkZW5MYXllcik7XG4gICAgfVxufVxuXG5jbGFzcyBMU1RNIGV4dGVuZHMgUk5OIHtcbiAgICBnZXRIaWRkZW5MYXllcihoaWRkZW5TaXplLCBwcmV2U2l6ZSkge1xuICAgICAgICByZXR1cm4gZ2V0SGlkZGVuTFNUTUxheWVyKGhpZGRlblNpemUsIHByZXZTaXplKTtcbiAgICB9XG4gICAgZ2V0RXF1YXRpb24oZXF1YXRpb24sIGlucHV0TWF0cml4LCBwcmV2aW91c1Jlc3VsdCwgaGlkZGVuTGF5ZXIpIHtcbiAgICAgICAgcmV0dXJuIGdldExTVE1FcXVhdGlvbihlcXVhdGlvbiwgaW5wdXRNYXRyaXgsIHByZXZpb3VzUmVzdWx0LCBoaWRkZW5MYXllcik7XG4gICAgfVxufVxuZnVuY3Rpb24gZ2V0SGlkZGVuTFNUTUxheWVyKGhpZGRlblNpemUsIHByZXZTaXplKSB7XG4gICAgcmV0dXJuIHtcbiAgICAgICAgLy8gZ2F0ZXMgcGFyYW1ldGVyc1xuICAgICAgICAvLyB3aXhcbiAgICAgICAgaW5wdXRNYXRyaXg6IG5ldyBSYW5kb21NYXRyaXgoaGlkZGVuU2l6ZSwgcHJldlNpemUsIDAuMDgpLFxuICAgICAgICBpbnB1dEhpZGRlbjogbmV3IFJhbmRvbU1hdHJpeChoaWRkZW5TaXplLCBoaWRkZW5TaXplLCAwLjA4KSxcbiAgICAgICAgaW5wdXRCaWFzOiBuZXcgTWF0cml4KGhpZGRlblNpemUsIDEpLFxuICAgICAgICAvLyB3ZnhcbiAgICAgICAgZm9yZ2V0TWF0cml4OiBuZXcgUmFuZG9tTWF0cml4KGhpZGRlblNpemUsIHByZXZTaXplLCAwLjA4KSxcbiAgICAgICAgZm9yZ2V0SGlkZGVuOiBuZXcgUmFuZG9tTWF0cml4KGhpZGRlblNpemUsIGhpZGRlblNpemUsIDAuMDgpLFxuICAgICAgICBmb3JnZXRCaWFzOiBuZXcgTWF0cml4KGhpZGRlblNpemUsIDEpLFxuICAgICAgICAvLyB3b3hcbiAgICAgICAgb3V0cHV0TWF0cml4OiBuZXcgUmFuZG9tTWF0cml4KGhpZGRlblNpemUsIHByZXZTaXplLCAwLjA4KSxcbiAgICAgICAgb3V0cHV0SGlkZGVuOiBuZXcgUmFuZG9tTWF0cml4KGhpZGRlblNpemUsIGhpZGRlblNpemUsIDAuMDgpLFxuICAgICAgICBvdXRwdXRCaWFzOiBuZXcgTWF0cml4KGhpZGRlblNpemUsIDEpLFxuICAgICAgICAvLyBjZWxsIHdyaXRlIHBhcmFtc1xuICAgICAgICAvLyB3Y3hcbiAgICAgICAgY2VsbEFjdGl2YXRpb25NYXRyaXg6IG5ldyBSYW5kb21NYXRyaXgoaGlkZGVuU2l6ZSwgcHJldlNpemUsIDAuMDgpLFxuICAgICAgICBjZWxsQWN0aXZhdGlvbkhpZGRlbjogbmV3IFJhbmRvbU1hdHJpeChoaWRkZW5TaXplLCBoaWRkZW5TaXplLCAwLjA4KSxcbiAgICAgICAgY2VsbEFjdGl2YXRpb25CaWFzOiBuZXcgTWF0cml4KGhpZGRlblNpemUsIDEpLFxuICAgIH07XG59XG5mdW5jdGlvbiBnZXRMU1RNRXF1YXRpb24oZXF1YXRpb24sIGlucHV0TWF0cml4LCBwcmV2aW91c1Jlc3VsdCwgaGlkZGVuTGF5ZXIpIHtcbiAgICBpZiAoIWhpZGRlbkxheWVyLmlucHV0TWF0cml4IHx8XG4gICAgICAgICFoaWRkZW5MYXllci5pbnB1dEhpZGRlbiB8fFxuICAgICAgICAhaGlkZGVuTGF5ZXIuaW5wdXRCaWFzIHx8XG4gICAgICAgICFoaWRkZW5MYXllci5mb3JnZXRNYXRyaXggfHxcbiAgICAgICAgIWhpZGRlbkxheWVyLmZvcmdldEhpZGRlbiB8fFxuICAgICAgICAhaGlkZGVuTGF5ZXIuZm9yZ2V0QmlhcyB8fFxuICAgICAgICAhaGlkZGVuTGF5ZXIub3V0cHV0TWF0cml4IHx8XG4gICAgICAgICFoaWRkZW5MYXllci5vdXRwdXRIaWRkZW4gfHxcbiAgICAgICAgIWhpZGRlbkxheWVyLm91dHB1dEJpYXMgfHxcbiAgICAgICAgIWhpZGRlbkxheWVyLmNlbGxBY3RpdmF0aW9uTWF0cml4IHx8XG4gICAgICAgICFoaWRkZW5MYXllci5jZWxsQWN0aXZhdGlvbkhpZGRlbiB8fFxuICAgICAgICAhaGlkZGVuTGF5ZXIuY2VsbEFjdGl2YXRpb25CaWFzKSB7XG4gICAgICAgIHRocm93IG5ldyBFcnJvcignaGlkZGVuTGF5ZXIgZG9lcyBub3QgaGF2ZSBleHBlY3RlZCBwcm9wZXJ0aWVzJyk7XG4gICAgfVxuICAgIGNvbnN0IHNpZ21vaWQgPSBlcXVhdGlvbi5zaWdtb2lkLmJpbmQoZXF1YXRpb24pO1xuICAgIGNvbnN0IGFkZCA9IGVxdWF0aW9uLmFkZC5iaW5kKGVxdWF0aW9uKTtcbiAgICBjb25zdCBtdWx0aXBseSA9IGVxdWF0aW9uLm11bHRpcGx5LmJpbmQoZXF1YXRpb24pO1xuICAgIGNvbnN0IG11bHRpcGx5RWxlbWVudCA9IGVxdWF0aW9uLm11bHRpcGx5RWxlbWVudC5iaW5kKGVxdWF0aW9uKTtcbiAgICBjb25zdCB0YW5oID0gZXF1YXRpb24udGFuaC5iaW5kKGVxdWF0aW9uKTtcbiAgICBjb25zdCBpbnB1dEdhdGUgPSBzaWdtb2lkKGFkZChhZGQobXVsdGlwbHkoaGlkZGVuTGF5ZXIuaW5wdXRNYXRyaXgsIGlucHV0TWF0cml4KSwgbXVsdGlwbHkoaGlkZGVuTGF5ZXIuaW5wdXRIaWRkZW4sIHByZXZpb3VzUmVzdWx0KSksIGhpZGRlbkxheWVyLmlucHV0QmlhcykpO1xuICAgIGNvbnN0IGZvcmdldEdhdGUgPSBzaWdtb2lkKGFkZChhZGQobXVsdGlwbHkoaGlkZGVuTGF5ZXIuZm9yZ2V0TWF0cml4LCBpbnB1dE1hdHJpeCksIG11bHRpcGx5KGhpZGRlbkxheWVyLmZvcmdldEhpZGRlbiwgcHJldmlvdXNSZXN1bHQpKSwgaGlkZGVuTGF5ZXIuZm9yZ2V0QmlhcykpO1xuICAgIC8vIG91dHB1dCBnYXRlXG4gICAgY29uc3Qgb3V0cHV0R2F0ZSA9IHNpZ21vaWQoYWRkKGFkZChtdWx0aXBseShoaWRkZW5MYXllci5vdXRwdXRNYXRyaXgsIGlucHV0TWF0cml4KSwgbXVsdGlwbHkoaGlkZGVuTGF5ZXIub3V0cHV0SGlkZGVuLCBwcmV2aW91c1Jlc3VsdCkpLCBoaWRkZW5MYXllci5vdXRwdXRCaWFzKSk7XG4gICAgLy8gd3JpdGUgb3BlcmF0aW9uIG9uIGNlbGxzXG4gICAgY29uc3QgY2VsbFdyaXRlID0gdGFuaChhZGQoYWRkKG11bHRpcGx5KGhpZGRlbkxheWVyLmNlbGxBY3RpdmF0aW9uTWF0cml4LCBpbnB1dE1hdHJpeCksIG11bHRpcGx5KGhpZGRlbkxheWVyLmNlbGxBY3RpdmF0aW9uSGlkZGVuLCBwcmV2aW91c1Jlc3VsdCkpLCBoaWRkZW5MYXllci5jZWxsQWN0aXZhdGlvbkJpYXMpKTtcbiAgICAvLyBjb21wdXRlIG5ldyBjZWxsIGFjdGl2YXRpb25cbiAgICBjb25zdCByZXRhaW5DZWxsID0gbXVsdGlwbHlFbGVtZW50KGZvcmdldEdhdGUsIHByZXZpb3VzUmVzdWx0KTsgLy8gd2hhdCBkbyB3ZSBrZWVwIGZyb20gY2VsbFxuICAgIGNvbnN0IHdyaXRlQ2VsbCA9IG11bHRpcGx5RWxlbWVudChpbnB1dEdhdGUsIGNlbGxXcml0ZSk7IC8vIHdoYXQgZG8gd2Ugd3JpdGUgdG8gY2VsbFxuICAgIGNvbnN0IGNlbGwgPSBhZGQocmV0YWluQ2VsbCwgd3JpdGVDZWxsKTsgLy8gbmV3IGNlbGwgY29udGVudHNcbiAgICAvLyBjb21wdXRlIGhpZGRlbiBzdGF0ZSBhcyBnYXRlZCwgc2F0dXJhdGVkIGNlbGwgYWN0aXZhdGlvbnNcbiAgICByZXR1cm4gbXVsdGlwbHlFbGVtZW50KG91dHB1dEdhdGUsIHRhbmgoY2VsbCkpO1xufVxuXG5jbGFzcyBMU1RNVGltZVN0ZXAgZXh0ZW5kcyBSTk5UaW1lU3RlcCB7XG4gICAgZ2V0SGlkZGVuTGF5ZXIoaGlkZGVuU2l6ZSwgcHJldlNpemUpIHtcbiAgICAgICAgcmV0dXJuIGdldEhpZGRlbkxTVE1MYXllcihoaWRkZW5TaXplLCBwcmV2U2l6ZSk7XG4gICAgfVxuICAgIGdldEVxdWF0aW9uKGVxdWF0aW9uLCBpbnB1dE1hdHJpeCwgcHJldmlvdXNSZXN1bHQsIGhpZGRlbkxheWVyKSB7XG4gICAgICAgIHJldHVybiBnZXRMU1RNRXF1YXRpb24oZXF1YXRpb24sIGlucHV0TWF0cml4LCBwcmV2aW91c1Jlc3VsdCwgaGlkZGVuTGF5ZXIpO1xuICAgIH1cbn1cblxuLyoqXG4gKlxuICogQHBhcmFtIHN0YXJ0XG4gKiBAcGFyYW0gZW5kXG4gKiBAcmV0dXJucyB7QXJyYXl9XG4gKi9cbmZ1bmN0aW9uIHJhbmdlKHN0YXJ0LCBlbmQpIHtcbiAgICBjb25zdCByZXN1bHQgPSBbXTtcbiAgICBmb3IgKDsgc3RhcnQgPCBlbmQ7IHN0YXJ0KyspIHtcbiAgICAgICAgcmVzdWx0LnB1c2goc3RhcnQpO1xuICAgIH1cbiAgICByZXR1cm4gcmVzdWx0O1xufVxuXG5mdW5jdGlvbiB0b0FycmF5KHZhbHVlcykge1xuICAgIGlmIChBcnJheS5pc0FycmF5KHZhbHVlcykpIHtcbiAgICAgICAgcmV0dXJuIEZsb2F0MzJBcnJheS5mcm9tKHZhbHVlcyk7XG4gICAgfVxuICAgIHJldHVybiBGbG9hdDMyQXJyYXkuZnJvbShPYmplY3QudmFsdWVzKHZhbHVlcykpO1xufVxuXG5mdW5jdGlvbiBkcmF3SW5wdXQoeyBwaXhlbFgsIHBpeGVsWSwgcmFkaXVzLCBpbnB1dHMsIHJvdywgbGluZSwgZm9udFNpemUsIGZvbnRDbGFzc05hbWUsIH0pIHtcbiAgICBsZXQgc3ZnID0gYDxyZWN0XG4gICAgICAgICAgICAgIHg9XCIke3BpeGVsWCAvIDIgLSByYWRpdXN9XCJcbiAgICAgICAgICAgICAgeT1cIiR7cGl4ZWxZIC8gMiArIHJvdyAqIHBpeGVsWSAtIHJhZGl1c31cIlxuICAgICAgICAgICAgICB3aWR0aD1cIiR7MiAqIHJhZGl1c31cIlxuICAgICAgICAgICAgICBoZWlnaHQ9XCIkezIgKiByYWRpdXN9XCJcbiAgICAgICAgICAgICAgc3Ryb2tlPVwiYmxhY2tcIlxuICAgICAgICAgICAgICBzdHJva2Utd2lkdGg9XCIxXCJcbiAgICAgICAgICAgICAgZmlsbD1cIiR7aW5wdXRzLmNvbG9yfVwiXG4gICAgICAgICAgICAgIGNsYXNzPVwiJHtpbnB1dHMuY2xhc3NOYW1lfVwiIC8+XG4gICAgICAgICAgICA8bGluZVxuICAgICAgICAgICAgICB4MT1cIiR7cGl4ZWxYIC8gNH1cIlxuICAgICAgICAgICAgICB5MT1cIiR7cGl4ZWxZIC8gMiArIHJvdyAqIHBpeGVsWX1cIlxuICAgICAgICAgICAgICB4Mj1cIiR7cGl4ZWxYIC8gMiAtIHJhZGl1c31cIlxuICAgICAgICAgICAgICB5Mj1cIiR7cGl4ZWxZIC8gMiArIHJvdyAqIHBpeGVsWX1cIlxuICAgICAgICAgICAgICBzdHlsZT1cInN0cm9rZToke2xpbmUuY29sb3J9O3N0cm9rZS13aWR0aDoke2xpbmUud2lkdGh9XCJcbiAgICAgICAgICAgICAgY2xhc3M9XCIke2xpbmUuY2xhc3NOYW1lfVwiIC8+YDtcbiAgICBpZiAoaW5wdXRzLmxhYmVscykge1xuICAgICAgICBzdmcgKz0gYDx0ZXh0XG4gICAgICAgICAgICAgIHg9XCIke3BpeGVsWCAvIDh9XCJcbiAgICAgICAgICAgICAgeT1cIiR7cGl4ZWxZIC8gMiArIHJvdyAqIHBpeGVsWSAtIDV9XCJcbiAgICAgICAgICAgICAgZmlsbD1cImJsYWNrXCJcbiAgICAgICAgICAgICAgZm9udC1zaXplPVwiJHtmb250U2l6ZX1cIlxuICAgICAgICAgICAgICBjbGFzcz1cIiR7Zm9udENsYXNzTmFtZX1cIj4ke2lucHV0cy5sYWJlbHNbcm93XX08L3RleHQ+YDtcbiAgICB9XG4gICAgcmV0dXJuIHN2Zztcbn1cbmZ1bmN0aW9uIGRyYXdOZXVyb24oeyBwaXhlbFgsIHBpeGVsWSwgcm93LCBjb2x1bW4sIHJhZGl1cywgaGlkZGVuLCB9KSB7XG4gICAgcmV0dXJuIGA8Y2lyY2xlXG4gICAgICAgICAgICBjeD1cIiR7cGl4ZWxYIC8gMiArIGNvbHVtbiAqIHBpeGVsWH1cIlxuICAgICAgICAgICAgY3k9XCIke3BpeGVsWSAvIDIgKyByb3cgKiBwaXhlbFl9XCJcbiAgICAgICAgICAgIHI9XCIke3JhZGl1c31cIlxuICAgICAgICAgICAgc3Ryb2tlPVwiYmxhY2tcIlxuICAgICAgICAgICAgc3Ryb2tlLXdpZHRoPVwiMVwiXG4gICAgICAgICAgICBmaWxsPVwiJHtoaWRkZW4uY29sb3J9XCJcbiAgICAgICAgICAgIGNsYXNzPVwiJHtoaWRkZW4uY2xhc3NOYW1lfVwiIC8+YDtcbn1cbmZ1bmN0aW9uIGRyYXdPdXRwdXQoeyBwaXhlbFgsIHBpeGVsWSwgcm93LCBjb2x1bW4sIGxpbmUsIG91dHB1dHMsIHJhZGl1cywgfSkge1xuICAgIHJldHVybiBgPGNpcmNsZVxuICAgICAgICAgICAgY3g9XCIke3BpeGVsWCAvIDIgKyBjb2x1bW4gKiBwaXhlbFh9XCJcbiAgICAgICAgICAgIGN5PVwiJHtwaXhlbFkgLyAyICsgcm93ICogcGl4ZWxZfVwiXG4gICAgICAgICAgICByPVwiJHtyYWRpdXN9XCJcbiAgICAgICAgICAgIHN0cm9rZT1cImJsYWNrXCJcbiAgICAgICAgICAgIHN0cm9rZS13aWR0aD1cIjFcIlxuICAgICAgICAgICAgZmlsbD1cIiR7b3V0cHV0cy5jb2xvcn1cIlxuICAgICAgICAgICAgY2xhc3M9XCIke291dHB1dHMuY2xhc3NOYW1lfVwiIC8+XG4gICAgICAgICAgPGxpbmVcbiAgICAgICAgICAgIHgxPVwiJHtwaXhlbFggLyAyICsgY29sdW1uICogcGl4ZWxYICsgcmFkaXVzfVwiXG4gICAgICAgICAgICB5MT1cIiR7cGl4ZWxZIC8gMiArIHJvdyAqIHBpeGVsWX1cIlxuICAgICAgICAgICAgeDI9XCIke3BpeGVsWCAvIDIgKyBjb2x1bW4gKiBwaXhlbFggKyBwaXhlbFggLyA0fVwiXG4gICAgICAgICAgICB5Mj1cIiR7cGl4ZWxZIC8gMiArIHJvdyAqIHBpeGVsWX1cIlxuICAgICAgICAgICAgc3R5bGU9XCJzdHJva2U6JHtsaW5lLmNvbG9yfTtzdHJva2Utd2lkdGg6JHtsaW5lLndpZHRofVwiXG4gICAgICAgICAgICBjbGFzcz1cIiR7bGluZS5jbGFzc05hbWV9XCIgLz5gO1xufVxuZnVuY3Rpb24gZHJhd0JhY2t3YXJkQ29ubmVjdGlvbnMoeyBwaXhlbFgsIHBpeGVsWSwgcm93LCBjb2x1bW4sIHJhZGl1cywgbGluZVksIGxpbmUsIHByZXZpb3VzQ29ubmVjdGlvbkluZGV4LCB9KSB7XG4gICAgcmV0dXJuIGA8bGluZVxuICAgICAgICAgICAgeDE9XCIke3BpeGVsWCAvIDIgKyAoY29sdW1uIC0gMSkgKiBwaXhlbFggKyByYWRpdXN9XCJcbiAgICAgICAgICAgIHkxPVwiJHtsaW5lWSAvIDIgKyBwcmV2aW91c0Nvbm5lY3Rpb25JbmRleCAqIGxpbmVZfVwiXG4gICAgICAgICAgICB4Mj1cIiR7cGl4ZWxYIC8gMiArIGNvbHVtbiAqIHBpeGVsWCAtIHJhZGl1c31cIlxuICAgICAgICAgICAgeTI9XCIke3BpeGVsWSAvIDIgKyByb3cgKiBwaXhlbFl9XCJcbiAgICAgICAgICAgIHN0eWxlPVwic3Ryb2tlOiR7bGluZS5jb2xvcn07c3Ryb2tlLXdpZHRoOiR7bGluZS53aWR0aH1cIlxuICAgICAgICAgICAgY2xhc3M9XCIke2xpbmUuY2xhc3NOYW1lfVwiIC8+YDtcbn1cbmZ1bmN0aW9uIG5ldXJhbE5ldHdvcmtUb0lubmVyU1ZHKG9wdGlvbnMpIHtcbiAgICBjb25zdCB7IHNpemVzLCBoZWlnaHQsIHdpZHRoIH0gPSBvcHRpb25zO1xuICAgIGxldCBzdmcgPSAnJztcbiAgICBjb25zdCBwaXhlbFggPSB3aWR0aCAvIHNpemVzLmxlbmd0aDtcbiAgICBmb3IgKGxldCBjb2x1bW4gPSAwOyBjb2x1bW4gPCBzaXplcy5sZW5ndGg7IGNvbHVtbisrKSB7XG4gICAgICAgIGNvbnN0IHNpemUgPSBzaXplc1tjb2x1bW5dO1xuICAgICAgICBjb25zdCBwaXhlbFkgPSBoZWlnaHQgLyBzaXplO1xuICAgICAgICBmb3IgKGxldCByb3cgPSAwOyByb3cgPCBzaXplOyByb3crKykge1xuICAgICAgICAgICAgaWYgKGNvbHVtbiA9PT0gMCkge1xuICAgICAgICAgICAgICAgIHN2ZyArPSBkcmF3SW5wdXQoeyBwaXhlbFgsIHBpeGVsWSwgcm93LCBjb2x1bW4sIC4uLm9wdGlvbnMgfSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgICAgICBpZiAoY29sdW1uID09PSBzaXplcy5sZW5ndGggLSAxKSB7XG4gICAgICAgICAgICAgICAgICAgIHN2ZyArPSBkcmF3T3V0cHV0KHsgcGl4ZWxYLCBwaXhlbFksIHJvdywgY29sdW1uLCAuLi5vcHRpb25zIH0pO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgc3ZnICs9IGRyYXdOZXVyb24oeyBwaXhlbFgsIHBpeGVsWSwgcm93LCBjb2x1bW4sIC4uLm9wdGlvbnMgfSk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGNvbnN0IHByZXZpb3VzU2l6ZSA9IHNpemVzW2NvbHVtbiAtIDFdO1xuICAgICAgICAgICAgICAgIGNvbnN0IGxpbmVZID0gaGVpZ2h0IC8gcHJldmlvdXNTaXplO1xuICAgICAgICAgICAgICAgIGZvciAobGV0IHByZXZpb3VzQ29ubmVjdGlvbkluZGV4ID0gMDsgcHJldmlvdXNDb25uZWN0aW9uSW5kZXggPCBwcmV2aW91c1NpemU7IHByZXZpb3VzQ29ubmVjdGlvbkluZGV4KyspIHtcbiAgICAgICAgICAgICAgICAgICAgc3ZnICs9IGRyYXdCYWNrd2FyZENvbm5lY3Rpb25zKHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHBpeGVsWCxcbiAgICAgICAgICAgICAgICAgICAgICAgIHBpeGVsWSxcbiAgICAgICAgICAgICAgICAgICAgICAgIHJvdyxcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbHVtbixcbiAgICAgICAgICAgICAgICAgICAgICAgIGxpbmVZLFxuICAgICAgICAgICAgICAgICAgICAgICAgcHJldmlvdXNDb25uZWN0aW9uSW5kZXgsXG4gICAgICAgICAgICAgICAgICAgICAgICAuLi5vcHRpb25zLFxuICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9XG4gICAgcmV0dXJuIHN2Zztcbn1cbmZ1bmN0aW9uIGRyYXdSZWN1cnJlbnRDb25uZWN0aW9ucyh7IHBpeGVsWCwgcGl4ZWxZLCByb3csIGNvbHVtbiwgcmFkaXVzLCByZWN1cnJlbnRMaW5lLCB9KSB7XG4gICAgY29uc3QgbW92ZVggPSBwaXhlbFggLyAyICsgY29sdW1uICogcGl4ZWxYICsgcmFkaXVzICsgMTtcbiAgICBjb25zdCBtb3ZlWSA9IHBpeGVsWSAvIDIgKyByb3cgKiBwaXhlbFk7XG4gICAgY29uc3QgeCA9IG1vdmVYIC0gcmFkaXVzICogMiAtIDI7XG4gICAgY29uc3QgeSA9IG1vdmVZO1xuICAgIGNvbnN0IHgxID0geCArIDEwMDtcbiAgICBjb25zdCB5MSA9IHkgKyA1MDtcbiAgICBjb25zdCB4MiA9IG1vdmVYIC0gMTAwO1xuICAgIGNvbnN0IHkyID0gbW92ZVkgKyA1MDtcbiAgICByZXR1cm4gYDxwYXRoXG4gICAgICAgICAgICAgIGQ9XCJNICR7bW92ZVh9ICR7bW92ZVl9IEMgJHt4MX0gJHt5MX0sICR7eDJ9ICR7eTJ9LCAke3h9ICR7eX1cIlxuICAgICAgICAgICAgICBzdHJva2U9XCIke3JlY3VycmVudExpbmUuY29sb3J9XCJcbiAgICAgICAgICAgICAgc3Ryb2tlLXdpZHRoPVwiJHtyZWN1cnJlbnRMaW5lLndpZHRofVwiXG4gICAgICAgICAgICAgIGZpbGw9XCJ0cmFuc3BhcmVudFwiXG4gICAgICAgICAgICAgIHN0cm9rZS1saW5lY2FwPVwicm91bmRcIlxuICAgICAgICAgICAgICBtYXJrZXItZW5kPVwidXJsKCNhcnJvdylcIlxuICAgICAgICAgICAgICBjbGFzcz1cIiR7cmVjdXJyZW50TGluZS5jbGFzc05hbWV9XCIgLz5gO1xufVxuZnVuY3Rpb24gcm5uVG9Jbm5lclNWRyhvcHRpb25zKSB7XG4gICAgY29uc3QgeyB3aWR0aCwgaGVpZ2h0LCByZWN1cnJlbnRMaW5lLCBzaXplcywgcmFkaXVzIH0gPSBvcHRpb25zO1xuICAgIGNvbnN0IHBpeGVsWCA9IHdpZHRoIC8gc2l6ZXMubGVuZ3RoO1xuICAgIGxldCBzdmcgPSBgPGRlZnM+XG4gICAgICAgICAgICAgIDxtYXJrZXIgaWQ9XCJhcnJvd1wiIG1hcmtlcldpZHRoPVwiMTBcIiBtYXJrZXJIZWlnaHQ9XCIxMFwiIHJlZlg9XCI4XCIgcmVmWT1cIjNcIiBvcmllbnQ9XCJhdXRvXCIgbWFya2VyVW5pdHM9XCJzdHJva2VXaWR0aFwiPlxuICAgICAgICAgICAgICAgIDxwYXRoIGQ9XCJNMCwwIEwwLDYgTDksMyB6XCIgZmlsbD1cIiR7cmVjdXJyZW50TGluZS5jb2xvcn1cIiAvPlxuICAgICAgICAgICAgICA8L21hcmtlcj5cbiAgICAgICAgICAgIDwvZGVmcz5gO1xuICAgIHN2ZyArPSBuZXVyYWxOZXR3b3JrVG9Jbm5lclNWRyhvcHRpb25zKTtcbiAgICBmb3IgKGxldCBjb2x1bW4gPSAxOyBjb2x1bW4gPCBzaXplcy5sZW5ndGg7IGNvbHVtbisrKSB7XG4gICAgICAgIGNvbnN0IHNpemUgPSBzaXplc1tjb2x1bW5dO1xuICAgICAgICBjb25zdCBwaXhlbFkgPSBoZWlnaHQgLyBzaXplO1xuICAgICAgICBmb3IgKGxldCByb3cgPSAwOyByb3cgPCBzaXplOyByb3crKykge1xuICAgICAgICAgICAgc3ZnICs9IGRyYXdSZWN1cnJlbnRDb25uZWN0aW9ucyh7XG4gICAgICAgICAgICAgICAgcGl4ZWxYLFxuICAgICAgICAgICAgICAgIHBpeGVsWSxcbiAgICAgICAgICAgICAgICByb3csXG4gICAgICAgICAgICAgICAgY29sdW1uLFxuICAgICAgICAgICAgICAgIHJhZGl1cyxcbiAgICAgICAgICAgICAgICByZWN1cnJlbnRMaW5lLFxuICAgICAgICAgICAgfSk7XG4gICAgICAgIH1cbiAgICB9XG4gICAgcmV0dXJuIHN2Zztcbn1cbmZ1bmN0aW9uIGdldEZlZWRGb3J3YXJkTGF5ZXJzKG5ldHdvcmspIHtcbiAgICBjb25zdCB7IG9wdGlvbnMgfSA9IG5ldHdvcms7XG4gICAgaWYgKCFvcHRpb25zKSB7XG4gICAgICAgIHRocm93IG5ldyBFcnJvcignb3B0aW9ucyBub3QgZGVmaW5lZCcpO1xuICAgIH1cbiAgICBpZiAoIW9wdGlvbnMuaW5wdXRMYXllcikge1xuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ29wdGlvbnMuaW5wdXRMYXRlciBub3QgZGVmaW5lZCcpO1xuICAgIH1cbiAgICBpZiAoIW9wdGlvbnMuaGlkZGVuTGF5ZXJzKSB7XG4gICAgICAgIHRocm93IG5ldyBFcnJvcignb3B0aW9ucy5oaWRkZW5MYXllcnMgbm90IGRlZmluZWQnKTtcbiAgICB9XG4gICAgaWYgKG9wdGlvbnMuaGlkZGVuTGF5ZXJzLmxlbmd0aCA8IDEpIHtcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdvcHRpb25zLmhpZGRlbkxheWVycyBpcyBlbXB0eScpO1xuICAgIH1cbiAgICBpZiAoIW9wdGlvbnMub3V0cHV0TGF5ZXIpIHtcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdvcHRpb25zLm91dHB1dExheWVyIG5vdCBkZWZpbmVkJyk7XG4gICAgfVxuICAgIGNvbnN0IGlucHV0TGF5ZXIgPSBvcHRpb25zLmlucHV0TGF5ZXIoKTtcbiAgICBjb25zdCBoaWRkZW5MYXllcnMgPSBbXTtcbiAgICBoaWRkZW5MYXllcnMucHVzaChvcHRpb25zLmhpZGRlbkxheWVyc1swXShpbnB1dExheWVyLCAwKSk7XG4gICAgZm9yIChsZXQgaSA9IDE7IGkgPCBvcHRpb25zLmhpZGRlbkxheWVycy5sZW5ndGg7IGkrKykge1xuICAgICAgICBoaWRkZW5MYXllcnMucHVzaChvcHRpb25zLmhpZGRlbkxheWVyc1tpXShoaWRkZW5MYXllcnNbaSAtIDFdLCBpKSk7XG4gICAgfVxuICAgIGNvbnN0IG91dHB1dExheWVyID0gb3B0aW9ucy5vdXRwdXRMYXllcihoaWRkZW5MYXllcnNbaGlkZGVuTGF5ZXJzLmxlbmd0aCAtIDFdLCBoaWRkZW5MYXllcnMubGVuZ3RoKTtcbiAgICByZXR1cm4ge1xuICAgICAgICBpbnB1dFNpemU6IGlucHV0TGF5ZXIuaGVpZ2h0LFxuICAgICAgICBoaWRkZW5MYXllcnM6IGhpZGRlbkxheWVycy5tYXAoKGhpZGRlbkxheWVyKSA9PiBoaWRkZW5MYXllci5oZWlnaHQpLFxuICAgICAgICBvdXRwdXRTaXplOiBvdXRwdXRMYXllci5oZWlnaHQsXG4gICAgfTtcbn1cbmZ1bmN0aW9uIGdldFJlY3VycmVudExheWVycyhuZXR3b3JrKSB7XG4gICAgY29uc3QgaGlkZGVuTGF5ZXJzID0gW107XG4gICAgY29uc3QgeyBvcHRpb25zIH0gPSBuZXR3b3JrO1xuICAgIGlmICghb3B0aW9ucy5pbnB1dExheWVyKSB7XG4gICAgICAgIHRocm93IG5ldyBFcnJvcignaW5wdXRMYXllciBub3QgZGVmaW5lZCcpO1xuICAgIH1cbiAgICBpZiAoIW9wdGlvbnMub3V0cHV0TGF5ZXIpIHtcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdvdXRwdXRMYXllciBub3QgZGVmaW5lZCcpO1xuICAgIH1cbiAgICBjb25zdCBpbnB1dExheWVyID0gb3B0aW9ucy5pbnB1dExheWVyKCk7XG4gICAgaGlkZGVuTGF5ZXJzLnB1c2gob3B0aW9ucy5oaWRkZW5MYXllcnNbMF0oaW5wdXRMYXllciwgcmVjdXJyZW50WmVyb3MoKSwgMCkpO1xuICAgIGZvciAobGV0IGkgPSAxOyBpIDwgb3B0aW9ucy5oaWRkZW5MYXllcnMubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgaGlkZGVuTGF5ZXJzLnB1c2gob3B0aW9ucy5oaWRkZW5MYXllcnNbaV0oaGlkZGVuTGF5ZXJzW2kgLSAxXSwgcmVjdXJyZW50WmVyb3MoKSwgaSkpO1xuICAgIH1cbiAgICBjb25zdCBvdXRwdXRMYXllciA9IG9wdGlvbnMub3V0cHV0TGF5ZXIoaGlkZGVuTGF5ZXJzW2hpZGRlbkxheWVycy5sZW5ndGggLSAxXSwgLTEpO1xuICAgIHJldHVybiB7XG4gICAgICAgIGlucHV0U2l6ZTogaW5wdXRMYXllci5oZWlnaHQsXG4gICAgICAgIGhpZGRlbkxheWVyczogaGlkZGVuTGF5ZXJzLm1hcCgoaGlkZGVuTGF5ZXIpID0+IGhpZGRlbkxheWVyLmhlaWdodCksXG4gICAgICAgIG91dHB1dFNpemU6IG91dHB1dExheWVyLmhlaWdodCxcbiAgICB9O1xufVxuZnVuY3Rpb24gd3JhcE91dGVyU1ZHKHN2Z0JvZHksIHdpZHRoLCBoZWlnaHQpIHtcbiAgICAvLyBsYW5ndWFnZT1odG1sXG4gICAgcmV0dXJuIGA8c3ZnXG4gICAgICAgICAgICB4bWxucz1cImh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnXCJcbiAgICAgICAgICAgIHhtbG5zOnhsaW5rPVwiaHR0cDovL3d3dy53My5vcmcvMTk5OS94bGlua1wiXG4gICAgICAgICAgICB2ZXJzaW9uPVwiMS4xXCJcbiAgICAgICAgICAgIHdpZHRoPVwiJHt3aWR0aH1cIlxuICAgICAgICAgICAgaGVpZ2h0PVwiJHtoZWlnaHR9XCI+JHtzdmdCb2R5fTwvc3ZnPmA7XG59XG5mdW5jdGlvbiBnZXROZXVyYWxOZXR3b3JrSlNPTlNpemVzKGpzb24pIHtcbiAgICByZXR1cm4ganNvbi5zaXplcztcbn1cbmZ1bmN0aW9uIGdldE5ldXJhbE5ldHdvcmtTaXplcyhuZXQpIHtcbiAgICBjb25zdCB7IG9wdGlvbnMsIHNpemVzIH0gPSBuZXQ7XG4gICAgY29uc3QgeyBpbnB1dFNpemUsIG91dHB1dFNpemUsIGhpZGRlbkxheWVycyB9ID0gb3B0aW9ucztcbiAgICBpZiAoIXNpemVzKSB7XG4gICAgICAgIGlmICh0eXBlb2YgaW5wdXRTaXplID09PSAnbnVtYmVyJyAmJiBpbnB1dFNpemUgPCAxKSB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ2lucHV0U2l6ZSBub3Qgc2V0Jyk7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKHR5cGVvZiBvdXRwdXRTaXplID09PSAnbnVtYmVyJyAmJiBvdXRwdXRTaXplIDwgMSkge1xuICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdvdXRwdXRTaXplIG5vdCBzZXQnKTtcbiAgICAgICAgfVxuICAgICAgICBpZiAoaGlkZGVuTGF5ZXJzID09PSBudWxsIHx8IGhpZGRlbkxheWVycyA9PT0gdm9pZCAwID8gdm9pZCAwIDogaGlkZGVuTGF5ZXJzLnNvbWUoKHYpID0+IHYgPCAxKSkge1xuICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdoaWRkZW5MYXllcnMgbm90IHNldCcpO1xuICAgICAgICB9XG4gICAgfVxuICAgIHJldHVybiB0eXBlb2YgaW5wdXRTaXplID09PSAnbnVtYmVyJyAmJlxuICAgICAgICBBcnJheS5pc0FycmF5KGhpZGRlbkxheWVycykgJiZcbiAgICAgICAgdHlwZW9mIG91dHB1dFNpemUgPT09ICdudW1iZXInXG4gICAgICAgID8gW2lucHV0U2l6ZV0uY29uY2F0KGhpZGRlbkxheWVycykuY29uY2F0KFtvdXRwdXRTaXplXSlcbiAgICAgICAgOiBzaXplcztcbn1cbmZ1bmN0aW9uIGdldFJOTlNpemVzKG5ldCkge1xuICAgIGNvbnN0IHsgb3B0aW9ucyB9ID0gbmV0O1xuICAgIGNvbnN0IHsgaW5wdXRTaXplLCBvdXRwdXRTaXplLCBoaWRkZW5MYXllcnMgfSA9IG9wdGlvbnM7XG4gICAgcmV0dXJuIFtpbnB1dFNpemVdLmNvbmNhdChoaWRkZW5MYXllcnMpLmNvbmNhdChbb3V0cHV0U2l6ZV0pO1xufVxuZnVuY3Rpb24gZGVmYXVsdE9wdGlvbnMoKSB7XG4gICAgcmV0dXJuIHtcbiAgICAgICAgbGluZToge1xuICAgICAgICAgICAgd2lkdGg6IDAuNSxcbiAgICAgICAgICAgIGNvbG9yOiAnYmxhY2snLFxuICAgICAgICAgICAgY2xhc3NOYW1lOiAnY29ubmVjdGlvbicsXG4gICAgICAgIH0sXG4gICAgICAgIHJlY3VycmVudExpbmU6IHtcbiAgICAgICAgICAgIHdpZHRoOiAxLFxuICAgICAgICAgICAgY29sb3I6ICdyZWQnLFxuICAgICAgICAgICAgY2xhc3NOYW1lOiAncmVjdXJyZW5jZScsXG4gICAgICAgIH0sXG4gICAgICAgIGlucHV0czoge1xuICAgICAgICAgICAgY29sb3I6ICdyZ2JhKDAsIDEyOCwgMCwgMC41KScsXG4gICAgICAgICAgICBsYWJlbHM6IG51bGwsXG4gICAgICAgICAgICBjbGFzc05hbWU6ICdpbnB1dCcsXG4gICAgICAgIH0sXG4gICAgICAgIG91dHB1dHM6IHtcbiAgICAgICAgICAgIGNvbG9yOiAncmdiYSgxMDAsIDE0OSwgMjM3LCAwLjUpJyxcbiAgICAgICAgICAgIGNsYXNzTmFtZTogJ291dHB1dCcsXG4gICAgICAgIH0sXG4gICAgICAgIGhpZGRlbjoge1xuICAgICAgICAgICAgY29sb3I6ICdyZ2JhKDI1NSwgMTI3LCA4MCwgMC41KScsXG4gICAgICAgICAgICBjbGFzc05hbWU6ICdoaWRkZW4tbmV1cm9uJyxcbiAgICAgICAgfSxcbiAgICAgICAgZm9udFNpemU6ICcxNHB4JyxcbiAgICAgICAgZm9udENsYXNzTmFtZTogJ2xhYmVsJyxcbiAgICAgICAgcmFkaXVzOiA4LFxuICAgICAgICB3aWR0aDogNDAwLFxuICAgICAgICBoZWlnaHQ6IDI1MCxcbiAgICAgICAgc2l6ZXM6IFtdLFxuICAgIH07XG59XG5mdW5jdGlvbiB0b1NWRyhuZXQsIG9wdGlvbnMpIHtcbiAgICBjb25zdCBtZXJnZWRPcHRpb25zID0geyAuLi5kZWZhdWx0T3B0aW9ucygpLCAuLi5vcHRpb25zIH07XG4gICAgY29uc3QgeyB3aWR0aCwgaGVpZ2h0LCBpbnB1dHMgfSA9IG1lcmdlZE9wdGlvbnM7XG4gICAgLy8gR2V0IG5ldHdvcmsgc2l6ZSBhcnJheSBmb3IgTmV1cmFsTmV0d29yayBvciBOZXVyYWxOZXR3b3JrR1BVXG4gICAgbGV0IHNpemVzID0gW107XG4gICAgaWYgKG5ldCBpbnN0YW5jZW9mIE5ldXJhbE5ldHdvcmsgfHwgbmV0IGluc3RhbmNlb2YgTmV1cmFsTmV0d29ya0dQVSkge1xuICAgICAgICBzaXplcyA9IGdldE5ldXJhbE5ldHdvcmtTaXplcyhuZXQpO1xuICAgIH1cbiAgICAvLyBnZXQgbmV0d29yayBzaXplIGZvciBSZWN1cnJlbnRcbiAgICBlbHNlIGlmIChuZXQgaW5zdGFuY2VvZiBSZWN1cnJlbnQpIHtcbiAgICAgICAgY29uc3QgeyBpbnB1dFNpemUsIGhpZGRlbkxheWVycywgb3V0cHV0U2l6ZSB9ID0gZ2V0UmVjdXJyZW50TGF5ZXJzKG5ldCk7XG4gICAgICAgIHNpemVzID0gW2lucHV0U2l6ZV0uY29uY2F0KGhpZGRlbkxheWVycykuY29uY2F0KFtvdXRwdXRTaXplXSk7XG4gICAgfVxuICAgIC8vIGdldCBuZXR3b3JrIHNpemUgZm9yIEZlZWRGb3J3YXJkXG4gICAgZWxzZSBpZiAobmV0IGluc3RhbmNlb2YgRmVlZEZvcndhcmQpIHtcbiAgICAgICAgY29uc3QgeyBpbnB1dFNpemUsIGhpZGRlbkxheWVycywgb3V0cHV0U2l6ZSB9ID0gZ2V0RmVlZEZvcndhcmRMYXllcnMobmV0KTtcbiAgICAgICAgc2l6ZXMgPSBbaW5wdXRTaXplXS5jb25jYXQoaGlkZGVuTGF5ZXJzKS5jb25jYXQoW291dHB1dFNpemVdKTtcbiAgICB9XG4gICAgLy8gaGFuZGxlIGpzb24sIHJlY3VycmVudCBmaXJzdFxuICAgIGVsc2UgaWYgKG5ldCBpbnN0YW5jZW9mIFJOTiB8fFxuICAgICAgICBuZXQgaW5zdGFuY2VvZiBMU1RNIHx8XG4gICAgICAgIG5ldCBpbnN0YW5jZW9mIEdSVSB8fFxuICAgICAgICBuZXQgaW5zdGFuY2VvZiBSTk5UaW1lU3RlcCB8fFxuICAgICAgICBuZXQgaW5zdGFuY2VvZiBMU1RNVGltZVN0ZXAgfHxcbiAgICAgICAgbmV0IGluc3RhbmNlb2YgR1JVVGltZVN0ZXApIHtcbiAgICAgICAgcmV0dXJuIHdyYXBPdXRlclNWRyhybm5Ub0lubmVyU1ZHKHtcbiAgICAgICAgICAgIC4uLm1lcmdlZE9wdGlvbnMsXG4gICAgICAgICAgICBzaXplczogY2hlY2tTaXplcyhnZXRSTk5TaXplcyhuZXQpLCBpbnB1dHMubGFiZWxzKSxcbiAgICAgICAgfSksIHdpZHRoLCBoZWlnaHQpO1xuICAgIH1cbiAgICAvLyBoYW5kbGUganNvbiwgTmV1cmFsTmV0d29ya1xuICAgIGVsc2UgaWYgKG5ldC5oYXNPd25Qcm9wZXJ0eSgndHlwZScpKSB7XG4gICAgICAgIHN3aXRjaCAobmV0LnR5cGUpIHtcbiAgICAgICAgICAgIGNhc2UgJ05ldXJhbE5ldHdvcmsnOlxuICAgICAgICAgICAgY2FzZSAnTmV1cmFsTmV0d29ya0dQVSc6XG4gICAgICAgICAgICAgICAgcmV0dXJuIHdyYXBPdXRlclNWRyhuZXVyYWxOZXR3b3JrVG9Jbm5lclNWRyh7XG4gICAgICAgICAgICAgICAgICAgIC4uLm1lcmdlZE9wdGlvbnMsXG4gICAgICAgICAgICAgICAgICAgIHNpemVzOiBjaGVja1NpemVzKGdldE5ldXJhbE5ldHdvcmtKU09OU2l6ZXMobmV0KSwgaW5wdXRzLmxhYmVscyksXG4gICAgICAgICAgICAgICAgfSksIHdpZHRoLCBoZWlnaHQpO1xuICAgICAgICAgICAgY2FzZSAnUk5OJzpcbiAgICAgICAgICAgIGNhc2UgJ0dSVSc6XG4gICAgICAgICAgICBjYXNlICdMU1RNJzpcbiAgICAgICAgICAgIGNhc2UgJ1JOTlRpbWVTdGVwJzpcbiAgICAgICAgICAgIGNhc2UgJ0dSVVRpbWVTdGVwJzpcbiAgICAgICAgICAgIGNhc2UgJ0xTVE1UaW1lU3RlcCc6XG4gICAgICAgICAgICAgICAgcmV0dXJuIHdyYXBPdXRlclNWRyhybm5Ub0lubmVyU1ZHKHtcbiAgICAgICAgICAgICAgICAgICAgLi4ubWVyZ2VkT3B0aW9ucyxcbiAgICAgICAgICAgICAgICAgICAgc2l6ZXM6IGNoZWNrU2l6ZXMoZ2V0Uk5OU2l6ZXMobmV0KSwgaW5wdXRzLmxhYmVscyksXG4gICAgICAgICAgICAgICAgfSksIHdpZHRoLCBoZWlnaHQpO1xuICAgICAgICAgICAgZGVmYXVsdDpcbiAgICAgICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ3VucmVjb2duaXplZCBuZXR3b3JrJyk7XG4gICAgICAgIH1cbiAgICB9XG4gICAgZWxzZSBpZiAobmV0Lmhhc093blByb3BlcnR5KCdpbnB1dFNpemUnKSAmJlxuICAgICAgICBuZXQuaGFzT3duUHJvcGVydHkoJ2hpZGRlbkxheWVycycpICYmXG4gICAgICAgIG5ldC5oYXNPd25Qcm9wZXJ0eSgnb3V0cHV0U2l6ZScpKSB7XG4gICAgICAgIGNvbnN0IHsgaW5wdXRTaXplLCBoaWRkZW5MYXllcnMsIG91dHB1dFNpemUgfSA9IG5ldDtcbiAgICAgICAgc2l6ZXMgPSBbaW5wdXRTaXplLCAuLi5oaWRkZW5MYXllcnMsIG91dHB1dFNpemVdO1xuICAgIH1cbiAgICBlbHNlIGlmIChuZXQuaGFzT3duUHJvcGVydHkoJ3NpemVzJykpIHtcbiAgICAgICAgc2l6ZXMgPSBuZXQuc2l6ZXM7XG4gICAgfVxuICAgIGVsc2Uge1xuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ3VucmVjb2duaXplZCBuZXR3b3JrJyk7XG4gICAgfVxuICAgIHJldHVybiB3cmFwT3V0ZXJTVkcobmV1cmFsTmV0d29ya1RvSW5uZXJTVkcoe1xuICAgICAgICAuLi5tZXJnZWRPcHRpb25zLFxuICAgICAgICBzaXplczogY2hlY2tTaXplcyhzaXplcywgaW5wdXRzLmxhYmVscyksXG4gICAgfSksIHdpZHRoLCBoZWlnaHQpO1xufVxuZnVuY3Rpb24gY2hlY2tTaXplcyhzaXplcywgbGFiZWxzKSB7XG4gICAgaWYgKCFzaXplcykge1xuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ3NpemVzIG5vdCBzZXQnKTtcbiAgICB9XG4gICAgaWYgKHNpemVzLnNvbWUoKHNpemUpID0+IHNpemUgPCAxKSkge1xuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ3NpemVzIG5vdCBzZXQgY29ycmVjdGx5Jyk7XG4gICAgfVxuICAgIGlmIChsYWJlbHMgJiYgbGFiZWxzLmxlbmd0aCAhPT0gc2l6ZXNbMF0pIHtcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdub3QgZW5vdWdoIGxhYmVscyBmb3IgaW5wdXRzJyk7XG4gICAgfVxuICAgIHJldHVybiBzaXplcztcbn1cblxuY29uc3QgcmVjdXJyZW50ID0ge1xuICAgIFJOTlRpbWVTdGVwLFxuICAgIExTVE1UaW1lU3RlcCxcbiAgICBHUlVUaW1lU3RlcCxcbiAgICBSTk4sXG4gICAgTFNUTSxcbiAgICBHUlUsXG59O1xuY29uc3QgdXRpbGl0aWVzID0ge1xuICAgIG1heCxcbiAgICBtc2U6IG1zZSQxLFxuICAgIG9uZXM6IG9uZXMkMSxcbiAgICBvbmVzMkQsXG4gICAgcmFuZG9tOiByYW5kb20kMSxcbiAgICByYW5kb21XZWlnaHQsXG4gICAgcmFuZG9zLFxuICAgIHJhbmdlLFxuICAgIHRvQXJyYXksXG4gICAgRGF0YUZvcm1hdHRlcixcbiAgICB6ZXJvczogemVyb3MkMSxcbiAgICB0b1NWRyxcbn07XG5cbmNsYXNzIFRyYWluU3RyZWFtIGV4dGVuZHMgc3RyZWFtLldyaXRhYmxlIHtcbiAgICBjb25zdHJ1Y3RvcihvcHRpb25zKSB7XG4gICAgICAgIHN1cGVyKHtcbiAgICAgICAgICAgIG9iamVjdE1vZGU6IHRydWUsXG4gICAgICAgIH0pO1xuICAgICAgICAvLyByZXF1aXJlIHRoZSBuZXVyYWxOZXR3b3JrXG4gICAgICAgIGlmICghb3B0aW9ucy5uZXVyYWxOZXR3b3JrKSB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ05vIG5ldXJhbCBuZXR3b3JrIHNwZWNpZmllZC4gUGxlYXNlIHNlZSBsaXN0IG9mIGF2YWlsYWJsZSBuZXR3b3JrIHR5cGVzOiBodHRwczovL2dpdGh1Yi5jb20vQnJhaW5KUy9icmFpbi5qcyNuZXVyYWwtbmV0d29yay10eXBlcycpO1xuICAgICAgICB9XG4gICAgICAgIGNvbnN0IHsgbmV1cmFsTmV0d29yayB9ID0gb3B0aW9ucztcbiAgICAgICAgLy8gaW5oZXJpdCB0cmFpbk9wdHMgc2V0dGluZ3MgZnJvbSBuZXVyYWxOZXR3b3JrXG4gICAgICAgIG5ldXJhbE5ldHdvcmsudXBkYXRlVHJhaW5pbmdPcHRpb25zKG9wdGlvbnMpO1xuICAgICAgICBjb25zdCB0cmFpbk9wdHMgPSBuZXVyYWxOZXR3b3JrID09PSBudWxsIHx8IG5ldXJhbE5ldHdvcmsgPT09IHZvaWQgMCA/IHZvaWQgMCA6IG5ldXJhbE5ldHdvcmsudHJhaW5PcHRzOyAvLyBqdXN0IHVwZGF0ZWQgZnJvbSBhYm92ZSBsaW5lXG4gICAgICAgIHRoaXMubmV1cmFsTmV0d29yayA9IG5ldXJhbE5ldHdvcms7XG4gICAgICAgIHRoaXMuZGF0YUZvcm1hdERldGVybWluZWQgPSBmYWxzZTtcbiAgICAgICAgdGhpcy5pID0gMDsgLy8ga2VlcCB0cmFjayBvZiBpbnRlcm5hbCBpdGVyYXRpb25zXG4gICAgICAgIHRoaXMuc2l6ZSA9IDA7XG4gICAgICAgIHRoaXMuY291bnQgPSAwO1xuICAgICAgICB0aGlzLnN1bSA9IDA7XG4gICAgICAgIHRoaXMuZmxvb2RDYWxsYmFjayA9IG9wdGlvbnMuZmxvb2RDYWxsYmFjaztcbiAgICAgICAgdGhpcy5kb25lVHJhaW5pbmdDYWxsYmFjayA9IG9wdGlvbnMuZG9uZVRyYWluaW5nQ2FsbGJhY2s7XG4gICAgICAgIHRoaXMuaXRlcmF0aW9ucyA9IHRyYWluT3B0cy5pdGVyYXRpb25zO1xuICAgICAgICB0aGlzLmVycm9yVGhyZXNoID0gdHJhaW5PcHRzLmVycm9yVGhyZXNoO1xuICAgICAgICB0aGlzLmxvZyA9IHRyYWluT3B0cy5sb2c7XG4gICAgICAgIHRoaXMubG9nUGVyaW9kID0gdHJhaW5PcHRzLmxvZ1BlcmlvZDtcbiAgICAgICAgdGhpcy5jYWxsYmFja1BlcmlvZCA9IHRyYWluT3B0cy5jYWxsYmFja1BlcmlvZDtcbiAgICAgICAgdGhpcy5vbignZmluaXNoJywgdGhpcy5maW5pc2hTdHJlYW1JdGVyYXRpb24uYmluZCh0aGlzKSk7XG4gICAgICAgIHRoaXMuY2FsbGJhY2sgPSB0cmFpbk9wdHMuY2FsbGJhY2s7XG4gICAgfVxuICAgIGVuZElucHV0cygpIHtcbiAgICAgICAgdGhpcy53cml0ZShmYWxzZSk7XG4gICAgfVxuICAgIF93cml0ZShjaHVuaywgZW5jLCBuZXh0KSB7XG4gICAgICAgIGlmICghY2h1bmspIHtcbiAgICAgICAgICAgIC8vIGNoZWNrIGZvciB0aGUgZW5kIG9mIG9uZSBpdGVyYXRpb24gb2YgdGhlIHN0cmVhbVxuICAgICAgICAgICAgdGhpcy5lbWl0KCdmaW5pc2gnKTtcbiAgICAgICAgICAgIHJldHVybiBuZXh0KCk7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKCF0aGlzLmRhdGFGb3JtYXREZXRlcm1pbmVkKSB7XG4gICAgICAgICAgICB0aGlzLnNpemUrKztcbiAgICAgICAgICAgIHRoaXMubmV1cmFsTmV0d29yay5hZGRGb3JtYXQoY2h1bmspO1xuICAgICAgICAgICAgaWYgKHRoaXMuZmlyc3REYXR1bSA9PT0gdW5kZWZpbmVkKSB7XG4gICAgICAgICAgICAgICAgdGhpcy5maXJzdERhdHVtID0gY2h1bms7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICByZXR1cm4gbmV4dCgpO1xuICAgICAgICB9XG4gICAgICAgIHRoaXMuY291bnQrKztcbiAgICAgICAgY29uc3QgZGF0YSA9IHRoaXMubmV1cmFsTmV0d29yay5mb3JtYXREYXRhKFtjaHVua10pO1xuICAgICAgICBjb25zdCBlcnJvciA9IHRoaXMubmV1cmFsTmV0d29yay50cmFpblBhdHRlcm4oZGF0YVswXSwgdHJ1ZSk7XG4gICAgICAgIGlmIChlcnJvciAhPT0gbnVsbCkge1xuICAgICAgICAgICAgdGhpcy5zdW0gKz0gZXJyb3I7XG4gICAgICAgIH1cbiAgICAgICAgLy8gdGVsbCB0aGUgUmVhZGFibGUgU3RyZWFtIHRoYXQgd2UgYXJlIHJlYWR5IGZvciBtb3JlIGRhdGFcbiAgICAgICAgbmV4dCgpO1xuICAgIH1cbiAgICBmaW5pc2hTdHJlYW1JdGVyYXRpb24oKSB7XG4gICAgICAgIGlmICh0aGlzLmRhdGFGb3JtYXREZXRlcm1pbmVkICYmIHRoaXMuc2l6ZSAhPT0gdGhpcy5jb3VudCkge1xuICAgICAgICAgICAgY29uc29sZS53YXJuKFwiVGhpcyBpdGVyYXRpb24ncyBkYXRhIGxlbmd0aCB3YXMgZGlmZmVyZW50IGZyb20gdGhlIGZpcnN0IVwiKTtcbiAgICAgICAgfVxuICAgICAgICBpZiAoIXRoaXMuZGF0YUZvcm1hdERldGVybWluZWQgJiYgdGhpcy5maXJzdERhdHVtICE9PSB1bmRlZmluZWQpIHtcbiAgICAgICAgICAgIGNvbnN0IGRhdGEgPSB0aGlzLm5ldXJhbE5ldHdvcmsuZm9ybWF0RGF0YShbdGhpcy5maXJzdERhdHVtXSk7XG4gICAgICAgICAgICB0aGlzLm5ldXJhbE5ldHdvcmsudmVyaWZ5SXNJbml0aWFsaXplZChkYXRhKTtcbiAgICAgICAgICAgIHRoaXMuZGF0YUZvcm1hdERldGVybWluZWQgPSB0cnVlO1xuICAgICAgICAgICAgaWYgKHR5cGVvZiB0aGlzLmZsb29kQ2FsbGJhY2sgPT09ICdmdW5jdGlvbicpIHtcbiAgICAgICAgICAgICAgICB0aGlzLmZsb29kQ2FsbGJhY2soKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCBlcnJvciA9IHRoaXMuc3VtIC8gdGhpcy5zaXplO1xuICAgICAgICBpZiAodGhpcy5sb2cgJiYgdGhpcy5pICUgdGhpcy5sb2dQZXJpb2QgPT09IDApIHtcbiAgICAgICAgICAgIGlmICh0eXBlb2YgdGhpcy5sb2cgPT09ICdmdW5jdGlvbicpIHtcbiAgICAgICAgICAgICAgICB0aGlzLmxvZyh7XG4gICAgICAgICAgICAgICAgICAgIGl0ZXJhdGlvbnM6IHRoaXMuaSxcbiAgICAgICAgICAgICAgICAgICAgZXJyb3I6IGVycm9yLFxuICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgICAgY29uc29sZS5pbmZvKGBpdGVyYXRpb25zOiAke3RoaXMuaX0sIHRyYWluaW5nIGVycm9yOiAke2Vycm9yfWApO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIGlmICh0aGlzLmNhbGxiYWNrICYmIHRoaXMuaSAlIHRoaXMuY2FsbGJhY2tQZXJpb2QgPT09IDApIHtcbiAgICAgICAgICAgIHRoaXMuY2FsbGJhY2soe1xuICAgICAgICAgICAgICAgIGVycm9yLFxuICAgICAgICAgICAgICAgIGl0ZXJhdGlvbnM6IHRoaXMuaSxcbiAgICAgICAgICAgIH0pO1xuICAgICAgICB9XG4gICAgICAgIHRoaXMuc3VtID0gMDtcbiAgICAgICAgdGhpcy5jb3VudCA9IDA7XG4gICAgICAgIC8vIHVwZGF0ZSB0aGUgaXRlcmF0aW9uc1xuICAgICAgICB0aGlzLmkrKztcbiAgICAgICAgLy8gZG8gYSBjaGVjayBoZXJlIHRvIHNlZSBpZiB3ZSBuZWVkIHRoZSBzdHJlYW0gYWdhaW5cbiAgICAgICAgaWYgKHRoaXMuaSA8IHRoaXMuaXRlcmF0aW9ucyAmJiBlcnJvciA+IHRoaXMuZXJyb3JUaHJlc2gpIHtcbiAgICAgICAgICAgIGlmICh0eXBlb2YgdGhpcy5mbG9vZENhbGxiYWNrID09PSAnZnVuY3Rpb24nKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIHRoaXMuZmxvb2RDYWxsYmFjaygpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgLy8gZG9uZSB0cmFpbmluZ1xuICAgICAgICAgICAgaWYgKHR5cGVvZiB0aGlzLmRvbmVUcmFpbmluZ0NhbGxiYWNrID09PSAnZnVuY3Rpb24nKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIHRoaXMuZG9uZVRyYWluaW5nQ2FsbGJhY2soe1xuICAgICAgICAgICAgICAgICAgICBlcnJvcixcbiAgICAgICAgICAgICAgICAgICAgaXRlcmF0aW9uczogdGhpcy5pLFxuICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfVxufVxuXG5leHBvcnRzLkNyb3NzVmFsaWRhdGUgPSBDcm9zc1ZhbGlkYXRlO1xuZXhwb3J0cy5GZWVkRm9yd2FyZCA9IEZlZWRGb3J3YXJkO1xuZXhwb3J0cy5OZXVyYWxOZXR3b3JrID0gTmV1cmFsTmV0d29yaztcbmV4cG9ydHMuTmV1cmFsTmV0d29ya0dQVSA9IE5ldXJhbE5ldHdvcmtHUFU7XG5leHBvcnRzLlJlY3VycmVudCA9IFJlY3VycmVudDtcbmV4cG9ydHMuVHJhaW5TdHJlYW0gPSBUcmFpblN0cmVhbTtcbmV4cG9ydHMuYWN0aXZhdGlvbiA9IGluZGV4JDE7XG5leHBvcnRzLmxheWVyID0gbGF5ZXI7XG5leHBvcnRzLmxheWVyVHlwZXMgPSBsYXllclR5cGVzO1xuZXhwb3J0cy5saWtlbHkgPSBsaWtlbHk7XG5leHBvcnRzLmxvb2t1cCA9IGxvb2t1cDtcbmV4cG9ydHMucHJheGlzID0gaW5kZXg7XG5leHBvcnRzLnJlY3VycmVudCA9IHJlY3VycmVudDtcbmV4cG9ydHMudXRpbGl0aWVzID0gdXRpbGl0aWVzO1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9aW5kZXgubWFwXG4iLCJpbXBvcnQgUmVhY3QgZnJvbSAncmVhY3QnXG5pbXBvcnQgeyBBcHBQcm9wcyB9IGZyb20gJ25leHQvYXBwJ1xuaW1wb3J0IHsgQ2hha3JhUHJvdmlkZXIgfSBmcm9tICdAY2hha3JhLXVpL3JlYWN0JztcbmltcG9ydCB7IEJyYWluUHJvdmlkZXIgfSBmcm9tICcuLi9zcmMvY29udGV4dC9CcmFpbkNvbnRleHQnO1xuXG5jb25zdCBNeUFwcDogUmVhY3QuRkM8QXBwUHJvcHM+ID0gKHsgQ29tcG9uZW50LCBwYWdlUHJvcHMgfSkgPT4ge1xuICByZXR1cm4gKFxuICAgIDxDaGFrcmFQcm92aWRlcj5cbiAgICAgIDxCcmFpblByb3ZpZGVyPlxuICAgICAgICA8Q29tcG9uZW50IHsuLi5wYWdlUHJvcHN9IC8+XG4gICAgICA8L0JyYWluUHJvdmlkZXI+XG4gICAgPC9DaGFrcmFQcm92aWRlcj5cbiAgKTtcbn1cblxuZXhwb3J0IGRlZmF1bHQgTXlBcHAiLCJpbXBvcnQgeyBjcmVhdGVDb250ZXh0LCBEaXNwYXRjaCwgU2V0U3RhdGVBY3Rpb24sIHVzZUNvbnRleHQsIHVzZUVmZmVjdCwgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7IGZldGNoRGFpbHlEYXRhLCBmZXRjaEdsb2JhbERhdGEgfSBmcm9tIFwiLi4vc2VydmljZXMvYXBpXCI7XG5pbXBvcnQgKiBhcyBicmFpbiBmcm9tICdicmFpbi5qcyc7XG4vLyBpbXBvcnQgc2NhbGVyIGZyb20gJ21pbm1heHNjYWxlcidcbmltcG9ydCBzY2FsZXIgZnJvbSAnLi4vdXRpbHMvc2NhbGVyJ1xuXG50eXBlIERhaWx5RGF0YSA9IHtcbiAgcG9zaXRpdmU6IG51bWJlcixcbiAgcmVjb3ZlcmVkOiBudW1iZXIsXG4gIGRlYXRoOiBudW1iZXIsXG4gIGRhdGU6IHN0cmluZ1xufVxuXG50eXBlIFRyYWluaW5nRGF0YSA9IHtcbiAgY29uZmlybWVkOiBudW1iZXIsXG4gIHJlY292ZXJlZDogbnVtYmVyLFxuICBkZWF0aHM6IG51bWJlcixcbiAgZGF0ZTogc3RyaW5nXG59XG5cbnR5cGUgVHJhaW5pbmdDaGFydCA9IHtcbiAgZGF0YToge1xuICAgIGxhYmVsczogc3RyaW5nW107XG4gICAgZGF0YXNldHM6ICh7XG4gICAgICAgIGRhdGE6IG51bWJlcltdO1xuICAgICAgICBsYWJlbDogc3RyaW5nO1xuICAgICAgICBib3JkZXJDb2xvcjogc3RyaW5nO1xuICAgICAgICBiYWNrZ3JvdW5kQ29sb3I6IHN0cmluZztcbiAgICAgICAgZmlsbD86IHVuZGVmaW5lZDtcbiAgICB9IHwge1xuICAgICAgICBkYXRhOiBudW1iZXJbXTtcbiAgICAgICAgbGFiZWw6IHN0cmluZztcbiAgICAgICAgYm9yZGVyQ29sb3I6IHN0cmluZztcbiAgICAgICAgYmFja2dyb3VuZENvbG9yOiBzdHJpbmc7XG4gICAgICAgIGZpbGw6IGJvb2xlYW47XG4gICAgfSlbXTtcbiAgfTtcbiAgb3B0aW9uczoge1xuICAgIHJlc3BvbnNpdmU6IGJvb2xlYW4sXG4gICAgcGx1Z2luczoge1xuICAgICAgbGVnZW5kOiB7XG4gICAgICAgIHBvc2l0aW9uOiBhbnksXG4gICAgICB9LFxuICAgICAgdGl0bGU6IHtcbiAgICAgICAgZGlzcGxheTogYm9vbGVhbixcbiAgICAgICAgdGV4dDogc3RyaW5nLFxuICAgICAgfSxcbiAgICB9XG4gIH07XG59XG5cbnR5cGUgUHJlZGljdGVkQ2hhcnQgPSB7XG4gIGRhdGE6IHtcbiAgICBsYWJlbHM6IG51bWJlcltdO1xuICAgIGRhdGFzZXRzOiB7XG4gICAgICAgIGRhdGE6IG51bWJlcltdO1xuICAgICAgICBsYWJlbDogc3RyaW5nO1xuICAgICAgICBib3JkZXJDb2xvcjogc3RyaW5nO1xuICAgICAgICBiYWNrZ3JvdW5kQ29sb3I6IHN0cmluZztcbiAgICB9W107XG4gIH07XG4gIG9wdGlvbnM6IHtcbiAgICAgIHJlc3BvbnNpdmU6IGJvb2xlYW47XG4gICAgICBwbHVnaW5zOiB7XG4gICAgICAgICAgbGVnZW5kOiB7XG4gICAgICAgICAgICAgIHBvc2l0aW9uOiBhbnk7XG4gICAgICAgICAgfTtcbiAgICAgICAgICB0aXRsZToge1xuICAgICAgICAgICAgICBkaXNwbGF5OiBib29sZWFuO1xuICAgICAgICAgICAgICB0ZXh0OiBzdHJpbmc7XG4gICAgICAgICAgfTtcbiAgICAgIH07XG4gIH07XG59XG5cbnR5cGUgQnJhaW5Db250ZXh0VHlwZSA9IHtcbiAgdHJhaW5pbmdEYXRhOiBUcmFpbmluZ0RhdGFbXSxcbiAgc2V0VHJhaW5pbmdEYXRhOiBEaXNwYXRjaDxTZXRTdGF0ZUFjdGlvbjxUcmFpbmluZ0RhdGFbXT4+LFxuICBzZXREYWlseURhdGE6IERpc3BhdGNoPFNldFN0YXRlQWN0aW9uPERhaWx5RGF0YVtdPj4sXG4gIGRhaWx5RGF0YTogRGFpbHlEYXRhW10sXG4gIHRyYWluaW5nQ2hhcnREYXRhOiBUcmFpbmluZ0NoYXJ0LFxuICBwcmVkaWN0ZWRDaGFydERhdGE6IFByZWRpY3RlZENoYXJ0LFxuICBmb3JlY2FzdDogKGRhdGE6IFRyYWluaW5nRGF0YVtdLCBkYXlzOiBudW1iZXIpID0+IHZvaWQsXG4gIGRheXNJbnB1dDogc3RyaW5nLFxuICBzZXREYXlzSW5wdXQ6IERpc3BhdGNoPFNldFN0YXRlQWN0aW9uPHN0cmluZz4+LFxuICBwcmVkaWN0aW9uOiBudW1iZXJbXSxcbiAgdHJhaW5pbmc6IGJvb2xlYW5cbn1cblxuZXhwb3J0IGNvbnN0IEJyYWluQ29udGV4dCA9IGNyZWF0ZUNvbnRleHQoe30gYXMgQnJhaW5Db250ZXh0VHlwZSlcblxuZXhwb3J0IGNvbnN0IEJyYWluUHJvdmlkZXIgPSAoeyBjaGlsZHJlbiB9KSA9PiB7XG5cbiAgY29uc3QgW3RyYWluaW5nLCBzZXRUcmFpbmluZ10gPSB1c2VTdGF0ZShmYWxzZSlcbiAgY29uc3QgW2RhaWx5RGF0YSwgc2V0RGFpbHlEYXRhXSA9IHVzZVN0YXRlPERhaWx5RGF0YVtdPihbXSlcbiAgY29uc3QgW2dsb2JhbERhdGEsIHNldEdsb2JhbERhdGFdID0gdXNlU3RhdGUoe30pXG4gIGNvbnN0IFt0cmFpbmluZ0RhdGEsIHNldFRyYWluaW5nRGF0YV0gPSB1c2VTdGF0ZTxUcmFpbmluZ0RhdGFbXT4oW10pXG5cbiAgY29uc3QgW2RheXNJbnB1dCwgc2V0RGF5c0lucHV0XSA9IHVzZVN0YXRlKCcnKVxuICBjb25zdCBbcHJlZGljdGlvbiwgc2V0UHJlZGljdGlvbl0gPSB1c2VTdGF0ZShbXSk7XG5cbiAgY29uc3QgcHJlZGljdGVkQ2hhcnREYXRhID0ge1xuICAgIGRhdGE6IHtcbiAgICAgIGxhYmVsczogcHJlZGljdGlvbi5tYXAoKCBuLCBpbmRleCApID0+IGluZGV4KSxcbiAgICAgIGRhdGFzZXRzOiBbe1xuICAgICAgICBkYXRhOiBwcmVkaWN0aW9uLm1hcCgoZGF0YSkgPT4gZGF0YSksXG4gICAgICAgIGxhYmVsOiAnSW5mZWN0ZWQnLFxuICAgICAgICBib3JkZXJDb2xvcjogJ3JnYig1MywgMTYyLCAyMzUpJyxcbiAgICAgICAgYmFja2dyb3VuZENvbG9yOiAncmdiYSg1MywgMTYyLCAyMzUsIDAuNSknLFxuICAgICAgfV0sXG4gICAgfSxcbiAgICBvcHRpb25zOiB7XG4gICAgICByZXNwb25zaXZlOiB0cnVlLFxuICAgICAgcGx1Z2luczoge1xuICAgICAgICBsZWdlbmQ6IHtcbiAgICAgICAgICBwb3NpdGlvbjogJ3RvcCcgYXMgY29uc3QsXG4gICAgICAgIH0sXG4gICAgICAgIHRpdGxlOiB7XG4gICAgICAgICAgZGlzcGxheTogdHJ1ZSxcbiAgICAgICAgICB0ZXh0OiAnWW91ciBDb3ZpZC0xOSBpbmZlY3Rpb24gZm9yZWNhc3RpbmcnLFxuICAgICAgICB9LFxuICAgICAgfVxuICAgIH1cbiAgfVxuXG4gIGNvbnN0IHRyYWluaW5nQ2hhcnREYXRhID0ge1xuICAgIGRhdGE6IHtcbiAgICAgIGxhYmVsczogdHJhaW5pbmdEYXRhLm1hcCgoeyBkYXRlIH0pID0+IG5ldyBEYXRlKGRhdGUpLnRvTG9jYWxlRGF0ZVN0cmluZygpKSxcbiAgICAgIGRhdGFzZXRzOiBbe1xuICAgICAgICBkYXRhOiB0cmFpbmluZ0RhdGEubWFwKChkYXRhKSA9PiBkYXRhLmNvbmZpcm1lZCksXG4gICAgICAgIGxhYmVsOiAnSW5mZWN0ZWQnLFxuICAgICAgICBib3JkZXJDb2xvcjogJ3JnYig1MywgMTYyLCAyMzUpJyxcbiAgICAgICAgYmFja2dyb3VuZENvbG9yOiAncmdiYSg1MywgMTYyLCAyMzUsIDAuNSknLFxuICAgICAgfSwge1xuICAgICAgICBkYXRhOiB0cmFpbmluZ0RhdGEubWFwKChkYXRhKSA9PiBkYXRhLmRlYXRocyksXG4gICAgICAgIGxhYmVsOiAnRGVhdGhzJyxcbiAgICAgICAgYm9yZGVyQ29sb3I6ICdyZ2IoMjU1LCA5OSwgMTMyKScsXG4gICAgICAgIGJhY2tncm91bmRDb2xvcjogJ3JnYmEoMjU1LCA5OSwgMTMyLCAwLjUpJyxcbiAgICAgIH1dLFxuICAgIH0sXG4gICAgb3B0aW9uczoge1xuICAgICAgcmVzcG9uc2l2ZTogdHJ1ZSxcbiAgICAgIHBsdWdpbnM6IHtcbiAgICAgICAgbGVnZW5kOiB7XG4gICAgICAgICAgcG9zaXRpb246ICd0b3AnIGFzIGNvbnN0LFxuICAgICAgICB9LFxuICAgICAgICB0aXRsZToge1xuICAgICAgICAgIGRpc3BsYXk6IHRydWUsXG4gICAgICAgICAgdGV4dDogJ0FJIHRyYWluaW5nIGRhdGEnLFxuICAgICAgICB9LFxuICAgICAgfVxuICAgIH1cbiAgfVxuXG4gIGNvbnN0IGZvcmVjYXN0ID0gKHRyYWluaW5nRGF0YTogVHJhaW5pbmdEYXRhW10sIGRheXNJbnB1dDogbnVtYmVyKSA9PiB7XG4gICAgc2V0VHJhaW5pbmcodHJ1ZSlcblxuICAgIGNvbnN0IG5ld1RyYWluaW5nRGF0YSA9IG5ldyBBcnJheSg1MCkuZmlsbCgwKVxuXG4gICAgaWYgKHRyYWluaW5nRGF0YSkge1xuICAgICAgZm9yKGxldCBpID0gMDsgaSA8PSA1MDsgaSArKykge1xuICAgICAgICBuZXdUcmFpbmluZ0RhdGFbaV0gPSB0cmFpbmluZ0RhdGFbdHJhaW5pbmdEYXRhLmxlbmd0aCAtIDUxICsgaV0/LmNvbmZpcm1lZFxuICAgICAgfVxuICAgIH1cblxuICAgIGNvbnN0IHNjYWxlZERhdGEgPSBzY2FsZXIuZml0X3RyYW5zZm9ybShuZXdUcmFpbmluZ0RhdGEpO1xuXG4gICAgY29uc3QgbmV0d29yayA9IG5ldyBicmFpbi5yZWN1cnJlbnQuTFNUTVRpbWVTdGVwKHtcbiAgICAgIGlucHV0U2l6ZTogMSxcbiAgICAgIGhpZGRlbkxheWVyczogWzEwXSxcbiAgICAgIG91dHB1dFNpemU6IDFcbiAgICB9KVxuXG4gICAgbmV0d29yay50cmFpbihbc2NhbGVkRGF0YV0sIHtcbiAgICAgIGxlYXJuaW5nUmF0ZTogMC4wMDUsXG4gICAgICBlcnJvclRocmVzaDogMC4wMSxcbiAgICAgIGxvZzogc3RhdHMgPT4ge1xuICAgICAgICBjb25zb2xlLmxvZyhzdGF0cyk7XG4gICAgICB9XG4gICAgfSlcblxuICAgIGNvbnN0IHJlc3VsdCA9IG5ldHdvcmsuZm9yZWNhc3QoWzFdLCBkYXlzSW5wdXQpXG4gICAgc2V0UHJlZGljdGlvbihzY2FsZXIuaW52ZXJzZV90cmFuc2Zvcm0ocmVzdWx0KSlcbiAgICBzZXRUcmFpbmluZyhmYWxzZSlcbiAgfVxuXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgY29uc3QgbG9hZERhaWx5RGF0YSA9IGFzeW5jICgpID0+IHtcbiAgICAgIGNvbnN0IGluaXRpYWxEYWlseURhdGEgPSBhd2FpdCBmZXRjaERhaWx5RGF0YSgpXG5cbiAgICAgIGlmIChpbml0aWFsRGFpbHlEYXRhKSB7XG4gICAgICAgIHNldERhaWx5RGF0YShpbml0aWFsRGFpbHlEYXRhKTtcbiAgICAgIH1cbiAgICB9XG5cbiAgICBjb25zdCBsb2FkR2xvYmFsRGF0YSA9IGFzeW5jICgpID0+IHtcbiAgICAgIGNvbnN0IGdsb2JhbERhdGEgPSBhd2FpdCBmZXRjaEdsb2JhbERhdGEoKVxuICAgICAgaWYgKGdsb2JhbERhdGEpIHtcbiAgICAgICAgc2V0R2xvYmFsRGF0YShnbG9iYWxEYXRhKVxuICAgICAgfVxuICAgIH1cblxuICAgIGxvYWREYWlseURhdGEoKVxuICAgIGxvYWRHbG9iYWxEYXRhKClcbiAgfSwgW10pXG5cbiAgcmV0dXJuIChcbiAgICA8QnJhaW5Db250ZXh0LlByb3ZpZGVyXG4gICAgICB2YWx1ZT17e1xuICAgICAgICB0cmFpbmluZ0RhdGEsXG4gICAgICAgIHNldFRyYWluaW5nRGF0YSxcbiAgICAgICAgc2V0RGFpbHlEYXRhLFxuICAgICAgICBkYWlseURhdGEsXG4gICAgICAgIHRyYWluaW5nQ2hhcnREYXRhLFxuICAgICAgICBmb3JlY2FzdCxcbiAgICAgICAgZGF5c0lucHV0LFxuICAgICAgICBzZXREYXlzSW5wdXQsXG4gICAgICAgIHByZWRpY3Rpb24sXG4gICAgICAgIHByZWRpY3RlZENoYXJ0RGF0YSxcbiAgICAgICAgdHJhaW5pbmdcbiAgICAgIH19XG4gICAgPlxuICAgICAge2NoaWxkcmVufVxuICAgIDwvQnJhaW5Db250ZXh0LlByb3ZpZGVyPlxuICApO1xufVxuXG4vL2Vhc2llciBleHBvcnRcbmV4cG9ydCBjb25zdCB1c2VCcmFpbkNvbnRleHQgPSAoKSA9PiB1c2VDb250ZXh0KEJyYWluQ29udGV4dCk7XG4iLCJpbXBvcnQgYXhpb3MgZnJvbSAnYXhpb3MnXG5cbmV4cG9ydCBjb25zdCBhcGkgPSBheGlvcy5jcmVhdGUoe1xuICBiYXNlVVJMOiAnaHR0cHM6Ly9jb3ZpZC0xOS1zdGF0aXN0aWNzLnAucmFwaWRhcGkuY29tL3JlcG9ydHMnXG59KVxuXG5hcGkuZGVmYXVsdHMuaGVhZGVyc1sneC1yYXBpZGFwaS1ob3N0J10gPSAnY292aWQtMTktc3RhdGlzdGljcy5wLnJhcGlkYXBpLmNvbSc7XG5hcGkuZGVmYXVsdHMuaGVhZGVyc1sneC1yYXBpZGFwaS1rZXknXSA9ICcwYjhiODgyOTlkbXNoNjMzZDE3N2I0ODMwYmIycDFmNGU2MmpzbjlhNDEwYzdlOTFmYydcblxuYXBpLmludGVyY2VwdG9ycy5yZXF1ZXN0LnVzZShjb25maWcgPT4ge1xuICBjb25zb2xlLmxvZyhjb25maWcpO1xuICByZXR1cm4gY29uZmlnO1xufSk7XG5cbmV4cG9ydCBjb25zdCBmZXRjaEdsb2JhbERhdGEgPSBhc3luYyAoKSA9PiB7XG4gIHRyeSB7XG4gICAgY29uc3QgeyBkYXRhIH0gPSBhd2FpdCBhcGkuZ2V0KCcvdG90YWwnKTtcbiAgICByZXR1cm4gZGF0YTtcbiAgfSBjYXRjaCAoZXJyKSB7XG4gICAgcmV0dXJuIGVycjtcbiAgfVxufVxuXG5leHBvcnQgY29uc3QgZmV0Y2hEYWlseURhdGEgPSBhc3luYyAoKSA9PiB7XG4gIHRyeSB7XG4gICAgY29uc3QgeyBkYXRhIH0gPSBhd2FpdCBheGlvcy5nZXQoJ2h0dHBzOi8vYXBpLmNvdmlkdHJhY2tpbmcuY29tL3YxL3VzL2RhaWx5Lmpzb24nKTtcblxuICAgIHJldHVybiBkYXRhLm1hcCgoeyBwb3NpdGl2ZSwgcmVjb3ZlcmVkLCBkZWF0aCwgZGF0ZUNoZWNrZWQ6IGRhdGUgfSkgPT4gKHsgY29uZmlybWVkOiBwb3NpdGl2ZSwgcmVjb3ZlcmVkLCBkZWF0aHM6IGRlYXRoLCBkYXRlIH0pKTtcbiAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICByZXR1cm4gZXJyb3I7XG4gIH1cbn07IiwibGV0IFhfbWluID0gMDtcbmxldCBYX21heCA9IDA7XG5sZXQgbWluXyA9IDA7XG5sZXQgbWF4XyA9IDE7XG5cbmxldCBkYXRhID0geyBYX21heDogWF9tYXgsIFhfbWluOiBYX21pbiwgbWF4XzogbWF4XywgbWluXzogbWluXyB9O1xuXG5mdW5jdGlvbiBmaXQoWCwgbWluID0gMCwgbWF4ID0gMSkge1xuICBYX21heCA9IE1hdGgubWF4LmFwcGx5KG51bGwsIFgpO1xuICBYX21pbiA9IE1hdGgubWluLmFwcGx5KG51bGwsIFgpO1xuICBtaW5fID0gbWluO1xuICBtYXhfID0gbWF4O1xuXG4gIGRhdGEgPSB7IFhfbWF4OiBYX21heCwgWF9taW46IFhfbWluLCBtYXhfOiBtYXhfLCBtaW5fOiBtaW5fIH07XG5cbiAgY29uc3QgWF9taW5BcnIgPSBYLm1hcChmdW5jdGlvbiAodmFsdWVzKSB7XG4gICAgcmV0dXJuIHZhbHVlcyAtIFhfbWluO1xuICB9KTtcbiAgLy8gWF9zdGQgPSAoWCAtIFgubWluKCkpIC8gKFgubWF4KCkgLSBYLm1pbigpKVxuICBjb25zdCBYX3N0ZCA9IFhfbWluQXJyLm1hcChmdW5jdGlvbiAodmFsdWVzKSB7XG4gICAgcmV0dXJuIHZhbHVlcyAvIChYX21heCAtIFhfbWluKTtcbiAgfSk7XG4gIC8vIFhfc2NhbGVkID0gWF9zdGQgKiAobWF4IC0gbWluKSArIG1pblxuICBjb25zdCBYX3NjYWxlZCA9IFhfc3RkLm1hcChmdW5jdGlvbiAodmFsdWVzKSB7XG4gICAgcmV0dXJuIHZhbHVlcyAqIChtYXggLSBtaW4pICsgbWluO1xuICB9KTtcblxuICByZXR1cm4gWF9zY2FsZWQ7XG59XG5cbmZ1bmN0aW9uIGZpdF90cmFuc2Zvcm0oZGF0YSwgbWluID0gMCwgbWF4ID0gMSkge1xuICBjb25zdCB0cmFpbl9zY2FsZWQgPSBmaXQoZGF0YSwgbWluLCBtYXgpO1xuXG5cbiAgcmV0dXJuIHRyYWluX3NjYWxlZDtcbn1cblxuZnVuY3Rpb24gaW52ZXJzZV90cmFuc2Zvcm0oaW5wdXQsIG1pbiA9IDAsIG1heCA9IDEpIHtcbiAgY29uc3QgZml0ID0gZGF0YTtcbiAgY29uc29sZS5sb2coZml0KVxuXG4gIGNvbnN0IFggPSBpbnB1dC5tYXAoZnVuY3Rpb24gKHZhbHVlcykge1xuICAgIHJldHVybiAodmFsdWVzIC0gbWluKSAvIChtYXggLSBtaW4pO1xuICB9KTtcbiAgY29uc3QgWF8gPSBYLm1hcChmdW5jdGlvbiAodmFsdWVzKSB7XG4gICAgcmV0dXJuIHZhbHVlcyAqIChmaXQuWF9tYXggLSBmaXQuWF9taW4pICsgZml0LlhfbWluO1xuICB9KTtcblxuICByZXR1cm4gWF87XG59XG5cbmV4cG9ydCBkZWZhdWx0IHsgZml0X3RyYW5zZm9ybSwgaW52ZXJzZV90cmFuc2Zvcm0gfTsiLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJAY2hha3JhLXVpL3JlYWN0XCIpOyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcImF4aW9zXCIpOyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcImdwdS5qc1wiKTsiLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJyZWFjdFwiKTsiLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJyZWFjdC9qc3gtZGV2LXJ1bnRpbWVcIik7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwic3RyZWFtXCIpOyJdLCJuYW1lcyI6WyJSZWFjdCIsIkNoYWtyYVByb3ZpZGVyIiwiQnJhaW5Qcm92aWRlciIsIk15QXBwIiwiQ29tcG9uZW50IiwicGFnZVByb3BzIiwiY3JlYXRlQ29udGV4dCIsInVzZUNvbnRleHQiLCJ1c2VFZmZlY3QiLCJ1c2VTdGF0ZSIsImZldGNoRGFpbHlEYXRhIiwiZmV0Y2hHbG9iYWxEYXRhIiwiYnJhaW4iLCJzY2FsZXIiLCJCcmFpbkNvbnRleHQiLCJjaGlsZHJlbiIsInRyYWluaW5nIiwic2V0VHJhaW5pbmciLCJkYWlseURhdGEiLCJzZXREYWlseURhdGEiLCJnbG9iYWxEYXRhIiwic2V0R2xvYmFsRGF0YSIsInRyYWluaW5nRGF0YSIsInNldFRyYWluaW5nRGF0YSIsImRheXNJbnB1dCIsInNldERheXNJbnB1dCIsInByZWRpY3Rpb24iLCJzZXRQcmVkaWN0aW9uIiwicHJlZGljdGVkQ2hhcnREYXRhIiwiZGF0YSIsImxhYmVscyIsIm1hcCIsIm4iLCJpbmRleCIsImRhdGFzZXRzIiwibGFiZWwiLCJib3JkZXJDb2xvciIsImJhY2tncm91bmRDb2xvciIsIm9wdGlvbnMiLCJyZXNwb25zaXZlIiwicGx1Z2lucyIsImxlZ2VuZCIsInBvc2l0aW9uIiwidGl0bGUiLCJkaXNwbGF5IiwidGV4dCIsInRyYWluaW5nQ2hhcnREYXRhIiwiZGF0ZSIsIkRhdGUiLCJ0b0xvY2FsZURhdGVTdHJpbmciLCJjb25maXJtZWQiLCJkZWF0aHMiLCJmb3JlY2FzdCIsIm5ld1RyYWluaW5nRGF0YSIsIkFycmF5IiwiZmlsbCIsImkiLCJsZW5ndGgiLCJzY2FsZWREYXRhIiwiZml0X3RyYW5zZm9ybSIsIm5ldHdvcmsiLCJyZWN1cnJlbnQiLCJMU1RNVGltZVN0ZXAiLCJpbnB1dFNpemUiLCJoaWRkZW5MYXllcnMiLCJvdXRwdXRTaXplIiwidHJhaW4iLCJsZWFybmluZ1JhdGUiLCJlcnJvclRocmVzaCIsImxvZyIsInN0YXRzIiwiY29uc29sZSIsInJlc3VsdCIsImludmVyc2VfdHJhbnNmb3JtIiwibG9hZERhaWx5RGF0YSIsImluaXRpYWxEYWlseURhdGEiLCJsb2FkR2xvYmFsRGF0YSIsInVzZUJyYWluQ29udGV4dCIsImF4aW9zIiwiYXBpIiwiY3JlYXRlIiwiYmFzZVVSTCIsImRlZmF1bHRzIiwiaGVhZGVycyIsImludGVyY2VwdG9ycyIsInJlcXVlc3QiLCJ1c2UiLCJjb25maWciLCJnZXQiLCJlcnIiLCJwb3NpdGl2ZSIsInJlY292ZXJlZCIsImRlYXRoIiwiZGF0ZUNoZWNrZWQiLCJlcnJvciIsIlhfbWluIiwiWF9tYXgiLCJtaW5fIiwibWF4XyIsImZpdCIsIlgiLCJtaW4iLCJtYXgiLCJNYXRoIiwiYXBwbHkiLCJYX21pbkFyciIsInZhbHVlcyIsIlhfc3RkIiwiWF9zY2FsZWQiLCJ0cmFpbl9zY2FsZWQiLCJpbnB1dCIsIlhfIl0sInNvdXJjZVJvb3QiOiIifQ==