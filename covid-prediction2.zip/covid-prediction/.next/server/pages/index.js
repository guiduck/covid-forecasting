"use strict";
(() => {
var exports = {};
exports.id = "pages/index";
exports.ids = ["pages/index"];
exports.modules = {

/***/ "./node_modules/brain.js/dist/src/index":
/*!**********************************************!*\
  !*** ./node_modules/brain.js/dist/src/index ***!
  \**********************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {



Object.defineProperty(exports, "__esModule", ({ value: true }));

var gpu_js = __webpack_require__(/*! gpu.js */ "gpu.js");
var stream = __webpack_require__(/*! stream */ "stream");

/**
 * Relu Activation, aka Rectified Linear Unit Activation
 * @description https://en.wikipedia.org/wiki/Rectifier_(neural_networks)
 */
function activate$3(weight) {
    return Math.max(0, weight);
}
/**
 * Relu derivative
 */
function measure$3(weight, delta) {
    if (weight <= 0) {
        return 0;
    }
    return delta;
}

var relu$2 = /*#__PURE__*/Object.freeze({
    __proto__: null,
    activate: activate$3,
    measure: measure$3
});

/**
 * sigmoid activation
 */
function activate$2(value) {
    return 1 / (1 + Math.exp(-value));
}
/**
 * sigmoid derivative
 */
function measure$2(weight, error) {
    return weight * (1 - weight) * error;
}

var sigmoid$2 = /*#__PURE__*/Object.freeze({
    __proto__: null,
    activate: activate$2,
    measure: measure$2
});

/**
 * Hyperbolic tan
 */
function activate$1(weight) {
    return Math.tanh(weight);
}
/**
 * @description grad for z = tanh(x) is (1 - z^2)
 */
function measure$1(weight, error) {
    return (1 - weight * weight) * error;
}

var tanh$2 = /*#__PURE__*/Object.freeze({
    __proto__: null,
    activate: activate$1,
    measure: measure$1
});

/**
 * Leaky Relu Activation, aka Leaky Rectified Linear Unit Activation
 * @description https://en.wikipedia.org/wiki/Rectifier_(neural_networks)
 */
function activate(weight) {
    return weight > 0 ? weight : 0.01 * weight;
}
/**
 * Leaky Relu derivative
 */
function measure(weight, error) {
    return weight > 0 ? error : 0.01 * error;
}

var leakyRelu$1 = /*#__PURE__*/Object.freeze({
    __proto__: null,
    activate: activate,
    measure: measure
});

var index$1 = /*#__PURE__*/Object.freeze({
    __proto__: null,
    relu: relu$2,
    sigmoid: sigmoid$2,
    tanh: tanh$2,
    leakyRelu: leakyRelu$1
});

class CrossValidate {
    constructor(initClassifier) {
        this.json = {
            avgs: {
                error: 0,
                iterations: 0,
                testTime: 0,
                trainTime: 0,
            },
            stats: {
                total: 0,
                testSize: 0,
                trainSize: 0,
            },
            sets: [],
        };
        this.initClassifier = initClassifier;
    }
    testPartition(trainOpts, trainSet, testSet) {
        const classifier = this.initClassifier();
        const beginTrain = Date.now();
        const trainingStats = classifier.train(trainSet, trainOpts);
        const beginTest = Date.now();
        const testStats = classifier.test(testSet);
        const endTest = Date.now();
        return {
            ...testStats,
            trainTime: beginTest - beginTrain,
            testTime: endTest - beginTest,
            iterations: trainingStats.iterations,
            error: trainingStats.error,
            total: testStats.total,
            network: classifier.toJSON(),
        };
    }
    /**
     * Randomize array element order in-place.
     * Using Durstenfeld shuffle algorithm.
     * source: http://stackoverflow.com/a/12646864/1324039
     */
    shuffleArray(array) {
        for (let i = array.length - 1; i > 0; i--) {
            const j = Math.floor(Math.random() * (i + 1));
            const temp = array[i];
            array[i] = array[j];
            array[j] = temp;
        }
        return array;
    }
    train(data, trainOpts = {}, k = 4) {
        if (data.length < k) {
            throw new Error(`Training set size is too small for ${data.length} k folds of ${k}`);
        }
        this.shuffleArray(data);
        const size = data.length / k;
        const avgs = {
            trainTime: 0,
            testTime: 0,
            iterations: 0,
            error: 0,
        };
        const stats = {
            total: 0,
            testSize: 0,
            trainSize: 0,
        };
        const binaryStats = {
            total: 0,
            testSize: 0,
            trainSize: 0,
            truePos: 0,
            trueNeg: 0,
            falsePos: 0,
            falseNeg: 0,
            precision: 0,
            recall: 0,
            accuracy: 0,
        };
        const results = [];
        let isBinary = null;
        for (let i = 0; i < k; i++) {
            const dclone = data.slice(0);
            const testSet = dclone.splice(i * size, size);
            const trainSet = dclone;
            const result = this.testPartition(trainOpts, trainSet, testSet);
            if (isBinary === null) {
                isBinary =
                    result.hasOwnProperty('falseNeg') &&
                        result.hasOwnProperty('falsePos') &&
                        result.hasOwnProperty('trueNeg') &&
                        result.hasOwnProperty('truePos');
                if (isBinary) {
                    Object.assign(stats, binaryStats);
                }
            }
            avgs.iterations += result.iterations;
            avgs.testTime += result.testTime;
            avgs.trainTime += result.trainTime;
            avgs.error += result.error;
            stats.total += result.total;
            if (CrossValidate.isBinaryStats(stats) &&
                CrossValidate.isBinaryPartitionResults(result)) {
                stats.accuracy += result.accuracy;
                stats.falseNeg += result.falseNeg;
                stats.falsePos += result.falsePos;
                stats.precision += result.precision;
                stats.recall += result.recall;
                stats.trueNeg += result.trueNeg;
                stats.truePos += result.truePos;
            }
            results.push(result);
        }
        avgs.error /= k;
        avgs.iterations /= k;
        avgs.testTime /= k;
        avgs.trainTime /= k;
        if (CrossValidate.isBinaryStats(stats)) {
            stats.precision = stats.truePos / (stats.truePos + stats.falsePos);
            stats.recall = stats.truePos / (stats.truePos + stats.falseNeg);
            stats.accuracy = (stats.trueNeg + stats.truePos) / stats.total;
        }
        stats.testSize = size;
        stats.trainSize = data.length - size;
        this.json = {
            avgs: avgs,
            stats: stats,
            sets: results,
        };
        return this.json;
    }
    toNeuralNetwork() {
        return this.fromJSON(this.json);
    }
    toJSON() {
        return this.json;
    }
    fromJSON(crossValidateJson) {
        const winningJSON = crossValidateJson.sets.reduce((prev, cur) => (prev.error < cur.error ? prev : cur));
        return this.initClassifier().fromJSON(winningJSON.network);
    }
}
CrossValidate.isBinaryStats = (stats) => {
    return (stats.accuracy !== undefined);
};
CrossValidate.isBinaryResults = (stats) => stats.stats.accuracy !== undefined;
CrossValidate.isBinaryPartitionResults = (stats) => stats.accuracy !==
    undefined;

let gpuInstance = null;
/**
 * Sets up the gpu.js instance
 */
function setup(value) {
    gpuInstance = value;
}
function makeKernel(fn, settings) {
    let _gpuInstance = gpuInstance;
    if (_gpuInstance === null) {
        _gpuInstance = new gpu_js.GPU({ mode: 'gpu' });
        setup(_gpuInstance);
    }
    return _gpuInstance
        .createKernel(fn, settings)
        .setPipeline(true);
}
function makeKernelMap(map, fn, settings) {
    let _gpuInstance = gpuInstance;
    if (_gpuInstance === null) {
        _gpuInstance = new gpu_js.GPU({ mode: 'gpu' });
        setup(_gpuInstance);
    }
    return _gpuInstance
        .createKernelMap(map, fn, settings)
        .setPipeline(true);
}
/**
 * Compiles a function into a gpu.js dev mode kernel
 */
// export function makeDevKernel(
//   fn: ThreadFunction,
//   settings: makeKernelSettings
// ): IKernelRunShortcut {
//   if ('map' in settings) {
//     throw new Error('map kernels are not supported by dev kernels');
//   }
//   const gpu = new GPU({ mode: 'dev' });
//   return gpu.createKernel(fn, settings);
// }
function kernelInput(value, size) {
    return new gpu_js.Input(value, size);
}
/**
 * Deletes a gpu.js texture and frees VRAM
 */
function release(possibleTexture) {
    if (possibleTexture instanceof gpu_js.Texture) {
        possibleTexture.delete();
    }
}
/**
 * Cleans ie sets all elements to 0 of a Texture or a js array
 */
function clear(value) {
    if (value instanceof gpu_js.Texture) {
        value.clear();
        return;
    }
    // array
    if (Array.isArray(value)) {
        if (typeof value[0] === 'number') {
            value.fill(0);
        }
        else if (typeof value[0][0] === 'number') {
            for (let x = 0; x < value.length; x++) {
                value[x].fill(0);
            }
            return;
        }
        else if (typeof value[0][0][0] === 'number') {
            // cube
            for (let y = 0; y < value.length; y++) {
                const row = value[y];
                for (let x = 0; x < row.length; x++) {
                    row[x].fill(0);
                }
            }
            return;
        }
    }
    throw new Error('unhandled value');
}
/**
 * Clones a value
 */
function clone(value) {
    if (value instanceof gpu_js.Texture) {
        return value.clone();
    }
    if (value instanceof Float32Array) {
        return value.slice(0);
    }
    if (Array.isArray(value)) {
        if (typeof value[0] === 'number') {
            return value.slice(0);
        }
        else if (typeof value[0][0] === 'number') {
            const matrix = new Array(value.length);
            for (let x = 0; x < value.length; x++) {
                matrix[x] = value[x].slice(0);
            }
            return matrix;
        }
        else if (typeof value[0][0][0] === 'number') {
            const cube = new Array(value.length);
            for (let y = 0; y < value.length; y++) {
                const row = value[y];
                const matrix = new Array(row.length);
                for (let x = 0; x < row.length; x++) {
                    matrix[x] = row[x].slice(0);
                }
            }
            return cube;
        }
    }
    throw new Error('unhandled value');
}

/**
 * 2D Mean Squared Error
 */
function mse2d(errors) {
    let sum = 0;
    for (let y = 0; y < this.constants.height; y++) {
        for (let x = 0; x < this.constants.width; x++) {
            sum += errors[y][x] ** 2;
        }
    }
    return sum / this.constants.length;
}
class MeanSquaredError {
    constructor({ width, height }) {
        this.calculate = makeKernel(mse2d, {
            output: [1],
            constants: {
                width,
                height,
                length: width * height,
            },
            immutable: true,
        });
        this.addAbsolute = makeKernel(function (prevError, prevLayerErrors) {
            return prevError[0] + Math.abs(prevLayerErrors[0][0]);
        }, {
            output: [1],
            immutable: true,
        });
        this.add = makeKernel(function (value1, value2) {
            return value1[0] + value2[0];
        }, {
            output: [1],
            immutable: true,
        });
        this.divide = makeKernel(function (length, mseSum) {
            const value = mseSum[0];
            if (value > 0) {
                return value / length;
            }
            return 0;
        }, {
            output: [1],
            immutable: true,
        });
    }
}

const baseLayerDefaultSettings = {
    width: 1,
    height: 1,
    depth: null,
    weights: null,
    deltas: null,
    praxis: null,
    praxisOpts: null,
};
class BaseLayer {
    constructor(settings) {
        this.praxis = null;
        this.predictKernel = null;
        this.compareKernel = null;
        if (settings) {
            this.settings = { ...baseLayerDefaultSettings, ...settings };
        }
        else {
            this.settings = { ...baseLayerDefaultSettings };
        }
        this.setupPraxis();
    }
    get width() {
        var _a;
        return (_a = this.settings.width) !== null && _a !== void 0 ? _a : 0;
    }
    get height() {
        var _a;
        return (_a = this.settings.height) !== null && _a !== void 0 ? _a : 0;
    }
    get depth() {
        var _a;
        return (_a = this.settings.depth) !== null && _a !== void 0 ? _a : 0;
    }
    get weights() {
        return this.settings.weights;
    }
    set weights(weights) {
        this.settings.weights = weights;
    }
    get deltas() {
        return this.settings.deltas;
    }
    set deltas(deltas) {
        this.settings.deltas = deltas;
    }
    get id() {
        var _a;
        return (_a = this.settings.id) !== null && _a !== void 0 ? _a : '';
    }
    set id(title) {
        this.settings.id = title;
    }
    setupPraxis() {
        const { initPraxis, praxis, praxisOpts } = this.settings;
        if (!this.praxis) {
            if (initPraxis) {
                if (praxisOpts) {
                    this.praxis = initPraxis(this, praxisOpts);
                }
                else {
                    this.praxis = initPraxis(this);
                }
            }
            else if (praxis) {
                this.praxis = praxis;
            }
        }
    }
    /*
    get weights() {
      return this._weights;
    }
  
    set weights(value) {
      if (value) {
        if (value.dimensions) {
          if (value.dimensions[0] !== this.width) {
            throw new Error(`${this.constructor.name}.weights being set with improper value width`);
          }
          if (value.dimensions[1] !== this.height) {
            throw new Error(`${this.constructor.name}.weights being set with improper value height`);
          }
        } else {
          if (value[0].length !== this.width) {
            throw new Error(`${this.constructor.name}.weights being set with improper value width`);
          }
          if (value.length !== this.height) {
            throw new Error(`${this.constructor.name}.weights being set with improper value height`);
          }
        }
      }
      this._weights = value;
    }
  
    get deltas() {
      return this._deltas;
    }
  
    set deltas(value) {
      if (value) {
        if (value.dimensions) {
          if (value.dimensions[0] !== this.width) {
            throw new Error(`${this.constructor.name}.deltas being set with improper value width`);
          }
          if (value.dimensions[1] !== this.height) {
            throw new Error(`${this.constructor.name}.deltas being set with improper value height`);
          }
        } else {
          if (value[0].length !== this.width) {
            throw new Error(`${this.constructor.name}.deltas being set with improper value width`);
          }
          if (value.length !== this.height) {
            throw new Error(`${this.constructor.name}.deltas being set with improper value height`);
          }
        }
      }
      this._deltas = value;
    } */
    validate() {
        if (Number.isNaN(this.height)) {
            throw new Error(`${this.constructor.name} layer height is not a number`);
        }
        if (Number.isNaN(this.width)) {
            throw new Error(`${this.constructor.name} layer width is not a number`);
        }
        if (this.height < 1) {
            throw new Error(`${this.constructor.name} layer height is less than 1`);
        }
        if (this.width < 1) {
            throw new Error(`${this.constructor.name} layer width is less than 1`);
        }
    }
    setupKernels(isTraining) { }
    reuseKernels(layer) {
        if (layer.width !== this.width) {
            throw new Error(`${this.constructor.name} kernel width mismatch ${layer.width} is not ${this.width}`);
        }
        if (layer.height !== this.height) {
            throw new Error(`${this.constructor.name} kernel width mismatch ${layer.height} is not ${this.height}`);
        }
        if (layer.hasOwnProperty('predictKernel') && layer.predictKernel !== null) {
            if (!layer.predictKernel.immutable) {
                throw new Error(`${layer.constructor.name}.predictKernel is not reusable, set kernel.immutable = true`);
            }
            this.predictKernel = layer.predictKernel;
        }
        if (layer.hasOwnProperty('compareKernel') && layer.compareKernel !== null) {
            if (!layer.compareKernel.immutable) {
                throw new Error(`${layer.constructor.name}.compareKernel is not reusable, set kernel.immutable = true`);
            }
            this.compareKernel = layer.compareKernel;
        }
        this.praxis = layer.praxis;
    }
    predict(inputs) { }
    compare(targetValues) { }
    learn(learningRate) {
        // TODO: do we need to release here?
        const { weights: oldWeights } = this;
        if (!this.praxis)
            throw new Error('this.praxis not defined');
        this.weights = this.praxis.run(this, learningRate);
        release(oldWeights);
        clear(this.deltas);
    }
    toArray() {
        return Array.isArray(this.weights)
            ? this.weights
            : this.weights.toArray();
    }
    toJSON() {
        return BaseLayer.toJSON(this);
    }
    static toJSON(layer) {
        const { weights } = layer;
        return {
            width: layer.width,
            height: layer.height,
            depth: layer.depth,
            weights: toUntypedArray((weights && weights instanceof gpu_js.Texture
                ? weights.toArray()
                : weights)),
            type: layer.constructor.name,
            praxisOpts: layer.praxis ? layer.praxis.toJSON() : null,
        };
    }
}
function toUntypedArray(weights) {
    if (weights === null)
        return null;
    if (Array.isArray(weights)) {
        if (typeof weights[0] === 'number') {
            return weights;
        }
        else if (Array.isArray(weights[0]) && typeof weights[0][0] === 'number') {
            return weights;
        }
        else if (Array.isArray(weights[0][0]) &&
            typeof weights[0][0][0] === 'number') {
            return weights;
        }
        else if (weights[0] instanceof Float32Array) {
            const matrix = weights;
            return matrix.map((row) => {
                return Array.from(row);
            });
        }
        else if (weights[0][0] instanceof Float32Array) {
            const cube = weights;
            return cube.map((matrix) => {
                return matrix.map((row) => {
                    return Array.from(row);
                });
            });
        }
    }
    else if (weights) {
        return Array.from(weights);
    }
    throw new Error('unexpected value');
}

/**
 * Returns an array of zeros
 */
function zeros$1(size) {
    return new Float32Array(size);
}

/**
 * Returns a 2D tensor(matrix) of zeros
 */
function zeros2D(width, height) {
    const result = new Array(height);
    for (let y = 0; y < height; y++) {
        result[y] = zeros$1(width);
    }
    return result;
}

/**
 * Returns a 3D tensor of arrays
 */
function zeros3D(width, height, depth) {
    const result = new Array(depth);
    for (let z = 0; z < depth; z++) {
        result[z] = zeros2D(width, height);
    }
    return result;
}

class Activation extends BaseLayer {
    constructor(inputLayer, settings) {
        super(settings);
        this.inputLayer = inputLayer;
        const { width, height, depth } = this;
        this.predictKernel = null;
        this.compareKernel = null;
        this.validate();
        if (depth > 0) {
            this.weights = zeros3D(width, height, depth);
            this.deltas = zeros3D(width, height, depth);
        }
        else if (height > 0) {
            this.weights = zeros2D(width, height);
            this.deltas = zeros2D(width, height);
        }
        this.setupPraxis();
    }
    get width() {
        return this.inputLayer.width;
    }
    get height() {
        return this.inputLayer.height;
    }
    get depth() {
        return this.inputLayer.depth;
    }
}

class Filter extends BaseLayer {
    constructor(settings, inputLayer) {
        super();
        this.settings = settings;
        this.inputLayer = inputLayer;
    }
    get width() {
        return this.inputLayer.width;
    }
    get height() {
        return this.inputLayer.height;
    }
    get depth() {
        return this.inputLayer.depth;
    }
    get filterCount() {
        return this.settings.filterCount;
    }
    get filterWidth() {
        return this.settings.filterWidth;
    }
    get filterHeight() {
        return this.settings.filterHeight;
    }
    get filters() {
        return this.settings.filters;
    }
    set filters(filters) {
        this.settings.filters = filters;
    }
    get filterDeltas() {
        return this.settings.filterDeltas;
    }
    set filterDeltas(filterDeltas) {
        this.settings.filterDeltas = filterDeltas;
    }
}

class Internal {
    constructor() {
        this.predictKernel = null;
        this.compareKernel = null;
        this.praxis = null;
    }
    get width() {
        return this.settings.width;
    }
    get height() {
        return this.settings.height;
    }
    get depth() {
        return this.settings.depth;
    }
    get weights() {
        return this.settings.weights;
    }
    set weights(weights) {
        this.settings.weights = weights;
    }
    get deltas() {
        return this.settings.deltas;
    }
    set deltas(deltas) {
        this.settings.deltas = deltas;
    }
    toJSON() {
        return BaseLayer.toJSON(this);
    }
}

class Modifier extends BaseLayer {
    constructor(inputLayer, settings) {
        super({
            ...settings,
            width: inputLayer.width,
            height: inputLayer.height,
            depth: inputLayer.depth,
        });
        this.inputLayer = inputLayer;
    }
    validate() {
        var _a;
        super.validate();
        if (this.width !== this.inputLayer.width) {
            throw new Error(`width of ${this.width} does not match inputLayer.width of ${this.inputLayer.width}`);
        }
        if (this.height !== this.inputLayer.height) {
            throw new Error(`height of ${this.height} does not match inputLayer.height of ${this.inputLayer.height}`);
        }
        if (this.depth !== ((_a = this.inputLayer.depth) !== null && _a !== void 0 ? _a : 0)) {
            throw new Error(`depth of ${this.depth} does not match inputLayer.depth of ${this.inputLayer.depth}`);
        }
    }
}

class Operator extends BaseLayer {
    constructor(inputLayer1, inputLayer2, settings) {
        super(settings);
        this.inputLayer1 = inputLayer1;
        this.inputLayer2 = inputLayer2;
        this.validate();
        this.weights = zeros2D(this.width, this.height);
        this.deltas = zeros2D(this.width, this.height);
        this.setupPraxis();
    }
}

function compare1D(weights, targetValues) {
    return weights[this.thread.y][this.thread.x] - targetValues[this.thread.x];
}
function compare2D$5(weights, targetValues) {
    return (weights[this.thread.y][this.thread.x] -
        targetValues[this.thread.y][this.thread.x]);
}
class Target extends BaseLayer {
    constructor(settings, inputLayer) {
        super(settings);
        this.inputLayer = inputLayer;
        this.validate();
        if (this.depth) {
            throw new Error('Target layer not implemented for depth');
        }
        else if (this.height) {
            this.weights = zeros2D(this.width, this.height);
            this.deltas = zeros2D(this.width, this.height);
            this.errors = zeros2D(this.width, this.height);
        }
        else {
            this.weights = zeros$1(this.width);
            this.deltas = zeros$1(this.width);
            this.errors = zeros$1(this.width);
        }
    }
    setupKernels() {
        if (this.width === 1) {
            this.compareKernel = makeKernel(compare1D, {
                output: [this.width, this.height],
                immutable: true,
            });
        }
        else {
            this.compareKernel = makeKernel(compare2D$5, {
                output: [this.width, this.height],
                immutable: true,
            });
        }
    }
    predict() {
        // TODO: should we clone here?
        // NOTE: this looks like it shouldn't be, but the weights are immutable, and this is where they are reused.
        release(this.weights);
        this.weights = clone(this.inputLayer.weights);
        clear(this.deltas);
    }
    compare(targetValues) {
        // this is where weights attach to deltas
        // deltas will be zero on learn, so save it in error for comparing to mse later
        release(this.deltas);
        release(this.errors);
        release(this.inputLayer.deltas);
        this.deltas = this.compareKernel(this.weights, targetValues);
        this.inputLayer.deltas = clone(this.deltas);
        this.errors = clone(this.deltas);
    }
    setupPraxis() { }
}
function target(settings, inputLayer) {
    return new Target(settings, inputLayer);
}

// eslint-disable-next-line @typescript-eslint/no-extraneous-class
class InternalModel {
}
// eslint-disable-next-line @typescript-eslint/no-extraneous-class
class EntryPoint extends BaseLayer {
}
// eslint-disable-next-line @typescript-eslint/no-extraneous-class
class Model extends BaseLayer {
}

/* Functions for turning sparse hashes into arrays and vice versa */
const lookup = {
    /**
     * Performs `[{a: 1}, {b: 6, c: 7}] -> {a: 0, b: 1, c: 2}`
     * @param {Object} hashes
     * @returns {Object}
     */
    toTable(hashes) {
        const hash = hashes.reduce((memo, hash) => {
            return Object.assign(memo, hash);
        }, {});
        return lookup.toHash(hash);
    },
    /**
     * Performs `[{a: 1}, {b: 6, c: 7}] -> {a: 0, b: 1, c: 2}`
     */
    toTable2D(objects2D) {
        const table = {};
        let valueIndex = 0;
        for (let i = 0; i < objects2D.length; i++) {
            const objects = objects2D[i];
            for (let j = 0; j < objects.length; j++) {
                const object = objects[j];
                for (const p in object) {
                    if (object.hasOwnProperty(p) && !table.hasOwnProperty(p)) {
                        table[p] = valueIndex++;
                    }
                }
            }
        }
        return table;
    },
    toInputTable2D(data) {
        const table = {};
        let tableIndex = 0;
        for (let dataIndex = 0; dataIndex < data.length; dataIndex++) {
            const input = data[dataIndex].input;
            for (let i = 0; i < input.length; i++) {
                const object = input[i];
                for (const p in object) {
                    if (!object.hasOwnProperty(p))
                        continue;
                    if (!table.hasOwnProperty(p)) {
                        table[p] = tableIndex++;
                    }
                }
            }
        }
        return table;
    },
    toOutputTable2D(data) {
        const table = {};
        let tableIndex = 0;
        for (let dataIndex = 0; dataIndex < data.length; dataIndex++) {
            const output = data[dataIndex].output;
            for (let i = 0; i < output.length; i++) {
                const object = output[i];
                for (const p in object) {
                    if (!object.hasOwnProperty(p))
                        continue;
                    if (!table.hasOwnProperty(p)) {
                        table[p] = tableIndex++;
                    }
                }
            }
        }
        return table;
    },
    /**
     * performs `{a: 6, b: 7} -> {a: 0, b: 1}`
     */
    toHash(hash) {
        const lookup = {};
        let index = 0;
        const keys = Object.keys(hash);
        for (let i = 0; i < keys.length; i++) {
            lookup[keys[i]] = index++;
        }
        return lookup;
    },
    /**
     * performs `{a: 0, b: 1}, {a: 6} -> [6, 0]`
     */
    toArray(lookup, object, arrayLength) {
        const result = new Float32Array(arrayLength);
        for (const p in lookup) {
            if (!lookup.hasOwnProperty(p))
                continue;
            result[lookup[p]] = object.hasOwnProperty(p) ? object[p] : 0;
        }
        return result;
    },
    toArrayShort(lookup, object) {
        const result = [];
        for (const p in lookup) {
            if (!lookup.hasOwnProperty(p))
                continue;
            if (!object.hasOwnProperty(p))
                break;
            result[lookup[p]] = object[p];
        }
        return Float32Array.from(result);
    },
    toArrays(lookup, objects, arrayLength) {
        const result = [];
        for (let i = 0; i < objects.length; i++) {
            result.push(this.toArray(lookup, objects[i], arrayLength));
        }
        return result;
    },
    /**
     * performs `{a: 0, b: 1}, [6, 7] -> {a: 6, b: 7}`
     * @param {Object} lookup
     * @param {Array} array
     * @returns {Object}
     */
    toObject(lookup, array) {
        const object = {};
        for (const p in lookup) {
            if (!lookup.hasOwnProperty(p))
                continue;
            object[p] = array[lookup[p]];
        }
        return object;
    },
    toObjectPartial(lookup, array, offset = 0, limit = 0) {
        const object = {};
        let i = 0;
        for (const p in lookup) {
            if (!lookup.hasOwnProperty(p))
                continue;
            if (offset > 0) {
                if (i++ < offset)
                    continue;
            }
            if (limit > 0) {
                if (i++ >= limit)
                    continue;
            }
            object[p] = array[lookup[p] - offset];
        }
        return object;
    },
    dataShape(data) {
        const shape = [];
        let lastData;
        if (data.hasOwnProperty('input')) {
            shape.push('datum');
            lastData = data.input;
        }
        else if (Array.isArray(data)) {
            if (data[0] &&
                data[0].input) {
                shape.push('array', 'datum');
                lastData = data[0].input;
            }
            else if (Array.isArray(data[0])) {
                shape.push('array');
                lastData = data[0];
            }
            else {
                lastData = data;
            }
        }
        else {
            lastData = data;
        }
        let p;
        while (lastData) {
            p = Object.keys(lastData)[0];
            if (Array.isArray(lastData) ||
                typeof lastData.buffer === 'object') {
                shape.push('array');
                const possibleNumber = lastData[parseInt(p)];
                if (typeof possibleNumber === 'number') {
                    shape.push('number');
                    break;
                }
                else {
                    lastData = possibleNumber;
                }
            }
            else if (typeof lastData === 'object' &&
                typeof lastData.buffer !== 'object') {
                shape.push('object');
                const possibleNumber = lastData[p];
                if (typeof possibleNumber === 'number') {
                    shape.push('number');
                    break;
                }
                else {
                    lastData = possibleNumber;
                }
            }
            else {
                throw new Error('unhandled signature');
            }
        }
        return shape;
    },
    addKeys(value, table) {
        if (Array.isArray(value))
            return table;
        let i = Object.keys(table).length;
        for (const p in value) {
            if (!value.hasOwnProperty(p))
                continue;
            if (table.hasOwnProperty(p))
                continue;
            table[p] = i++;
        }
        return table;
    },
};

class BasePraxis {
    constructor(layerTemplate, settings = {}) {
        this.layerTemplate = layerTemplate;
        this.settings = { ...settings };
        this.kernel = null;
    }
    get width() {
        return this.layerTemplate.width;
    }
    get height() {
        return this.layerTemplate.height;
    }
    get depth() {
        return this.layerTemplate.depth;
    }
    setupKernels() { }
    reuseKernels(praxis) {
        if (praxis.width !== this.width) {
            throw new Error(`${this.constructor.name} kernel width mismatch ${praxis.width} is not ${this.width}`);
        }
        if (praxis.height !== this.height) {
            throw new Error(`${this.constructor.name} kernel width mismatch ${praxis.height} is not ${this.height}`);
        }
        if (praxis.hasOwnProperty('kernel')) {
            this.kernel = praxis.kernel;
        }
    }
    toJSON() {
        return { ...this.settings };
    }
}

function update$2(weights, deltas) {
    return (weights[this.thread.y][this.thread.x] +
        this.constants.learningRate * deltas[this.thread.y][this.thread.x]);
}
const defaultSettings$1 = {
    learningRate: 0.3,
};
class ArthurDeviationBiases extends BasePraxis {
    constructor(layer, settings) {
        super(layer);
        this.settings = { ...defaultSettings$1, ...settings };
        this.kernel = null;
    }
    run(layer) {
        return this.kernel(layer.weights, layer.deltas);
    }
    setupKernels() {
        this.kernel = makeKernel(update$2, {
            output: [this.width, this.height],
            constants: {
                learningRate: this.settings.learningRate,
            },
        });
    }
}
function arthurDeviationBiases(layer, settings) {
    return new ArthurDeviationBiases(layer, settings);
}

function updateChange(value) {
    return value;
}
function update$1(changes, weights, incomingWeights, inputDeltas) {
    const lastChange = changes[this.thread.y][this.thread.x];
    const inputDelta = inputDeltas[this.thread.y][0];
    const weight = weights[this.thread.y][this.thread.x];
    const incoming = incomingWeights[this.thread.x][0];
    const change = this.constants.learningRate * inputDelta * incoming +
        this.constants.momentum * lastChange;
    return weight + change;
}
const defaultSettings = {
    learningRate: 0.3,
    momentum: 0.1,
    weightsLayer: null,
    incomingLayer: null,
    deltaLayer: null,
};
class ArthurDeviationWeights extends BasePraxis {
    constructor(layer, settings) {
        super(layer);
        this.kernelMap = null;
        this.settings = { ...defaultSettings, ...settings };
        this.changes = zeros2D(layer.width, layer.height);
    }
    get learningRate() {
        return this.settings.learningRate;
    }
    get momentum() {
        return this.settings.momentum;
    }
    get weightsLayer() {
        return this.settings.weightsLayer;
    }
    set weightsLayer(layer) {
        this.settings.weightsLayer = layer;
    }
    get deltaLayer() {
        return this.settings.deltaLayer;
    }
    set deltaLayer(layer) {
        this.settings.deltaLayer = layer;
    }
    get incomingLayer() {
        return this.settings.incomingLayer;
    }
    set incomingLayer(layer) {
        this.settings.incomingLayer = layer;
    }
    run() {
        const output = this.kernelMap(this.changes, this.weightsLayer.weights, this.incomingLayer.weights, this.deltaLayer.deltas);
        this.changes = output.changes;
        return output.result;
    }
    setupKernels() {
        this.kernelMap = makeKernelMap({
            changes: updateChange,
        }, update$1, {
            output: [this.width, this.height],
            constants: {
                learningRate: this.learningRate,
                momentum: this.momentum,
            },
        });
    }
}
function arthurDeviationWeights(layer, settings) {
    return new ArthurDeviationWeights(layer, settings);
}

function getMomentum(delta, decay, previousMomentum) {
    return previousMomentum * decay + (1 - decay) * delta * delta;
}
function clipByValue(value, max, min) {
    if (value > max) {
        return max;
    }
    if (value < min) {
        return min;
    }
    return value;
}
/**
 * @description Momentum Root Mean Square Propagation Function
 */
function update(weights, deltas, previousMomenta) {
    const delta = deltas[this.thread.y][this.thread.x];
    const clippedDelta = clipByValue(delta, this.constants.clipValue, -this.constants.clipValue);
    const weight = weights[this.thread.y][this.thread.x];
    const previousMomentum = previousMomenta[this.thread.y][this.thread.x];
    const momentum = getMomentum(delta, this.constants.decayRate, previousMomentum);
    return (weight +
        (-this.constants.learningRate * clippedDelta) /
            Math.sqrt(momentum + this.constants.smoothEps) -
        this.constants.regularizationStrength * weight);
}
const defaults$8 = {
    decayRate: 0.999,
    regularizationStrength: 0.0001,
    learningRate: 0.01,
    smoothEps: 1e-8,
    clipValue: 5,
};
class MomentumRootMeanSquaredPropagation extends BasePraxis {
    constructor(layerTemplate, settings = {}) {
        super(layerTemplate);
        this.kernelMap = null;
        this.settings = { ...defaults$8, ...settings };
        this.momenta = zeros2D(layerTemplate.width, layerTemplate.height);
    }
    get clipValue() {
        return this.settings.clipValue;
    }
    get decayRate() {
        return this.settings.decayRate;
    }
    get learningRate() {
        return this.settings.learningRate;
    }
    get regularizationStrength() {
        return this.settings.regularizationStrength;
    }
    get smoothEps() {
        return this.settings.smoothEps;
    }
    run(layer) {
        const { momenta, result } = this.kernelMap(layer.weights, layer.deltas, this.momenta);
        release(this.momenta);
        this.momenta = momenta;
        return result;
    }
    setupKernels() {
        this.kernelMap = makeKernelMap({
            momenta: getMomentum,
        }, update, {
            output: [this.width, this.height],
            constants: {
                clipValue: this.clipValue,
                decayRate: this.decayRate,
                learningRate: this.learningRate,
                regularizationStrength: this.regularizationStrength,
                smoothEps: this.smoothEps,
            },
            functions: [clipByValue],
            immutable: true,
        });
    }
}
function momentumRootMeanSquaredPropagation(layer, settings) {
    return new MomentumRootMeanSquaredPropagation(layer, settings);
}
/**
 * @description Mathematician friendly name of MomentumRootMeanSquaredPropagation class. For those that are not mere mortals
 */
const MRmsProp = MomentumRootMeanSquaredPropagation;
const mRmsProp = momentumRootMeanSquaredPropagation;

var index = /*#__PURE__*/Object.freeze({
    __proto__: null,
    ArthurDeviationBiases: ArthurDeviationBiases,
    arthurDeviationBiases: arthurDeviationBiases,
    ArthurDeviationWeights: ArthurDeviationWeights,
    arthurDeviationWeights: arthurDeviationWeights,
    MomentumRootMeanSquaredPropagation: MomentumRootMeanSquaredPropagation,
    momentumRootMeanSquaredPropagation: momentumRootMeanSquaredPropagation,
    MRmsProp: MRmsProp,
    mRmsProp: mRmsProp
});

function traverseLayersFrom(layer, cb) {
    if (layer.hasOwnProperty('inputLayer')) {
        traverseLayersFrom(layer.inputLayer, cb);
    }
    else {
        if (layer.hasOwnProperty('inputLayer1')) {
            traverseLayersFrom(layer.inputLayer1, cb);
        }
        if (layer.hasOwnProperty('inputLayer2')) {
            traverseLayersFrom(layer.inputLayer2, cb);
        }
    }
    cb(layer);
}

function flattenLayers(layers) {
    const result = layers.slice(0);
    for (let i = 0; i < result.length; i++) {
        let offset = 0;
        traverseLayersFrom(result[i], (layer) => {
            if (!result.includes(layer)) {
                result.splice(i + offset, 0, layer);
                offset++;
            }
        });
    }
    return result;
}

function checkSameSize(layer1, layer2) {
    if (layer1.width !== layer2.width) {
        throw new Error(`Layer width mismatch of ${layer1.width} and ${layer2.width}`);
    }
    if (layer1.height !== layer2.height) {
        throw new Error(`Layer height mismatch of ${layer1.height} and ${layer2.height}`);
    }
}

function predict$8(inputWeights1, inputWeights2) {
    return (inputWeights1[this.thread.y][this.thread.x] +
        inputWeights2[this.thread.y][this.thread.x]);
}
class Add extends Operator {
    get width() {
        return this.inputLayer1.width;
    }
    get height() {
        return this.inputLayer1.height;
    }
    get depth() {
        return this.inputLayer1.depth;
    }
    validate() {
        super.validate();
        checkSameSize(this.inputLayer1, this.inputLayer2);
    }
    setupKernels() {
        this.predictKernel = makeKernel(predict$8, {
            output: [this.width, this.height],
            immutable: true,
        });
    }
    predict() {
        release(this.weights);
        this.weights = this.predictKernel(this.inputLayer1.weights, this.inputLayer2.weights);
        clear(this.deltas);
    }
    compare() {
        // TODO: Do we need release and clone here?
        release(this.inputLayer1.deltas);
        release(this.inputLayer2.deltas);
        this.inputLayer1.deltas = clone(this.deltas);
        this.inputLayer2.deltas = clone(this.deltas);
    }
    learn() { }
}
function add$1(inputLayer1, inputLayer2, settings) {
    return new Add(inputLayer1, inputLayer2, settings);
}

function randomWeight() {
    return Math.random() * 0.4 - 0.2;
}

/**
 * Returns a random float between given min and max bounds (inclusive)
 * @param min Minimum value of the ranfom float
 * @param max Maximum value of the random float
 */
function randomFloat(min, max) {
    return Math.random() * (max - min) + min;
}
/**
 * Complicated math. All you need to know is that it returns a random number.
 * More info: https://en.wikipedia.org/wiki/Normal_distribution
 */
function gaussRandom() {
    if (gaussRandom.returnV) {
        gaussRandom.returnV = false;
        return gaussRandom.vVal;
    }
    const u = 2 * Math.random() - 1;
    const v = 2 * Math.random() - 1;
    const r = u * u + v * v;
    if (r === 0 || r > 1) {
        return gaussRandom();
    }
    const c = Math.sqrt((-2 * Math.log(r)) / r);
    gaussRandom.vVal = v * c; // cache this
    gaussRandom.returnV = true;
    return u * c;
}
/**
 * Returns a random integer between given min and max bounds
 * @param min Minimum value of the random integer
 * @param max Maximum value of the random integer
 */
function randomInteger(min, max) {
    return Math.floor(Math.random() * (max - min) + min);
}
/**
 * If you know what this is: https://en.wikipedia.org/wiki/Normal_distribution
 * @param mu
 * @param std
 */
function randomN(mu, std) {
    return mu + gaussRandom() * std;
}
gaussRandom.returnV = false;
gaussRandom.vVal = 0;

var random$1 = /*#__PURE__*/Object.freeze({
    __proto__: null,
    randomFloat: randomFloat,
    gaussRandom: gaussRandom,
    randomInteger: randomInteger,
    randomN: randomN
});

/**
 * Returns an array of given size, full of randomness
 */
function randos(size, std = null) {
    const array = new Float32Array(size);
    if (std === null) {
        for (let i = 0; i < size; i++) {
            array[i] = randomWeight();
        }
    }
    else {
        for (let i = 0; i < size; i++) {
            array[i] = randomFloat(-std, std);
        }
    }
    return array;
}
/**
 * Returns a 2D matrix of given size, full of randomness
 */
function randos2D(width, height, std) {
    const result = new Array(height);
    for (let y = 0; y < height; y++) {
        result[y] = randos(width, std);
    }
    return result;
}
/**
 * Returns a 3D tensor of given size, full of randomness
 */
function randos3D(width, height, depth, std) {
    const result = new Array(depth);
    for (let z = 0; z < depth; z++) {
        result[z] = randos2D(width, height, std);
    }
    return result;
}

const defaults$7 = {
    ...baseLayerDefaultSettings,
    std: null,
};
class Random extends Model {
    constructor(settings) {
        super();
        this.settings = { ...defaults$7, ...settings };
        this.setupPraxis();
        this.validate();
        if (!this.weights) {
            this.weights = randos2D(this.width, this.height, settings.std);
        }
        if (!this.deltas) {
            this.deltas = zeros2D(this.width, this.height);
        }
    }
    predict() { }
    compare() { }
}
function random(settings) {
    return new Random(settings);
}

function predict$7(weights1, weights2) {
    let sum = 0;
    for (let i = 0; i < this.constants.size; i++) {
        sum += weights1[this.thread.y][i] * weights2[i][this.thread.x];
    }
    return sum;
}
function compareFromX(deltas, inputDeltas, inputWeights) {
    let sum = inputDeltas[this.thread.y][this.thread.x];
    for (let i = 0; i < this.constants.size; i++) {
        sum += deltas[this.thread.y][i] * inputWeights[this.thread.x][i];
    }
    return sum;
}
function compareFromY(deltas, inputDeltas, inputWeights) {
    let sum = inputDeltas[this.thread.y][this.thread.x];
    for (let i = 0; i < this.constants.size; i++) {
        sum += deltas[i][this.thread.x] * inputWeights[i][this.thread.y];
    }
    return sum;
}
class Multiply extends Operator {
    constructor() {
        super(...arguments);
        this.compareKernel1 = null;
        this.compareKernel2 = null;
    }
    get width() {
        return this.inputLayer2.width;
    }
    set width(width) {
        throw new Error('Cannot set width on Multiply');
    }
    get height() {
        return this.inputLayer1.height;
    }
    set height(height) {
        throw new Error('Cannot set height on Multiply');
    }
    get depth() {
        return this.inputLayer1.depth;
    }
    set depth(depth) {
        throw new Error('Cannot set depth on Multiply');
    }
    validate() {
        super.validate();
        if (this.inputLayer1.width !== this.inputLayer2.height) {
            throw new Error(`Layer width mismatch of ${this.inputLayer1.width} and ${this.inputLayer2.height}`);
        }
    }
    setupKernels() {
        this.predictKernel = makeKernel(predict$7, {
            output: [this.width, this.height],
            constants: {
                size: this.inputLayer2.height,
            },
            immutable: true,
        });
        this.compareKernel1 = makeKernel(compareFromX, {
            output: [this.inputLayer1.width, this.inputLayer1.height],
            constants: {
                size: this.inputLayer2.width,
            },
            immutable: true,
        });
        this.compareKernel2 = makeKernel(compareFromY, {
            output: [this.inputLayer2.width, this.inputLayer2.height],
            constants: {
                size: this.inputLayer1.height,
            },
            immutable: true,
        });
    }
    reuseKernels(layer) {
        super.reuseKernels(layer);
        this.compareKernel1 = layer.compareKernel1;
        this.compareKernel2 = layer.compareKernel2;
    }
    predict() {
        release(this.weights);
        if (!this.predictKernel)
            throw new Error('this.predictKernel is not set');
        this.weights = this.predictKernel(this.inputLayer1.weights, this.inputLayer2.weights);
        clear(this.deltas);
    }
    compare() {
        if (!this.compareKernel1)
            throw new Error('this.compareKernel1 not set');
        if (!this.compareKernel2)
            throw new Error('this.compareKernel2 not set');
        const inputLayer1Deltas = this.inputLayer1.deltas;
        const inputLayer2Deltas = this.inputLayer2.deltas;
        const newDeltas1 = this.compareKernel1(this.deltas, this.inputLayer1.deltas, this.inputLayer2.weights);
        const newDeltas2 = this.compareKernel2(this.deltas, this.inputLayer2.deltas, this.inputLayer1.weights);
        this.inputLayer2.deltas = newDeltas2;
        this.inputLayer1.deltas = newDeltas1;
        release(inputLayer1Deltas);
        release(inputLayer2Deltas);
    }
    setupPraxis() { }
    learn() { }
    toJSON() {
        return {
            ...super.toJSON(),
            width: this.width,
            height: this.height,
        };
    }
}
function multiply$1(inputLayer1, inputLayer2, settings) {
    return new Multiply(inputLayer1, inputLayer2, settings);
}

function predict2D$4(inputs) {
    return 1 / (1 + Math.exp(-inputs[this.thread.y][this.thread.x]));
}
function predict3D$5(inputs) {
    return (1 / (1 + Math.exp(-inputs[this.thread.z][this.thread.y][this.thread.x])));
}
function compare2D$4(weights, deltas) {
    const weight = weights[this.thread.y][this.thread.x];
    const delta = deltas[this.thread.y][this.thread.x];
    return weight * (1 - weight) * delta;
}
function compare3D$4(weights, deltas) {
    const weight = weights[this.thread.z][this.thread.y][this.thread.x];
    const delta = deltas[this.thread.z][this.thread.y][this.thread.x];
    return weight * (1 - weight) * delta;
}
class Sigmoid extends Activation {
    setupKernels() {
        if (this.depth > 0) {
            this.predictKernel = makeKernel(predict3D$5, {
                output: [this.width, this.height, this.depth],
                functions: [activate$2],
                immutable: true,
            });
            this.compareKernel = makeKernel(compare3D$4, {
                output: [this.width, this.height, this.depth],
                functions: [measure$2],
                immutable: true,
            });
        }
        else {
            this.predictKernel = makeKernel(predict2D$4, {
                output: [this.width, this.height],
                functions: [activate$2],
                immutable: true,
            });
            this.compareKernel = makeKernel(compare2D$4, {
                output: [this.width, this.height],
                functions: [measure$2],
                immutable: true,
            });
        }
    }
    predict() {
        release(this.weights);
        this.weights = this.predictKernel(this.inputLayer.weights);
        clear(this.deltas);
    }
    compare() {
        release(this.inputLayer.deltas);
        this.inputLayer.deltas = this.compareKernel(this.weights, this.deltas);
    }
}
function sigmoid$1(inputLayer, settings) {
    return new Sigmoid(inputLayer, settings);
}

function arthurFeedForward(settings, inputLayer) {
    const { height } = settings;
    function initWeightsPraxis(layerTemplate, settings) {
        const praxis = arthurDeviationWeights(layerTemplate, settings);
        praxis.setupKernels();
        return praxis;
    }
    function initBiasesPraxis(layerTemplate, settings) {
        const praxis = arthurDeviationBiases(layerTemplate, settings);
        praxis.setupKernels();
        return praxis;
    }
    const weightsLayer = random({
        id: 'weights',
        height,
        width: inputLayer.height,
        initPraxis: initWeightsPraxis,
    });
    const biasesLayer = random({
        id: 'biases',
        height,
        initPraxis: initBiasesPraxis,
    });
    const multiplyLayer = multiply$1(weightsLayer, inputLayer);
    const addLayer = add$1(multiplyLayer, biasesLayer);
    const sigmoidLayer = sigmoid$1(addLayer);
    const weightsPraxis = weightsLayer.praxis;
    weightsPraxis.weightsLayer = weightsLayer;
    weightsPraxis.incomingLayer = inputLayer;
    weightsPraxis.deltaLayer = sigmoidLayer;
    return sigmoidLayer;
}

function getStride(settings, defaults) {
    if (typeof settings.stride === 'number') {
        return { strideX: settings.stride, strideY: settings.stride };
    }
    else {
        let strideX = defaults.stride;
        let strideY = defaults.stride;
        if (typeof settings.strideX === 'number') {
            strideX = settings.strideX;
        }
        if (typeof settings.strideY === 'number') {
            strideY = settings.strideY;
        }
        return { strideX, strideY };
    }
}
function getPadding(settings, defaults) {
    if (typeof settings.padding === 'number') {
        return { paddingX: settings.padding, paddingY: settings.padding };
    }
    else {
        let paddingX = defaults.padding;
        let paddingY = defaults.padding;
        if (typeof settings.paddingX === 'number') {
            paddingX = settings.paddingX;
        }
        if (typeof settings.paddingY === 'number') {
            paddingY = settings.paddingY;
        }
        return { paddingX, paddingY };
    }
}

/**
 * Returns an array of a given size with each element filled with a single value
 */
function values(size, value) {
    return new Float32Array(size).fill(value);
}

function predict$6(inputs, filters, biases) {
    const startFilterX = this.constants.paddingX - this.thread.x * this.constants.strideX;
    const startInputX = this.thread.x * this.constants.strideX - this.constants.paddingX;
    const endFilterX = Math.min(this.constants.filterWidth, startFilterX + this.constants.inputWidth);
    const startFilterY = this.constants.paddingY - this.thread.y * this.constants.strideY;
    const startInputY = this.thread.y * this.constants.strideY - this.constants.paddingY;
    const endFilterY = Math.min(this.constants.filterHeight, startFilterY + this.constants.inputHeight);
    let sum = 0;
    for (let z = 0; z < this.constants.inputDepth; z++) {
        for (let filterY = Math.max(0, startFilterY), inputY = Math.max(0, startInputY); filterY < endFilterY; filterY++, inputY++) {
            for (let filterX = Math.max(0, startFilterX), inputX = Math.max(0, startInputX); filterX < endFilterX; filterX++, inputX++) {
                sum += filters[z][filterY][filterX] * inputs[z][inputY][inputX];
            }
        }
    }
    return sum + biases[this.thread.z];
}
function compareFilterDeltas$1(filterDeltas, inputs, deltas) {
    const startDeltaX = Math.max(0, Math.ceil((this.constants.paddingX - this.thread.x) / this.constants.strideX));
    const startInputX = startDeltaX * this.constants.strideX +
        this.thread.x -
        this.constants.paddingX;
    const endDeltaX = Math.min(this.constants.deltaWidth, Math.floor((this.constants.inputWidth -
        1 -
        this.thread.x +
        this.constants.paddingX) /
        this.constants.strideX) + 1);
    const startDeltaY = Math.max(0, Math.ceil((this.constants.paddingY - this.thread.y) / this.constants.strideY));
    const startInputY = startDeltaY * this.constants.strideY +
        this.thread.y -
        this.constants.paddingY;
    const endDeltaY = Math.min(this.constants.deltaHeight, Math.floor((this.constants.inputHeight -
        1 -
        this.thread.y +
        this.constants.paddingY) /
        this.constants.strideY) + 1);
    let sum = filterDeltas[this.thread.z][this.thread.y][this.thread.x];
    for (let deltaY = startDeltaY, inputY = startInputY; deltaY < endDeltaY; deltaY++, inputY += this.constants.strideY) {
        for (let deltaX = startDeltaX, inputX = startInputX; deltaX < endDeltaX; deltaX++, inputX += this.constants.strideX) {
            sum +=
                inputs[this.thread.z][inputY][inputX] *
                    deltas[this.constants.deltaZ][deltaY][deltaX];
        }
    }
    return sum;
}
function compareInputDeltas$1(inputDeltas, filters, deltas) {
    const x = this.thread.x + this.constants.paddingX;
    const startDeltaX = x < this.constants.filterWidth
        ? 0
        : Math.floor((x - this.constants.filterWidth + this.constants.strideX) /
            this.constants.strideX);
    const startFilterX = x - startDeltaX * this.constants.strideX;
    const endDeltaX = Math.min(startDeltaX + Math.floor(startFilterX / this.constants.strideX) + 1, this.constants.deltaWidth);
    const y = this.thread.y + this.constants.paddingY;
    const startDeltaY = y < this.constants.filterHeight
        ? 0
        : Math.floor((y - this.constants.filterHeight + this.constants.strideY) /
            this.constants.strideY);
    const startFilterY = y - startDeltaY * this.constants.strideY;
    const endDeltaY = Math.min(startDeltaY + Math.floor(startFilterY / this.constants.strideY) + 1, this.constants.deltaHeight);
    let sum = inputDeltas[this.thread.z][this.thread.y][this.thread.x];
    let deltaY = startDeltaY;
    for (let filterY = startFilterY; deltaY < endDeltaY; filterY -= this.constants.strideY, deltaY++) {
        let deltaX = startDeltaX;
        for (let filterX = startFilterX; deltaX < endDeltaX; filterX -= this.constants.strideX, deltaX++) {
            sum +=
                filters[this.thread.z][filterY][filterX] *
                    deltas[this.constants.deltaZ][deltaY][deltaX];
        }
    }
    return sum;
}
function compareBiases$1(biasDeltas, deltas) {
    let sum = 0;
    for (let y = 0; y < this.constants.deltaHeight; y++) {
        for (let x = 0; x < this.constants.deltaWidth; x++) {
            sum += deltas[this.thread.z][y][x];
        }
    }
    return biasDeltas[this.thread.z][this.thread.y][this.thread.x] + sum;
}
const defaults$6 = {
    stride: 0,
    padding: 0,
    bias: 0.1,
    filterCount: 1,
    filterWidth: 0,
    filterHeight: 0,
};
class Convolution extends Filter {
    constructor(settings, inputLayer) {
        var _a, _b, _c;
        super(settings, inputLayer);
        this.compareFilterDeltasKernel = null;
        this.compareInputDeltasKernel = null;
        this.compareBiasesKernel = null;
        this.settings = {
            ...defaults$6,
            ...settings,
            ...getPadding(settings, defaults$6),
            ...getStride(settings, defaults$6),
        };
        this.weights = (_a = settings.weights) !== null && _a !== void 0 ? _a : randos3D(this.width, this.height, this.depth);
        this.deltas = zeros3D(this.width, this.height, this.depth);
        this.biases = values(this.depth, this.bias);
        this.biasDeltas = (_b = settings.biasDeltas) !== null && _b !== void 0 ? _b : randos(this.depth);
        this.filters = (_c = settings.filters) !== null && _c !== void 0 ? _c : randos3D(this.filterWidth, this.filterHeight, this.filterCount);
        this.filterDeltas = zeros3D(this.filterWidth, this.filterHeight, this.filterCount);
        this.validate();
    }
    get strideX() {
        return this.settings.strideX;
    }
    get strideY() {
        return this.settings.strideY;
    }
    get paddingX() {
        return this.settings.paddingX;
    }
    get paddingY() {
        return this.settings.paddingX;
    }
    get width() {
        return Math.floor((this.inputLayer.width + this.paddingX * 2 - this.filterWidth) /
            this.strideX +
            1);
    }
    get height() {
        return Math.floor((this.inputLayer.height + this.paddingY * 2 - this.filterHeight) /
            this.strideY +
            1);
    }
    get bias() {
        return this.settings.bias;
    }
    get depth() {
        return this.filterCount;
    }
    get biases() {
        return this.settings.biases;
    }
    set biases(biases) {
        this.settings.biases = biases;
    }
    get biasDeltas() {
        return this.settings.biasDeltas;
    }
    set biasDeltas(weights) {
        this.settings.biasDeltas = weights;
    }
    get filters() {
        return this.settings.filters;
    }
    set filters(filters) {
        this.settings.filters = filters;
    }
    get filterDeltas() {
        return this.settings.filterDeltas;
    }
    set filterDeltas(filterDeltas) {
        this.settings.filterDeltas = filterDeltas;
    }
    setupKernels() {
        this.predictKernel = makeKernel(predict$6, {
            constants: {
                inputWidth: this.inputLayer.width,
                inputHeight: this.inputLayer.height,
                inputDepth: this.inputLayer.depth,
                strideX: this.strideX,
                strideY: this.strideY,
                paddingX: this.paddingX,
                paddingY: this.paddingY,
                filterWidth: this.filterWidth,
                filterHeight: this.filterHeight,
            },
            output: [this.width, this.height, this.depth],
            immutable: true,
        });
        this.compareFilterDeltasKernel = makeKernel(compareFilterDeltas$1, {
            constants: {
                deltasWidth: this.width,
                deltasHeight: this.height,
                deltasDepth: this.depth,
                inputWidth: this.inputLayer.width,
                inputHeight: this.inputLayer.height,
                inputDepth: this.inputLayer.depth,
                strideX: this.strideX,
                strideY: this.strideY,
                paddingX: this.paddingX,
                paddingY: this.paddingY,
                filterWidth: this.filterWidth,
                filterHeight: this.filterHeight,
            },
            output: [this.width, this.height, this.depth],
            immutable: true,
        });
        this.compareInputDeltasKernel = makeKernel(compareInputDeltas$1, {
            constants: {
                filterCount: this.filterCount,
            },
            output: [
                this.inputLayer.width,
                this.inputLayer.height,
                this.inputLayer.depth,
            ],
            immutable: true,
        });
        this.compareBiasesKernel = makeKernel(compareBiases$1, {
            output: [1, 1, this.depth],
            constants: {
                deltaWidth: this.width,
                deltaHeight: this.height,
            },
            immutable: true,
        });
    }
    predict() {
        this.weights = this.predictKernel(this.inputLayer.weights, this.filters, this.biases);
    }
    compare() {
        const { filterDeltas, biasDeltas } = this;
        this.filterDeltas = this.compareFilterDeltasKernel(filterDeltas, this.inputLayer.weights, this.deltas);
        release(filterDeltas);
        this.biasDeltas = this.compareBiasesKernel(biasDeltas, this.deltas);
        release(biasDeltas);
        release(this.deltas);
        this.deltas = this.compareInputDeltasKernel(this.filters, this.inputLayer.deltas);
        release(this.inputLayer.deltas);
        // TODO: do we need to clone here?
        this.inputLayer.deltas = clone(this.deltas);
    }
    learn(learningRate) {
        // TODO: handle filters
        // TODO: do we need to release here?
        const { weights: oldWeights } = this;
        this.weights = this.praxis.run(this, learningRate);
        release(oldWeights);
        clear(this.deltas);
    }
}
function convolution(settings, inputLayer) {
    return new Convolution(settings, inputLayer);
}

function setDropout(dropout) {
    return dropout;
}
function trainingPredict(inputs) {
    if (setDropout(Math.random()) < this.constants.probability) {
        return 0;
    }
    return inputs[this.thread.y][this.thread.x];
}
function predict$5(inputs) {
    return inputs[this.thread.y][this.thread.x] * this.constants.probability;
}
function compare$3(dropouts, deltas) {
    if (dropouts[this.thread.y][this.thread.x] === 0) {
        return 0;
    }
    return deltas[this.thread.y][this.thread.x];
}
const dropoutDefaults = {
    ...baseLayerDefaultSettings,
    probability: 0.5,
};
class Dropout extends Filter {
    constructor(inputLayer, settings) {
        super(settings, inputLayer);
        this.predictKernelMap = null;
        this.settings = { ...dropoutDefaults, ...settings };
        this.dropouts = null;
        this.validate();
    }
    setupKernels(isTraining) {
        const output = [this.width, this.height];
        if (isTraining) {
            this.predictKernelMap = makeKernelMap({ dropouts: setDropout }, trainingPredict, {
                output,
                immutable: true,
            });
            this.compareKernel = makeKernel(compare$3, { output, immutable: true });
        }
        else {
            this.predictKernelMap = makeKernelMap({}, predict$5, { output, immutable: true });
        }
    }
    predict() {
        release(this.weights);
        if (this.dropouts) {
            release(this.dropouts);
        }
        const { result, dropouts } = this
            .predictKernelMap(this.inputLayer.weights);
        this.weights = result;
        this.dropouts = dropouts;
    }
    compare() {
        release(this.deltas);
        this.deltas = this.compareKernel(this.dropouts, this.inputLayer.deltas);
    }
}
function dropout(inputLayer, settings) {
    return new Dropout(inputLayer, settings);
}

function feedForward(settings, input) {
    const { height, praxisOpts = null } = settings;
    const weights = random({
        id: 'weights',
        height,
        width: input.height,
        praxisOpts,
    });
    const biases = random({ id: 'biases', height, praxisOpts });
    return sigmoid$1(add$1(multiply$1(weights, input, { praxisOpts }), biases, { praxisOpts }), { praxisOpts });
}

function predict$4(inputs, filters, biases) {
    let output = 0;
    let i = 0;
    for (let y = 0; y < this.constants.inputHeight; y++) {
        for (let x = 0; x < this.constants.inputWidth; x++) {
            output += inputs[y][x] * filters[this.thread.x][i];
            i++;
        }
    }
    return output + biases[this.thread.x];
}
function predict3D$4(inputs, filters, biases) {
    let output = 0;
    let i = 0;
    for (let z = 0; z < this.constants.inputDepth; z++) {
        for (let y = 0; y < this.constants.inputHeight; y++) {
            for (let x = 0; x < this.constants.inputWidth; x++) {
                output += inputs[z][y][x] * filters[this.thread.x][i];
                i++;
            }
        }
    }
    return output + biases[this.thread.x];
}
function compareInputDeltas(inputDeltas, deltas, filters) {
    let sum = 0;
    const filterX = this.thread.x + this.thread.y * this.output.x;
    for (let filterY = 0; filterY < this.constants.filterCount; filterY++) {
        sum += filters[filterY][filterX] * deltas[0][filterY];
    }
    return sum + inputDeltas[this.thread.y][this.thread.x];
}
function compareInputDeltas3D(inputDeltas, deltas, filters) {
    let sum = 0;
    const filterX = this.thread.x + this.thread.y * this.output.x;
    for (let filterY = 0; filterY < this.constants.filterCount; filterY++) {
        sum += filters[filterY][filterX] * deltas[0][filterY];
    }
    return sum + inputDeltas[this.thread.z][this.thread.y][this.thread.x];
}
function compareBiases(biases, deltas) {
    return biases[this.thread.x] + deltas[this.thread.y][this.thread.x];
}
function compareFilterDeltas(filterDeltas, inputWeights, deltas) {
    return (filterDeltas[this.thread.y][this.thread.x] +
        inputWeights[this.thread.y][this.thread.x] *
            deltas[this.constants.deltaY][this.constants.deltaX]);
}
function compareFilterDeltas3D(filterDeltas, inputWeights, deltas) {
    const inputZ = Math.floor(this.thread.x / (this.constants.inputWidth * this.constants.inputHeight));
    const inputY = Math.floor((this.thread.x -
        inputZ * this.constants.inputWidth * this.constants.inputHeight) /
        this.constants.inputWidth);
    const inputX = this.thread.x -
        this.constants.inputWidth * (inputY + this.constants.inputHeight * inputZ);
    return (filterDeltas[this.thread.y][this.thread.x] +
        inputWeights[inputZ][inputY][inputX] * deltas[0][this.thread.y]);
}
class FullyConnected extends Filter {
    constructor(settings, inputLayer) {
        super(settings, inputLayer);
        this.compareFilterDeltasKernel = null;
        this.compareInputDeltasKernel = null;
        this.compareBiasesKernel = null;
        this.settings = { ...settings };
        this.validate();
        const connectionCount = inputLayer.width * inputLayer.height * inputLayer.depth;
        this.biases = values(this.height, this.bias);
        this.biasDeltas = zeros$1(this.height);
        this.filters = randos2D(connectionCount, this.height);
        this.filterDeltas = zeros2D(connectionCount, this.height);
        if (this.depth > 0) {
            this.weights = randos3D(this.width, this.height, this.depth);
            this.deltas = zeros3D(this.width, this.height, this.depth);
        }
        else if (this.height > 0) {
            this.weights = randos2D(this.width, this.height);
            this.deltas = zeros2D(this.width, this.height);
        }
    }
    get bias() {
        return this.settings.bias;
    }
    get biases() {
        return this.settings.biases;
    }
    set biases(biases) {
        this.settings.biases = biases;
    }
    get biasDeltas() {
        return this.settings.biases;
    }
    set biasDeltas(biasDeltas) {
        this.settings.biasDeltas = biasDeltas;
    }
    validate() {
        super.validate();
        if (this.depth > 0)
            throw new Error('depth not supported');
    }
    setupKernels() {
        const { inputLayer } = this;
        const connectionCount = inputLayer.width * inputLayer.height * inputLayer.depth;
        if (inputLayer.depth > 0) {
            this.predictKernel = makeKernel(predict3D$4, {
                output: [this.width, this.height],
                constants: {
                    inputHeight: inputLayer.height,
                    inputWidth: inputLayer.width,
                    inputDepth: inputLayer.depth,
                },
            });
            this.compareFilterDeltasKernel = makeKernel(compareFilterDeltas3D, {
                output: [connectionCount, this.height],
                constants: {
                    inputWidth: inputLayer.width,
                    inputHeight: inputLayer.height,
                },
                immutable: true,
            });
            this.compareInputDeltasKernel = makeKernel(compareInputDeltas3D, {
                output: [inputLayer.width, inputLayer.height, inputLayer.depth],
                constants: {
                    filterCount: this.height,
                },
                immutable: true,
            });
        }
        else {
            this.predictKernel = makeKernel(predict$4, {
                output: [this.width, this.height],
                constants: {
                    inputHeight: inputLayer.height,
                    inputWidth: inputLayer.width,
                },
            });
            this.compareFilterDeltasKernel = makeKernel(compareFilterDeltas, {
                output: [connectionCount, this.height],
                constants: {
                    inputWidth: inputLayer.width,
                },
            });
            this.compareInputDeltasKernel = makeKernel(compareInputDeltas, {
                output: [inputLayer.width, inputLayer.height],
                constants: {
                    filterCount: this.height,
                },
            });
        }
        this.compareBiasesKernel = makeKernel(compareBiases, {
            output: [this.width, this.height],
        });
    }
    predict() {
        this.weights = this.predictKernel(this.inputLayer.weights, this.filters, this.biases);
    }
    compare() {
        const inputLayerDeltas = this.inputLayer.deltas;
        this.inputLayer.deltas = this
            .compareInputDeltasKernel(inputLayerDeltas, this.deltas, this.filters);
        release(inputLayerDeltas);
        const { biasDeltas, filterDeltas } = this;
        // TODO: handle biasDeltas learn
        this.biasDeltas = this.compareBiasesKernel(this.biases, this.deltas);
        // TODO: handle filterDeltas learn
        this.filterDeltas = this.compareFilterDeltasKernel(filterDeltas, this.inputLayer.weights, this.deltas);
        release(biasDeltas);
        release(filterDeltas);
    }
}
function fullyConnected(settings, inputLayer) {
    return new FullyConnected(settings, inputLayer);
}

function predict$3(weights) {
    return -weights[this.thread.y][this.thread.x];
}
class Negative extends Modifier {
    constructor(inputLayer, settings) {
        super(inputLayer, settings);
        this.validate();
    }
    setupKernels() {
        this.predictKernel = makeKernel(predict$3, {
            output: [this.width, this.height],
        });
    }
    predict() {
        this.weights = this.predictKernel(this.inputLayer.weights);
    }
}
function negative(inputLayer, settings) {
    return new Negative(inputLayer, settings);
}

function predict$2(inputLayerWeights1, inputLayerWeights2) {
    return (inputLayerWeights1[this.thread.y][this.thread.x] *
        inputLayerWeights2[this.thread.y][this.thread.x]);
}
function compare$2(weights, deltas) {
    return (weights[this.thread.y][this.thread.x] * deltas[this.thread.y][this.thread.x]);
}
class MultiplyElement extends Operator {
    get width() {
        return this.inputLayer1.width;
    }
    get height() {
        return this.inputLayer1.height;
    }
    get depth() {
        return this.inputLayer1.depth;
    }
    validate() {
        super.validate();
        checkSameSize(this.inputLayer1, this.inputLayer2);
    }
    setupKernels() {
        this.predictKernel = makeKernel(predict$2, {
            output: [this.width, this.height],
            immutable: true,
        });
        this.compareKernel = makeKernel(compare$2, {
            output: [this.width, this.height],
            immutable: true,
        });
    }
    predict() {
        release(this.weights);
        this.weights = this.predictKernel(this.inputLayer1.weights, this.inputLayer2.weights);
        clear(this.deltas);
    }
    compare() {
        release(this.inputLayer1.deltas);
        release(this.inputLayer2.deltas);
        this.inputLayer1.deltas = this.compareKernel(this.inputLayer2.weights, this.deltas);
        this.inputLayer2.deltas = this.compareKernel(this.inputLayer1.weights, this.deltas);
    }
}
function multiplyElement$1(inputLayer1, inputLayer2, settings) {
    return new MultiplyElement(inputLayer1, inputLayer2, settings);
}

function ones$1(size) {
    return new Float32Array(size).fill(1);
}
function ones2D(width, height) {
    const result = new Array(height);
    for (let y = 0; y < height; y++) {
        result[y] = ones$1(width);
    }
    return result;
}

class Ones extends Model {
    constructor(settings) {
        super(settings);
        this.validate();
        this.weights = ones2D(this.width, this.height);
        this.deltas = zeros2D(this.width, this.height);
    }
}
function ones(settings) {
    return new Ones(settings);
}

function predict2D$3(inputs) {
    return activate$1(inputs[this.thread.y][this.thread.x]);
}
function predict3D$3(inputs) {
    return activate$1(inputs[this.thread.z][this.thread.y][this.thread.x]);
}
function compare2D$3(weights, errors) {
    return measure$1(weights[this.thread.y][this.thread.x], errors[this.thread.y][this.thread.x]);
}
function compare3D$3(weights, errors) {
    return measure$1(weights[this.thread.z][this.thread.y][this.thread.x], errors[this.thread.z][this.thread.y][this.thread.x]);
}
class Tanh extends Activation {
    setupKernels() {
        if (this.depth > 0) {
            this.predictKernel = makeKernel(predict3D$3, {
                output: [this.width, this.height, this.depth],
                functions: [activate$1],
                immutable: true,
            });
            this.compareKernel = makeKernel(compare3D$3, {
                output: [this.width, this.height, this.depth],
                functions: [measure$1],
                immutable: true,
            });
        }
        else {
            this.predictKernel = makeKernel(predict2D$3, {
                output: [this.width, this.height],
                functions: [activate$1],
                immutable: true,
            });
            this.compareKernel = makeKernel(compare2D$3, {
                output: [this.width, this.height],
                functions: [measure$1],
                immutable: true,
            });
        }
    }
    predict() {
        release(this.weights);
        this.weights = this.predictKernel(this.inputLayer.weights);
        clear(this.deltas);
    }
    compare() {
        release(this.inputLayer.deltas);
        this.inputLayer.deltas = this.compareKernel(this.weights, this.deltas);
    }
}
function tanh$1(inputLayer, settings) {
    return new Tanh(inputLayer, settings);
}

class Zeros extends Model {
    constructor(settings) {
        super(settings);
        this.validate();
        this.weights = zeros2D(this.width, this.height);
        this.deltas = zeros2D(this.width, this.height);
    }
    predict() {
        // throw new Error(`${this.constructor.name}-predict is not yet implemented`)
    }
    compare() {
        // throw new Error(`${this.constructor.name}-compare is not yet implemented`)
    }
}
function zeros(settings) {
    return new Zeros(settings);
}

function gru(settings, recurrentInput, input) {
    const { height } = settings;
    const updateGateWeights = random({ height, width: input.height });
    const updateGatePeepholes = random({ width: height, height });
    const updateGateBias = zeros({ height });
    const updateGate = sigmoid$1(add$1(add$1(multiply$1(updateGateWeights, input), multiply$1(updateGatePeepholes, recurrentInput)), updateGateBias));
    const resetGateWeights = random({ height, width: input.height });
    const resetGatePeepholes = random({ width: height, height });
    const resetGateBias = zeros({ height });
    const resetGate = sigmoid$1(add$1(add$1(multiply$1(resetGateWeights, input), multiply$1(resetGatePeepholes, recurrentInput)), resetGateBias));
    const cellWeights = random({ height, width: input.height });
    const cellPeepholes = random({ width: height, height });
    const cellBias = zeros({ height });
    const cell = tanh$1(add$1(add$1(multiply$1(cellWeights, input), multiply$1(cellPeepholes, multiplyElement$1(resetGate, recurrentInput))), cellBias));
    // compute hidden state as gated, saturated cell activations
    // negate updateGate
    return add$1(multiplyElement$1(add$1(ones({ width: updateGate.width, height: updateGate.height }), negative(updateGate)), cell), multiplyElement$1(recurrentInput, updateGate));
}

const defaults$5 = {
    weights: null,
};
class Input extends EntryPoint {
    constructor(settings) {
        super({ ...defaults$5, ...settings });
        this.reshapeInput = null;
        this.validate();
        this.reshapeInput = null;
        this.deltas = zeros2D(this.width, this.height);
    }
    setupKernels() {
        if (this.width === 1) {
            this.predict = this.predict1D;
            this.reshapeInput = makeKernel(function (value) {
                return value[this.thread.y];
            }, {
                output: [1, this.height],
                immutable: true,
            });
        }
    }
    reuseKernels(layer) {
        // super.reuseKernels(layer);
        this.reshapeInput = layer.reshapeInput;
    }
    predict(inputs) {
        if ((Array.isArray(inputs) || inputs instanceof Float32Array) &&
            typeof inputs[0] === 'number' &&
            inputs.length === this.height * this.width) {
            release(this.weights);
            this.weights = kernelInput(inputs, [this.width, this.height]);
        }
        else if (Array.isArray(inputs) &&
            inputs.length === this.height &&
            (Array.isArray(inputs[0]) || inputs[0] instanceof Float32Array) &&
            inputs[0].length === this.width) {
            this.weights = clone(inputs);
        }
        else {
            throw new Error('Inputs are not of sized correctly');
        }
        clear(this.deltas);
    }
    predict1D(inputs) {
        if (this.weights)
            release(this.weights);
        if (this.reshapeInput) {
            this.weights = this.reshapeInput(inputs);
        }
        else {
            this.weights = inputs;
        }
        clear(this.deltas);
    }
    compare() {
        // throw new Error(`${this.constructor.name}-compare is not yet implemented`)
    }
}
function input(settings) {
    return new Input(settings);
}

function predict2D$2(inputs) {
    return activate(inputs[this.thread.y][this.thread.x]);
}
function predict3D$2(inputs) {
    return activate(inputs[this.thread.z][this.thread.y][this.thread.x]);
}
function compare2D$2(weights, deltas) {
    return measure(weights[this.thread.y][this.thread.x], deltas[this.thread.y][this.thread.x]);
}
function compare3D$2(weights, deltas) {
    return measure(weights[this.thread.z][this.thread.y][this.thread.x], deltas[this.thread.z][this.thread.y][this.thread.x]);
}
class LeakyRelu extends Activation {
    setupKernels() {
        const { width, height, depth } = this.inputLayer;
        if (this.depth > 0) {
            this.predictKernel = makeKernel(predict3D$2, {
                output: [width, height, depth],
                functions: [activate],
                immutable: true,
            });
            this.compareKernel = makeKernel(compare3D$2, {
                output: [width, height, depth],
                functions: [measure],
                immutable: true,
            });
        }
        else {
            this.predictKernel = makeKernel(predict2D$2, {
                output: [width, height],
                functions: [activate],
                immutable: true,
            });
            this.compareKernel = makeKernel(compare2D$2, {
                output: [width, height],
                functions: [measure],
                immutable: true,
            });
        }
    }
    predict() {
        release(this.weights);
        this.weights = this.predictKernel(this.inputLayer.weights);
        clear(this.deltas);
    }
    compare() {
        const { deltas } = this;
        this.deltas = this.compareKernel(this.weights, deltas);
        release(deltas);
    }
}
function leakyRelu(inputLayer, settings) {
    return new LeakyRelu(inputLayer, settings);
}

function lstmCell(settings, input, recurrentInput) {
    const { height } = settings;
    if (typeof height !== 'number') {
        throw new Error('no settings.height given');
    }
    if (recurrentInput.setDimensions) {
        recurrentInput.setDimensions(1, height);
    }
    const inputGateWeights = random({
        height,
        width: input.height,
        std: 0.08,
        id: 'inputGateWeights',
    });
    const inputGatePeepholes = random({
        width: height,
        height,
        std: 0.08,
        id: 'inputGatePeepholes',
    });
    const inputGateBias = zeros({ height, id: 'inputGateBias' });
    const inputGate = sigmoid$1(add$1(add$1(multiply$1(inputGateWeights, input), multiply$1(inputGatePeepholes, recurrentInput)), inputGateBias), { id: 'inputGate' });
    const forgetGateWeights = random({
        height,
        width: input.height,
        std: 0.08,
        id: 'forgetGateWeights',
    });
    const forgetGatePeepholes = random({
        width: height,
        height,
        std: 0.08,
        id: 'forgetGatePeepholes',
    });
    const forgetGateBias = zeros({ height, id: 'forgetGateBias' });
    const forgetGate = sigmoid$1(add$1(add$1(multiply$1(forgetGateWeights, input), multiply$1(forgetGatePeepholes, recurrentInput)), forgetGateBias), { id: 'forgetGate' });
    const outputGateWeights = random({
        height,
        width: input.height,
        std: 0.08,
        id: 'outputGateWeights',
    });
    const outputGatePeepholes = random({
        width: height,
        height,
        std: 0.08,
        id: 'outputGatePeepholes',
    });
    const outputGateBias = zeros({ height, id: 'outputGateBias' });
    const outputGate = sigmoid$1(add$1(add$1(multiply$1(outputGateWeights, input), multiply$1(outputGatePeepholes, recurrentInput)), outputGateBias), { id: 'outputGate' });
    const memoryWeights = random({
        height,
        width: input.height,
        std: 0.08,
        id: 'memoryWeights',
    });
    const memoryPeepholes = random({
        width: height,
        height,
        std: 0.08,
        id: 'memoryPeepholes',
    });
    const memoryBias = zeros({ height, id: 'memoryBias' });
    const memory = tanh$1(add$1(add$1(multiply$1(memoryWeights, input), multiply$1(memoryPeepholes, recurrentInput)), memoryBias), { id: 'memory' });
    // compute new cell activation
    const retainCell = multiplyElement$1(forgetGate, recurrentInput, {
        id: 'retainCell',
    }); // what do we keep from cell
    const writeCell = multiplyElement$1(inputGate, memory, { id: 'writeCell' }); // what do we write to cell
    const cell = add$1(retainCell, writeCell, { id: 'cell' }); // new cell contents
    // compute hidden state as gated, saturated cell activations
    return multiplyElement$1(outputGate, tanh$1(cell), { id: 'activations' });
}

function output(settings, inputLayer) {
    const { height } = settings;
    const outputGate = random({
        height,
        width: inputLayer.height,
        id: 'outputGate',
        std: 0.08,
    });
    const output = random({ height, id: 'output', std: 0.08 });
    const outputGateConnector = multiply$1(outputGate, inputLayer, {
        id: 'outputGateConnected',
    });
    return target({ id: 'target', ...settings }, add$1(outputGateConnector, output));
}

function setSwitchY(value) {
    return value;
}
function setSwitchX(value) {
    return value;
}
function predict$1(inputs) {
    const startFilterX = this.constants.paddingX - this.thread.x * this.constants.strideX;
    const startInputX = this.thread.x * this.constants.strideX - this.constants.paddingX;
    const endFilterX = Math.min(this.constants.filterWidth, startFilterX + this.constants.inputWidth);
    const startFilterY = this.constants.paddingY - this.thread.y * this.constants.strideY;
    const startInputY = this.thread.y * this.constants.strideY - this.constants.paddingY;
    const endFilterY = Math.min(this.constants.filterHeight, startFilterY + this.constants.inputHeight);
    let largestValue = -99999;
    // convolve centered at this particular location
    for (let filterY = Math.max(0, startFilterY), inputY = Math.max(0, startInputY); filterY < endFilterY; filterY++, inputY++) {
        for (let filterX = Math.max(0, startFilterX), inputX = Math.max(0, startInputX); filterX < endFilterX; filterX++, inputX++) {
            if (inputY >= 0 &&
                inputY < this.constants.inputHeight &&
                inputX >= 0 &&
                inputX < this.constants.inputWidth) {
                const input = inputs[this.thread.z][inputY][inputX];
                if (input > largestValue) {
                    largestValue = input;
                }
            }
        }
    }
    return largestValue;
}
function compare$1(deltas, switchY, switchX) {
    const x = Math.floor((this.thread.x / this.output.x) * this.constants.outputWidth);
    const y = Math.floor((this.thread.y / this.output.y) * this.constants.outputHeight);
    let value = 0;
    for (let deltasY = 0; deltasY < this.constants.inputHeight; deltasY++) {
        for (let deltasX = 0; deltasX < this.constants.inputWidth; deltasX++) {
            const switchXValue = switchX[deltasY][deltasX];
            const switchYValue = switchY[deltasY][deltasX];
            if (switchXValue === x && switchYValue === y) {
                value += deltas[deltasY][deltasX];
            }
        }
    }
    return value;
}
const defaults$4 = {
    padding: 0,
    stride: 0,
    filterWidth: 0,
    filterHeight: 0,
    filterCount: 0,
};
class Pool extends Filter {
    constructor(settings, inputLayer) {
        super(settings, inputLayer);
        this.predictKernelMap = null;
        this.settings = {
            ...settings,
            ...getStride(settings, defaults$4),
            ...getPadding(settings, defaults$4),
        };
        this.weights = randos3D(this.width, this.height, this.depth);
        this.deltas = zeros3D(this.width, this.height, this.depth);
        this.filters = randos3D(this.filterWidth, this.filterHeight, this.filterCount);
        this.filterDeltas = zeros3D(this.filterWidth, this.filterHeight, this.filterCount);
        this.validate();
    }
    get strideX() {
        return this.settings.strideX;
    }
    get strideY() {
        return this.settings.strideY;
    }
    get paddingX() {
        return this.settings.paddingX;
    }
    get paddingY() {
        return this.settings.paddingY;
    }
    get width() {
        return Math.floor((this.inputLayer.width + this.paddingX * 2 - this.filterWidth) /
            this.strideX +
            1);
    }
    get height() {
        return Math.floor((this.inputLayer.height + this.paddingY * 2 - this.filterHeight) /
            this.strideY +
            1);
    }
    get depth() {
        return this.settings.filterCount;
    }
    get filterCount() {
        // TODO: handle 1 depth?
        return this.settings.filterCount;
    }
    get switchX() {
        return this.settings.switchX;
    }
    set switchX(switchX) {
        this.settings.switchX = switchX;
    }
    get switchY() {
        return this.settings.switchY;
    }
    set switchY(switchY) {
        this.settings.switchY = switchY;
    }
    setupKernels() {
        this.predictKernelMap = makeKernelMap({
            switchX: setSwitchX,
            switchY: setSwitchY,
        }, predict$1, {
            output: [this.width, this.height, this.depth],
            constants: {
                inputWidth: this.inputLayer.width,
                inputHeight: this.inputLayer.height,
                paddingX: this.paddingX,
                paddingY: this.paddingY,
                filterHeight: this.filterHeight,
                filterWidth: this.filterWidth,
            },
        });
        this.compareKernel = makeKernel(compare$1, {
            output: [
                this.inputLayer.width,
                this.inputLayer.height,
                this.inputLayer.depth,
            ],
            constants: {
                inputWidth: this.inputLayer.width,
                inputHeight: this.inputLayer.height,
                outputWidth: this.width,
                outputHeight: this.height,
            },
        });
    }
    predict() {
        const { result: weights, switchX, switchY } = this
            .predictKernelMap(this.inputLayer.weights);
        this.switchX = switchX;
        this.switchY = switchY;
        this.weights = weights;
    }
    compare() {
        // debugger;
        // const depth = this.inputLayer.deltas.length;
        // const height = this.inputLayer.deltas[0].length;
        // const width = this.inputLayer.deltas[0][0].length;
        // const type = typeof this.inputLayer.deltas[0][0][0];
        const inputLayerDeltas = this.inputLayer.deltas;
        this.inputLayer.deltas = this.compareKernel(this.deltas, this.switchX, this.switchY);
        release(inputLayerDeltas);
        // debugger;
        // if (depth !== this.inputLayer.deltas.length) debugger;
        // if (height !== this.inputLayer.deltas[0].length) debugger;
        // if (width !== this.inputLayer.deltas[0][0].length) debugger;
        // if (type !== typeof this.inputLayer.deltas[0][0][0]) debugger;
    }
}
function pool(settings, inputLayer) {
    return new Pool(settings, inputLayer);
}

class RecurrentInput extends Internal {
    constructor(recurrentInput) {
        super();
        this.praxis = null;
        this.predictKernel = null;
        this.compareKernel = null;
        this.settings = {};
        this.recurrentInput = recurrentInput;
        this.validate();
    }
    get width() {
        return this.recurrentInput.width;
    }
    get height() {
        return this.recurrentInput.height;
    }
    get depth() {
        return this.recurrentInput.depth;
    }
    get deltas() {
        return this.recurrentInput.deltas;
    }
    set deltas(deltas) {
        const recurrentInputDeltas = this.recurrentInput.deltas;
        this.recurrentInput.deltas = deltas;
        release(recurrentInputDeltas);
    }
    get weights() {
        return this.recurrentInput.weights;
    }
    set weights(weights) {
        const recurrentInputWeights = this.recurrentInput.weights;
        this.recurrentInput.weights = weights;
        release(recurrentInputWeights);
    }
    validate() {
        BaseLayer.prototype.validate.call(this);
        if (this.width !== this.recurrentInput.width) {
            throw new Error(`${this.constructor.name} layer width ${this.width} and ${this.recurrentInput.constructor.name} width (${this.recurrentInput.width}) are not same`);
        }
        if (this.height !== this.recurrentInput.height) {
            throw new Error(`${this.constructor.name} layer height ${this.height} and ${this.recurrentInput.constructor.name} width (${this.recurrentInput.height}) are not same`);
        }
    }
    setDimensions(width, height) {
        this.recurrentInput.width = width;
        this.recurrentInput.height = height;
    }
    predict() {
        // throw new Error(`${this.constructor.name}-predict is not yet implemented`)
    }
    compare() {
        // throw new Error(`${this.constructor.name}-compare is not yet implemented`)
    }
    learn() {
        // throw new Error(`${this.constructor.name}-learn is not yet implemented`)
    }
    setupKernels() {
        // throw new Error(
        //   `${this.constructor.name}-setupKernels is not yet implemented`
        // )
    }
    reuseKernels() {
        // throw new Error(
        //   `${this.constructor.name}-reuseKernels is not yet implemented`
        // )
    }
}

class RecurrentZeros extends Internal {
    constructor(settings) {
        super();
        this.praxis = null;
        this.settings = {};
        this.predictKernel = null;
        this.compareKernel = null;
        if (settings) {
            this.settings = { ...settings };
        }
    }
    setDimensions(width, height) {
        this.praxis = null;
        this.settings = {
            ...this.settings,
            width,
            height,
            weights: zeros2D(width, height),
            deltas: zeros2D(width, height),
        };
    }
    setupKernels() {
        // throw new Error(
        //   `${this.constructor.name}-setupKernels is not yet implemented`
        // )
    }
    reuseKernels() {
        // throw new Error(
        //   `${this.constructor.name}-reuseKernels is not yet implemented`
        // )
    }
    predict() {
        // throw new Error(`${this.constructor.name}-predict is not yet implemented`)
    }
    compare() {
        // throw new Error(`${this.constructor.name}-compare is not yet implemented`)
    }
    learn(learningRate) {
        const { weights: oldWeights } = this;
        this.weights = this.praxis.run(this, learningRate);
        // this.deltas = deltas;
        release(oldWeights);
        clear(this.deltas);
    }
}
function recurrentZeros() {
    return new RecurrentZeros();
}

function predict2D$1(inputs) {
    return activate$3(inputs[this.thread.y][this.thread.x]);
}
function compare2D$1(weights, deltas) {
    return measure$3(weights[this.thread.y][this.thread.x], deltas[this.thread.y][this.thread.x]);
}
function predict3D$1(inputs) {
    return activate$3(inputs[this.thread.z][this.thread.y][this.thread.x]);
}
function compare3D$1(weights, deltas) {
    return measure$3(weights[this.thread.z][this.thread.y][this.thread.x], deltas[this.thread.z][this.thread.y][this.thread.x]);
}
class Relu extends Activation {
    setupKernels() {
        const { width, height, depth } = this.inputLayer;
        if (depth > 0) {
            this.predictKernel = makeKernel(predict3D$1, {
                output: [width, height, depth],
                functions: [activate$3],
                immutable: true,
            });
            this.compareKernel = makeKernel(compare3D$1, {
                output: [width, height, depth],
                functions: [measure$3],
                immutable: true,
            });
        }
        else {
            this.predictKernel = makeKernel(predict2D$1, {
                output: [width, height],
                functions: [activate$3],
                immutable: true,
            });
            this.compareKernel = makeKernel(compare2D$1, {
                output: [width, height],
                functions: [measure$3],
                immutable: true,
            });
        }
    }
    predict() {
        release(this.weights);
        this.weights = this.predictKernel(this.inputLayer.weights);
        clear(this.deltas);
    }
    compare() {
        release(this.inputLayer.deltas);
        this.inputLayer.deltas = this.compareKernel(this.weights, this.deltas);
    }
}
function relu$1(inputLayer, settings) {
    return new Relu(inputLayer, settings);
}

function rnnCell(settings, input, recurrentInput) {
    const { height } = settings;
    if (typeof height !== 'number')
        throw new Error('height not set');
    if (recurrentInput.setDimensions) {
        recurrentInput.setDimensions(1, height);
    }
    // wxh
    const weight = random({
        id: 'weight',
        height,
        width: input.height,
        std: 0.08,
    });
    // whh
    const transition = random({
        id: 'transition',
        height,
        width: height,
        std: 0.08,
    });
    // bhh
    const bias = zeros({ id: 'bias', height });
    return relu$1(add$1(add$1(multiply$1(weight, input), multiply$1(transition, recurrentInput)), bias));
}

class Regression extends BaseLayer {
    constructor(settings, inputLayer) {
        super(settings);
        this.inputLayer = inputLayer;
        this.validate();
    }
    predict() {
        release(this.weights);
        this.weights = clone(this.inputLayer.weights);
    }
    learn() {
        // throw new Error(`${this.constructor.name}-learn is not yet implemented`)
    }
}
// TODO: handle `loss += 0.5*dy*dy;` total and sum in learn
function regression(settings, inputLayer) {
    return new Regression(settings, inputLayer);
}

function getMaxValue2D(inputs) {
    let maxInput = -Infinity;
    for (let y = 0; y < this.constants.inputHeight; y++) {
        for (let x = 0; x < this.constants.inputWidth; x++) {
            const input = inputs[y][x];
            if (input > maxInput) {
                maxInput = input;
            }
        }
    }
    return maxInput;
}
function getMaxValue3D(inputs) {
    let maxInput = -Infinity;
    for (let z = 0; z < this.constants.inputDepth; z++) {
        for (let y = 0; y < this.constants.inputHeight; y++) {
            for (let x = 0; x < this.constants.inputWidth; x++) {
                const input = inputs[z][y][x];
                if (input > maxInput) {
                    maxInput = input;
                }
            }
        }
    }
    return maxInput;
}
function getSum2D(inputs) {
    let sum = 0;
    for (let y = 0; y < this.constants.inputHeight; y++) {
        for (let x = 0; x < this.constants.inputWidth; x++) {
            sum += inputs[y][x];
        }
    }
    return sum;
}
function getSum3D(inputs) {
    let sum = 0;
    for (let z = 0; z < this.constants.inputDepth; z++) {
        for (let y = 0; y < this.constants.inputHeight; y++) {
            for (let x = 0; x < this.constants.inputWidth; x++) {
                sum += inputs[z][y][x];
            }
        }
    }
    return sum;
}
function getExponentials(inputs, maxInput) {
    return Math.exp(inputs[this.thread.x] - maxInput[0]);
}
function getExponentials3D(inputs, maxInput) {
    return Math.exp(inputs[this.thread.z][this.thread.y][this.thread.x] - maxInput[0]);
}
function predict2D(exponentials, exponentialsSum) {
    return exponentials[this.thread.y][this.thread.x] / exponentialsSum[0];
}
function predict3D(exponentials, exponentialsSum) {
    return (exponentials[this.thread.z][this.thread.y][this.thread.x] /
        exponentialsSum[0]);
}
function compare2D(target, exponentials) {
    let indicator = 0;
    const index = this.thread.x + this.thread.y * this.output.x;
    if (index === target) {
        indicator = 1;
    }
    return -(indicator - exponentials[this.thread.y][this.thread.x]);
}
function compare3D(target, exponentials) {
    let indicator = 0;
    const index = this.thread.x +
        this.thread.y * this.output.x +
        this.thread.z * this.output.x * this.output.y;
    if (index === target) {
        indicator = 1;
    }
    return -(indicator - exponentials[this.thread.z][this.thread.y][this.thread.x]);
}
// TODO: handle: `return -Math.log(this.es[y]);` in learn
class SoftMax extends Modifier {
    constructor(inputLayer, settings) {
        super(inputLayer, settings);
        this.errors = null;
        this.getExponentialsKernel = null;
        this.getMaxValueKernel = null;
        this.getSumKernel = null;
        this.validate();
        if (this.depth > 0) {
            this.weights = randos3D(this.width, this.height, this.depth);
            this.deltas = zeros3D(this.width, this.height, this.depth);
        }
        else if (this.height > 0) {
            this.weights = randos2D(this.width, this.height);
            this.deltas = zeros2D(this.width, this.height);
        }
        else {
            this.weights = randos(this.width);
            this.deltas = zeros$1(this.width);
        }
    }
    setupKernels() {
        const { width, height, depth } = this;
        if (depth > 0) {
            this.getExponentialsKernel = makeKernel(getExponentials3D, {
                output: [width, height, depth],
            });
            this.getMaxValueKernel = makeKernel(getMaxValue3D, {
                output: [1, 1, 1],
                constants: {
                    inputWidth: width,
                    inputHeight: height,
                    inputDepth: depth,
                },
            });
            this.getSumKernel = makeKernel(getSum3D, {
                output: [1, 1, 1],
                constants: {
                    inputWidth: width,
                    inputHeight: height,
                    inputDepth: depth,
                },
            });
            this.predictKernel = makeKernel(predict3D, {
                output: [width, height, depth],
            });
            this.compareKernel = makeKernel(compare3D, {
                output: [width, height, depth],
                immutable: true,
            });
        }
        else {
            this.getExponentialsKernel = makeKernel(getExponentials, {
                output: [width, height],
            });
            this.getMaxValueKernel = makeKernel(getMaxValue2D, {
                output: [1, 1],
                constants: {
                    inputWidth: width,
                    inputHeight: height,
                },
            });
            this.getSumKernel = makeKernel(getSum2D, {
                output: [1, 1],
                constants: {
                    inputWidth: width,
                    inputHeight: height,
                },
            });
            this.predictKernel = makeKernel(predict2D, {
                output: [width, height],
            });
            this.compareKernel = makeKernel(compare2D, {
                output: [width, height],
                immutable: true,
            });
        }
    }
    predict() {
        const maxValue = this.getMaxValueKernel(this.inputLayer.weights);
        const exponentials = this.getExponentialsKernel(this.inputLayer.weights, maxValue);
        const exponentialsSum = this.getSumKernel(exponentials);
        this.weights = this.predictKernel(exponentials, exponentialsSum);
    }
    compare(targetValues) {
        const { deltas, errors } = this;
        this.errors = this.compareKernel(targetValues[0], deltas);
        this.deltas = clone(this.errors);
        release(deltas);
        release(errors);
        const inputLayerDeltas = this.inputLayer.deltas;
        this.inputLayer.deltas = clone(this.deltas);
        release(inputLayerDeltas);
    }
}
function softMax(inputLayer, settings) {
    return new SoftMax(inputLayer, settings);
}

class SVM extends BaseLayer {
    constructor(inputLayer, settings) {
        super(settings);
        this.inputLayer = inputLayer;
    }
    predict() {
        release(this.weights);
        this.weights = clone(this.inputLayer.weights);
        this.validate();
    }
    learn() {
        // throw new Error(`${this.constructor.name}-learn is not yet implemented`)
    }
}
// function learn(target) {
//   if (y === i) {
//     continue;
//   }
//   const ydiff = -yscore + x.w[i] + margin;
//   if (ydiff > 0) {
//     // violating dimension, apply loss
//     x.dw[i] += 1;
//     x.dw[y] -= 1;
//     loss += ydiff;
//   }
// }
function svm(inputLayer, settings) {
    return new SVM(inputLayer, settings);
}

function predict(value) {
    return value[this.thread.x][this.thread.y];
}
const compare = predict;
class Transpose extends Modifier {
    get width() {
        return this.inputLayer.height;
    }
    get height() {
        return this.inputLayer.width;
    }
    constructor(inputLayer) {
        super(inputLayer);
        this.validate();
    }
    setupKernels() {
        this.predictKernel = makeKernel(predict, {
            output: [this.height, this.width],
        });
        this.compareKernel = makeKernel(compare, {
            output: [this.width, this.height],
        });
    }
    predict() {
        this.weights = this.predictKernel(this.inputLayer.weights);
        clear(this.deltas);
    }
    compare() {
        this.inputLayer.deltas = this.compareKernel(this.deltas);
    }
}
function transpose(inputLayer) {
    return new Transpose(inputLayer);
}

const layerTypes = {
    Activation,
    Internal,
    InternalModel,
    EntryPoint,
    Filter,
    Model,
    Modifier,
    Operator,
    Target,
};

var layer = /*#__PURE__*/Object.freeze({
    __proto__: null,
    layerTypes: layerTypes,
    Add: Add,
    add: add$1,
    arthurFeedForward: arthurFeedForward,
    BaseLayer: BaseLayer,
    baseLayerDefaultSettings: baseLayerDefaultSettings,
    Convolution: Convolution,
    convolution: convolution,
    Dropout: Dropout,
    dropout: dropout,
    feedForward: feedForward,
    FullyConnected: FullyConnected,
    fullyConnected: fullyConnected,
    gru: gru,
    Input: Input,
    input: input,
    LeakyRelu: LeakyRelu,
    leakyRelu: leakyRelu,
    lstmCell: lstmCell,
    Multiply: Multiply,
    multiply: multiply$1,
    MultiplyElement: MultiplyElement,
    multiplyElement: multiplyElement$1,
    Negative: Negative,
    negative: negative,
    Ones: Ones,
    ones: ones,
    output: output,
    Pool: Pool,
    pool: pool,
    Random: Random,
    random: random,
    RecurrentInput: RecurrentInput,
    RecurrentZeros: RecurrentZeros,
    rnnCell: rnnCell,
    Regression: Regression,
    regression: regression,
    Relu: Relu,
    relu: relu$1,
    Sigmoid: Sigmoid,
    sigmoid: sigmoid$1,
    SoftMax: SoftMax,
    softMax: softMax,
    SVM: SVM,
    svm: svm,
    Tanh: Tanh,
    tanh: tanh$1,
    Target: Target,
    target: target,
    Transpose: Transpose,
    transpose: transpose,
    Zeros: Zeros,
    zeros: zeros
});

const layerNameTypes = Object.keys(layer);
function layerFromJSON(jsonLayer, inputLayer1, inputLayer2) {
    if (!layerNameTypes.find((layerNameType) => layerNameType === jsonLayer.type)) {
        return null;
    }
    const Layer = layer[jsonLayer.type];
    if (Layer.prototype instanceof layerTypes.Filter) {
        if (!inputLayer1)
            throw new Error('inputLayer missing');
        return new Layer(jsonLayer, inputLayer1);
    }
    else if (Layer.prototype instanceof layerTypes.Activation ||
        Layer.prototype instanceof layerTypes.Modifier) {
        if (!inputLayer1)
            throw new Error('inputLayer missing');
        return new Layer(inputLayer1, jsonLayer);
    }
    else if (Layer.prototype instanceof layerTypes.Internal) {
        return new Layer(jsonLayer);
    }
    else if (Layer.prototype instanceof layerTypes.Operator) {
        if (!inputLayer1)
            throw new Error('inputLayer1 missing');
        if (!inputLayer2)
            throw new Error('inputLayer2 missing');
        return new Layer(inputLayer1, inputLayer2, jsonLayer);
    }
    else if (Layer.prototype instanceof layerTypes.InternalModel ||
        Layer.prototype instanceof layerTypes.EntryPoint ||
        Layer.prototype instanceof layerTypes.Model) {
        return new Layer(jsonLayer);
    }
    else if (Layer === Target) {
        if (!inputLayer1)
            throw new Error('inputLayer missing');
        return new Layer(jsonLayer, inputLayer1);
    }
    return null;
}

class LookupTable {
    constructor(data, prop) {
        this.prop = null;
        this.table = {};
        this.length = 0;
        const table = this.table;
        if (prop) {
            this.prop = prop;
            for (let i = 0; i < data.length; i++) {
                const datum = data[i];
                const object = datum[prop];
                for (const p in object) {
                    if (!object.hasOwnProperty(p))
                        continue;
                    if (table.hasOwnProperty(p))
                        continue;
                    table[p] = this.length++;
                }
            }
        }
        else if (Array.isArray(data) && Array.isArray(data[0])) {
            for (let i = 0; i < data.length; i++) {
                const array = data[i];
                for (let j = 0; j < array.length; j++) {
                    const object = array[j];
                    for (const p in object) {
                        if (!object.hasOwnProperty(p))
                            continue;
                        if (table.hasOwnProperty(p))
                            continue;
                        table[p] = this.length++;
                    }
                }
            }
        }
        else {
            for (let i = 0; i < data.length; i++) {
                const object = data[i];
                for (const p in object) {
                    if (!object.hasOwnProperty(p))
                        continue;
                    if (table.hasOwnProperty(p))
                        continue;
                    table[p] = this.length++;
                }
            }
        }
    }
}

const defaults$3 = {
    learningRate: 0.3,
    binaryThresh: 0.5,
    initPraxis: (layerTemplate, settings) => {
        var _a;
        return momentumRootMeanSquaredPropagation(layerTemplate, (_a = layerTemplate.settings.praxisOpts) !== null && _a !== void 0 ? _a : settings);
    },
};
const trainDefaults$3 = {
    iterations: 20000,
    errorThresh: 0.005,
    log: false,
    logPeriod: 10,
    learningRate: 0.3,
    callbackPeriod: 10,
    errorCheckInterval: 100,
    timeout: Infinity,
};
class FeedForward {
    constructor(options = {}) {
        this.trainOpts = {};
        this.layers = null;
        this._inputLayer = null;
        this._hiddenLayers = null;
        this._outputLayer = null;
        this._model = null;
        this.meanSquaredError = null;
        this.inputLookup = null;
        this.inputLookupLength = null;
        this.outputLookup = null;
        this.outputLookupLength = null;
        this.options = { ...defaults$3, ...options };
        this._updateTrainingOptions({
            ...trainDefaults$3,
            ...options,
        });
    }
    static _validateTrainingOptions(options) {
        const { iterations, errorThresh, log, logPeriod, learningRate, callback, callbackPeriod, timeout, } = options;
        const validations = {
            iterations: () => typeof iterations === 'number' && iterations > 0,
            errorThresh: () => typeof errorThresh === 'number' && errorThresh > 0 && errorThresh < 1,
            log: () => typeof log === 'function' || typeof log === 'boolean',
            logPeriod: () => typeof logPeriod === 'number' && logPeriod > 0,
            learningRate: () => typeof learningRate === 'number' &&
                learningRate > 0 &&
                learningRate < 1,
            callback: () => typeof callback === 'function' || callback === null,
            callbackPeriod: () => typeof callbackPeriod === 'number' && callbackPeriod > 0,
            timeout: () => typeof timeout === 'number' && timeout > 0,
        };
        Object.keys(trainDefaults$3).forEach((key) => {
            if (validations.hasOwnProperty(key) && !validations[key]()) {
                const val = options[key];
                throw new Error(`[${key}, ${(val !== null && val !== void 0 ? val : 'undefined').toString()}] is out of normal training range, your network will probably not train.`);
            }
        });
    }
    /**
     * if a method is passed in method is used
     * if false passed in nothing is logged
     */
    _setLogMethod(log) {
        if (typeof log === 'function') {
            this.trainOpts.log = log;
        }
        else if (log) {
            // eslint-disable-next-line
            this.trainOpts.log = console.log;
        }
        else {
            this.trainOpts.log = false;
        }
    }
    _updateTrainingOptions(opts) {
        var _a;
        this.trainOpts = { ...trainDefaults$3, ...this.trainOpts, ...opts };
        FeedForward._validateTrainingOptions(this.trainOpts);
        this._setLogMethod((_a = opts.log) !== null && _a !== void 0 ? _a : this.trainOpts.log);
        const { callback, callbackPeriod, errorCheckInterval } = this.trainOpts;
        if (callback && callbackPeriod !== errorCheckInterval) {
            console.warn(`options.callbackPeriod with value of ${(callbackPeriod !== null && callbackPeriod !== void 0 ? callbackPeriod : 'undefined').toString()} does not match options.errorCheckInterval with value of ${(errorCheckInterval !== null && errorCheckInterval !== void 0 ? errorCheckInterval : 'undefined').toString()}, if logging error, it will repeat.  These values may need to match`);
        }
    }
    _connectOptionsLayers() {
        const { inputLayerIndex, outputLayerIndex, layers } = this.options;
        if (!layers)
            throw new Error('this.options.layers in unexpected state');
        if (typeof inputLayerIndex !== 'number')
            throw new Error('inputLayerIndex not a number');
        if (typeof outputLayerIndex !== 'number')
            throw new Error('inputLayerIndex not a number');
        const inputLayer = layers[inputLayerIndex];
        if (!inputLayer) {
            throw new Error('inputLayer not found in this.options.layers');
        }
        const outputLayer = layers[outputLayerIndex];
        if (!outputLayer) {
            throw new Error('outputLayer not found in this.options.layers');
        }
        this._inputLayer = inputLayer;
        this._hiddenLayers = layers.slice(inputLayerIndex, outputLayerIndex - inputLayerIndex);
        this._outputLayer = outputLayer;
        return layers;
    }
    _connectNewLayers() {
        const { inputLayer, outputLayer } = this.options;
        if (!inputLayer)
            throw new Error('inputLayer not defined');
        const layers = [];
        this._inputLayer = inputLayer();
        const hiddenLayers = this._connectHiddenLayers(this._inputLayer);
        if (!outputLayer)
            throw new Error('outputLayer not defined');
        this._outputLayer = outputLayer(hiddenLayers[hiddenLayers.length - 1], hiddenLayers.length);
        layers.push(this._inputLayer);
        layers.push(...hiddenLayers);
        layers.push(this._outputLayer);
        return flattenLayers(layers);
    }
    _connectHiddenLayers(previousLayer) {
        this._hiddenLayers = [];
        const result = [];
        const { hiddenLayers } = this.options;
        if (!hiddenLayers)
            throw new Error('hiddenLayers not defined');
        for (let i = 0; i < hiddenLayers.length; i++) {
            const hiddenLayer = hiddenLayers[i](previousLayer, i);
            result.push(hiddenLayer);
            this._hiddenLayers.push(hiddenLayer);
            previousLayer = hiddenLayer;
        }
        return result;
    }
    initialize() {
        this.layers = this.options.layers
            ? this._connectOptionsLayers()
            : this._connectNewLayers();
        this.initializeLayers(this.layers);
        this._model = this.layers.filter((l) => l instanceof Model);
    }
    initializeLayers(layers) {
        var _a, _b;
        for (let i = 0; i < layers.length; i++) {
            const layer = layers[i];
            // TODO: optimize for when training or just running
            layer.setupKernels(true);
            if (layer instanceof Model &&
                layer.praxis === null &&
                typeof this.options.initPraxis === 'function') {
                layer.praxis = this.options.initPraxis(layer, (_b = (_a = layer.settings.praxisOpts) !== null && _a !== void 0 ? _a : this.options.praxisOpts) !== null && _b !== void 0 ? _b : {});
                layer.praxis.setupKernels();
            }
        }
        const lastLayer = layers[layers.length - 1];
        this.meanSquaredError = new MeanSquaredError({
            width: lastLayer.width,
            height: lastLayer.height,
        });
    }
    run(input) {
        let typeSafeInput;
        if (Array.isArray(input) || input.buffer) {
            typeSafeInput = input;
        }
        else {
            if (this.inputLookup) {
                typeSafeInput = lookup.toArray(this.inputLookup, input, this.inputLookupLength);
            }
            else {
                throw new Error('input is incompatible with net');
            }
        }
        let output = this.runInput(typeSafeInput);
        if (output instanceof gpu_js.Texture) {
            output = output.toArray();
        }
        if (this.outputLookup) {
            return lookup.toObject(this.outputLookup, output);
        }
        return output;
    }
    runInput(input) {
        if (!this.layers)
            throw new Error('not initialized');
        this.layers[0].predict(input);
        for (let i = 1; i < this.layers.length; i++) {
            this.layers[i].predict();
        }
        return this.layers[this.layers.length - 1].weights;
    }
    train(data, options = {}) {
        const { preparedData, status, endTime } = this._prepTraining(data, options);
        let continueTicking = true;
        const calculateError = () => this._calculateTrainingError(preparedData);
        const trainPatters = () => this._trainPatterns(preparedData);
        while (continueTicking) {
            continueTicking = this._trainingTick(status, endTime, calculateError, trainPatters);
        }
        return status;
    }
    _trainingTick(status, endTime, calculateError, trainPatterns) {
        const { trainOpts } = this;
        if (status.iterations >= trainOpts.iterations ||
            status.error <= trainOpts.errorThresh ||
            Date.now() >= endTime) {
            return false;
        }
        if (typeof trainOpts.log === 'function' &&
            status.iterations % trainOpts.logPeriod === 0) {
            status.error = calculateError();
            trainOpts.log(`iterations: ${status.iterations}, training error: ${status.error}`);
        }
        else if (status.iterations % trainOpts.errorCheckInterval ===
            0) {
            status.error = calculateError();
        }
        else {
            trainPatterns();
        }
        if (trainOpts.callback &&
            status.iterations % trainOpts.callbackPeriod === 0) {
            trainOpts.callback(Object.assign(status));
        }
        status.iterations++;
        return true;
    }
    _prepTraining(data, options) {
        this._updateTrainingOptions(options);
        const formattedData = this.formatData(data);
        const endTime = this.trainOpts.timeout
            ? Date.now() + this.trainOpts.timeout
            : 0;
        const status = {
            error: 1,
            iterations: 0,
        };
        this.verifyIsInitialized();
        return {
            preparedData: this.transferData(formattedData),
            status,
            endTime,
        };
    }
    verifyIsInitialized() {
        if (!this._model) {
            this.initialize();
        }
    }
    _calculateTrainingError(preparedData) {
        let sum = new Float32Array([0]);
        const meanSquaredError = this.meanSquaredError;
        for (let i = 0; i < preparedData.length; ++i) {
            const prevSum = sum;
            const error = this._trainPattern(preparedData[i].input, preparedData[i].output, true);
            sum = meanSquaredError.add(sum, error);
            release(error);
            release(prevSum);
        }
        const result = meanSquaredError.divide(preparedData.length, sum);
        release(sum);
        if (result instanceof gpu_js.Texture) {
            const resultArray = result.toArray();
            release(result);
            return resultArray[0];
        }
        return result[0];
    }
    /**
     * @param data
     * @private
     */
    _trainPatterns(data) {
        for (let i = 0; i < data.length; ++i) {
            this._trainPattern(data[i].input, data[i].output, false);
        }
    }
    _trainPattern(input, target, logErrorRate) {
        var _a;
        // forward propagate
        this.runInput(input);
        // back propagate
        this._calculateDeltas(target);
        this.adjustWeights();
        if (logErrorRate) {
            if (!((_a = this._outputLayer) === null || _a === void 0 ? void 0 : _a.errors)) {
                throw new Error('outputLayer.errors not defined');
            }
            return this.meanSquaredError.calculate(this._outputLayer.errors);
        }
        return null;
    }
    _calculateDeltas(target) {
        const layers = this.layers;
        for (let i = layers.length - 1; i > -1; i--) {
            layers[i].compare(target);
        }
    }
    /**
     *
     */
    adjustWeights() {
        const _model = this._model;
        for (let i = 0; i < _model.length; i++) {
            _model[i].learn(this.trainOpts.learningRate);
        }
    }
    /**
     *
     * @param data
     * @returns {*}
     */
    formatData(data) {
        if (!Array.isArray(data)) {
            // turn stream datum into array
            const tmp = [];
            tmp.push(data);
            data = tmp;
        }
        // turn sparse hash input into arrays with 0s as filler
        const inputDatumCheck = data[0].input;
        let formattedData;
        if (Array.isArray(data) &&
            !Array.isArray(inputDatumCheck) &&
            !(inputDatumCheck instanceof Float32Array)) {
            if (!this.inputLookup) {
                const lookupTable = new LookupTable(data, 'input');
                this.inputLookup = lookupTable.table;
                this.inputLookupLength = lookupTable.length;
            }
            formattedData = data.map((datumParam) => {
                const array = lookup.toArray(this.inputLookup, datumParam.input, this.inputLookupLength);
                return { input: array };
            }, this);
        }
        else {
            formattedData = data;
        }
        const outputDatumCheck = data[0].output;
        if (!Array.isArray(outputDatumCheck) &&
            !(outputDatumCheck instanceof Float32Array)) {
            if (!this.outputLookup) {
                const lookupTable = new LookupTable(data, 'output');
                this.outputLookup = lookupTable.table;
                this.outputLookupLength = lookupTable.length;
            }
            formattedData = data.map((datumParam, index) => {
                const array = lookup.toArray(this.outputLookup, datumParam.output, this.inputLookupLength);
                return {
                    input: formattedData[index].input,
                    output: array,
                };
            }, this);
        }
        return formattedData;
    }
    transferData(formattedData) {
        const transferredData = new Array(formattedData.length);
        const transferInput = makeKernel(function (value) {
            return value[this.thread.x];
        }, {
            output: [formattedData[0].input.length],
            immutable: true,
        });
        const transferOutput = makeKernel(function (value) {
            return value[this.thread.x];
        }, {
            output: [formattedData[0].output.length],
            immutable: true,
        });
        for (let i = 0; i < formattedData.length; i++) {
            const formattedDatum = formattedData[i];
            transferredData[i] = {
                input: transferInput(formattedDatum.input),
                output: transferOutput(formattedDatum.output),
            };
        }
        return transferredData;
    }
    /**
     *
     * @param data
     * @returns {
     *  {
     *    error: number,
     *    misclasses: Array
     *  }
     * }
     */
    test() {
        throw new Error(`${this.constructor.name}-test is not yet implemented`);
    }
    /**
     *
     */
    toJSON() {
        var _a;
        if (!this.layers) {
            this.initialize();
        }
        if (!this._model ||
            !this.layers ||
            !this._inputLayer ||
            !this._hiddenLayers ||
            !this._outputLayer) {
            throw new Error('network is not initialized');
        }
        const jsonLayers = [];
        for (let i = 0; i < this.layers.length; i++) {
            const layer = this.layers[i];
            const jsonLayer = layer.toJSON();
            if (layer.hasOwnProperty('inputLayer')) {
                jsonLayer.inputLayerIndex = this.layers.indexOf(layer.inputLayer);
            }
            else if (layer.hasOwnProperty('inputLayer1') &&
                layer.hasOwnProperty('inputLayer2')) {
                jsonLayer.inputLayer1Index = this.layers.indexOf(layer.inputLayer1);
                jsonLayer.inputLayer2Index = this.layers.indexOf(layer.inputLayer2);
            }
            jsonLayers.push(jsonLayer);
        }
        return {
            type: this.constructor.name,
            sizes: (_a = this.options.sizes) !== null && _a !== void 0 ? _a : [this._inputLayer.height]
                .concat(this._hiddenLayers.map((l) => l.height))
                .concat([this._outputLayer.height]),
            outputLayerIndex: this.layers.indexOf(this._outputLayer),
            layers: jsonLayers,
            inputLayerIndex: this.layers.indexOf(this._inputLayer),
        };
    }
    static fromJSON(json, getLayer) {
        var _a, _b, _c, _d;
        const jsonLayers = json.layers;
        const layers = [];
        const inputLayer = getLayer
            ? (_a = layerFromJSON(jsonLayers[0])) !== null && _a !== void 0 ? _a : getLayer(jsonLayers[0]) : layerFromJSON(jsonLayers[0]);
        if (!inputLayer)
            throw new Error('unable to find layer');
        layers.push(inputLayer);
        for (let i = 1; i < jsonLayers.length; i++) {
            const jsonLayer = jsonLayers[i];
            if (typeof jsonLayer.inputLayerIndex === 'undefined' &&
                typeof jsonLayer.inputLayer1Index === 'undefined' &&
                typeof jsonLayer.inputLayer2Index === 'undefined') {
                const layer = getLayer
                    ? (_b = layerFromJSON(jsonLayer)) !== null && _b !== void 0 ? _b : getLayer(jsonLayer) : layerFromJSON(jsonLayer);
                if (!layer)
                    throw new Error('unable to find layer');
                layers.push(layer);
            }
            else if (typeof jsonLayer.inputLayerIndex === 'number') {
                const inputLayer = layers[jsonLayer.inputLayerIndex];
                if (!inputLayer) {
                    throw new Error('inputLayer1 not found');
                }
                const layer = getLayer
                    ? (_c = layerFromJSON(jsonLayer, inputLayer)) !== null && _c !== void 0 ? _c : getLayer(jsonLayer, inputLayer) : layerFromJSON(jsonLayer, inputLayer);
                if (!layer)
                    throw new Error('unable to find layer');
                layers.push(layer);
            }
            else {
                if (typeof jsonLayer.inputLayer1Index !== 'number') {
                    throw new Error('Cannot create network from provided JSON. inputLayer1Index not defined.');
                }
                if (typeof jsonLayer.inputLayer2Index !== 'number') {
                    throw new Error('Cannot create network from provided JSON. inputLayer2Index not defined.');
                }
                const inputLayer1 = layers[jsonLayer.inputLayer1Index];
                const inputLayer2 = layers[jsonLayer.inputLayer2Index];
                if (inputLayer1 === undefined)
                    throw new Error(`Cannot create network from provided JSON. layer of index ${jsonLayer.inputLayer1Index} not found.`);
                if (inputLayer2 === undefined)
                    throw new Error(`Cannot create network from provided JSON. layer of index ${jsonLayer.inputLayer2Index} not found.`);
                const layer = getLayer
                    ? (_d = layerFromJSON(jsonLayer, inputLayer1, inputLayer2)) !== null && _d !== void 0 ? _d : getLayer(jsonLayer, inputLayer1, inputLayer2) : layerFromJSON(jsonLayer, inputLayer1, inputLayer2);
                if (!layer)
                    throw new Error('unable to find layer');
                layers.push(layer);
            }
        }
        return new this({ ...json, layers });
    }
    /**
     *
     * @returns {Function}
     */
    toFunction() {
        throw new Error(`${this.constructor.name}-toFunction is not yet implemented`);
    }
    /**
     * This will create a TrainStream (WriteStream) for us to send the training data to.
     * @param opts training options
     * @returns {TrainStream|*}
     */
    createTrainStream() {
        throw new Error(`${this.constructor.name}-createTrainStream is not yet implemented`);
    }
}

function likely(input, net) {
    if (!net) {
        throw new TypeError(`Required parameter 'net' is of type ${typeof net}. Must be of type 'brain.NeuralNetwork'`);
    }
    const output = net.run(input);
    let maxProp = null;
    let maxValue = -1;
    Object.entries(output).forEach(([key, value]) => {
        if (typeof value !== 'undefined' &&
            typeof value === 'number' &&
            value > maxValue) {
            maxProp = key;
            maxValue = value;
        }
    });
    return maxProp;
}

var commonjsGlobal = typeof globalThis !== 'undefined' ? globalThis : typeof window !== 'undefined' ? window : typeof global !== 'undefined' ? global : typeof self !== 'undefined' ? self : {};

function createCommonjsModule(fn, basedir, module) {
	return module = {
		path: basedir,
		exports: {},
		require: function (path, base) {
			return commonjsRequire(path, (base === undefined || base === null) ? module.path : base);
		}
	}, fn(module, module.exports), module.exports;
}

function commonjsRequire () {
	throw new Error('Dynamic requires are not currently supported by @rollup/plugin-commonjs');
}

var thaw_1 = createCommonjsModule(function (module, exports) {
var __assign = (commonjsGlobal && commonjsGlobal.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.thaw = exports.Thaw = void 0;
/**
 * thaw an array of items
 */
var Thaw = /** @class */ (function () {
    function Thaw(items, options) {
        var _this = this;
        if (options === void 0) { options = {}; }
        var _a = __assign(__assign({}, Thaw.defaultSettings), options), each = _a.each, done = _a.done;
        this.i = 0;
        this.isStopped = false;
        this.items = items;
        this.options = options;
        this.tick = function () {
            if (_this.isStopped)
                return;
            _this.timeout = setTimeout(_this.tick, 0);
            if (Thaw.thawing)
                return;
            var item = _this.items[_this.i];
            if (_this.i >= _this.items.length) {
                if (done !== null) {
                    Thaw.thawing = true;
                    done();
                    Thaw.thawing = false;
                }
                _this.isStopped = true;
                clearTimeout(_this.timeout);
                return;
            }
            if (each !== null) {
                Thaw.thawing = true;
                each(item, _this.i);
                Thaw.thawing = false;
            }
            else if (item !== undefined) {
                item();
            }
            _this.i++;
        };
        Thaw.thaws.push(this);
        if (!options.delay) {
            this.tick();
        }
    }
    Object.defineProperty(Thaw, "isThawing", {
        /**
         * returns if Thaw.js is thawing
         */
        get: function () {
            return Thaw.thawing;
        },
        enumerable: false,
        configurable: true
    });
    /**
     * Stops all Thaw instances
     */
    Thaw.stopAll = function () {
        for (var i = 0; i < Thaw.thaws.length; i++) {
            Thaw.thaws[i].stop();
        }
    };
    /**
     * readies thaw to continue
     */
    Thaw.prototype.makeReady = function () {
        if (this.isStopped) {
            this.isStopped = false;
            return true;
        }
        return false;
    };
    /**
     * Adds an item to the end of this instance of Thaw and readies Thaw to process it
     */
    Thaw.prototype.add = function (item) {
        this.items.push(item);
        if (this.makeReady()) {
            this.tick();
        }
        return this;
    };
    /**
     * Inserts an item just after the current item being processed in Thaw and readies Thaw to process it
     */
    Thaw.prototype.insert = function (item) {
        this.items.splice(this.i, 0, item);
        if (this.makeReady()) {
            this.tick();
        }
        return this;
    };
    /**
     * Adds an Array to the end of this instance of Thaw and readies Thaw to process it
     */
    Thaw.prototype.addArray = function (items) {
        this.items = this.items.concat(items);
        if (this.makeReady()) {
            this.tick();
        }
        return this;
    };
    /**
     * Inserts an Array just after the current item being processed in Thaw and readies Thaw to process them
     */
    Thaw.prototype.insertArray = function (items) {
        var before = this.items.splice(0, this.i);
        var after = this.items;
        this.items = before.concat(items, after);
        if (this.makeReady()) {
            this.tick();
        }
        return this;
    };
    /**
     * Stops this instance of Thaw
     */
    Thaw.prototype.stop = function () {
        this.isStopped = true;
        clearTimeout(this.timeout);
        if (this.options.done) {
            this.options.done();
        }
        return this;
    };
    Thaw.thawing = false;
    Thaw.thaws = [];
    Thaw.defaultSettings = {
        each: null,
        done: null
    };
    return Thaw;
}());
exports.Thaw = Thaw;
/**
 * simple thaw
 */
function thaw(items, options) {
    return new Thaw(items, options);
}
exports.thaw = thaw;

});

var block = createCommonjsModule(function (module, exports) {
Object.defineProperty(exports, "__esModule", { value: true });
exports.Block = void 0;

var Block = /** @class */ (function () {
    function Block(options, count) {
        if (count === void 0) { count = 200; }
        this.index = 0;
        this.thaws = [];
        this.count = count;
        this.options = options;
    }
    /**
     * add an item to the end of items
     */
    Block.prototype.add = function (item) {
        var next = this.next();
        next.add(item);
        return this;
    };
    /**
     * add an Array to the end of items
     */
    Block.prototype.addArray = function (items) {
        var next = this.next();
        next.addArray(items);
        return this;
    };
    /**
     * insert an item into items @ current position
     */
    Block.prototype.insert = function (item) {
        var next = this.next();
        next.insert(item);
        return this;
    };
    /**
     * insert and array into items @ current position
     */
    Block.prototype.insertArray = function (items) {
        var next = this.next();
        next.insertArray(items);
        return this;
    };
    /**
     * Stops all thaws in this block
     */
    Block.prototype.stop = function () {
        for (var i = 0; i < this.thaws.length; i++) {
            this.thaws[i].stop();
        }
        return this;
    };
    /**
     * Get next available in block
     */
    Block.prototype.next = function () {
        var thaw;
        var thaws = this.thaws;
        if (thaws.length < this.count) {
            thaw = new thaw_1.Thaw([], this.options);
            thaws.push(thaw);
        }
        else {
            thaw = thaws[this.index] || null;
        }
        this.index++;
        if (this.index >= this.count) {
            this.index = 0;
        }
        return thaw;
    };
    return Block;
}());
exports.Block = Block;

});

var dist = createCommonjsModule(function (module, exports) {
Object.defineProperty(exports, "__esModule", { value: true });
exports.Block = exports.thaw = exports.Thaw = void 0;

Object.defineProperty(exports, "Thaw", { enumerable: true, get: function () { return thaw_1.Thaw; } });
Object.defineProperty(exports, "thaw", { enumerable: true, get: function () { return thaw_1.thaw; } });

Object.defineProperty(exports, "Block", { enumerable: true, get: function () { return block.Block; } });
if (typeof window !== 'undefined') {
    // @ts-ignore
    window.Thaw = thaw_1.Thaw;
    // @ts-ignore
    window.thaw = thaw_1.thaw;
    // @ts-ignore
    window.Thaw.Block = block.Block;
}

});

function arraysToFloat32Arrays(arrays) {
    const result = [];
    for (let i = 0; i < arrays.length; i++) {
        result.push(Float32Array.from(arrays[i]));
    }
    return result;
}
function inputOutputArraysToFloat32Arrays(input, output) {
    const result = [];
    for (let i = 0; i < input.length; i++) {
        result.push(Float32Array.from(input[i]));
    }
    for (let i = 0; i < output.length; i++) {
        result.push(Float32Array.from(output[i]));
    }
    return result;
}
function arrayToFloat32Arrays(array) {
    const result = [];
    for (let i = 0; i < array.length; i++) {
        result.push(Float32Array.from([array[i]]));
    }
    return result;
}
function inputOutputArrayToFloat32Arrays(input, output) {
    const result = [];
    for (let i = 0; i < input.length; i++) {
        result.push(Float32Array.from([input[i]]));
    }
    for (let i = 0; i < output.length; i++) {
        result.push(Float32Array.from([output[i]]));
    }
    return result;
}
function arrayToFloat32Array(array) {
    return Float32Array.from(array);
}
function inputOutputObjectsToFloat32Arrays(input, output, inputTable, outputTable, inputLength, outputLength) {
    const results = [];
    for (let i = 0; i < input.length; i++) {
        const object = input[i];
        const result = new Float32Array(inputLength);
        for (const p in object) {
            if (object.hasOwnProperty(p)) {
                result[inputTable[p]] = object[p];
            }
        }
        results.push(result);
    }
    for (let i = 0; i < output.length; i++) {
        const object = output[i];
        const result = new Float32Array(outputLength);
        for (const p in object) {
            if (object.hasOwnProperty(p)) {
                result[outputTable[p]] = object[p];
            }
        }
        results.push(result);
    }
    return results;
}
function objectToFloat32Arrays(object) {
    const result = [];
    for (const p in object) {
        if (!object.hasOwnProperty(p))
            continue;
        result.push(Float32Array.from([object[p]]));
    }
    return result;
}
function inputOutputObjectToFloat32Arrays(input, output) {
    const result = [];
    for (const p in input) {
        if (!input.hasOwnProperty(p))
            continue;
        result.push(Float32Array.from([input[p]]));
    }
    for (const p in output) {
        if (!output.hasOwnProperty(p))
            continue;
        result.push(Float32Array.from([output[p]]));
    }
    return result;
}
function objectToFloat32Array(object, table, length) {
    const result = new Float32Array(length);
    for (const p in object) {
        if (object.hasOwnProperty(p)) {
            result[table[p]] = object[p];
        }
    }
    return result;
}

function max(values) {
    if (Array.isArray(values) || values instanceof Float32Array) {
        return Math.max(...values);
    }
    else {
        return Math.max(...Object.values(values));
    }
}

function mse$1(errors) {
    // mean squared error
    let sum = 0;
    for (let i = 0; i < errors.length; i++) {
        sum += errors[i] ** 2;
    }
    return sum / errors.length;
}

function getTypedArrayFn(value, table) {
    if (value.buffer instanceof ArrayBuffer) {
        return null;
    }
    if (Array.isArray(value)) {
        return arrayToFloat32Array;
    }
    if (!table)
        throw new Error('table is not Object');
    const { length } = Object.keys(table);
    return (v) => {
        const array = new Float32Array(length);
        for (const p in table) {
            if (!table.hasOwnProperty(p))
                continue;
            array[table[p]] = v[p] || 0;
        }
        return array;
    };
}
function defaults$2() {
    return {
        inputSize: 0,
        outputSize: 0,
        binaryThresh: 0.5,
    };
}
function trainDefaults$2() {
    return {
        activation: 'sigmoid',
        iterations: 20000,
        errorThresh: 0.005,
        log: false,
        logPeriod: 10,
        leakyReluAlpha: 0.01,
        learningRate: 0.3,
        momentum: 0.1,
        callbackPeriod: 10,
        timeout: Infinity,
        beta1: 0.9,
        beta2: 0.999,
        epsilon: 1e-8,
    };
}
class NeuralNetwork {
    constructor(options = {}) {
        this.options = defaults$2();
        this.trainOpts = trainDefaults$2();
        this.sizes = [];
        this.outputLayer = -1;
        this.biases = [];
        this.weights = []; // weights for bias nodes
        this.outputs = [];
        // state for training
        this.deltas = [];
        this.changes = []; // for momentum
        this.errors = [];
        this.errorCheckInterval = 1;
        this.inputLookup = null;
        this.inputLookupLength = 0;
        this.outputLookup = null;
        this.outputLookupLength = 0;
        this._formatInput = null;
        this._formatOutput = null;
        this.runInput = (input) => {
            this.setActivation();
            return this.runInput(input);
        };
        this.calculateDeltas = (output) => {
            this.setActivation();
            return this.calculateDeltas(output);
        };
        // adam
        this.biasChangesLow = [];
        this.biasChangesHigh = [];
        this.changesLow = [];
        this.changesHigh = [];
        this.iterations = 0;
        this.options = { ...this.options, ...options };
        this.updateTrainingOptions(options);
        const { inputSize, hiddenLayers, outputSize } = this.options;
        if (inputSize && outputSize) {
            this.sizes = [inputSize].concat(hiddenLayers !== null && hiddenLayers !== void 0 ? hiddenLayers : []).concat([outputSize]);
        }
    }
    /**
     *
     * Expects this.sizes to have been set
     */
    initialize() {
        if (!this.sizes.length) {
            throw new Error('Sizes must be set before initializing');
        }
        this.outputLayer = this.sizes.length - 1;
        this.biases = new Array(this.outputLayer); // weights for bias nodes
        this.weights = new Array(this.outputLayer);
        this.outputs = new Array(this.outputLayer);
        // state for training
        this.deltas = new Array(this.outputLayer);
        this.changes = new Array(this.outputLayer); // for momentum
        this.errors = new Array(this.outputLayer);
        for (let layerIndex = 0; layerIndex <= this.outputLayer; layerIndex++) {
            const size = this.sizes[layerIndex];
            this.deltas[layerIndex] = zeros$1(size);
            this.errors[layerIndex] = zeros$1(size);
            this.outputs[layerIndex] = zeros$1(size);
            if (layerIndex > 0) {
                this.biases[layerIndex] = randos(size);
                this.weights[layerIndex] = new Array(size);
                this.changes[layerIndex] = new Array(size);
                for (let nodeIndex = 0; nodeIndex < size; nodeIndex++) {
                    const prevSize = this.sizes[layerIndex - 1];
                    this.weights[layerIndex][nodeIndex] = randos(prevSize);
                    this.changes[layerIndex][nodeIndex] = zeros$1(prevSize);
                }
            }
        }
        this.setActivation();
        if (this.trainOpts.praxis === 'adam') {
            this._setupAdam();
        }
    }
    setActivation(activation) {
        const value = activation !== null && activation !== void 0 ? activation : this.trainOpts.activation;
        switch (value) {
            case 'sigmoid':
                this.runInput = this._runInputSigmoid;
                this.calculateDeltas = this._calculateDeltasSigmoid;
                break;
            case 'relu':
                this.runInput = this._runInputRelu;
                this.calculateDeltas = this._calculateDeltasRelu;
                break;
            case 'leaky-relu':
                this.runInput = this._runInputLeakyRelu;
                this.calculateDeltas = this._calculateDeltasLeakyRelu;
                break;
            case 'tanh':
                this.runInput = this._runInputTanh;
                this.calculateDeltas = this._calculateDeltasTanh;
                break;
            default:
                throw new Error(`Unknown activation ${value}. Available activations are: 'sigmoid', 'relu', 'leaky-relu', 'tanh'`);
        }
    }
    get isRunnable() {
        return this.sizes.length > 0;
    }
    run(input) {
        if (!this.isRunnable) {
            throw new Error('network not runnable');
        }
        let formattedInput;
        if (this.inputLookup) {
            formattedInput = lookup.toArray(this.inputLookup, input, this.inputLookupLength);
        }
        else {
            formattedInput = input;
        }
        if (formattedInput.length !== this.sizes[0]) {
            throw new Error(`input is not in correct length of ${this.sizes[0]}`);
        }
        const output = this.runInput(formattedInput).slice(0);
        if (this.outputLookup) {
            return lookup.toObject(this.outputLookup, output);
        }
        return output;
    }
    _runInputSigmoid(input) {
        this.outputs[0] = input; // set output state of input layer
        let output = null;
        for (let layer = 1; layer <= this.outputLayer; layer++) {
            const activeLayer = this.sizes[layer];
            const activeWeights = this.weights[layer];
            const activeBiases = this.biases[layer];
            const activeOutputs = this.outputs[layer];
            for (let node = 0; node < activeLayer; node++) {
                const weights = activeWeights[node];
                let sum = activeBiases[node];
                for (let k = 0; k < weights.length; k++) {
                    sum += weights[k] * input[k];
                }
                // sigmoid
                activeOutputs[node] = 1 / (1 + Math.exp(-sum));
            }
            output = input = activeOutputs;
        }
        if (!output) {
            throw new Error('output was empty');
        }
        return output;
    }
    _runInputRelu(input) {
        this.outputs[0] = input; // set output state of input layer
        let output = null;
        for (let layer = 1; layer <= this.outputLayer; layer++) {
            const activeSize = this.sizes[layer];
            const activeWeights = this.weights[layer];
            const activeBiases = this.biases[layer];
            const activeOutputs = this.outputs[layer];
            for (let node = 0; node < activeSize; node++) {
                const weights = activeWeights[node];
                let sum = activeBiases[node];
                for (let k = 0; k < weights.length; k++) {
                    sum += weights[k] * input[k];
                }
                // relu
                activeOutputs[node] = sum < 0 ? 0 : sum;
            }
            output = input = activeOutputs;
        }
        if (!output) {
            throw new Error('output was empty');
        }
        return output;
    }
    _runInputLeakyRelu(input) {
        this.outputs[0] = input; // set output state of input layer
        const { leakyReluAlpha } = this.trainOpts;
        let output = null;
        for (let layer = 1; layer <= this.outputLayer; layer++) {
            const activeSize = this.sizes[layer];
            const activeWeights = this.weights[layer];
            const activeBiases = this.biases[layer];
            const activeOutputs = this.outputs[layer];
            for (let node = 0; node < activeSize; node++) {
                const weights = activeWeights[node];
                let sum = activeBiases[node];
                for (let k = 0; k < weights.length; k++) {
                    sum += weights[k] * input[k];
                }
                // leaky relu
                activeOutputs[node] = Math.max(sum, leakyReluAlpha * sum);
            }
            output = input = activeOutputs;
        }
        if (!output) {
            throw new Error('output was empty');
        }
        return output;
    }
    _runInputTanh(input) {
        this.outputs[0] = input; // set output state of input layer
        let output = null;
        for (let layer = 1; layer <= this.outputLayer; layer++) {
            const activeSize = this.sizes[layer];
            const activeWeights = this.weights[layer];
            const activeBiases = this.biases[layer];
            const activeOutputs = this.outputs[layer];
            for (let node = 0; node < activeSize; node++) {
                const weights = activeWeights[node];
                let sum = activeBiases[node];
                for (let k = 0; k < weights.length; k++) {
                    sum += weights[k] * input[k];
                }
                // tanh
                activeOutputs[node] = Math.tanh(sum);
            }
            output = input = activeOutputs;
        }
        if (!output) {
            throw new Error('output was empty');
        }
        return output;
    }
    /**
     *
     * Verifies network sizes are initialized
     * If they are not it will initialize them based off the data set.
     */
    verifyIsInitialized(preparedData) {
        if (this.sizes.length)
            return;
        this.sizes = [];
        this.sizes.push(preparedData[0].input.length);
        if (!this.options.hiddenLayers) {
            this.sizes.push(Math.max(3, Math.floor(preparedData[0].input.length / 2)));
        }
        else {
            this.options.hiddenLayers.forEach((size) => {
                this.sizes.push(size);
            });
        }
        this.sizes.push(preparedData[0].output.length);
        this.initialize();
    }
    updateTrainingOptions(trainOpts) {
        const merged = { ...this.trainOpts, ...trainOpts };
        this.validateTrainingOptions(merged);
        this.trainOpts = merged;
        this.setLogMethod(this.trainOpts.log);
    }
    validateTrainingOptions(options) {
        const validations = {
            activation: () => {
                return ['sigmoid', 'relu', 'leaky-relu', 'tanh'].includes(options.activation);
            },
            iterations: () => {
                const val = options.iterations;
                return typeof val === 'number' && val > 0;
            },
            errorThresh: () => {
                const val = options.errorThresh;
                return typeof val === 'number' && val > 0 && val < 1;
            },
            log: () => {
                const val = options.log;
                return typeof val === 'function' || typeof val === 'boolean';
            },
            logPeriod: () => {
                const val = options.logPeriod;
                return typeof val === 'number' && val > 0;
            },
            leakyReluAlpha: () => {
                const val = options.leakyReluAlpha;
                return typeof val === 'number' && val > 0 && val < 1;
            },
            learningRate: () => {
                const val = options.learningRate;
                return typeof val === 'number' && val > 0 && val < 1;
            },
            momentum: () => {
                const val = options.momentum;
                return typeof val === 'number' && val > 0 && val < 1;
            },
            callback: () => {
                const val = options.callback;
                return typeof val === 'function' || val === undefined;
            },
            callbackPeriod: () => {
                const val = options.callbackPeriod;
                return typeof val === 'number' && val > 0;
            },
            timeout: () => {
                const val = options.timeout;
                return typeof val === 'number' && val > 0;
            },
            praxis: () => {
                const val = options.praxis;
                return !val || val === 'adam';
            },
            beta1: () => {
                const val = options.beta1;
                return val > 0 && val < 1;
            },
            beta2: () => {
                const val = options.beta2;
                return val > 0 && val < 1;
            },
            epsilon: () => {
                const val = options.epsilon;
                return val > 0 && val < 1;
            },
        };
        for (const p in validations) {
            const v = options;
            if (!validations[p]()) {
                throw new Error(`[${p}, ${v[p]}] is out of normal training range, your network will probably not train.`);
            }
        }
    }
    /**
     *
     *  Gets JSON of trainOpts object
     *    NOTE: Activation is stored directly on JSON object and not in the training options
     */
    getTrainOptsJSON() {
        const { activation, iterations, errorThresh, log, logPeriod, leakyReluAlpha, learningRate, momentum, callbackPeriod, timeout, praxis, beta1, beta2, epsilon, } = this.trainOpts;
        return {
            activation,
            iterations,
            errorThresh,
            log: typeof log === 'function'
                ? true
                : typeof log === 'boolean'
                    ? log
                    : false,
            logPeriod,
            leakyReluAlpha,
            learningRate,
            momentum,
            callbackPeriod,
            timeout: timeout === Infinity ? 'Infinity' : timeout,
            praxis,
            beta1,
            beta2,
            epsilon,
        };
    }
    setLogMethod(log) {
        if (typeof log === 'function') {
            this.trainOpts.log = log;
        }
        else if (log) {
            this.trainOpts.log = this.logTrainingStatus;
        }
        else {
            this.trainOpts.log = false;
        }
    }
    logTrainingStatus(status) {
        console.log(`iterations: ${status.iterations}, training error: ${status.error}`);
    }
    calculateTrainingError(data) {
        let sum = 0;
        for (let i = 0; i < data.length; ++i) {
            sum += this.trainPattern(data[i], true);
        }
        return sum / data.length;
    }
    trainPatterns(data) {
        for (let i = 0; i < data.length; ++i) {
            this.trainPattern(data[i]);
        }
    }
    trainingTick(data, status, endTime) {
        const { callback, callbackPeriod, errorThresh, iterations, log, logPeriod, } = this.trainOpts;
        if (status.iterations >= iterations ||
            status.error <= errorThresh ||
            Date.now() >= endTime) {
            return false;
        }
        status.iterations++;
        if (log && status.iterations % logPeriod === 0) {
            status.error = this.calculateTrainingError(data);
            log(status);
        }
        else if (status.iterations % this.errorCheckInterval === 0) {
            status.error = this.calculateTrainingError(data);
        }
        else {
            this.trainPatterns(data);
        }
        if (callback && status.iterations % callbackPeriod === 0) {
            callback({
                iterations: status.iterations,
                error: status.error,
            });
        }
        return true;
    }
    prepTraining(data, options = {}) {
        this.updateTrainingOptions(options);
        const preparedData = this.formatData(data);
        const endTime = Date.now() + this.trainOpts.timeout;
        const status = {
            error: 1,
            iterations: 0,
        };
        this.verifyIsInitialized(preparedData);
        return {
            preparedData,
            status,
            endTime,
        };
    }
    train(data, options = {}) {
        const { preparedData, status, endTime } = this.prepTraining(data, options);
        while (true) {
            if (!this.trainingTick(preparedData, status, endTime)) {
                break;
            }
        }
        return status;
    }
    async trainAsync(data, options = {}) {
        const { preparedData, status, endTime } = this.prepTraining(data, options);
        return await new Promise((resolve, reject) => {
            try {
                const thawedTrain = new dist.Thaw(new Array(this.trainOpts.iterations), {
                    delay: true,
                    each: () => this.trainingTick(preparedData, status, endTime) ||
                        thawedTrain.stop(),
                    done: () => resolve(status),
                });
                thawedTrain.tick();
            }
            catch (trainError) {
                reject(trainError);
            }
        });
    }
    trainPattern(value, logErrorRate) {
        // forward propagate
        this.runInput(value.input);
        // back propagate
        this.calculateDeltas(value.output);
        this.adjustWeights();
        if (logErrorRate) {
            return mse$1(this.errors[this.outputLayer]);
        }
        return null;
    }
    _calculateDeltasSigmoid(target) {
        for (let layer = this.outputLayer; layer >= 0; layer--) {
            const activeSize = this.sizes[layer];
            const activeOutput = this.outputs[layer];
            const activeError = this.errors[layer];
            const activeDeltas = this.deltas[layer];
            const nextLayer = this.weights[layer + 1];
            for (let node = 0; node < activeSize; node++) {
                const output = activeOutput[node];
                let error = 0;
                if (layer === this.outputLayer) {
                    error = target[node] - output;
                }
                else {
                    const deltas = this.deltas[layer + 1];
                    for (let k = 0; k < deltas.length; k++) {
                        error += deltas[k] * nextLayer[k][node];
                    }
                }
                activeError[node] = error;
                activeDeltas[node] = error * output * (1 - output);
            }
        }
    }
    _calculateDeltasRelu(target) {
        for (let layer = this.outputLayer; layer >= 0; layer--) {
            const currentSize = this.sizes[layer];
            const currentOutputs = this.outputs[layer];
            const nextWeights = this.weights[layer + 1];
            const nextDeltas = this.deltas[layer + 1];
            const currentErrors = this.errors[layer];
            const currentDeltas = this.deltas[layer];
            for (let node = 0; node < currentSize; node++) {
                const output = currentOutputs[node];
                let error = 0;
                if (layer === this.outputLayer) {
                    error = target[node] - output;
                }
                else {
                    for (let k = 0; k < nextDeltas.length; k++) {
                        error += nextDeltas[k] * nextWeights[k][node];
                    }
                }
                currentErrors[node] = error;
                currentDeltas[node] = output > 0 ? error : 0;
            }
        }
    }
    _calculateDeltasLeakyRelu(target) {
        const alpha = this.trainOpts.leakyReluAlpha;
        for (let layer = this.outputLayer; layer >= 0; layer--) {
            const currentSize = this.sizes[layer];
            const currentOutputs = this.outputs[layer];
            const nextDeltas = this.deltas[layer + 1];
            const nextWeights = this.weights[layer + 1];
            const currentErrors = this.errors[layer];
            const currentDeltas = this.deltas[layer];
            for (let node = 0; node < currentSize; node++) {
                const output = currentOutputs[node];
                let error = 0;
                if (layer === this.outputLayer) {
                    error = target[node] - output;
                }
                else {
                    for (let k = 0; k < nextDeltas.length; k++) {
                        error += nextDeltas[k] * nextWeights[k][node];
                    }
                }
                currentErrors[node] = error;
                currentDeltas[node] = output > 0 ? error : alpha * error;
            }
        }
    }
    _calculateDeltasTanh(target) {
        for (let layer = this.outputLayer; layer >= 0; layer--) {
            const currentSize = this.sizes[layer];
            const currentOutputs = this.outputs[layer];
            const nextDeltas = this.deltas[layer + 1];
            const nextWeights = this.weights[layer + 1];
            const currentErrors = this.errors[layer];
            const currentDeltas = this.deltas[layer];
            for (let node = 0; node < currentSize; node++) {
                const output = currentOutputs[node];
                let error = 0;
                if (layer === this.outputLayer) {
                    error = target[node] - output;
                }
                else {
                    for (let k = 0; k < nextDeltas.length; k++) {
                        error += nextDeltas[k] * nextWeights[k][node];
                    }
                }
                currentErrors[node] = error;
                currentDeltas[node] = (1 - output * output) * error;
            }
        }
    }
    /**
     *
     * Changes weights of networks
     */
    adjustWeights() {
        const { learningRate, momentum } = this.trainOpts;
        for (let layer = 1; layer <= this.outputLayer; layer++) {
            const incoming = this.outputs[layer - 1];
            const activeSize = this.sizes[layer];
            const activeDelta = this.deltas[layer];
            const activeChanges = this.changes[layer];
            const activeWeights = this.weights[layer];
            const activeBiases = this.biases[layer];
            for (let node = 0; node < activeSize; node++) {
                const delta = activeDelta[node];
                for (let k = 0; k < incoming.length; k++) {
                    let change = activeChanges[node][k];
                    change = learningRate * delta * incoming[k] + momentum * change;
                    activeChanges[node][k] = change;
                    activeWeights[node][k] += change;
                }
                activeBiases[node] += learningRate * delta;
            }
        }
    }
    _setupAdam() {
        this.biasChangesLow = [];
        this.biasChangesHigh = [];
        this.changesLow = [];
        this.changesHigh = [];
        this.iterations = 0;
        for (let layer = 0; layer <= this.outputLayer; layer++) {
            const size = this.sizes[layer];
            if (layer > 0) {
                this.biasChangesLow[layer] = zeros$1(size);
                this.biasChangesHigh[layer] = zeros$1(size);
                this.changesLow[layer] = new Array(size);
                this.changesHigh[layer] = new Array(size);
                for (let node = 0; node < size; node++) {
                    const prevSize = this.sizes[layer - 1];
                    this.changesLow[layer][node] = zeros$1(prevSize);
                    this.changesHigh[layer][node] = zeros$1(prevSize);
                }
            }
        }
        this.adjustWeights = this._adjustWeightsAdam;
    }
    _adjustWeightsAdam() {
        this.iterations++;
        const { iterations } = this;
        const { beta1, beta2, epsilon, learningRate } = this.trainOpts;
        for (let layer = 1; layer <= this.outputLayer; layer++) {
            const incoming = this.outputs[layer - 1];
            const currentSize = this.sizes[layer];
            const currentDeltas = this.deltas[layer];
            const currentChangesLow = this.changesLow[layer];
            const currentChangesHigh = this.changesHigh[layer];
            const currentWeights = this.weights[layer];
            const currentBiases = this.biases[layer];
            const currentBiasChangesLow = this.biasChangesLow[layer];
            const currentBiasChangesHigh = this.biasChangesHigh[layer];
            for (let node = 0; node < currentSize; node++) {
                const delta = currentDeltas[node];
                for (let k = 0; k < incoming.length; k++) {
                    const gradient = delta * incoming[k];
                    const changeLow = currentChangesLow[node][k] * beta1 + (1 - beta1) * gradient;
                    const changeHigh = currentChangesHigh[node][k] * beta2 +
                        (1 - beta2) * gradient * gradient;
                    const momentumCorrection = changeLow / (1 - Math.pow(beta1, iterations));
                    const gradientCorrection = changeHigh / (1 - Math.pow(beta2, iterations));
                    currentChangesLow[node][k] = changeLow;
                    currentChangesHigh[node][k] = changeHigh;
                    currentWeights[node][k] +=
                        (learningRate * momentumCorrection) /
                            (Math.sqrt(gradientCorrection) + epsilon);
                }
                const biasGradient = currentDeltas[node];
                const biasChangeLow = currentBiasChangesLow[node] * beta1 + (1 - beta1) * biasGradient;
                const biasChangeHigh = currentBiasChangesHigh[node] * beta2 +
                    (1 - beta2) * biasGradient * biasGradient;
                const biasMomentumCorrection = currentBiasChangesLow[node] / (1 - Math.pow(beta1, iterations));
                const biasGradientCorrection = currentBiasChangesHigh[node] / (1 - Math.pow(beta2, iterations));
                currentBiasChangesLow[node] = biasChangeLow;
                currentBiasChangesHigh[node] = biasChangeHigh;
                currentBiases[node] +=
                    (learningRate * biasMomentumCorrection) /
                        (Math.sqrt(biasGradientCorrection) + epsilon);
            }
        }
    }
    formatData(data) {
        if (!Array.isArray(data[0].input)) {
            if (this.inputLookup) {
                this.inputLookupLength = Object.keys(this.inputLookup).length;
            }
            else {
                const inputLookup = new LookupTable(data, 'input');
                this.inputLookup = inputLookup.table;
                this.inputLookupLength = inputLookup.length;
            }
        }
        if (!Array.isArray(data[0].output)) {
            if (this.outputLookup) {
                this.outputLookupLength = Object.keys(this.outputLookup).length;
            }
            else {
                const lookup = new LookupTable(data, 'output');
                this.outputLookup = lookup.table;
                this.outputLookupLength = lookup.length;
            }
        }
        if (!this._formatInput) {
            this._formatInput = getTypedArrayFn(data[0].input, this.inputLookup);
        }
        if (!this._formatOutput) {
            this._formatOutput = getTypedArrayFn(data[0].output, this.outputLookup);
        }
        // turn sparse hash input into arrays with 0s as filler
        if (this._formatInput && this._formatOutput) {
            const result = [];
            for (let i = 0; i < data.length; i++) {
                result.push({
                    input: this._formatInput(data[i].input),
                    output: this._formatOutput(data[i].output),
                });
            }
            return result;
        }
        if (this._formatInput) {
            const result = [];
            for (let i = 0; i < data.length; i++) {
                result.push({
                    input: this._formatInput(data[i].input),
                    output: data[i].output,
                });
            }
            return result;
        }
        if (this._formatOutput) {
            const result = [];
            for (let i = 0; i < data.length; i++) {
                result.push({
                    input: data[i].input,
                    output: this._formatOutput(data[i].output),
                });
            }
            return result;
        }
        return data;
    }
    addFormat(data) {
        var _a, _b;
        if (!Array.isArray(data.input) || typeof data.input[0] !== 'number') {
            this.inputLookup = lookup.addKeys(data.input, (_a = this.inputLookup) !== null && _a !== void 0 ? _a : {});
            if (this.inputLookup) {
                this.inputLookupLength = Object.keys(this.inputLookup).length;
            }
        }
        if (!Array.isArray(data.output) || typeof data.output[0] !== 'number') {
            this.outputLookup = lookup.addKeys(data.output, (_b = this.outputLookup) !== null && _b !== void 0 ? _b : {});
            if (this.outputLookup) {
                this.outputLookupLength = Object.keys(this.outputLookup).length;
            }
        }
    }
    test(data) {
        const { preparedData } = this.prepTraining(data);
        // for binary classification problems with one output node
        const isBinary = preparedData[0].output.length === 1;
        // for classification problems
        const misclasses = [];
        // run each pattern through the trained network and collect
        // error and misclassification statistics
        let errorSum = 0;
        if (isBinary) {
            let falsePos = 0;
            let falseNeg = 0;
            let truePos = 0;
            let trueNeg = 0;
            for (let i = 0; i < preparedData.length; i++) {
                const output = this.runInput(preparedData[i].input);
                const target = preparedData[i].output;
                const actual = output[0] > this.options.binaryThresh ? 1 : 0;
                const expected = target[0];
                if (actual !== expected) {
                    const misclass = preparedData[i];
                    misclasses.push({
                        input: misclass.input,
                        output: misclass.output,
                        actual,
                        expected,
                    });
                }
                if (actual === 0 && expected === 0) {
                    trueNeg++;
                }
                else if (actual === 1 && expected === 1) {
                    truePos++;
                }
                else if (actual === 0 && expected === 1) {
                    falseNeg++;
                }
                else if (actual === 1 && expected === 0) {
                    falsePos++;
                }
                errorSum += mse$1(output.map((value, i) => {
                    return target[i] - value;
                }));
            }
            return {
                error: errorSum / preparedData.length,
                misclasses,
                total: preparedData.length,
                trueNeg,
                truePos,
                falseNeg,
                falsePos,
                precision: truePos > 0 ? truePos / (truePos + falsePos) : 0,
                recall: truePos > 0 ? truePos / (truePos + falseNeg) : 0,
                accuracy: (trueNeg + truePos) / preparedData.length,
            };
        }
        for (let i = 0; i < preparedData.length; i++) {
            const output = this.runInput(preparedData[i].input);
            const target = preparedData[i].output;
            const actual = output.indexOf(max(output));
            const expected = target.indexOf(max(target));
            if (actual !== expected) {
                const misclass = preparedData[i];
                misclasses.push({
                    input: misclass.input,
                    output: misclass.output,
                    actual,
                    expected,
                });
            }
            errorSum += mse$1(output.map((value, i) => {
                return target[i] - value;
            }));
        }
        return {
            error: errorSum / preparedData.length,
            misclasses,
            total: preparedData.length,
        };
    }
    toJSON() {
        var _a, _b;
        if (!this.isRunnable) {
            this.initialize();
        }
        // use Array.from, keeping json small
        const jsonLayerWeights = this.weights.map((layerWeights) => {
            return layerWeights.map((layerWeights) => Array.from(layerWeights));
        });
        const jsonLayerBiases = this.biases.map((layerBiases) => Array.from(layerBiases));
        const jsonLayers = [];
        const outputLength = this.sizes.length - 1;
        for (let i = 0; i <= outputLength; i++) {
            jsonLayers.push({
                weights: (_a = jsonLayerWeights[i]) !== null && _a !== void 0 ? _a : [],
                biases: (_b = jsonLayerBiases[i]) !== null && _b !== void 0 ? _b : [],
            });
        }
        return {
            type: 'NeuralNetwork',
            sizes: [...this.sizes],
            layers: jsonLayers,
            inputLookup: this.inputLookup ? { ...this.inputLookup } : null,
            inputLookupLength: this.inputLookupLength,
            outputLookup: this.outputLookup ? { ...this.outputLookup } : null,
            outputLookupLength: this.outputLookupLength,
            options: { ...this.options },
            trainOpts: this.getTrainOptsJSON(),
        };
    }
    fromJSON(json) {
        this.options = { ...defaults$2(), ...json.options };
        if (json.hasOwnProperty('trainOpts')) {
            const trainOpts = {
                ...json.trainOpts,
                timeout: json.trainOpts.timeout === 'Infinity'
                    ? Infinity
                    : json.trainOpts.timeout,
            };
            this.updateTrainingOptions(trainOpts);
        }
        this.sizes = json.sizes;
        this.initialize();
        this.inputLookup = json.inputLookup ? { ...json.inputLookup } : null;
        this.inputLookupLength = json.inputLookupLength;
        this.outputLookup = json.outputLookup ? { ...json.outputLookup } : null;
        this.outputLookupLength = json.outputLookupLength;
        const jsonLayers = json.layers;
        const layerWeights = this.weights.map((layerWeights, layerIndex) => {
            return jsonLayers[layerIndex].weights.map((layerWeights) => Float32Array.from(layerWeights));
        });
        const layerBiases = this.biases.map((layerBiases, layerIndex) => Float32Array.from(jsonLayers[layerIndex].biases));
        for (let i = 0; i <= this.outputLayer; i++) {
            this.weights[i] = layerWeights[i] || [];
            this.biases[i] = layerBiases[i] || [];
        }
        return this;
    }
    toFunction(cb) {
        const { activation, leakyReluAlpha } = this.trainOpts;
        let needsVar = false;
        const nodeHandle = (layerIndex, nodeIndex) => {
            if (layerIndex === 0) {
                return `(input[${nodeIndex}]||0)`;
            }
            const weights = this.weights[layerIndex][nodeIndex];
            const bias = this.biases[layerIndex][nodeIndex];
            if (!weights) {
                throw new Error(`weights at layerIndex ${layerIndex} & nodeIndex ${nodeIndex} not found`);
            }
            if (!bias) {
                throw new Error(`bias as layerIndex ${layerIndex} & nodeIndex ${nodeIndex} not found`);
            }
            const weightsArray = [];
            weights.forEach((weight, subNodeIndex) => {
                if (weight < 0) {
                    weightsArray.push(`${weight}*${nodeHandle(layerIndex - 1, subNodeIndex)}`);
                }
                else {
                    weightsArray.push(`+${weight}*${nodeHandle(layerIndex - 1, subNodeIndex)}`);
                }
            });
            const result = `(${bias.toString()}${weightsArray.join('')})`;
            switch (activation) {
                case 'sigmoid':
                    return `1/(1+1/Math.exp(${result}))`;
                case 'relu': {
                    needsVar = true;
                    return `((v=${result})<0?0:v)`;
                }
                case 'leaky-relu': {
                    needsVar = true;
                    return `Math.max((v=${result}),${leakyReluAlpha}*v)`;
                }
                case 'tanh':
                    return `Math.tanh(${result})`;
                default:
                    throw new Error(`Unknown activation ${activation}. Available activations are: 'sigmoid', 'relu', 'leaky-relu', 'tanh'`);
            }
        };
        function checkKeys(keys) {
            if (keys.find((v) => v.includes('"'))) {
                throw new Error(`key contains '"', which is not compatible`);
            }
        }
        const layersAsMath = [];
        let result;
        let inputLookup = '';
        if (this.inputLookup) {
            const keys = Object.keys(this.inputLookup);
            checkKeys(keys);
            inputLookup = `input = new Float32Array([${Object.keys(this.inputLookup)
                .map((key) => `input["${key}"]`)
                .join(',')}]);`;
        }
        if (this.sizes.length < 1)
            throw new Error('No layers');
        for (let nodeIndex = 0; nodeIndex < this.sizes[this.outputLayer]; nodeIndex++) {
            layersAsMath.push(nodeHandle(this.outputLayer, nodeIndex));
        }
        if (this.outputLookup) {
            const keys = Object.keys(this.outputLookup);
            checkKeys(keys);
            const values = keys
                .map((key, i) => `"${key}":${layersAsMath[i]}`)
                .join(',');
            result = `{${values}}`;
        }
        else {
            result = `[${layersAsMath.join(',')}]`;
        }
        const source = `${inputLookup}${needsVar ? 'var v;' : ''}return ${result};`;
        // eslint-disable-next-line @typescript-eslint/no-implied-eval,no-new-func
        return new Function('input', cb ? cb(source) : source);
    }
}

function weightedSumSigmoid(weights, biases, inputs) {
    let sum = biases[this.thread.x];
    for (let k = 0; k < this.constants.size; k++) {
        sum += weights[this.thread.x][k] * inputs[k];
    }
    // sigmoid
    return 1 / (1 + Math.exp(-sum));
}
function weightedSumRelu(weights, biases, inputs) {
    let sum = biases[this.thread.x];
    for (let k = 0; k < this.constants.size; k++) {
        sum += weights[this.thread.x][k] * inputs[k];
    }
    // relu
    return sum < 0 ? 0 : sum;
}
function weightedSumLeakyRelu(weights, biases, inputs) {
    let sum = biases[this.thread.x];
    for (let k = 0; k < this.constants.size; k++) {
        sum += weights[this.thread.x][k] * inputs[k];
    }
    // leaky relu
    return sum < 0 ? 0 : 0.01 * sum;
}
function weightedSumTanh(weights, biases, inputs) {
    let sum = biases[this.thread.x];
    for (let k = 0; k < this.constants.size; k++) {
        sum += weights[this.thread.x][k] * inputs[k];
    }
    // tanh
    return Math.tanh(sum);
}
function calcErrorOutput(output, target) {
    return target - output;
}
function calcDeltasSigmoid(error, output) {
    // sigmoid derivative
    return error * output * (1 - output);
}
function calcDeltasRelu(error, output) {
    // relu derivative
    return output > 0 ? error : 0;
}
function calcDeltasLeakyRelu(error, output) {
    // leaky relu derivative
    return output > 0 ? error : 0.01 * error;
}
function calcDeltasTanh(error, output) {
    // tanh derivative
    return (1 - output * output) * error;
}
function calcError(x, size, nextWeights, nextDeltas) {
    let error = 0;
    for (let k = 0; k < size; k++) {
        error += nextDeltas[k] * nextWeights[k][x];
    }
    return error;
}
function calcChanges(learningRate, momentum, previousChange, delta, previousOutput) {
    return learningRate * delta * previousOutput + momentum * previousChange;
}
function addWeights(change, weight) {
    return change + weight;
}
function addBiases(biases, deltas) {
    return (biases[this.thread.x] + deltas[this.thread.x] * this.constants.learningRate);
}
// mean squared error, reimplemented for GPU
function mse(errors) {
    let sum = 0;
    for (let i = 0; i < this.constants.size; i++) {
        sum += errors[i] ** 2;
    }
    return sum / this.constants.size;
}
class NeuralNetworkGPU extends NeuralNetwork {
    constructor(options = {}) {
        super(options);
        this.texturizeInputData = () => {
            throw new Error('not yet setup');
        };
        this.forwardPropagate = [];
        this.backwardPropagate = [];
        this.changesPropagate = [];
        this.biasesPropagate = [];
        this.getMSE = () => {
            throw new Error('not yet setup');
        };
        this._addMSE = () => {
            throw new Error('not yet setup');
        };
        this._divideMSESum = () => {
            throw new Error('not yet setup');
        };
        // eslint-disable-next-line @typescript-eslint/ban-ts-comment
        // @ts-expect-error
        this.outputs = [];
        // eslint-disable-next-line @typescript-eslint/ban-ts-comment
        // @ts-expect-error
        this.deltas = [];
        // eslint-disable-next-line @typescript-eslint/ban-ts-comment
        // @ts-expect-error
        this.errors = [];
        // eslint-disable-next-line @typescript-eslint/ban-ts-comment
        // @ts-expect-error
        this.weights = [];
        // eslint-disable-next-line @typescript-eslint/ban-ts-comment
        // @ts-expect-error
        this.changes = [];
        // eslint-disable-next-line @typescript-eslint/ban-ts-comment
        // @ts-expect-error
        this.biases = [];
        // eslint-disable-next-line @typescript-eslint/ban-ts-comment
        // @ts-expect-error
        this.runInput = (input) => {
            let output;
            this.outputs[0] = input;
            for (let layer = 1; layer <= this.outputLayer; layer++) {
                release(this.outputs[layer]);
                this.outputs[layer] = this.forwardPropagate[layer](this.weights[layer], this.biases[layer], input);
                output = input = this.outputs[layer];
            }
            return output;
        };
        this.calculateDeltas = (target) => {
            for (let layer = this.outputLayer; layer > 0; layer--) {
                release(this.deltas[layer]);
                release(this.errors[layer]);
                let output;
                if (layer === this.outputLayer) {
                    // eslint-disable-next-line @typescript-eslint/ban-ts-comment
                    // @ts-expect-error
                    output = this.backwardPropagate[layer](this.outputs[layer], target);
                }
                else {
                    // eslint-disable-next-line @typescript-eslint/ban-ts-comment
                    // @ts-expect-error
                    output = this.backwardPropagate[layer](this.weights[layer + 1], this.outputs[layer], this.deltas[layer + 1]);
                }
                this.deltas[layer] = output.result;
                this.errors[layer] = output.error;
            }
        };
        this.errorCheckInterval = 100;
        this.gpu = new gpu_js.GPU({ mode: options.mode });
    }
    initialize() {
        super.initialize();
        this.buildRunInput();
        this.buildCalculateDeltas();
        this.buildGetChanges();
        this.buildChangeBiases();
        this.buildGetMSE();
    }
    setActivation() { }
    // eslint-disable-next-line @typescript-eslint/ban-ts-comment
    // @ts-expect-error
    trainPattern(value, logErrorRate) {
        // forward propagate
        this.runInput(value.input);
        // back propagate
        this.calculateDeltas(value.output);
        this.adjustWeights();
        if (logErrorRate) {
            return this.getMSE(this.errors[this.outputLayer]);
        }
        return null;
    }
    calculateTrainingError(data) {
        let sum = new Float32Array([0]);
        for (let i = 0; i < data.length; ++i) {
            const prevSum = sum;
            const error = this.trainPattern(data[i], true);
            sum = this._addMSE(sum, error);
            release(error);
            release(prevSum);
        }
        const result = this._divideMSESum(data.length, sum);
        release(sum);
        return (result instanceof gpu_js.Texture
            ? result.toArray()
            : result)[0];
    }
    adjustWeights() {
        this.getChanges();
        this.changeBiases();
    }
    buildRunInput() {
        let weightedSum = null;
        switch (this.trainOpts.activation) {
            case 'sigmoid':
                weightedSum = weightedSumSigmoid;
                break;
            case 'relu':
                weightedSum = weightedSumRelu;
                break;
            case 'leaky-relu':
                weightedSum = weightedSumLeakyRelu;
                break;
            case 'tanh':
                weightedSum = weightedSumTanh;
                break;
            default:
                throw new Error(`Unknown activation ${this.trainOpts.activation}. Available activations are: 'sigmoid', 'relu', 'leaky-relu', 'tanh'`);
        }
        for (let layer = 1; layer <= this.outputLayer; layer++) {
            this.forwardPropagate[layer] = this.gpu.createKernel(weightedSum, {
                output: [this.sizes[layer]],
                pipeline: true,
                constants: {
                    size: this.sizes[layer - 1],
                },
                immutable: true,
            });
        }
        this.texturizeInputData = this.gpu.createKernel(function (value) {
            return value[this.thread.x];
        }, {
            output: [this.sizes[1]],
            pipeline: true,
            immutable: true,
        });
    }
    buildCalculateDeltas() {
        let calcDeltas;
        switch (this.trainOpts.activation) {
            case 'sigmoid':
                calcDeltas = calcDeltasSigmoid;
                break;
            case 'relu':
                calcDeltas = calcDeltasRelu;
                break;
            case 'leaky-relu':
                calcDeltas = calcDeltasLeakyRelu;
                break;
            case 'tanh':
                calcDeltas = calcDeltasTanh;
                break;
            default:
                throw new Error(`Unknown activation ${this.trainOpts.activation}. Available activations are: 'sigmoid', 'relu', 'leaky-relu', 'tanh'`);
        }
        calcDeltas = gpu_js.alias(gpu_js.utils.getMinifySafeName(() => calcDeltas), calcDeltas);
        this.gpu.addFunction(calcDeltas);
        for (let layer = this.outputLayer; layer > 0; layer--) {
            if (layer === this.outputLayer) {
                // eslint-disable-next-line @typescript-eslint/ban-ts-comment
                // @ts-expect-error
                this.backwardPropagate[this.outputLayer] = this.gpu.createKernelMap({
                    error: calcErrorOutput,
                }, function (outputs, targets) {
                    const output = outputs[this.thread.x];
                    const target = targets[this.thread.x];
                    // eslint-disable-next-line @typescript-eslint/ban-ts-comment
                    // @ts-expect-error
                    return calcDeltas(calcErrorOutput(output, target), output);
                }, {
                    output: [this.sizes[this.outputLayer]],
                    pipeline: true,
                    immutable: true,
                });
            }
            else {
                // eslint-disable-next-line @typescript-eslint/ban-ts-comment
                // @ts-expect-error
                this.backwardPropagate[layer] = this.gpu.createKernelMap({
                    error: calcError,
                }, function (nextWeights, outputs, nextDeltas) {
                    const output = outputs[this.thread.x];
                    // eslint-disable-next-line @typescript-eslint/ban-ts-comment
                    // @ts-expect-error
                    return calcDeltas(calcError(this.thread.x, this.constants.size, nextWeights, nextDeltas), output);
                }, {
                    output: [this.sizes[layer]],
                    pipeline: true,
                    constants: {
                        size: this.sizes[layer + 1],
                    },
                    immutable: true,
                });
            }
        }
    }
    buildGetChanges() {
        for (let layer = 1; layer <= this.outputLayer; layer++) {
            // eslint-disable-next-line @typescript-eslint/ban-ts-comment
            // @ts-expect-error
            this.changesPropagate[layer] = this.gpu.createKernelMap({
                weights: addWeights,
                changes: calcChanges,
            }, function (previousOutputs, deltas, weights, previousChanges) {
                const change = calcChanges(this.constants.learningRate, this.constants.momentum, previousChanges[this.thread.y][this.thread.x], deltas[this.thread.y], previousOutputs[this.thread.x]);
                return addWeights(change, weights[this.thread.y][this.thread.x]);
            }, {
                output: [this.sizes[layer - 1], this.sizes[layer]],
                pipeline: true,
                constants: {
                    size: this.sizes[layer - 1],
                    learningRate: this.trainOpts.learningRate,
                    momentum: this.trainOpts.momentum,
                },
                immutable: true,
            });
        }
    }
    getChanges() {
        for (let layer = 1; layer <= this.outputLayer; layer++) {
            const weights = this.weights[layer];
            const changes = this.changes[layer];
            const output = this.changesPropagate[layer](this.outputs[layer - 1], this.deltas[layer], weights, changes);
            release(weights);
            release(changes);
            this.weights[layer] = output.weights;
            this.changes[layer] = output.changes;
            release(output.result);
        }
    }
    buildChangeBiases() {
        for (let layer = 1; layer <= this.outputLayer; layer++) {
            this.biasesPropagate[layer] = this.gpu.createKernel(addBiases, {
                output: [this.sizes[layer]],
                pipeline: true,
                constants: {
                    learningRate: this.trainOpts.learningRate,
                },
                immutable: true,
            });
        }
    }
    changeBiases() {
        for (let layer = 1; layer <= this.outputLayer; layer++) {
            const biases = this.biases[layer];
            this.biases[layer] = this.biasesPropagate[layer](biases, this.deltas[layer]);
            release(biases);
        }
    }
    buildGetMSE() {
        this.getMSE = this.gpu.createKernel(mse, {
            output: [1],
            constants: {
                size: this.sizes[this.outputLayer],
            },
            pipeline: true,
            immutable: true,
        });
        this._addMSE = this.gpu.createKernel(function (value1, value2) {
            return value1[0] + value2[0];
        }, {
            output: [1],
            pipeline: true,
            immutable: true,
        });
        this._divideMSESum = this.gpu.createKernel(function (length, mseSum) {
            const value = mseSum[0];
            if (value > 0) {
                return value / length;
            }
            return 0;
        }, {
            output: [1],
        });
    }
    run(input) {
        if (!this.isRunnable) {
            throw new Error('network not runnable');
        }
        let formattedInput;
        if (this.inputLookup) {
            formattedInput = lookup.toArray(this.inputLookup, input, this.inputLookupLength);
        }
        else {
            formattedInput = input;
        }
        const outputTextures = this.runInput(formattedInput);
        const output = outputTextures instanceof gpu_js.Texture
            ? outputTextures.toArray()
            : outputTextures;
        if (this.outputLookup) {
            return lookup.toObject(this.outputLookup, output);
        }
        return output;
    }
    // @ts-expect-error the underlying network works as normal, but we are working on the GPU
    prepTraining(data, options = {}) {
        this.updateTrainingOptions(options);
        const preparedData = this.formatData(data);
        const endTime = Date.now() + this.trainOpts.timeout;
        const status = {
            error: 1,
            iterations: 0,
        };
        this.verifyIsInitialized(preparedData);
        const texturizeOutputData = this.gpu.createKernel(function (value) {
            return value[this.thread.x];
        }, {
            output: [preparedData[0].output.length],
            pipeline: true,
            immutable: true,
        });
        return {
            preparedData: preparedData.map((set) => ({
                input: this.texturizeInputData(set.input),
                output: texturizeOutputData(set.output),
            })),
            status,
            endTime,
        };
    }
    // eslint-disable-next-line @typescript-eslint/ban-ts-comment
    // @ts-expect-error
    toFunction() {
        throw new Error(`${this.constructor.name}-toFunction is not yet implemented`);
    }
    toJSON() {
        var _a, _b;
        if (this.sizes === null) {
            this.initialize();
        }
        // use Array.from, keeping json small
        const jsonLayerWeights = this.weights.map((layerWeights) => {
            return (layerWeights instanceof gpu_js.Texture
                ? layerWeights.toArray()
                : layerWeights).map((layerWeights) => Array.from(layerWeights));
        });
        const jsonLayerBiases = this.biases.map((layerBiases) => Array.from(layerBiases instanceof gpu_js.Texture
            ? layerBiases.toArray()
            : layerBiases));
        const jsonLayers = [];
        for (let i = 0; i <= this.outputLayer; i++) {
            jsonLayers.push({
                weights: (_a = jsonLayerWeights[i]) !== null && _a !== void 0 ? _a : [],
                biases: (_b = jsonLayerBiases[i]) !== null && _b !== void 0 ? _b : [],
            });
        }
        return {
            type: 'NeuralNetworkGPU',
            sizes: [...this.sizes],
            layers: jsonLayers,
            inputLookup: this.inputLookup ? { ...this.inputLookup } : null,
            inputLookupLength: this.inputLookupLength,
            outputLookup: this.outputLookup ? { ...this.outputLookup } : null,
            outputLookupLength: this.outputLookupLength,
            options: { ...this.options },
            trainOpts: this.getTrainOptsJSON(),
        };
    }
}

class RecurrentConnection extends Internal {
    constructor() {
        super(...arguments);
        this.settings = {};
        this.layer = null;
    }
    setLayer(layer) {
        this.layer = layer;
    }
    get width() {
        if (!this.layer)
            throw new Error('layer not set');
        return this.layer.width;
    }
    set width(value) {
        throw new Error(`${this.constructor.name}-width is not yet implemented`);
    }
    get height() {
        if (!this.layer)
            throw new Error('layer not set');
        return this.layer.height;
    }
    set height(value) {
        throw new Error(`${this.constructor.name}-height is not yet implemented`);
    }
    get deltas() {
        if (!this.layer)
            throw new Error('layer not set');
        return this.layer.deltas;
    }
    set deltas(deltas) {
        if (!this.layer)
            throw new Error('layer not set');
        release(this.layer.deltas);
        this.layer.deltas = deltas;
    }
    get weights() {
        if (!this.layer)
            throw new Error('layer not set');
        return this.layer.weights;
    }
    set weights(weights) {
        if (!this.layer)
            throw new Error('layer not set');
        release(this.layer.weights);
        this.layer.weights = weights;
    }
    predict() {
        // throw new Error(`${this.constructor.name}-predict is not yet implemented`)
    }
    compare() {
        // throw new Error(`${this.constructor.name}-compare is not yet implemented`)
    }
    learn() {
        throw new Error('no longer using');
    }
    setupKernels() {
        // throw new Error(
        //   `${this.constructor.name}-setupKernels is not yet implemented`
        // )
    }
    reuseKernels() {
        // throw new Error(
        //   `${this.constructor.name}-reuseKernels is not yet implemented`
        // )
    }
}

class Recurrent extends FeedForward {
    // TODO: use generics in extend
    constructor(options = {}) {
        // eslint-disable-next-line @typescript-eslint/ban-ts-comment
        // @ts-expect-error
        super(options);
        this.trainOpts = {};
        this._outputConnection = null;
        this._layerSets = [];
        this._hiddenLayerOutputIndices = [];
        this._model = null;
    }
    _connectLayers() {
        if (!this.options.inputLayer) {
            throw new Error('inputLayer not found');
        }
        if (!this.options.outputLayer) {
            throw new Error('outputLayer not found');
        }
        const inputLayer = this.options.inputLayer();
        const hiddenLayers = this._connectHiddenLayers(inputLayer);
        const outputLayer = this.options.outputLayer(hiddenLayers[hiddenLayers.length - 1], -1);
        return {
            inputLayer,
            hiddenLayers,
            outputLayer,
        };
    }
    _connectLayersDeep() {
        const layers = [];
        const previousLayers = this._layerSets[this._layerSets.length - 1];
        let usedHiddenLayerOutputIndex = 0;
        function findInputLayer(inputLayer) {
            const index = previousLayers.indexOf(inputLayer);
            if (index < 0)
                throw new Error('unable to find layer');
            return layers[index];
        }
        function layerSettings(layer) {
            return {
                ...layer.settings,
                weights: null,
                deltas: null,
                praxis: null,
            };
        }
        for (let i = 0; i < previousLayers.length; i++) {
            const previousLayer = previousLayers[i];
            let layer;
            if (previousLayer instanceof Activation) {
                layer = new previousLayer.constructor(findInputLayer(previousLayer.inputLayer), layerSettings(previousLayer));
            }
            else if (previousLayer instanceof EntryPoint) {
                layer = new previousLayer.constructor(layerSettings(previousLayer));
            }
            else if (previousLayer instanceof Filter) {
                layer = new previousLayer.constructor(layerSettings(previousLayer.inputLayer), findInputLayer(previousLayer.inputLayer));
            }
            else if (previousLayer instanceof Internal) {
                const previousHiddenLayerOutput = previousLayers[this._hiddenLayerOutputIndices[usedHiddenLayerOutputIndex++]];
                if (previousLayer instanceof RecurrentConnection) {
                    throw new Error('unfinished');
                }
                else if (previousLayer instanceof RecurrentInput) {
                    layer = new RecurrentInput(previousHiddenLayerOutput);
                }
                else if (previousLayer instanceof RecurrentZeros) {
                    layer = new RecurrentInput(previousHiddenLayerOutput);
                }
                else {
                    throw new Error(`hidden layer ${previousLayer.constructor.name} extends unknown hidden layer`);
                }
            }
            else if (previousLayer instanceof InternalModel ||
                previousLayer instanceof Model) {
                layer = previousLayer;
            }
            else if (previousLayer instanceof Modifier) {
                layer = new previousLayer.constructor(findInputLayer(previousLayer.inputLayer), layerSettings(previousLayer.inputLayer));
            }
            else if (previousLayer instanceof Operator) {
                layer = new previousLayer.constructor(findInputLayer(previousLayer.inputLayer1), findInputLayer(previousLayer.inputLayer2), layerSettings(previousLayer));
            }
            else if (previousLayer instanceof Target) {
                layer = new previousLayer.constructor(layerSettings(previousLayer), findInputLayer(previousLayer.inputLayer));
            }
            else {
                throw new Error(`hidden layer ${previousLayer.constructor.name} extends unknown hidden layer`);
            }
            layers.push(layer);
        }
        return layers;
    }
    _connectHiddenLayers(previousLayer) {
        const hiddenLayers = [];
        if (!this.options.hiddenLayers)
            throw new Error('hiddenLayers not defined');
        for (let i = 0; i < this.options.hiddenLayers.length; i++) {
            const recurrentInput = new RecurrentZeros();
            const hiddenLayer = this.options.hiddenLayers[i](previousLayer, recurrentInput, i);
            previousLayer = hiddenLayer;
            hiddenLayers.push(hiddenLayer);
        }
        return hiddenLayers;
    }
    initialize() {
        this._outputConnection = new RecurrentConnection();
        let layerSet;
        if (this.options.layers) {
            layerSet = this._connectOptionsLayers();
        }
        else {
            const { inputLayer, hiddenLayers, outputLayer } = this._connectLayers();
            layerSet = flattenLayers([inputLayer, ...hiddenLayers, outputLayer]);
            this._hiddenLayerOutputIndices = hiddenLayers.map((l) => layerSet.indexOf(l));
            this._inputLayer = inputLayer;
            this._hiddenLayers = hiddenLayers;
            this._outputLayer = outputLayer;
        }
        this.layers = layerSet;
        this._layerSets = [layerSet];
        this._model = layerSet.filter((l) => l instanceof Model || l instanceof InternalModel);
        this.initializeLayers(layerSet);
    }
    initializeDeep() {
        const layers = this._connectLayersDeep();
        for (let i = 0; i < layers.length; i++) {
            const layer = layers[i];
            layer.setupKernels(true);
            // TODO: enable this?
            // layer.reuseKernels(this._layerSets[0][i]);
        }
        this._layerSets.push(layers);
    }
    // eslint-disable-next-line @typescript-eslint/ban-ts-comment
    // @ts-expect-error
    run(inputs) {
        while (this._layerSets.length <= inputs.length) {
            this.initializeDeep();
        }
        const result = this.runInputs(inputs);
        if (result instanceof gpu_js.Texture)
            return result.toArray();
        return result;
    }
    runInput(input) {
        throw new Error('use .runInputs()');
    }
    runInputs(inputs) {
        while (this._layerSets.length < inputs.length) {
            this.initializeDeep();
        }
        const max = inputs.length - 1; // last output will be compared with last index
        for (let x = 0; x <= max; x++) {
            const layerSet = this._layerSets[x];
            layerSet[0].predict(inputs[x]);
            for (let i = 1; i < layerSet.length; i++) {
                layerSet[i].predict();
            }
        }
        const lastLayerUsed = this._layerSets[max];
        const result = lastLayerUsed[lastLayerUsed.length - 1].weights;
        this.end();
        return result;
    }
    // eslint-disable-next-line @typescript-eslint/ban-ts-comment
    // @ts-expect-error
    train(data, options = {}) {
        const { preparedData, status, endTime } = this._prepTraining(data, options);
        let continueTicking = true;
        const calculateError = () => this._calculateTrainingError(preparedData);
        const trainPatters = () => this._trainPatterns(preparedData);
        while (continueTicking) {
            continueTicking = this._trainingTick(status, endTime, calculateError, trainPatters);
        }
        return status;
    }
    end() {
        const x = this._layerSets.length - 1;
        const lastLayerSet = this._layerSets[x];
        lastLayerSet[0].predict([new Float32Array([0])]);
        for (let i = 1; i < lastLayerSet.length; i++) {
            lastLayerSet[i].predict();
        }
    }
    // eslint-disable-next-line @typescript-eslint/ban-ts-comment
    // @ts-expect-error
    transferData(formattedData) {
        return formattedData;
    }
    // eslint-disable-next-line @typescript-eslint/ban-ts-comment
    // @ts-expect-error
    _prepTraining(data, options) {
        this._updateTrainingOptions(options);
        const endTime = this.trainOpts.timeout
            ? Date.now() + this.trainOpts.timeout
            : 0;
        const status = {
            error: 1,
            iterations: 0,
        };
        this.verifyIsInitialized();
        return {
            preparedData: this.transferData(data),
            status,
            endTime,
        };
    }
    // eslint-disable-next-line @typescript-eslint/ban-ts-comment
    // @ts-expect-error
    _calculateTrainingError(data) {
        if (!this.meanSquaredError) {
            throw new Error('this.meanSquaredError not setup');
        }
        let sum = new Float32Array(1);
        for (let i = 0; i < data.length; ++i) {
            const prevSum = sum;
            const error = this._trainPattern(data[i], true);
            sum = this.meanSquaredError.add(sum, error);
            release(error);
            release(prevSum);
        }
        const result = this.meanSquaredError.divide(data.length, sum);
        release(sum);
        if (result instanceof gpu_js.Texture) {
            const resultArray = result.toArray();
            return resultArray[0];
        }
        return result[0];
    }
    // TODO: more types
    // eslint-disable-next-line @typescript-eslint/ban-ts-comment
    // @ts-expect-error
    formatData(data) {
        return data;
    }
    // eslint-disable-next-line @typescript-eslint/ban-ts-comment
    // @ts-expect-error
    _calculateDeltas(target) {
        const lastLayerSet = this._layerSets[this._layerSets.length - 1];
        // Iterate from the second to last layer backwards, propagating 0's
        for (let i = lastLayerSet.length - 2; i >= 0; i--) {
            lastLayerSet[i].compare();
        }
        for (let x = target.length - 2; x >= 0; x--) {
            const layerSet = this._layerSets[x];
            layerSet[layerSet.length - 1].compare(target[x + 1]);
            for (let i = layerSet.length - 2; i >= 0; i--) {
                layerSet[i].compare();
            }
        }
    }
    adjustWeights() {
        var _a;
        const _model = this._model;
        for (let i = 0; i < _model.length; i++) {
            _model[i].learn((_a = this.options.learningRate) !== null && _a !== void 0 ? _a : 0);
        }
    }
    // eslint-disable-next-line @typescript-eslint/ban-ts-comment
    // @ts-expect-error
    _trainPatterns(data) {
        for (let i = 0; i < data.length; ++i) {
            this._trainPattern(data[i], false);
        }
    }
    // eslint-disable-next-line @typescript-eslint/ban-ts-comment
    // @ts-expect-error
    _trainPattern(inputs, logErrorRate) {
        // forward propagate
        this.runInputs(inputs);
        // back propagate
        this._calculateDeltas(inputs);
        this.adjustWeights();
        if (logErrorRate) {
            if (!this.meanSquaredError) {
                throw new Error('this.meanSquaredError not setup');
            }
            let error = new Float32Array(1);
            for (let i = 0, max = inputs.length - 1; i <= max; i++) {
                const layerSet = this._layerSets[i];
                const lastLayer = layerSet[layerSet.length - 1];
                const prevError = error;
                error = this.meanSquaredError.addAbsolute(prevError, lastLayer.errors);
                release(prevError);
            }
            return clone(this.meanSquaredError.divide(inputs.length, error));
        }
        return null;
    }
}

/**
 * A matrix
 */
class Matrix {
    constructor(rows, columns) {
        this.rows = 0;
        this.columns = 0;
        if (rows)
            this.rows = rows;
        if (columns)
            this.columns = columns;
        this.weights = zeros$1(this.rows * this.columns);
        this.deltas = zeros$1(this.rows * this.columns);
    }
    getWeight(row, col) {
        // slow but careful accessor function
        // we want row-major order
        const ix = this.columns * row + col;
        if (ix < 0 || ix >= this.weights.length) {
            throw new Error('get accessor is skewed');
        }
        return this.weights[ix];
    }
    setWeight(row, col, v) {
        // slow but careful accessor function
        const ix = this.columns * row + col;
        if (ix < 0 || ix >= this.weights.length) {
            throw new Error('set accessor is skewed');
        }
        this.weights[ix] = v;
        return this;
    }
    getDelta(row, col) {
        // slow but careful accessor function
        // we want row-major order
        const ix = this.columns * row + col;
        if (ix < 0 || ix >= this.deltas.length) {
            throw new Error('get accessor is skewed');
        }
        return this.deltas[ix];
    }
    setDelta(row, col, v) {
        // slow but careful accessor function
        const ix = this.columns * row + col;
        if (ix < 0 || ix >= this.weights.length) {
            throw new Error('set accessor is skewed');
        }
        this.deltas[ix] = v;
        return this;
    }
    toJSON() {
        return {
            rows: this.rows,
            columns: this.columns,
            weights: Array.from(this.weights.slice(0)),
        };
    }
    static fromJSON(json) {
        const matrix = new Matrix(json.rows, json.columns);
        for (let i = 0, max = json.rows * json.columns; i < max; i++) {
            matrix.weights[i] = json.weights[i]; // copy over weights
        }
        return matrix;
    }
    static fromArray(weights) {
        const matrix = new Matrix(weights.length, weights[0].length);
        matrix.fromArray(weights);
        return matrix;
    }
    deltasToArray() {
        return this.toArray('deltas');
    }
    weightsToArray() {
        return this.toArray('weights');
    }
    toArray(prop = 'weights') {
        const result = new Array(this.rows);
        this.iterate({
            row: (rowIndex) => {
                result[rowIndex] = new Array(this.columns);
            },
            column: (rowIndex, columnIndex) => {
                if (prop === 'weights') {
                    result[rowIndex][columnIndex] = this.getWeight(rowIndex, columnIndex);
                }
                else if (prop === 'deltas') {
                    result[rowIndex][columnIndex] = this.getDelta(rowIndex, columnIndex);
                }
            },
        });
        return result;
    }
    fromArray(array, prop = 'weights') {
        if (array.length !== this.rows) {
            throw new Error('rows do not match');
        }
        if (array[0].length !== this.columns) {
            throw new Error('columns do not match');
        }
        this.iterate({
            column: (rowIndex, columnIndex) => {
                const value = array[rowIndex][columnIndex];
                if (typeof value !== 'number') {
                    throw new Error('value not number');
                }
                if (prop === 'weights') {
                    this.setWeight(rowIndex, columnIndex, value);
                }
                else if (prop === 'deltas') {
                    this.setDelta(rowIndex, columnIndex, value);
                }
            },
        });
        return this;
    }
    iterate(callbacks) {
        const rows = this.rows;
        const columns = this.columns;
        for (let rowIndex = 0; rowIndex < rows; rowIndex++) {
            if (callbacks.row) {
                callbacks.row(rowIndex);
            }
            for (let columnIndex = 0; columnIndex < columns; columnIndex++) {
                if (callbacks.column) {
                    callbacks.column(rowIndex, columnIndex);
                }
            }
        }
        return this;
    }
}

/** return Matrix but filled with random numbers from gaussian
 */
class RandomMatrix extends Matrix {
    constructor(rows, columns, std) {
        super(rows, columns);
        this.std = std;
        for (let i = 0, max = this.weights.length; i < max; i++) {
            this.weights[i] = randomFloat(-std, std);
        }
    }
}

class DataFormatter {
    constructor(values, maxThreshold = 0) {
        this.values = values;
        this.indexTable = {};
        this.characterTable = {};
        this.characters = [];
        this.specialIndexes = [];
        this.isSetup = false;
        if (values === undefined)
            return;
        this.setup(values, maxThreshold);
    }
    setup(values, maxThreshold = 0) {
        if (this.isSetup)
            throw new Error('DataFormatter is already setup');
        this.values = values;
        // go over all characters and keep track of all unique ones seen
        // count up all characters
        this.buildCharactersFromIterable(values);
        this.buildTables(maxThreshold);
        if (values[0].input) {
            this.addInputOutput();
        }
        this.addUnrecognized();
        this.isSetup = true;
    }
    buildCharactersFromIterable(values) {
        const tempCharactersTable = {};
        for (let dataFormatterIndex = 0, dataFormatterLength = values.length; dataFormatterIndex < dataFormatterLength; dataFormatterIndex++) {
            const characters = values[dataFormatterIndex];
            // if (typeof characters === 'string') {
            //   const character = characters;
            //   if (tempCharactersTable.hasOwnProperty(character)) continue;
            //   tempCharactersTable[character] = true;
            //   this.characters.push(character);
            if (characters.hasOwnProperty('length')) {
                const iteratable = characters;
                for (let characterIndex = 0, charactersLength = iteratable.length; characterIndex < charactersLength; characterIndex++) {
                    const character = iteratable[characterIndex];
                    if (tempCharactersTable.hasOwnProperty(character))
                        continue;
                    tempCharactersTable[character] = true;
                    this.characters.push(character);
                }
            }
            else if (typeof characters === 'number') {
                if (tempCharactersTable.hasOwnProperty(characters))
                    continue;
                tempCharactersTable[characters] = true;
                this.characters.push(characters);
            }
            else if (typeof characters === 'boolean') {
                const character = characters.toString();
                if (tempCharactersTable.hasOwnProperty(character))
                    continue;
                tempCharactersTable[character] = true;
                this.characters.push(character);
            }
            else if (Array.isArray(characters) &&
                typeof characters[0] === 'string') {
                for (let i = 0; i < characters.length; i++) {
                    const character = characters[i];
                    if (tempCharactersTable.hasOwnProperty(character))
                        continue;
                    tempCharactersTable[character] = true;
                    this.characters.push(character);
                }
            }
            else if (Array.isArray(characters) &&
                (typeof characters[0] === 'number' ||
                    typeof characters[0] === 'boolean')) {
                for (let i = 0; i < characters.length; i++) {
                    const character = characters[i].toString();
                    if (tempCharactersTable.hasOwnProperty(dataFormatterIndex))
                        continue;
                    tempCharactersTable[character] = true;
                    this.characters.push(character);
                }
            }
            else if (characters.hasOwnProperty('input') &&
                characters.hasOwnProperty('output')) {
                const { input, output } = characters;
                if (Array.isArray(input)) {
                    this.addCharacters(input, tempCharactersTable);
                }
                else {
                    this.addCharacters(input.toString(), tempCharactersTable);
                }
                if (Array.isArray(output)) {
                    this.addCharacters(output, tempCharactersTable);
                }
                else {
                    this.addCharacters(output.toString(), tempCharactersTable);
                }
            }
            else {
                throw new Error('Unhandled value');
            }
        }
    }
    addCharacters(characters, charactersTable) {
        for (let i = 0; i < characters.length; i++) {
            const character = characters[i].toString();
            if (charactersTable.hasOwnProperty(character))
                continue;
            charactersTable[character] = true;
            this.characters.push(character);
        }
    }
    buildTables(maxThreshold) {
        // filter by count threshold and create pointers
        const charactersLength = this.characters.length;
        for (let characterIndex = 0; characterIndex < charactersLength; characterIndex++) {
            const character = this.characters[characterIndex];
            if (characterIndex >= maxThreshold) {
                // add character to dataFormatter
                this.indexTable[character] = characterIndex;
                this.characterTable[characterIndex] = character;
            }
        }
    }
    toIndexes(value, maxThreshold = 0) {
        const result = [];
        const { indexTable } = this;
        switch (typeof value) {
            case 'number':
            case 'boolean':
                value = value.toString();
        }
        for (let i = 0, max = value.length; i < max; i++) {
            const character = value[i].toString();
            let index = indexTable[character];
            if (index === undefined) {
                if (indexTable.unrecognized) {
                    index = indexTable.unrecognized;
                }
                else {
                    throw new Error(`unrecognized character "${character}"`);
                }
            }
            if (index < maxThreshold)
                continue;
            result.push(index);
        }
        return result;
    }
    toIndexesInputOutput(input, output, maxThreshold = 0) {
        const result = this.toIndexesValue(input, maxThreshold, true);
        if (typeof output === 'undefined')
            return result;
        return result.concat(this.toIndexesValue(output, maxThreshold, false));
    }
    toIndexesValue(value, maxThreshold, isInput) {
        if (typeof value === 'string') {
            value = value.split('');
        }
        else if (typeof value === 'number' || typeof value === 'boolean') {
            value = value.toString().split('');
        }
        else if (Array.isArray(value) &&
            (typeof value[0] === 'number' ||
                typeof value[0] === 'boolean' ||
                typeof value[0] === 'string')) {
            value = value.map((v) => v.toString());
        }
        else {
            throw new Error('unrecognized value');
        }
        if (isInput) {
            value = value.concat(['stop-input', 'start-output']);
        }
        return this.toIndexes(value, maxThreshold);
    }
    toCharacters(indices, maxThreshold = 0) {
        const result = [];
        const { indexTable, characterTable } = this;
        for (let i = 0, max = indices.length; i < max; i++) {
            const index = indices[i];
            if (index < maxThreshold)
                continue;
            let character = characterTable[index];
            if (character === undefined) {
                if (indexTable.unrecognized) {
                    character = characterTable[indexTable.unrecognized];
                }
                else {
                    throw new Error(`unrecognized index "${index}"`);
                }
            }
            else if (character !== null) {
                result.push(character.toString());
            }
        }
        return result;
    }
    toString(indices, maxThreshold) {
        return this.toCharacters(indices, maxThreshold).join('');
    }
    addInputOutput() {
        this.addSpecial('stop-input');
        this.addSpecial('start-output');
    }
    addUnrecognized() {
        this.addSpecial('unrecognized');
    }
    static fromAllPrintable(maxThreshold, values = ['\n']) {
        for (let i = 32; i <= 126; i++) {
            values.push(String.fromCharCode(i));
        }
        return new DataFormatter(values, maxThreshold);
    }
    static fromAllPrintableInputOutput(maxThreshold, values = ['\n']) {
        const dataFormatter = DataFormatter.fromAllPrintable(maxThreshold, values);
        dataFormatter.addInputOutput();
        dataFormatter.addUnrecognized();
        return dataFormatter;
    }
    static fromStringInputOutput(string, maxThreshold) {
        const values = Array.from(new Set(string)).join('');
        const dataFormatter = new DataFormatter(values.split(''), maxThreshold);
        dataFormatter.addInputOutput();
        dataFormatter.addUnrecognized();
        dataFormatter.isSetup = true;
        return dataFormatter;
    }
    static fromArrayInputOutput(data, maxThreshold) {
        const values = [];
        for (let i = 0; i < data.length; i++) {
            const datum = data[i];
            values.push(validateAndCast(datum.input), validateAndCast(datum.output));
        }
        const flatArray = Array.isArray(values)
            ? values.flat()
            : values;
        const dataFormatter = new DataFormatter(Array.from(new Set(flatArray)), maxThreshold);
        dataFormatter.addInputOutput();
        dataFormatter.addUnrecognized();
        dataFormatter.isSetup = true;
        return dataFormatter;
    }
    static fromString(string, maxThreshold = 0) {
        const values = Array.from(new Set(string)).join('');
        return new DataFormatter(values.split(''), maxThreshold);
    }
    toJSON() {
        return {
            indexTable: this.indexTable,
            characterTable: this.characterTable,
            values: this.values,
            characters: this.characters,
            specialIndexes: this.specialIndexes,
        };
    }
    /** TODO: Type better, The type of json is not "string that is a valid JSON", it is a POJO in the shape of DataFormatter.
     * this method re-hydrates the the data as an instance of DataFormatter.
     */
    static fromJSON(json) {
        const dataFormatter = new DataFormatter();
        dataFormatter.indexTable = json.indexTable;
        dataFormatter.characterTable = json.characterTable;
        dataFormatter.values = json.values;
        dataFormatter.characters = json.characters;
        dataFormatter.specialIndexes = json.specialIndexes;
        return dataFormatter;
    }
    addSpecial(special, character = null) {
        const specialIndex = (this.indexTable[special] = this.characters.length);
        this.characterTable[specialIndex] = character;
        this.specialIndexes.push(this.characters.length);
        this.characters.push(special);
    }
    toFunctionString() {
        return `
var characterTable = ${JSON.stringify(this.characterTable)};
var indexTable = ${JSON.stringify(this.indexTable)};
var characters = ${JSON.stringify(this.characters)};
var dataFormatter = {
  toIndexes: function ${this.toIndexes.toString()},
  toIndexesInputOutput: function ${this.toIndexesInputOutput.toString()},
  toCharacters: function ${this.toCharacters.toString()},
  toIndexesValue: function ${this.toIndexesValue.toString()},
};`;
    }
    formatDataIn(input, output) {
        var _a;
        if (input === undefined)
            return [];
        if (Array.isArray(input) && typeof input[0] === 'number') {
            return input;
        }
        if ((_a = this.indexTable) === null || _a === void 0 ? void 0 : _a.hasOwnProperty('stop-input')) {
            return this.toIndexesInputOutput(input, output);
        }
        return this.toIndexes(input);
    }
    formatDataOut(input, output) {
        return this.toCharacters(output).join('');
    }
    format(data) {
        if (typeof data[0] === 'number' &&
            !Array.isArray(data[0]) &&
            (!data[0].hasOwnProperty('input') || !data[0].hasOwnProperty('output'))) {
            return data;
        }
        const result = [];
        if (typeof data[0] === 'string' ||
            typeof data[0] === 'number' ||
            Array.isArray(data[0])) {
            if (!this.isSetup) {
                this.setup(data);
                for (let i = 0; i < data.length; i++) {
                    result.push(this.formatDataIn(validateAndCast(data[i])));
                }
            }
            else {
                for (let i = 0, max = data.length; i < max; i++) {
                    result.push(this.formatDataIn(data[i]));
                }
            }
        }
        else if (data[0].input && data[0].output) {
            if (!this.isSetup) {
                this.setup(data);
            }
            for (let i = 0, max = data.length; i < max; i++) {
                result.push(this.formatDataIn(validateAndCast(data[i].input), validateAndCast(data[i].output)));
            }
        }
        else {
            throw new Error('unrecognized data');
        }
        return result;
    }
}
function validateAndCast(value) {
    if (typeof value === 'string')
        return value;
    if (typeof value === 'number')
        return value.toString();
    if (typeof value === 'boolean')
        return value.toString();
    if (Array.isArray(value) && typeof value[0] === 'string')
        return value;
    if (typeof value[0] === 'boolean') {
        return value.map((v) => v.toString());
    }
    if (typeof value[0] === 'number') {
        return value.map((v) => v.toString());
    }
    throw new Error('unrecognized value, expected string[], string, number[], number, boolean[], or boolean');
}

function copy(product, left) {
    product.rows = left.rows;
    product.columns = left.columns;
    product.weights = left.weights.slice(0);
    product.deltas = left.deltas.slice(0);
}

/**
 * add {left} and {right} matrix weights into {into}
 */
function add(product, left, right) {
    for (let i = 0; i < left.weights.length; i++) {
        product.weights[i] = left.weights[i] + right.weights[i];
        product.deltas[i] = 0;
    }
}

/**
 * adds {from} deltas to {left} and {right} deltas
 */
function addB(product, left, right) {
    for (let i = 0; i < product.deltas.length; i++) {
        left.deltas[i] = product.deltas[i];
        right.deltas[i] = product.deltas[i];
    }
}

/**
 * makes matrix weights and deltas all ones
 */
function allOnes(product) {
    for (let i = 0; i < product.weights.length; i++) {
        product.weights[i] = 1;
        product.deltas[i] = 0;
    }
}

function cloneNegative(product, left) {
    product.rows = left.rows;
    product.columns = left.columns;
    product.weights = left.weights.slice(0);
    product.deltas = left.deltas.slice(0);
    for (let i = 0; i < left.weights.length; i++) {
        product.weights[i] = -left.weights[i];
        product.deltas[i] = 0;
    }
}

/**
 * multiply {left} and {right} matrix weights to {into}
 */
function multiply(product, left, right) {
    const leftRows = left.rows;
    const leftColumns = left.columns;
    const rightColumns = right.columns;
    // loop over rows of left
    for (let leftRow = 0; leftRow < leftRows; leftRow++) {
        const leftRowBase = leftColumns * leftRow;
        const rightRowBase = rightColumns * leftRow;
        // loop over cols of right
        for (let rightColumn = 0; rightColumn < rightColumns; rightColumn++) {
            // dot product loop
            let dot = 0;
            // loop over columns of left
            for (let leftColumn = 0; leftColumn < leftColumns; leftColumn++) {
                const rightColumnBase = rightColumns * leftColumn;
                const leftIndex = leftRowBase + leftColumn;
                const rightIndex = rightColumnBase + rightColumn;
                dot += left.weights[leftIndex] * right.weights[rightIndex];
                left.deltas[leftIndex] = 0;
                right.deltas[rightIndex] = 0;
            }
            product.weights[rightRowBase + rightColumn] = dot;
        }
    }
}

/**
 * multiplies {from} deltas to {left} and {right}
 */
function multiplyB(product, left, right) {
    const leftRows = left.rows;
    const leftColumns = left.columns;
    const rightColumns = right.columns;
    // loop over rows of left
    for (let leftRowRoot = 0; leftRowRoot < leftRows; leftRowRoot++) {
        const leftRowBase = leftColumns * leftRowRoot;
        const rightRowBase = rightColumns * leftRowRoot;
        // loop over cols of right
        for (let rightColumn = 0; rightColumn < rightColumns; rightColumn++) {
            // loop over columns of left
            for (let leftColumn = 0; leftColumn < leftColumns; leftColumn++) {
                const rightColumnBase = rightColumns * leftColumn;
                const leftRow = leftRowBase + leftColumn;
                const rightRow = rightColumnBase + rightColumn;
                const backPropagateValue = product.deltas[rightRowBase + rightColumn];
                left.deltas[leftRow] += right.weights[rightRow] * backPropagateValue;
                right.deltas[rightRow] += left.weights[leftRow] * backPropagateValue;
            }
        }
    }
}

function multiplyElement(product, left, right) {
    const { weights } = left;
    for (let i = 0; i < weights.length; i++) {
        product.weights[i] = left.weights[i] * right.weights[i];
        product.deltas[i] = 0;
    }
}

/**
 * multiplies {left} and {right} weight by {from} deltas into {left} and {right} deltas
 */
function multiplyElementB(product, left, right) {
    for (let i = 0; i < left.weights.length; i++) {
        left.deltas[i] = right.weights[i] * product.deltas[i];
        right.deltas[i] = left.weights[i] * product.deltas[i];
    }
}

/**
 *
 * relu {m} weights to {into} weights
 */
function relu(product, left) {
    for (let i = 0; i < left.weights.length; i++) {
        product.weights[i] = Math.max(0, left.weights[i]); // relu
        product.deltas[i] = 0;
    }
}

/**
 * adds {from} deltas to {m} deltas when {m} weights are above other a threshold of 0
 */
function reluB(product, left) {
    for (let i = 0; i < product.deltas.length; i++) {
        left.deltas[i] = left.weights[i] > 0 ? product.deltas[i] : 0;
    }
}

function rowPluck(product, left, rowPluckIndex) {
    const { columns } = left;
    const rowBase = columns * rowPluckIndex;
    for (let column = 0; column < columns; column++) {
        product.weights[column] = left.weights[rowBase + column];
        product.deltas[column] = 0;
    }
}

/**
 * adds {from} deltas into {m} deltas
 */
function rowPluckB(product, left, rowIndex) {
    const { columns } = left;
    const rowBase = columns * rowIndex;
    for (let column = 0; column < columns; column++) {
        left.deltas[rowBase + column] = product.deltas[column];
    }
}

function sigmoid(product, left) {
    // sigmoid nonlinearity
    for (let i = 0; i < left.weights.length; i++) {
        product.weights[i] = 1 / (1 + Math.exp(-left.weights[i]));
        product.deltas[i] = 0;
    }
}
// function sig(x) {
//   // helper function for computing sigmoid
//   return 1 / (1 + Math.exp(-x));
// }

function sigmoidB(product, left) {
    for (let i = 0; i < product.deltas.length; i++) {
        const mwi = product.weights[i];
        left.deltas[i] = mwi * (1 - mwi) * product.deltas[i];
    }
}

function softmax(matrix) {
    // probability volume
    const result = new Matrix(matrix.rows, matrix.columns);
    let maxVal = -999999;
    for (let i = 0; i < matrix.weights.length; i++) {
        if (matrix.weights[i] > maxVal) {
            maxVal = matrix.weights[i];
        }
    }
    let s = 0;
    for (let i = 0; i < matrix.weights.length; i++) {
        result.weights[i] = Math.exp(matrix.weights[i] - maxVal);
        s += result.weights[i];
    }
    for (let i = 0; i < matrix.weights.length; i++) {
        result.weights[i] /= s;
    }
    // no backward pass here needed
    // since we will use the computed probabilities outside
    // to set gradients directly on m
    return result;
}

function tanh(product, left) {
    // tanh nonlinearity
    for (let i = 0; i < left.weights.length; i++) {
        product.weights[i] = Math.tanh(left.weights[i]);
        product.deltas[i] = 0;
    }
}

function tanhB(product, left) {
    for (let i = 0; i < product.deltas.length; i++) {
        // grad for z = tanh(x) is (1 - z^2)
        const mwi = product.weights[i];
        left.deltas[i] = (1 - mwi * mwi) * product.deltas[i];
    }
}

class Equation {
    constructor() {
        this.states = [];
        this.inputRow = 0;
    }
    add(left, right) {
        if (left.weights.length !== right.weights.length) {
            throw new Error('misaligned matrices');
        }
        const product = new Matrix(left.rows, left.columns);
        this.states.push({
            name: 'add',
            product,
            left,
            right,
            forwardFn: add,
            backpropagationFn: addB,
        });
        return product;
    }
    allOnes(rows, columns) {
        const product = new Matrix(rows, columns);
        this.states.push({
            name: 'allOnes',
            product,
            left: product,
            forwardFn: allOnes,
            backpropagationFn: () => { },
        });
        return product;
    }
    cloneNegative(matrix) {
        const product = new Matrix(matrix.rows, matrix.columns);
        this.states.push({
            name: 'cloneNegative',
            product,
            left: matrix,
            forwardFn: cloneNegative,
            backpropagationFn: () => { },
        });
        return product;
    }
    /**
     * connects two matrices together by subtract
     */
    subtract(left, right) {
        if (left.weights.length !== right.weights.length) {
            throw new Error('misaligned matrices');
        }
        return this.add(this.add(this.allOnes(left.rows, left.columns), this.cloneNegative(left)), right);
    }
    /**
     * connects two matrices together by multiply
     */
    multiply(left, right) {
        if (left.columns !== right.rows) {
            throw new Error('misaligned matrices');
        }
        const product = new Matrix(left.rows, right.columns);
        this.states.push({
            name: 'multiply',
            product,
            left,
            right,
            forwardFn: multiply,
            backpropagationFn: multiplyB,
        });
        return product;
    }
    /**
     * connects two matrices together by multiplyElement
     */
    multiplyElement(left, right) {
        if (left.weights.length !== right.weights.length) {
            throw new Error('misaligned matrices');
        }
        const product = new Matrix(left.rows, left.columns);
        this.states.push({
            name: 'multiplyElement',
            product,
            left,
            right,
            forwardFn: multiplyElement,
            backpropagationFn: multiplyElementB,
        });
        return product;
    }
    /**
     * connects a matrix to relu
     */
    relu(matrix) {
        const product = new Matrix(matrix.rows, matrix.columns);
        this.states.push({
            name: 'relu',
            product,
            left: matrix,
            forwardFn: relu,
            backpropagationFn: reluB,
        });
        return product;
    }
    /**
     * input a matrix
     */
    input(input) {
        this.states.push({
            name: 'input',
            product: input,
            forwardFn: (product) => {
                if (!this.inputValue)
                    return;
                if (this.inputValue.length !== product.weights.length) {
                    throw new Error('this.inputValue is of wrong dimensions');
                }
                product.weights = input.weights = this.inputValue;
            },
            backpropagationFn: () => { },
        });
        return input;
    }
    /**
     * connects a matrix via a row
     */
    inputMatrixToRow(matrix) {
        // eslint-disable-next-line @typescript-eslint/no-this-alias
        const self = this;
        const product = new Matrix(matrix.columns, 1);
        this.states.push({
            name: 'inputMatrixToRow',
            product,
            left: matrix,
            get right() {
                return self.inputRow;
            },
            forwardFn: rowPluck,
            backpropagationFn: rowPluckB,
        });
        return product;
    }
    /**
     * connects a matrix to sigmoid
     */
    sigmoid(matrix) {
        const product = new Matrix(matrix.rows, matrix.columns);
        this.states.push({
            name: 'sigmoid',
            product,
            left: matrix,
            forwardFn: sigmoid,
            backpropagationFn: sigmoidB,
        });
        return product;
    }
    /**
     * connects a matrix to tanh
     */
    tanh(matrix) {
        const product = new Matrix(matrix.rows, matrix.columns);
        this.states.push({
            name: 'tanh',
            product,
            left: matrix,
            forwardFn: tanh,
            backpropagationFn: tanhB,
        });
        return product;
    }
    /**
     *
     * Observe a matrix for debugging
     */
    observe(matrix) {
        this.states.push({
            name: 'observe',
            product: new Matrix(),
            forwardFn: () => { },
            backpropagationFn: () => { },
        });
        return matrix;
    }
    /**
     * Run index through equations via forward propagation
     */
    runIndex(rowIndex = 0) {
        this.inputRow = rowIndex;
        let state = this.states[0];
        for (let i = 0, max = this.states.length; i < max; i++) {
            state = this.states[i];
            if (!state.hasOwnProperty('forwardFn'))
                continue;
            state.forwardFn(state.product, state.left, state.right);
        }
        return state.product;
    }
    /**
     * Run value through equations via forward propagation
     */
    runInput(inputValue) {
        this.inputValue = inputValue;
        let state = this.states[0];
        for (let i = 0, max = this.states.length; i < max; i++) {
            state = this.states[i];
            if (!state.hasOwnProperty('forwardFn'))
                continue;
            state.forwardFn(state.product, state.left, state.right);
        }
        return state.product;
    }
    /**
     * Run value through equations via back propagation
     */
    backpropagate() {
        let i = this.states.length;
        let state = this.states[0];
        while (i-- > 0) {
            state = this.states[i];
            if (!state.hasOwnProperty('backpropagationFn'))
                continue;
            state.backpropagationFn(state.product, state.left, state.right);
        }
        return state.product;
    }
    /**
     * Run index through equations via back propagation
     */
    backpropagateIndex(rowIndex = 0) {
        this.inputRow = rowIndex;
        let i = this.states.length;
        let state = this.states[0];
        while (i-- > 0) {
            state = this.states[i];
            if (!state.hasOwnProperty('backpropagationFn'))
                continue;
            state.backpropagationFn(state.product, state.left, state.right);
        }
        return state.product;
    }
    /**
     * Predict a target value from equation
     */
    predictTarget(input, target) {
        let errorSum = 0;
        const output = this.runInput(input);
        for (let i = 0; i < output.weights.length; i++) {
            const error = output.weights[i] - target[i];
            // set gradients into log probabilities
            errorSum += Math.abs(error);
            // write gradients into log probabilities
            output.deltas[i] = error;
        }
        return errorSum;
    }
    /**
     * Predict a target index from equation
     */
    predictTargetIndex(input, target) {
        const output = this.runIndex(input);
        // set gradients into log probabilities
        const logProbabilities = output; // interpret output as log probabilities
        const probabilities = softmax(output); // compute the softmax probabilities
        // write gradients into log probabilities
        logProbabilities.deltas = probabilities.weights.slice(0);
        logProbabilities.deltas[target] -= 1;
        // accumulate base 2 log prob and do smoothing
        return -Math.log2(probabilities.weights[target]);
    }
}

function maxI(matrix) {
    // argmax of array w
    const { weights } = matrix;
    let maxv = weights[0];
    let maxix = 0;
    for (let i = 1; i < weights.length; i++) {
        const v = weights[i];
        if (v < maxv)
            continue;
        maxix = i;
        maxv = v;
    }
    return maxix;
}

function sampleI(matrix) {
    // sample argmax from w, assuming w are
    // probabilities that sum to one
    const r = randomFloat(0, 1);
    const w = matrix.weights;
    let x = 0;
    let i = 0;
    while (true) {
        x += w[i];
        if (x > r) {
            return i;
        }
        i++;
    }
}

const trainDefaults$1 = {
    iterations: 20000,
    errorThresh: 0.005,
    log: false,
    logPeriod: 10,
    learningRate: 0.01,
    callbackPeriod: 10,
    timeout: Infinity,
};
const defaults$1 = () => {
    return {
        inputSize: 20,
        inputRange: 20,
        hiddenLayers: [20, 20],
        outputSize: 20,
        decayRate: 0.999,
        smoothEps: 1e-8,
        regc: 0.000001,
        clipval: 5,
        maxPredictionLength: 100,
        dataFormatter: new DataFormatter(),
    };
};
class RNN {
    constructor(options = {}) {
        this.options = { ...defaults$1() };
        this.trainOpts = { ...trainDefaults$1 };
        this.stepCache = {};
        this.runs = 0;
        this.ratioClipped = 0;
        this.model = Object.seal({
            isInitialized: false,
            input: new Matrix(0, 0),
            hiddenLayers: [],
            output: new Matrix(0, 0),
            equations: [],
            allMatrices: [],
            equationConnections: [],
            outputConnector: new RandomMatrix(0, 0, 0.08),
        });
        this.initialLayerInputs = [];
        this.options = { ...this.options, ...options };
        this.updateTrainingOptions({
            ...trainDefaults$1,
        });
        if (options.json) {
            this.fromJSON(options.json);
        }
    }
    initialize() {
        const { dataFormatter } = this.options;
        if (dataFormatter === null || dataFormatter === void 0 ? void 0 : dataFormatter.characters.length) {
            this.options.inputSize = this.options.inputRange = this.options.outputSize =
                dataFormatter.characters.length;
        }
        this.model = this.mapModel();
    }
    createHiddenLayers() {
        const { hiddenLayers, inputSize } = this.options;
        const hiddenLayersModel = [];
        // 0 is end, so add 1 to offset
        hiddenLayersModel.push(this.getHiddenLayer(hiddenLayers[0], inputSize));
        let prevSize = hiddenLayers[0];
        for (let d = 1; d < hiddenLayers.length; d++) {
            // loop over depths
            const hiddenSize = hiddenLayers[d];
            hiddenLayersModel.push(this.getHiddenLayer(hiddenSize, prevSize));
            prevSize = hiddenSize;
        }
        return hiddenLayersModel;
    }
    getHiddenLayer(hiddenSize, prevSize) {
        return {
            // wxh
            weight: new RandomMatrix(hiddenSize, prevSize, 0.08),
            // whh
            transition: new RandomMatrix(hiddenSize, hiddenSize, 0.08),
            // bhh
            bias: new Matrix(hiddenSize, 1),
        };
    }
    getEquation(equation, inputMatrix, previousResult, hiddenLayer) {
        if (!hiddenLayer.weight || !hiddenLayer.transition || !hiddenLayer.bias) {
            throw new Error('hiddenLayer does not have expected properties');
        }
        const relu = equation.relu.bind(equation);
        const add = equation.add.bind(equation);
        const multiply = equation.multiply.bind(equation);
        return relu(add(add(multiply(hiddenLayer.weight, inputMatrix), multiply(hiddenLayer.transition, previousResult)), hiddenLayer.bias));
    }
    createInputMatrix() {
        const { inputRange, inputSize } = this.options;
        if (inputRange < 1)
            throw new Error('this.options.inputRange not an expected number');
        if (inputSize < 1)
            throw new Error('this.options.inputSize not an expected number');
        // 0 is end, so add 1 to offset
        return new RandomMatrix(inputRange + 1, inputSize, 0.08);
    }
    createOutputMatrices() {
        const { outputSize, hiddenLayers } = this.options;
        const lastHiddenSize = last(hiddenLayers);
        // 0 is end, so add 1 to offset
        return {
            // whd
            outputConnector: new RandomMatrix(outputSize + 1, lastHiddenSize, 0.08),
            // 0 is end, so add 1 to offset
            // bd
            output: new Matrix(outputSize + 1, 1),
        };
    }
    bindEquation() {
        const { model } = this;
        const { hiddenLayers } = this.options;
        const equation = new Equation();
        const outputs = [];
        const equationConnection = model.equationConnections.length > 0
            ? last(model.equationConnections)
            : this.initialLayerInputs;
        // 0 index
        let output = this.getEquation(equation, equation.inputMatrixToRow(model.input), equationConnection[0], model.hiddenLayers[0]);
        outputs.push(output);
        // 1+ indices
        for (let i = 1, max = hiddenLayers.length; i < max; i++) {
            if (!equationConnection[i]) {
                throw new Error(`Cannot find equation at index ${i}`);
            }
            output = this.getEquation(equation, output, equationConnection[i], model.hiddenLayers[i]);
            outputs.push(output);
        }
        model.equationConnections.push(outputs);
        equation.add(equation.multiply(model.outputConnector, output), model.output);
        model.equations.push(equation);
    }
    mapModel() {
        const allMatrices = [];
        this.initialLayerInputs = this.options.hiddenLayers.map((size) => new Matrix(size, 1));
        const input = this.createInputMatrix();
        allMatrices.push(input);
        const hiddenLayers = this.createHiddenLayers();
        if (!hiddenLayers.length)
            throw new Error('net.hiddenLayers not set');
        for (let i = 0, max = hiddenLayers.length; i < max; i++) {
            const hiddenMatrix = hiddenLayers[i];
            for (const property in hiddenMatrix) {
                if (!hiddenMatrix.hasOwnProperty(property))
                    continue;
                allMatrices.push(hiddenMatrix[property]);
            }
        }
        const { output, outputConnector } = this.createOutputMatrices();
        allMatrices.push(outputConnector);
        allMatrices.push(output);
        return Object.seal({
            isInitialized: true,
            input,
            hiddenLayers,
            output,
            equations: [],
            allMatrices,
            equationConnections: [],
            outputConnector,
        });
    }
    trainInput(input) {
        this.runs++;
        const { model } = this;
        const max = input.length;
        let log2ppl = 0;
        let equation;
        while (model.equations.length <= input.length + 1) {
            // last is zero
            this.bindEquation();
        }
        for (let inputIndex = -1, inputMax = input.length; inputIndex < inputMax; inputIndex++) {
            // start and end tokens are zeros
            const equationIndex = inputIndex + 1;
            equation = model.equations[equationIndex];
            const source = inputIndex === -1 ? 0 : input[inputIndex] + 1; // first step: start with START token
            const target = inputIndex === max - 1 ? 0 : input[inputIndex + 1] + 1; // last step: end with END token
            log2ppl += equation.predictTargetIndex(source, target);
        }
        return Math.pow(2, log2ppl / (max - 1)) / 100;
    }
    backpropagate(input) {
        let i = input.length;
        const { model } = this;
        const { equations } = model;
        while (i > 0) {
            equations[i].backpropagateIndex(input[i - 1] + 1);
            i--;
        }
        equations[0].backpropagateIndex(0);
    }
    adjustWeights() {
        const { regc, clipval, decayRate, smoothEps } = this.options;
        const { trainOpts, model, stepCache } = this;
        const { learningRate } = trainOpts;
        const { allMatrices } = model;
        let numClipped = 0;
        let numTot = 0;
        for (let matrixIndex = 0; matrixIndex < allMatrices.length; matrixIndex++) {
            const matrix = allMatrices[matrixIndex];
            const { weights, deltas } = matrix;
            if (!(matrixIndex in stepCache)) {
                stepCache[matrixIndex] = zeros$1(matrix.rows * matrix.columns);
            }
            const cache = stepCache[matrixIndex];
            for (let i = 0; i < weights.length; i++) {
                let r = deltas[i];
                const w = weights[i];
                // rmsprop adaptive learning rate
                cache[i] = cache[i] * decayRate + (1 - decayRate) * r * r;
                // gradient clip
                if (r > clipval) {
                    r = clipval;
                    numClipped++;
                }
                else if (r < -clipval) {
                    r = -clipval;
                    numClipped++;
                }
                numTot++;
                // update (and regularize)
                weights[i] =
                    w + (-learningRate * r) / Math.sqrt(cache[i] + smoothEps) - regc * w;
            }
        }
        this.ratioClipped = numClipped / numTot;
    }
    get isRunnable() {
        if (this.model && this.model.equations.length === 0) {
            console.error(`No equations bound, did you run train()?`);
            return false;
        }
        return true;
    }
    checkRunnable() {
        if (!this.isRunnable) {
            throw new Error('Network not runnable');
        }
    }
    run(rawInput = [], isSampleI = false, temperature = 1) {
        const maxPredictionLength = this.options.maxPredictionLength +
            (rawInput !== null ? rawInput.length : 0) +
            (this.options.dataFormatter
                ? this.options.dataFormatter.specialIndexes.length
                : 0);
        this.checkRunnable();
        const input = this.options.dataFormatter && rawInput.length > 0
            ? this.options.dataFormatter.formatDataIn(rawInput)
            : rawInput;
        const { model } = this;
        const output = [];
        let i = 0;
        while (true) {
            const previousIndex = i === 0 ? 0 : i < input.length ? input[i - 1] + 1 : output[i - 1];
            while (model.equations.length <= i) {
                this.bindEquation();
            }
            const equation = model.equations[i];
            // sample predicted letter
            const outputMatrix = equation.runIndex(previousIndex);
            const logProbabilities = new Matrix(model.output.rows, model.output.columns);
            copy(logProbabilities, outputMatrix);
            if (temperature !== 1 && isSampleI) {
                /**
                 * scale log probabilities by temperature and re-normalize
                 * if temperature is high, logProbabilities will go towards zero
                 * and the softmax outputs will be more diffuse. if temperature is
                 * very low, the softmax outputs will be more peaky
                 */
                for (let j = 0, max = logProbabilities.weights.length; j < max; j++) {
                    logProbabilities.weights[j] /= temperature;
                }
            }
            const probs = softmax(logProbabilities);
            const nextIndex = isSampleI ? sampleI(probs) : maxI(probs);
            i++;
            if (nextIndex === 0) {
                // END token predicted, break out
                break;
            }
            if (i >= maxPredictionLength) {
                // something is wrong
                break;
            }
            output.push(nextIndex);
        }
        /**
         * we slice the input length here, not because output contains it, but it will be erroneous as we are sending the
         * network what is contained in input, so the data is essentially guessed by the network what could be next, till it
         * locks in on a value.
         * Kind of like this, values are from input:
         * 0 -> 4 (or in English: "beginning on input" -> "I have no idea? I'll guess what they want next!")
         * 2 -> 2 (oh how interesting, I've narrowed down values...)
         * 1 -> 9 (oh how interesting, I've now know what the values are...)
         * then the output looks like: [4, 2, 9,...]
         * so we then remove the erroneous data to get our true output
         */
        return this.options.dataFormatter.formatDataOut(input, output.slice(input.length).map((value) => value - 1));
    }
    /**
     *
     * Verifies network sizes are initialized
     * If they are not it will initialize them
     */
    verifyIsInitialized() {
        if (!this.model.isInitialized) {
            this.initialize();
        }
    }
    /**
     *
     * @param options
     *    Supports all `trainDefaults` properties
     *    also supports:
     *       learningRate: (number),
     *       momentum: (number),
     *       activation: 'sigmoid', 'relu', 'leaky-relu', 'tanh'
     */
    updateTrainingOptions(options) {
        var _a;
        this.trainOpts = { ...trainDefaults$1, ...options };
        this.validateTrainingOptions(this.trainOpts);
        this.setLogMethod((_a = options.log) !== null && _a !== void 0 ? _a : this.trainOpts.log);
        // TODO: Remove this?
        // this.activation = options.activation || this.activation;
    }
    validateTrainingOptions(options) {
        const validations = {
            iterations: () => {
                const val = options.iterations;
                return typeof val === 'number' && val > 0;
            },
            errorThresh: () => {
                const val = options.errorThresh;
                return typeof val === 'number' && val > 0 && val < 1;
            },
            log: () => {
                const val = options.log;
                return typeof val === 'function' || typeof val === 'boolean';
            },
            logPeriod: () => {
                const val = options.logPeriod;
                return typeof val === 'number' && val > 0;
            },
            learningRate: () => {
                const val = options.learningRate;
                return typeof val === 'number' && val > 0 && val < 1;
            },
            callback: () => {
                const val = options.callback;
                return typeof val === 'function' || val === undefined;
            },
            callbackPeriod: () => {
                const val = options.callbackPeriod;
                return typeof val === 'number' && val > 0;
            },
            timeout: () => {
                const val = options.timeout;
                return typeof val === 'number' && val > 0;
            },
        };
        for (const p in validations) {
            const v = options;
            if (!validations[p]()) {
                throw new Error(`[${p}, ${v[p]}] is out of normal training range, your network will probably not train.`);
            }
        }
    }
    setLogMethod(log) {
        if (typeof log === 'function') {
            this.trainOpts.log = log;
        }
        else if (log) {
            this.trainOpts.log = console.log;
        }
        else {
            this.trainOpts.log = false;
        }
    }
    prepTraining(data, options) {
        var _a;
        this.updateTrainingOptions(options);
        const preparedData = this.options.dataFormatter.format(data);
        const endTime = Date.now() + ((_a = this.trainOpts.timeout) !== null && _a !== void 0 ? _a : 0);
        const status = {
            error: 1,
            iterations: 0,
        };
        this.verifyIsInitialized();
        return {
            preparedData,
            status,
            endTime,
        };
    }
    train(data, trainOpts = {}) {
        var _a;
        this.trainOpts = trainOpts = {
            ...trainDefaults$1,
            ...trainOpts,
        };
        const { iterations, errorThresh, logPeriod, callback, callbackPeriod, } = this.trainOpts;
        const log = trainOpts.log === true ? console.log : trainOpts.log;
        let error = Infinity;
        let i;
        let inputs;
        if ((_a = this.options) === null || _a === void 0 ? void 0 : _a.dataFormatter) {
            inputs = this.options.dataFormatter.format(data);
        }
        else if (Array.isArray(data) &&
            Array.isArray(data[0]) &&
            typeof data[0][0] === 'number') {
            inputs = data;
        }
        else {
            throw new Error('training not in expected format of number[][]');
        }
        this.verifyIsInitialized();
        for (i = 0; i < iterations && error > errorThresh; i++) {
            let sum = 0;
            for (let j = 0; j < inputs.length; j++) {
                const err = this.trainPattern(inputs[j], true);
                sum += err;
            }
            error = sum / data.length;
            if (isNaN(error)) {
                throw new Error('Network error rate is unexpected NaN, check network configurations and try again. Most probably input format is not correct or training data is not enough. ');
            }
            if (log && i % logPeriod === 0) {
                log(`iterations: ${i}, training error: ${error}`);
            }
            if (callback && i % callbackPeriod === 0) {
                callback({ error, iterations: i });
            }
        }
        return {
            error,
            iterations: i,
        };
    }
    addFormat() {
        throw new Error('not yet implemented');
    }
    toJSON() {
        if (!this.model.isInitialized) {
            this.initialize();
        }
        const { model, options } = this;
        return {
            type: this.constructor.name,
            options: { ...options, dataFormatter: options.dataFormatter.toJSON() },
            trainOpts: {
                ...this.trainOpts,
                timeout: this.trainOpts.timeout === Infinity
                    ? 'Infinity'
                    : this.trainOpts.timeout,
            },
            input: model.input.toJSON(),
            hiddenLayers: model.hiddenLayers.map((hiddenLayer) => {
                const layers = {};
                for (const p in hiddenLayer) {
                    if (!hiddenLayer.hasOwnProperty(p))
                        continue;
                    layers[p] = hiddenLayer[p].toJSON();
                }
                return layers;
            }),
            outputConnector: this.model.outputConnector.toJSON(),
            output: this.model.output.toJSON(),
        };
    }
    fromJSON(json) {
        const { options } = json;
        const allMatrices = [];
        const input = Matrix.fromJSON(json.input);
        allMatrices.push(input);
        const hiddenLayers = [];
        json.hiddenLayers.forEach((hiddenLayer) => {
            const layers = {};
            for (const p in hiddenLayer) {
                layers[p] = Matrix.fromJSON(hiddenLayer[p]);
                allMatrices.push(layers[p]);
            }
            hiddenLayers.push(layers);
        });
        const outputConnector = Matrix.fromJSON(json.outputConnector);
        allMatrices.push(outputConnector);
        const output = Matrix.fromJSON(json.output);
        allMatrices.push(output);
        if (options.dataFormatter) {
            this.options = {
                ...defaults$1(),
                ...options,
                dataFormatter: DataFormatter.fromJSON(options.dataFormatter),
            };
        }
        else {
            this.options = {
                ...defaults$1(),
                ...options,
                dataFormatter: new DataFormatter(),
            };
        }
        this.model = Object.seal({
            isInitialized: true,
            input,
            hiddenLayers,
            output,
            allMatrices,
            outputConnector,
            equations: [],
            equationConnections: [],
        });
        this.initialLayerInputs = this.options.hiddenLayers.map((size) => new Matrix(size, 1));
        this.bindEquation();
        return this;
    }
    toFunction(cb) {
        const { model } = this;
        const { equations } = this.model;
        const equation = equations[1];
        const { states } = equation;
        const jsonString = JSON.stringify(this.toJSON());
        function previousConnectionIndex(m) {
            const connection = model.equationConnections[0];
            const { states } = equations[0];
            for (let i = 0, max = states.length; i < max; i++) {
                if (states[i].product === m) {
                    return i;
                }
            }
            return connection.indexOf(m);
        }
        function matrixOrigin(m, stateIndex) {
            for (let i = 0, max = states.length; i < max; i++) {
                const state = states[i];
                if (i === stateIndex) {
                    const j = previousConnectionIndex(m);
                    if (j > -1 && (m === state.left || m === state.right)) {
                        return `typeof prevStates[${j}] === 'object' ? prevStates[${j}].product : new Matrix(${m.rows}, ${m.columns})`;
                    }
                    return `new Matrix(${m.rows}, ${m.columns})`;
                }
                if (m === state.product)
                    return `states[${i}].product`;
                if (m === state.right)
                    return `states[${i}].right`;
                if (m === state.left)
                    return `states[${i}].left`;
            }
            return '';
        }
        function matrixToString(m, stateIndex) {
            if (!m || !m.rows || !m.columns)
                return 'null';
            if (m === model.input)
                return `json.input`;
            if (m === model.outputConnector)
                return `json.outputConnector`;
            if (m === model.output)
                return `json.output`;
            for (let i = 0, max = model.hiddenLayers.length; i < max; i++) {
                const hiddenLayer = model.hiddenLayers[i];
                for (const p in hiddenLayer) {
                    if (!hiddenLayer.hasOwnProperty(p))
                        continue;
                    if (hiddenLayer[p] !== m)
                        continue;
                    return `json.hiddenLayers[${i}].${p}`;
                }
            }
            return matrixOrigin(m, stateIndex);
        }
        function toInner(fnString) {
            // crude, but should be sufficient for now
            // function() { body }
            const fnParts = fnString.toString().split('{');
            fnParts.shift();
            // body }
            const fnBodyString = fnParts.join('{');
            const fnBodyParts = fnBodyString.split('}');
            fnBodyParts.pop();
            // body
            return fnBodyParts
                .join('}')
                .split('\n')
                .join('\n        ')
                .replace('product.deltas[i] = 0;', '')
                .replace('product.deltas[column] = 0;', '')
                .replace('left.deltas[leftIndex] = 0;', '')
                .replace('right.deltas[rightIndex] = 0;', '')
                .replace('product.deltas = left.deltas.slice(0);', '');
        }
        function fileName(fnName) {
            return `src/recurrent/matrix/${fnName.replace(/[A-Z]/g, function (value) {
                return `-${value.toLowerCase()}`;
            })}.js`;
        }
        const statesRaw = [];
        const usedFunctionNames = {};
        const innerFunctionsSwitch = [];
        for (let i = 0, max = states.length; i < max; i++) {
            const state = states[i];
            statesRaw.push(`states[${i}] = {
      name: '${state.forwardFn.name}',
      left: ${state.left ? matrixToString(state.left, i) : 'undefined'},
      right: ${state.right ? matrixToString(state.right, i) : 'undefined'},
      product: ${matrixToString(state.product, i)}
    }`);
            const fnName = state.forwardFn.name;
            if (!usedFunctionNames[fnName]) {
                usedFunctionNames[fnName] = true;
                innerFunctionsSwitch.push(`        case '${fnName}': //compiled from ${fileName(fnName)}
          ${toInner(state.forwardFn.toString())}
          break;`);
            }
        }
        const src = `
  if (typeof rawInput === 'undefined') rawInput = [];
  if (typeof isSampleI === 'undefined') isSampleI = false;
  if (typeof temperature === 'undefined') temperature = 1;
  var json = ${jsonString};
  ${this.options.dataFormatter
            ? `${this.options.dataFormatter.toFunctionString()};
  Object.assign(dataFormatter, json.options.dataFormatter);`
            : ''}
  ${this.options.dataFormatter &&
            typeof this.options.dataFormatter.formatDataIn === 'function'
            ? `const formatDataIn = function (input, output) { ${toInner(this.options.dataFormatter.formatDataIn.toString())} }.bind(dataFormatter);`
            : ''}
  ${this.options.dataFormatter !== null &&
            typeof this.options.dataFormatter.formatDataOut === 'function'
            ? `const formatDataOut = function formatDataOut(input, output) { ${toInner(this.options.dataFormatter.formatDataOut.toString())} }.bind(dataFormatter);`
            : ''}
  var maxPredictionLength =
    ${this.options.maxPredictionLength} +
    rawInput.length +
    ${this.options.dataFormatter
            ? this.options.dataFormatter.specialIndexes.length
            : 0};
  var input = ${this.options.dataFormatter &&
            typeof this.options.dataFormatter.formatDataIn === 'function'
            ? 'formatDataIn(rawInput)'
            : 'rawInput'};
  var _i = 0;
  var output = [];
  var states = [];
  var prevStates;
  while (true) {
    var previousIndex = (_i === 0
        ? 0
        : _i < input.length
          ? input[_i - 1] + 1
          : output[_i - 1])
          ;
    var rowPluckIndex = previousIndex;
    prevStates = states;
    states = [];
    ${statesRaw.join(';\n    ')};
    for (var stateIndex = 0, stateMax = ${statesRaw.length}; stateIndex < stateMax; stateIndex++) {
      var state = states[stateIndex];
      var product = state.product;
      var left = state.left;
      var right = state.right;
      switch (state.name) {
${innerFunctionsSwitch.join('\n')}
      }
    }

    var logProbabilities = state.product;
    if (temperature !== 1 && isSampleI) {
      for (var q = 0, nq = logProbabilities.weights.length; q < nq; q++) {
        logProbabilities.weights[q] /= temperature;
      }
    }

    var probs = softmax(logProbabilities);
    var nextIndex = isSampleI ? sampleI(probs) : maxI(probs);

    _i++;
    if (nextIndex === 0) {
      break;
    }
    if (_i >= maxPredictionLength) {
      break;
    }

    output.push(nextIndex);
  }
  ${this.options.dataFormatter &&
            typeof this.options.dataFormatter.formatDataOut === 'function'
            ? 'return formatDataOut(input, output.slice(input.length).map(function(value) { return value - 1; }))'
            : 'return output.slice(input.length).map(function(value) { return value - 1; })'};
  function Matrix(rows, columns) {
    this.rows = rows;
    this.columns = columns;
    this.weights = zeros(rows * columns);
  }
  ${zeros$1.toString()}
  ${softmax.toString().replace('_1.Matrix', 'Matrix')}
  ${randomFloat.toString()}
  ${sampleI.toString()}
  ${maxI.toString()}`;
        // eslint-disable-next-line
        return new Function('rawInput', 'isSampleI', 'temperature', cb ? cb(src) : src);
    }
    trainPattern(input, logErrorRate) {
        const error = this.trainInput(input);
        this.backpropagate(input);
        this.adjustWeights();
        if (logErrorRate) {
            return error;
        }
        return 0;
    }
}
function last(values) {
    return values[values.length - 1];
}

class GRU extends RNN {
    getHiddenLayer(hiddenSize, prevSize) {
        return getGRUHiddenLayer(hiddenSize, prevSize);
    }
    getEquation(equation, inputMatrix, previousResult, hiddenLayer) {
        return getGRUEquation(equation, inputMatrix, previousResult, hiddenLayer);
    }
}
function getGRUHiddenLayer(hiddenSize, prevSize) {
    return {
        // update Gate
        // wzxh
        updateGateInputMatrix: new RandomMatrix(hiddenSize, prevSize, 0.08),
        updateGateHiddenMatrix: new RandomMatrix(hiddenSize, hiddenSize, 0.08),
        updateGateBias: new Matrix(hiddenSize, 1),
        // reset Gate
        // wrxh
        resetGateInputMatrix: new RandomMatrix(hiddenSize, prevSize, 0.08),
        resetGateHiddenMatrix: new RandomMatrix(hiddenSize, hiddenSize, 0.08),
        resetGateBias: new Matrix(hiddenSize, 1),
        // cell write parameters
        // wcxh
        cellWriteInputMatrix: new RandomMatrix(hiddenSize, prevSize, 0.08),
        cellWriteHiddenMatrix: new RandomMatrix(hiddenSize, hiddenSize, 0.08),
        cellWriteBias: new Matrix(hiddenSize, 1),
    };
}
function getGRUEquation(equation, inputMatrix, previousResult, hiddenLayer) {
    if (!hiddenLayer.updateGateInputMatrix ||
        !hiddenLayer.updateGateHiddenMatrix ||
        !hiddenLayer.updateGateBias ||
        !hiddenLayer.resetGateInputMatrix ||
        !hiddenLayer.resetGateHiddenMatrix ||
        !hiddenLayer.resetGateBias ||
        !hiddenLayer.cellWriteInputMatrix ||
        !hiddenLayer.cellWriteHiddenMatrix ||
        !hiddenLayer.cellWriteBias) {
        throw new Error('hiddenLayer does not have expected properties');
    }
    const sigmoid = equation.sigmoid.bind(equation);
    const add = equation.add.bind(equation);
    const multiply = equation.multiply.bind(equation);
    const multiplyElement = equation.multiplyElement.bind(equation);
    const tanh = equation.tanh.bind(equation);
    const allOnes = equation.allOnes.bind(equation);
    const cloneNegative = equation.cloneNegative.bind(equation);
    // update gate
    const updateGate = sigmoid(add(add(multiply(hiddenLayer.updateGateInputMatrix, inputMatrix), multiply(hiddenLayer.updateGateHiddenMatrix, previousResult)), hiddenLayer.updateGateBias));
    // reset gate
    const resetGate = sigmoid(add(add(multiply(hiddenLayer.resetGateInputMatrix, inputMatrix), multiply(hiddenLayer.resetGateHiddenMatrix, previousResult)), hiddenLayer.resetGateBias));
    // cell
    const cell = tanh(add(add(multiply(hiddenLayer.cellWriteInputMatrix, inputMatrix), multiply(hiddenLayer.cellWriteHiddenMatrix, multiplyElement(resetGate, previousResult))), hiddenLayer.cellWriteBias));
    // compute hidden state as gated, saturated cell activations
    // negate updateGate
    return add(multiplyElement(add(allOnes(updateGate.rows, updateGate.columns), cloneNegative(updateGate)), cell), multiplyElement(previousResult, updateGate));
}

class ArrayLookupTable {
    constructor(data, prop) {
        this.prop = prop;
        this.length = 0;
        this.table = {};
        for (let i = 0; i < data.length; i++) {
            const datum = data[i];
            const ioValue = datum[prop];
            for (let j = 0; j < ioValue.length; j++) {
                const value = ioValue[j];
                for (const p in value) {
                    if (!value.hasOwnProperty(p))
                        continue;
                    if (this.table.hasOwnProperty(p))
                        continue;
                    this.table[p] = this.length++;
                }
            }
        }
    }
}

const defaults = () => {
    return {
        ...defaults$1(),
        inputSize: 1,
        hiddenLayers: [20],
        outputSize: 1,
        inputRange: 0,
    };
};
class RNNTimeStep extends RNN {
    constructor(options = {}) {
        super();
        this.inputLookupLength = 0;
        this.inputLookup = null;
        this.outputLookup = null;
        this.outputLookupLength = 0;
        // eslint-disable-next-line @typescript-eslint/ban-ts-comment
        // @ts-expect-error
        this.model = Object.seal({
            isInitialized: false,
            hiddenLayers: [],
            output: new Matrix(0, 0),
            equations: [],
            allMatrices: [],
            equationConnections: [],
            outputConnector: new RandomMatrix(0, 0, 0.08),
        });
        // eslint-disable-next-line @typescript-eslint/ban-ts-comment
        // @ts-expect-error
        this.options = defaults();
        this.options = { ...this.options, ...options };
        this.updateTrainingOptions({
            ...trainDefaults,
            ...options,
        });
        if (options.json) {
            this.fromJSON(options.json);
        }
    }
    createInputMatrix() {
        throw new Error('Input Matrices do not exist on RNNTimeStep');
    }
    createOutputMatrices() {
        const { outputSize } = this.options;
        const lastHiddenSize = last(this.options.hiddenLayers);
        // whd
        const outputConnector = new RandomMatrix(outputSize, lastHiddenSize, 0.08);
        // bd
        const output = new RandomMatrix(outputSize, 1, 0.08);
        return { output, outputConnector };
    }
    bindEquation() {
        const { model, options } = this;
        const { hiddenLayers, inputSize } = options;
        const layers = model.hiddenLayers;
        const equation = new Equation();
        const outputs = [];
        const equationConnection = model.equationConnections.length > 0
            ? model.equationConnections[model.equationConnections.length - 1]
            : this.initialLayerInputs;
        // 0 index
        let output = this.getEquation(equation, equation.input(new Matrix(inputSize, 1)), equationConnection[0], layers[0]);
        outputs.push(output);
        // 1+ indices
        for (let i = 1, max = hiddenLayers.length; i < max; i++) {
            output = this.getEquation(equation, output, equationConnection[i], layers[i]);
            outputs.push(output);
        }
        model.equationConnections.push(outputs);
        equation.add(equation.multiply(model.outputConnector, output), model.output);
        model.equations.push(equation);
    }
    initialize() {
        this.model = this.mapModel();
    }
    // eslint-disable-next-line @typescript-eslint/ban-ts-comment
    // @ts-expect-error
    mapModel() {
        const allMatrices = [];
        this.initialLayerInputs = this.options.hiddenLayers.map((size) => new Matrix(size, 1));
        const hiddenLayers = this.createHiddenLayers();
        for (let i = 0, max = hiddenLayers.length; i < max; i++) {
            const hiddenMatrix = hiddenLayers[i];
            for (const property in hiddenMatrix) {
                if (!hiddenMatrix.hasOwnProperty(property))
                    continue;
                allMatrices.push(hiddenMatrix[property]);
            }
        }
        const { outputConnector, output } = this.createOutputMatrices();
        allMatrices.push(outputConnector);
        allMatrices.push(output);
        return Object.seal({
            isInitialized: true,
            hiddenLayers,
            output,
            equations: [],
            allMatrices,
            equationConnections: [],
            outputConnector,
        });
    }
    backpropagate() {
        for (let i = this.model.equations.length - 1; i > -1; i--) {
            this.model.equations[i].backpropagate();
        }
    }
    // eslint-disable-next-line @typescript-eslint/ban-ts-comment
    // @ts-expect-error
    run(rawInput) {
        const shape = lookup.dataShape(rawInput).join(',');
        switch (shape) {
            case 'array,number':
                // eslint-disable-next-line @typescript-eslint/ban-ts-comment
                // @ts-expect-error
                return this.runArray(rawInput);
            case 'array,array,number':
                // eslint-disable-next-line @typescript-eslint/ban-ts-comment
                // @ts-expect-error
                return this.runArrayOfArray(rawInput);
            case 'object,number':
                // eslint-disable-next-line @typescript-eslint/ban-ts-comment
                // @ts-expect-error
                return this.runObject(rawInput); // Backward compatibility, will be result of `unknown` and need casting.  Better to just use net.runObject() directly
            case 'array,object,number':
                // eslint-disable-next-line @typescript-eslint/ban-ts-comment
                // @ts-expect-error
                return this.runArrayOfObject(rawInput);
            default:
                throw new Error(`Unrecognized data shape ${shape}`);
        }
    }
    forecast(rawInput, count = 1) {
        const shape = lookup.dataShape(rawInput).join(',');
        switch (shape) {
            case 'array,number':
                // eslint-disable-next-line @typescript-eslint/ban-ts-comment
                // @ts-expect-error
                return this.forecastArray(rawInput, count);
            case 'array,array,number':
                // eslint-disable-next-line @typescript-eslint/ban-ts-comment
                // @ts-expect-error
                return this.forecastArrayOfArray(rawInput, count);
            case 'object,number':
                // eslint-disable-next-line @typescript-eslint/ban-ts-comment
                // @ts-expect-error
                return this.runObject(rawInput);
            case 'array,object,number':
                // eslint-disable-next-line @typescript-eslint/ban-ts-comment
                // @ts-expect-error
                return this.forecastArrayOfObject(rawInput, count);
            default:
                throw new Error(`Unrecognized data shape ${shape}`);
        }
    }
    forecastArray(input, count = 1) {
        this.checkRunnable();
        const { model } = this;
        const { equations } = model;
        const length = input.length + count;
        while (equations.length <= length) {
            this.bindEquation();
        }
        let lastOutput;
        let equationIndex = 0;
        if (this.options.inputSize === 1) {
            for (let i = 0; i < input.length; i++) {
                lastOutput = equations[equationIndex++].runInput(Float32Array.from([input[i]]));
            }
        }
        else {
            for (let i = 0; i < input.length; i++) {
                lastOutput = equations[equationIndex++].runInput(Float32Array.from([]));
            }
        }
        if (!lastOutput) {
            throw new Error('lastOutput not set');
        }
        const result = [lastOutput.weights[0]];
        for (let i = 0, max = count - 1; i < max; i++) {
            lastOutput = equations[equationIndex++].runInput(lastOutput.weights);
            result.push(lastOutput.weights[0]);
        }
        this.end();
        return Float32Array.from(result);
    }
    forecastArrayOfArray(input, count = 1) {
        this.checkRunnable();
        const { model } = this;
        const { equations } = model;
        const length = input.length + count;
        while (equations.length <= length) {
            this.bindEquation();
        }
        let lastOutput;
        let equationIndex = 0;
        for (let i = 0; i < input.length; i++) {
            lastOutput = equations[equationIndex++].runInput(input[i]);
        }
        if (!lastOutput) {
            throw new Error('lastOutput not set');
        }
        const result = [Float32Array.from(lastOutput.weights)];
        for (let i = 0, max = count - 1; i < max; i++) {
            lastOutput = equations[equationIndex++].runInput(lastOutput.weights);
            result.push(Float32Array.from(lastOutput.weights.slice(0)));
        }
        this.end();
        return result;
    }
    forecastArrayOfObject(input, count = 1) {
        if (!this.inputLookup) {
            throw new Error('this.inputLookup not set');
        }
        if (!this.outputLookup) {
            throw new Error('this.outputLookup not set');
        }
        const formattedData = input.map((value) => lookup.toArray(this.inputLookup, value, this.inputLookupLength));
        return this.forecastArrayOfArray(formattedData, count).map((value) => lookup.toObject(this.outputLookup, value));
    }
    // eslint-disable-next-line @typescript-eslint/ban-ts-comment
    // @ts-expect-error
    train(data, trainOpts = {}) {
        this.trainOpts = trainOpts = {
            ...trainDefaults$1,
            ...trainOpts,
        };
        // Don't destructure here because this.setSize() can reset this.options.
        if (this.options.inputSize === 1 && this.options.outputSize === 1) {
            this.setSize(data);
        }
        this.verifySize();
        const formattedData = this.formatData(data);
        let error = Infinity;
        let i;
        this.verifyIsInitialized();
        const { iterations, errorThresh, logPeriod, callback, callbackPeriod, } = this.trainOpts;
        const log = trainOpts.log === true ? console.log : trainOpts.log;
        for (i = 0; i < iterations && error > errorThresh; i++) {
            let sum = 0;
            for (let j = 0; j < formattedData.length; j++) {
                const err = this.trainPattern(formattedData[j], true);
                sum += err;
            }
            error = sum / formattedData.length;
            if (isNaN(error))
                throw new Error('Network error rate is unexpected NaN, check network configurations and try again. Most probably input format is not correct or training data is not enough. ');
            if (log && i % logPeriod === 0) {
                log(`iterations: ${i}, training error: ${error}`);
            }
            if (callback && i % callbackPeriod === 0) {
                callback({ error, iterations: i });
            }
        }
        return {
            error,
            iterations: i,
        };
    }
    trainArrayOfArray(input) {
        if (input.length < 2) {
            throw new Error('input must be an array of 2 or more');
        }
        const { equations } = this.model;
        while (equations.length < input.length) {
            this.bindEquation();
        }
        let errorSum = 0;
        for (let i = 0, max = input.length - 1; i < max; i++) {
            errorSum += equations[i].predictTarget(input[i], input[i + 1]);
        }
        this.end();
        return errorSum / input.length;
    }
    // eslint-disable-next-line @typescript-eslint/ban-ts-comment
    // @ts-expect-error
    trainPattern(input, logErrorRate) {
        const error = this.trainArrayOfArray(input);
        this.backpropagate();
        this.adjustWeights();
        if (logErrorRate) {
            return error;
        }
        return 0;
    }
    setSize(data) {
        let size = 0;
        const dataShape = lookup.dataShape(data).join(',');
        switch (dataShape) {
            case 'array,array,number':
            case 'array,object,number':
            case 'array,datum,array,number':
            case 'array,datum,object,number':
                size = 1;
                // probably 1
                break;
            case 'array,array,array,number':
                size = data[0][0].length;
                break;
            case 'array,array,object,number':
                // inputs and outputs should match
                size = Object.keys(lookup.toTable2D(data)).length;
                break;
            case 'array,datum,array,array,number':
                size = data[0].input[0].length;
                break;
            case 'array,datum,array,object,number':
                size = Object.keys(lookup.toInputTable2D(data)).length;
                break;
            default:
                throw new Error('unknown data shape or configuration');
        }
        this.options = Object.seal({
            ...this.options,
            inputSize: size,
            outputSize: size,
        });
    }
    verifySize() {
        if (this.options.inputSize || this.options.outputSize) {
            if (this.options.inputSize !== this.options.outputSize) {
                throw new Error('manually set inputSize and outputSize mismatch');
            }
        }
    }
    runArray(input) {
        this.checkRunnable();
        const { equations } = this.model;
        while (equations.length <= input.length) {
            this.bindEquation();
        }
        let lastOutput;
        for (let i = 0; i < input.length; i++) {
            lastOutput = equations[i].runInput(new Float32Array([input[i]]));
        }
        this.end();
        return lastOutput.weights[0];
    }
    runArrayOfArray(input) {
        this.checkRunnable();
        const { model } = this;
        const { equations } = model;
        while (equations.length <= input.length) {
            this.bindEquation();
        }
        let lastOutput;
        for (let i = 0; i < input.length; i++) {
            const outputMatrix = equations[i].runInput(input[i]);
            lastOutput = outputMatrix.weights;
        }
        this.end();
        return lastOutput !== null && lastOutput !== void 0 ? lastOutput : Float32Array.from([]);
    }
    runObject(input) {
        if (!this.inputLookup) {
            throw new Error('this.inputLookup not set');
        }
        if (!this.outputLookup) {
            throw new Error('this.outputLookup not set');
        }
        if (!this.outputLookupLength) {
            throw new Error('this.outputLookupLength not set');
        }
        if (this.inputLookup === this.outputLookup) {
            const inputArray = lookup.toArrayShort(this.inputLookup, input);
            return lookup.toObjectPartial(this.outputLookup, this.forecastArray(inputArray, this.outputLookupLength - inputArray.length), inputArray.length);
        }
        return lookup.toObject(this.outputLookup, this.forecastArray(lookup.toArray(this.inputLookup, input, this.inputLookupLength), this.outputLookupLength));
    }
    runArrayOfObject(input) {
        if (this.inputLookup === null) {
            throw new Error('this.inputLookup not set');
        }
        if (this.outputLookup === null) {
            throw new Error('this.outputLookup not set');
        }
        const formattedInput = input.map((value) => lookup.toArray(this.inputLookup, value, this.inputLookupLength));
        return this.forecastArrayOfArray(formattedInput, 1).map((value) => lookup.toObject(this.outputLookup, value))[0];
    }
    runArrayOfObjectOfArray(input) {
        if (!this.inputLookup) {
            throw new Error('this.inputLookup not set');
        }
        if (!this.outputLookup) {
            throw new Error('this.outputLookup not set');
        }
        return lookup.toObject(this.outputLookup, this.runArrayOfArray(lookup.toArrays(this.inputLookup, input, this.inputLookupLength)));
    }
    end() {
        this.model.equations[this.model.equations.length - 1].runInput(new Float32Array(this.options.outputSize));
    }
    requireInputOutputOfOne() {
        if (this.options.inputSize !== 1) {
            throw new Error('inputSize must be 1 for this data size');
        }
        if (this.options.outputSize !== 1) {
            throw new Error('outputSize must be 1 for this data size');
        }
    }
    // Handles data shape of 'array,number'
    formatArray(data) {
        const result = [];
        this.requireInputOutputOfOne();
        for (let i = 0; i < data.length; i++) {
            result.push(Float32Array.from([data[i]]));
        }
        return [result];
    }
    // Handles data shape of 'array,array,number'
    formatArrayOfArray(data) {
        const result = [];
        const { inputSize, outputSize } = this.options;
        if (inputSize === 1 && outputSize === 1) {
            for (let i = 0; i < data.length; i++) {
                result.push(arrayToFloat32Arrays(data[i]));
            }
            return result;
        }
        if (inputSize !== data[0].length) {
            throw new Error('inputSize must match data input size');
        }
        if (outputSize !== data[0].length) {
            throw new Error('outputSize must match data output size');
        }
        for (let i = 0; i < data.length; i++) {
            result.push(Float32Array.from(data[i]));
        }
        return [result];
    }
    // Handles data shape of 'array,object,number'
    formatArrayOfObject(data) {
        this.requireInputOutputOfOne();
        if (!this.inputLookup) {
            const lookupTable = new LookupTable(data);
            this.inputLookup = this.outputLookup = lookupTable.table;
            this.inputLookupLength = this.outputLookupLength = lookupTable.length;
        }
        const result = [];
        for (let i = 0; i < data.length; i++) {
            result.push(objectToFloat32Arrays(data[i]));
        }
        return result;
    }
    // Handles data shape of 'array,object,number' when this.options.inputSize > 1
    formatArrayOfObjectMulti(data) {
        if (!this.inputLookup) {
            const lookupTable = new LookupTable(data);
            this.inputLookup = this.outputLookup = lookupTable.table;
            this.inputLookupLength = this.outputLookupLength = lookupTable.length;
        }
        const result = [];
        for (let i = 0; i < data.length; i++) {
            result.push([
                objectToFloat32Array(data[i], this.inputLookup, this.inputLookupLength),
            ]);
        }
        return result;
    }
    // Handles data shape of 'array,datum,array,number'
    formatArrayOfDatumOfArray(data) {
        const result = [];
        this.requireInputOutputOfOne();
        for (let i = 0; i < data.length; i++) {
            const datum = data[i];
            result.push(inputOutputArrayToFloat32Arrays(datum.input, datum.output));
        }
        return result;
    }
    // Handles data shape of 'array,datum,object,number'
    formatArrayOfDatumOfObject(data) {
        this.requireInputOutputOfOne();
        if (!this.inputLookup) {
            const inputLookup = new LookupTable(data, 'input');
            this.inputLookup = inputLookup.table;
            this.inputLookupLength = inputLookup.length;
        }
        if (!this.outputLookup) {
            const outputLookup = new LookupTable(data, 'output');
            this.outputLookup = outputLookup.table;
            this.outputLookupLength = outputLookup.length;
        }
        const result = [];
        for (let i = 0; i < data.length; i++) {
            const datum = data[i];
            result.push(inputOutputObjectToFloat32Arrays(datum.input, datum.output));
        }
        return result;
    }
    // Handles data shape of 'array,array,array,number'
    formatArrayOfArrayOfArray(data) {
        const result = [];
        for (let i = 0; i < data.length; i++) {
            result.push(arraysToFloat32Arrays(data[i]));
        }
        return result;
    }
    // Handles data shape of 'array,array,object,number'
    formatArrayOfArrayOfObject(data) {
        if (!this.inputLookup) {
            const lookupTable = new LookupTable(data);
            this.inputLookup = this.outputLookup = lookupTable.table;
            this.inputLookupLength = this.outputLookupLength = lookupTable.length;
        }
        const result = [];
        for (let i = 0; i < data.length; i++) {
            const array = [];
            for (let j = 0; j < data[i].length; j++) {
                array.push(objectToFloat32Array(data[i][j], this.inputLookup, this.inputLookupLength));
            }
            result.push(array);
        }
        return result;
    }
    // Handles data shape of 'array,datum,array,array,number'
    formatArrayOfDatumOfArrayOfArray(data) {
        const result = [];
        const { inputSize, outputSize } = this.options;
        if (inputSize !== data[0].input[0].length) {
            throw new Error('inputSize must match data input size');
        }
        if (outputSize !== data[0].output[0].length) {
            throw new Error('outputSize must match data output size');
        }
        for (let i = 0; i < data.length; i++) {
            const datum = data[i];
            result.push(inputOutputArraysToFloat32Arrays(datum.input, datum.output));
        }
        return result;
    }
    // 'Handles data shape of array,datum,array,object,number'
    formatArrayOfDatumOfArrayOfObject(data) {
        if (!this.inputLookup) {
            const inputLookup = new ArrayLookupTable(data, 'input');
            this.inputLookup = inputLookup.table;
            this.inputLookupLength = inputLookup.length;
        }
        if (!this.outputLookup) {
            const outputLookup = new ArrayLookupTable(data, 'output');
            this.outputLookup = outputLookup.table;
            this.outputLookupLength = outputLookup.length;
        }
        if (!this.outputLookupLength) {
            throw new Error('this.outputLookupLength not set to usable number');
        }
        const result = [];
        for (let i = 0; i < data.length; i++) {
            const datum = data[i];
            result.push(inputOutputObjectsToFloat32Arrays(datum.input, datum.output, this.inputLookup, this.outputLookup, this.inputLookupLength, this.outputLookupLength));
        }
        return result;
    }
    formatData(data) {
        const dataShape = lookup.dataShape(data).join(',');
        switch (dataShape) {
            case 'array,number':
                return this.formatArray(data);
            case 'array,array,number':
                return this.formatArrayOfArray(data);
            case 'array,object,number':
                if (this.options.inputSize === 1) {
                    return this.formatArrayOfObject(data);
                }
                else {
                    return this.formatArrayOfObjectMulti(data);
                }
            case 'array,datum,array,number':
                return this.formatArrayOfDatumOfArray(data);
            case 'array,datum,object,number':
                return this.formatArrayOfDatumOfObject(data);
            case 'array,array,array,number':
                return this.formatArrayOfArrayOfArray(data);
            case 'array,array,object,number':
                return this.formatArrayOfArrayOfObject(data);
            case 'array,datum,array,array,number':
                return this.formatArrayOfDatumOfArrayOfArray(data);
            case 'array,datum,array,object,number':
                return this.formatArrayOfDatumOfArrayOfObject(data);
            default:
                throw new Error('unknown data shape or configuration');
        }
    }
    test(data) {
        // for classification problems
        const misclasses = [];
        // run each pattern through the trained network and collect
        // error and misclassification statistics
        let errorSum = 0;
        const formattedData = this.formatData(data);
        for (let i = 0; i < formattedData.length; i++) {
            const input = formattedData[i];
            const output = this.run(input.splice(0, input.length - 1));
            const target = input[input.length - 1];
            let errors = 0;
            let errorCount = 0;
            for (let j = 0; j < output.length; j++) {
                errorCount++;
                const error = target[j] - output[j];
                // mse
                errors += error * error;
            }
            errorSum += errors / errorCount;
            const errorsAbs = Math.abs(errors);
            if (errorsAbs > this.trainOpts.errorThresh) {
                const misclass = data[i];
                misclasses.push({
                    value: misclass,
                    actual: output,
                });
            }
        }
        return {
            error: errorSum / formattedData.length,
            misclasses,
            total: formattedData.length,
        };
    }
    // eslint-disable-next-line @typescript-eslint/ban-ts-comment
    // @ts-expect-error
    addFormat(value) {
        var _a, _b, _c, _d, _e, _f;
        const dataShape = lookup.dataShape(value).join(',');
        switch (dataShape) {
            case 'array,array,number':
            case 'datum,array,array,number':
            case 'array,number':
            case 'datum,array,number':
                return;
            case 'datum,object,number': {
                this.inputLookup = lookup.addKeys(value.input, (_a = this.inputLookup) !== null && _a !== void 0 ? _a : {});
                if (this.inputLookup) {
                    this.inputLookupLength = Object.keys(this.inputLookup).length;
                }
                this.outputLookup = lookup.addKeys(value.output, (_b = this.outputLookup) !== null && _b !== void 0 ? _b : {});
                if (this.outputLookup) {
                    this.outputLookupLength = Object.keys(this.outputLookup).length;
                }
                break;
            }
            case 'object,number': {
                this.inputLookup = this.outputLookup = lookup.addKeys(value, (_c = this.inputLookup) !== null && _c !== void 0 ? _c : {});
                if (this.inputLookup) {
                    this.inputLookupLength = this.outputLookupLength = Object.keys(this.inputLookup).length;
                }
                break;
            }
            case 'array,object,number': {
                const typedValue = value;
                for (let i = 0; i < typedValue.length; i++) {
                    this.inputLookup = this.outputLookup = lookup.addKeys(typedValue[i], (_d = this.inputLookup) !== null && _d !== void 0 ? _d : {});
                    if (this.inputLookup) {
                        this.inputLookupLength = this.outputLookupLength = Object.keys(this.inputLookup).length;
                    }
                }
                break;
            }
            case 'datum,array,object,number': {
                const typedValue = value;
                const typedInput = typedValue.input;
                for (let i = 0; i < typedInput.length; i++) {
                    this.inputLookup = lookup.addKeys(typedInput[i], (_e = this.inputLookup) !== null && _e !== void 0 ? _e : {});
                    if (this.inputLookup) {
                        this.inputLookupLength = Object.keys(this.inputLookup).length;
                    }
                }
                const typedOutput = typedValue.output;
                for (let i = 0; i < typedOutput.length; i++) {
                    this.outputLookup = lookup.addKeys(typedOutput[i], (_f = this.outputLookup) !== null && _f !== void 0 ? _f : {});
                    if (this.outputLookup) {
                        this.outputLookupLength = Object.keys(this.outputLookup).length;
                    }
                }
                break;
            }
            default:
                throw new Error('unknown data shape or configuration');
        }
    }
    // eslint-disable-next-line @typescript-eslint/ban-ts-comment
    // @ts-expect-error
    toJSON() {
        if (!this.model) {
            this.initialize();
        }
        const { model } = this;
        const options = { ...this.options, ...defaults$1 };
        return {
            type: this.constructor.name,
            options,
            hiddenLayers: model.hiddenLayers.map((hiddenLayer) => {
                const layers = {};
                for (const p in hiddenLayer) {
                    if (!hiddenLayer.hasOwnProperty(p))
                        continue;
                    layers[p] = hiddenLayer[p].toJSON();
                }
                return layers;
            }),
            outputConnector: model.outputConnector.toJSON(),
            output: model.output.toJSON(),
            inputLookup: this.inputLookup,
            inputLookupLength: this.inputLookupLength,
            outputLookup: this.outputLookup,
            outputLookupLength: this.outputLookupLength,
        };
    }
    // eslint-disable-next-line @typescript-eslint/ban-ts-comment
    // @ts-expect-error
    fromJSON(json) {
        const { options } = json;
        const allMatrices = [];
        const hiddenLayers = [];
        // backward compatibility for hiddenSizes
        json.hiddenLayers.forEach((hiddenLayer) => {
            const layers = {};
            for (const p in hiddenLayer) {
                layers[p] = Matrix.fromJSON(hiddenLayer[p]);
                allMatrices.push(layers[p]);
            }
            hiddenLayers.push(layers);
        });
        const outputConnector = Matrix.fromJSON(json.outputConnector);
        allMatrices.push(outputConnector);
        const output = Matrix.fromJSON(json.output);
        allMatrices.push(output);
        // eslint-disable-next-line @typescript-eslint/ban-ts-comment
        // @ts-expect-error
        this.options = { ...defaults(), ...options };
        this.inputLookup = json.inputLookup;
        this.inputLookupLength = json.inputLookupLength;
        this.outputLookup = json.outputLookup;
        this.outputLookupLength = json.outputLookupLength;
        this.model = Object.seal({
            isInitialized: true,
            hiddenLayers,
            output,
            allMatrices,
            outputConnector,
            equations: [],
            equationConnections: [],
        });
        this.initialLayerInputs = options.hiddenLayers.map((size) => new Matrix(size, 1));
        this.bindEquation();
        return this;
    }
    // eslint-disable-next-line @typescript-eslint/ban-ts-comment
    // @ts-expect-error
    toFunction(cb) {
        const { model, inputLookup, inputLookupLength, outputLookup, outputLookupLength, } = this;
        const { inputSize } = this.options;
        const { equations } = model;
        const equation = equations[1];
        const { states } = equation;
        const jsonString = JSON.stringify(this.toJSON());
        function previousConnectionIndex(m) {
            const connection = model.equationConnections[0];
            const { states } = equations[0];
            for (let i = 0, max = states.length; i < max; i++) {
                if (states[i].product === m) {
                    return i;
                }
            }
            return connection.indexOf(m);
        }
        function matrixOrigin(m, stateIndex) {
            for (let i = 0, max = states.length; i < max; i++) {
                const state = states[i];
                if (i === stateIndex) {
                    const j = previousConnectionIndex(m);
                    switch (m) {
                        case state.left:
                            if (j > -1) {
                                return `typeof prevStates[${j}] === 'object' ? prevStates[${j}].product : new Matrix(${m.rows}, ${m.columns})`;
                            }
                        // eslint-disable-next-line no-fallthrough
                        case state.right:
                            if (j > -1) {
                                return `typeof prevStates[${j}] === 'object' ? prevStates[${j}].product : new Matrix(${m.rows}, ${m.columns})`;
                            }
                        // eslint-disable-next-line no-fallthrough
                        case state.product:
                            return `new Matrix(${m.rows}, ${m.columns})`;
                        default:
                            throw Error('unknown state');
                    }
                }
                if (m === state.product)
                    return `states[${i}].product`;
                if (m === state.right)
                    return `states[${i}].right`;
                if (m === state.left)
                    return `states[${i}].left`;
            }
            return '';
        }
        function matrixToString(m, stateIndex) {
            if (!m || !m.rows || !m.columns)
                return 'null';
            if (m === model.outputConnector)
                return `json.outputConnector`;
            if (m === model.output)
                return `json.output`;
            for (let i = 0, max = model.hiddenLayers.length; i < max; i++) {
                const hiddenLayer = model.hiddenLayers[i];
                for (const p in hiddenLayer) {
                    if (!hiddenLayer.hasOwnProperty(p))
                        continue;
                    if (hiddenLayer[p] !== m)
                        continue;
                    return `json.hiddenLayers[${i}].${p}`;
                }
            }
            return matrixOrigin(m, stateIndex);
        }
        function formatInputData() {
            if (!inputLookup)
                return '';
            if (inputSize === 1) {
                if (inputLookup === outputLookup) {
                    return `function lookupInput(input) {
            var table = ${JSON.stringify(inputLookup)};
            var result = [];
            for (var p in table) {
              if (!input.hasOwnProperty(p)) break;
              result.push(Float32Array.from([input[p]]));
            }
            return result;
          }`;
                }
                return `function lookupInput(input) {
          var table = ${JSON.stringify(inputLookup)};
          var result = [];
          for (var p in table) {
            result.push(Float32Array.from([input[p]]));
          }
          return result;
        }`;
            }
            return `function lookupInput(rawInputs) {
        var table = ${JSON.stringify(inputLookup)};
        var result = [];
        for (var i = 0; i < rawInputs.length; i++) {
          var rawInput = rawInputs[i];
          var input = new Float32Array(${inputLookupLength});
          for (var p in table) {
            input[table[p]] = rawInput.hasOwnProperty(p) ? rawInput[p] : 0;
          }
          result.push(input);
        }
        return result;
      }`;
        }
        function formatOutputData() {
            if (!outputLookup)
                return '';
            if (inputSize === 1) {
                if (inputLookup === outputLookup) {
                    return `function lookupOutputPartial(output, input) {
            var table = ${JSON.stringify(outputLookup)};
            var offset = input.length;
            var result = {};
            var i = 0;
            for (var p in table) {
              if (i++ < offset) continue;
              result[p] = output[table[p] - offset][0];
            }
            return result;
          }`;
                }
                return `function lookupOutput(output) {
          var table = ${JSON.stringify(outputLookup)};
          var result = {};
          for (var p in table) {
            result[p] = output[table[p]][0];
          }
          return result;
        }`;
            }
            return `function lookupOutput(output) {
        var table = ${JSON.stringify(outputLookup)};
        var result = {};
        for (var p in table) {
          result[p] = output[table[p]];
        }
        return result;
      }`;
        }
        function toInner(fnString) {
            // crude, but should be sufficient for now
            // function() { body }
            // crude, but should be sufficient for now
            // function() { body }
            const fnParts = fnString.toString().split('{');
            fnParts.shift();
            // body }
            const fnBodyString = fnParts.join('{');
            const fnBodyParts = fnBodyString.split('}');
            fnBodyParts.pop();
            // body
            return fnBodyParts
                .join('}')
                .split('\n')
                .join('\n        ')
                .replace('product.deltas[i] = 0;', '')
                .replace('product.deltas[column] = 0;', '')
                .replace('left.deltas[leftIndex] = 0;', '')
                .replace('right.deltas[rightIndex] = 0;', '')
                .replace('product.deltas = left.deltas.slice(0);', '');
        }
        function fileName(fnName) {
            return `src/recurrent/matrix/${fnName.replace(/[A-Z]/g, function (value) {
                return `-${value.toLowerCase()}`;
            })}.js`;
        }
        const statesRaw = [];
        const usedFunctionNames = {};
        const innerFunctionsSwitch = [];
        for (let i = 0, max = states.length; i < max; i++) {
            const state = states[i];
            statesRaw.push(`states[${i}] = {
      name: '${state.forwardFn.name}',
      left: ${state.left ? matrixToString(state.left, i) : 'undefined'},
      right: ${state.right ? matrixToString(state.right, i) : 'undefined'},
      product: ${matrixToString(state.product, i)}
    }`);
            const fnName = state.forwardFn.name;
            if (!usedFunctionNames[fnName]) {
                usedFunctionNames[fnName] = true;
                if (state.name === 'input') {
                    innerFunctionsSwitch.push(`case '${fnName}':`);
                    innerFunctionsSwitch.push(inputLookup && inputSize === 1
                        ? 'product.weights = _i < input.length ? input[_i]: prevStates[prevStates.length - 1].product.weights;'
                        : inputSize === 1
                            ? 'product.weights = [input[_i]];'
                            : 'product.weights = input[_i];');
                    innerFunctionsSwitch.push('break;');
                }
                else {
                    innerFunctionsSwitch.push(`        case '${fnName}':${fnName !== 'forwardFn'
                        ? ` //compiled from ${fileName(fnName)}`
                        : ''}
          ${toInner(state.forwardFn.toString())}
          break;`);
                }
            }
        }
        const forceForecast = inputSize === 1 && this.outputLookup;
        const src = `
  var input = ${this.inputLookup ? 'lookupInput(rawInput)' : 'rawInput'};
  var json = ${jsonString};
  var output = [];
  var states = [];
  var prevStates;
  var state;
  var max = ${forceForecast
            ? inputLookup === outputLookup
                ? inputLookupLength
                : `input.length + ${outputLookupLength - 1}`
            : 'input.length'};
  for (var _i = 0; _i < max; _i++) {
    prevStates = states;
    states = [];
    ${statesRaw.join(';\n    ')};
    for (var stateIndex = 0, stateMax = ${statesRaw.length}; stateIndex < stateMax; stateIndex++) {
      state = states[stateIndex];
      var product = state.product;
      var left = state.left;
      var right = state.right;

      switch (state.name) {
${innerFunctionsSwitch.join('\n')}
      }
    }
    ${inputSize === 1 && inputLookup
            ? 'if (_i >= input.length - 1) { output.push(state.product.weights); }'
            : 'output = state.product.weights;'}
  }
  ${outputLookup
            ? outputLookup === inputLookup
                ? 'return lookupOutputPartial(output, input)'
                : 'return lookupOutput(output)'
            : inputSize === 1
                ? 'return output[0]'
                : 'return output'};
  ${formatInputData()}
  ${formatOutputData()}

  function Matrix(rows, columns) {
    this.rows = rows;
    this.columns = columns;
    this.weights = zeros(rows * columns);
  }
  ${zeros$1.toString()}
  ${softmax.toString().replace('_2.default', 'Matrix')}
  ${randomFloat.toString()}
  ${sampleI.toString()}
  ${maxI.toString()}`;
        // eslint-disable-next-line
        return new Function('rawInput', cb ? cb(src) : src);
    }
}
const trainDefaults = { ...trainDefaults$1 };

class GRUTimeStep extends RNNTimeStep {
    getHiddenLayer(hiddenSize, prevSize) {
        return getGRUHiddenLayer(hiddenSize, prevSize);
    }
    getEquation(equation, inputMatrix, previousResult, hiddenLayer) {
        return getGRUEquation(equation, inputMatrix, previousResult, hiddenLayer);
    }
}

class LSTM extends RNN {
    getHiddenLayer(hiddenSize, prevSize) {
        return getHiddenLSTMLayer(hiddenSize, prevSize);
    }
    getEquation(equation, inputMatrix, previousResult, hiddenLayer) {
        return getLSTMEquation(equation, inputMatrix, previousResult, hiddenLayer);
    }
}
function getHiddenLSTMLayer(hiddenSize, prevSize) {
    return {
        // gates parameters
        // wix
        inputMatrix: new RandomMatrix(hiddenSize, prevSize, 0.08),
        inputHidden: new RandomMatrix(hiddenSize, hiddenSize, 0.08),
        inputBias: new Matrix(hiddenSize, 1),
        // wfx
        forgetMatrix: new RandomMatrix(hiddenSize, prevSize, 0.08),
        forgetHidden: new RandomMatrix(hiddenSize, hiddenSize, 0.08),
        forgetBias: new Matrix(hiddenSize, 1),
        // wox
        outputMatrix: new RandomMatrix(hiddenSize, prevSize, 0.08),
        outputHidden: new RandomMatrix(hiddenSize, hiddenSize, 0.08),
        outputBias: new Matrix(hiddenSize, 1),
        // cell write params
        // wcx
        cellActivationMatrix: new RandomMatrix(hiddenSize, prevSize, 0.08),
        cellActivationHidden: new RandomMatrix(hiddenSize, hiddenSize, 0.08),
        cellActivationBias: new Matrix(hiddenSize, 1),
    };
}
function getLSTMEquation(equation, inputMatrix, previousResult, hiddenLayer) {
    if (!hiddenLayer.inputMatrix ||
        !hiddenLayer.inputHidden ||
        !hiddenLayer.inputBias ||
        !hiddenLayer.forgetMatrix ||
        !hiddenLayer.forgetHidden ||
        !hiddenLayer.forgetBias ||
        !hiddenLayer.outputMatrix ||
        !hiddenLayer.outputHidden ||
        !hiddenLayer.outputBias ||
        !hiddenLayer.cellActivationMatrix ||
        !hiddenLayer.cellActivationHidden ||
        !hiddenLayer.cellActivationBias) {
        throw new Error('hiddenLayer does not have expected properties');
    }
    const sigmoid = equation.sigmoid.bind(equation);
    const add = equation.add.bind(equation);
    const multiply = equation.multiply.bind(equation);
    const multiplyElement = equation.multiplyElement.bind(equation);
    const tanh = equation.tanh.bind(equation);
    const inputGate = sigmoid(add(add(multiply(hiddenLayer.inputMatrix, inputMatrix), multiply(hiddenLayer.inputHidden, previousResult)), hiddenLayer.inputBias));
    const forgetGate = sigmoid(add(add(multiply(hiddenLayer.forgetMatrix, inputMatrix), multiply(hiddenLayer.forgetHidden, previousResult)), hiddenLayer.forgetBias));
    // output gate
    const outputGate = sigmoid(add(add(multiply(hiddenLayer.outputMatrix, inputMatrix), multiply(hiddenLayer.outputHidden, previousResult)), hiddenLayer.outputBias));
    // write operation on cells
    const cellWrite = tanh(add(add(multiply(hiddenLayer.cellActivationMatrix, inputMatrix), multiply(hiddenLayer.cellActivationHidden, previousResult)), hiddenLayer.cellActivationBias));
    // compute new cell activation
    const retainCell = multiplyElement(forgetGate, previousResult); // what do we keep from cell
    const writeCell = multiplyElement(inputGate, cellWrite); // what do we write to cell
    const cell = add(retainCell, writeCell); // new cell contents
    // compute hidden state as gated, saturated cell activations
    return multiplyElement(outputGate, tanh(cell));
}

class LSTMTimeStep extends RNNTimeStep {
    getHiddenLayer(hiddenSize, prevSize) {
        return getHiddenLSTMLayer(hiddenSize, prevSize);
    }
    getEquation(equation, inputMatrix, previousResult, hiddenLayer) {
        return getLSTMEquation(equation, inputMatrix, previousResult, hiddenLayer);
    }
}

/**
 *
 * @param start
 * @param end
 * @returns {Array}
 */
function range(start, end) {
    const result = [];
    for (; start < end; start++) {
        result.push(start);
    }
    return result;
}

function toArray(values) {
    if (Array.isArray(values)) {
        return Float32Array.from(values);
    }
    return Float32Array.from(Object.values(values));
}

function drawInput({ pixelX, pixelY, radius, inputs, row, line, fontSize, fontClassName, }) {
    let svg = `<rect
              x="${pixelX / 2 - radius}"
              y="${pixelY / 2 + row * pixelY - radius}"
              width="${2 * radius}"
              height="${2 * radius}"
              stroke="black"
              stroke-width="1"
              fill="${inputs.color}"
              class="${inputs.className}" />
            <line
              x1="${pixelX / 4}"
              y1="${pixelY / 2 + row * pixelY}"
              x2="${pixelX / 2 - radius}"
              y2="${pixelY / 2 + row * pixelY}"
              style="stroke:${line.color};stroke-width:${line.width}"
              class="${line.className}" />`;
    if (inputs.labels) {
        svg += `<text
              x="${pixelX / 8}"
              y="${pixelY / 2 + row * pixelY - 5}"
              fill="black"
              font-size="${fontSize}"
              class="${fontClassName}">${inputs.labels[row]}</text>`;
    }
    return svg;
}
function drawNeuron({ pixelX, pixelY, row, column, radius, hidden, }) {
    return `<circle
            cx="${pixelX / 2 + column * pixelX}"
            cy="${pixelY / 2 + row * pixelY}"
            r="${radius}"
            stroke="black"
            stroke-width="1"
            fill="${hidden.color}"
            class="${hidden.className}" />`;
}
function drawOutput({ pixelX, pixelY, row, column, line, outputs, radius, }) {
    return `<circle
            cx="${pixelX / 2 + column * pixelX}"
            cy="${pixelY / 2 + row * pixelY}"
            r="${radius}"
            stroke="black"
            stroke-width="1"
            fill="${outputs.color}"
            class="${outputs.className}" />
          <line
            x1="${pixelX / 2 + column * pixelX + radius}"
            y1="${pixelY / 2 + row * pixelY}"
            x2="${pixelX / 2 + column * pixelX + pixelX / 4}"
            y2="${pixelY / 2 + row * pixelY}"
            style="stroke:${line.color};stroke-width:${line.width}"
            class="${line.className}" />`;
}
function drawBackwardConnections({ pixelX, pixelY, row, column, radius, lineY, line, previousConnectionIndex, }) {
    return `<line
            x1="${pixelX / 2 + (column - 1) * pixelX + radius}"
            y1="${lineY / 2 + previousConnectionIndex * lineY}"
            x2="${pixelX / 2 + column * pixelX - radius}"
            y2="${pixelY / 2 + row * pixelY}"
            style="stroke:${line.color};stroke-width:${line.width}"
            class="${line.className}" />`;
}
function neuralNetworkToInnerSVG(options) {
    const { sizes, height, width } = options;
    let svg = '';
    const pixelX = width / sizes.length;
    for (let column = 0; column < sizes.length; column++) {
        const size = sizes[column];
        const pixelY = height / size;
        for (let row = 0; row < size; row++) {
            if (column === 0) {
                svg += drawInput({ pixelX, pixelY, row, column, ...options });
            }
            else {
                if (column === sizes.length - 1) {
                    svg += drawOutput({ pixelX, pixelY, row, column, ...options });
                }
                else {
                    svg += drawNeuron({ pixelX, pixelY, row, column, ...options });
                }
                const previousSize = sizes[column - 1];
                const lineY = height / previousSize;
                for (let previousConnectionIndex = 0; previousConnectionIndex < previousSize; previousConnectionIndex++) {
                    svg += drawBackwardConnections({
                        pixelX,
                        pixelY,
                        row,
                        column,
                        lineY,
                        previousConnectionIndex,
                        ...options,
                    });
                }
            }
        }
    }
    return svg;
}
function drawRecurrentConnections({ pixelX, pixelY, row, column, radius, recurrentLine, }) {
    const moveX = pixelX / 2 + column * pixelX + radius + 1;
    const moveY = pixelY / 2 + row * pixelY;
    const x = moveX - radius * 2 - 2;
    const y = moveY;
    const x1 = x + 100;
    const y1 = y + 50;
    const x2 = moveX - 100;
    const y2 = moveY + 50;
    return `<path
              d="M ${moveX} ${moveY} C ${x1} ${y1}, ${x2} ${y2}, ${x} ${y}"
              stroke="${recurrentLine.color}"
              stroke-width="${recurrentLine.width}"
              fill="transparent"
              stroke-linecap="round"
              marker-end="url(#arrow)"
              class="${recurrentLine.className}" />`;
}
function rnnToInnerSVG(options) {
    const { width, height, recurrentLine, sizes, radius } = options;
    const pixelX = width / sizes.length;
    let svg = `<defs>
              <marker id="arrow" markerWidth="10" markerHeight="10" refX="8" refY="3" orient="auto" markerUnits="strokeWidth">
                <path d="M0,0 L0,6 L9,3 z" fill="${recurrentLine.color}" />
              </marker>
            </defs>`;
    svg += neuralNetworkToInnerSVG(options);
    for (let column = 1; column < sizes.length; column++) {
        const size = sizes[column];
        const pixelY = height / size;
        for (let row = 0; row < size; row++) {
            svg += drawRecurrentConnections({
                pixelX,
                pixelY,
                row,
                column,
                radius,
                recurrentLine,
            });
        }
    }
    return svg;
}
function getFeedForwardLayers(network) {
    const { options } = network;
    if (!options) {
        throw new Error('options not defined');
    }
    if (!options.inputLayer) {
        throw new Error('options.inputLater not defined');
    }
    if (!options.hiddenLayers) {
        throw new Error('options.hiddenLayers not defined');
    }
    if (options.hiddenLayers.length < 1) {
        throw new Error('options.hiddenLayers is empty');
    }
    if (!options.outputLayer) {
        throw new Error('options.outputLayer not defined');
    }
    const inputLayer = options.inputLayer();
    const hiddenLayers = [];
    hiddenLayers.push(options.hiddenLayers[0](inputLayer, 0));
    for (let i = 1; i < options.hiddenLayers.length; i++) {
        hiddenLayers.push(options.hiddenLayers[i](hiddenLayers[i - 1], i));
    }
    const outputLayer = options.outputLayer(hiddenLayers[hiddenLayers.length - 1], hiddenLayers.length);
    return {
        inputSize: inputLayer.height,
        hiddenLayers: hiddenLayers.map((hiddenLayer) => hiddenLayer.height),
        outputSize: outputLayer.height,
    };
}
function getRecurrentLayers(network) {
    const hiddenLayers = [];
    const { options } = network;
    if (!options.inputLayer) {
        throw new Error('inputLayer not defined');
    }
    if (!options.outputLayer) {
        throw new Error('outputLayer not defined');
    }
    const inputLayer = options.inputLayer();
    hiddenLayers.push(options.hiddenLayers[0](inputLayer, recurrentZeros(), 0));
    for (let i = 1; i < options.hiddenLayers.length; i++) {
        hiddenLayers.push(options.hiddenLayers[i](hiddenLayers[i - 1], recurrentZeros(), i));
    }
    const outputLayer = options.outputLayer(hiddenLayers[hiddenLayers.length - 1], -1);
    return {
        inputSize: inputLayer.height,
        hiddenLayers: hiddenLayers.map((hiddenLayer) => hiddenLayer.height),
        outputSize: outputLayer.height,
    };
}
function wrapOuterSVG(svgBody, width, height) {
    // language=html
    return `<svg
            xmlns="http://www.w3.org/2000/svg"
            xmlns:xlink="http://www.w3.org/1999/xlink"
            version="1.1"
            width="${width}"
            height="${height}">${svgBody}</svg>`;
}
function getNeuralNetworkJSONSizes(json) {
    return json.sizes;
}
function getNeuralNetworkSizes(net) {
    const { options, sizes } = net;
    const { inputSize, outputSize, hiddenLayers } = options;
    if (!sizes) {
        if (typeof inputSize === 'number' && inputSize < 1) {
            throw new Error('inputSize not set');
        }
        if (typeof outputSize === 'number' && outputSize < 1) {
            throw new Error('outputSize not set');
        }
        if (hiddenLayers === null || hiddenLayers === void 0 ? void 0 : hiddenLayers.some((v) => v < 1)) {
            throw new Error('hiddenLayers not set');
        }
    }
    return typeof inputSize === 'number' &&
        Array.isArray(hiddenLayers) &&
        typeof outputSize === 'number'
        ? [inputSize].concat(hiddenLayers).concat([outputSize])
        : sizes;
}
function getRNNSizes(net) {
    const { options } = net;
    const { inputSize, outputSize, hiddenLayers } = options;
    return [inputSize].concat(hiddenLayers).concat([outputSize]);
}
function defaultOptions() {
    return {
        line: {
            width: 0.5,
            color: 'black',
            className: 'connection',
        },
        recurrentLine: {
            width: 1,
            color: 'red',
            className: 'recurrence',
        },
        inputs: {
            color: 'rgba(0, 128, 0, 0.5)',
            labels: null,
            className: 'input',
        },
        outputs: {
            color: 'rgba(100, 149, 237, 0.5)',
            className: 'output',
        },
        hidden: {
            color: 'rgba(255, 127, 80, 0.5)',
            className: 'hidden-neuron',
        },
        fontSize: '14px',
        fontClassName: 'label',
        radius: 8,
        width: 400,
        height: 250,
        sizes: [],
    };
}
function toSVG(net, options) {
    const mergedOptions = { ...defaultOptions(), ...options };
    const { width, height, inputs } = mergedOptions;
    // Get network size array for NeuralNetwork or NeuralNetworkGPU
    let sizes = [];
    if (net instanceof NeuralNetwork || net instanceof NeuralNetworkGPU) {
        sizes = getNeuralNetworkSizes(net);
    }
    // get network size for Recurrent
    else if (net instanceof Recurrent) {
        const { inputSize, hiddenLayers, outputSize } = getRecurrentLayers(net);
        sizes = [inputSize].concat(hiddenLayers).concat([outputSize]);
    }
    // get network size for FeedForward
    else if (net instanceof FeedForward) {
        const { inputSize, hiddenLayers, outputSize } = getFeedForwardLayers(net);
        sizes = [inputSize].concat(hiddenLayers).concat([outputSize]);
    }
    // handle json, recurrent first
    else if (net instanceof RNN ||
        net instanceof LSTM ||
        net instanceof GRU ||
        net instanceof RNNTimeStep ||
        net instanceof LSTMTimeStep ||
        net instanceof GRUTimeStep) {
        return wrapOuterSVG(rnnToInnerSVG({
            ...mergedOptions,
            sizes: checkSizes(getRNNSizes(net), inputs.labels),
        }), width, height);
    }
    // handle json, NeuralNetwork
    else if (net.hasOwnProperty('type')) {
        switch (net.type) {
            case 'NeuralNetwork':
            case 'NeuralNetworkGPU':
                return wrapOuterSVG(neuralNetworkToInnerSVG({
                    ...mergedOptions,
                    sizes: checkSizes(getNeuralNetworkJSONSizes(net), inputs.labels),
                }), width, height);
            case 'RNN':
            case 'GRU':
            case 'LSTM':
            case 'RNNTimeStep':
            case 'GRUTimeStep':
            case 'LSTMTimeStep':
                return wrapOuterSVG(rnnToInnerSVG({
                    ...mergedOptions,
                    sizes: checkSizes(getRNNSizes(net), inputs.labels),
                }), width, height);
            default:
                throw new Error('unrecognized network');
        }
    }
    else if (net.hasOwnProperty('inputSize') &&
        net.hasOwnProperty('hiddenLayers') &&
        net.hasOwnProperty('outputSize')) {
        const { inputSize, hiddenLayers, outputSize } = net;
        sizes = [inputSize, ...hiddenLayers, outputSize];
    }
    else if (net.hasOwnProperty('sizes')) {
        sizes = net.sizes;
    }
    else {
        throw new Error('unrecognized network');
    }
    return wrapOuterSVG(neuralNetworkToInnerSVG({
        ...mergedOptions,
        sizes: checkSizes(sizes, inputs.labels),
    }), width, height);
}
function checkSizes(sizes, labels) {
    if (!sizes) {
        throw new Error('sizes not set');
    }
    if (sizes.some((size) => size < 1)) {
        throw new Error('sizes not set correctly');
    }
    if (labels && labels.length !== sizes[0]) {
        throw new Error('not enough labels for inputs');
    }
    return sizes;
}

const recurrent = {
    RNNTimeStep,
    LSTMTimeStep,
    GRUTimeStep,
    RNN,
    LSTM,
    GRU,
};
const utilities = {
    max,
    mse: mse$1,
    ones: ones$1,
    ones2D,
    random: random$1,
    randomWeight,
    randos,
    range,
    toArray,
    DataFormatter,
    zeros: zeros$1,
    toSVG,
};

class TrainStream extends stream.Writable {
    constructor(options) {
        super({
            objectMode: true,
        });
        // require the neuralNetwork
        if (!options.neuralNetwork) {
            throw new Error('No neural network specified. Please see list of available network types: https://github.com/BrainJS/brain.js#neural-network-types');
        }
        const { neuralNetwork } = options;
        // inherit trainOpts settings from neuralNetwork
        neuralNetwork.updateTrainingOptions(options);
        const trainOpts = neuralNetwork === null || neuralNetwork === void 0 ? void 0 : neuralNetwork.trainOpts; // just updated from above line
        this.neuralNetwork = neuralNetwork;
        this.dataFormatDetermined = false;
        this.i = 0; // keep track of internal iterations
        this.size = 0;
        this.count = 0;
        this.sum = 0;
        this.floodCallback = options.floodCallback;
        this.doneTrainingCallback = options.doneTrainingCallback;
        this.iterations = trainOpts.iterations;
        this.errorThresh = trainOpts.errorThresh;
        this.log = trainOpts.log;
        this.logPeriod = trainOpts.logPeriod;
        this.callbackPeriod = trainOpts.callbackPeriod;
        this.on('finish', this.finishStreamIteration.bind(this));
        this.callback = trainOpts.callback;
    }
    endInputs() {
        this.write(false);
    }
    _write(chunk, enc, next) {
        if (!chunk) {
            // check for the end of one iteration of the stream
            this.emit('finish');
            return next();
        }
        if (!this.dataFormatDetermined) {
            this.size++;
            this.neuralNetwork.addFormat(chunk);
            if (this.firstDatum === undefined) {
                this.firstDatum = chunk;
            }
            return next();
        }
        this.count++;
        const data = this.neuralNetwork.formatData([chunk]);
        const error = this.neuralNetwork.trainPattern(data[0], true);
        if (error !== null) {
            this.sum += error;
        }
        // tell the Readable Stream that we are ready for more data
        next();
    }
    finishStreamIteration() {
        if (this.dataFormatDetermined && this.size !== this.count) {
            console.warn("This iteration's data length was different from the first!");
        }
        if (!this.dataFormatDetermined && this.firstDatum !== undefined) {
            const data = this.neuralNetwork.formatData([this.firstDatum]);
            this.neuralNetwork.verifyIsInitialized(data);
            this.dataFormatDetermined = true;
            if (typeof this.floodCallback === 'function') {
                this.floodCallback();
            }
            return;
        }
        const error = this.sum / this.size;
        if (this.log && this.i % this.logPeriod === 0) {
            if (typeof this.log === 'function') {
                this.log({
                    iterations: this.i,
                    error: error,
                });
            }
            else {
                console.info(`iterations: ${this.i}, training error: ${error}`);
            }
        }
        if (this.callback && this.i % this.callbackPeriod === 0) {
            this.callback({
                error,
                iterations: this.i,
            });
        }
        this.sum = 0;
        this.count = 0;
        // update the iterations
        this.i++;
        // do a check here to see if we need the stream again
        if (this.i < this.iterations && error > this.errorThresh) {
            if (typeof this.floodCallback === 'function') {
                return this.floodCallback();
            }
        }
        else {
            // done training
            if (typeof this.doneTrainingCallback === 'function') {
                return this.doneTrainingCallback({
                    error,
                    iterations: this.i,
                });
            }
        }
    }
}

exports.CrossValidate = CrossValidate;
exports.FeedForward = FeedForward;
exports.NeuralNetwork = NeuralNetwork;
exports.NeuralNetworkGPU = NeuralNetworkGPU;
exports.Recurrent = Recurrent;
exports.TrainStream = TrainStream;
exports.activation = index$1;
exports.layer = layer;
exports.layerTypes = layerTypes;
exports.likely = likely;
exports.lookup = lookup;
exports.praxis = index;
exports.recurrent = recurrent;
exports.utilities = utilities;
//# sourceMappingURL=index.map


/***/ }),

/***/ "./pages/index.tsx":
/*!*************************!*\
  !*** ./pages/index.tsx ***!
  \*************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _src_components_Dashboard__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../src/components/Dashboard */ "./src/components/Dashboard/index.tsx");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__);
var _jsxFileName = "/home/vittis/dev/github/covid-prediction/pages/index.tsx";




const Home = () => {
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(_src_components_Dashboard__WEBPACK_IMPORTED_MODULE_1__.default, {}, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 6,
    columnNumber: 5
  }, undefined);
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Home);

/***/ }),

/***/ "./src/components/Chart/index.tsx":
/*!****************************************!*\
  !*** ./src/components/Chart/index.tsx ***!
  \****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _chakra_ui_react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @chakra-ui/react */ "@chakra-ui/react");
/* harmony import */ var _chakra_ui_react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var chart_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! chart.js */ "chart.js");
/* harmony import */ var chart_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(chart_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_chartjs_2__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react-chartjs-2 */ "react-chartjs-2");
/* harmony import */ var react_chartjs_2__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_chartjs_2__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _context_BrainContext__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../context/BrainContext */ "./src/context/BrainContext.tsx");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__);
var _jsxFileName = "/home/vittis/dev/github/covid-prediction/src/components/Chart/index.tsx";






chart_js__WEBPACK_IMPORTED_MODULE_2__.Chart.register(chart_js__WEBPACK_IMPORTED_MODULE_2__.CategoryScale, chart_js__WEBPACK_IMPORTED_MODULE_2__.LinearScale, chart_js__WEBPACK_IMPORTED_MODULE_2__.PointElement, chart_js__WEBPACK_IMPORTED_MODULE_2__.LineElement, chart_js__WEBPACK_IMPORTED_MODULE_2__.Title, chart_js__WEBPACK_IMPORTED_MODULE_2__.Tooltip, chart_js__WEBPACK_IMPORTED_MODULE_2__.Legend);

const Chart = ({
  dailyData
}) => {
  const {
    setTrainingData,
    trainingChartData,
    predictedChartData,
    training
  } = (0,_context_BrainContext__WEBPACK_IMPORTED_MODULE_4__.useBrainContext)();
  (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(() => {
    if (dailyData) {
      setTrainingData(dailyData.reverse());
    }
  }, [dailyData]);
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_0__.Flex, {
    direction: ['column', 'column', 'column', 'row'],
    w: "100%",
    children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_0__.Flex, {
      w: ['100%', '100%', '100%', '50%'],
      p: 50,
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(react_chartjs_2__WEBPACK_IMPORTED_MODULE_3__.Line, {
        options: trainingChartData.options,
        data: trainingChartData.data
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 41,
        columnNumber: 9
      }, undefined)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 40,
      columnNumber: 7
    }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_0__.Flex, {
      w: ['100%', '100%', '100%', '50%'],
      p: 50,
      children: !training ? /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(react_chartjs_2__WEBPACK_IMPORTED_MODULE_3__.Line, {
        options: predictedChartData.options,
        data: predictedChartData.data
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 44,
        columnNumber: 22
      }, undefined) : /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_0__.Spinner, {
        size: "xl"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 44,
        columnNumber: 101
      }, undefined)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 43,
      columnNumber: 7
    }, undefined)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 39,
    columnNumber: 5
  }, undefined);
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Chart);

/***/ }),

/***/ "./src/components/Dashboard/index.tsx":
/*!********************************************!*\
  !*** ./src/components/Dashboard/index.tsx ***!
  \********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _chakra_ui_react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @chakra-ui/react */ "@chakra-ui/react");
/* harmony import */ var _chakra_ui_react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _Chart__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../Chart */ "./src/components/Chart/index.tsx");
/* harmony import */ var _context_BrainContext__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../context/BrainContext */ "./src/context/BrainContext.tsx");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__);
var _jsxFileName = "/home/vittis/dev/github/covid-prediction/src/components/Dashboard/index.tsx";






const Dashboard = () => {
  const {
    dailyData,
    forecast,
    trainingData,
    daysInput,
    setDaysInput
  } = (0,_context_BrainContext__WEBPACK_IMPORTED_MODULE_3__.useBrainContext)();

  const handleForecast = e => {
    console.log(daysInput);
    forecast(trainingData, parseInt(daysInput, 10));
  };

  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_0__.Flex, {
    direction: "column",
    width: "100vw",
    justifyContent: "center",
    children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_0__.Flex, {
      direction: "column",
      alignItems: "center",
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_0__.Heading, {
        m: 5,
        size: "xl",
        children: "How many days ahead would you like to predict? "
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 25,
        columnNumber: 9
      }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_0__.Text, {
        ml: 10,
        mb: 5,
        size: "md",
        children: "Textinho explicando coisa boa Textinho explicando coisa boa Textinho explicando coisa boa Textinho explicando coisa boa Textinho explicando coisa boa Textinho explicando coisa boa Textinho explicando coisa boa Textinho explicando coisa boa Textinho explicando coisa boa"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 26,
        columnNumber: 9
      }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_0__.Flex, {
        children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_0__.Input, {
          width: "200px",
          placeholder: "Days to predict",
          type: "number",
          value: daysInput,
          onChange: e => setDaysInput(e.target.value)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 37,
          columnNumber: 11
        }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_0__.Button, {
          disabled: daysInput === "",
          ml: "1.5",
          onClick: handleForecast,
          children: "Train AI"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 44,
          columnNumber: 11
        }, undefined)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 36,
        columnNumber: 9
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 24,
      columnNumber: 7
    }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_0__.Box, {
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)(_Chart__WEBPACK_IMPORTED_MODULE_2__.default, {
        dailyData: dailyData
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 48,
        columnNumber: 9
      }, undefined)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 47,
      columnNumber: 7
    }, undefined)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 23,
    columnNumber: 5
  }, undefined);
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Dashboard);

/***/ }),

/***/ "./src/context/BrainContext.tsx":
/*!**************************************!*\
  !*** ./src/context/BrainContext.tsx ***!
  \**************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "BrainContext": () => (/* binding */ BrainContext),
/* harmony export */   "BrainProvider": () => (/* binding */ BrainProvider),
/* harmony export */   "useBrainContext": () => (/* binding */ useBrainContext)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _services_api__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../services/api */ "./src/services/api.ts");
/* harmony import */ var brain_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! brain.js */ "./node_modules/brain.js/dist/src/index");
/* harmony import */ var _utils_scaler__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../utils/scaler */ "./src/utils/scaler.ts");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__);
var _jsxFileName = "/home/vittis/dev/github/covid-prediction/src/context/BrainContext.tsx";


 // import scaler from 'minmaxscaler'



const BrainContext = /*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_0__.createContext)({});
const BrainProvider = ({
  children
}) => {
  const {
    0: training,
    1: setTraining
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
  const {
    0: dailyData,
    1: setDailyData
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)([]);
  const {
    0: globalData,
    1: setGlobalData
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)({});
  const {
    0: trainingData,
    1: setTrainingData
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)([]);
  const {
    0: daysInput,
    1: setDaysInput
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)('');
  const {
    0: prediction,
    1: setPrediction
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)([]);
  const predictedChartData = {
    data: {
      labels: prediction.map((n, index) => index),
      datasets: [{
        data: prediction.map(data => data),
        label: 'Infected',
        borderColor: 'rgb(53, 162, 235)',
        backgroundColor: 'rgba(53, 162, 235, 0.5)'
      }]
    },
    options: {
      responsive: true,
      plugins: {
        legend: {
          position: 'top'
        },
        title: {
          display: true,
          text: 'Your Covid-19 infection forecasting'
        }
      }
    }
  };
  const trainingChartData = {
    data: {
      labels: trainingData.map(({
        date
      }) => new Date(date).toLocaleDateString()),
      datasets: [{
        data: trainingData.map(data => data.confirmed),
        label: 'Infected',
        borderColor: 'rgb(53, 162, 235)',
        backgroundColor: 'rgba(53, 162, 235, 0.5)'
      }, {
        data: trainingData.map(data => data.deaths),
        label: 'Deaths',
        borderColor: 'rgb(255, 99, 132)',
        backgroundColor: 'rgba(255, 99, 132, 0.5)'
      }]
    },
    options: {
      responsive: true,
      plugins: {
        legend: {
          position: 'top'
        },
        title: {
          display: true,
          text: 'AI training data'
        }
      }
    }
  };

  const forecast = (trainingData, daysInput) => {
    setTraining(true);
    const newTrainingData = new Array(50).fill(0);

    if (trainingData) {
      for (let i = 0; i <= 50; i++) {
        var _trainingData;

        newTrainingData[i] = (_trainingData = trainingData[trainingData.length - 51 + i]) === null || _trainingData === void 0 ? void 0 : _trainingData.confirmed;
      }
    }

    const scaledData = _utils_scaler__WEBPACK_IMPORTED_MODULE_3__.default.fit_transform(newTrainingData);
    const network = new brain_js__WEBPACK_IMPORTED_MODULE_2__.recurrent.LSTMTimeStep({
      inputSize: 1,
      hiddenLayers: [10],
      outputSize: 1
    });
    network.train([scaledData], {
      learningRate: 0.005,
      errorThresh: 0.01,
      log: stats => {
        console.log(stats);
      }
    });
    const result = network.forecast([1], daysInput);
    setPrediction(_utils_scaler__WEBPACK_IMPORTED_MODULE_3__.default.inverse_transform(result));
    setTraining(false);
  };

  (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
    const loadDailyData = async () => {
      const initialDailyData = await (0,_services_api__WEBPACK_IMPORTED_MODULE_1__.fetchDailyData)();

      if (initialDailyData) {
        setDailyData(initialDailyData);
      }
    };

    const loadGlobalData = async () => {
      const globalData = await (0,_services_api__WEBPACK_IMPORTED_MODULE_1__.fetchGlobalData)();

      if (globalData) {
        setGlobalData(globalData);
      }
    };

    loadDailyData();
    loadGlobalData();
  }, []);
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)(BrainContext.Provider, {
    value: {
      trainingData,
      setTrainingData,
      setDailyData,
      dailyData,
      trainingChartData,
      forecast,
      daysInput,
      setDaysInput,
      prediction,
      predictedChartData,
      training
    },
    children: children
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 208,
    columnNumber: 5
  }, undefined);
}; //easier export

const useBrainContext = () => (0,react__WEBPACK_IMPORTED_MODULE_0__.useContext)(BrainContext);

/***/ }),

/***/ "./src/services/api.ts":
/*!*****************************!*\
  !*** ./src/services/api.ts ***!
  \*****************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "api": () => (/* binding */ api),
/* harmony export */   "fetchGlobalData": () => (/* binding */ fetchGlobalData),
/* harmony export */   "fetchDailyData": () => (/* binding */ fetchDailyData)
/* harmony export */ });
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! axios */ "axios");
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_0__);

const api = axios__WEBPACK_IMPORTED_MODULE_0___default().create({
  baseURL: 'https://covid-19-statistics.p.rapidapi.com/reports'
});
api.defaults.headers['x-rapidapi-host'] = 'covid-19-statistics.p.rapidapi.com';
api.defaults.headers['x-rapidapi-key'] = '0b8b88299dmsh633d177b4830bb2p1f4e62jsn9a410c7e91fc';
api.interceptors.request.use(config => {
  console.log(config);
  return config;
});
const fetchGlobalData = async () => {
  try {
    const {
      data
    } = await api.get('/total');
    return data;
  } catch (err) {
    return err;
  }
};
const fetchDailyData = async () => {
  try {
    const {
      data
    } = await axios__WEBPACK_IMPORTED_MODULE_0___default().get('https://api.covidtracking.com/v1/us/daily.json');
    return data.map(({
      positive,
      recovered,
      death,
      dateChecked: date
    }) => ({
      confirmed: positive,
      recovered,
      deaths: death,
      date
    }));
  } catch (error) {
    return error;
  }
};

/***/ }),

/***/ "./src/utils/scaler.ts":
/*!*****************************!*\
  !*** ./src/utils/scaler.ts ***!
  \*****************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
let X_min = 0;
let X_max = 0;
let min_ = 0;
let max_ = 1;
let data = {
  X_max: X_max,
  X_min: X_min,
  max_: max_,
  min_: min_
};

function fit(X, min = 0, max = 1) {
  X_max = Math.max.apply(null, X);
  X_min = Math.min.apply(null, X);
  min_ = min;
  max_ = max;
  data = {
    X_max: X_max,
    X_min: X_min,
    max_: max_,
    min_: min_
  };
  const X_minArr = X.map(function (values) {
    return values - X_min;
  }); // X_std = (X - X.min()) / (X.max() - X.min())

  const X_std = X_minArr.map(function (values) {
    return values / (X_max - X_min);
  }); // X_scaled = X_std * (max - min) + min

  const X_scaled = X_std.map(function (values) {
    return values * (max - min) + min;
  });
  return X_scaled;
}

function fit_transform(data, min = 0, max = 1) {
  const train_scaled = fit(data, min, max);
  return train_scaled;
}

function inverse_transform(input, min = 0, max = 1) {
  const fit = data;
  console.log(fit);
  const X = input.map(function (values) {
    return (values - min) / (max - min);
  });
  const X_ = X.map(function (values) {
    return values * (fit.X_max - fit.X_min) + fit.X_min;
  });
  return X_;
}

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  fit_transform,
  inverse_transform
});

/***/ }),

/***/ "@chakra-ui/react":
/*!***********************************!*\
  !*** external "@chakra-ui/react" ***!
  \***********************************/
/***/ ((module) => {

module.exports = require("@chakra-ui/react");

/***/ }),

/***/ "axios":
/*!************************!*\
  !*** external "axios" ***!
  \************************/
/***/ ((module) => {

module.exports = require("axios");

/***/ }),

/***/ "chart.js":
/*!***************************!*\
  !*** external "chart.js" ***!
  \***************************/
/***/ ((module) => {

module.exports = require("chart.js");

/***/ }),

/***/ "gpu.js":
/*!*************************!*\
  !*** external "gpu.js" ***!
  \*************************/
/***/ ((module) => {

module.exports = require("gpu.js");

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ "react-chartjs-2":
/*!**********************************!*\
  !*** external "react-chartjs-2" ***!
  \**********************************/
/***/ ((module) => {

module.exports = require("react-chartjs-2");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

module.exports = require("react/jsx-dev-runtime");

/***/ }),

/***/ "stream":
/*!*************************!*\
  !*** external "stream" ***!
  \*************************/
/***/ ((module) => {

module.exports = require("stream");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("./pages/index.tsx"));
module.exports = __webpack_exports__;

})();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicGFnZXMvaW5kZXguanMiLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7OztBQUFhOztBQUViLDhDQUE2QyxFQUFFLGFBQWEsRUFBQzs7QUFFN0QsYUFBYSxtQkFBTyxDQUFDLHNCQUFRO0FBQzdCLGFBQWEsbUJBQU8sQ0FBQyxzQkFBUTs7QUFFN0I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQSxDQUFDOztBQUVEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLENBQUM7O0FBRUQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsQ0FBQzs7QUFFRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLENBQUM7O0FBRUQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsQ0FBQzs7QUFFRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsYUFBYTtBQUNiO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsYUFBYTtBQUNiO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHVDQUF1QyxPQUFPO0FBQzlDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsOEJBQThCO0FBQzlCO0FBQ0Esa0VBQWtFLGFBQWEsYUFBYSxFQUFFO0FBQzlGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esd0JBQXdCLE9BQU87QUFDL0I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esd0NBQXdDLGFBQWE7QUFDckQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esd0NBQXdDLGFBQWE7QUFDckQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSwyQkFBMkIsYUFBYTtBQUN4QztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSw0QkFBNEIsa0JBQWtCO0FBQzlDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLDRCQUE0QixrQkFBa0I7QUFDOUM7QUFDQSxnQ0FBZ0MsZ0JBQWdCO0FBQ2hEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLDRCQUE0QixrQkFBa0I7QUFDOUM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsNEJBQTRCLGtCQUFrQjtBQUM5QztBQUNBO0FBQ0EsZ0NBQWdDLGdCQUFnQjtBQUNoRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxvQkFBb0IsMkJBQTJCO0FBQy9DLHdCQUF3QiwwQkFBMEI7QUFDbEQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esa0JBQWtCLGVBQWU7QUFDakM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsYUFBYTtBQUNiO0FBQ0EsU0FBUztBQUNUO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBLFNBQVM7QUFDVDtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSw4QkFBOEI7QUFDOUI7QUFDQTtBQUNBLDhCQUE4QjtBQUM5QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsZ0JBQWdCLGlDQUFpQztBQUNqRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsK0JBQStCLHNCQUFzQjtBQUNyRDtBQUNBO0FBQ0EsK0JBQStCLHNCQUFzQjtBQUNyRDtBQUNBLFVBQVU7QUFDVjtBQUNBLCtCQUErQixzQkFBc0I7QUFDckQ7QUFDQTtBQUNBLCtCQUErQixzQkFBc0I7QUFDckQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLCtCQUErQixzQkFBc0I7QUFDckQ7QUFDQTtBQUNBLCtCQUErQixzQkFBc0I7QUFDckQ7QUFDQSxVQUFVO0FBQ1Y7QUFDQSwrQkFBK0Isc0JBQXNCO0FBQ3JEO0FBQ0E7QUFDQSwrQkFBK0Isc0JBQXNCO0FBQ3JEO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsTUFBTTtBQUNOO0FBQ0E7QUFDQSwrQkFBK0IsdUJBQXVCO0FBQ3REO0FBQ0E7QUFDQSwrQkFBK0IsdUJBQXVCO0FBQ3REO0FBQ0E7QUFDQSwrQkFBK0IsdUJBQXVCO0FBQ3REO0FBQ0E7QUFDQSwrQkFBK0IsdUJBQXVCO0FBQ3REO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSwrQkFBK0IsdUJBQXVCLHdCQUF3QixhQUFhLFNBQVMsV0FBVztBQUMvRztBQUNBO0FBQ0EsK0JBQStCLHVCQUF1Qix3QkFBd0IsY0FBYyxTQUFTLFlBQVk7QUFDakg7QUFDQTtBQUNBO0FBQ0EsbUNBQW1DLHVCQUF1QjtBQUMxRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsbUNBQW1DLHVCQUF1QjtBQUMxRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxnQkFBZ0Isc0JBQXNCO0FBQ3RDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGdCQUFnQixVQUFVO0FBQzFCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGFBQWE7QUFDYjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxpQkFBaUI7QUFDakIsYUFBYTtBQUNiO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esb0JBQW9CLFlBQVk7QUFDaEM7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLG9CQUFvQixXQUFXO0FBQy9CO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsZ0JBQWdCLHVCQUF1QjtBQUN2QztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHdDQUF3QyxZQUFZLHFDQUFxQyxzQkFBc0I7QUFDL0c7QUFDQTtBQUNBLHlDQUF5QyxhQUFhLHNDQUFzQyx1QkFBdUI7QUFDbkg7QUFDQTtBQUNBLHdDQUF3QyxZQUFZLHFDQUFxQyxzQkFBc0I7QUFDL0c7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxhQUFhO0FBQ2I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGFBQWE7QUFDYjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBLG1CQUFtQixLQUFLLEdBQUcsV0FBVyxNQUFNLGlCQUFpQjtBQUM3RCxlQUFlLFFBQVE7QUFDdkIsaUJBQWlCO0FBQ2pCO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUyxJQUFJO0FBQ2I7QUFDQSxLQUFLO0FBQ0w7QUFDQSxtQkFBbUIsS0FBSyxHQUFHLFdBQVcsTUFBTSxpQkFBaUI7QUFDN0Q7QUFDQTtBQUNBO0FBQ0E7QUFDQSx3QkFBd0Isc0JBQXNCO0FBQzlDO0FBQ0EsNEJBQTRCLG9CQUFvQjtBQUNoRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQTtBQUNBO0FBQ0EsZ0NBQWdDLHlCQUF5QjtBQUN6RDtBQUNBLDRCQUE0QixrQkFBa0I7QUFDOUM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0E7QUFDQSxnQ0FBZ0MseUJBQXlCO0FBQ3pEO0FBQ0EsNEJBQTRCLG1CQUFtQjtBQUMvQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0Esa0JBQWtCLFlBQVksSUFBSSxXQUFXO0FBQzdDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSx3QkFBd0IsaUJBQWlCO0FBQ3pDO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBLGtCQUFrQixXQUFXLEdBQUcsTUFBTTtBQUN0QztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQTtBQUNBLHdCQUF3QixvQkFBb0I7QUFDNUM7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0Esa0JBQWtCLFdBQVcsYUFBYSxXQUFXO0FBQ3JELGVBQWUsUUFBUTtBQUN2QixlQUFlLE9BQU87QUFDdEIsaUJBQWlCO0FBQ2pCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMOztBQUVBO0FBQ0EsNENBQTRDO0FBQzVDO0FBQ0EsMEJBQTBCO0FBQzFCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSwrQkFBK0IsdUJBQXVCLHdCQUF3QixjQUFjLFNBQVMsV0FBVztBQUNoSDtBQUNBO0FBQ0EsK0JBQStCLHVCQUF1Qix3QkFBd0IsZUFBZSxTQUFTLFlBQVk7QUFDbEg7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsaUJBQWlCO0FBQ2pCO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSwwQkFBMEI7QUFDMUI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxhQUFhO0FBQ2IsU0FBUztBQUNUO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLDBCQUEwQjtBQUMxQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVM7QUFDVDtBQUNBO0FBQ0E7QUFDQTtBQUNBLGFBQWE7QUFDYixTQUFTO0FBQ1Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLDRDQUE0QztBQUM1QztBQUNBO0FBQ0EsMEJBQTBCO0FBQzFCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGdCQUFnQixrQkFBa0I7QUFDbEM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxhQUFhO0FBQ2I7QUFDQTtBQUNBLFNBQVM7QUFDVDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLENBQUM7O0FBRUQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0Esb0JBQW9CLG1CQUFtQjtBQUN2QztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQSxtREFBbUQsY0FBYyxNQUFNLGFBQWE7QUFDcEY7QUFDQTtBQUNBLG9EQUFvRCxlQUFlLE1BQU0sY0FBYztBQUN2RjtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsOEJBQThCO0FBQzlCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxDQUFDOztBQUVEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHdCQUF3QixVQUFVO0FBQ2xDO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esd0JBQXdCLFVBQVU7QUFDbEM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxvQkFBb0IsWUFBWTtBQUNoQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxvQkFBb0IsV0FBVztBQUMvQjtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLDBCQUEwQjtBQUMxQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBLG9CQUFvQix5QkFBeUI7QUFDN0M7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esb0JBQW9CLHlCQUF5QjtBQUM3QztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxvQkFBb0IseUJBQXlCO0FBQzdDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsdURBQXVELHdCQUF3QixNQUFNLHdCQUF3QjtBQUM3RztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGFBQWE7QUFDYjtBQUNBLFNBQVM7QUFDVDtBQUNBO0FBQ0E7QUFDQTtBQUNBLGFBQWE7QUFDYjtBQUNBLFNBQVM7QUFDVDtBQUNBO0FBQ0E7QUFDQTtBQUNBLGFBQWE7QUFDYjtBQUNBLFNBQVM7QUFDVDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsYUFBYTtBQUNiO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsYUFBYTtBQUNiO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGFBQWE7QUFDYjtBQUNBO0FBQ0E7QUFDQTtBQUNBLGFBQWE7QUFDYjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQSxZQUFZLFNBQVM7QUFDckI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0EsaUJBQWlCO0FBQ2pCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsaUJBQWlCO0FBQ2pCO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsaUJBQWlCO0FBQ2pCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsaUJBQWlCO0FBQ2pCO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxvQkFBb0IsK0JBQStCO0FBQ25ELHlGQUF5RixzQkFBc0I7QUFDL0csNkZBQTZGLHNCQUFzQjtBQUNuSDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EseURBQXlELG9CQUFvQjtBQUM3RSw2REFBNkQsb0JBQW9CO0FBQ2pGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHFDQUFxQyxvQkFBb0I7QUFDekQ7QUFDQSx5Q0FBeUMsb0JBQW9CO0FBQzdEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLG9CQUFvQixnQ0FBZ0M7QUFDcEQsd0JBQXdCLCtCQUErQjtBQUN2RDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsYUFBYTtBQUNiO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGFBQWE7QUFDYjtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0E7QUFDQTtBQUNBLGFBQWE7QUFDYjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGFBQWE7QUFDYjtBQUNBLFNBQVM7QUFDVDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsZ0JBQWdCLDJCQUEyQjtBQUMzQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGdCQUFnQixzQkFBc0I7QUFDdEM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsMEJBQTBCO0FBQzFCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLG9EQUFvRCxzQkFBc0I7QUFDMUU7QUFDQTtBQUNBLGFBQWE7QUFDYix5REFBeUQseUJBQXlCO0FBQ2xGO0FBQ0E7QUFDQSxvREFBb0QsZUFBZSx5QkFBeUI7QUFDNUY7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxnQkFBZ0IsbUJBQW1CO0FBQ25DO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBLFlBQVksNEJBQTRCO0FBQ3hDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0wsNEJBQTRCLGtDQUFrQztBQUM5RCx3REFBd0QsWUFBWSxhQUFhLFlBQVksS0FBSyxZQUFZO0FBQzlHOztBQUVBO0FBQ0E7QUFDQTtBQUNBLG9CQUFvQixnQ0FBZ0M7QUFDcEQsd0JBQXdCLCtCQUErQjtBQUN2RDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxvQkFBb0IsK0JBQStCO0FBQ25ELHdCQUF3QixnQ0FBZ0M7QUFDeEQsNEJBQTRCLCtCQUErQjtBQUMzRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLDBCQUEwQixzQ0FBc0M7QUFDaEU7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSwwQkFBMEIsc0NBQXNDO0FBQ2hFO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsMEJBQTBCO0FBQzFCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGdCQUFnQixhQUFhO0FBQzdCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxpQkFBaUI7QUFDakIsYUFBYTtBQUNiO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxpQkFBaUI7QUFDakI7QUFDQSxhQUFhO0FBQ2I7QUFDQTtBQUNBO0FBQ0E7QUFDQSxpQkFBaUI7QUFDakI7QUFDQSxhQUFhO0FBQ2I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxpQkFBaUI7QUFDakIsYUFBYTtBQUNiO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsaUJBQWlCO0FBQ2pCLGFBQWE7QUFDYjtBQUNBO0FBQ0E7QUFDQTtBQUNBLGlCQUFpQjtBQUNqQixhQUFhO0FBQ2I7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGdCQUFnQiwyQkFBMkI7QUFDM0M7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxvQkFBb0IsWUFBWTtBQUNoQztBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsYUFBYTtBQUNiO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsYUFBYTtBQUNiO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGFBQWE7QUFDYjtBQUNBO0FBQ0E7QUFDQTtBQUNBLGFBQWE7QUFDYjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLDhCQUE4QixzQkFBc0I7QUFDcEQ7QUFDQTtBQUNBLDhCQUE4QixzQkFBc0I7QUFDcEQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBLFlBQVksU0FBUztBQUNyQix1Q0FBdUMsNkJBQTZCO0FBQ3BFLHlDQUF5Qyx1QkFBdUI7QUFDaEUsbUNBQW1DLFFBQVE7QUFDM0M7QUFDQSxzQ0FBc0MsNkJBQTZCO0FBQ25FLHdDQUF3Qyx1QkFBdUI7QUFDL0Qsa0NBQWtDLFFBQVE7QUFDMUM7QUFDQSxpQ0FBaUMsNkJBQTZCO0FBQzlELG1DQUFtQyx1QkFBdUI7QUFDMUQsNkJBQTZCLFFBQVE7QUFDckM7QUFDQTtBQUNBO0FBQ0EsZ0RBQWdELG9EQUFvRDtBQUNwRzs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsZ0JBQWdCLDRCQUE0QjtBQUM1QztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGFBQWE7QUFDYjtBQUNBO0FBQ0EsYUFBYTtBQUNiO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLDhCQUE4QixzQkFBc0I7QUFDcEQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsZ0JBQWdCLHVCQUF1QjtBQUN2QztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsYUFBYTtBQUNiO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsYUFBYTtBQUNiO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGFBQWE7QUFDYjtBQUNBO0FBQ0E7QUFDQTtBQUNBLGFBQWE7QUFDYjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsZ0JBQWdCLFNBQVM7QUFDekI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQSxZQUFZLFNBQVM7QUFDckI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMLGtDQUFrQyw2QkFBNkI7QUFDL0Qsb0pBQW9KLGlCQUFpQjtBQUNySztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0wsbUNBQW1DLDhCQUE4QjtBQUNqRSx3SkFBd0osa0JBQWtCO0FBQzFLO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTCxtQ0FBbUMsOEJBQThCO0FBQ2pFLHdKQUF3SixrQkFBa0I7QUFDMUs7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMLCtCQUErQiwwQkFBMEI7QUFDekQscUlBQXFJLGNBQWM7QUFDbko7QUFDQTtBQUNBO0FBQ0EsS0FBSyxHQUFHO0FBQ1IsNkRBQTZELGlCQUFpQixHQUFHO0FBQ2pGLGdEQUFnRCxZQUFZLEdBQUc7QUFDL0Q7QUFDQSx5REFBeUQsbUJBQW1CO0FBQzVFOztBQUVBO0FBQ0EsWUFBWSxTQUFTO0FBQ3JCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0wsNEJBQTRCLGlDQUFpQztBQUM3RDtBQUNBO0FBQ0EsS0FBSztBQUNMLG9CQUFvQiwyQkFBMkI7QUFDL0M7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EscUZBQXFGLHNCQUFzQjtBQUMzRyx5RkFBeUYsc0JBQXNCO0FBQy9HO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSwwQkFBMEIsc0NBQXNDO0FBQ2hFLDhCQUE4QixxQ0FBcUM7QUFDbkU7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGFBQWE7QUFDYixTQUFTO0FBQ1Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGFBQWE7QUFDYixTQUFTO0FBQ1Q7QUFDQTtBQUNBLGdCQUFnQixvQ0FBb0M7QUFDcEQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSwrQkFBK0IsdUJBQXVCLGNBQWMsWUFBWSxNQUFNLHNDQUFzQyxTQUFTLDBCQUEwQjtBQUMvSjtBQUNBO0FBQ0EsK0JBQStCLHVCQUF1QixlQUFlLGFBQWEsTUFBTSxzQ0FBc0MsU0FBUywyQkFBMkI7QUFDbEs7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSw4QkFBOEIsc0JBQXNCO0FBQ3BEO0FBQ0E7QUFDQSw4QkFBOEIsc0JBQXNCO0FBQ3BEO0FBQ0E7QUFDQSw4QkFBOEIsc0JBQXNCO0FBQ3BEO0FBQ0E7QUFDQTtBQUNBLGdCQUFnQixzQkFBc0I7QUFDdEM7QUFDQTtBQUNBO0FBQ0E7QUFDQSxnQkFBZ0Isc0JBQXNCO0FBQ3RDO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsOEJBQThCO0FBQzlCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxnQkFBZ0Isc0JBQXNCO0FBQ3RDO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsZ0JBQWdCLHNCQUFzQjtBQUN0QztBQUNBO0FBQ0E7QUFDQSw4QkFBOEIsc0JBQXNCO0FBQ3BEO0FBQ0E7QUFDQSw4QkFBOEIsc0JBQXNCO0FBQ3BEO0FBQ0E7QUFDQSxnQkFBZ0Isc0JBQXNCO0FBQ3RDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsZ0JBQWdCLHVCQUF1QjtBQUN2QztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsYUFBYTtBQUNiO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsYUFBYTtBQUNiO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGFBQWE7QUFDYjtBQUNBO0FBQ0E7QUFDQTtBQUNBLGFBQWE7QUFDYjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQSxZQUFZLFNBQVM7QUFDckI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQSx5QkFBeUIsb0JBQW9CO0FBQzdDO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLDhCQUE4QixzQkFBc0I7QUFDcEQ7QUFDQTtBQUNBLG1DQUFtQztBQUNuQztBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBLG9CQUFvQixnQ0FBZ0M7QUFDcEQsd0JBQXdCLCtCQUErQjtBQUN2RDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLG9CQUFvQiwrQkFBK0I7QUFDbkQsd0JBQXdCLGdDQUFnQztBQUN4RCw0QkFBNEIsK0JBQStCO0FBQzNEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxvQkFBb0IsZ0NBQWdDO0FBQ3BELHdCQUF3QiwrQkFBK0I7QUFDdkQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxvQkFBb0IsK0JBQStCO0FBQ25ELHdCQUF3QixnQ0FBZ0M7QUFDeEQsNEJBQTRCLCtCQUErQjtBQUMzRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLCtDQUErQztBQUMvQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGdCQUFnQix1QkFBdUI7QUFDdkM7QUFDQTtBQUNBO0FBQ0EsYUFBYTtBQUNiO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGlCQUFpQjtBQUNqQixhQUFhO0FBQ2I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsaUJBQWlCO0FBQ2pCLGFBQWE7QUFDYjtBQUNBO0FBQ0EsYUFBYTtBQUNiO0FBQ0E7QUFDQTtBQUNBLGFBQWE7QUFDYjtBQUNBO0FBQ0E7QUFDQTtBQUNBLGFBQWE7QUFDYjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsaUJBQWlCO0FBQ2pCLGFBQWE7QUFDYjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsaUJBQWlCO0FBQ2pCLGFBQWE7QUFDYjtBQUNBO0FBQ0EsYUFBYTtBQUNiO0FBQ0E7QUFDQTtBQUNBLGFBQWE7QUFDYjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxnQkFBZ0IsaUJBQWlCO0FBQ2pDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsOEJBQThCLHNCQUFzQjtBQUNwRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVM7QUFDVDtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsQ0FBQzs7QUFFRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLDRCQUE0QixpQkFBaUI7QUFDN0M7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsNEJBQTRCLGlCQUFpQjtBQUM3QztBQUNBLGdDQUFnQyxrQkFBa0I7QUFDbEQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsNEJBQTRCLGlCQUFpQjtBQUM3QztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLDRCQUE0QjtBQUM1QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EseUJBQXlCO0FBQ3pCO0FBQ0E7QUFDQTtBQUNBLFNBQVM7QUFDVDtBQUNBO0FBQ0EsZ0JBQWdCLDRGQUE0RjtBQUM1RztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxvQ0FBb0MsSUFBSSxJQUFJLGdFQUFnRTtBQUM1RztBQUNBLFNBQVM7QUFDVDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLDJCQUEyQjtBQUMzQjtBQUNBO0FBQ0EsZ0JBQWdCLCtDQUErQztBQUMvRDtBQUNBLGlFQUFpRSxrR0FBa0csMERBQTBELDZHQUE2RztBQUMxVTtBQUNBO0FBQ0E7QUFDQSxnQkFBZ0IsNENBQTRDO0FBQzVEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxnQkFBZ0IsMEJBQTBCO0FBQzFDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsZ0JBQWdCLGVBQWU7QUFDL0I7QUFDQTtBQUNBLHdCQUF3Qix5QkFBeUI7QUFDakQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSx3QkFBd0IsbUJBQW1CO0FBQzNDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGtNQUFrTTtBQUNsTTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVM7QUFDVDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSx3QkFBd0Isd0JBQXdCO0FBQ2hEO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsNEJBQTRCO0FBQzVCLGdCQUFnQixnQ0FBZ0M7QUFDaEQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsZ0JBQWdCLFlBQVk7QUFDNUI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHlDQUF5QyxrQkFBa0Isb0JBQW9CLGFBQWE7QUFDNUY7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSx3QkFBd0IseUJBQXlCO0FBQ2pEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSx3QkFBd0IsaUJBQWlCO0FBQ3pDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSx3Q0FBd0MsUUFBUTtBQUNoRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esd0JBQXdCLG1CQUFtQjtBQUMzQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxpQkFBaUI7QUFDakI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EseUJBQXlCO0FBQ3pCLGFBQWE7QUFDYjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxhQUFhO0FBQ2I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBLFNBQVM7QUFDVDtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0E7QUFDQSxTQUFTO0FBQ1Qsd0JBQXdCLDBCQUEwQjtBQUNsRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLDJCQUEyQixzQkFBc0I7QUFDakQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHdCQUF3Qix3QkFBd0I7QUFDaEQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSx3QkFBd0IsdUJBQXVCO0FBQy9DO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsZ0dBQWdHLDRCQUE0QjtBQUM1SDtBQUNBLGdHQUFnRyw0QkFBNEI7QUFDNUg7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSwwQkFBMEIsaUJBQWlCO0FBQzNDO0FBQ0E7QUFDQTtBQUNBLGlCQUFpQjtBQUNqQjtBQUNBO0FBQ0EsMkJBQTJCLHNCQUFzQjtBQUNqRDtBQUNBO0FBQ0E7QUFDQTtBQUNBLGlCQUFpQjtBQUNqQjtBQUNBO0FBQ0EsMkJBQTJCLHNCQUFzQjtBQUNqRDtBQUNBOztBQUVBO0FBQ0E7QUFDQSxtRUFBbUUsV0FBVztBQUM5RTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7O0FBRUE7O0FBRUE7QUFDQTtBQUNBO0FBQ0EsYUFBYTtBQUNiO0FBQ0E7QUFDQTtBQUNBLEVBQUU7QUFDRjs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0EsaURBQWlELE9BQU87QUFDeEQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLCtDQUErQyxhQUFhO0FBQzVEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esa0NBQWtDO0FBQ2xDLHFDQUFxQztBQUNyQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0E7QUFDQTtBQUNBLHdCQUF3Qix1QkFBdUI7QUFDL0M7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxDQUFDO0FBQ0Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQSxDQUFDOztBQUVEO0FBQ0EsK0NBQStDLGFBQWE7QUFDNUQ7O0FBRUE7QUFDQTtBQUNBLGdDQUFnQztBQUNoQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esd0JBQXdCLHVCQUF1QjtBQUMvQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxDQUFDO0FBQ0Q7O0FBRUEsQ0FBQzs7QUFFRDtBQUNBLCtDQUErQyxhQUFhO0FBQzVEOztBQUVBLHlDQUF5QyxxQ0FBcUMsdUJBQXVCO0FBQ3JHLHlDQUF5QyxxQ0FBcUMsdUJBQXVCOztBQUVyRywwQ0FBMEMscUNBQXFDLHVCQUF1QjtBQUN0RztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBLENBQUM7O0FBRUQ7QUFDQTtBQUNBLG9CQUFvQixtQkFBbUI7QUFDdkM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esb0JBQW9CLGtCQUFrQjtBQUN0QztBQUNBO0FBQ0Esb0JBQW9CLG1CQUFtQjtBQUN2QztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxvQkFBb0Isa0JBQWtCO0FBQ3RDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLG9CQUFvQixrQkFBa0I7QUFDdEM7QUFDQTtBQUNBLG9CQUFvQixtQkFBbUI7QUFDdkM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esb0JBQW9CLGtCQUFrQjtBQUN0QztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxvQkFBb0IsbUJBQW1CO0FBQ3ZDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0Esb0JBQW9CLG1CQUFtQjtBQUN2QztBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxZQUFZLFNBQVM7QUFDckI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLDRCQUE0QjtBQUM1QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsMkJBQTJCO0FBQzNCO0FBQ0E7QUFDQTtBQUNBLDJCQUEyQjtBQUMzQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHlCQUF5QjtBQUN6QjtBQUNBLGdCQUFnQixzQ0FBc0M7QUFDdEQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxtREFBbUQ7QUFDbkQ7QUFDQTtBQUNBO0FBQ0E7QUFDQSxvREFBb0Q7QUFDcEQ7QUFDQSxpQ0FBaUMsZ0NBQWdDO0FBQ2pFO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSx3Q0FBd0Msa0JBQWtCO0FBQzFEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esc0RBQXNELE1BQU07QUFDNUQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGlFQUFpRSxjQUFjO0FBQy9FO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxpQ0FBaUM7QUFDakM7QUFDQSw0QkFBNEIsMkJBQTJCO0FBQ3ZEO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsK0JBQStCLG9CQUFvQjtBQUNuRDtBQUNBO0FBQ0EsZ0NBQWdDLG9CQUFvQjtBQUNwRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGlDQUFpQztBQUNqQztBQUNBLDRCQUE0QiwyQkFBMkI7QUFDdkQ7QUFDQTtBQUNBO0FBQ0E7QUFDQSwrQkFBK0IsbUJBQW1CO0FBQ2xEO0FBQ0E7QUFDQSxnQ0FBZ0Msb0JBQW9CO0FBQ3BEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsaUNBQWlDO0FBQ2pDLGdCQUFnQixpQkFBaUI7QUFDakM7QUFDQSw0QkFBNEIsMkJBQTJCO0FBQ3ZEO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsK0JBQStCLG1CQUFtQjtBQUNsRDtBQUNBO0FBQ0EsZ0NBQWdDLG9CQUFvQjtBQUNwRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGlDQUFpQztBQUNqQztBQUNBLDRCQUE0QiwyQkFBMkI7QUFDdkQ7QUFDQTtBQUNBO0FBQ0E7QUFDQSwrQkFBK0IsbUJBQW1CO0FBQ2xEO0FBQ0E7QUFDQSxnQ0FBZ0Msb0JBQW9CO0FBQ3BEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsYUFBYTtBQUNiO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSx5QkFBeUI7QUFDekI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGFBQWE7QUFDYjtBQUNBO0FBQ0E7QUFDQSxhQUFhO0FBQ2I7QUFDQTtBQUNBO0FBQ0EsYUFBYTtBQUNiO0FBQ0E7QUFDQTtBQUNBLGFBQWE7QUFDYjtBQUNBO0FBQ0E7QUFDQSxhQUFhO0FBQ2I7QUFDQTtBQUNBO0FBQ0EsYUFBYTtBQUNiO0FBQ0E7QUFDQTtBQUNBLGFBQWE7QUFDYjtBQUNBO0FBQ0E7QUFDQSxhQUFhO0FBQ2I7QUFDQTtBQUNBO0FBQ0EsYUFBYTtBQUNiO0FBQ0E7QUFDQTtBQUNBLGFBQWE7QUFDYjtBQUNBO0FBQ0E7QUFDQSxhQUFhO0FBQ2I7QUFDQTtBQUNBO0FBQ0EsYUFBYTtBQUNiO0FBQ0E7QUFDQTtBQUNBLGFBQWE7QUFDYjtBQUNBO0FBQ0E7QUFDQSxhQUFhO0FBQ2I7QUFDQTtBQUNBO0FBQ0EsYUFBYTtBQUNiO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esb0NBQW9DLEVBQUUsSUFBSSxLQUFLO0FBQy9DO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGdCQUFnQix1SkFBdUo7QUFDdks7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsbUNBQW1DLGtCQUFrQixvQkFBb0IsYUFBYTtBQUN0RjtBQUNBO0FBQ0E7QUFDQSx3QkFBd0IsaUJBQWlCO0FBQ3pDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSx3QkFBd0IsaUJBQWlCO0FBQ3pDO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsZ0JBQWdCLHFFQUFxRTtBQUNyRjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsYUFBYTtBQUNiO0FBQ0E7QUFDQTtBQUNBLG1DQUFtQztBQUNuQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsNEJBQTRCO0FBQzVCLGdCQUFnQixnQ0FBZ0M7QUFDaEQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSx1Q0FBdUM7QUFDdkMsZ0JBQWdCLGdDQUFnQztBQUNoRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGlCQUFpQjtBQUNqQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsMkNBQTJDLFlBQVk7QUFDdkQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLCtCQUErQixtQkFBbUI7QUFDbEQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxvQ0FBb0MsbUJBQW1CO0FBQ3ZEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLDJDQUEyQyxZQUFZO0FBQ3ZEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLCtCQUErQixvQkFBb0I7QUFDbkQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esb0NBQW9DLHVCQUF1QjtBQUMzRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLDJDQUEyQyxZQUFZO0FBQ3ZEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLCtCQUErQixvQkFBb0I7QUFDbkQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esb0NBQW9DLHVCQUF1QjtBQUMzRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSwyQ0FBMkMsWUFBWTtBQUN2RDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSwrQkFBK0Isb0JBQW9CO0FBQ25EO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLG9DQUFvQyx1QkFBdUI7QUFDM0Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxnQkFBZ0IseUJBQXlCO0FBQ3pDLDRCQUE0QiwyQkFBMkI7QUFDdkQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsK0JBQStCLG1CQUFtQjtBQUNsRDtBQUNBLGdDQUFnQyxxQkFBcUI7QUFDckQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsNEJBQTRCLDJCQUEyQjtBQUN2RDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxtQ0FBbUMsYUFBYTtBQUNoRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGdCQUFnQixhQUFhO0FBQzdCLGdCQUFnQixzQ0FBc0M7QUFDdEQsNEJBQTRCLDJCQUEyQjtBQUN2RDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSwrQkFBK0Isb0JBQW9CO0FBQ25EO0FBQ0EsZ0NBQWdDLHFCQUFxQjtBQUNyRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsNEJBQTRCLGlCQUFpQjtBQUM3QztBQUNBO0FBQ0E7QUFDQSxpQkFBaUI7QUFDakI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLDRCQUE0QixpQkFBaUI7QUFDN0M7QUFDQTtBQUNBO0FBQ0EsaUJBQWlCO0FBQ2pCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSw0QkFBNEIsaUJBQWlCO0FBQzdDO0FBQ0E7QUFDQTtBQUNBLGlCQUFpQjtBQUNqQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EscUhBQXFIO0FBQ3JIO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSx3SEFBd0g7QUFDeEg7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsZ0JBQWdCLGVBQWU7QUFDL0I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsNEJBQTRCLHlCQUF5QjtBQUNyRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EscUJBQXFCO0FBQ3JCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGlCQUFpQjtBQUNqQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esd0JBQXdCLHlCQUF5QjtBQUNqRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsaUJBQWlCO0FBQ2pCO0FBQ0E7QUFDQTtBQUNBLGFBQWE7QUFDYjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBO0FBQ0Esd0JBQXdCLG1CQUFtQjtBQUMzQztBQUNBO0FBQ0E7QUFDQSxhQUFhO0FBQ2I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLDhDQUE4QyxzQkFBc0I7QUFDcEU7QUFDQSxnREFBZ0QsdUJBQXVCO0FBQ3ZFO0FBQ0EsdUJBQXVCLGlCQUFpQjtBQUN4QztBQUNBO0FBQ0E7QUFDQTtBQUNBLHlCQUF5QjtBQUN6QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsZ0RBQWdELHNCQUFzQjtBQUN0RTtBQUNBLGtEQUFrRCx1QkFBdUI7QUFDekU7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQSx3QkFBd0IsdUJBQXVCO0FBQy9DO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGdCQUFnQiw2QkFBNkI7QUFDN0M7QUFDQTtBQUNBO0FBQ0EsaUNBQWlDLFVBQVU7QUFDM0M7QUFDQTtBQUNBO0FBQ0E7QUFDQSx5REFBeUQsWUFBWSxjQUFjLFdBQVc7QUFDOUY7QUFDQTtBQUNBLHNEQUFzRCxZQUFZLGNBQWMsV0FBVztBQUMzRjtBQUNBO0FBQ0E7QUFDQTtBQUNBLHlDQUF5QyxPQUFPLEdBQUcseUNBQXlDO0FBQzVGO0FBQ0E7QUFDQSwwQ0FBMEMsT0FBTyxHQUFHLHlDQUF5QztBQUM3RjtBQUNBLGFBQWE7QUFDYiwrQkFBK0IsZ0JBQWdCLEVBQUUsc0JBQXNCO0FBQ3ZFO0FBQ0E7QUFDQSw4Q0FBOEMsT0FBTztBQUNyRDtBQUNBO0FBQ0Esa0NBQWtDLE9BQU87QUFDekM7QUFDQTtBQUNBO0FBQ0EsMENBQTBDLE9BQU8sSUFBSSxlQUFlO0FBQ3BFO0FBQ0E7QUFDQSx3Q0FBd0MsT0FBTztBQUMvQztBQUNBLDBEQUEwRCxXQUFXO0FBQ3JFO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsdURBQXVEO0FBQ3ZELHdDQUF3QyxJQUFJO0FBQzVDLDJCQUEyQixHQUFHO0FBQzlCO0FBQ0E7QUFDQTtBQUNBLGdDQUFnQywwQ0FBMEM7QUFDMUU7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EscUNBQXFDLElBQUksSUFBSSxnQkFBZ0I7QUFDN0Q7QUFDQSx1QkFBdUIsRUFBRSxRQUFRO0FBQ2pDO0FBQ0E7QUFDQSx5QkFBeUIsdUJBQXVCO0FBQ2hEO0FBQ0EsMEJBQTBCLFlBQVksRUFBRSxrQkFBa0IsT0FBTyxTQUFTLFFBQVE7QUFDbEY7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBLG9CQUFvQix5QkFBeUI7QUFDN0M7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxvQkFBb0IseUJBQXlCO0FBQzdDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esb0JBQW9CLHlCQUF5QjtBQUM3QztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLG9CQUFvQix5QkFBeUI7QUFDN0M7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLG9CQUFvQixVQUFVO0FBQzlCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esb0JBQW9CLHlCQUF5QjtBQUM3QztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsNEJBQTRCO0FBQzVCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsZ0NBQWdDLDJCQUEyQjtBQUMzRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLCtDQUErQyxXQUFXO0FBQzFEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLG9DQUFvQyxvQkFBb0I7QUFDeEQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSx3QkFBd0IsaUJBQWlCO0FBQ3pDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxzREFBc0QsMEJBQTBCO0FBQ2hGO0FBQ0EsNEJBQTRCLDJCQUEyQjtBQUN2RDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsaUJBQWlCO0FBQ2pCO0FBQ0EsYUFBYTtBQUNiO0FBQ0E7QUFDQTtBQUNBLFNBQVM7QUFDVDtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHNEQUFzRCwwQkFBMEI7QUFDaEY7QUFDQTtBQUNBO0FBQ0EsMkNBQTJDLFdBQVc7QUFDdEQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGlCQUFpQjtBQUNqQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsaUJBQWlCO0FBQ2pCO0FBQ0E7QUFDQTtBQUNBLGlCQUFpQjtBQUNqQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxpQkFBaUI7QUFDakI7QUFDQTtBQUNBO0FBQ0E7QUFDQSxpQkFBaUI7QUFDakI7QUFDQTtBQUNBO0FBQ0E7QUFDQSxxQkFBcUI7QUFDckI7QUFDQSxpQkFBaUI7QUFDakI7QUFDQTtBQUNBO0FBQ0E7QUFDQSw0QkFBNEIsMkJBQTJCO0FBQ3ZEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxhQUFhO0FBQ2I7QUFDQTtBQUNBLGFBQWE7QUFDYjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxpQkFBaUI7QUFDakI7QUFDQSxhQUFhO0FBQ2I7QUFDQTtBQUNBO0FBQ0EsNEJBQTRCLDJCQUEyQjtBQUN2RDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsNEJBQTRCLDJCQUEyQjtBQUN2RDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsaUJBQWlCO0FBQ2pCO0FBQ0EsYUFBYTtBQUNiO0FBQ0E7QUFDQTtBQUNBLDRCQUE0QiwyQkFBMkI7QUFDdkQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxhQUFhO0FBQ2I7QUFDQTtBQUNBLFNBQVM7QUFDVDtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0E7QUFDQTtBQUNBLFNBQVM7QUFDVDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxtQ0FBbUM7QUFDbkM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsYUFBYTtBQUNiO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsMkJBQTJCLHNCQUFzQjtBQUNqRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esd0JBQXdCLHVCQUF1QjtBQUMvQztBQUNBO0FBQ0E7QUFDQSxhQUFhO0FBQ2I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLDhDQUE4QyxzQkFBc0I7QUFDcEU7QUFDQSxnREFBZ0QsdUJBQXVCO0FBQ3ZFO0FBQ0EsdUJBQXVCLGlCQUFpQjtBQUN4QztBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSwyQkFBMkIsc0JBQXNCO0FBQ2pEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsMkJBQTJCLHNCQUFzQjtBQUNqRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSw4QkFBOEIsc0JBQXNCO0FBQ3BEO0FBQ0E7QUFDQSw4QkFBOEIsc0JBQXNCO0FBQ3BEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGdCQUFnQixzQkFBc0I7QUFDdEM7QUFDQTtBQUNBO0FBQ0E7QUFDQSxnQkFBZ0Isc0JBQXNCO0FBQ3RDO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0EsNEJBQTRCO0FBQzVCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esd0JBQXdCLDJCQUEyQjtBQUNuRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esb0RBQW9ELGdDQUFnQztBQUNwRjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGdEQUFnRCxnQ0FBZ0M7QUFDaEY7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esd0JBQXdCLHNDQUFzQztBQUM5RDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esb0JBQW9CLHdDQUF3QztBQUM1RDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHdCQUF3QixtQkFBbUI7QUFDM0M7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSx1Q0FBdUM7QUFDdkMsd0JBQXdCLFVBQVU7QUFDbEM7QUFDQTtBQUNBLDRCQUE0QixxQkFBcUI7QUFDakQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSw0QkFBNEI7QUFDNUIsZ0JBQWdCLGdDQUFnQztBQUNoRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSx3QkFBd0IseUJBQXlCO0FBQ2pEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHdCQUF3QixpQkFBaUI7QUFDekM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSw4Q0FBOEMsUUFBUTtBQUN0RDtBQUNBO0FBQ0Esd0NBQXdDLFFBQVE7QUFDaEQ7QUFDQTtBQUNBLDhDQUE4QyxRQUFRO0FBQ3REO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esd0JBQXdCLG1CQUFtQjtBQUMzQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSx3QkFBd0IsaUJBQWlCO0FBQ3pDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EscURBQXFELFVBQVU7QUFDL0Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esd0RBQXdELFNBQVM7QUFDakUsaURBQWlEO0FBQ2pEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsYUFBYTtBQUNiO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsYUFBYTtBQUNiLFNBQVM7QUFDVDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxhQUFhO0FBQ2IsU0FBUztBQUNUO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSwrQkFBK0IsaUJBQWlCO0FBQ2hEO0FBQ0E7QUFDQTtBQUNBLHNDQUFzQyx1QkFBdUI7QUFDN0Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxtREFBbUQsU0FBUztBQUM1RDtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLDhFQUE4RSwwQ0FBMEM7QUFDeEg7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLG1GQUFtRixtQ0FBbUM7QUFDdEg7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxnQ0FBZ0MsdUJBQXVCO0FBQ3ZEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsZ0NBQWdDLHVCQUF1QjtBQUN2RDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSx3QkFBd0IsZ0JBQWdCO0FBQ3hDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esd0JBQXdCLHVCQUF1QjtBQUMvQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHFDQUFxQyxtQ0FBbUM7QUFDeEU7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxnQkFBZ0IsYUFBYTtBQUM3QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsNENBQTRDLFNBQVM7QUFDckQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSwrREFBK0QsVUFBVTtBQUN6RTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGdCQUFnQiw2QkFBNkI7QUFDN0MsOENBQThDLFNBQVM7QUFDdkQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsMkRBQTJELE1BQU07QUFDakU7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSx5QkFBeUIsVUFBVTtBQUNuQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esd0JBQXdCLGlCQUFpQjtBQUN6QztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSx1QkFBdUI7QUFDdkIsbUJBQW1CO0FBQ25CLG1CQUFtQjtBQUNuQjtBQUNBLHdCQUF3QiwwQkFBMEI7QUFDbEQsbUNBQW1DLHFDQUFxQztBQUN4RSwyQkFBMkIsNkJBQTZCO0FBQ3hELDZCQUE2QiwrQkFBK0I7QUFDNUQsRUFBRTtBQUNGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsZ0NBQWdDLGlCQUFpQjtBQUNqRDtBQUNBO0FBQ0E7QUFDQTtBQUNBLG1EQUFtRCxTQUFTO0FBQzVEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSwrQ0FBK0MsU0FBUztBQUN4RDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBLFFBQVEsTUFBTSxLQUFLLE9BQU8scUJBQXFCO0FBQy9DO0FBQ0E7QUFDQSxvQkFBb0IseUJBQXlCO0FBQzdDO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0EsU0FBUyxNQUFNLFdBQVcsTUFBTSxLQUFLLE9BQU87QUFDNUM7QUFDQTtBQUNBLG9CQUFvQiwyQkFBMkI7QUFDL0M7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQSxvQkFBb0IsNEJBQTRCO0FBQ2hEO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxvQkFBb0IseUJBQXlCO0FBQzdDO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0EsYUFBYSxNQUFNLEtBQUssT0FBTyxtQkFBbUI7QUFDbEQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsMEJBQTBCLG9CQUFvQjtBQUM5QztBQUNBO0FBQ0E7QUFDQSxrQ0FBa0MsNEJBQTRCO0FBQzlEO0FBQ0E7QUFDQTtBQUNBLHFDQUFxQywwQkFBMEI7QUFDL0Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBLGVBQWUsTUFBTSxXQUFXLE1BQU0sS0FBSztBQUMzQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSw4QkFBOEIsd0JBQXdCO0FBQ3REO0FBQ0E7QUFDQTtBQUNBLGtDQUFrQyw0QkFBNEI7QUFDOUQ7QUFDQSxxQ0FBcUMsMEJBQTBCO0FBQy9EO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0EsWUFBWSxVQUFVO0FBQ3RCLG9CQUFvQixvQkFBb0I7QUFDeEM7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQSxlQUFlLE1BQU0sS0FBSyxPQUFPLFdBQVcsTUFBTSxhQUFhLE1BQU0sS0FBSyxPQUFPO0FBQ2pGO0FBQ0E7QUFDQSxvQkFBb0IseUJBQXlCO0FBQzdDO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQSxTQUFTLEdBQUcsWUFBWSxNQUFNO0FBQzlCO0FBQ0E7QUFDQSxvQkFBb0IseUJBQXlCO0FBQzdDLDJEQUEyRDtBQUMzRDtBQUNBO0FBQ0E7O0FBRUE7QUFDQSxTQUFTLE1BQU0sV0FBVyxHQUFHLGFBQWEsR0FBRztBQUM3QztBQUNBO0FBQ0Esb0JBQW9CLDJCQUEyQjtBQUMvQztBQUNBO0FBQ0E7O0FBRUE7QUFDQSxZQUFZLFVBQVU7QUFDdEI7QUFDQSx5QkFBeUIsa0JBQWtCO0FBQzNDO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0EsU0FBUyxNQUFNLGFBQWEsR0FBRztBQUMvQjtBQUNBO0FBQ0EsWUFBWSxVQUFVO0FBQ3RCO0FBQ0EseUJBQXlCLGtCQUFrQjtBQUMzQztBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBLG9CQUFvQix5QkFBeUI7QUFDN0M7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBLG9CQUFvQiwyQkFBMkI7QUFDL0M7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQSxvQkFBb0IsMkJBQTJCO0FBQy9DO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxvQkFBb0IsMkJBQTJCO0FBQy9DO0FBQ0E7QUFDQTtBQUNBLG9CQUFvQiwyQkFBMkI7QUFDL0M7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBLG9CQUFvQix5QkFBeUI7QUFDN0M7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQSxvQkFBb0IsMkJBQTJCO0FBQy9DO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVM7QUFDVDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSx3Q0FBd0M7QUFDeEMsU0FBUztBQUNUO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHdDQUF3QztBQUN4QyxTQUFTO0FBQ1Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVM7QUFDVDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsYUFBYTtBQUNiLHdDQUF3QztBQUN4QyxTQUFTO0FBQ1Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsYUFBYTtBQUNiO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxnQ0FBZ0M7QUFDaEMsd0NBQXdDO0FBQ3hDLFNBQVM7QUFDVDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esa0RBQWtELFNBQVM7QUFDM0Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxrREFBa0QsU0FBUztBQUMzRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSx3QkFBd0IsMkJBQTJCO0FBQ25EO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSx5Q0FBeUM7QUFDekMsK0NBQStDO0FBQy9DO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQSxZQUFZLFVBQVU7QUFDdEI7QUFDQTtBQUNBLG9CQUFvQixvQkFBb0I7QUFDeEM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsNEJBQTRCO0FBQzVCLHlCQUF5QjtBQUN6QiwyQkFBMkI7QUFDM0I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0EseUJBQXlCO0FBQ3pCO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGdCQUFnQixnQkFBZ0I7QUFDaEM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxnQkFBZ0IsMEJBQTBCO0FBQzFDO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esd0JBQXdCLHlCQUF5QjtBQUNqRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxnQkFBZ0Isd0JBQXdCO0FBQ3hDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxnQkFBZ0IsMkJBQTJCO0FBQzNDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxnQkFBZ0IsUUFBUTtBQUN4QixnQkFBZ0IsZUFBZTtBQUMvQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxtREFBbUQsU0FBUztBQUM1RDtBQUNBLGlFQUFpRSxFQUFFO0FBQ25FO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsbURBQW1ELFNBQVM7QUFDNUQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxnQkFBZ0IsMEJBQTBCO0FBQzFDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBO0FBQ0EsZ0JBQWdCLFFBQVE7QUFDeEI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSwyREFBMkQsdUJBQXVCO0FBQ2xGO0FBQ0E7QUFDQTtBQUNBLDBFQUEwRTtBQUMxRSxtRkFBbUY7QUFDbkY7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsZ0JBQWdCLFFBQVE7QUFDeEIsZ0JBQWdCLFlBQVk7QUFDNUI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxnQkFBZ0Isc0NBQXNDO0FBQ3RELGdCQUFnQiw4QkFBOEI7QUFDOUMsZ0JBQWdCLGVBQWU7QUFDL0IsZ0JBQWdCLGNBQWM7QUFDOUI7QUFDQTtBQUNBLGtDQUFrQyxrQ0FBa0M7QUFDcEU7QUFDQSxvQkFBb0Isa0JBQWtCO0FBQ3RDO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsNEJBQTRCLG9CQUFvQjtBQUNoRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGdCQUFnQixRQUFRO0FBQ3hCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsdUVBQXVFLFNBQVM7QUFDaEY7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLDJCQUEyQjtBQUMzQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGFBQWE7QUFDYjtBQUNBO0FBQ0E7QUFDQSxhQUFhO0FBQ2I7QUFDQTtBQUNBO0FBQ0EsYUFBYTtBQUNiO0FBQ0E7QUFDQTtBQUNBLGFBQWE7QUFDYjtBQUNBO0FBQ0E7QUFDQSxhQUFhO0FBQ2I7QUFDQTtBQUNBO0FBQ0EsYUFBYTtBQUNiO0FBQ0E7QUFDQTtBQUNBLGFBQWE7QUFDYjtBQUNBO0FBQ0E7QUFDQSxhQUFhO0FBQ2I7QUFDQTtBQUNBO0FBQ0E7QUFDQSxvQ0FBb0MsRUFBRSxJQUFJLEtBQUs7QUFDL0M7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsOEJBQThCO0FBQzlCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxnQkFBZ0IsZ0VBQWdFO0FBQ2hGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esb0JBQW9CLHVDQUF1QztBQUMzRDtBQUNBLDRCQUE0QixtQkFBbUI7QUFDL0M7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLG1DQUFtQyxFQUFFLG9CQUFvQixNQUFNO0FBQy9EO0FBQ0E7QUFDQSwyQkFBMkIsc0JBQXNCO0FBQ2pEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxnQkFBZ0IsaUJBQWlCO0FBQ2pDO0FBQ0E7QUFDQSx1QkFBdUIsMkRBQTJEO0FBQ2xGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxhQUFhO0FBQ2I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsYUFBYTtBQUNiO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxnQkFBZ0IsVUFBVTtBQUMxQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVM7QUFDVDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsZ0JBQWdCLFFBQVE7QUFDeEIsZ0JBQWdCLFlBQVk7QUFDNUI7QUFDQSxnQkFBZ0IsU0FBUztBQUN6QjtBQUNBO0FBQ0E7QUFDQSxvQkFBb0IsU0FBUztBQUM3QixpREFBaUQsU0FBUztBQUMxRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGlEQUFpRCxTQUFTO0FBQzFEO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esb0RBQW9ELEVBQUUsOEJBQThCLEVBQUUseUJBQXlCLE9BQU8sSUFBSSxVQUFVO0FBQ3BJO0FBQ0EseUNBQXlDLE9BQU8sSUFBSSxVQUFVO0FBQzlEO0FBQ0E7QUFDQSxxQ0FBcUMsRUFBRTtBQUN2QztBQUNBLHFDQUFxQyxFQUFFO0FBQ3ZDO0FBQ0EscUNBQXFDLEVBQUU7QUFDdkM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsNkRBQTZELFNBQVM7QUFDdEU7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsZ0RBQWdELEVBQUUsSUFBSSxFQUFFO0FBQ3hEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLDRCQUE0QjtBQUM1Qix3REFBd0Q7QUFDeEQ7QUFDQTtBQUNBLGdEQUFnRDtBQUNoRCxxREFBcUQ7QUFDckQ7QUFDQTtBQUNBO0FBQ0Esd0JBQXdCO0FBQ3hCO0FBQ0E7QUFDQSxnREFBZ0Q7QUFDaEQscURBQXFEO0FBQ3JELHFEQUFxRDtBQUNyRCx1REFBdUQ7QUFDdkQsZ0VBQWdFO0FBQ2hFO0FBQ0E7QUFDQSwyQ0FBMkM7QUFDM0MsMkJBQTJCLG9CQUFvQjtBQUMvQyxhQUFhLEVBQUU7QUFDZjtBQUNBO0FBQ0E7QUFDQTtBQUNBLDZDQUE2QyxTQUFTO0FBQ3REO0FBQ0EscUNBQXFDLEVBQUU7QUFDdkMsZUFBZSxxQkFBcUI7QUFDcEMsY0FBYyx5REFBeUQ7QUFDdkUsZUFBZSwyREFBMkQ7QUFDMUUsaUJBQWlCO0FBQ2pCLEtBQUs7QUFDTDtBQUNBO0FBQ0E7QUFDQSwyREFBMkQsT0FBTyxxQkFBcUI7QUFDdkYsWUFBWTtBQUNaLGdCQUFnQjtBQUNoQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxlQUFlO0FBQ2YsSUFBSTtBQUNKLGlCQUFpQjtBQUNqQiwyREFBMkQ7QUFDM0Q7QUFDQSxJQUFJO0FBQ0o7QUFDQSwrREFBK0QsRUFBRSw4REFBOEQscUJBQXFCO0FBQ3BKO0FBQ0EsSUFBSTtBQUNKO0FBQ0EsNkVBQTZFLEVBQUUsK0RBQStELHFCQUFxQjtBQUNuSztBQUNBO0FBQ0EsTUFBTSxrQ0FBa0M7QUFDeEM7QUFDQSxNQUFNO0FBQ047QUFDQTtBQUNBLGdCQUFnQjtBQUNoQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsTUFBTSxpQkFBaUI7QUFDdkIsMENBQTBDLG1CQUFtQix1QkFBdUI7QUFDcEY7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEVBQUU7QUFDRjtBQUNBOztBQUVBO0FBQ0E7QUFDQSw0REFBNEQsUUFBUTtBQUNwRTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0EsSUFBSTtBQUNKO0FBQ0EsNEZBQTRGLG1CQUFtQjtBQUMvRyx1RUFBdUUsbUJBQW1CO0FBQzFGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxJQUFJO0FBQ0osSUFBSTtBQUNKLElBQUk7QUFDSixJQUFJO0FBQ0osSUFBSSxnQkFBZ0I7QUFDcEI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esd0JBQXdCLGlCQUFpQjtBQUN6QztBQUNBO0FBQ0EsNEJBQTRCLG9CQUFvQjtBQUNoRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSw0QkFBNEI7QUFDNUI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0E7QUFDQTtBQUNBLHlCQUF5QjtBQUN6QjtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGdCQUFnQixhQUFhO0FBQzdCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxpQkFBaUI7QUFDakI7QUFDQTtBQUNBLGdCQUFnQixpQkFBaUI7QUFDakMsZ0JBQWdCLDBCQUEwQjtBQUMxQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLG1EQUFtRCxTQUFTO0FBQzVEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsbURBQW1ELFNBQVM7QUFDNUQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxnQkFBZ0IsMEJBQTBCO0FBQzFDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0E7QUFDQSxzREFBc0QsUUFBUTtBQUM5RDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGlEQUFpRDtBQUNqRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsMkRBQTJELE1BQU07QUFDakU7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSwyREFBMkQsTUFBTTtBQUNqRTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGdCQUFnQixRQUFRO0FBQ3hCLGdCQUFnQixZQUFZO0FBQzVCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsNEJBQTRCLGtCQUFrQjtBQUM5QztBQUNBO0FBQ0E7QUFDQTtBQUNBLDRCQUE0QixrQkFBa0I7QUFDOUM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSx5Q0FBeUMsU0FBUztBQUNsRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsZ0JBQWdCLFFBQVE7QUFDeEIsZ0JBQWdCLFlBQVk7QUFDNUI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esd0JBQXdCLGtCQUFrQjtBQUMxQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSx5Q0FBeUMsU0FBUztBQUNsRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSw4QkFBOEI7QUFDOUI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxnQkFBZ0IsZ0VBQWdFO0FBQ2hGO0FBQ0Esb0JBQW9CLHVDQUF1QztBQUMzRDtBQUNBLDRCQUE0QiwwQkFBMEI7QUFDdEQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxtQ0FBbUMsRUFBRSxvQkFBb0IsTUFBTTtBQUMvRDtBQUNBO0FBQ0EsMkJBQTJCLHNCQUFzQjtBQUNqRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsZ0JBQWdCLFlBQVk7QUFDNUI7QUFDQTtBQUNBO0FBQ0E7QUFDQSxnREFBZ0QsU0FBUztBQUN6RDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsZ0JBQWdCLFlBQVk7QUFDNUI7QUFDQTtBQUNBO0FBQ0E7QUFDQSx3QkFBd0Isa0JBQWtCO0FBQzFDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsZ0JBQWdCLFFBQVE7QUFDeEIsZ0JBQWdCLFlBQVk7QUFDNUI7QUFDQTtBQUNBO0FBQ0E7QUFDQSx3QkFBd0Isa0JBQWtCO0FBQzFDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSx3QkFBd0IsaUJBQWlCO0FBQ3pDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsZ0JBQWdCLHdCQUF3QjtBQUN4QztBQUNBLDRCQUE0QixpQkFBaUI7QUFDN0M7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSx3QkFBd0IsaUJBQWlCO0FBQ3pDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esd0JBQXdCLGlCQUFpQjtBQUN6QztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSx3QkFBd0IsaUJBQWlCO0FBQ3pDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esd0JBQXdCLGlCQUFpQjtBQUN6QztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHdCQUF3QixpQkFBaUI7QUFDekM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHdCQUF3QixpQkFBaUI7QUFDekM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esd0JBQXdCLGlCQUFpQjtBQUN6QztBQUNBLDRCQUE0QixvQkFBb0I7QUFDaEQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsZ0JBQWdCLHdCQUF3QjtBQUN4QztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSx3QkFBd0IsaUJBQWlCO0FBQ3pDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHdCQUF3QixpQkFBaUI7QUFDekM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esd0JBQXdCLDBCQUEwQjtBQUNsRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsNEJBQTRCLG1CQUFtQjtBQUMvQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxpQkFBaUI7QUFDakI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLDBIQUEwSDtBQUMxSDtBQUNBO0FBQ0E7QUFDQSw2SEFBNkg7QUFDN0g7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esd0lBQXdJO0FBQ3hJO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsZ0NBQWdDLHVCQUF1QjtBQUN2RCxvSkFBb0o7QUFDcEo7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsZ0NBQWdDLHVCQUF1QjtBQUN2RCxnSUFBZ0k7QUFDaEk7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGdDQUFnQyx3QkFBd0I7QUFDeEQsbUlBQW1JO0FBQ25JO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsZ0JBQWdCLFFBQVE7QUFDeEIsMEJBQTBCO0FBQzFCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxhQUFhO0FBQ2I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGdCQUFnQixVQUFVO0FBQzFCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHlCQUF5QjtBQUN6QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxnQkFBZ0IsMkVBQTJFO0FBQzNGLGdCQUFnQixZQUFZO0FBQzVCLGdCQUFnQixZQUFZO0FBQzVCO0FBQ0EsZ0JBQWdCLFNBQVM7QUFDekI7QUFDQTtBQUNBO0FBQ0Esb0JBQW9CLFNBQVM7QUFDN0IsaURBQWlELFNBQVM7QUFDMUQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxpREFBaUQsU0FBUztBQUMxRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSw0REFBNEQsRUFBRSw4QkFBOEIsRUFBRSx5QkFBeUIsT0FBTyxJQUFJLFVBQVU7QUFDNUk7QUFDQTtBQUNBO0FBQ0E7QUFDQSw0REFBNEQsRUFBRSw4QkFBOEIsRUFBRSx5QkFBeUIsT0FBTyxJQUFJLFVBQVU7QUFDNUk7QUFDQTtBQUNBO0FBQ0EsaURBQWlELE9BQU8sSUFBSSxVQUFVO0FBQ3RFO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxxQ0FBcUMsRUFBRTtBQUN2QztBQUNBLHFDQUFxQyxFQUFFO0FBQ3ZDO0FBQ0EscUNBQXFDLEVBQUU7QUFDdkM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSw2REFBNkQsU0FBUztBQUN0RTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxnREFBZ0QsRUFBRSxJQUFJLEVBQUU7QUFDeEQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSwwQkFBMEI7QUFDMUI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsV0FBVztBQUNYO0FBQ0E7QUFDQSx3QkFBd0I7QUFDeEI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVM7QUFDVDtBQUNBO0FBQ0Esc0JBQXNCO0FBQ3RCO0FBQ0Esd0JBQXdCLHNCQUFzQjtBQUM5QztBQUNBLHlDQUF5QyxrQkFBa0I7QUFDM0Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsT0FBTztBQUNQO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsMEJBQTBCO0FBQzFCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxXQUFXO0FBQ1g7QUFDQTtBQUNBLHdCQUF3QjtBQUN4QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0E7QUFDQSxzQkFBc0I7QUFDdEI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLE9BQU87QUFDUDtBQUNBO0FBQ0E7QUFDQSw0QkFBNEI7QUFDNUI7QUFDQSw0QkFBNEI7QUFDNUIsd0RBQXdEO0FBQ3hEO0FBQ0E7QUFDQSxnREFBZ0Q7QUFDaEQscURBQXFEO0FBQ3JEO0FBQ0E7QUFDQTtBQUNBLHdCQUF3QjtBQUN4QjtBQUNBO0FBQ0EsZ0RBQWdEO0FBQ2hELHFEQUFxRDtBQUNyRCxxREFBcUQ7QUFDckQsdURBQXVEO0FBQ3ZELGdFQUFnRTtBQUNoRTtBQUNBO0FBQ0EsMkNBQTJDO0FBQzNDLDJCQUEyQixvQkFBb0I7QUFDL0MsYUFBYSxFQUFFO0FBQ2Y7QUFDQTtBQUNBO0FBQ0E7QUFDQSw2Q0FBNkMsU0FBUztBQUN0RDtBQUNBLHFDQUFxQyxFQUFFO0FBQ3ZDLGVBQWUscUJBQXFCO0FBQ3BDLGNBQWMseURBQXlEO0FBQ3ZFLGVBQWUsMkRBQTJEO0FBQzFFLGlCQUFpQjtBQUNqQixLQUFLO0FBQ0w7QUFDQTtBQUNBO0FBQ0E7QUFDQSx1REFBdUQsT0FBTztBQUM5RDtBQUNBLDhIQUE4SDtBQUM5SDtBQUNBLDZEQUE2RDtBQUM3RCwyREFBMkQ7QUFDM0QscURBQXFEO0FBQ3JEO0FBQ0E7QUFDQSwrREFBK0QsT0FBTyxJQUFJO0FBQzFFLDhDQUE4QyxpQkFBaUI7QUFDL0Q7QUFDQSxZQUFZO0FBQ1osZ0JBQWdCO0FBQ2hCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxnQkFBZ0I7QUFDaEIsZUFBZTtBQUNmO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsY0FBYztBQUNkO0FBQ0E7QUFDQSxvQ0FBb0MsdUJBQXVCO0FBQzNEO0FBQ0EsbUJBQW1CLFVBQVU7QUFDN0I7QUFDQTtBQUNBLE1BQU0saUJBQWlCO0FBQ3ZCLDBDQUEwQyxtQkFBbUIsdUJBQXVCO0FBQ3BGO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0EsRUFBRTtBQUNGO0FBQ0E7QUFDQSxNQUFNO0FBQ04sNkNBQTZDLHFDQUFxQztBQUNsRiw4Q0FBOEM7QUFDOUM7QUFDQSxJQUFJO0FBQ0o7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsSUFBSTtBQUNKLElBQUk7O0FBRUo7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLElBQUk7QUFDSixJQUFJO0FBQ0osSUFBSTtBQUNKLElBQUk7QUFDSixJQUFJLGdCQUFnQjtBQUNwQjtBQUNBO0FBQ0E7QUFDQTtBQUNBLHdCQUF3Qjs7QUFFeEI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxvRUFBb0U7QUFDcEUsNkRBQTZEO0FBQzdELDZDQUE2QztBQUM3QztBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGFBQWE7QUFDYjtBQUNBO0FBQ0E7QUFDQSxXQUFXLGFBQWE7QUFDeEI7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBLHFCQUFxQixxRUFBcUU7QUFDMUY7QUFDQSxtQkFBbUIsb0JBQW9CO0FBQ3ZDLG1CQUFtQixtQ0FBbUM7QUFDdEQsdUJBQXVCLFdBQVc7QUFDbEMsd0JBQXdCLFdBQVc7QUFDbkM7QUFDQTtBQUNBLHNCQUFzQixhQUFhO0FBQ25DLHVCQUF1QixpQkFBaUI7QUFDeEM7QUFDQSxvQkFBb0IsV0FBVztBQUMvQixvQkFBb0IsMEJBQTBCO0FBQzlDLG9CQUFvQixvQkFBb0I7QUFDeEMsb0JBQW9CLDBCQUEwQjtBQUM5Qyw4QkFBOEIsWUFBWSxlQUFlLFdBQVc7QUFDcEUsdUJBQXVCLGVBQWU7QUFDdEM7QUFDQTtBQUNBLG1CQUFtQixXQUFXO0FBQzlCLG1CQUFtQiw4QkFBOEI7QUFDakQ7QUFDQSwyQkFBMkIsU0FBUztBQUNwQyx1QkFBdUIsY0FBYyxJQUFJLG1CQUFtQjtBQUM1RDtBQUNBO0FBQ0E7QUFDQSxzQkFBc0IsOENBQThDO0FBQ3BFO0FBQ0Esa0JBQWtCLDZCQUE2QjtBQUMvQyxrQkFBa0IsMEJBQTBCO0FBQzVDLGlCQUFpQixPQUFPO0FBQ3hCO0FBQ0E7QUFDQSxvQkFBb0IsYUFBYTtBQUNqQyxxQkFBcUIsaUJBQWlCO0FBQ3RDO0FBQ0Esc0JBQXNCLHFEQUFxRDtBQUMzRTtBQUNBLGtCQUFrQiw2QkFBNkI7QUFDL0Msa0JBQWtCLDBCQUEwQjtBQUM1QyxpQkFBaUIsT0FBTztBQUN4QjtBQUNBO0FBQ0Esb0JBQW9CLGNBQWM7QUFDbEMscUJBQXFCLGtCQUFrQjtBQUN2QztBQUNBLGtCQUFrQixzQ0FBc0M7QUFDeEQsa0JBQWtCLDBCQUEwQjtBQUM1QyxrQkFBa0IsMENBQTBDO0FBQzVELGtCQUFrQiwwQkFBMEI7QUFDNUMsNEJBQTRCLFlBQVksZUFBZSxXQUFXO0FBQ2xFLHFCQUFxQixlQUFlO0FBQ3BDO0FBQ0EsbUNBQW1DLDRFQUE0RTtBQUMvRztBQUNBLGtCQUFrQiw0Q0FBNEM7QUFDOUQsa0JBQWtCLDRDQUE0QztBQUM5RCxrQkFBa0Isc0NBQXNDO0FBQ3hELGtCQUFrQiwwQkFBMEI7QUFDNUMsNEJBQTRCLFlBQVksZUFBZSxXQUFXO0FBQ2xFLHFCQUFxQixlQUFlO0FBQ3BDO0FBQ0E7QUFDQSxZQUFZLHVCQUF1QjtBQUNuQztBQUNBO0FBQ0EseUJBQXlCLHVCQUF1QjtBQUNoRDtBQUNBO0FBQ0EsMEJBQTBCLFlBQVk7QUFDdEM7QUFDQSxtQ0FBbUMseUNBQXlDO0FBQzVFO0FBQ0E7QUFDQTtBQUNBLHdDQUF3Qyx5Q0FBeUM7QUFDakY7QUFDQTtBQUNBLHdDQUF3Qyx5Q0FBeUM7QUFDakY7QUFDQTtBQUNBO0FBQ0Esc0RBQXNELHdDQUF3QztBQUM5RjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EscUJBQXFCO0FBQ3JCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLG9DQUFvQyxxREFBcUQ7QUFDekY7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EscUJBQXFCLE9BQU8sRUFBRSxPQUFPLElBQUksSUFBSSxFQUFFLEdBQUcsSUFBSSxJQUFJLEVBQUUsR0FBRyxJQUFJLEdBQUcsRUFBRSxFQUFFO0FBQzFFLHdCQUF3QixvQkFBb0I7QUFDNUMsOEJBQThCLG9CQUFvQjtBQUNsRDtBQUNBO0FBQ0E7QUFDQSx1QkFBdUIsd0JBQXdCO0FBQy9DO0FBQ0E7QUFDQSxZQUFZLDhDQUE4QztBQUMxRDtBQUNBO0FBQ0E7QUFDQSxtREFBbUQsb0JBQW9CO0FBQ3ZFO0FBQ0E7QUFDQTtBQUNBLHlCQUF5Qix1QkFBdUI7QUFDaEQ7QUFDQTtBQUNBLDBCQUEwQixZQUFZO0FBQ3RDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsYUFBYTtBQUNiO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxZQUFZLFVBQVU7QUFDdEI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esb0JBQW9CLGlDQUFpQztBQUNyRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsWUFBWSxVQUFVO0FBQ3RCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxvQkFBb0IsaUNBQWlDO0FBQ3JEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHFCQUFxQixNQUFNO0FBQzNCLHNCQUFzQixPQUFPLElBQUksUUFBUTtBQUN6QztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsWUFBWSxpQkFBaUI7QUFDN0IsWUFBWSxzQ0FBc0M7QUFDbEQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsWUFBWSxVQUFVO0FBQ3RCLFlBQVksc0NBQXNDO0FBQ2xEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0E7QUFDQTtBQUNBLFNBQVM7QUFDVDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSw0QkFBNEI7QUFDNUIsWUFBWSx3QkFBd0I7QUFDcEM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxnQkFBZ0Isc0NBQXNDO0FBQ3REO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsZ0JBQWdCLHNDQUFzQztBQUN0RDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsaUJBQWlCO0FBQ2pCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGlCQUFpQjtBQUNqQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGdCQUFnQixzQ0FBc0M7QUFDdEQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVM7QUFDVDtBQUNBO0FBQ0E7QUFDQTtBQUNBLGdCQUFnQixnQkFBZ0I7QUFDaEM7QUFDQTtBQUNBLGlIQUFpSDtBQUNqSDtBQUNBO0FBQ0Esb0JBQW9CO0FBQ3BCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsaUJBQWlCO0FBQ2pCO0FBQ0E7QUFDQSw0Q0FBNEMsT0FBTyxvQkFBb0IsTUFBTTtBQUM3RTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxhQUFhO0FBQ2I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGlCQUFpQjtBQUNqQjtBQUNBO0FBQ0E7QUFDQTs7QUFFQSxxQkFBcUI7QUFDckIsbUJBQW1CO0FBQ25CLHFCQUFxQjtBQUNyQix3QkFBd0I7QUFDeEIsaUJBQWlCO0FBQ2pCLG1CQUFtQjtBQUNuQixrQkFBa0I7QUFDbEIsYUFBYTtBQUNiLGtCQUFrQjtBQUNsQixjQUFjO0FBQ2QsY0FBYztBQUNkLGNBQWM7QUFDZCxpQkFBaUI7QUFDakIsaUJBQWlCO0FBQ2pCOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNoelNBO0FBQ0E7OztBQUVBLE1BQU1FLElBQWMsR0FBRyxNQUFNO0FBQzNCLHNCQUNFLDhEQUFDLDhEQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFERjtBQUdELENBSkQ7O0FBTUEsaUVBQWVBLElBQWY7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDVEE7QUFDQTtBQUNBO0FBVUE7QUFDQTs7QUFFQUssb0RBQUEsQ0FDRUMsbURBREYsRUFFRUMsaURBRkYsRUFHRUMsa0RBSEYsRUFJRUMsaURBSkYsRUFLRUMsMkNBTEYsRUFNRUMsNkNBTkYsRUFPRUMsNENBUEY7O0FBVUEsTUFBTVIsS0FBb0IsR0FBRyxDQUFDO0FBQUVZLEVBQUFBO0FBQUYsQ0FBRCxLQUFtQjtBQUU5QyxRQUFNO0FBQUVDLElBQUFBLGVBQUY7QUFBbUJDLElBQUFBLGlCQUFuQjtBQUFzQ0MsSUFBQUEsa0JBQXRDO0FBQTBEQyxJQUFBQTtBQUExRCxNQUF1RU4sc0VBQWUsRUFBNUY7QUFFQVgsRUFBQUEsZ0RBQVMsQ0FBQyxNQUFNO0FBQ2QsUUFBSWEsU0FBSixFQUFlO0FBQ2JDLE1BQUFBLGVBQWUsQ0FBQ0QsU0FBUyxDQUFDSyxPQUFWLEVBQUQsQ0FBZjtBQUNEO0FBRUYsR0FMUSxFQUtOLENBQUNMLFNBQUQsQ0FMTSxDQUFUO0FBUUEsc0JBQ0UsOERBQUMsa0RBQUQ7QUFBTSxhQUFTLEVBQUUsQ0FBQyxRQUFELEVBQVcsUUFBWCxFQUFxQixRQUFyQixFQUErQixLQUEvQixDQUFqQjtBQUF3RCxLQUFDLEVBQUMsTUFBMUQ7QUFBQSw0QkFDRSw4REFBQyxrREFBRDtBQUFNLE9BQUMsRUFBRSxDQUFDLE1BQUQsRUFBUyxNQUFULEVBQWlCLE1BQWpCLEVBQXlCLEtBQXpCLENBQVQ7QUFBMEMsT0FBQyxFQUFFLEVBQTdDO0FBQUEsNkJBQ0UsOERBQUMsaURBQUQ7QUFBTSxlQUFPLEVBQUVFLGlCQUFpQixDQUFDSSxPQUFqQztBQUEwQyxZQUFJLEVBQUVKLGlCQUFpQixDQUFDSztBQUFsRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFERixlQUlFLDhEQUFDLGtEQUFEO0FBQU0sT0FBQyxFQUFFLENBQUMsTUFBRCxFQUFTLE1BQVQsRUFBaUIsTUFBakIsRUFBeUIsS0FBekIsQ0FBVDtBQUEwQyxPQUFDLEVBQUUsRUFBN0M7QUFBQSxnQkFDRyxDQUFDSCxRQUFELGdCQUFZLDhEQUFDLGlEQUFEO0FBQU0sZUFBTyxFQUFFRCxrQkFBa0IsQ0FBQ0csT0FBbEM7QUFBMkMsWUFBSSxFQUFFSCxrQkFBa0IsQ0FBQ0k7QUFBcEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBWixnQkFBMkYsOERBQUMscURBQUQ7QUFBUyxZQUFJLEVBQUM7QUFBZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBRDlGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBREY7QUFXRCxDQXZCRDs7QUF5QkEsaUVBQWVuQixLQUFmOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ2xEQTtBQUNBO0FBQ0E7QUFDQTs7O0FBU0EsTUFBTUwsU0FBbUIsR0FBRyxNQUFNO0FBRWhDLFFBQU07QUFBRWlCLElBQUFBLFNBQUY7QUFBYWEsSUFBQUEsUUFBYjtBQUF1QkMsSUFBQUEsWUFBdkI7QUFBcUNDLElBQUFBLFNBQXJDO0FBQWdEQyxJQUFBQTtBQUFoRCxNQUFpRWxCLHNFQUFlLEVBQXRGOztBQUVBLFFBQU1tQixjQUFjLEdBQUlDLENBQUQsSUFBTztBQUM1QkMsSUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVlMLFNBQVo7QUFDQUYsSUFBQUEsUUFBUSxDQUFDQyxZQUFELEVBQWVPLFFBQVEsQ0FBQ04sU0FBRCxFQUFZLEVBQVosQ0FBdkIsQ0FBUjtBQUNELEdBSEQ7O0FBS0Esc0JBQ0UsOERBQUMsa0RBQUQ7QUFBTSxhQUFTLEVBQUMsUUFBaEI7QUFBeUIsU0FBSyxFQUFDLE9BQS9CO0FBQXVDLGtCQUFjLEVBQUMsUUFBdEQ7QUFBQSw0QkFDRSw4REFBQyxrREFBRDtBQUFNLGVBQVMsRUFBQyxRQUFoQjtBQUF5QixnQkFBVSxFQUFDLFFBQXBDO0FBQUEsOEJBQ0UsOERBQUMscURBQUQ7QUFBUyxTQUFDLEVBQUUsQ0FBWjtBQUFlLFlBQUksRUFBQyxJQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFERixlQUVFLDhEQUFDLGtEQUFEO0FBQU0sVUFBRSxFQUFFLEVBQVY7QUFBYyxVQUFFLEVBQUUsQ0FBbEI7QUFBcUIsWUFBSSxFQUFDLElBQTFCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUZGLGVBWUUsOERBQUMsa0RBQUQ7QUFBQSxnQ0FDRSw4REFBQyxtREFBRDtBQUNFLGVBQUssRUFBQyxPQURSO0FBRUUscUJBQVcsRUFBQyxpQkFGZDtBQUdFLGNBQUksRUFBQyxRQUhQO0FBSUUsZUFBSyxFQUFFQSxTQUpUO0FBS0Usa0JBQVEsRUFBR0csQ0FBRCxJQUFPRixZQUFZLENBQUNFLENBQUMsQ0FBQ0ksTUFBRixDQUFTQyxLQUFWO0FBTC9CO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBREYsZUFRRSw4REFBQyxvREFBRDtBQUFRLGtCQUFRLEVBQUVSLFNBQVMsS0FBSyxFQUFoQztBQUFvQyxZQUFFLEVBQUMsS0FBdkM7QUFBNkMsaUJBQU8sRUFBRUUsY0FBdEQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBUkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVpGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFERixlQXdCRSw4REFBQyxpREFBRDtBQUFBLDZCQUNFLDhEQUFDLDJDQUFEO0FBQU8saUJBQVMsRUFBRWpCO0FBQWxCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQXhCRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFERjtBQThCRCxDQXZDRDs7QUF5Q0EsaUVBQWVqQixTQUFmOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNyREE7QUFDQTtDQUVBOztBQUNBOztBQXFGTyxNQUFNZ0QsWUFBWSxnQkFBR1Asb0RBQWEsQ0FBQyxFQUFELENBQWxDO0FBRUEsTUFBTVEsYUFBYSxHQUFHLENBQUM7QUFBRUMsRUFBQUE7QUFBRixDQUFELEtBQWtCO0FBRTdDLFFBQU07QUFBQSxPQUFDN0IsUUFBRDtBQUFBLE9BQVc4QjtBQUFYLE1BQTBCUiwrQ0FBUSxDQUFDLEtBQUQsQ0FBeEM7QUFDQSxRQUFNO0FBQUEsT0FBQzFCLFNBQUQ7QUFBQSxPQUFZbUM7QUFBWixNQUE0QlQsK0NBQVEsQ0FBYyxFQUFkLENBQTFDO0FBQ0EsUUFBTTtBQUFBLE9BQUNVLFVBQUQ7QUFBQSxPQUFhQztBQUFiLE1BQThCWCwrQ0FBUSxDQUFDLEVBQUQsQ0FBNUM7QUFDQSxRQUFNO0FBQUEsT0FBQ1osWUFBRDtBQUFBLE9BQWViO0FBQWYsTUFBa0N5QiwrQ0FBUSxDQUFpQixFQUFqQixDQUFoRDtBQUVBLFFBQU07QUFBQSxPQUFDWCxTQUFEO0FBQUEsT0FBWUM7QUFBWixNQUE0QlUsK0NBQVEsQ0FBQyxFQUFELENBQTFDO0FBQ0EsUUFBTTtBQUFBLE9BQUNZLFVBQUQ7QUFBQSxPQUFhQztBQUFiLE1BQThCYiwrQ0FBUSxDQUFDLEVBQUQsQ0FBNUM7QUFFQSxRQUFNdkIsa0JBQWtCLEdBQUc7QUFDekJJLElBQUFBLElBQUksRUFBRTtBQUNKaUMsTUFBQUEsTUFBTSxFQUFFRixVQUFVLENBQUNHLEdBQVgsQ0FBZSxDQUFFQyxDQUFGLEVBQUtDLEtBQUwsS0FBZ0JBLEtBQS9CLENBREo7QUFFSkMsTUFBQUEsUUFBUSxFQUFFLENBQUM7QUFDVHJDLFFBQUFBLElBQUksRUFBRStCLFVBQVUsQ0FBQ0csR0FBWCxDQUFnQmxDLElBQUQsSUFBVUEsSUFBekIsQ0FERztBQUVUc0MsUUFBQUEsS0FBSyxFQUFFLFVBRkU7QUFHVEMsUUFBQUEsV0FBVyxFQUFFLG1CQUhKO0FBSVRDLFFBQUFBLGVBQWUsRUFBRTtBQUpSLE9BQUQ7QUFGTixLQURtQjtBQVV6QnpDLElBQUFBLE9BQU8sRUFBRTtBQUNQMEMsTUFBQUEsVUFBVSxFQUFFLElBREw7QUFFUEMsTUFBQUEsT0FBTyxFQUFFO0FBQ1BDLFFBQUFBLE1BQU0sRUFBRTtBQUNOQyxVQUFBQSxRQUFRLEVBQUU7QUFESixTQUREO0FBSVBDLFFBQUFBLEtBQUssRUFBRTtBQUNMQyxVQUFBQSxPQUFPLEVBQUUsSUFESjtBQUVMQyxVQUFBQSxJQUFJLEVBQUU7QUFGRDtBQUpBO0FBRkY7QUFWZ0IsR0FBM0I7QUF3QkEsUUFBTXBELGlCQUFpQixHQUFHO0FBQ3hCSyxJQUFBQSxJQUFJLEVBQUU7QUFDSmlDLE1BQUFBLE1BQU0sRUFBRTFCLFlBQVksQ0FBQzJCLEdBQWIsQ0FBaUIsQ0FBQztBQUFFYyxRQUFBQTtBQUFGLE9BQUQsS0FBYyxJQUFJQyxJQUFKLENBQVNELElBQVQsRUFBZUUsa0JBQWYsRUFBL0IsQ0FESjtBQUVKYixNQUFBQSxRQUFRLEVBQUUsQ0FBQztBQUNUckMsUUFBQUEsSUFBSSxFQUFFTyxZQUFZLENBQUMyQixHQUFiLENBQWtCbEMsSUFBRCxJQUFVQSxJQUFJLENBQUNtRCxTQUFoQyxDQURHO0FBRVRiLFFBQUFBLEtBQUssRUFBRSxVQUZFO0FBR1RDLFFBQUFBLFdBQVcsRUFBRSxtQkFISjtBQUlUQyxRQUFBQSxlQUFlLEVBQUU7QUFKUixPQUFELEVBS1A7QUFDRHhDLFFBQUFBLElBQUksRUFBRU8sWUFBWSxDQUFDMkIsR0FBYixDQUFrQmxDLElBQUQsSUFBVUEsSUFBSSxDQUFDb0QsTUFBaEMsQ0FETDtBQUVEZCxRQUFBQSxLQUFLLEVBQUUsUUFGTjtBQUdEQyxRQUFBQSxXQUFXLEVBQUUsbUJBSFo7QUFJREMsUUFBQUEsZUFBZSxFQUFFO0FBSmhCLE9BTE87QUFGTixLQURrQjtBQWV4QnpDLElBQUFBLE9BQU8sRUFBRTtBQUNQMEMsTUFBQUEsVUFBVSxFQUFFLElBREw7QUFFUEMsTUFBQUEsT0FBTyxFQUFFO0FBQ1BDLFFBQUFBLE1BQU0sRUFBRTtBQUNOQyxVQUFBQSxRQUFRLEVBQUU7QUFESixTQUREO0FBSVBDLFFBQUFBLEtBQUssRUFBRTtBQUNMQyxVQUFBQSxPQUFPLEVBQUUsSUFESjtBQUVMQyxVQUFBQSxJQUFJLEVBQUU7QUFGRDtBQUpBO0FBRkY7QUFmZSxHQUExQjs7QUE2QkEsUUFBTXpDLFFBQVEsR0FBRyxDQUFDQyxZQUFELEVBQStCQyxTQUEvQixLQUFxRDtBQUNwRW1CLElBQUFBLFdBQVcsQ0FBQyxJQUFELENBQVg7QUFFQSxVQUFNMEIsZUFBZSxHQUFHLElBQUlDLEtBQUosQ0FBVSxFQUFWLEVBQWNDLElBQWQsQ0FBbUIsQ0FBbkIsQ0FBeEI7O0FBRUEsUUFBSWhELFlBQUosRUFBa0I7QUFDaEIsV0FBSSxJQUFJaUQsQ0FBQyxHQUFHLENBQVosRUFBZUEsQ0FBQyxJQUFJLEVBQXBCLEVBQXdCQSxDQUFDLEVBQXpCLEVBQThCO0FBQUE7O0FBQzVCSCxRQUFBQSxlQUFlLENBQUNHLENBQUQsQ0FBZixvQkFBcUJqRCxZQUFZLENBQUNBLFlBQVksQ0FBQ2tELE1BQWIsR0FBc0IsRUFBdEIsR0FBMkJELENBQTVCLENBQWpDLGtEQUFxQixjQUE0Q0wsU0FBakU7QUFDRDtBQUNGOztBQUVELFVBQU1PLFVBQVUsR0FBR25DLGdFQUFBLENBQXFCOEIsZUFBckIsQ0FBbkI7QUFFQSxVQUFNTyxPQUFPLEdBQUcsSUFBSXRDLDREQUFKLENBQWlDO0FBQy9DeUMsTUFBQUEsU0FBUyxFQUFFLENBRG9DO0FBRS9DQyxNQUFBQSxZQUFZLEVBQUUsQ0FBQyxFQUFELENBRmlDO0FBRy9DQyxNQUFBQSxVQUFVLEVBQUU7QUFIbUMsS0FBakMsQ0FBaEI7QUFNQUwsSUFBQUEsT0FBTyxDQUFDTSxLQUFSLENBQWMsQ0FBQ1IsVUFBRCxDQUFkLEVBQTRCO0FBQzFCUyxNQUFBQSxZQUFZLEVBQUUsS0FEWTtBQUUxQkMsTUFBQUEsV0FBVyxFQUFFLElBRmE7QUFHMUJ2RCxNQUFBQSxHQUFHLEVBQUV3RCxLQUFLLElBQUk7QUFDWnpELFFBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZd0QsS0FBWjtBQUNEO0FBTHlCLEtBQTVCO0FBUUEsVUFBTUMsTUFBTSxHQUFHVixPQUFPLENBQUN0RCxRQUFSLENBQWlCLENBQUMsQ0FBRCxDQUFqQixFQUFzQkUsU0FBdEIsQ0FBZjtBQUNBd0IsSUFBQUEsYUFBYSxDQUFDVCxvRUFBQSxDQUF5QitDLE1BQXpCLENBQUQsQ0FBYjtBQUNBM0MsSUFBQUEsV0FBVyxDQUFDLEtBQUQsQ0FBWDtBQUNELEdBOUJEOztBQWdDQS9DLEVBQUFBLGdEQUFTLENBQUMsTUFBTTtBQUNkLFVBQU00RixhQUFhLEdBQUcsWUFBWTtBQUNoQyxZQUFNQyxnQkFBZ0IsR0FBRyxNQUFNckQsNkRBQWMsRUFBN0M7O0FBRUEsVUFBSXFELGdCQUFKLEVBQXNCO0FBQ3BCN0MsUUFBQUEsWUFBWSxDQUFDNkMsZ0JBQUQsQ0FBWjtBQUNEO0FBQ0YsS0FORDs7QUFRQSxVQUFNQyxjQUFjLEdBQUcsWUFBWTtBQUNqQyxZQUFNN0MsVUFBVSxHQUFHLE1BQU1SLDhEQUFlLEVBQXhDOztBQUNBLFVBQUlRLFVBQUosRUFBZ0I7QUFDZEMsUUFBQUEsYUFBYSxDQUFDRCxVQUFELENBQWI7QUFDRDtBQUNGLEtBTEQ7O0FBT0EyQyxJQUFBQSxhQUFhO0FBQ2JFLElBQUFBLGNBQWM7QUFDZixHQWxCUSxFQWtCTixFQWxCTSxDQUFUO0FBb0JBLHNCQUNFLDhEQUFDLFlBQUQsQ0FBYyxRQUFkO0FBQ0UsU0FBSyxFQUFFO0FBQ0xuRSxNQUFBQSxZQURLO0FBRUxiLE1BQUFBLGVBRks7QUFHTGtDLE1BQUFBLFlBSEs7QUFJTG5DLE1BQUFBLFNBSks7QUFLTEUsTUFBQUEsaUJBTEs7QUFNTFcsTUFBQUEsUUFOSztBQU9MRSxNQUFBQSxTQVBLO0FBUUxDLE1BQUFBLFlBUks7QUFTTHNCLE1BQUFBLFVBVEs7QUFVTG5DLE1BQUFBLGtCQVZLO0FBV0xDLE1BQUFBO0FBWEssS0FEVDtBQUFBLGNBZUc2QjtBQWZIO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFERjtBQW1CRCxDQXRJTSxFQXdJUDs7QUFDTyxNQUFNbkMsZUFBZSxHQUFHLE1BQU0yQixpREFBVSxDQUFDTSxZQUFELENBQXhDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNwT1A7QUFFTyxNQUFNb0QsR0FBRyxHQUFHRCxtREFBQSxDQUFhO0FBQzlCRyxFQUFBQSxPQUFPLEVBQUU7QUFEcUIsQ0FBYixDQUFaO0FBSVBGLEdBQUcsQ0FBQ0csUUFBSixDQUFhQyxPQUFiLENBQXFCLGlCQUFyQixJQUEwQyxvQ0FBMUM7QUFDQUosR0FBRyxDQUFDRyxRQUFKLENBQWFDLE9BQWIsQ0FBcUIsZ0JBQXJCLElBQXlDLG9EQUF6QztBQUVBSixHQUFHLENBQUNLLFlBQUosQ0FBaUJDLE9BQWpCLENBQXlCQyxHQUF6QixDQUE2QkMsTUFBTSxJQUFJO0FBQ3JDeEUsRUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVl1RSxNQUFaO0FBQ0EsU0FBT0EsTUFBUDtBQUNELENBSEQ7QUFLTyxNQUFNL0QsZUFBZSxHQUFHLFlBQVk7QUFDekMsTUFBSTtBQUNGLFVBQU07QUFBRXJCLE1BQUFBO0FBQUYsUUFBVyxNQUFNNEUsR0FBRyxDQUFDUyxHQUFKLENBQVEsUUFBUixDQUF2QjtBQUNBLFdBQU9yRixJQUFQO0FBQ0QsR0FIRCxDQUdFLE9BQU9zRixHQUFQLEVBQVk7QUFDWixXQUFPQSxHQUFQO0FBQ0Q7QUFDRixDQVBNO0FBU0EsTUFBTWxFLGNBQWMsR0FBRyxZQUFZO0FBQ3hDLE1BQUk7QUFDRixVQUFNO0FBQUVwQixNQUFBQTtBQUFGLFFBQVcsTUFBTTJFLGdEQUFBLENBQVUsZ0RBQVYsQ0FBdkI7QUFFQSxXQUFPM0UsSUFBSSxDQUFDa0MsR0FBTCxDQUFTLENBQUM7QUFBRXFELE1BQUFBLFFBQUY7QUFBWUMsTUFBQUEsU0FBWjtBQUF1QkMsTUFBQUEsS0FBdkI7QUFBOEJDLE1BQUFBLFdBQVcsRUFBRTFDO0FBQTNDLEtBQUQsTUFBd0Q7QUFBRUcsTUFBQUEsU0FBUyxFQUFFb0MsUUFBYjtBQUF1QkMsTUFBQUEsU0FBdkI7QUFBa0NwQyxNQUFBQSxNQUFNLEVBQUVxQyxLQUExQztBQUFpRHpDLE1BQUFBO0FBQWpELEtBQXhELENBQVQsQ0FBUDtBQUNELEdBSkQsQ0FJRSxPQUFPMkMsS0FBUCxFQUFjO0FBQ2QsV0FBT0EsS0FBUDtBQUNEO0FBQ0YsQ0FSTTs7Ozs7Ozs7Ozs7Ozs7QUN2QlAsSUFBSUMsS0FBSyxHQUFHLENBQVo7QUFDQSxJQUFJQyxLQUFLLEdBQUcsQ0FBWjtBQUNBLElBQUlDLElBQUksR0FBRyxDQUFYO0FBQ0EsSUFBSUMsSUFBSSxHQUFHLENBQVg7QUFFQSxJQUFJL0YsSUFBSSxHQUFHO0FBQUU2RixFQUFBQSxLQUFLLEVBQUVBLEtBQVQ7QUFBZ0JELEVBQUFBLEtBQUssRUFBRUEsS0FBdkI7QUFBOEJHLEVBQUFBLElBQUksRUFBRUEsSUFBcEM7QUFBMENELEVBQUFBLElBQUksRUFBRUE7QUFBaEQsQ0FBWDs7QUFFQSxTQUFTRSxHQUFULENBQWFDLENBQWIsRUFBZ0JDLEdBQUcsR0FBRyxDQUF0QixFQUF5QkMsR0FBRyxHQUFHLENBQS9CLEVBQWtDO0FBQ2hDTixFQUFBQSxLQUFLLEdBQUdPLElBQUksQ0FBQ0QsR0FBTCxDQUFTRSxLQUFULENBQWUsSUFBZixFQUFxQkosQ0FBckIsQ0FBUjtBQUNBTCxFQUFBQSxLQUFLLEdBQUdRLElBQUksQ0FBQ0YsR0FBTCxDQUFTRyxLQUFULENBQWUsSUFBZixFQUFxQkosQ0FBckIsQ0FBUjtBQUNBSCxFQUFBQSxJQUFJLEdBQUdJLEdBQVA7QUFDQUgsRUFBQUEsSUFBSSxHQUFHSSxHQUFQO0FBRUFuRyxFQUFBQSxJQUFJLEdBQUc7QUFBRTZGLElBQUFBLEtBQUssRUFBRUEsS0FBVDtBQUFnQkQsSUFBQUEsS0FBSyxFQUFFQSxLQUF2QjtBQUE4QkcsSUFBQUEsSUFBSSxFQUFFQSxJQUFwQztBQUEwQ0QsSUFBQUEsSUFBSSxFQUFFQTtBQUFoRCxHQUFQO0FBRUEsUUFBTVEsUUFBUSxHQUFHTCxDQUFDLENBQUMvRCxHQUFGLENBQU0sVUFBVXFFLE1BQVYsRUFBa0I7QUFDdkMsV0FBT0EsTUFBTSxHQUFHWCxLQUFoQjtBQUNELEdBRmdCLENBQWpCLENBUmdDLENBV2hDOztBQUNBLFFBQU1ZLEtBQUssR0FBR0YsUUFBUSxDQUFDcEUsR0FBVCxDQUFhLFVBQVVxRSxNQUFWLEVBQWtCO0FBQzNDLFdBQU9BLE1BQU0sSUFBSVYsS0FBSyxHQUFHRCxLQUFaLENBQWI7QUFDRCxHQUZhLENBQWQsQ0FaZ0MsQ0FlaEM7O0FBQ0EsUUFBTWEsUUFBUSxHQUFHRCxLQUFLLENBQUN0RSxHQUFOLENBQVUsVUFBVXFFLE1BQVYsRUFBa0I7QUFDM0MsV0FBT0EsTUFBTSxJQUFJSixHQUFHLEdBQUdELEdBQVYsQ0FBTixHQUF1QkEsR0FBOUI7QUFDRCxHQUZnQixDQUFqQjtBQUlBLFNBQU9PLFFBQVA7QUFDRDs7QUFFRCxTQUFTOUMsYUFBVCxDQUF1QjNELElBQXZCLEVBQTZCa0csR0FBRyxHQUFHLENBQW5DLEVBQXNDQyxHQUFHLEdBQUcsQ0FBNUMsRUFBK0M7QUFDN0MsUUFBTU8sWUFBWSxHQUFHVixHQUFHLENBQUNoRyxJQUFELEVBQU9rRyxHQUFQLEVBQVlDLEdBQVosQ0FBeEI7QUFHQSxTQUFPTyxZQUFQO0FBQ0Q7O0FBRUQsU0FBU25DLGlCQUFULENBQTJCb0MsS0FBM0IsRUFBa0NULEdBQUcsR0FBRyxDQUF4QyxFQUEyQ0MsR0FBRyxHQUFHLENBQWpELEVBQW9EO0FBQ2xELFFBQU1ILEdBQUcsR0FBR2hHLElBQVo7QUFDQVksRUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVltRixHQUFaO0FBRUEsUUFBTUMsQ0FBQyxHQUFHVSxLQUFLLENBQUN6RSxHQUFOLENBQVUsVUFBVXFFLE1BQVYsRUFBa0I7QUFDcEMsV0FBTyxDQUFDQSxNQUFNLEdBQUdMLEdBQVYsS0FBa0JDLEdBQUcsR0FBR0QsR0FBeEIsQ0FBUDtBQUNELEdBRlMsQ0FBVjtBQUdBLFFBQU1VLEVBQUUsR0FBR1gsQ0FBQyxDQUFDL0QsR0FBRixDQUFNLFVBQVVxRSxNQUFWLEVBQWtCO0FBQ2pDLFdBQU9BLE1BQU0sSUFBSVAsR0FBRyxDQUFDSCxLQUFKLEdBQVlHLEdBQUcsQ0FBQ0osS0FBcEIsQ0FBTixHQUFtQ0ksR0FBRyxDQUFDSixLQUE5QztBQUNELEdBRlUsQ0FBWDtBQUlBLFNBQU9nQixFQUFQO0FBQ0Q7O0FBRUQsaUVBQWU7QUFBRWpELEVBQUFBLGFBQUY7QUFBaUJZLEVBQUFBO0FBQWpCLENBQWY7Ozs7Ozs7Ozs7QUNuREE7Ozs7Ozs7Ozs7QUNBQTs7Ozs7Ozs7OztBQ0FBOzs7Ozs7Ozs7O0FDQUE7Ozs7Ozs7Ozs7QUNBQTs7Ozs7Ozs7OztBQ0FBOzs7Ozs7Ozs7O0FDQUE7Ozs7Ozs7Ozs7QUNBQSIsInNvdXJjZXMiOlsid2VicGFjazovL3JlYWN0c2V0dXAvLi9ub2RlX21vZHVsZXMvYnJhaW4uanMvZGlzdC9zcmMvaW5kZXgiLCJ3ZWJwYWNrOi8vcmVhY3RzZXR1cC8uL3BhZ2VzL2luZGV4LnRzeCIsIndlYnBhY2s6Ly9yZWFjdHNldHVwLy4vc3JjL2NvbXBvbmVudHMvQ2hhcnQvaW5kZXgudHN4Iiwid2VicGFjazovL3JlYWN0c2V0dXAvLi9zcmMvY29tcG9uZW50cy9EYXNoYm9hcmQvaW5kZXgudHN4Iiwid2VicGFjazovL3JlYWN0c2V0dXAvLi9zcmMvY29udGV4dC9CcmFpbkNvbnRleHQudHN4Iiwid2VicGFjazovL3JlYWN0c2V0dXAvLi9zcmMvc2VydmljZXMvYXBpLnRzIiwid2VicGFjazovL3JlYWN0c2V0dXAvLi9zcmMvdXRpbHMvc2NhbGVyLnRzIiwid2VicGFjazovL3JlYWN0c2V0dXAvZXh0ZXJuYWwgXCJAY2hha3JhLXVpL3JlYWN0XCIiLCJ3ZWJwYWNrOi8vcmVhY3RzZXR1cC9leHRlcm5hbCBcImF4aW9zXCIiLCJ3ZWJwYWNrOi8vcmVhY3RzZXR1cC9leHRlcm5hbCBcImNoYXJ0LmpzXCIiLCJ3ZWJwYWNrOi8vcmVhY3RzZXR1cC9leHRlcm5hbCBcImdwdS5qc1wiIiwid2VicGFjazovL3JlYWN0c2V0dXAvZXh0ZXJuYWwgXCJyZWFjdFwiIiwid2VicGFjazovL3JlYWN0c2V0dXAvZXh0ZXJuYWwgXCJyZWFjdC1jaGFydGpzLTJcIiIsIndlYnBhY2s6Ly9yZWFjdHNldHVwL2V4dGVybmFsIFwicmVhY3QvanN4LWRldi1ydW50aW1lXCIiLCJ3ZWJwYWNrOi8vcmVhY3RzZXR1cC9leHRlcm5hbCBcInN0cmVhbVwiIl0sInNvdXJjZXNDb250ZW50IjpbIid1c2Ugc3RyaWN0JztcblxuT2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsICdfX2VzTW9kdWxlJywgeyB2YWx1ZTogdHJ1ZSB9KTtcblxudmFyIGdwdV9qcyA9IHJlcXVpcmUoJ2dwdS5qcycpO1xudmFyIHN0cmVhbSA9IHJlcXVpcmUoJ3N0cmVhbScpO1xuXG4vKipcbiAqIFJlbHUgQWN0aXZhdGlvbiwgYWthIFJlY3RpZmllZCBMaW5lYXIgVW5pdCBBY3RpdmF0aW9uXG4gKiBAZGVzY3JpcHRpb24gaHR0cHM6Ly9lbi53aWtpcGVkaWEub3JnL3dpa2kvUmVjdGlmaWVyXyhuZXVyYWxfbmV0d29ya3MpXG4gKi9cbmZ1bmN0aW9uIGFjdGl2YXRlJDMod2VpZ2h0KSB7XG4gICAgcmV0dXJuIE1hdGgubWF4KDAsIHdlaWdodCk7XG59XG4vKipcbiAqIFJlbHUgZGVyaXZhdGl2ZVxuICovXG5mdW5jdGlvbiBtZWFzdXJlJDMod2VpZ2h0LCBkZWx0YSkge1xuICAgIGlmICh3ZWlnaHQgPD0gMCkge1xuICAgICAgICByZXR1cm4gMDtcbiAgICB9XG4gICAgcmV0dXJuIGRlbHRhO1xufVxuXG52YXIgcmVsdSQyID0gLyojX19QVVJFX18qL09iamVjdC5mcmVlemUoe1xuICAgIF9fcHJvdG9fXzogbnVsbCxcbiAgICBhY3RpdmF0ZTogYWN0aXZhdGUkMyxcbiAgICBtZWFzdXJlOiBtZWFzdXJlJDNcbn0pO1xuXG4vKipcbiAqIHNpZ21vaWQgYWN0aXZhdGlvblxuICovXG5mdW5jdGlvbiBhY3RpdmF0ZSQyKHZhbHVlKSB7XG4gICAgcmV0dXJuIDEgLyAoMSArIE1hdGguZXhwKC12YWx1ZSkpO1xufVxuLyoqXG4gKiBzaWdtb2lkIGRlcml2YXRpdmVcbiAqL1xuZnVuY3Rpb24gbWVhc3VyZSQyKHdlaWdodCwgZXJyb3IpIHtcbiAgICByZXR1cm4gd2VpZ2h0ICogKDEgLSB3ZWlnaHQpICogZXJyb3I7XG59XG5cbnZhciBzaWdtb2lkJDIgPSAvKiNfX1BVUkVfXyovT2JqZWN0LmZyZWV6ZSh7XG4gICAgX19wcm90b19fOiBudWxsLFxuICAgIGFjdGl2YXRlOiBhY3RpdmF0ZSQyLFxuICAgIG1lYXN1cmU6IG1lYXN1cmUkMlxufSk7XG5cbi8qKlxuICogSHlwZXJib2xpYyB0YW5cbiAqL1xuZnVuY3Rpb24gYWN0aXZhdGUkMSh3ZWlnaHQpIHtcbiAgICByZXR1cm4gTWF0aC50YW5oKHdlaWdodCk7XG59XG4vKipcbiAqIEBkZXNjcmlwdGlvbiBncmFkIGZvciB6ID0gdGFuaCh4KSBpcyAoMSAtIHpeMilcbiAqL1xuZnVuY3Rpb24gbWVhc3VyZSQxKHdlaWdodCwgZXJyb3IpIHtcbiAgICByZXR1cm4gKDEgLSB3ZWlnaHQgKiB3ZWlnaHQpICogZXJyb3I7XG59XG5cbnZhciB0YW5oJDIgPSAvKiNfX1BVUkVfXyovT2JqZWN0LmZyZWV6ZSh7XG4gICAgX19wcm90b19fOiBudWxsLFxuICAgIGFjdGl2YXRlOiBhY3RpdmF0ZSQxLFxuICAgIG1lYXN1cmU6IG1lYXN1cmUkMVxufSk7XG5cbi8qKlxuICogTGVha3kgUmVsdSBBY3RpdmF0aW9uLCBha2EgTGVha3kgUmVjdGlmaWVkIExpbmVhciBVbml0IEFjdGl2YXRpb25cbiAqIEBkZXNjcmlwdGlvbiBodHRwczovL2VuLndpa2lwZWRpYS5vcmcvd2lraS9SZWN0aWZpZXJfKG5ldXJhbF9uZXR3b3JrcylcbiAqL1xuZnVuY3Rpb24gYWN0aXZhdGUod2VpZ2h0KSB7XG4gICAgcmV0dXJuIHdlaWdodCA+IDAgPyB3ZWlnaHQgOiAwLjAxICogd2VpZ2h0O1xufVxuLyoqXG4gKiBMZWFreSBSZWx1IGRlcml2YXRpdmVcbiAqL1xuZnVuY3Rpb24gbWVhc3VyZSh3ZWlnaHQsIGVycm9yKSB7XG4gICAgcmV0dXJuIHdlaWdodCA+IDAgPyBlcnJvciA6IDAuMDEgKiBlcnJvcjtcbn1cblxudmFyIGxlYWt5UmVsdSQxID0gLyojX19QVVJFX18qL09iamVjdC5mcmVlemUoe1xuICAgIF9fcHJvdG9fXzogbnVsbCxcbiAgICBhY3RpdmF0ZTogYWN0aXZhdGUsXG4gICAgbWVhc3VyZTogbWVhc3VyZVxufSk7XG5cbnZhciBpbmRleCQxID0gLyojX19QVVJFX18qL09iamVjdC5mcmVlemUoe1xuICAgIF9fcHJvdG9fXzogbnVsbCxcbiAgICByZWx1OiByZWx1JDIsXG4gICAgc2lnbW9pZDogc2lnbW9pZCQyLFxuICAgIHRhbmg6IHRhbmgkMixcbiAgICBsZWFreVJlbHU6IGxlYWt5UmVsdSQxXG59KTtcblxuY2xhc3MgQ3Jvc3NWYWxpZGF0ZSB7XG4gICAgY29uc3RydWN0b3IoaW5pdENsYXNzaWZpZXIpIHtcbiAgICAgICAgdGhpcy5qc29uID0ge1xuICAgICAgICAgICAgYXZnczoge1xuICAgICAgICAgICAgICAgIGVycm9yOiAwLFxuICAgICAgICAgICAgICAgIGl0ZXJhdGlvbnM6IDAsXG4gICAgICAgICAgICAgICAgdGVzdFRpbWU6IDAsXG4gICAgICAgICAgICAgICAgdHJhaW5UaW1lOiAwLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIHN0YXRzOiB7XG4gICAgICAgICAgICAgICAgdG90YWw6IDAsXG4gICAgICAgICAgICAgICAgdGVzdFNpemU6IDAsXG4gICAgICAgICAgICAgICAgdHJhaW5TaXplOiAwLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIHNldHM6IFtdLFxuICAgICAgICB9O1xuICAgICAgICB0aGlzLmluaXRDbGFzc2lmaWVyID0gaW5pdENsYXNzaWZpZXI7XG4gICAgfVxuICAgIHRlc3RQYXJ0aXRpb24odHJhaW5PcHRzLCB0cmFpblNldCwgdGVzdFNldCkge1xuICAgICAgICBjb25zdCBjbGFzc2lmaWVyID0gdGhpcy5pbml0Q2xhc3NpZmllcigpO1xuICAgICAgICBjb25zdCBiZWdpblRyYWluID0gRGF0ZS5ub3coKTtcbiAgICAgICAgY29uc3QgdHJhaW5pbmdTdGF0cyA9IGNsYXNzaWZpZXIudHJhaW4odHJhaW5TZXQsIHRyYWluT3B0cyk7XG4gICAgICAgIGNvbnN0IGJlZ2luVGVzdCA9IERhdGUubm93KCk7XG4gICAgICAgIGNvbnN0IHRlc3RTdGF0cyA9IGNsYXNzaWZpZXIudGVzdCh0ZXN0U2V0KTtcbiAgICAgICAgY29uc3QgZW5kVGVzdCA9IERhdGUubm93KCk7XG4gICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICAuLi50ZXN0U3RhdHMsXG4gICAgICAgICAgICB0cmFpblRpbWU6IGJlZ2luVGVzdCAtIGJlZ2luVHJhaW4sXG4gICAgICAgICAgICB0ZXN0VGltZTogZW5kVGVzdCAtIGJlZ2luVGVzdCxcbiAgICAgICAgICAgIGl0ZXJhdGlvbnM6IHRyYWluaW5nU3RhdHMuaXRlcmF0aW9ucyxcbiAgICAgICAgICAgIGVycm9yOiB0cmFpbmluZ1N0YXRzLmVycm9yLFxuICAgICAgICAgICAgdG90YWw6IHRlc3RTdGF0cy50b3RhbCxcbiAgICAgICAgICAgIG5ldHdvcms6IGNsYXNzaWZpZXIudG9KU09OKCksXG4gICAgICAgIH07XG4gICAgfVxuICAgIC8qKlxuICAgICAqIFJhbmRvbWl6ZSBhcnJheSBlbGVtZW50IG9yZGVyIGluLXBsYWNlLlxuICAgICAqIFVzaW5nIER1cnN0ZW5mZWxkIHNodWZmbGUgYWxnb3JpdGhtLlxuICAgICAqIHNvdXJjZTogaHR0cDovL3N0YWNrb3ZlcmZsb3cuY29tL2EvMTI2NDY4NjQvMTMyNDAzOVxuICAgICAqL1xuICAgIHNodWZmbGVBcnJheShhcnJheSkge1xuICAgICAgICBmb3IgKGxldCBpID0gYXJyYXkubGVuZ3RoIC0gMTsgaSA+IDA7IGktLSkge1xuICAgICAgICAgICAgY29uc3QgaiA9IE1hdGguZmxvb3IoTWF0aC5yYW5kb20oKSAqIChpICsgMSkpO1xuICAgICAgICAgICAgY29uc3QgdGVtcCA9IGFycmF5W2ldO1xuICAgICAgICAgICAgYXJyYXlbaV0gPSBhcnJheVtqXTtcbiAgICAgICAgICAgIGFycmF5W2pdID0gdGVtcDtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gYXJyYXk7XG4gICAgfVxuICAgIHRyYWluKGRhdGEsIHRyYWluT3B0cyA9IHt9LCBrID0gNCkge1xuICAgICAgICBpZiAoZGF0YS5sZW5ndGggPCBrKSB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoYFRyYWluaW5nIHNldCBzaXplIGlzIHRvbyBzbWFsbCBmb3IgJHtkYXRhLmxlbmd0aH0gayBmb2xkcyBvZiAke2t9YCk7XG4gICAgICAgIH1cbiAgICAgICAgdGhpcy5zaHVmZmxlQXJyYXkoZGF0YSk7XG4gICAgICAgIGNvbnN0IHNpemUgPSBkYXRhLmxlbmd0aCAvIGs7XG4gICAgICAgIGNvbnN0IGF2Z3MgPSB7XG4gICAgICAgICAgICB0cmFpblRpbWU6IDAsXG4gICAgICAgICAgICB0ZXN0VGltZTogMCxcbiAgICAgICAgICAgIGl0ZXJhdGlvbnM6IDAsXG4gICAgICAgICAgICBlcnJvcjogMCxcbiAgICAgICAgfTtcbiAgICAgICAgY29uc3Qgc3RhdHMgPSB7XG4gICAgICAgICAgICB0b3RhbDogMCxcbiAgICAgICAgICAgIHRlc3RTaXplOiAwLFxuICAgICAgICAgICAgdHJhaW5TaXplOiAwLFxuICAgICAgICB9O1xuICAgICAgICBjb25zdCBiaW5hcnlTdGF0cyA9IHtcbiAgICAgICAgICAgIHRvdGFsOiAwLFxuICAgICAgICAgICAgdGVzdFNpemU6IDAsXG4gICAgICAgICAgICB0cmFpblNpemU6IDAsXG4gICAgICAgICAgICB0cnVlUG9zOiAwLFxuICAgICAgICAgICAgdHJ1ZU5lZzogMCxcbiAgICAgICAgICAgIGZhbHNlUG9zOiAwLFxuICAgICAgICAgICAgZmFsc2VOZWc6IDAsXG4gICAgICAgICAgICBwcmVjaXNpb246IDAsXG4gICAgICAgICAgICByZWNhbGw6IDAsXG4gICAgICAgICAgICBhY2N1cmFjeTogMCxcbiAgICAgICAgfTtcbiAgICAgICAgY29uc3QgcmVzdWx0cyA9IFtdO1xuICAgICAgICBsZXQgaXNCaW5hcnkgPSBudWxsO1xuICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IGs7IGkrKykge1xuICAgICAgICAgICAgY29uc3QgZGNsb25lID0gZGF0YS5zbGljZSgwKTtcbiAgICAgICAgICAgIGNvbnN0IHRlc3RTZXQgPSBkY2xvbmUuc3BsaWNlKGkgKiBzaXplLCBzaXplKTtcbiAgICAgICAgICAgIGNvbnN0IHRyYWluU2V0ID0gZGNsb25lO1xuICAgICAgICAgICAgY29uc3QgcmVzdWx0ID0gdGhpcy50ZXN0UGFydGl0aW9uKHRyYWluT3B0cywgdHJhaW5TZXQsIHRlc3RTZXQpO1xuICAgICAgICAgICAgaWYgKGlzQmluYXJ5ID09PSBudWxsKSB7XG4gICAgICAgICAgICAgICAgaXNCaW5hcnkgPVxuICAgICAgICAgICAgICAgICAgICByZXN1bHQuaGFzT3duUHJvcGVydHkoJ2ZhbHNlTmVnJykgJiZcbiAgICAgICAgICAgICAgICAgICAgICAgIHJlc3VsdC5oYXNPd25Qcm9wZXJ0eSgnZmFsc2VQb3MnKSAmJlxuICAgICAgICAgICAgICAgICAgICAgICAgcmVzdWx0Lmhhc093blByb3BlcnR5KCd0cnVlTmVnJykgJiZcbiAgICAgICAgICAgICAgICAgICAgICAgIHJlc3VsdC5oYXNPd25Qcm9wZXJ0eSgndHJ1ZVBvcycpO1xuICAgICAgICAgICAgICAgIGlmIChpc0JpbmFyeSkge1xuICAgICAgICAgICAgICAgICAgICBPYmplY3QuYXNzaWduKHN0YXRzLCBiaW5hcnlTdGF0cyk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgYXZncy5pdGVyYXRpb25zICs9IHJlc3VsdC5pdGVyYXRpb25zO1xuICAgICAgICAgICAgYXZncy50ZXN0VGltZSArPSByZXN1bHQudGVzdFRpbWU7XG4gICAgICAgICAgICBhdmdzLnRyYWluVGltZSArPSByZXN1bHQudHJhaW5UaW1lO1xuICAgICAgICAgICAgYXZncy5lcnJvciArPSByZXN1bHQuZXJyb3I7XG4gICAgICAgICAgICBzdGF0cy50b3RhbCArPSByZXN1bHQudG90YWw7XG4gICAgICAgICAgICBpZiAoQ3Jvc3NWYWxpZGF0ZS5pc0JpbmFyeVN0YXRzKHN0YXRzKSAmJlxuICAgICAgICAgICAgICAgIENyb3NzVmFsaWRhdGUuaXNCaW5hcnlQYXJ0aXRpb25SZXN1bHRzKHJlc3VsdCkpIHtcbiAgICAgICAgICAgICAgICBzdGF0cy5hY2N1cmFjeSArPSByZXN1bHQuYWNjdXJhY3k7XG4gICAgICAgICAgICAgICAgc3RhdHMuZmFsc2VOZWcgKz0gcmVzdWx0LmZhbHNlTmVnO1xuICAgICAgICAgICAgICAgIHN0YXRzLmZhbHNlUG9zICs9IHJlc3VsdC5mYWxzZVBvcztcbiAgICAgICAgICAgICAgICBzdGF0cy5wcmVjaXNpb24gKz0gcmVzdWx0LnByZWNpc2lvbjtcbiAgICAgICAgICAgICAgICBzdGF0cy5yZWNhbGwgKz0gcmVzdWx0LnJlY2FsbDtcbiAgICAgICAgICAgICAgICBzdGF0cy50cnVlTmVnICs9IHJlc3VsdC50cnVlTmVnO1xuICAgICAgICAgICAgICAgIHN0YXRzLnRydWVQb3MgKz0gcmVzdWx0LnRydWVQb3M7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICByZXN1bHRzLnB1c2gocmVzdWx0KTtcbiAgICAgICAgfVxuICAgICAgICBhdmdzLmVycm9yIC89IGs7XG4gICAgICAgIGF2Z3MuaXRlcmF0aW9ucyAvPSBrO1xuICAgICAgICBhdmdzLnRlc3RUaW1lIC89IGs7XG4gICAgICAgIGF2Z3MudHJhaW5UaW1lIC89IGs7XG4gICAgICAgIGlmIChDcm9zc1ZhbGlkYXRlLmlzQmluYXJ5U3RhdHMoc3RhdHMpKSB7XG4gICAgICAgICAgICBzdGF0cy5wcmVjaXNpb24gPSBzdGF0cy50cnVlUG9zIC8gKHN0YXRzLnRydWVQb3MgKyBzdGF0cy5mYWxzZVBvcyk7XG4gICAgICAgICAgICBzdGF0cy5yZWNhbGwgPSBzdGF0cy50cnVlUG9zIC8gKHN0YXRzLnRydWVQb3MgKyBzdGF0cy5mYWxzZU5lZyk7XG4gICAgICAgICAgICBzdGF0cy5hY2N1cmFjeSA9IChzdGF0cy50cnVlTmVnICsgc3RhdHMudHJ1ZVBvcykgLyBzdGF0cy50b3RhbDtcbiAgICAgICAgfVxuICAgICAgICBzdGF0cy50ZXN0U2l6ZSA9IHNpemU7XG4gICAgICAgIHN0YXRzLnRyYWluU2l6ZSA9IGRhdGEubGVuZ3RoIC0gc2l6ZTtcbiAgICAgICAgdGhpcy5qc29uID0ge1xuICAgICAgICAgICAgYXZnczogYXZncyxcbiAgICAgICAgICAgIHN0YXRzOiBzdGF0cyxcbiAgICAgICAgICAgIHNldHM6IHJlc3VsdHMsXG4gICAgICAgIH07XG4gICAgICAgIHJldHVybiB0aGlzLmpzb247XG4gICAgfVxuICAgIHRvTmV1cmFsTmV0d29yaygpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuZnJvbUpTT04odGhpcy5qc29uKTtcbiAgICB9XG4gICAgdG9KU09OKCkge1xuICAgICAgICByZXR1cm4gdGhpcy5qc29uO1xuICAgIH1cbiAgICBmcm9tSlNPTihjcm9zc1ZhbGlkYXRlSnNvbikge1xuICAgICAgICBjb25zdCB3aW5uaW5nSlNPTiA9IGNyb3NzVmFsaWRhdGVKc29uLnNldHMucmVkdWNlKChwcmV2LCBjdXIpID0+IChwcmV2LmVycm9yIDwgY3VyLmVycm9yID8gcHJldiA6IGN1cikpO1xuICAgICAgICByZXR1cm4gdGhpcy5pbml0Q2xhc3NpZmllcigpLmZyb21KU09OKHdpbm5pbmdKU09OLm5ldHdvcmspO1xuICAgIH1cbn1cbkNyb3NzVmFsaWRhdGUuaXNCaW5hcnlTdGF0cyA9IChzdGF0cykgPT4ge1xuICAgIHJldHVybiAoc3RhdHMuYWNjdXJhY3kgIT09IHVuZGVmaW5lZCk7XG59O1xuQ3Jvc3NWYWxpZGF0ZS5pc0JpbmFyeVJlc3VsdHMgPSAoc3RhdHMpID0+IHN0YXRzLnN0YXRzLmFjY3VyYWN5ICE9PSB1bmRlZmluZWQ7XG5Dcm9zc1ZhbGlkYXRlLmlzQmluYXJ5UGFydGl0aW9uUmVzdWx0cyA9IChzdGF0cykgPT4gc3RhdHMuYWNjdXJhY3kgIT09XG4gICAgdW5kZWZpbmVkO1xuXG5sZXQgZ3B1SW5zdGFuY2UgPSBudWxsO1xuLyoqXG4gKiBTZXRzIHVwIHRoZSBncHUuanMgaW5zdGFuY2VcbiAqL1xuZnVuY3Rpb24gc2V0dXAodmFsdWUpIHtcbiAgICBncHVJbnN0YW5jZSA9IHZhbHVlO1xufVxuZnVuY3Rpb24gbWFrZUtlcm5lbChmbiwgc2V0dGluZ3MpIHtcbiAgICBsZXQgX2dwdUluc3RhbmNlID0gZ3B1SW5zdGFuY2U7XG4gICAgaWYgKF9ncHVJbnN0YW5jZSA9PT0gbnVsbCkge1xuICAgICAgICBfZ3B1SW5zdGFuY2UgPSBuZXcgZ3B1X2pzLkdQVSh7IG1vZGU6ICdncHUnIH0pO1xuICAgICAgICBzZXR1cChfZ3B1SW5zdGFuY2UpO1xuICAgIH1cbiAgICByZXR1cm4gX2dwdUluc3RhbmNlXG4gICAgICAgIC5jcmVhdGVLZXJuZWwoZm4sIHNldHRpbmdzKVxuICAgICAgICAuc2V0UGlwZWxpbmUodHJ1ZSk7XG59XG5mdW5jdGlvbiBtYWtlS2VybmVsTWFwKG1hcCwgZm4sIHNldHRpbmdzKSB7XG4gICAgbGV0IF9ncHVJbnN0YW5jZSA9IGdwdUluc3RhbmNlO1xuICAgIGlmIChfZ3B1SW5zdGFuY2UgPT09IG51bGwpIHtcbiAgICAgICAgX2dwdUluc3RhbmNlID0gbmV3IGdwdV9qcy5HUFUoeyBtb2RlOiAnZ3B1JyB9KTtcbiAgICAgICAgc2V0dXAoX2dwdUluc3RhbmNlKTtcbiAgICB9XG4gICAgcmV0dXJuIF9ncHVJbnN0YW5jZVxuICAgICAgICAuY3JlYXRlS2VybmVsTWFwKG1hcCwgZm4sIHNldHRpbmdzKVxuICAgICAgICAuc2V0UGlwZWxpbmUodHJ1ZSk7XG59XG4vKipcbiAqIENvbXBpbGVzIGEgZnVuY3Rpb24gaW50byBhIGdwdS5qcyBkZXYgbW9kZSBrZXJuZWxcbiAqL1xuLy8gZXhwb3J0IGZ1bmN0aW9uIG1ha2VEZXZLZXJuZWwoXG4vLyAgIGZuOiBUaHJlYWRGdW5jdGlvbixcbi8vICAgc2V0dGluZ3M6IG1ha2VLZXJuZWxTZXR0aW5nc1xuLy8gKTogSUtlcm5lbFJ1blNob3J0Y3V0IHtcbi8vICAgaWYgKCdtYXAnIGluIHNldHRpbmdzKSB7XG4vLyAgICAgdGhyb3cgbmV3IEVycm9yKCdtYXAga2VybmVscyBhcmUgbm90IHN1cHBvcnRlZCBieSBkZXYga2VybmVscycpO1xuLy8gICB9XG4vLyAgIGNvbnN0IGdwdSA9IG5ldyBHUFUoeyBtb2RlOiAnZGV2JyB9KTtcbi8vICAgcmV0dXJuIGdwdS5jcmVhdGVLZXJuZWwoZm4sIHNldHRpbmdzKTtcbi8vIH1cbmZ1bmN0aW9uIGtlcm5lbElucHV0KHZhbHVlLCBzaXplKSB7XG4gICAgcmV0dXJuIG5ldyBncHVfanMuSW5wdXQodmFsdWUsIHNpemUpO1xufVxuLyoqXG4gKiBEZWxldGVzIGEgZ3B1LmpzIHRleHR1cmUgYW5kIGZyZWVzIFZSQU1cbiAqL1xuZnVuY3Rpb24gcmVsZWFzZShwb3NzaWJsZVRleHR1cmUpIHtcbiAgICBpZiAocG9zc2libGVUZXh0dXJlIGluc3RhbmNlb2YgZ3B1X2pzLlRleHR1cmUpIHtcbiAgICAgICAgcG9zc2libGVUZXh0dXJlLmRlbGV0ZSgpO1xuICAgIH1cbn1cbi8qKlxuICogQ2xlYW5zIGllIHNldHMgYWxsIGVsZW1lbnRzIHRvIDAgb2YgYSBUZXh0dXJlIG9yIGEganMgYXJyYXlcbiAqL1xuZnVuY3Rpb24gY2xlYXIodmFsdWUpIHtcbiAgICBpZiAodmFsdWUgaW5zdGFuY2VvZiBncHVfanMuVGV4dHVyZSkge1xuICAgICAgICB2YWx1ZS5jbGVhcigpO1xuICAgICAgICByZXR1cm47XG4gICAgfVxuICAgIC8vIGFycmF5XG4gICAgaWYgKEFycmF5LmlzQXJyYXkodmFsdWUpKSB7XG4gICAgICAgIGlmICh0eXBlb2YgdmFsdWVbMF0gPT09ICdudW1iZXInKSB7XG4gICAgICAgICAgICB2YWx1ZS5maWxsKDApO1xuICAgICAgICB9XG4gICAgICAgIGVsc2UgaWYgKHR5cGVvZiB2YWx1ZVswXVswXSA9PT0gJ251bWJlcicpIHtcbiAgICAgICAgICAgIGZvciAobGV0IHggPSAwOyB4IDwgdmFsdWUubGVuZ3RoOyB4KyspIHtcbiAgICAgICAgICAgICAgICB2YWx1ZVt4XS5maWxsKDApO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICAgIGVsc2UgaWYgKHR5cGVvZiB2YWx1ZVswXVswXVswXSA9PT0gJ251bWJlcicpIHtcbiAgICAgICAgICAgIC8vIGN1YmVcbiAgICAgICAgICAgIGZvciAobGV0IHkgPSAwOyB5IDwgdmFsdWUubGVuZ3RoOyB5KyspIHtcbiAgICAgICAgICAgICAgICBjb25zdCByb3cgPSB2YWx1ZVt5XTtcbiAgICAgICAgICAgICAgICBmb3IgKGxldCB4ID0gMDsgeCA8IHJvdy5sZW5ndGg7IHgrKykge1xuICAgICAgICAgICAgICAgICAgICByb3dbeF0uZmlsbCgwKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICB9XG4gICAgdGhyb3cgbmV3IEVycm9yKCd1bmhhbmRsZWQgdmFsdWUnKTtcbn1cbi8qKlxuICogQ2xvbmVzIGEgdmFsdWVcbiAqL1xuZnVuY3Rpb24gY2xvbmUodmFsdWUpIHtcbiAgICBpZiAodmFsdWUgaW5zdGFuY2VvZiBncHVfanMuVGV4dHVyZSkge1xuICAgICAgICByZXR1cm4gdmFsdWUuY2xvbmUoKTtcbiAgICB9XG4gICAgaWYgKHZhbHVlIGluc3RhbmNlb2YgRmxvYXQzMkFycmF5KSB7XG4gICAgICAgIHJldHVybiB2YWx1ZS5zbGljZSgwKTtcbiAgICB9XG4gICAgaWYgKEFycmF5LmlzQXJyYXkodmFsdWUpKSB7XG4gICAgICAgIGlmICh0eXBlb2YgdmFsdWVbMF0gPT09ICdudW1iZXInKSB7XG4gICAgICAgICAgICByZXR1cm4gdmFsdWUuc2xpY2UoMCk7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSBpZiAodHlwZW9mIHZhbHVlWzBdWzBdID09PSAnbnVtYmVyJykge1xuICAgICAgICAgICAgY29uc3QgbWF0cml4ID0gbmV3IEFycmF5KHZhbHVlLmxlbmd0aCk7XG4gICAgICAgICAgICBmb3IgKGxldCB4ID0gMDsgeCA8IHZhbHVlLmxlbmd0aDsgeCsrKSB7XG4gICAgICAgICAgICAgICAgbWF0cml4W3hdID0gdmFsdWVbeF0uc2xpY2UoMCk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICByZXR1cm4gbWF0cml4O1xuICAgICAgICB9XG4gICAgICAgIGVsc2UgaWYgKHR5cGVvZiB2YWx1ZVswXVswXVswXSA9PT0gJ251bWJlcicpIHtcbiAgICAgICAgICAgIGNvbnN0IGN1YmUgPSBuZXcgQXJyYXkodmFsdWUubGVuZ3RoKTtcbiAgICAgICAgICAgIGZvciAobGV0IHkgPSAwOyB5IDwgdmFsdWUubGVuZ3RoOyB5KyspIHtcbiAgICAgICAgICAgICAgICBjb25zdCByb3cgPSB2YWx1ZVt5XTtcbiAgICAgICAgICAgICAgICBjb25zdCBtYXRyaXggPSBuZXcgQXJyYXkocm93Lmxlbmd0aCk7XG4gICAgICAgICAgICAgICAgZm9yIChsZXQgeCA9IDA7IHggPCByb3cubGVuZ3RoOyB4KyspIHtcbiAgICAgICAgICAgICAgICAgICAgbWF0cml4W3hdID0gcm93W3hdLnNsaWNlKDApO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHJldHVybiBjdWJlO1xuICAgICAgICB9XG4gICAgfVxuICAgIHRocm93IG5ldyBFcnJvcigndW5oYW5kbGVkIHZhbHVlJyk7XG59XG5cbi8qKlxuICogMkQgTWVhbiBTcXVhcmVkIEVycm9yXG4gKi9cbmZ1bmN0aW9uIG1zZTJkKGVycm9ycykge1xuICAgIGxldCBzdW0gPSAwO1xuICAgIGZvciAobGV0IHkgPSAwOyB5IDwgdGhpcy5jb25zdGFudHMuaGVpZ2h0OyB5KyspIHtcbiAgICAgICAgZm9yIChsZXQgeCA9IDA7IHggPCB0aGlzLmNvbnN0YW50cy53aWR0aDsgeCsrKSB7XG4gICAgICAgICAgICBzdW0gKz0gZXJyb3JzW3ldW3hdICoqIDI7XG4gICAgICAgIH1cbiAgICB9XG4gICAgcmV0dXJuIHN1bSAvIHRoaXMuY29uc3RhbnRzLmxlbmd0aDtcbn1cbmNsYXNzIE1lYW5TcXVhcmVkRXJyb3Ige1xuICAgIGNvbnN0cnVjdG9yKHsgd2lkdGgsIGhlaWdodCB9KSB7XG4gICAgICAgIHRoaXMuY2FsY3VsYXRlID0gbWFrZUtlcm5lbChtc2UyZCwge1xuICAgICAgICAgICAgb3V0cHV0OiBbMV0sXG4gICAgICAgICAgICBjb25zdGFudHM6IHtcbiAgICAgICAgICAgICAgICB3aWR0aCxcbiAgICAgICAgICAgICAgICBoZWlnaHQsXG4gICAgICAgICAgICAgICAgbGVuZ3RoOiB3aWR0aCAqIGhlaWdodCxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBpbW11dGFibGU6IHRydWUsXG4gICAgICAgIH0pO1xuICAgICAgICB0aGlzLmFkZEFic29sdXRlID0gbWFrZUtlcm5lbChmdW5jdGlvbiAocHJldkVycm9yLCBwcmV2TGF5ZXJFcnJvcnMpIHtcbiAgICAgICAgICAgIHJldHVybiBwcmV2RXJyb3JbMF0gKyBNYXRoLmFicyhwcmV2TGF5ZXJFcnJvcnNbMF1bMF0pO1xuICAgICAgICB9LCB7XG4gICAgICAgICAgICBvdXRwdXQ6IFsxXSxcbiAgICAgICAgICAgIGltbXV0YWJsZTogdHJ1ZSxcbiAgICAgICAgfSk7XG4gICAgICAgIHRoaXMuYWRkID0gbWFrZUtlcm5lbChmdW5jdGlvbiAodmFsdWUxLCB2YWx1ZTIpIHtcbiAgICAgICAgICAgIHJldHVybiB2YWx1ZTFbMF0gKyB2YWx1ZTJbMF07XG4gICAgICAgIH0sIHtcbiAgICAgICAgICAgIG91dHB1dDogWzFdLFxuICAgICAgICAgICAgaW1tdXRhYmxlOiB0cnVlLFxuICAgICAgICB9KTtcbiAgICAgICAgdGhpcy5kaXZpZGUgPSBtYWtlS2VybmVsKGZ1bmN0aW9uIChsZW5ndGgsIG1zZVN1bSkge1xuICAgICAgICAgICAgY29uc3QgdmFsdWUgPSBtc2VTdW1bMF07XG4gICAgICAgICAgICBpZiAodmFsdWUgPiAwKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIHZhbHVlIC8gbGVuZ3RoO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgcmV0dXJuIDA7XG4gICAgICAgIH0sIHtcbiAgICAgICAgICAgIG91dHB1dDogWzFdLFxuICAgICAgICAgICAgaW1tdXRhYmxlOiB0cnVlLFxuICAgICAgICB9KTtcbiAgICB9XG59XG5cbmNvbnN0IGJhc2VMYXllckRlZmF1bHRTZXR0aW5ncyA9IHtcbiAgICB3aWR0aDogMSxcbiAgICBoZWlnaHQ6IDEsXG4gICAgZGVwdGg6IG51bGwsXG4gICAgd2VpZ2h0czogbnVsbCxcbiAgICBkZWx0YXM6IG51bGwsXG4gICAgcHJheGlzOiBudWxsLFxuICAgIHByYXhpc09wdHM6IG51bGwsXG59O1xuY2xhc3MgQmFzZUxheWVyIHtcbiAgICBjb25zdHJ1Y3RvcihzZXR0aW5ncykge1xuICAgICAgICB0aGlzLnByYXhpcyA9IG51bGw7XG4gICAgICAgIHRoaXMucHJlZGljdEtlcm5lbCA9IG51bGw7XG4gICAgICAgIHRoaXMuY29tcGFyZUtlcm5lbCA9IG51bGw7XG4gICAgICAgIGlmIChzZXR0aW5ncykge1xuICAgICAgICAgICAgdGhpcy5zZXR0aW5ncyA9IHsgLi4uYmFzZUxheWVyRGVmYXVsdFNldHRpbmdzLCAuLi5zZXR0aW5ncyB9O1xuICAgICAgICB9XG4gICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgdGhpcy5zZXR0aW5ncyA9IHsgLi4uYmFzZUxheWVyRGVmYXVsdFNldHRpbmdzIH07XG4gICAgICAgIH1cbiAgICAgICAgdGhpcy5zZXR1cFByYXhpcygpO1xuICAgIH1cbiAgICBnZXQgd2lkdGgoKSB7XG4gICAgICAgIHZhciBfYTtcbiAgICAgICAgcmV0dXJuIChfYSA9IHRoaXMuc2V0dGluZ3Mud2lkdGgpICE9PSBudWxsICYmIF9hICE9PSB2b2lkIDAgPyBfYSA6IDA7XG4gICAgfVxuICAgIGdldCBoZWlnaHQoKSB7XG4gICAgICAgIHZhciBfYTtcbiAgICAgICAgcmV0dXJuIChfYSA9IHRoaXMuc2V0dGluZ3MuaGVpZ2h0KSAhPT0gbnVsbCAmJiBfYSAhPT0gdm9pZCAwID8gX2EgOiAwO1xuICAgIH1cbiAgICBnZXQgZGVwdGgoKSB7XG4gICAgICAgIHZhciBfYTtcbiAgICAgICAgcmV0dXJuIChfYSA9IHRoaXMuc2V0dGluZ3MuZGVwdGgpICE9PSBudWxsICYmIF9hICE9PSB2b2lkIDAgPyBfYSA6IDA7XG4gICAgfVxuICAgIGdldCB3ZWlnaHRzKCkge1xuICAgICAgICByZXR1cm4gdGhpcy5zZXR0aW5ncy53ZWlnaHRzO1xuICAgIH1cbiAgICBzZXQgd2VpZ2h0cyh3ZWlnaHRzKSB7XG4gICAgICAgIHRoaXMuc2V0dGluZ3Mud2VpZ2h0cyA9IHdlaWdodHM7XG4gICAgfVxuICAgIGdldCBkZWx0YXMoKSB7XG4gICAgICAgIHJldHVybiB0aGlzLnNldHRpbmdzLmRlbHRhcztcbiAgICB9XG4gICAgc2V0IGRlbHRhcyhkZWx0YXMpIHtcbiAgICAgICAgdGhpcy5zZXR0aW5ncy5kZWx0YXMgPSBkZWx0YXM7XG4gICAgfVxuICAgIGdldCBpZCgpIHtcbiAgICAgICAgdmFyIF9hO1xuICAgICAgICByZXR1cm4gKF9hID0gdGhpcy5zZXR0aW5ncy5pZCkgIT09IG51bGwgJiYgX2EgIT09IHZvaWQgMCA/IF9hIDogJyc7XG4gICAgfVxuICAgIHNldCBpZCh0aXRsZSkge1xuICAgICAgICB0aGlzLnNldHRpbmdzLmlkID0gdGl0bGU7XG4gICAgfVxuICAgIHNldHVwUHJheGlzKCkge1xuICAgICAgICBjb25zdCB7IGluaXRQcmF4aXMsIHByYXhpcywgcHJheGlzT3B0cyB9ID0gdGhpcy5zZXR0aW5ncztcbiAgICAgICAgaWYgKCF0aGlzLnByYXhpcykge1xuICAgICAgICAgICAgaWYgKGluaXRQcmF4aXMpIHtcbiAgICAgICAgICAgICAgICBpZiAocHJheGlzT3B0cykge1xuICAgICAgICAgICAgICAgICAgICB0aGlzLnByYXhpcyA9IGluaXRQcmF4aXModGhpcywgcHJheGlzT3B0cyk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICB0aGlzLnByYXhpcyA9IGluaXRQcmF4aXModGhpcyk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZWxzZSBpZiAocHJheGlzKSB7XG4gICAgICAgICAgICAgICAgdGhpcy5wcmF4aXMgPSBwcmF4aXM7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9XG4gICAgLypcbiAgICBnZXQgd2VpZ2h0cygpIHtcbiAgICAgIHJldHVybiB0aGlzLl93ZWlnaHRzO1xuICAgIH1cbiAgXG4gICAgc2V0IHdlaWdodHModmFsdWUpIHtcbiAgICAgIGlmICh2YWx1ZSkge1xuICAgICAgICBpZiAodmFsdWUuZGltZW5zaW9ucykge1xuICAgICAgICAgIGlmICh2YWx1ZS5kaW1lbnNpb25zWzBdICE9PSB0aGlzLndpZHRoKSB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoYCR7dGhpcy5jb25zdHJ1Y3Rvci5uYW1lfS53ZWlnaHRzIGJlaW5nIHNldCB3aXRoIGltcHJvcGVyIHZhbHVlIHdpZHRoYCk7XG4gICAgICAgICAgfVxuICAgICAgICAgIGlmICh2YWx1ZS5kaW1lbnNpb25zWzFdICE9PSB0aGlzLmhlaWdodCkge1xuICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKGAke3RoaXMuY29uc3RydWN0b3IubmFtZX0ud2VpZ2h0cyBiZWluZyBzZXQgd2l0aCBpbXByb3BlciB2YWx1ZSBoZWlnaHRgKTtcbiAgICAgICAgICB9XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgaWYgKHZhbHVlWzBdLmxlbmd0aCAhPT0gdGhpcy53aWR0aCkge1xuICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKGAke3RoaXMuY29uc3RydWN0b3IubmFtZX0ud2VpZ2h0cyBiZWluZyBzZXQgd2l0aCBpbXByb3BlciB2YWx1ZSB3aWR0aGApO1xuICAgICAgICAgIH1cbiAgICAgICAgICBpZiAodmFsdWUubGVuZ3RoICE9PSB0aGlzLmhlaWdodCkge1xuICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKGAke3RoaXMuY29uc3RydWN0b3IubmFtZX0ud2VpZ2h0cyBiZWluZyBzZXQgd2l0aCBpbXByb3BlciB2YWx1ZSBoZWlnaHRgKTtcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIHRoaXMuX3dlaWdodHMgPSB2YWx1ZTtcbiAgICB9XG4gIFxuICAgIGdldCBkZWx0YXMoKSB7XG4gICAgICByZXR1cm4gdGhpcy5fZGVsdGFzO1xuICAgIH1cbiAgXG4gICAgc2V0IGRlbHRhcyh2YWx1ZSkge1xuICAgICAgaWYgKHZhbHVlKSB7XG4gICAgICAgIGlmICh2YWx1ZS5kaW1lbnNpb25zKSB7XG4gICAgICAgICAgaWYgKHZhbHVlLmRpbWVuc2lvbnNbMF0gIT09IHRoaXMud2lkdGgpIHtcbiAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcihgJHt0aGlzLmNvbnN0cnVjdG9yLm5hbWV9LmRlbHRhcyBiZWluZyBzZXQgd2l0aCBpbXByb3BlciB2YWx1ZSB3aWR0aGApO1xuICAgICAgICAgIH1cbiAgICAgICAgICBpZiAodmFsdWUuZGltZW5zaW9uc1sxXSAhPT0gdGhpcy5oZWlnaHQpIHtcbiAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcihgJHt0aGlzLmNvbnN0cnVjdG9yLm5hbWV9LmRlbHRhcyBiZWluZyBzZXQgd2l0aCBpbXByb3BlciB2YWx1ZSBoZWlnaHRgKTtcbiAgICAgICAgICB9XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgaWYgKHZhbHVlWzBdLmxlbmd0aCAhPT0gdGhpcy53aWR0aCkge1xuICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKGAke3RoaXMuY29uc3RydWN0b3IubmFtZX0uZGVsdGFzIGJlaW5nIHNldCB3aXRoIGltcHJvcGVyIHZhbHVlIHdpZHRoYCk7XG4gICAgICAgICAgfVxuICAgICAgICAgIGlmICh2YWx1ZS5sZW5ndGggIT09IHRoaXMuaGVpZ2h0KSB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoYCR7dGhpcy5jb25zdHJ1Y3Rvci5uYW1lfS5kZWx0YXMgYmVpbmcgc2V0IHdpdGggaW1wcm9wZXIgdmFsdWUgaGVpZ2h0YCk7XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICB9XG4gICAgICB0aGlzLl9kZWx0YXMgPSB2YWx1ZTtcbiAgICB9ICovXG4gICAgdmFsaWRhdGUoKSB7XG4gICAgICAgIGlmIChOdW1iZXIuaXNOYU4odGhpcy5oZWlnaHQpKSB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoYCR7dGhpcy5jb25zdHJ1Y3Rvci5uYW1lfSBsYXllciBoZWlnaHQgaXMgbm90IGEgbnVtYmVyYCk7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKE51bWJlci5pc05hTih0aGlzLndpZHRoKSkge1xuICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKGAke3RoaXMuY29uc3RydWN0b3IubmFtZX0gbGF5ZXIgd2lkdGggaXMgbm90IGEgbnVtYmVyYCk7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKHRoaXMuaGVpZ2h0IDwgMSkge1xuICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKGAke3RoaXMuY29uc3RydWN0b3IubmFtZX0gbGF5ZXIgaGVpZ2h0IGlzIGxlc3MgdGhhbiAxYCk7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKHRoaXMud2lkdGggPCAxKSB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoYCR7dGhpcy5jb25zdHJ1Y3Rvci5uYW1lfSBsYXllciB3aWR0aCBpcyBsZXNzIHRoYW4gMWApO1xuICAgICAgICB9XG4gICAgfVxuICAgIHNldHVwS2VybmVscyhpc1RyYWluaW5nKSB7IH1cbiAgICByZXVzZUtlcm5lbHMobGF5ZXIpIHtcbiAgICAgICAgaWYgKGxheWVyLndpZHRoICE9PSB0aGlzLndpZHRoKSB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoYCR7dGhpcy5jb25zdHJ1Y3Rvci5uYW1lfSBrZXJuZWwgd2lkdGggbWlzbWF0Y2ggJHtsYXllci53aWR0aH0gaXMgbm90ICR7dGhpcy53aWR0aH1gKTtcbiAgICAgICAgfVxuICAgICAgICBpZiAobGF5ZXIuaGVpZ2h0ICE9PSB0aGlzLmhlaWdodCkge1xuICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKGAke3RoaXMuY29uc3RydWN0b3IubmFtZX0ga2VybmVsIHdpZHRoIG1pc21hdGNoICR7bGF5ZXIuaGVpZ2h0fSBpcyBub3QgJHt0aGlzLmhlaWdodH1gKTtcbiAgICAgICAgfVxuICAgICAgICBpZiAobGF5ZXIuaGFzT3duUHJvcGVydHkoJ3ByZWRpY3RLZXJuZWwnKSAmJiBsYXllci5wcmVkaWN0S2VybmVsICE9PSBudWxsKSB7XG4gICAgICAgICAgICBpZiAoIWxheWVyLnByZWRpY3RLZXJuZWwuaW1tdXRhYmxlKSB7XG4gICAgICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKGAke2xheWVyLmNvbnN0cnVjdG9yLm5hbWV9LnByZWRpY3RLZXJuZWwgaXMgbm90IHJldXNhYmxlLCBzZXQga2VybmVsLmltbXV0YWJsZSA9IHRydWVgKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHRoaXMucHJlZGljdEtlcm5lbCA9IGxheWVyLnByZWRpY3RLZXJuZWw7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKGxheWVyLmhhc093blByb3BlcnR5KCdjb21wYXJlS2VybmVsJykgJiYgbGF5ZXIuY29tcGFyZUtlcm5lbCAhPT0gbnVsbCkge1xuICAgICAgICAgICAgaWYgKCFsYXllci5jb21wYXJlS2VybmVsLmltbXV0YWJsZSkge1xuICAgICAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcihgJHtsYXllci5jb25zdHJ1Y3Rvci5uYW1lfS5jb21wYXJlS2VybmVsIGlzIG5vdCByZXVzYWJsZSwgc2V0IGtlcm5lbC5pbW11dGFibGUgPSB0cnVlYCk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICB0aGlzLmNvbXBhcmVLZXJuZWwgPSBsYXllci5jb21wYXJlS2VybmVsO1xuICAgICAgICB9XG4gICAgICAgIHRoaXMucHJheGlzID0gbGF5ZXIucHJheGlzO1xuICAgIH1cbiAgICBwcmVkaWN0KGlucHV0cykgeyB9XG4gICAgY29tcGFyZSh0YXJnZXRWYWx1ZXMpIHsgfVxuICAgIGxlYXJuKGxlYXJuaW5nUmF0ZSkge1xuICAgICAgICAvLyBUT0RPOiBkbyB3ZSBuZWVkIHRvIHJlbGVhc2UgaGVyZT9cbiAgICAgICAgY29uc3QgeyB3ZWlnaHRzOiBvbGRXZWlnaHRzIH0gPSB0aGlzO1xuICAgICAgICBpZiAoIXRoaXMucHJheGlzKVxuICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKCd0aGlzLnByYXhpcyBub3QgZGVmaW5lZCcpO1xuICAgICAgICB0aGlzLndlaWdodHMgPSB0aGlzLnByYXhpcy5ydW4odGhpcywgbGVhcm5pbmdSYXRlKTtcbiAgICAgICAgcmVsZWFzZShvbGRXZWlnaHRzKTtcbiAgICAgICAgY2xlYXIodGhpcy5kZWx0YXMpO1xuICAgIH1cbiAgICB0b0FycmF5KCkge1xuICAgICAgICByZXR1cm4gQXJyYXkuaXNBcnJheSh0aGlzLndlaWdodHMpXG4gICAgICAgICAgICA/IHRoaXMud2VpZ2h0c1xuICAgICAgICAgICAgOiB0aGlzLndlaWdodHMudG9BcnJheSgpO1xuICAgIH1cbiAgICB0b0pTT04oKSB7XG4gICAgICAgIHJldHVybiBCYXNlTGF5ZXIudG9KU09OKHRoaXMpO1xuICAgIH1cbiAgICBzdGF0aWMgdG9KU09OKGxheWVyKSB7XG4gICAgICAgIGNvbnN0IHsgd2VpZ2h0cyB9ID0gbGF5ZXI7XG4gICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICB3aWR0aDogbGF5ZXIud2lkdGgsXG4gICAgICAgICAgICBoZWlnaHQ6IGxheWVyLmhlaWdodCxcbiAgICAgICAgICAgIGRlcHRoOiBsYXllci5kZXB0aCxcbiAgICAgICAgICAgIHdlaWdodHM6IHRvVW50eXBlZEFycmF5KCh3ZWlnaHRzICYmIHdlaWdodHMgaW5zdGFuY2VvZiBncHVfanMuVGV4dHVyZVxuICAgICAgICAgICAgICAgID8gd2VpZ2h0cy50b0FycmF5KClcbiAgICAgICAgICAgICAgICA6IHdlaWdodHMpKSxcbiAgICAgICAgICAgIHR5cGU6IGxheWVyLmNvbnN0cnVjdG9yLm5hbWUsXG4gICAgICAgICAgICBwcmF4aXNPcHRzOiBsYXllci5wcmF4aXMgPyBsYXllci5wcmF4aXMudG9KU09OKCkgOiBudWxsLFxuICAgICAgICB9O1xuICAgIH1cbn1cbmZ1bmN0aW9uIHRvVW50eXBlZEFycmF5KHdlaWdodHMpIHtcbiAgICBpZiAod2VpZ2h0cyA9PT0gbnVsbClcbiAgICAgICAgcmV0dXJuIG51bGw7XG4gICAgaWYgKEFycmF5LmlzQXJyYXkod2VpZ2h0cykpIHtcbiAgICAgICAgaWYgKHR5cGVvZiB3ZWlnaHRzWzBdID09PSAnbnVtYmVyJykge1xuICAgICAgICAgICAgcmV0dXJuIHdlaWdodHM7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSBpZiAoQXJyYXkuaXNBcnJheSh3ZWlnaHRzWzBdKSAmJiB0eXBlb2Ygd2VpZ2h0c1swXVswXSA9PT0gJ251bWJlcicpIHtcbiAgICAgICAgICAgIHJldHVybiB3ZWlnaHRzO1xuICAgICAgICB9XG4gICAgICAgIGVsc2UgaWYgKEFycmF5LmlzQXJyYXkod2VpZ2h0c1swXVswXSkgJiZcbiAgICAgICAgICAgIHR5cGVvZiB3ZWlnaHRzWzBdWzBdWzBdID09PSAnbnVtYmVyJykge1xuICAgICAgICAgICAgcmV0dXJuIHdlaWdodHM7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSBpZiAod2VpZ2h0c1swXSBpbnN0YW5jZW9mIEZsb2F0MzJBcnJheSkge1xuICAgICAgICAgICAgY29uc3QgbWF0cml4ID0gd2VpZ2h0cztcbiAgICAgICAgICAgIHJldHVybiBtYXRyaXgubWFwKChyb3cpID0+IHtcbiAgICAgICAgICAgICAgICByZXR1cm4gQXJyYXkuZnJvbShyb3cpO1xuICAgICAgICAgICAgfSk7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSBpZiAod2VpZ2h0c1swXVswXSBpbnN0YW5jZW9mIEZsb2F0MzJBcnJheSkge1xuICAgICAgICAgICAgY29uc3QgY3ViZSA9IHdlaWdodHM7XG4gICAgICAgICAgICByZXR1cm4gY3ViZS5tYXAoKG1hdHJpeCkgPT4ge1xuICAgICAgICAgICAgICAgIHJldHVybiBtYXRyaXgubWFwKChyb3cpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIEFycmF5LmZyb20ocm93KTtcbiAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIH0pO1xuICAgICAgICB9XG4gICAgfVxuICAgIGVsc2UgaWYgKHdlaWdodHMpIHtcbiAgICAgICAgcmV0dXJuIEFycmF5LmZyb20od2VpZ2h0cyk7XG4gICAgfVxuICAgIHRocm93IG5ldyBFcnJvcigndW5leHBlY3RlZCB2YWx1ZScpO1xufVxuXG4vKipcbiAqIFJldHVybnMgYW4gYXJyYXkgb2YgemVyb3NcbiAqL1xuZnVuY3Rpb24gemVyb3MkMShzaXplKSB7XG4gICAgcmV0dXJuIG5ldyBGbG9hdDMyQXJyYXkoc2l6ZSk7XG59XG5cbi8qKlxuICogUmV0dXJucyBhIDJEIHRlbnNvcihtYXRyaXgpIG9mIHplcm9zXG4gKi9cbmZ1bmN0aW9uIHplcm9zMkQod2lkdGgsIGhlaWdodCkge1xuICAgIGNvbnN0IHJlc3VsdCA9IG5ldyBBcnJheShoZWlnaHQpO1xuICAgIGZvciAobGV0IHkgPSAwOyB5IDwgaGVpZ2h0OyB5KyspIHtcbiAgICAgICAgcmVzdWx0W3ldID0gemVyb3MkMSh3aWR0aCk7XG4gICAgfVxuICAgIHJldHVybiByZXN1bHQ7XG59XG5cbi8qKlxuICogUmV0dXJucyBhIDNEIHRlbnNvciBvZiBhcnJheXNcbiAqL1xuZnVuY3Rpb24gemVyb3MzRCh3aWR0aCwgaGVpZ2h0LCBkZXB0aCkge1xuICAgIGNvbnN0IHJlc3VsdCA9IG5ldyBBcnJheShkZXB0aCk7XG4gICAgZm9yIChsZXQgeiA9IDA7IHogPCBkZXB0aDsgeisrKSB7XG4gICAgICAgIHJlc3VsdFt6XSA9IHplcm9zMkQod2lkdGgsIGhlaWdodCk7XG4gICAgfVxuICAgIHJldHVybiByZXN1bHQ7XG59XG5cbmNsYXNzIEFjdGl2YXRpb24gZXh0ZW5kcyBCYXNlTGF5ZXIge1xuICAgIGNvbnN0cnVjdG9yKGlucHV0TGF5ZXIsIHNldHRpbmdzKSB7XG4gICAgICAgIHN1cGVyKHNldHRpbmdzKTtcbiAgICAgICAgdGhpcy5pbnB1dExheWVyID0gaW5wdXRMYXllcjtcbiAgICAgICAgY29uc3QgeyB3aWR0aCwgaGVpZ2h0LCBkZXB0aCB9ID0gdGhpcztcbiAgICAgICAgdGhpcy5wcmVkaWN0S2VybmVsID0gbnVsbDtcbiAgICAgICAgdGhpcy5jb21wYXJlS2VybmVsID0gbnVsbDtcbiAgICAgICAgdGhpcy52YWxpZGF0ZSgpO1xuICAgICAgICBpZiAoZGVwdGggPiAwKSB7XG4gICAgICAgICAgICB0aGlzLndlaWdodHMgPSB6ZXJvczNEKHdpZHRoLCBoZWlnaHQsIGRlcHRoKTtcbiAgICAgICAgICAgIHRoaXMuZGVsdGFzID0gemVyb3MzRCh3aWR0aCwgaGVpZ2h0LCBkZXB0aCk7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSBpZiAoaGVpZ2h0ID4gMCkge1xuICAgICAgICAgICAgdGhpcy53ZWlnaHRzID0gemVyb3MyRCh3aWR0aCwgaGVpZ2h0KTtcbiAgICAgICAgICAgIHRoaXMuZGVsdGFzID0gemVyb3MyRCh3aWR0aCwgaGVpZ2h0KTtcbiAgICAgICAgfVxuICAgICAgICB0aGlzLnNldHVwUHJheGlzKCk7XG4gICAgfVxuICAgIGdldCB3aWR0aCgpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuaW5wdXRMYXllci53aWR0aDtcbiAgICB9XG4gICAgZ2V0IGhlaWdodCgpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuaW5wdXRMYXllci5oZWlnaHQ7XG4gICAgfVxuICAgIGdldCBkZXB0aCgpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuaW5wdXRMYXllci5kZXB0aDtcbiAgICB9XG59XG5cbmNsYXNzIEZpbHRlciBleHRlbmRzIEJhc2VMYXllciB7XG4gICAgY29uc3RydWN0b3Ioc2V0dGluZ3MsIGlucHV0TGF5ZXIpIHtcbiAgICAgICAgc3VwZXIoKTtcbiAgICAgICAgdGhpcy5zZXR0aW5ncyA9IHNldHRpbmdzO1xuICAgICAgICB0aGlzLmlucHV0TGF5ZXIgPSBpbnB1dExheWVyO1xuICAgIH1cbiAgICBnZXQgd2lkdGgoKSB7XG4gICAgICAgIHJldHVybiB0aGlzLmlucHV0TGF5ZXIud2lkdGg7XG4gICAgfVxuICAgIGdldCBoZWlnaHQoKSB7XG4gICAgICAgIHJldHVybiB0aGlzLmlucHV0TGF5ZXIuaGVpZ2h0O1xuICAgIH1cbiAgICBnZXQgZGVwdGgoKSB7XG4gICAgICAgIHJldHVybiB0aGlzLmlucHV0TGF5ZXIuZGVwdGg7XG4gICAgfVxuICAgIGdldCBmaWx0ZXJDb3VudCgpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuc2V0dGluZ3MuZmlsdGVyQ291bnQ7XG4gICAgfVxuICAgIGdldCBmaWx0ZXJXaWR0aCgpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuc2V0dGluZ3MuZmlsdGVyV2lkdGg7XG4gICAgfVxuICAgIGdldCBmaWx0ZXJIZWlnaHQoKSB7XG4gICAgICAgIHJldHVybiB0aGlzLnNldHRpbmdzLmZpbHRlckhlaWdodDtcbiAgICB9XG4gICAgZ2V0IGZpbHRlcnMoKSB7XG4gICAgICAgIHJldHVybiB0aGlzLnNldHRpbmdzLmZpbHRlcnM7XG4gICAgfVxuICAgIHNldCBmaWx0ZXJzKGZpbHRlcnMpIHtcbiAgICAgICAgdGhpcy5zZXR0aW5ncy5maWx0ZXJzID0gZmlsdGVycztcbiAgICB9XG4gICAgZ2V0IGZpbHRlckRlbHRhcygpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuc2V0dGluZ3MuZmlsdGVyRGVsdGFzO1xuICAgIH1cbiAgICBzZXQgZmlsdGVyRGVsdGFzKGZpbHRlckRlbHRhcykge1xuICAgICAgICB0aGlzLnNldHRpbmdzLmZpbHRlckRlbHRhcyA9IGZpbHRlckRlbHRhcztcbiAgICB9XG59XG5cbmNsYXNzIEludGVybmFsIHtcbiAgICBjb25zdHJ1Y3RvcigpIHtcbiAgICAgICAgdGhpcy5wcmVkaWN0S2VybmVsID0gbnVsbDtcbiAgICAgICAgdGhpcy5jb21wYXJlS2VybmVsID0gbnVsbDtcbiAgICAgICAgdGhpcy5wcmF4aXMgPSBudWxsO1xuICAgIH1cbiAgICBnZXQgd2lkdGgoKSB7XG4gICAgICAgIHJldHVybiB0aGlzLnNldHRpbmdzLndpZHRoO1xuICAgIH1cbiAgICBnZXQgaGVpZ2h0KCkge1xuICAgICAgICByZXR1cm4gdGhpcy5zZXR0aW5ncy5oZWlnaHQ7XG4gICAgfVxuICAgIGdldCBkZXB0aCgpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuc2V0dGluZ3MuZGVwdGg7XG4gICAgfVxuICAgIGdldCB3ZWlnaHRzKCkge1xuICAgICAgICByZXR1cm4gdGhpcy5zZXR0aW5ncy53ZWlnaHRzO1xuICAgIH1cbiAgICBzZXQgd2VpZ2h0cyh3ZWlnaHRzKSB7XG4gICAgICAgIHRoaXMuc2V0dGluZ3Mud2VpZ2h0cyA9IHdlaWdodHM7XG4gICAgfVxuICAgIGdldCBkZWx0YXMoKSB7XG4gICAgICAgIHJldHVybiB0aGlzLnNldHRpbmdzLmRlbHRhcztcbiAgICB9XG4gICAgc2V0IGRlbHRhcyhkZWx0YXMpIHtcbiAgICAgICAgdGhpcy5zZXR0aW5ncy5kZWx0YXMgPSBkZWx0YXM7XG4gICAgfVxuICAgIHRvSlNPTigpIHtcbiAgICAgICAgcmV0dXJuIEJhc2VMYXllci50b0pTT04odGhpcyk7XG4gICAgfVxufVxuXG5jbGFzcyBNb2RpZmllciBleHRlbmRzIEJhc2VMYXllciB7XG4gICAgY29uc3RydWN0b3IoaW5wdXRMYXllciwgc2V0dGluZ3MpIHtcbiAgICAgICAgc3VwZXIoe1xuICAgICAgICAgICAgLi4uc2V0dGluZ3MsXG4gICAgICAgICAgICB3aWR0aDogaW5wdXRMYXllci53aWR0aCxcbiAgICAgICAgICAgIGhlaWdodDogaW5wdXRMYXllci5oZWlnaHQsXG4gICAgICAgICAgICBkZXB0aDogaW5wdXRMYXllci5kZXB0aCxcbiAgICAgICAgfSk7XG4gICAgICAgIHRoaXMuaW5wdXRMYXllciA9IGlucHV0TGF5ZXI7XG4gICAgfVxuICAgIHZhbGlkYXRlKCkge1xuICAgICAgICB2YXIgX2E7XG4gICAgICAgIHN1cGVyLnZhbGlkYXRlKCk7XG4gICAgICAgIGlmICh0aGlzLndpZHRoICE9PSB0aGlzLmlucHV0TGF5ZXIud2lkdGgpIHtcbiAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcihgd2lkdGggb2YgJHt0aGlzLndpZHRofSBkb2VzIG5vdCBtYXRjaCBpbnB1dExheWVyLndpZHRoIG9mICR7dGhpcy5pbnB1dExheWVyLndpZHRofWApO1xuICAgICAgICB9XG4gICAgICAgIGlmICh0aGlzLmhlaWdodCAhPT0gdGhpcy5pbnB1dExheWVyLmhlaWdodCkge1xuICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKGBoZWlnaHQgb2YgJHt0aGlzLmhlaWdodH0gZG9lcyBub3QgbWF0Y2ggaW5wdXRMYXllci5oZWlnaHQgb2YgJHt0aGlzLmlucHV0TGF5ZXIuaGVpZ2h0fWApO1xuICAgICAgICB9XG4gICAgICAgIGlmICh0aGlzLmRlcHRoICE9PSAoKF9hID0gdGhpcy5pbnB1dExheWVyLmRlcHRoKSAhPT0gbnVsbCAmJiBfYSAhPT0gdm9pZCAwID8gX2EgOiAwKSkge1xuICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKGBkZXB0aCBvZiAke3RoaXMuZGVwdGh9IGRvZXMgbm90IG1hdGNoIGlucHV0TGF5ZXIuZGVwdGggb2YgJHt0aGlzLmlucHV0TGF5ZXIuZGVwdGh9YCk7XG4gICAgICAgIH1cbiAgICB9XG59XG5cbmNsYXNzIE9wZXJhdG9yIGV4dGVuZHMgQmFzZUxheWVyIHtcbiAgICBjb25zdHJ1Y3RvcihpbnB1dExheWVyMSwgaW5wdXRMYXllcjIsIHNldHRpbmdzKSB7XG4gICAgICAgIHN1cGVyKHNldHRpbmdzKTtcbiAgICAgICAgdGhpcy5pbnB1dExheWVyMSA9IGlucHV0TGF5ZXIxO1xuICAgICAgICB0aGlzLmlucHV0TGF5ZXIyID0gaW5wdXRMYXllcjI7XG4gICAgICAgIHRoaXMudmFsaWRhdGUoKTtcbiAgICAgICAgdGhpcy53ZWlnaHRzID0gemVyb3MyRCh0aGlzLndpZHRoLCB0aGlzLmhlaWdodCk7XG4gICAgICAgIHRoaXMuZGVsdGFzID0gemVyb3MyRCh0aGlzLndpZHRoLCB0aGlzLmhlaWdodCk7XG4gICAgICAgIHRoaXMuc2V0dXBQcmF4aXMoKTtcbiAgICB9XG59XG5cbmZ1bmN0aW9uIGNvbXBhcmUxRCh3ZWlnaHRzLCB0YXJnZXRWYWx1ZXMpIHtcbiAgICByZXR1cm4gd2VpZ2h0c1t0aGlzLnRocmVhZC55XVt0aGlzLnRocmVhZC54XSAtIHRhcmdldFZhbHVlc1t0aGlzLnRocmVhZC54XTtcbn1cbmZ1bmN0aW9uIGNvbXBhcmUyRCQ1KHdlaWdodHMsIHRhcmdldFZhbHVlcykge1xuICAgIHJldHVybiAod2VpZ2h0c1t0aGlzLnRocmVhZC55XVt0aGlzLnRocmVhZC54XSAtXG4gICAgICAgIHRhcmdldFZhbHVlc1t0aGlzLnRocmVhZC55XVt0aGlzLnRocmVhZC54XSk7XG59XG5jbGFzcyBUYXJnZXQgZXh0ZW5kcyBCYXNlTGF5ZXIge1xuICAgIGNvbnN0cnVjdG9yKHNldHRpbmdzLCBpbnB1dExheWVyKSB7XG4gICAgICAgIHN1cGVyKHNldHRpbmdzKTtcbiAgICAgICAgdGhpcy5pbnB1dExheWVyID0gaW5wdXRMYXllcjtcbiAgICAgICAgdGhpcy52YWxpZGF0ZSgpO1xuICAgICAgICBpZiAodGhpcy5kZXB0aCkge1xuICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdUYXJnZXQgbGF5ZXIgbm90IGltcGxlbWVudGVkIGZvciBkZXB0aCcpO1xuICAgICAgICB9XG4gICAgICAgIGVsc2UgaWYgKHRoaXMuaGVpZ2h0KSB7XG4gICAgICAgICAgICB0aGlzLndlaWdodHMgPSB6ZXJvczJEKHRoaXMud2lkdGgsIHRoaXMuaGVpZ2h0KTtcbiAgICAgICAgICAgIHRoaXMuZGVsdGFzID0gemVyb3MyRCh0aGlzLndpZHRoLCB0aGlzLmhlaWdodCk7XG4gICAgICAgICAgICB0aGlzLmVycm9ycyA9IHplcm9zMkQodGhpcy53aWR0aCwgdGhpcy5oZWlnaHQpO1xuICAgICAgICB9XG4gICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgdGhpcy53ZWlnaHRzID0gemVyb3MkMSh0aGlzLndpZHRoKTtcbiAgICAgICAgICAgIHRoaXMuZGVsdGFzID0gemVyb3MkMSh0aGlzLndpZHRoKTtcbiAgICAgICAgICAgIHRoaXMuZXJyb3JzID0gemVyb3MkMSh0aGlzLndpZHRoKTtcbiAgICAgICAgfVxuICAgIH1cbiAgICBzZXR1cEtlcm5lbHMoKSB7XG4gICAgICAgIGlmICh0aGlzLndpZHRoID09PSAxKSB7XG4gICAgICAgICAgICB0aGlzLmNvbXBhcmVLZXJuZWwgPSBtYWtlS2VybmVsKGNvbXBhcmUxRCwge1xuICAgICAgICAgICAgICAgIG91dHB1dDogW3RoaXMud2lkdGgsIHRoaXMuaGVpZ2h0XSxcbiAgICAgICAgICAgICAgICBpbW11dGFibGU6IHRydWUsXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgfVxuICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgIHRoaXMuY29tcGFyZUtlcm5lbCA9IG1ha2VLZXJuZWwoY29tcGFyZTJEJDUsIHtcbiAgICAgICAgICAgICAgICBvdXRwdXQ6IFt0aGlzLndpZHRoLCB0aGlzLmhlaWdodF0sXG4gICAgICAgICAgICAgICAgaW1tdXRhYmxlOiB0cnVlLFxuICAgICAgICAgICAgfSk7XG4gICAgICAgIH1cbiAgICB9XG4gICAgcHJlZGljdCgpIHtcbiAgICAgICAgLy8gVE9ETzogc2hvdWxkIHdlIGNsb25lIGhlcmU/XG4gICAgICAgIC8vIE5PVEU6IHRoaXMgbG9va3MgbGlrZSBpdCBzaG91bGRuJ3QgYmUsIGJ1dCB0aGUgd2VpZ2h0cyBhcmUgaW1tdXRhYmxlLCBhbmQgdGhpcyBpcyB3aGVyZSB0aGV5IGFyZSByZXVzZWQuXG4gICAgICAgIHJlbGVhc2UodGhpcy53ZWlnaHRzKTtcbiAgICAgICAgdGhpcy53ZWlnaHRzID0gY2xvbmUodGhpcy5pbnB1dExheWVyLndlaWdodHMpO1xuICAgICAgICBjbGVhcih0aGlzLmRlbHRhcyk7XG4gICAgfVxuICAgIGNvbXBhcmUodGFyZ2V0VmFsdWVzKSB7XG4gICAgICAgIC8vIHRoaXMgaXMgd2hlcmUgd2VpZ2h0cyBhdHRhY2ggdG8gZGVsdGFzXG4gICAgICAgIC8vIGRlbHRhcyB3aWxsIGJlIHplcm8gb24gbGVhcm4sIHNvIHNhdmUgaXQgaW4gZXJyb3IgZm9yIGNvbXBhcmluZyB0byBtc2UgbGF0ZXJcbiAgICAgICAgcmVsZWFzZSh0aGlzLmRlbHRhcyk7XG4gICAgICAgIHJlbGVhc2UodGhpcy5lcnJvcnMpO1xuICAgICAgICByZWxlYXNlKHRoaXMuaW5wdXRMYXllci5kZWx0YXMpO1xuICAgICAgICB0aGlzLmRlbHRhcyA9IHRoaXMuY29tcGFyZUtlcm5lbCh0aGlzLndlaWdodHMsIHRhcmdldFZhbHVlcyk7XG4gICAgICAgIHRoaXMuaW5wdXRMYXllci5kZWx0YXMgPSBjbG9uZSh0aGlzLmRlbHRhcyk7XG4gICAgICAgIHRoaXMuZXJyb3JzID0gY2xvbmUodGhpcy5kZWx0YXMpO1xuICAgIH1cbiAgICBzZXR1cFByYXhpcygpIHsgfVxufVxuZnVuY3Rpb24gdGFyZ2V0KHNldHRpbmdzLCBpbnB1dExheWVyKSB7XG4gICAgcmV0dXJuIG5ldyBUYXJnZXQoc2V0dGluZ3MsIGlucHV0TGF5ZXIpO1xufVxuXG4vLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgQHR5cGVzY3JpcHQtZXNsaW50L25vLWV4dHJhbmVvdXMtY2xhc3NcbmNsYXNzIEludGVybmFsTW9kZWwge1xufVxuLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIEB0eXBlc2NyaXB0LWVzbGludC9uby1leHRyYW5lb3VzLWNsYXNzXG5jbGFzcyBFbnRyeVBvaW50IGV4dGVuZHMgQmFzZUxheWVyIHtcbn1cbi8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBAdHlwZXNjcmlwdC1lc2xpbnQvbm8tZXh0cmFuZW91cy1jbGFzc1xuY2xhc3MgTW9kZWwgZXh0ZW5kcyBCYXNlTGF5ZXIge1xufVxuXG4vKiBGdW5jdGlvbnMgZm9yIHR1cm5pbmcgc3BhcnNlIGhhc2hlcyBpbnRvIGFycmF5cyBhbmQgdmljZSB2ZXJzYSAqL1xuY29uc3QgbG9va3VwID0ge1xuICAgIC8qKlxuICAgICAqIFBlcmZvcm1zIGBbe2E6IDF9LCB7YjogNiwgYzogN31dIC0+IHthOiAwLCBiOiAxLCBjOiAyfWBcbiAgICAgKiBAcGFyYW0ge09iamVjdH0gaGFzaGVzXG4gICAgICogQHJldHVybnMge09iamVjdH1cbiAgICAgKi9cbiAgICB0b1RhYmxlKGhhc2hlcykge1xuICAgICAgICBjb25zdCBoYXNoID0gaGFzaGVzLnJlZHVjZSgobWVtbywgaGFzaCkgPT4ge1xuICAgICAgICAgICAgcmV0dXJuIE9iamVjdC5hc3NpZ24obWVtbywgaGFzaCk7XG4gICAgICAgIH0sIHt9KTtcbiAgICAgICAgcmV0dXJuIGxvb2t1cC50b0hhc2goaGFzaCk7XG4gICAgfSxcbiAgICAvKipcbiAgICAgKiBQZXJmb3JtcyBgW3thOiAxfSwge2I6IDYsIGM6IDd9XSAtPiB7YTogMCwgYjogMSwgYzogMn1gXG4gICAgICovXG4gICAgdG9UYWJsZTJEKG9iamVjdHMyRCkge1xuICAgICAgICBjb25zdCB0YWJsZSA9IHt9O1xuICAgICAgICBsZXQgdmFsdWVJbmRleCA9IDA7XG4gICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgb2JqZWN0czJELmxlbmd0aDsgaSsrKSB7XG4gICAgICAgICAgICBjb25zdCBvYmplY3RzID0gb2JqZWN0czJEW2ldO1xuICAgICAgICAgICAgZm9yIChsZXQgaiA9IDA7IGogPCBvYmplY3RzLmxlbmd0aDsgaisrKSB7XG4gICAgICAgICAgICAgICAgY29uc3Qgb2JqZWN0ID0gb2JqZWN0c1tqXTtcbiAgICAgICAgICAgICAgICBmb3IgKGNvbnN0IHAgaW4gb2JqZWN0KSB7XG4gICAgICAgICAgICAgICAgICAgIGlmIChvYmplY3QuaGFzT3duUHJvcGVydHkocCkgJiYgIXRhYmxlLmhhc093blByb3BlcnR5KHApKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB0YWJsZVtwXSA9IHZhbHVlSW5kZXgrKztcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gdGFibGU7XG4gICAgfSxcbiAgICB0b0lucHV0VGFibGUyRChkYXRhKSB7XG4gICAgICAgIGNvbnN0IHRhYmxlID0ge307XG4gICAgICAgIGxldCB0YWJsZUluZGV4ID0gMDtcbiAgICAgICAgZm9yIChsZXQgZGF0YUluZGV4ID0gMDsgZGF0YUluZGV4IDwgZGF0YS5sZW5ndGg7IGRhdGFJbmRleCsrKSB7XG4gICAgICAgICAgICBjb25zdCBpbnB1dCA9IGRhdGFbZGF0YUluZGV4XS5pbnB1dDtcbiAgICAgICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgaW5wdXQubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgICAgICAgICBjb25zdCBvYmplY3QgPSBpbnB1dFtpXTtcbiAgICAgICAgICAgICAgICBmb3IgKGNvbnN0IHAgaW4gb2JqZWN0KSB7XG4gICAgICAgICAgICAgICAgICAgIGlmICghb2JqZWN0Lmhhc093blByb3BlcnR5KHApKVxuICAgICAgICAgICAgICAgICAgICAgICAgY29udGludWU7XG4gICAgICAgICAgICAgICAgICAgIGlmICghdGFibGUuaGFzT3duUHJvcGVydHkocCkpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRhYmxlW3BdID0gdGFibGVJbmRleCsrO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIHJldHVybiB0YWJsZTtcbiAgICB9LFxuICAgIHRvT3V0cHV0VGFibGUyRChkYXRhKSB7XG4gICAgICAgIGNvbnN0IHRhYmxlID0ge307XG4gICAgICAgIGxldCB0YWJsZUluZGV4ID0gMDtcbiAgICAgICAgZm9yIChsZXQgZGF0YUluZGV4ID0gMDsgZGF0YUluZGV4IDwgZGF0YS5sZW5ndGg7IGRhdGFJbmRleCsrKSB7XG4gICAgICAgICAgICBjb25zdCBvdXRwdXQgPSBkYXRhW2RhdGFJbmRleF0ub3V0cHV0O1xuICAgICAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBvdXRwdXQubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgICAgICAgICBjb25zdCBvYmplY3QgPSBvdXRwdXRbaV07XG4gICAgICAgICAgICAgICAgZm9yIChjb25zdCBwIGluIG9iamVjdCkge1xuICAgICAgICAgICAgICAgICAgICBpZiAoIW9iamVjdC5oYXNPd25Qcm9wZXJ0eShwKSlcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnRpbnVlO1xuICAgICAgICAgICAgICAgICAgICBpZiAoIXRhYmxlLmhhc093blByb3BlcnR5KHApKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB0YWJsZVtwXSA9IHRhYmxlSW5kZXgrKztcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gdGFibGU7XG4gICAgfSxcbiAgICAvKipcbiAgICAgKiBwZXJmb3JtcyBge2E6IDYsIGI6IDd9IC0+IHthOiAwLCBiOiAxfWBcbiAgICAgKi9cbiAgICB0b0hhc2goaGFzaCkge1xuICAgICAgICBjb25zdCBsb29rdXAgPSB7fTtcbiAgICAgICAgbGV0IGluZGV4ID0gMDtcbiAgICAgICAgY29uc3Qga2V5cyA9IE9iamVjdC5rZXlzKGhhc2gpO1xuICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IGtleXMubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgICAgIGxvb2t1cFtrZXlzW2ldXSA9IGluZGV4Kys7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIGxvb2t1cDtcbiAgICB9LFxuICAgIC8qKlxuICAgICAqIHBlcmZvcm1zIGB7YTogMCwgYjogMX0sIHthOiA2fSAtPiBbNiwgMF1gXG4gICAgICovXG4gICAgdG9BcnJheShsb29rdXAsIG9iamVjdCwgYXJyYXlMZW5ndGgpIHtcbiAgICAgICAgY29uc3QgcmVzdWx0ID0gbmV3IEZsb2F0MzJBcnJheShhcnJheUxlbmd0aCk7XG4gICAgICAgIGZvciAoY29uc3QgcCBpbiBsb29rdXApIHtcbiAgICAgICAgICAgIGlmICghbG9va3VwLmhhc093blByb3BlcnR5KHApKVxuICAgICAgICAgICAgICAgIGNvbnRpbnVlO1xuICAgICAgICAgICAgcmVzdWx0W2xvb2t1cFtwXV0gPSBvYmplY3QuaGFzT3duUHJvcGVydHkocCkgPyBvYmplY3RbcF0gOiAwO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiByZXN1bHQ7XG4gICAgfSxcbiAgICB0b0FycmF5U2hvcnQobG9va3VwLCBvYmplY3QpIHtcbiAgICAgICAgY29uc3QgcmVzdWx0ID0gW107XG4gICAgICAgIGZvciAoY29uc3QgcCBpbiBsb29rdXApIHtcbiAgICAgICAgICAgIGlmICghbG9va3VwLmhhc093blByb3BlcnR5KHApKVxuICAgICAgICAgICAgICAgIGNvbnRpbnVlO1xuICAgICAgICAgICAgaWYgKCFvYmplY3QuaGFzT3duUHJvcGVydHkocCkpXG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICByZXN1bHRbbG9va3VwW3BdXSA9IG9iamVjdFtwXTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gRmxvYXQzMkFycmF5LmZyb20ocmVzdWx0KTtcbiAgICB9LFxuICAgIHRvQXJyYXlzKGxvb2t1cCwgb2JqZWN0cywgYXJyYXlMZW5ndGgpIHtcbiAgICAgICAgY29uc3QgcmVzdWx0ID0gW107XG4gICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgb2JqZWN0cy5sZW5ndGg7IGkrKykge1xuICAgICAgICAgICAgcmVzdWx0LnB1c2godGhpcy50b0FycmF5KGxvb2t1cCwgb2JqZWN0c1tpXSwgYXJyYXlMZW5ndGgpKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gcmVzdWx0O1xuICAgIH0sXG4gICAgLyoqXG4gICAgICogcGVyZm9ybXMgYHthOiAwLCBiOiAxfSwgWzYsIDddIC0+IHthOiA2LCBiOiA3fWBcbiAgICAgKiBAcGFyYW0ge09iamVjdH0gbG9va3VwXG4gICAgICogQHBhcmFtIHtBcnJheX0gYXJyYXlcbiAgICAgKiBAcmV0dXJucyB7T2JqZWN0fVxuICAgICAqL1xuICAgIHRvT2JqZWN0KGxvb2t1cCwgYXJyYXkpIHtcbiAgICAgICAgY29uc3Qgb2JqZWN0ID0ge307XG4gICAgICAgIGZvciAoY29uc3QgcCBpbiBsb29rdXApIHtcbiAgICAgICAgICAgIGlmICghbG9va3VwLmhhc093blByb3BlcnR5KHApKVxuICAgICAgICAgICAgICAgIGNvbnRpbnVlO1xuICAgICAgICAgICAgb2JqZWN0W3BdID0gYXJyYXlbbG9va3VwW3BdXTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gb2JqZWN0O1xuICAgIH0sXG4gICAgdG9PYmplY3RQYXJ0aWFsKGxvb2t1cCwgYXJyYXksIG9mZnNldCA9IDAsIGxpbWl0ID0gMCkge1xuICAgICAgICBjb25zdCBvYmplY3QgPSB7fTtcbiAgICAgICAgbGV0IGkgPSAwO1xuICAgICAgICBmb3IgKGNvbnN0IHAgaW4gbG9va3VwKSB7XG4gICAgICAgICAgICBpZiAoIWxvb2t1cC5oYXNPd25Qcm9wZXJ0eShwKSlcbiAgICAgICAgICAgICAgICBjb250aW51ZTtcbiAgICAgICAgICAgIGlmIChvZmZzZXQgPiAwKSB7XG4gICAgICAgICAgICAgICAgaWYgKGkrKyA8IG9mZnNldClcbiAgICAgICAgICAgICAgICAgICAgY29udGludWU7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBpZiAobGltaXQgPiAwKSB7XG4gICAgICAgICAgICAgICAgaWYgKGkrKyA+PSBsaW1pdClcbiAgICAgICAgICAgICAgICAgICAgY29udGludWU7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBvYmplY3RbcF0gPSBhcnJheVtsb29rdXBbcF0gLSBvZmZzZXRdO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBvYmplY3Q7XG4gICAgfSxcbiAgICBkYXRhU2hhcGUoZGF0YSkge1xuICAgICAgICBjb25zdCBzaGFwZSA9IFtdO1xuICAgICAgICBsZXQgbGFzdERhdGE7XG4gICAgICAgIGlmIChkYXRhLmhhc093blByb3BlcnR5KCdpbnB1dCcpKSB7XG4gICAgICAgICAgICBzaGFwZS5wdXNoKCdkYXR1bScpO1xuICAgICAgICAgICAgbGFzdERhdGEgPSBkYXRhLmlucHV0O1xuICAgICAgICB9XG4gICAgICAgIGVsc2UgaWYgKEFycmF5LmlzQXJyYXkoZGF0YSkpIHtcbiAgICAgICAgICAgIGlmIChkYXRhWzBdICYmXG4gICAgICAgICAgICAgICAgZGF0YVswXS5pbnB1dCkge1xuICAgICAgICAgICAgICAgIHNoYXBlLnB1c2goJ2FycmF5JywgJ2RhdHVtJyk7XG4gICAgICAgICAgICAgICAgbGFzdERhdGEgPSBkYXRhWzBdLmlucHV0O1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZWxzZSBpZiAoQXJyYXkuaXNBcnJheShkYXRhWzBdKSkge1xuICAgICAgICAgICAgICAgIHNoYXBlLnB1c2goJ2FycmF5Jyk7XG4gICAgICAgICAgICAgICAgbGFzdERhdGEgPSBkYXRhWzBdO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgICAgbGFzdERhdGEgPSBkYXRhO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgbGFzdERhdGEgPSBkYXRhO1xuICAgICAgICB9XG4gICAgICAgIGxldCBwO1xuICAgICAgICB3aGlsZSAobGFzdERhdGEpIHtcbiAgICAgICAgICAgIHAgPSBPYmplY3Qua2V5cyhsYXN0RGF0YSlbMF07XG4gICAgICAgICAgICBpZiAoQXJyYXkuaXNBcnJheShsYXN0RGF0YSkgfHxcbiAgICAgICAgICAgICAgICB0eXBlb2YgbGFzdERhdGEuYnVmZmVyID09PSAnb2JqZWN0Jykge1xuICAgICAgICAgICAgICAgIHNoYXBlLnB1c2goJ2FycmF5Jyk7XG4gICAgICAgICAgICAgICAgY29uc3QgcG9zc2libGVOdW1iZXIgPSBsYXN0RGF0YVtwYXJzZUludChwKV07XG4gICAgICAgICAgICAgICAgaWYgKHR5cGVvZiBwb3NzaWJsZU51bWJlciA9PT0gJ251bWJlcicpIHtcbiAgICAgICAgICAgICAgICAgICAgc2hhcGUucHVzaCgnbnVtYmVyJyk7XG4gICAgICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgbGFzdERhdGEgPSBwb3NzaWJsZU51bWJlcjtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBlbHNlIGlmICh0eXBlb2YgbGFzdERhdGEgPT09ICdvYmplY3QnICYmXG4gICAgICAgICAgICAgICAgdHlwZW9mIGxhc3REYXRhLmJ1ZmZlciAhPT0gJ29iamVjdCcpIHtcbiAgICAgICAgICAgICAgICBzaGFwZS5wdXNoKCdvYmplY3QnKTtcbiAgICAgICAgICAgICAgICBjb25zdCBwb3NzaWJsZU51bWJlciA9IGxhc3REYXRhW3BdO1xuICAgICAgICAgICAgICAgIGlmICh0eXBlb2YgcG9zc2libGVOdW1iZXIgPT09ICdudW1iZXInKSB7XG4gICAgICAgICAgICAgICAgICAgIHNoYXBlLnB1c2goJ251bWJlcicpO1xuICAgICAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgIGxhc3REYXRhID0gcG9zc2libGVOdW1iZXI7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKCd1bmhhbmRsZWQgc2lnbmF0dXJlJyk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHNoYXBlO1xuICAgIH0sXG4gICAgYWRkS2V5cyh2YWx1ZSwgdGFibGUpIHtcbiAgICAgICAgaWYgKEFycmF5LmlzQXJyYXkodmFsdWUpKVxuICAgICAgICAgICAgcmV0dXJuIHRhYmxlO1xuICAgICAgICBsZXQgaSA9IE9iamVjdC5rZXlzKHRhYmxlKS5sZW5ndGg7XG4gICAgICAgIGZvciAoY29uc3QgcCBpbiB2YWx1ZSkge1xuICAgICAgICAgICAgaWYgKCF2YWx1ZS5oYXNPd25Qcm9wZXJ0eShwKSlcbiAgICAgICAgICAgICAgICBjb250aW51ZTtcbiAgICAgICAgICAgIGlmICh0YWJsZS5oYXNPd25Qcm9wZXJ0eShwKSlcbiAgICAgICAgICAgICAgICBjb250aW51ZTtcbiAgICAgICAgICAgIHRhYmxlW3BdID0gaSsrO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiB0YWJsZTtcbiAgICB9LFxufTtcblxuY2xhc3MgQmFzZVByYXhpcyB7XG4gICAgY29uc3RydWN0b3IobGF5ZXJUZW1wbGF0ZSwgc2V0dGluZ3MgPSB7fSkge1xuICAgICAgICB0aGlzLmxheWVyVGVtcGxhdGUgPSBsYXllclRlbXBsYXRlO1xuICAgICAgICB0aGlzLnNldHRpbmdzID0geyAuLi5zZXR0aW5ncyB9O1xuICAgICAgICB0aGlzLmtlcm5lbCA9IG51bGw7XG4gICAgfVxuICAgIGdldCB3aWR0aCgpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMubGF5ZXJUZW1wbGF0ZS53aWR0aDtcbiAgICB9XG4gICAgZ2V0IGhlaWdodCgpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMubGF5ZXJUZW1wbGF0ZS5oZWlnaHQ7XG4gICAgfVxuICAgIGdldCBkZXB0aCgpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMubGF5ZXJUZW1wbGF0ZS5kZXB0aDtcbiAgICB9XG4gICAgc2V0dXBLZXJuZWxzKCkgeyB9XG4gICAgcmV1c2VLZXJuZWxzKHByYXhpcykge1xuICAgICAgICBpZiAocHJheGlzLndpZHRoICE9PSB0aGlzLndpZHRoKSB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoYCR7dGhpcy5jb25zdHJ1Y3Rvci5uYW1lfSBrZXJuZWwgd2lkdGggbWlzbWF0Y2ggJHtwcmF4aXMud2lkdGh9IGlzIG5vdCAke3RoaXMud2lkdGh9YCk7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKHByYXhpcy5oZWlnaHQgIT09IHRoaXMuaGVpZ2h0KSB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoYCR7dGhpcy5jb25zdHJ1Y3Rvci5uYW1lfSBrZXJuZWwgd2lkdGggbWlzbWF0Y2ggJHtwcmF4aXMuaGVpZ2h0fSBpcyBub3QgJHt0aGlzLmhlaWdodH1gKTtcbiAgICAgICAgfVxuICAgICAgICBpZiAocHJheGlzLmhhc093blByb3BlcnR5KCdrZXJuZWwnKSkge1xuICAgICAgICAgICAgdGhpcy5rZXJuZWwgPSBwcmF4aXMua2VybmVsO1xuICAgICAgICB9XG4gICAgfVxuICAgIHRvSlNPTigpIHtcbiAgICAgICAgcmV0dXJuIHsgLi4udGhpcy5zZXR0aW5ncyB9O1xuICAgIH1cbn1cblxuZnVuY3Rpb24gdXBkYXRlJDIod2VpZ2h0cywgZGVsdGFzKSB7XG4gICAgcmV0dXJuICh3ZWlnaHRzW3RoaXMudGhyZWFkLnldW3RoaXMudGhyZWFkLnhdICtcbiAgICAgICAgdGhpcy5jb25zdGFudHMubGVhcm5pbmdSYXRlICogZGVsdGFzW3RoaXMudGhyZWFkLnldW3RoaXMudGhyZWFkLnhdKTtcbn1cbmNvbnN0IGRlZmF1bHRTZXR0aW5ncyQxID0ge1xuICAgIGxlYXJuaW5nUmF0ZTogMC4zLFxufTtcbmNsYXNzIEFydGh1ckRldmlhdGlvbkJpYXNlcyBleHRlbmRzIEJhc2VQcmF4aXMge1xuICAgIGNvbnN0cnVjdG9yKGxheWVyLCBzZXR0aW5ncykge1xuICAgICAgICBzdXBlcihsYXllcik7XG4gICAgICAgIHRoaXMuc2V0dGluZ3MgPSB7IC4uLmRlZmF1bHRTZXR0aW5ncyQxLCAuLi5zZXR0aW5ncyB9O1xuICAgICAgICB0aGlzLmtlcm5lbCA9IG51bGw7XG4gICAgfVxuICAgIHJ1bihsYXllcikge1xuICAgICAgICByZXR1cm4gdGhpcy5rZXJuZWwobGF5ZXIud2VpZ2h0cywgbGF5ZXIuZGVsdGFzKTtcbiAgICB9XG4gICAgc2V0dXBLZXJuZWxzKCkge1xuICAgICAgICB0aGlzLmtlcm5lbCA9IG1ha2VLZXJuZWwodXBkYXRlJDIsIHtcbiAgICAgICAgICAgIG91dHB1dDogW3RoaXMud2lkdGgsIHRoaXMuaGVpZ2h0XSxcbiAgICAgICAgICAgIGNvbnN0YW50czoge1xuICAgICAgICAgICAgICAgIGxlYXJuaW5nUmF0ZTogdGhpcy5zZXR0aW5ncy5sZWFybmluZ1JhdGUsXG4gICAgICAgICAgICB9LFxuICAgICAgICB9KTtcbiAgICB9XG59XG5mdW5jdGlvbiBhcnRodXJEZXZpYXRpb25CaWFzZXMobGF5ZXIsIHNldHRpbmdzKSB7XG4gICAgcmV0dXJuIG5ldyBBcnRodXJEZXZpYXRpb25CaWFzZXMobGF5ZXIsIHNldHRpbmdzKTtcbn1cblxuZnVuY3Rpb24gdXBkYXRlQ2hhbmdlKHZhbHVlKSB7XG4gICAgcmV0dXJuIHZhbHVlO1xufVxuZnVuY3Rpb24gdXBkYXRlJDEoY2hhbmdlcywgd2VpZ2h0cywgaW5jb21pbmdXZWlnaHRzLCBpbnB1dERlbHRhcykge1xuICAgIGNvbnN0IGxhc3RDaGFuZ2UgPSBjaGFuZ2VzW3RoaXMudGhyZWFkLnldW3RoaXMudGhyZWFkLnhdO1xuICAgIGNvbnN0IGlucHV0RGVsdGEgPSBpbnB1dERlbHRhc1t0aGlzLnRocmVhZC55XVswXTtcbiAgICBjb25zdCB3ZWlnaHQgPSB3ZWlnaHRzW3RoaXMudGhyZWFkLnldW3RoaXMudGhyZWFkLnhdO1xuICAgIGNvbnN0IGluY29taW5nID0gaW5jb21pbmdXZWlnaHRzW3RoaXMudGhyZWFkLnhdWzBdO1xuICAgIGNvbnN0IGNoYW5nZSA9IHRoaXMuY29uc3RhbnRzLmxlYXJuaW5nUmF0ZSAqIGlucHV0RGVsdGEgKiBpbmNvbWluZyArXG4gICAgICAgIHRoaXMuY29uc3RhbnRzLm1vbWVudHVtICogbGFzdENoYW5nZTtcbiAgICByZXR1cm4gd2VpZ2h0ICsgY2hhbmdlO1xufVxuY29uc3QgZGVmYXVsdFNldHRpbmdzID0ge1xuICAgIGxlYXJuaW5nUmF0ZTogMC4zLFxuICAgIG1vbWVudHVtOiAwLjEsXG4gICAgd2VpZ2h0c0xheWVyOiBudWxsLFxuICAgIGluY29taW5nTGF5ZXI6IG51bGwsXG4gICAgZGVsdGFMYXllcjogbnVsbCxcbn07XG5jbGFzcyBBcnRodXJEZXZpYXRpb25XZWlnaHRzIGV4dGVuZHMgQmFzZVByYXhpcyB7XG4gICAgY29uc3RydWN0b3IobGF5ZXIsIHNldHRpbmdzKSB7XG4gICAgICAgIHN1cGVyKGxheWVyKTtcbiAgICAgICAgdGhpcy5rZXJuZWxNYXAgPSBudWxsO1xuICAgICAgICB0aGlzLnNldHRpbmdzID0geyAuLi5kZWZhdWx0U2V0dGluZ3MsIC4uLnNldHRpbmdzIH07XG4gICAgICAgIHRoaXMuY2hhbmdlcyA9IHplcm9zMkQobGF5ZXIud2lkdGgsIGxheWVyLmhlaWdodCk7XG4gICAgfVxuICAgIGdldCBsZWFybmluZ1JhdGUoKSB7XG4gICAgICAgIHJldHVybiB0aGlzLnNldHRpbmdzLmxlYXJuaW5nUmF0ZTtcbiAgICB9XG4gICAgZ2V0IG1vbWVudHVtKCkge1xuICAgICAgICByZXR1cm4gdGhpcy5zZXR0aW5ncy5tb21lbnR1bTtcbiAgICB9XG4gICAgZ2V0IHdlaWdodHNMYXllcigpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuc2V0dGluZ3Mud2VpZ2h0c0xheWVyO1xuICAgIH1cbiAgICBzZXQgd2VpZ2h0c0xheWVyKGxheWVyKSB7XG4gICAgICAgIHRoaXMuc2V0dGluZ3Mud2VpZ2h0c0xheWVyID0gbGF5ZXI7XG4gICAgfVxuICAgIGdldCBkZWx0YUxheWVyKCkge1xuICAgICAgICByZXR1cm4gdGhpcy5zZXR0aW5ncy5kZWx0YUxheWVyO1xuICAgIH1cbiAgICBzZXQgZGVsdGFMYXllcihsYXllcikge1xuICAgICAgICB0aGlzLnNldHRpbmdzLmRlbHRhTGF5ZXIgPSBsYXllcjtcbiAgICB9XG4gICAgZ2V0IGluY29taW5nTGF5ZXIoKSB7XG4gICAgICAgIHJldHVybiB0aGlzLnNldHRpbmdzLmluY29taW5nTGF5ZXI7XG4gICAgfVxuICAgIHNldCBpbmNvbWluZ0xheWVyKGxheWVyKSB7XG4gICAgICAgIHRoaXMuc2V0dGluZ3MuaW5jb21pbmdMYXllciA9IGxheWVyO1xuICAgIH1cbiAgICBydW4oKSB7XG4gICAgICAgIGNvbnN0IG91dHB1dCA9IHRoaXMua2VybmVsTWFwKHRoaXMuY2hhbmdlcywgdGhpcy53ZWlnaHRzTGF5ZXIud2VpZ2h0cywgdGhpcy5pbmNvbWluZ0xheWVyLndlaWdodHMsIHRoaXMuZGVsdGFMYXllci5kZWx0YXMpO1xuICAgICAgICB0aGlzLmNoYW5nZXMgPSBvdXRwdXQuY2hhbmdlcztcbiAgICAgICAgcmV0dXJuIG91dHB1dC5yZXN1bHQ7XG4gICAgfVxuICAgIHNldHVwS2VybmVscygpIHtcbiAgICAgICAgdGhpcy5rZXJuZWxNYXAgPSBtYWtlS2VybmVsTWFwKHtcbiAgICAgICAgICAgIGNoYW5nZXM6IHVwZGF0ZUNoYW5nZSxcbiAgICAgICAgfSwgdXBkYXRlJDEsIHtcbiAgICAgICAgICAgIG91dHB1dDogW3RoaXMud2lkdGgsIHRoaXMuaGVpZ2h0XSxcbiAgICAgICAgICAgIGNvbnN0YW50czoge1xuICAgICAgICAgICAgICAgIGxlYXJuaW5nUmF0ZTogdGhpcy5sZWFybmluZ1JhdGUsXG4gICAgICAgICAgICAgICAgbW9tZW50dW06IHRoaXMubW9tZW50dW0sXG4gICAgICAgICAgICB9LFxuICAgICAgICB9KTtcbiAgICB9XG59XG5mdW5jdGlvbiBhcnRodXJEZXZpYXRpb25XZWlnaHRzKGxheWVyLCBzZXR0aW5ncykge1xuICAgIHJldHVybiBuZXcgQXJ0aHVyRGV2aWF0aW9uV2VpZ2h0cyhsYXllciwgc2V0dGluZ3MpO1xufVxuXG5mdW5jdGlvbiBnZXRNb21lbnR1bShkZWx0YSwgZGVjYXksIHByZXZpb3VzTW9tZW50dW0pIHtcbiAgICByZXR1cm4gcHJldmlvdXNNb21lbnR1bSAqIGRlY2F5ICsgKDEgLSBkZWNheSkgKiBkZWx0YSAqIGRlbHRhO1xufVxuZnVuY3Rpb24gY2xpcEJ5VmFsdWUodmFsdWUsIG1heCwgbWluKSB7XG4gICAgaWYgKHZhbHVlID4gbWF4KSB7XG4gICAgICAgIHJldHVybiBtYXg7XG4gICAgfVxuICAgIGlmICh2YWx1ZSA8IG1pbikge1xuICAgICAgICByZXR1cm4gbWluO1xuICAgIH1cbiAgICByZXR1cm4gdmFsdWU7XG59XG4vKipcbiAqIEBkZXNjcmlwdGlvbiBNb21lbnR1bSBSb290IE1lYW4gU3F1YXJlIFByb3BhZ2F0aW9uIEZ1bmN0aW9uXG4gKi9cbmZ1bmN0aW9uIHVwZGF0ZSh3ZWlnaHRzLCBkZWx0YXMsIHByZXZpb3VzTW9tZW50YSkge1xuICAgIGNvbnN0IGRlbHRhID0gZGVsdGFzW3RoaXMudGhyZWFkLnldW3RoaXMudGhyZWFkLnhdO1xuICAgIGNvbnN0IGNsaXBwZWREZWx0YSA9IGNsaXBCeVZhbHVlKGRlbHRhLCB0aGlzLmNvbnN0YW50cy5jbGlwVmFsdWUsIC10aGlzLmNvbnN0YW50cy5jbGlwVmFsdWUpO1xuICAgIGNvbnN0IHdlaWdodCA9IHdlaWdodHNbdGhpcy50aHJlYWQueV1bdGhpcy50aHJlYWQueF07XG4gICAgY29uc3QgcHJldmlvdXNNb21lbnR1bSA9IHByZXZpb3VzTW9tZW50YVt0aGlzLnRocmVhZC55XVt0aGlzLnRocmVhZC54XTtcbiAgICBjb25zdCBtb21lbnR1bSA9IGdldE1vbWVudHVtKGRlbHRhLCB0aGlzLmNvbnN0YW50cy5kZWNheVJhdGUsIHByZXZpb3VzTW9tZW50dW0pO1xuICAgIHJldHVybiAod2VpZ2h0ICtcbiAgICAgICAgKC10aGlzLmNvbnN0YW50cy5sZWFybmluZ1JhdGUgKiBjbGlwcGVkRGVsdGEpIC9cbiAgICAgICAgICAgIE1hdGguc3FydChtb21lbnR1bSArIHRoaXMuY29uc3RhbnRzLnNtb290aEVwcykgLVxuICAgICAgICB0aGlzLmNvbnN0YW50cy5yZWd1bGFyaXphdGlvblN0cmVuZ3RoICogd2VpZ2h0KTtcbn1cbmNvbnN0IGRlZmF1bHRzJDggPSB7XG4gICAgZGVjYXlSYXRlOiAwLjk5OSxcbiAgICByZWd1bGFyaXphdGlvblN0cmVuZ3RoOiAwLjAwMDEsXG4gICAgbGVhcm5pbmdSYXRlOiAwLjAxLFxuICAgIHNtb290aEVwczogMWUtOCxcbiAgICBjbGlwVmFsdWU6IDUsXG59O1xuY2xhc3MgTW9tZW50dW1Sb290TWVhblNxdWFyZWRQcm9wYWdhdGlvbiBleHRlbmRzIEJhc2VQcmF4aXMge1xuICAgIGNvbnN0cnVjdG9yKGxheWVyVGVtcGxhdGUsIHNldHRpbmdzID0ge30pIHtcbiAgICAgICAgc3VwZXIobGF5ZXJUZW1wbGF0ZSk7XG4gICAgICAgIHRoaXMua2VybmVsTWFwID0gbnVsbDtcbiAgICAgICAgdGhpcy5zZXR0aW5ncyA9IHsgLi4uZGVmYXVsdHMkOCwgLi4uc2V0dGluZ3MgfTtcbiAgICAgICAgdGhpcy5tb21lbnRhID0gemVyb3MyRChsYXllclRlbXBsYXRlLndpZHRoLCBsYXllclRlbXBsYXRlLmhlaWdodCk7XG4gICAgfVxuICAgIGdldCBjbGlwVmFsdWUoKSB7XG4gICAgICAgIHJldHVybiB0aGlzLnNldHRpbmdzLmNsaXBWYWx1ZTtcbiAgICB9XG4gICAgZ2V0IGRlY2F5UmF0ZSgpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuc2V0dGluZ3MuZGVjYXlSYXRlO1xuICAgIH1cbiAgICBnZXQgbGVhcm5pbmdSYXRlKCkge1xuICAgICAgICByZXR1cm4gdGhpcy5zZXR0aW5ncy5sZWFybmluZ1JhdGU7XG4gICAgfVxuICAgIGdldCByZWd1bGFyaXphdGlvblN0cmVuZ3RoKCkge1xuICAgICAgICByZXR1cm4gdGhpcy5zZXR0aW5ncy5yZWd1bGFyaXphdGlvblN0cmVuZ3RoO1xuICAgIH1cbiAgICBnZXQgc21vb3RoRXBzKCkge1xuICAgICAgICByZXR1cm4gdGhpcy5zZXR0aW5ncy5zbW9vdGhFcHM7XG4gICAgfVxuICAgIHJ1bihsYXllcikge1xuICAgICAgICBjb25zdCB7IG1vbWVudGEsIHJlc3VsdCB9ID0gdGhpcy5rZXJuZWxNYXAobGF5ZXIud2VpZ2h0cywgbGF5ZXIuZGVsdGFzLCB0aGlzLm1vbWVudGEpO1xuICAgICAgICByZWxlYXNlKHRoaXMubW9tZW50YSk7XG4gICAgICAgIHRoaXMubW9tZW50YSA9IG1vbWVudGE7XG4gICAgICAgIHJldHVybiByZXN1bHQ7XG4gICAgfVxuICAgIHNldHVwS2VybmVscygpIHtcbiAgICAgICAgdGhpcy5rZXJuZWxNYXAgPSBtYWtlS2VybmVsTWFwKHtcbiAgICAgICAgICAgIG1vbWVudGE6IGdldE1vbWVudHVtLFxuICAgICAgICB9LCB1cGRhdGUsIHtcbiAgICAgICAgICAgIG91dHB1dDogW3RoaXMud2lkdGgsIHRoaXMuaGVpZ2h0XSxcbiAgICAgICAgICAgIGNvbnN0YW50czoge1xuICAgICAgICAgICAgICAgIGNsaXBWYWx1ZTogdGhpcy5jbGlwVmFsdWUsXG4gICAgICAgICAgICAgICAgZGVjYXlSYXRlOiB0aGlzLmRlY2F5UmF0ZSxcbiAgICAgICAgICAgICAgICBsZWFybmluZ1JhdGU6IHRoaXMubGVhcm5pbmdSYXRlLFxuICAgICAgICAgICAgICAgIHJlZ3VsYXJpemF0aW9uU3RyZW5ndGg6IHRoaXMucmVndWxhcml6YXRpb25TdHJlbmd0aCxcbiAgICAgICAgICAgICAgICBzbW9vdGhFcHM6IHRoaXMuc21vb3RoRXBzLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIGZ1bmN0aW9uczogW2NsaXBCeVZhbHVlXSxcbiAgICAgICAgICAgIGltbXV0YWJsZTogdHJ1ZSxcbiAgICAgICAgfSk7XG4gICAgfVxufVxuZnVuY3Rpb24gbW9tZW50dW1Sb290TWVhblNxdWFyZWRQcm9wYWdhdGlvbihsYXllciwgc2V0dGluZ3MpIHtcbiAgICByZXR1cm4gbmV3IE1vbWVudHVtUm9vdE1lYW5TcXVhcmVkUHJvcGFnYXRpb24obGF5ZXIsIHNldHRpbmdzKTtcbn1cbi8qKlxuICogQGRlc2NyaXB0aW9uIE1hdGhlbWF0aWNpYW4gZnJpZW5kbHkgbmFtZSBvZiBNb21lbnR1bVJvb3RNZWFuU3F1YXJlZFByb3BhZ2F0aW9uIGNsYXNzLiBGb3IgdGhvc2UgdGhhdCBhcmUgbm90IG1lcmUgbW9ydGFsc1xuICovXG5jb25zdCBNUm1zUHJvcCA9IE1vbWVudHVtUm9vdE1lYW5TcXVhcmVkUHJvcGFnYXRpb247XG5jb25zdCBtUm1zUHJvcCA9IG1vbWVudHVtUm9vdE1lYW5TcXVhcmVkUHJvcGFnYXRpb247XG5cbnZhciBpbmRleCA9IC8qI19fUFVSRV9fKi9PYmplY3QuZnJlZXplKHtcbiAgICBfX3Byb3RvX186IG51bGwsXG4gICAgQXJ0aHVyRGV2aWF0aW9uQmlhc2VzOiBBcnRodXJEZXZpYXRpb25CaWFzZXMsXG4gICAgYXJ0aHVyRGV2aWF0aW9uQmlhc2VzOiBhcnRodXJEZXZpYXRpb25CaWFzZXMsXG4gICAgQXJ0aHVyRGV2aWF0aW9uV2VpZ2h0czogQXJ0aHVyRGV2aWF0aW9uV2VpZ2h0cyxcbiAgICBhcnRodXJEZXZpYXRpb25XZWlnaHRzOiBhcnRodXJEZXZpYXRpb25XZWlnaHRzLFxuICAgIE1vbWVudHVtUm9vdE1lYW5TcXVhcmVkUHJvcGFnYXRpb246IE1vbWVudHVtUm9vdE1lYW5TcXVhcmVkUHJvcGFnYXRpb24sXG4gICAgbW9tZW50dW1Sb290TWVhblNxdWFyZWRQcm9wYWdhdGlvbjogbW9tZW50dW1Sb290TWVhblNxdWFyZWRQcm9wYWdhdGlvbixcbiAgICBNUm1zUHJvcDogTVJtc1Byb3AsXG4gICAgbVJtc1Byb3A6IG1SbXNQcm9wXG59KTtcblxuZnVuY3Rpb24gdHJhdmVyc2VMYXllcnNGcm9tKGxheWVyLCBjYikge1xuICAgIGlmIChsYXllci5oYXNPd25Qcm9wZXJ0eSgnaW5wdXRMYXllcicpKSB7XG4gICAgICAgIHRyYXZlcnNlTGF5ZXJzRnJvbShsYXllci5pbnB1dExheWVyLCBjYik7XG4gICAgfVxuICAgIGVsc2Uge1xuICAgICAgICBpZiAobGF5ZXIuaGFzT3duUHJvcGVydHkoJ2lucHV0TGF5ZXIxJykpIHtcbiAgICAgICAgICAgIHRyYXZlcnNlTGF5ZXJzRnJvbShsYXllci5pbnB1dExheWVyMSwgY2IpO1xuICAgICAgICB9XG4gICAgICAgIGlmIChsYXllci5oYXNPd25Qcm9wZXJ0eSgnaW5wdXRMYXllcjInKSkge1xuICAgICAgICAgICAgdHJhdmVyc2VMYXllcnNGcm9tKGxheWVyLmlucHV0TGF5ZXIyLCBjYik7XG4gICAgICAgIH1cbiAgICB9XG4gICAgY2IobGF5ZXIpO1xufVxuXG5mdW5jdGlvbiBmbGF0dGVuTGF5ZXJzKGxheWVycykge1xuICAgIGNvbnN0IHJlc3VsdCA9IGxheWVycy5zbGljZSgwKTtcbiAgICBmb3IgKGxldCBpID0gMDsgaSA8IHJlc3VsdC5sZW5ndGg7IGkrKykge1xuICAgICAgICBsZXQgb2Zmc2V0ID0gMDtcbiAgICAgICAgdHJhdmVyc2VMYXllcnNGcm9tKHJlc3VsdFtpXSwgKGxheWVyKSA9PiB7XG4gICAgICAgICAgICBpZiAoIXJlc3VsdC5pbmNsdWRlcyhsYXllcikpIHtcbiAgICAgICAgICAgICAgICByZXN1bHQuc3BsaWNlKGkgKyBvZmZzZXQsIDAsIGxheWVyKTtcbiAgICAgICAgICAgICAgICBvZmZzZXQrKztcbiAgICAgICAgICAgIH1cbiAgICAgICAgfSk7XG4gICAgfVxuICAgIHJldHVybiByZXN1bHQ7XG59XG5cbmZ1bmN0aW9uIGNoZWNrU2FtZVNpemUobGF5ZXIxLCBsYXllcjIpIHtcbiAgICBpZiAobGF5ZXIxLndpZHRoICE9PSBsYXllcjIud2lkdGgpIHtcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKGBMYXllciB3aWR0aCBtaXNtYXRjaCBvZiAke2xheWVyMS53aWR0aH0gYW5kICR7bGF5ZXIyLndpZHRofWApO1xuICAgIH1cbiAgICBpZiAobGF5ZXIxLmhlaWdodCAhPT0gbGF5ZXIyLmhlaWdodCkge1xuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoYExheWVyIGhlaWdodCBtaXNtYXRjaCBvZiAke2xheWVyMS5oZWlnaHR9IGFuZCAke2xheWVyMi5oZWlnaHR9YCk7XG4gICAgfVxufVxuXG5mdW5jdGlvbiBwcmVkaWN0JDgoaW5wdXRXZWlnaHRzMSwgaW5wdXRXZWlnaHRzMikge1xuICAgIHJldHVybiAoaW5wdXRXZWlnaHRzMVt0aGlzLnRocmVhZC55XVt0aGlzLnRocmVhZC54XSArXG4gICAgICAgIGlucHV0V2VpZ2h0czJbdGhpcy50aHJlYWQueV1bdGhpcy50aHJlYWQueF0pO1xufVxuY2xhc3MgQWRkIGV4dGVuZHMgT3BlcmF0b3Ige1xuICAgIGdldCB3aWR0aCgpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuaW5wdXRMYXllcjEud2lkdGg7XG4gICAgfVxuICAgIGdldCBoZWlnaHQoKSB7XG4gICAgICAgIHJldHVybiB0aGlzLmlucHV0TGF5ZXIxLmhlaWdodDtcbiAgICB9XG4gICAgZ2V0IGRlcHRoKCkge1xuICAgICAgICByZXR1cm4gdGhpcy5pbnB1dExheWVyMS5kZXB0aDtcbiAgICB9XG4gICAgdmFsaWRhdGUoKSB7XG4gICAgICAgIHN1cGVyLnZhbGlkYXRlKCk7XG4gICAgICAgIGNoZWNrU2FtZVNpemUodGhpcy5pbnB1dExheWVyMSwgdGhpcy5pbnB1dExheWVyMik7XG4gICAgfVxuICAgIHNldHVwS2VybmVscygpIHtcbiAgICAgICAgdGhpcy5wcmVkaWN0S2VybmVsID0gbWFrZUtlcm5lbChwcmVkaWN0JDgsIHtcbiAgICAgICAgICAgIG91dHB1dDogW3RoaXMud2lkdGgsIHRoaXMuaGVpZ2h0XSxcbiAgICAgICAgICAgIGltbXV0YWJsZTogdHJ1ZSxcbiAgICAgICAgfSk7XG4gICAgfVxuICAgIHByZWRpY3QoKSB7XG4gICAgICAgIHJlbGVhc2UodGhpcy53ZWlnaHRzKTtcbiAgICAgICAgdGhpcy53ZWlnaHRzID0gdGhpcy5wcmVkaWN0S2VybmVsKHRoaXMuaW5wdXRMYXllcjEud2VpZ2h0cywgdGhpcy5pbnB1dExheWVyMi53ZWlnaHRzKTtcbiAgICAgICAgY2xlYXIodGhpcy5kZWx0YXMpO1xuICAgIH1cbiAgICBjb21wYXJlKCkge1xuICAgICAgICAvLyBUT0RPOiBEbyB3ZSBuZWVkIHJlbGVhc2UgYW5kIGNsb25lIGhlcmU/XG4gICAgICAgIHJlbGVhc2UodGhpcy5pbnB1dExheWVyMS5kZWx0YXMpO1xuICAgICAgICByZWxlYXNlKHRoaXMuaW5wdXRMYXllcjIuZGVsdGFzKTtcbiAgICAgICAgdGhpcy5pbnB1dExheWVyMS5kZWx0YXMgPSBjbG9uZSh0aGlzLmRlbHRhcyk7XG4gICAgICAgIHRoaXMuaW5wdXRMYXllcjIuZGVsdGFzID0gY2xvbmUodGhpcy5kZWx0YXMpO1xuICAgIH1cbiAgICBsZWFybigpIHsgfVxufVxuZnVuY3Rpb24gYWRkJDEoaW5wdXRMYXllcjEsIGlucHV0TGF5ZXIyLCBzZXR0aW5ncykge1xuICAgIHJldHVybiBuZXcgQWRkKGlucHV0TGF5ZXIxLCBpbnB1dExheWVyMiwgc2V0dGluZ3MpO1xufVxuXG5mdW5jdGlvbiByYW5kb21XZWlnaHQoKSB7XG4gICAgcmV0dXJuIE1hdGgucmFuZG9tKCkgKiAwLjQgLSAwLjI7XG59XG5cbi8qKlxuICogUmV0dXJucyBhIHJhbmRvbSBmbG9hdCBiZXR3ZWVuIGdpdmVuIG1pbiBhbmQgbWF4IGJvdW5kcyAoaW5jbHVzaXZlKVxuICogQHBhcmFtIG1pbiBNaW5pbXVtIHZhbHVlIG9mIHRoZSByYW5mb20gZmxvYXRcbiAqIEBwYXJhbSBtYXggTWF4aW11bSB2YWx1ZSBvZiB0aGUgcmFuZG9tIGZsb2F0XG4gKi9cbmZ1bmN0aW9uIHJhbmRvbUZsb2F0KG1pbiwgbWF4KSB7XG4gICAgcmV0dXJuIE1hdGgucmFuZG9tKCkgKiAobWF4IC0gbWluKSArIG1pbjtcbn1cbi8qKlxuICogQ29tcGxpY2F0ZWQgbWF0aC4gQWxsIHlvdSBuZWVkIHRvIGtub3cgaXMgdGhhdCBpdCByZXR1cm5zIGEgcmFuZG9tIG51bWJlci5cbiAqIE1vcmUgaW5mbzogaHR0cHM6Ly9lbi53aWtpcGVkaWEub3JnL3dpa2kvTm9ybWFsX2Rpc3RyaWJ1dGlvblxuICovXG5mdW5jdGlvbiBnYXVzc1JhbmRvbSgpIHtcbiAgICBpZiAoZ2F1c3NSYW5kb20ucmV0dXJuVikge1xuICAgICAgICBnYXVzc1JhbmRvbS5yZXR1cm5WID0gZmFsc2U7XG4gICAgICAgIHJldHVybiBnYXVzc1JhbmRvbS52VmFsO1xuICAgIH1cbiAgICBjb25zdCB1ID0gMiAqIE1hdGgucmFuZG9tKCkgLSAxO1xuICAgIGNvbnN0IHYgPSAyICogTWF0aC5yYW5kb20oKSAtIDE7XG4gICAgY29uc3QgciA9IHUgKiB1ICsgdiAqIHY7XG4gICAgaWYgKHIgPT09IDAgfHwgciA+IDEpIHtcbiAgICAgICAgcmV0dXJuIGdhdXNzUmFuZG9tKCk7XG4gICAgfVxuICAgIGNvbnN0IGMgPSBNYXRoLnNxcnQoKC0yICogTWF0aC5sb2cocikpIC8gcik7XG4gICAgZ2F1c3NSYW5kb20udlZhbCA9IHYgKiBjOyAvLyBjYWNoZSB0aGlzXG4gICAgZ2F1c3NSYW5kb20ucmV0dXJuViA9IHRydWU7XG4gICAgcmV0dXJuIHUgKiBjO1xufVxuLyoqXG4gKiBSZXR1cm5zIGEgcmFuZG9tIGludGVnZXIgYmV0d2VlbiBnaXZlbiBtaW4gYW5kIG1heCBib3VuZHNcbiAqIEBwYXJhbSBtaW4gTWluaW11bSB2YWx1ZSBvZiB0aGUgcmFuZG9tIGludGVnZXJcbiAqIEBwYXJhbSBtYXggTWF4aW11bSB2YWx1ZSBvZiB0aGUgcmFuZG9tIGludGVnZXJcbiAqL1xuZnVuY3Rpb24gcmFuZG9tSW50ZWdlcihtaW4sIG1heCkge1xuICAgIHJldHVybiBNYXRoLmZsb29yKE1hdGgucmFuZG9tKCkgKiAobWF4IC0gbWluKSArIG1pbik7XG59XG4vKipcbiAqIElmIHlvdSBrbm93IHdoYXQgdGhpcyBpczogaHR0cHM6Ly9lbi53aWtpcGVkaWEub3JnL3dpa2kvTm9ybWFsX2Rpc3RyaWJ1dGlvblxuICogQHBhcmFtIG11XG4gKiBAcGFyYW0gc3RkXG4gKi9cbmZ1bmN0aW9uIHJhbmRvbU4obXUsIHN0ZCkge1xuICAgIHJldHVybiBtdSArIGdhdXNzUmFuZG9tKCkgKiBzdGQ7XG59XG5nYXVzc1JhbmRvbS5yZXR1cm5WID0gZmFsc2U7XG5nYXVzc1JhbmRvbS52VmFsID0gMDtcblxudmFyIHJhbmRvbSQxID0gLyojX19QVVJFX18qL09iamVjdC5mcmVlemUoe1xuICAgIF9fcHJvdG9fXzogbnVsbCxcbiAgICByYW5kb21GbG9hdDogcmFuZG9tRmxvYXQsXG4gICAgZ2F1c3NSYW5kb206IGdhdXNzUmFuZG9tLFxuICAgIHJhbmRvbUludGVnZXI6IHJhbmRvbUludGVnZXIsXG4gICAgcmFuZG9tTjogcmFuZG9tTlxufSk7XG5cbi8qKlxuICogUmV0dXJucyBhbiBhcnJheSBvZiBnaXZlbiBzaXplLCBmdWxsIG9mIHJhbmRvbW5lc3NcbiAqL1xuZnVuY3Rpb24gcmFuZG9zKHNpemUsIHN0ZCA9IG51bGwpIHtcbiAgICBjb25zdCBhcnJheSA9IG5ldyBGbG9hdDMyQXJyYXkoc2l6ZSk7XG4gICAgaWYgKHN0ZCA9PT0gbnVsbCkge1xuICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IHNpemU7IGkrKykge1xuICAgICAgICAgICAgYXJyYXlbaV0gPSByYW5kb21XZWlnaHQoKTtcbiAgICAgICAgfVxuICAgIH1cbiAgICBlbHNlIHtcbiAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBzaXplOyBpKyspIHtcbiAgICAgICAgICAgIGFycmF5W2ldID0gcmFuZG9tRmxvYXQoLXN0ZCwgc3RkKTtcbiAgICAgICAgfVxuICAgIH1cbiAgICByZXR1cm4gYXJyYXk7XG59XG4vKipcbiAqIFJldHVybnMgYSAyRCBtYXRyaXggb2YgZ2l2ZW4gc2l6ZSwgZnVsbCBvZiByYW5kb21uZXNzXG4gKi9cbmZ1bmN0aW9uIHJhbmRvczJEKHdpZHRoLCBoZWlnaHQsIHN0ZCkge1xuICAgIGNvbnN0IHJlc3VsdCA9IG5ldyBBcnJheShoZWlnaHQpO1xuICAgIGZvciAobGV0IHkgPSAwOyB5IDwgaGVpZ2h0OyB5KyspIHtcbiAgICAgICAgcmVzdWx0W3ldID0gcmFuZG9zKHdpZHRoLCBzdGQpO1xuICAgIH1cbiAgICByZXR1cm4gcmVzdWx0O1xufVxuLyoqXG4gKiBSZXR1cm5zIGEgM0QgdGVuc29yIG9mIGdpdmVuIHNpemUsIGZ1bGwgb2YgcmFuZG9tbmVzc1xuICovXG5mdW5jdGlvbiByYW5kb3MzRCh3aWR0aCwgaGVpZ2h0LCBkZXB0aCwgc3RkKSB7XG4gICAgY29uc3QgcmVzdWx0ID0gbmV3IEFycmF5KGRlcHRoKTtcbiAgICBmb3IgKGxldCB6ID0gMDsgeiA8IGRlcHRoOyB6KyspIHtcbiAgICAgICAgcmVzdWx0W3pdID0gcmFuZG9zMkQod2lkdGgsIGhlaWdodCwgc3RkKTtcbiAgICB9XG4gICAgcmV0dXJuIHJlc3VsdDtcbn1cblxuY29uc3QgZGVmYXVsdHMkNyA9IHtcbiAgICAuLi5iYXNlTGF5ZXJEZWZhdWx0U2V0dGluZ3MsXG4gICAgc3RkOiBudWxsLFxufTtcbmNsYXNzIFJhbmRvbSBleHRlbmRzIE1vZGVsIHtcbiAgICBjb25zdHJ1Y3RvcihzZXR0aW5ncykge1xuICAgICAgICBzdXBlcigpO1xuICAgICAgICB0aGlzLnNldHRpbmdzID0geyAuLi5kZWZhdWx0cyQ3LCAuLi5zZXR0aW5ncyB9O1xuICAgICAgICB0aGlzLnNldHVwUHJheGlzKCk7XG4gICAgICAgIHRoaXMudmFsaWRhdGUoKTtcbiAgICAgICAgaWYgKCF0aGlzLndlaWdodHMpIHtcbiAgICAgICAgICAgIHRoaXMud2VpZ2h0cyA9IHJhbmRvczJEKHRoaXMud2lkdGgsIHRoaXMuaGVpZ2h0LCBzZXR0aW5ncy5zdGQpO1xuICAgICAgICB9XG4gICAgICAgIGlmICghdGhpcy5kZWx0YXMpIHtcbiAgICAgICAgICAgIHRoaXMuZGVsdGFzID0gemVyb3MyRCh0aGlzLndpZHRoLCB0aGlzLmhlaWdodCk7XG4gICAgICAgIH1cbiAgICB9XG4gICAgcHJlZGljdCgpIHsgfVxuICAgIGNvbXBhcmUoKSB7IH1cbn1cbmZ1bmN0aW9uIHJhbmRvbShzZXR0aW5ncykge1xuICAgIHJldHVybiBuZXcgUmFuZG9tKHNldHRpbmdzKTtcbn1cblxuZnVuY3Rpb24gcHJlZGljdCQ3KHdlaWdodHMxLCB3ZWlnaHRzMikge1xuICAgIGxldCBzdW0gPSAwO1xuICAgIGZvciAobGV0IGkgPSAwOyBpIDwgdGhpcy5jb25zdGFudHMuc2l6ZTsgaSsrKSB7XG4gICAgICAgIHN1bSArPSB3ZWlnaHRzMVt0aGlzLnRocmVhZC55XVtpXSAqIHdlaWdodHMyW2ldW3RoaXMudGhyZWFkLnhdO1xuICAgIH1cbiAgICByZXR1cm4gc3VtO1xufVxuZnVuY3Rpb24gY29tcGFyZUZyb21YKGRlbHRhcywgaW5wdXREZWx0YXMsIGlucHV0V2VpZ2h0cykge1xuICAgIGxldCBzdW0gPSBpbnB1dERlbHRhc1t0aGlzLnRocmVhZC55XVt0aGlzLnRocmVhZC54XTtcbiAgICBmb3IgKGxldCBpID0gMDsgaSA8IHRoaXMuY29uc3RhbnRzLnNpemU7IGkrKykge1xuICAgICAgICBzdW0gKz0gZGVsdGFzW3RoaXMudGhyZWFkLnldW2ldICogaW5wdXRXZWlnaHRzW3RoaXMudGhyZWFkLnhdW2ldO1xuICAgIH1cbiAgICByZXR1cm4gc3VtO1xufVxuZnVuY3Rpb24gY29tcGFyZUZyb21ZKGRlbHRhcywgaW5wdXREZWx0YXMsIGlucHV0V2VpZ2h0cykge1xuICAgIGxldCBzdW0gPSBpbnB1dERlbHRhc1t0aGlzLnRocmVhZC55XVt0aGlzLnRocmVhZC54XTtcbiAgICBmb3IgKGxldCBpID0gMDsgaSA8IHRoaXMuY29uc3RhbnRzLnNpemU7IGkrKykge1xuICAgICAgICBzdW0gKz0gZGVsdGFzW2ldW3RoaXMudGhyZWFkLnhdICogaW5wdXRXZWlnaHRzW2ldW3RoaXMudGhyZWFkLnldO1xuICAgIH1cbiAgICByZXR1cm4gc3VtO1xufVxuY2xhc3MgTXVsdGlwbHkgZXh0ZW5kcyBPcGVyYXRvciB7XG4gICAgY29uc3RydWN0b3IoKSB7XG4gICAgICAgIHN1cGVyKC4uLmFyZ3VtZW50cyk7XG4gICAgICAgIHRoaXMuY29tcGFyZUtlcm5lbDEgPSBudWxsO1xuICAgICAgICB0aGlzLmNvbXBhcmVLZXJuZWwyID0gbnVsbDtcbiAgICB9XG4gICAgZ2V0IHdpZHRoKCkge1xuICAgICAgICByZXR1cm4gdGhpcy5pbnB1dExheWVyMi53aWR0aDtcbiAgICB9XG4gICAgc2V0IHdpZHRoKHdpZHRoKSB7XG4gICAgICAgIHRocm93IG5ldyBFcnJvcignQ2Fubm90IHNldCB3aWR0aCBvbiBNdWx0aXBseScpO1xuICAgIH1cbiAgICBnZXQgaGVpZ2h0KCkge1xuICAgICAgICByZXR1cm4gdGhpcy5pbnB1dExheWVyMS5oZWlnaHQ7XG4gICAgfVxuICAgIHNldCBoZWlnaHQoaGVpZ2h0KSB7XG4gICAgICAgIHRocm93IG5ldyBFcnJvcignQ2Fubm90IHNldCBoZWlnaHQgb24gTXVsdGlwbHknKTtcbiAgICB9XG4gICAgZ2V0IGRlcHRoKCkge1xuICAgICAgICByZXR1cm4gdGhpcy5pbnB1dExheWVyMS5kZXB0aDtcbiAgICB9XG4gICAgc2V0IGRlcHRoKGRlcHRoKSB7XG4gICAgICAgIHRocm93IG5ldyBFcnJvcignQ2Fubm90IHNldCBkZXB0aCBvbiBNdWx0aXBseScpO1xuICAgIH1cbiAgICB2YWxpZGF0ZSgpIHtcbiAgICAgICAgc3VwZXIudmFsaWRhdGUoKTtcbiAgICAgICAgaWYgKHRoaXMuaW5wdXRMYXllcjEud2lkdGggIT09IHRoaXMuaW5wdXRMYXllcjIuaGVpZ2h0KSB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoYExheWVyIHdpZHRoIG1pc21hdGNoIG9mICR7dGhpcy5pbnB1dExheWVyMS53aWR0aH0gYW5kICR7dGhpcy5pbnB1dExheWVyMi5oZWlnaHR9YCk7XG4gICAgICAgIH1cbiAgICB9XG4gICAgc2V0dXBLZXJuZWxzKCkge1xuICAgICAgICB0aGlzLnByZWRpY3RLZXJuZWwgPSBtYWtlS2VybmVsKHByZWRpY3QkNywge1xuICAgICAgICAgICAgb3V0cHV0OiBbdGhpcy53aWR0aCwgdGhpcy5oZWlnaHRdLFxuICAgICAgICAgICAgY29uc3RhbnRzOiB7XG4gICAgICAgICAgICAgICAgc2l6ZTogdGhpcy5pbnB1dExheWVyMi5oZWlnaHQsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgaW1tdXRhYmxlOiB0cnVlLFxuICAgICAgICB9KTtcbiAgICAgICAgdGhpcy5jb21wYXJlS2VybmVsMSA9IG1ha2VLZXJuZWwoY29tcGFyZUZyb21YLCB7XG4gICAgICAgICAgICBvdXRwdXQ6IFt0aGlzLmlucHV0TGF5ZXIxLndpZHRoLCB0aGlzLmlucHV0TGF5ZXIxLmhlaWdodF0sXG4gICAgICAgICAgICBjb25zdGFudHM6IHtcbiAgICAgICAgICAgICAgICBzaXplOiB0aGlzLmlucHV0TGF5ZXIyLndpZHRoLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIGltbXV0YWJsZTogdHJ1ZSxcbiAgICAgICAgfSk7XG4gICAgICAgIHRoaXMuY29tcGFyZUtlcm5lbDIgPSBtYWtlS2VybmVsKGNvbXBhcmVGcm9tWSwge1xuICAgICAgICAgICAgb3V0cHV0OiBbdGhpcy5pbnB1dExheWVyMi53aWR0aCwgdGhpcy5pbnB1dExheWVyMi5oZWlnaHRdLFxuICAgICAgICAgICAgY29uc3RhbnRzOiB7XG4gICAgICAgICAgICAgICAgc2l6ZTogdGhpcy5pbnB1dExheWVyMS5oZWlnaHQsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgaW1tdXRhYmxlOiB0cnVlLFxuICAgICAgICB9KTtcbiAgICB9XG4gICAgcmV1c2VLZXJuZWxzKGxheWVyKSB7XG4gICAgICAgIHN1cGVyLnJldXNlS2VybmVscyhsYXllcik7XG4gICAgICAgIHRoaXMuY29tcGFyZUtlcm5lbDEgPSBsYXllci5jb21wYXJlS2VybmVsMTtcbiAgICAgICAgdGhpcy5jb21wYXJlS2VybmVsMiA9IGxheWVyLmNvbXBhcmVLZXJuZWwyO1xuICAgIH1cbiAgICBwcmVkaWN0KCkge1xuICAgICAgICByZWxlYXNlKHRoaXMud2VpZ2h0cyk7XG4gICAgICAgIGlmICghdGhpcy5wcmVkaWN0S2VybmVsKVxuICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKCd0aGlzLnByZWRpY3RLZXJuZWwgaXMgbm90IHNldCcpO1xuICAgICAgICB0aGlzLndlaWdodHMgPSB0aGlzLnByZWRpY3RLZXJuZWwodGhpcy5pbnB1dExheWVyMS53ZWlnaHRzLCB0aGlzLmlucHV0TGF5ZXIyLndlaWdodHMpO1xuICAgICAgICBjbGVhcih0aGlzLmRlbHRhcyk7XG4gICAgfVxuICAgIGNvbXBhcmUoKSB7XG4gICAgICAgIGlmICghdGhpcy5jb21wYXJlS2VybmVsMSlcbiAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcigndGhpcy5jb21wYXJlS2VybmVsMSBub3Qgc2V0Jyk7XG4gICAgICAgIGlmICghdGhpcy5jb21wYXJlS2VybmVsMilcbiAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcigndGhpcy5jb21wYXJlS2VybmVsMiBub3Qgc2V0Jyk7XG4gICAgICAgIGNvbnN0IGlucHV0TGF5ZXIxRGVsdGFzID0gdGhpcy5pbnB1dExheWVyMS5kZWx0YXM7XG4gICAgICAgIGNvbnN0IGlucHV0TGF5ZXIyRGVsdGFzID0gdGhpcy5pbnB1dExheWVyMi5kZWx0YXM7XG4gICAgICAgIGNvbnN0IG5ld0RlbHRhczEgPSB0aGlzLmNvbXBhcmVLZXJuZWwxKHRoaXMuZGVsdGFzLCB0aGlzLmlucHV0TGF5ZXIxLmRlbHRhcywgdGhpcy5pbnB1dExheWVyMi53ZWlnaHRzKTtcbiAgICAgICAgY29uc3QgbmV3RGVsdGFzMiA9IHRoaXMuY29tcGFyZUtlcm5lbDIodGhpcy5kZWx0YXMsIHRoaXMuaW5wdXRMYXllcjIuZGVsdGFzLCB0aGlzLmlucHV0TGF5ZXIxLndlaWdodHMpO1xuICAgICAgICB0aGlzLmlucHV0TGF5ZXIyLmRlbHRhcyA9IG5ld0RlbHRhczI7XG4gICAgICAgIHRoaXMuaW5wdXRMYXllcjEuZGVsdGFzID0gbmV3RGVsdGFzMTtcbiAgICAgICAgcmVsZWFzZShpbnB1dExheWVyMURlbHRhcyk7XG4gICAgICAgIHJlbGVhc2UoaW5wdXRMYXllcjJEZWx0YXMpO1xuICAgIH1cbiAgICBzZXR1cFByYXhpcygpIHsgfVxuICAgIGxlYXJuKCkgeyB9XG4gICAgdG9KU09OKCkge1xuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgLi4uc3VwZXIudG9KU09OKCksXG4gICAgICAgICAgICB3aWR0aDogdGhpcy53aWR0aCxcbiAgICAgICAgICAgIGhlaWdodDogdGhpcy5oZWlnaHQsXG4gICAgICAgIH07XG4gICAgfVxufVxuZnVuY3Rpb24gbXVsdGlwbHkkMShpbnB1dExheWVyMSwgaW5wdXRMYXllcjIsIHNldHRpbmdzKSB7XG4gICAgcmV0dXJuIG5ldyBNdWx0aXBseShpbnB1dExheWVyMSwgaW5wdXRMYXllcjIsIHNldHRpbmdzKTtcbn1cblxuZnVuY3Rpb24gcHJlZGljdDJEJDQoaW5wdXRzKSB7XG4gICAgcmV0dXJuIDEgLyAoMSArIE1hdGguZXhwKC1pbnB1dHNbdGhpcy50aHJlYWQueV1bdGhpcy50aHJlYWQueF0pKTtcbn1cbmZ1bmN0aW9uIHByZWRpY3QzRCQ1KGlucHV0cykge1xuICAgIHJldHVybiAoMSAvICgxICsgTWF0aC5leHAoLWlucHV0c1t0aGlzLnRocmVhZC56XVt0aGlzLnRocmVhZC55XVt0aGlzLnRocmVhZC54XSkpKTtcbn1cbmZ1bmN0aW9uIGNvbXBhcmUyRCQ0KHdlaWdodHMsIGRlbHRhcykge1xuICAgIGNvbnN0IHdlaWdodCA9IHdlaWdodHNbdGhpcy50aHJlYWQueV1bdGhpcy50aHJlYWQueF07XG4gICAgY29uc3QgZGVsdGEgPSBkZWx0YXNbdGhpcy50aHJlYWQueV1bdGhpcy50aHJlYWQueF07XG4gICAgcmV0dXJuIHdlaWdodCAqICgxIC0gd2VpZ2h0KSAqIGRlbHRhO1xufVxuZnVuY3Rpb24gY29tcGFyZTNEJDQod2VpZ2h0cywgZGVsdGFzKSB7XG4gICAgY29uc3Qgd2VpZ2h0ID0gd2VpZ2h0c1t0aGlzLnRocmVhZC56XVt0aGlzLnRocmVhZC55XVt0aGlzLnRocmVhZC54XTtcbiAgICBjb25zdCBkZWx0YSA9IGRlbHRhc1t0aGlzLnRocmVhZC56XVt0aGlzLnRocmVhZC55XVt0aGlzLnRocmVhZC54XTtcbiAgICByZXR1cm4gd2VpZ2h0ICogKDEgLSB3ZWlnaHQpICogZGVsdGE7XG59XG5jbGFzcyBTaWdtb2lkIGV4dGVuZHMgQWN0aXZhdGlvbiB7XG4gICAgc2V0dXBLZXJuZWxzKCkge1xuICAgICAgICBpZiAodGhpcy5kZXB0aCA+IDApIHtcbiAgICAgICAgICAgIHRoaXMucHJlZGljdEtlcm5lbCA9IG1ha2VLZXJuZWwocHJlZGljdDNEJDUsIHtcbiAgICAgICAgICAgICAgICBvdXRwdXQ6IFt0aGlzLndpZHRoLCB0aGlzLmhlaWdodCwgdGhpcy5kZXB0aF0sXG4gICAgICAgICAgICAgICAgZnVuY3Rpb25zOiBbYWN0aXZhdGUkMl0sXG4gICAgICAgICAgICAgICAgaW1tdXRhYmxlOiB0cnVlLFxuICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICB0aGlzLmNvbXBhcmVLZXJuZWwgPSBtYWtlS2VybmVsKGNvbXBhcmUzRCQ0LCB7XG4gICAgICAgICAgICAgICAgb3V0cHV0OiBbdGhpcy53aWR0aCwgdGhpcy5oZWlnaHQsIHRoaXMuZGVwdGhdLFxuICAgICAgICAgICAgICAgIGZ1bmN0aW9uczogW21lYXN1cmUkMl0sXG4gICAgICAgICAgICAgICAgaW1tdXRhYmxlOiB0cnVlLFxuICAgICAgICAgICAgfSk7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICB0aGlzLnByZWRpY3RLZXJuZWwgPSBtYWtlS2VybmVsKHByZWRpY3QyRCQ0LCB7XG4gICAgICAgICAgICAgICAgb3V0cHV0OiBbdGhpcy53aWR0aCwgdGhpcy5oZWlnaHRdLFxuICAgICAgICAgICAgICAgIGZ1bmN0aW9uczogW2FjdGl2YXRlJDJdLFxuICAgICAgICAgICAgICAgIGltbXV0YWJsZTogdHJ1ZSxcbiAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgdGhpcy5jb21wYXJlS2VybmVsID0gbWFrZUtlcm5lbChjb21wYXJlMkQkNCwge1xuICAgICAgICAgICAgICAgIG91dHB1dDogW3RoaXMud2lkdGgsIHRoaXMuaGVpZ2h0XSxcbiAgICAgICAgICAgICAgICBmdW5jdGlvbnM6IFttZWFzdXJlJDJdLFxuICAgICAgICAgICAgICAgIGltbXV0YWJsZTogdHJ1ZSxcbiAgICAgICAgICAgIH0pO1xuICAgICAgICB9XG4gICAgfVxuICAgIHByZWRpY3QoKSB7XG4gICAgICAgIHJlbGVhc2UodGhpcy53ZWlnaHRzKTtcbiAgICAgICAgdGhpcy53ZWlnaHRzID0gdGhpcy5wcmVkaWN0S2VybmVsKHRoaXMuaW5wdXRMYXllci53ZWlnaHRzKTtcbiAgICAgICAgY2xlYXIodGhpcy5kZWx0YXMpO1xuICAgIH1cbiAgICBjb21wYXJlKCkge1xuICAgICAgICByZWxlYXNlKHRoaXMuaW5wdXRMYXllci5kZWx0YXMpO1xuICAgICAgICB0aGlzLmlucHV0TGF5ZXIuZGVsdGFzID0gdGhpcy5jb21wYXJlS2VybmVsKHRoaXMud2VpZ2h0cywgdGhpcy5kZWx0YXMpO1xuICAgIH1cbn1cbmZ1bmN0aW9uIHNpZ21vaWQkMShpbnB1dExheWVyLCBzZXR0aW5ncykge1xuICAgIHJldHVybiBuZXcgU2lnbW9pZChpbnB1dExheWVyLCBzZXR0aW5ncyk7XG59XG5cbmZ1bmN0aW9uIGFydGh1ckZlZWRGb3J3YXJkKHNldHRpbmdzLCBpbnB1dExheWVyKSB7XG4gICAgY29uc3QgeyBoZWlnaHQgfSA9IHNldHRpbmdzO1xuICAgIGZ1bmN0aW9uIGluaXRXZWlnaHRzUHJheGlzKGxheWVyVGVtcGxhdGUsIHNldHRpbmdzKSB7XG4gICAgICAgIGNvbnN0IHByYXhpcyA9IGFydGh1ckRldmlhdGlvbldlaWdodHMobGF5ZXJUZW1wbGF0ZSwgc2V0dGluZ3MpO1xuICAgICAgICBwcmF4aXMuc2V0dXBLZXJuZWxzKCk7XG4gICAgICAgIHJldHVybiBwcmF4aXM7XG4gICAgfVxuICAgIGZ1bmN0aW9uIGluaXRCaWFzZXNQcmF4aXMobGF5ZXJUZW1wbGF0ZSwgc2V0dGluZ3MpIHtcbiAgICAgICAgY29uc3QgcHJheGlzID0gYXJ0aHVyRGV2aWF0aW9uQmlhc2VzKGxheWVyVGVtcGxhdGUsIHNldHRpbmdzKTtcbiAgICAgICAgcHJheGlzLnNldHVwS2VybmVscygpO1xuICAgICAgICByZXR1cm4gcHJheGlzO1xuICAgIH1cbiAgICBjb25zdCB3ZWlnaHRzTGF5ZXIgPSByYW5kb20oe1xuICAgICAgICBpZDogJ3dlaWdodHMnLFxuICAgICAgICBoZWlnaHQsXG4gICAgICAgIHdpZHRoOiBpbnB1dExheWVyLmhlaWdodCxcbiAgICAgICAgaW5pdFByYXhpczogaW5pdFdlaWdodHNQcmF4aXMsXG4gICAgfSk7XG4gICAgY29uc3QgYmlhc2VzTGF5ZXIgPSByYW5kb20oe1xuICAgICAgICBpZDogJ2JpYXNlcycsXG4gICAgICAgIGhlaWdodCxcbiAgICAgICAgaW5pdFByYXhpczogaW5pdEJpYXNlc1ByYXhpcyxcbiAgICB9KTtcbiAgICBjb25zdCBtdWx0aXBseUxheWVyID0gbXVsdGlwbHkkMSh3ZWlnaHRzTGF5ZXIsIGlucHV0TGF5ZXIpO1xuICAgIGNvbnN0IGFkZExheWVyID0gYWRkJDEobXVsdGlwbHlMYXllciwgYmlhc2VzTGF5ZXIpO1xuICAgIGNvbnN0IHNpZ21vaWRMYXllciA9IHNpZ21vaWQkMShhZGRMYXllcik7XG4gICAgY29uc3Qgd2VpZ2h0c1ByYXhpcyA9IHdlaWdodHNMYXllci5wcmF4aXM7XG4gICAgd2VpZ2h0c1ByYXhpcy53ZWlnaHRzTGF5ZXIgPSB3ZWlnaHRzTGF5ZXI7XG4gICAgd2VpZ2h0c1ByYXhpcy5pbmNvbWluZ0xheWVyID0gaW5wdXRMYXllcjtcbiAgICB3ZWlnaHRzUHJheGlzLmRlbHRhTGF5ZXIgPSBzaWdtb2lkTGF5ZXI7XG4gICAgcmV0dXJuIHNpZ21vaWRMYXllcjtcbn1cblxuZnVuY3Rpb24gZ2V0U3RyaWRlKHNldHRpbmdzLCBkZWZhdWx0cykge1xuICAgIGlmICh0eXBlb2Ygc2V0dGluZ3Muc3RyaWRlID09PSAnbnVtYmVyJykge1xuICAgICAgICByZXR1cm4geyBzdHJpZGVYOiBzZXR0aW5ncy5zdHJpZGUsIHN0cmlkZVk6IHNldHRpbmdzLnN0cmlkZSB9O1xuICAgIH1cbiAgICBlbHNlIHtcbiAgICAgICAgbGV0IHN0cmlkZVggPSBkZWZhdWx0cy5zdHJpZGU7XG4gICAgICAgIGxldCBzdHJpZGVZID0gZGVmYXVsdHMuc3RyaWRlO1xuICAgICAgICBpZiAodHlwZW9mIHNldHRpbmdzLnN0cmlkZVggPT09ICdudW1iZXInKSB7XG4gICAgICAgICAgICBzdHJpZGVYID0gc2V0dGluZ3Muc3RyaWRlWDtcbiAgICAgICAgfVxuICAgICAgICBpZiAodHlwZW9mIHNldHRpbmdzLnN0cmlkZVkgPT09ICdudW1iZXInKSB7XG4gICAgICAgICAgICBzdHJpZGVZID0gc2V0dGluZ3Muc3RyaWRlWTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4geyBzdHJpZGVYLCBzdHJpZGVZIH07XG4gICAgfVxufVxuZnVuY3Rpb24gZ2V0UGFkZGluZyhzZXR0aW5ncywgZGVmYXVsdHMpIHtcbiAgICBpZiAodHlwZW9mIHNldHRpbmdzLnBhZGRpbmcgPT09ICdudW1iZXInKSB7XG4gICAgICAgIHJldHVybiB7IHBhZGRpbmdYOiBzZXR0aW5ncy5wYWRkaW5nLCBwYWRkaW5nWTogc2V0dGluZ3MucGFkZGluZyB9O1xuICAgIH1cbiAgICBlbHNlIHtcbiAgICAgICAgbGV0IHBhZGRpbmdYID0gZGVmYXVsdHMucGFkZGluZztcbiAgICAgICAgbGV0IHBhZGRpbmdZID0gZGVmYXVsdHMucGFkZGluZztcbiAgICAgICAgaWYgKHR5cGVvZiBzZXR0aW5ncy5wYWRkaW5nWCA9PT0gJ251bWJlcicpIHtcbiAgICAgICAgICAgIHBhZGRpbmdYID0gc2V0dGluZ3MucGFkZGluZ1g7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKHR5cGVvZiBzZXR0aW5ncy5wYWRkaW5nWSA9PT0gJ251bWJlcicpIHtcbiAgICAgICAgICAgIHBhZGRpbmdZID0gc2V0dGluZ3MucGFkZGluZ1k7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHsgcGFkZGluZ1gsIHBhZGRpbmdZIH07XG4gICAgfVxufVxuXG4vKipcbiAqIFJldHVybnMgYW4gYXJyYXkgb2YgYSBnaXZlbiBzaXplIHdpdGggZWFjaCBlbGVtZW50IGZpbGxlZCB3aXRoIGEgc2luZ2xlIHZhbHVlXG4gKi9cbmZ1bmN0aW9uIHZhbHVlcyhzaXplLCB2YWx1ZSkge1xuICAgIHJldHVybiBuZXcgRmxvYXQzMkFycmF5KHNpemUpLmZpbGwodmFsdWUpO1xufVxuXG5mdW5jdGlvbiBwcmVkaWN0JDYoaW5wdXRzLCBmaWx0ZXJzLCBiaWFzZXMpIHtcbiAgICBjb25zdCBzdGFydEZpbHRlclggPSB0aGlzLmNvbnN0YW50cy5wYWRkaW5nWCAtIHRoaXMudGhyZWFkLnggKiB0aGlzLmNvbnN0YW50cy5zdHJpZGVYO1xuICAgIGNvbnN0IHN0YXJ0SW5wdXRYID0gdGhpcy50aHJlYWQueCAqIHRoaXMuY29uc3RhbnRzLnN0cmlkZVggLSB0aGlzLmNvbnN0YW50cy5wYWRkaW5nWDtcbiAgICBjb25zdCBlbmRGaWx0ZXJYID0gTWF0aC5taW4odGhpcy5jb25zdGFudHMuZmlsdGVyV2lkdGgsIHN0YXJ0RmlsdGVyWCArIHRoaXMuY29uc3RhbnRzLmlucHV0V2lkdGgpO1xuICAgIGNvbnN0IHN0YXJ0RmlsdGVyWSA9IHRoaXMuY29uc3RhbnRzLnBhZGRpbmdZIC0gdGhpcy50aHJlYWQueSAqIHRoaXMuY29uc3RhbnRzLnN0cmlkZVk7XG4gICAgY29uc3Qgc3RhcnRJbnB1dFkgPSB0aGlzLnRocmVhZC55ICogdGhpcy5jb25zdGFudHMuc3RyaWRlWSAtIHRoaXMuY29uc3RhbnRzLnBhZGRpbmdZO1xuICAgIGNvbnN0IGVuZEZpbHRlclkgPSBNYXRoLm1pbih0aGlzLmNvbnN0YW50cy5maWx0ZXJIZWlnaHQsIHN0YXJ0RmlsdGVyWSArIHRoaXMuY29uc3RhbnRzLmlucHV0SGVpZ2h0KTtcbiAgICBsZXQgc3VtID0gMDtcbiAgICBmb3IgKGxldCB6ID0gMDsgeiA8IHRoaXMuY29uc3RhbnRzLmlucHV0RGVwdGg7IHorKykge1xuICAgICAgICBmb3IgKGxldCBmaWx0ZXJZID0gTWF0aC5tYXgoMCwgc3RhcnRGaWx0ZXJZKSwgaW5wdXRZID0gTWF0aC5tYXgoMCwgc3RhcnRJbnB1dFkpOyBmaWx0ZXJZIDwgZW5kRmlsdGVyWTsgZmlsdGVyWSsrLCBpbnB1dFkrKykge1xuICAgICAgICAgICAgZm9yIChsZXQgZmlsdGVyWCA9IE1hdGgubWF4KDAsIHN0YXJ0RmlsdGVyWCksIGlucHV0WCA9IE1hdGgubWF4KDAsIHN0YXJ0SW5wdXRYKTsgZmlsdGVyWCA8IGVuZEZpbHRlclg7IGZpbHRlclgrKywgaW5wdXRYKyspIHtcbiAgICAgICAgICAgICAgICBzdW0gKz0gZmlsdGVyc1t6XVtmaWx0ZXJZXVtmaWx0ZXJYXSAqIGlucHV0c1t6XVtpbnB1dFldW2lucHV0WF07XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9XG4gICAgcmV0dXJuIHN1bSArIGJpYXNlc1t0aGlzLnRocmVhZC56XTtcbn1cbmZ1bmN0aW9uIGNvbXBhcmVGaWx0ZXJEZWx0YXMkMShmaWx0ZXJEZWx0YXMsIGlucHV0cywgZGVsdGFzKSB7XG4gICAgY29uc3Qgc3RhcnREZWx0YVggPSBNYXRoLm1heCgwLCBNYXRoLmNlaWwoKHRoaXMuY29uc3RhbnRzLnBhZGRpbmdYIC0gdGhpcy50aHJlYWQueCkgLyB0aGlzLmNvbnN0YW50cy5zdHJpZGVYKSk7XG4gICAgY29uc3Qgc3RhcnRJbnB1dFggPSBzdGFydERlbHRhWCAqIHRoaXMuY29uc3RhbnRzLnN0cmlkZVggK1xuICAgICAgICB0aGlzLnRocmVhZC54IC1cbiAgICAgICAgdGhpcy5jb25zdGFudHMucGFkZGluZ1g7XG4gICAgY29uc3QgZW5kRGVsdGFYID0gTWF0aC5taW4odGhpcy5jb25zdGFudHMuZGVsdGFXaWR0aCwgTWF0aC5mbG9vcigodGhpcy5jb25zdGFudHMuaW5wdXRXaWR0aCAtXG4gICAgICAgIDEgLVxuICAgICAgICB0aGlzLnRocmVhZC54ICtcbiAgICAgICAgdGhpcy5jb25zdGFudHMucGFkZGluZ1gpIC9cbiAgICAgICAgdGhpcy5jb25zdGFudHMuc3RyaWRlWCkgKyAxKTtcbiAgICBjb25zdCBzdGFydERlbHRhWSA9IE1hdGgubWF4KDAsIE1hdGguY2VpbCgodGhpcy5jb25zdGFudHMucGFkZGluZ1kgLSB0aGlzLnRocmVhZC55KSAvIHRoaXMuY29uc3RhbnRzLnN0cmlkZVkpKTtcbiAgICBjb25zdCBzdGFydElucHV0WSA9IHN0YXJ0RGVsdGFZICogdGhpcy5jb25zdGFudHMuc3RyaWRlWSArXG4gICAgICAgIHRoaXMudGhyZWFkLnkgLVxuICAgICAgICB0aGlzLmNvbnN0YW50cy5wYWRkaW5nWTtcbiAgICBjb25zdCBlbmREZWx0YVkgPSBNYXRoLm1pbih0aGlzLmNvbnN0YW50cy5kZWx0YUhlaWdodCwgTWF0aC5mbG9vcigodGhpcy5jb25zdGFudHMuaW5wdXRIZWlnaHQgLVxuICAgICAgICAxIC1cbiAgICAgICAgdGhpcy50aHJlYWQueSArXG4gICAgICAgIHRoaXMuY29uc3RhbnRzLnBhZGRpbmdZKSAvXG4gICAgICAgIHRoaXMuY29uc3RhbnRzLnN0cmlkZVkpICsgMSk7XG4gICAgbGV0IHN1bSA9IGZpbHRlckRlbHRhc1t0aGlzLnRocmVhZC56XVt0aGlzLnRocmVhZC55XVt0aGlzLnRocmVhZC54XTtcbiAgICBmb3IgKGxldCBkZWx0YVkgPSBzdGFydERlbHRhWSwgaW5wdXRZID0gc3RhcnRJbnB1dFk7IGRlbHRhWSA8IGVuZERlbHRhWTsgZGVsdGFZKyssIGlucHV0WSArPSB0aGlzLmNvbnN0YW50cy5zdHJpZGVZKSB7XG4gICAgICAgIGZvciAobGV0IGRlbHRhWCA9IHN0YXJ0RGVsdGFYLCBpbnB1dFggPSBzdGFydElucHV0WDsgZGVsdGFYIDwgZW5kRGVsdGFYOyBkZWx0YVgrKywgaW5wdXRYICs9IHRoaXMuY29uc3RhbnRzLnN0cmlkZVgpIHtcbiAgICAgICAgICAgIHN1bSArPVxuICAgICAgICAgICAgICAgIGlucHV0c1t0aGlzLnRocmVhZC56XVtpbnB1dFldW2lucHV0WF0gKlxuICAgICAgICAgICAgICAgICAgICBkZWx0YXNbdGhpcy5jb25zdGFudHMuZGVsdGFaXVtkZWx0YVldW2RlbHRhWF07XG4gICAgICAgIH1cbiAgICB9XG4gICAgcmV0dXJuIHN1bTtcbn1cbmZ1bmN0aW9uIGNvbXBhcmVJbnB1dERlbHRhcyQxKGlucHV0RGVsdGFzLCBmaWx0ZXJzLCBkZWx0YXMpIHtcbiAgICBjb25zdCB4ID0gdGhpcy50aHJlYWQueCArIHRoaXMuY29uc3RhbnRzLnBhZGRpbmdYO1xuICAgIGNvbnN0IHN0YXJ0RGVsdGFYID0geCA8IHRoaXMuY29uc3RhbnRzLmZpbHRlcldpZHRoXG4gICAgICAgID8gMFxuICAgICAgICA6IE1hdGguZmxvb3IoKHggLSB0aGlzLmNvbnN0YW50cy5maWx0ZXJXaWR0aCArIHRoaXMuY29uc3RhbnRzLnN0cmlkZVgpIC9cbiAgICAgICAgICAgIHRoaXMuY29uc3RhbnRzLnN0cmlkZVgpO1xuICAgIGNvbnN0IHN0YXJ0RmlsdGVyWCA9IHggLSBzdGFydERlbHRhWCAqIHRoaXMuY29uc3RhbnRzLnN0cmlkZVg7XG4gICAgY29uc3QgZW5kRGVsdGFYID0gTWF0aC5taW4oc3RhcnREZWx0YVggKyBNYXRoLmZsb29yKHN0YXJ0RmlsdGVyWCAvIHRoaXMuY29uc3RhbnRzLnN0cmlkZVgpICsgMSwgdGhpcy5jb25zdGFudHMuZGVsdGFXaWR0aCk7XG4gICAgY29uc3QgeSA9IHRoaXMudGhyZWFkLnkgKyB0aGlzLmNvbnN0YW50cy5wYWRkaW5nWTtcbiAgICBjb25zdCBzdGFydERlbHRhWSA9IHkgPCB0aGlzLmNvbnN0YW50cy5maWx0ZXJIZWlnaHRcbiAgICAgICAgPyAwXG4gICAgICAgIDogTWF0aC5mbG9vcigoeSAtIHRoaXMuY29uc3RhbnRzLmZpbHRlckhlaWdodCArIHRoaXMuY29uc3RhbnRzLnN0cmlkZVkpIC9cbiAgICAgICAgICAgIHRoaXMuY29uc3RhbnRzLnN0cmlkZVkpO1xuICAgIGNvbnN0IHN0YXJ0RmlsdGVyWSA9IHkgLSBzdGFydERlbHRhWSAqIHRoaXMuY29uc3RhbnRzLnN0cmlkZVk7XG4gICAgY29uc3QgZW5kRGVsdGFZID0gTWF0aC5taW4oc3RhcnREZWx0YVkgKyBNYXRoLmZsb29yKHN0YXJ0RmlsdGVyWSAvIHRoaXMuY29uc3RhbnRzLnN0cmlkZVkpICsgMSwgdGhpcy5jb25zdGFudHMuZGVsdGFIZWlnaHQpO1xuICAgIGxldCBzdW0gPSBpbnB1dERlbHRhc1t0aGlzLnRocmVhZC56XVt0aGlzLnRocmVhZC55XVt0aGlzLnRocmVhZC54XTtcbiAgICBsZXQgZGVsdGFZID0gc3RhcnREZWx0YVk7XG4gICAgZm9yIChsZXQgZmlsdGVyWSA9IHN0YXJ0RmlsdGVyWTsgZGVsdGFZIDwgZW5kRGVsdGFZOyBmaWx0ZXJZIC09IHRoaXMuY29uc3RhbnRzLnN0cmlkZVksIGRlbHRhWSsrKSB7XG4gICAgICAgIGxldCBkZWx0YVggPSBzdGFydERlbHRhWDtcbiAgICAgICAgZm9yIChsZXQgZmlsdGVyWCA9IHN0YXJ0RmlsdGVyWDsgZGVsdGFYIDwgZW5kRGVsdGFYOyBmaWx0ZXJYIC09IHRoaXMuY29uc3RhbnRzLnN0cmlkZVgsIGRlbHRhWCsrKSB7XG4gICAgICAgICAgICBzdW0gKz1cbiAgICAgICAgICAgICAgICBmaWx0ZXJzW3RoaXMudGhyZWFkLnpdW2ZpbHRlclldW2ZpbHRlclhdICpcbiAgICAgICAgICAgICAgICAgICAgZGVsdGFzW3RoaXMuY29uc3RhbnRzLmRlbHRhWl1bZGVsdGFZXVtkZWx0YVhdO1xuICAgICAgICB9XG4gICAgfVxuICAgIHJldHVybiBzdW07XG59XG5mdW5jdGlvbiBjb21wYXJlQmlhc2VzJDEoYmlhc0RlbHRhcywgZGVsdGFzKSB7XG4gICAgbGV0IHN1bSA9IDA7XG4gICAgZm9yIChsZXQgeSA9IDA7IHkgPCB0aGlzLmNvbnN0YW50cy5kZWx0YUhlaWdodDsgeSsrKSB7XG4gICAgICAgIGZvciAobGV0IHggPSAwOyB4IDwgdGhpcy5jb25zdGFudHMuZGVsdGFXaWR0aDsgeCsrKSB7XG4gICAgICAgICAgICBzdW0gKz0gZGVsdGFzW3RoaXMudGhyZWFkLnpdW3ldW3hdO1xuICAgICAgICB9XG4gICAgfVxuICAgIHJldHVybiBiaWFzRGVsdGFzW3RoaXMudGhyZWFkLnpdW3RoaXMudGhyZWFkLnldW3RoaXMudGhyZWFkLnhdICsgc3VtO1xufVxuY29uc3QgZGVmYXVsdHMkNiA9IHtcbiAgICBzdHJpZGU6IDAsXG4gICAgcGFkZGluZzogMCxcbiAgICBiaWFzOiAwLjEsXG4gICAgZmlsdGVyQ291bnQ6IDEsXG4gICAgZmlsdGVyV2lkdGg6IDAsXG4gICAgZmlsdGVySGVpZ2h0OiAwLFxufTtcbmNsYXNzIENvbnZvbHV0aW9uIGV4dGVuZHMgRmlsdGVyIHtcbiAgICBjb25zdHJ1Y3RvcihzZXR0aW5ncywgaW5wdXRMYXllcikge1xuICAgICAgICB2YXIgX2EsIF9iLCBfYztcbiAgICAgICAgc3VwZXIoc2V0dGluZ3MsIGlucHV0TGF5ZXIpO1xuICAgICAgICB0aGlzLmNvbXBhcmVGaWx0ZXJEZWx0YXNLZXJuZWwgPSBudWxsO1xuICAgICAgICB0aGlzLmNvbXBhcmVJbnB1dERlbHRhc0tlcm5lbCA9IG51bGw7XG4gICAgICAgIHRoaXMuY29tcGFyZUJpYXNlc0tlcm5lbCA9IG51bGw7XG4gICAgICAgIHRoaXMuc2V0dGluZ3MgPSB7XG4gICAgICAgICAgICAuLi5kZWZhdWx0cyQ2LFxuICAgICAgICAgICAgLi4uc2V0dGluZ3MsXG4gICAgICAgICAgICAuLi5nZXRQYWRkaW5nKHNldHRpbmdzLCBkZWZhdWx0cyQ2KSxcbiAgICAgICAgICAgIC4uLmdldFN0cmlkZShzZXR0aW5ncywgZGVmYXVsdHMkNiksXG4gICAgICAgIH07XG4gICAgICAgIHRoaXMud2VpZ2h0cyA9IChfYSA9IHNldHRpbmdzLndlaWdodHMpICE9PSBudWxsICYmIF9hICE9PSB2b2lkIDAgPyBfYSA6IHJhbmRvczNEKHRoaXMud2lkdGgsIHRoaXMuaGVpZ2h0LCB0aGlzLmRlcHRoKTtcbiAgICAgICAgdGhpcy5kZWx0YXMgPSB6ZXJvczNEKHRoaXMud2lkdGgsIHRoaXMuaGVpZ2h0LCB0aGlzLmRlcHRoKTtcbiAgICAgICAgdGhpcy5iaWFzZXMgPSB2YWx1ZXModGhpcy5kZXB0aCwgdGhpcy5iaWFzKTtcbiAgICAgICAgdGhpcy5iaWFzRGVsdGFzID0gKF9iID0gc2V0dGluZ3MuYmlhc0RlbHRhcykgIT09IG51bGwgJiYgX2IgIT09IHZvaWQgMCA/IF9iIDogcmFuZG9zKHRoaXMuZGVwdGgpO1xuICAgICAgICB0aGlzLmZpbHRlcnMgPSAoX2MgPSBzZXR0aW5ncy5maWx0ZXJzKSAhPT0gbnVsbCAmJiBfYyAhPT0gdm9pZCAwID8gX2MgOiByYW5kb3MzRCh0aGlzLmZpbHRlcldpZHRoLCB0aGlzLmZpbHRlckhlaWdodCwgdGhpcy5maWx0ZXJDb3VudCk7XG4gICAgICAgIHRoaXMuZmlsdGVyRGVsdGFzID0gemVyb3MzRCh0aGlzLmZpbHRlcldpZHRoLCB0aGlzLmZpbHRlckhlaWdodCwgdGhpcy5maWx0ZXJDb3VudCk7XG4gICAgICAgIHRoaXMudmFsaWRhdGUoKTtcbiAgICB9XG4gICAgZ2V0IHN0cmlkZVgoKSB7XG4gICAgICAgIHJldHVybiB0aGlzLnNldHRpbmdzLnN0cmlkZVg7XG4gICAgfVxuICAgIGdldCBzdHJpZGVZKCkge1xuICAgICAgICByZXR1cm4gdGhpcy5zZXR0aW5ncy5zdHJpZGVZO1xuICAgIH1cbiAgICBnZXQgcGFkZGluZ1goKSB7XG4gICAgICAgIHJldHVybiB0aGlzLnNldHRpbmdzLnBhZGRpbmdYO1xuICAgIH1cbiAgICBnZXQgcGFkZGluZ1koKSB7XG4gICAgICAgIHJldHVybiB0aGlzLnNldHRpbmdzLnBhZGRpbmdYO1xuICAgIH1cbiAgICBnZXQgd2lkdGgoKSB7XG4gICAgICAgIHJldHVybiBNYXRoLmZsb29yKCh0aGlzLmlucHV0TGF5ZXIud2lkdGggKyB0aGlzLnBhZGRpbmdYICogMiAtIHRoaXMuZmlsdGVyV2lkdGgpIC9cbiAgICAgICAgICAgIHRoaXMuc3RyaWRlWCArXG4gICAgICAgICAgICAxKTtcbiAgICB9XG4gICAgZ2V0IGhlaWdodCgpIHtcbiAgICAgICAgcmV0dXJuIE1hdGguZmxvb3IoKHRoaXMuaW5wdXRMYXllci5oZWlnaHQgKyB0aGlzLnBhZGRpbmdZICogMiAtIHRoaXMuZmlsdGVySGVpZ2h0KSAvXG4gICAgICAgICAgICB0aGlzLnN0cmlkZVkgK1xuICAgICAgICAgICAgMSk7XG4gICAgfVxuICAgIGdldCBiaWFzKCkge1xuICAgICAgICByZXR1cm4gdGhpcy5zZXR0aW5ncy5iaWFzO1xuICAgIH1cbiAgICBnZXQgZGVwdGgoKSB7XG4gICAgICAgIHJldHVybiB0aGlzLmZpbHRlckNvdW50O1xuICAgIH1cbiAgICBnZXQgYmlhc2VzKCkge1xuICAgICAgICByZXR1cm4gdGhpcy5zZXR0aW5ncy5iaWFzZXM7XG4gICAgfVxuICAgIHNldCBiaWFzZXMoYmlhc2VzKSB7XG4gICAgICAgIHRoaXMuc2V0dGluZ3MuYmlhc2VzID0gYmlhc2VzO1xuICAgIH1cbiAgICBnZXQgYmlhc0RlbHRhcygpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuc2V0dGluZ3MuYmlhc0RlbHRhcztcbiAgICB9XG4gICAgc2V0IGJpYXNEZWx0YXMod2VpZ2h0cykge1xuICAgICAgICB0aGlzLnNldHRpbmdzLmJpYXNEZWx0YXMgPSB3ZWlnaHRzO1xuICAgIH1cbiAgICBnZXQgZmlsdGVycygpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuc2V0dGluZ3MuZmlsdGVycztcbiAgICB9XG4gICAgc2V0IGZpbHRlcnMoZmlsdGVycykge1xuICAgICAgICB0aGlzLnNldHRpbmdzLmZpbHRlcnMgPSBmaWx0ZXJzO1xuICAgIH1cbiAgICBnZXQgZmlsdGVyRGVsdGFzKCkge1xuICAgICAgICByZXR1cm4gdGhpcy5zZXR0aW5ncy5maWx0ZXJEZWx0YXM7XG4gICAgfVxuICAgIHNldCBmaWx0ZXJEZWx0YXMoZmlsdGVyRGVsdGFzKSB7XG4gICAgICAgIHRoaXMuc2V0dGluZ3MuZmlsdGVyRGVsdGFzID0gZmlsdGVyRGVsdGFzO1xuICAgIH1cbiAgICBzZXR1cEtlcm5lbHMoKSB7XG4gICAgICAgIHRoaXMucHJlZGljdEtlcm5lbCA9IG1ha2VLZXJuZWwocHJlZGljdCQ2LCB7XG4gICAgICAgICAgICBjb25zdGFudHM6IHtcbiAgICAgICAgICAgICAgICBpbnB1dFdpZHRoOiB0aGlzLmlucHV0TGF5ZXIud2lkdGgsXG4gICAgICAgICAgICAgICAgaW5wdXRIZWlnaHQ6IHRoaXMuaW5wdXRMYXllci5oZWlnaHQsXG4gICAgICAgICAgICAgICAgaW5wdXREZXB0aDogdGhpcy5pbnB1dExheWVyLmRlcHRoLFxuICAgICAgICAgICAgICAgIHN0cmlkZVg6IHRoaXMuc3RyaWRlWCxcbiAgICAgICAgICAgICAgICBzdHJpZGVZOiB0aGlzLnN0cmlkZVksXG4gICAgICAgICAgICAgICAgcGFkZGluZ1g6IHRoaXMucGFkZGluZ1gsXG4gICAgICAgICAgICAgICAgcGFkZGluZ1k6IHRoaXMucGFkZGluZ1ksXG4gICAgICAgICAgICAgICAgZmlsdGVyV2lkdGg6IHRoaXMuZmlsdGVyV2lkdGgsXG4gICAgICAgICAgICAgICAgZmlsdGVySGVpZ2h0OiB0aGlzLmZpbHRlckhlaWdodCxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBvdXRwdXQ6IFt0aGlzLndpZHRoLCB0aGlzLmhlaWdodCwgdGhpcy5kZXB0aF0sXG4gICAgICAgICAgICBpbW11dGFibGU6IHRydWUsXG4gICAgICAgIH0pO1xuICAgICAgICB0aGlzLmNvbXBhcmVGaWx0ZXJEZWx0YXNLZXJuZWwgPSBtYWtlS2VybmVsKGNvbXBhcmVGaWx0ZXJEZWx0YXMkMSwge1xuICAgICAgICAgICAgY29uc3RhbnRzOiB7XG4gICAgICAgICAgICAgICAgZGVsdGFzV2lkdGg6IHRoaXMud2lkdGgsXG4gICAgICAgICAgICAgICAgZGVsdGFzSGVpZ2h0OiB0aGlzLmhlaWdodCxcbiAgICAgICAgICAgICAgICBkZWx0YXNEZXB0aDogdGhpcy5kZXB0aCxcbiAgICAgICAgICAgICAgICBpbnB1dFdpZHRoOiB0aGlzLmlucHV0TGF5ZXIud2lkdGgsXG4gICAgICAgICAgICAgICAgaW5wdXRIZWlnaHQ6IHRoaXMuaW5wdXRMYXllci5oZWlnaHQsXG4gICAgICAgICAgICAgICAgaW5wdXREZXB0aDogdGhpcy5pbnB1dExheWVyLmRlcHRoLFxuICAgICAgICAgICAgICAgIHN0cmlkZVg6IHRoaXMuc3RyaWRlWCxcbiAgICAgICAgICAgICAgICBzdHJpZGVZOiB0aGlzLnN0cmlkZVksXG4gICAgICAgICAgICAgICAgcGFkZGluZ1g6IHRoaXMucGFkZGluZ1gsXG4gICAgICAgICAgICAgICAgcGFkZGluZ1k6IHRoaXMucGFkZGluZ1ksXG4gICAgICAgICAgICAgICAgZmlsdGVyV2lkdGg6IHRoaXMuZmlsdGVyV2lkdGgsXG4gICAgICAgICAgICAgICAgZmlsdGVySGVpZ2h0OiB0aGlzLmZpbHRlckhlaWdodCxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBvdXRwdXQ6IFt0aGlzLndpZHRoLCB0aGlzLmhlaWdodCwgdGhpcy5kZXB0aF0sXG4gICAgICAgICAgICBpbW11dGFibGU6IHRydWUsXG4gICAgICAgIH0pO1xuICAgICAgICB0aGlzLmNvbXBhcmVJbnB1dERlbHRhc0tlcm5lbCA9IG1ha2VLZXJuZWwoY29tcGFyZUlucHV0RGVsdGFzJDEsIHtcbiAgICAgICAgICAgIGNvbnN0YW50czoge1xuICAgICAgICAgICAgICAgIGZpbHRlckNvdW50OiB0aGlzLmZpbHRlckNvdW50LFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIG91dHB1dDogW1xuICAgICAgICAgICAgICAgIHRoaXMuaW5wdXRMYXllci53aWR0aCxcbiAgICAgICAgICAgICAgICB0aGlzLmlucHV0TGF5ZXIuaGVpZ2h0LFxuICAgICAgICAgICAgICAgIHRoaXMuaW5wdXRMYXllci5kZXB0aCxcbiAgICAgICAgICAgIF0sXG4gICAgICAgICAgICBpbW11dGFibGU6IHRydWUsXG4gICAgICAgIH0pO1xuICAgICAgICB0aGlzLmNvbXBhcmVCaWFzZXNLZXJuZWwgPSBtYWtlS2VybmVsKGNvbXBhcmVCaWFzZXMkMSwge1xuICAgICAgICAgICAgb3V0cHV0OiBbMSwgMSwgdGhpcy5kZXB0aF0sXG4gICAgICAgICAgICBjb25zdGFudHM6IHtcbiAgICAgICAgICAgICAgICBkZWx0YVdpZHRoOiB0aGlzLndpZHRoLFxuICAgICAgICAgICAgICAgIGRlbHRhSGVpZ2h0OiB0aGlzLmhlaWdodCxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBpbW11dGFibGU6IHRydWUsXG4gICAgICAgIH0pO1xuICAgIH1cbiAgICBwcmVkaWN0KCkge1xuICAgICAgICB0aGlzLndlaWdodHMgPSB0aGlzLnByZWRpY3RLZXJuZWwodGhpcy5pbnB1dExheWVyLndlaWdodHMsIHRoaXMuZmlsdGVycywgdGhpcy5iaWFzZXMpO1xuICAgIH1cbiAgICBjb21wYXJlKCkge1xuICAgICAgICBjb25zdCB7IGZpbHRlckRlbHRhcywgYmlhc0RlbHRhcyB9ID0gdGhpcztcbiAgICAgICAgdGhpcy5maWx0ZXJEZWx0YXMgPSB0aGlzLmNvbXBhcmVGaWx0ZXJEZWx0YXNLZXJuZWwoZmlsdGVyRGVsdGFzLCB0aGlzLmlucHV0TGF5ZXIud2VpZ2h0cywgdGhpcy5kZWx0YXMpO1xuICAgICAgICByZWxlYXNlKGZpbHRlckRlbHRhcyk7XG4gICAgICAgIHRoaXMuYmlhc0RlbHRhcyA9IHRoaXMuY29tcGFyZUJpYXNlc0tlcm5lbChiaWFzRGVsdGFzLCB0aGlzLmRlbHRhcyk7XG4gICAgICAgIHJlbGVhc2UoYmlhc0RlbHRhcyk7XG4gICAgICAgIHJlbGVhc2UodGhpcy5kZWx0YXMpO1xuICAgICAgICB0aGlzLmRlbHRhcyA9IHRoaXMuY29tcGFyZUlucHV0RGVsdGFzS2VybmVsKHRoaXMuZmlsdGVycywgdGhpcy5pbnB1dExheWVyLmRlbHRhcyk7XG4gICAgICAgIHJlbGVhc2UodGhpcy5pbnB1dExheWVyLmRlbHRhcyk7XG4gICAgICAgIC8vIFRPRE86IGRvIHdlIG5lZWQgdG8gY2xvbmUgaGVyZT9cbiAgICAgICAgdGhpcy5pbnB1dExheWVyLmRlbHRhcyA9IGNsb25lKHRoaXMuZGVsdGFzKTtcbiAgICB9XG4gICAgbGVhcm4obGVhcm5pbmdSYXRlKSB7XG4gICAgICAgIC8vIFRPRE86IGhhbmRsZSBmaWx0ZXJzXG4gICAgICAgIC8vIFRPRE86IGRvIHdlIG5lZWQgdG8gcmVsZWFzZSBoZXJlP1xuICAgICAgICBjb25zdCB7IHdlaWdodHM6IG9sZFdlaWdodHMgfSA9IHRoaXM7XG4gICAgICAgIHRoaXMud2VpZ2h0cyA9IHRoaXMucHJheGlzLnJ1bih0aGlzLCBsZWFybmluZ1JhdGUpO1xuICAgICAgICByZWxlYXNlKG9sZFdlaWdodHMpO1xuICAgICAgICBjbGVhcih0aGlzLmRlbHRhcyk7XG4gICAgfVxufVxuZnVuY3Rpb24gY29udm9sdXRpb24oc2V0dGluZ3MsIGlucHV0TGF5ZXIpIHtcbiAgICByZXR1cm4gbmV3IENvbnZvbHV0aW9uKHNldHRpbmdzLCBpbnB1dExheWVyKTtcbn1cblxuZnVuY3Rpb24gc2V0RHJvcG91dChkcm9wb3V0KSB7XG4gICAgcmV0dXJuIGRyb3BvdXQ7XG59XG5mdW5jdGlvbiB0cmFpbmluZ1ByZWRpY3QoaW5wdXRzKSB7XG4gICAgaWYgKHNldERyb3BvdXQoTWF0aC5yYW5kb20oKSkgPCB0aGlzLmNvbnN0YW50cy5wcm9iYWJpbGl0eSkge1xuICAgICAgICByZXR1cm4gMDtcbiAgICB9XG4gICAgcmV0dXJuIGlucHV0c1t0aGlzLnRocmVhZC55XVt0aGlzLnRocmVhZC54XTtcbn1cbmZ1bmN0aW9uIHByZWRpY3QkNShpbnB1dHMpIHtcbiAgICByZXR1cm4gaW5wdXRzW3RoaXMudGhyZWFkLnldW3RoaXMudGhyZWFkLnhdICogdGhpcy5jb25zdGFudHMucHJvYmFiaWxpdHk7XG59XG5mdW5jdGlvbiBjb21wYXJlJDMoZHJvcG91dHMsIGRlbHRhcykge1xuICAgIGlmIChkcm9wb3V0c1t0aGlzLnRocmVhZC55XVt0aGlzLnRocmVhZC54XSA9PT0gMCkge1xuICAgICAgICByZXR1cm4gMDtcbiAgICB9XG4gICAgcmV0dXJuIGRlbHRhc1t0aGlzLnRocmVhZC55XVt0aGlzLnRocmVhZC54XTtcbn1cbmNvbnN0IGRyb3BvdXREZWZhdWx0cyA9IHtcbiAgICAuLi5iYXNlTGF5ZXJEZWZhdWx0U2V0dGluZ3MsXG4gICAgcHJvYmFiaWxpdHk6IDAuNSxcbn07XG5jbGFzcyBEcm9wb3V0IGV4dGVuZHMgRmlsdGVyIHtcbiAgICBjb25zdHJ1Y3RvcihpbnB1dExheWVyLCBzZXR0aW5ncykge1xuICAgICAgICBzdXBlcihzZXR0aW5ncywgaW5wdXRMYXllcik7XG4gICAgICAgIHRoaXMucHJlZGljdEtlcm5lbE1hcCA9IG51bGw7XG4gICAgICAgIHRoaXMuc2V0dGluZ3MgPSB7IC4uLmRyb3BvdXREZWZhdWx0cywgLi4uc2V0dGluZ3MgfTtcbiAgICAgICAgdGhpcy5kcm9wb3V0cyA9IG51bGw7XG4gICAgICAgIHRoaXMudmFsaWRhdGUoKTtcbiAgICB9XG4gICAgc2V0dXBLZXJuZWxzKGlzVHJhaW5pbmcpIHtcbiAgICAgICAgY29uc3Qgb3V0cHV0ID0gW3RoaXMud2lkdGgsIHRoaXMuaGVpZ2h0XTtcbiAgICAgICAgaWYgKGlzVHJhaW5pbmcpIHtcbiAgICAgICAgICAgIHRoaXMucHJlZGljdEtlcm5lbE1hcCA9IG1ha2VLZXJuZWxNYXAoeyBkcm9wb3V0czogc2V0RHJvcG91dCB9LCB0cmFpbmluZ1ByZWRpY3QsIHtcbiAgICAgICAgICAgICAgICBvdXRwdXQsXG4gICAgICAgICAgICAgICAgaW1tdXRhYmxlOiB0cnVlLFxuICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICB0aGlzLmNvbXBhcmVLZXJuZWwgPSBtYWtlS2VybmVsKGNvbXBhcmUkMywgeyBvdXRwdXQsIGltbXV0YWJsZTogdHJ1ZSB9KTtcbiAgICAgICAgfVxuICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgIHRoaXMucHJlZGljdEtlcm5lbE1hcCA9IG1ha2VLZXJuZWxNYXAoe30sIHByZWRpY3QkNSwgeyBvdXRwdXQsIGltbXV0YWJsZTogdHJ1ZSB9KTtcbiAgICAgICAgfVxuICAgIH1cbiAgICBwcmVkaWN0KCkge1xuICAgICAgICByZWxlYXNlKHRoaXMud2VpZ2h0cyk7XG4gICAgICAgIGlmICh0aGlzLmRyb3BvdXRzKSB7XG4gICAgICAgICAgICByZWxlYXNlKHRoaXMuZHJvcG91dHMpO1xuICAgICAgICB9XG4gICAgICAgIGNvbnN0IHsgcmVzdWx0LCBkcm9wb3V0cyB9ID0gdGhpc1xuICAgICAgICAgICAgLnByZWRpY3RLZXJuZWxNYXAodGhpcy5pbnB1dExheWVyLndlaWdodHMpO1xuICAgICAgICB0aGlzLndlaWdodHMgPSByZXN1bHQ7XG4gICAgICAgIHRoaXMuZHJvcG91dHMgPSBkcm9wb3V0cztcbiAgICB9XG4gICAgY29tcGFyZSgpIHtcbiAgICAgICAgcmVsZWFzZSh0aGlzLmRlbHRhcyk7XG4gICAgICAgIHRoaXMuZGVsdGFzID0gdGhpcy5jb21wYXJlS2VybmVsKHRoaXMuZHJvcG91dHMsIHRoaXMuaW5wdXRMYXllci5kZWx0YXMpO1xuICAgIH1cbn1cbmZ1bmN0aW9uIGRyb3BvdXQoaW5wdXRMYXllciwgc2V0dGluZ3MpIHtcbiAgICByZXR1cm4gbmV3IERyb3BvdXQoaW5wdXRMYXllciwgc2V0dGluZ3MpO1xufVxuXG5mdW5jdGlvbiBmZWVkRm9yd2FyZChzZXR0aW5ncywgaW5wdXQpIHtcbiAgICBjb25zdCB7IGhlaWdodCwgcHJheGlzT3B0cyA9IG51bGwgfSA9IHNldHRpbmdzO1xuICAgIGNvbnN0IHdlaWdodHMgPSByYW5kb20oe1xuICAgICAgICBpZDogJ3dlaWdodHMnLFxuICAgICAgICBoZWlnaHQsXG4gICAgICAgIHdpZHRoOiBpbnB1dC5oZWlnaHQsXG4gICAgICAgIHByYXhpc09wdHMsXG4gICAgfSk7XG4gICAgY29uc3QgYmlhc2VzID0gcmFuZG9tKHsgaWQ6ICdiaWFzZXMnLCBoZWlnaHQsIHByYXhpc09wdHMgfSk7XG4gICAgcmV0dXJuIHNpZ21vaWQkMShhZGQkMShtdWx0aXBseSQxKHdlaWdodHMsIGlucHV0LCB7IHByYXhpc09wdHMgfSksIGJpYXNlcywgeyBwcmF4aXNPcHRzIH0pLCB7IHByYXhpc09wdHMgfSk7XG59XG5cbmZ1bmN0aW9uIHByZWRpY3QkNChpbnB1dHMsIGZpbHRlcnMsIGJpYXNlcykge1xuICAgIGxldCBvdXRwdXQgPSAwO1xuICAgIGxldCBpID0gMDtcbiAgICBmb3IgKGxldCB5ID0gMDsgeSA8IHRoaXMuY29uc3RhbnRzLmlucHV0SGVpZ2h0OyB5KyspIHtcbiAgICAgICAgZm9yIChsZXQgeCA9IDA7IHggPCB0aGlzLmNvbnN0YW50cy5pbnB1dFdpZHRoOyB4KyspIHtcbiAgICAgICAgICAgIG91dHB1dCArPSBpbnB1dHNbeV1beF0gKiBmaWx0ZXJzW3RoaXMudGhyZWFkLnhdW2ldO1xuICAgICAgICAgICAgaSsrO1xuICAgICAgICB9XG4gICAgfVxuICAgIHJldHVybiBvdXRwdXQgKyBiaWFzZXNbdGhpcy50aHJlYWQueF07XG59XG5mdW5jdGlvbiBwcmVkaWN0M0QkNChpbnB1dHMsIGZpbHRlcnMsIGJpYXNlcykge1xuICAgIGxldCBvdXRwdXQgPSAwO1xuICAgIGxldCBpID0gMDtcbiAgICBmb3IgKGxldCB6ID0gMDsgeiA8IHRoaXMuY29uc3RhbnRzLmlucHV0RGVwdGg7IHorKykge1xuICAgICAgICBmb3IgKGxldCB5ID0gMDsgeSA8IHRoaXMuY29uc3RhbnRzLmlucHV0SGVpZ2h0OyB5KyspIHtcbiAgICAgICAgICAgIGZvciAobGV0IHggPSAwOyB4IDwgdGhpcy5jb25zdGFudHMuaW5wdXRXaWR0aDsgeCsrKSB7XG4gICAgICAgICAgICAgICAgb3V0cHV0ICs9IGlucHV0c1t6XVt5XVt4XSAqIGZpbHRlcnNbdGhpcy50aHJlYWQueF1baV07XG4gICAgICAgICAgICAgICAgaSsrO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfVxuICAgIHJldHVybiBvdXRwdXQgKyBiaWFzZXNbdGhpcy50aHJlYWQueF07XG59XG5mdW5jdGlvbiBjb21wYXJlSW5wdXREZWx0YXMoaW5wdXREZWx0YXMsIGRlbHRhcywgZmlsdGVycykge1xuICAgIGxldCBzdW0gPSAwO1xuICAgIGNvbnN0IGZpbHRlclggPSB0aGlzLnRocmVhZC54ICsgdGhpcy50aHJlYWQueSAqIHRoaXMub3V0cHV0Lng7XG4gICAgZm9yIChsZXQgZmlsdGVyWSA9IDA7IGZpbHRlclkgPCB0aGlzLmNvbnN0YW50cy5maWx0ZXJDb3VudDsgZmlsdGVyWSsrKSB7XG4gICAgICAgIHN1bSArPSBmaWx0ZXJzW2ZpbHRlclldW2ZpbHRlclhdICogZGVsdGFzWzBdW2ZpbHRlclldO1xuICAgIH1cbiAgICByZXR1cm4gc3VtICsgaW5wdXREZWx0YXNbdGhpcy50aHJlYWQueV1bdGhpcy50aHJlYWQueF07XG59XG5mdW5jdGlvbiBjb21wYXJlSW5wdXREZWx0YXMzRChpbnB1dERlbHRhcywgZGVsdGFzLCBmaWx0ZXJzKSB7XG4gICAgbGV0IHN1bSA9IDA7XG4gICAgY29uc3QgZmlsdGVyWCA9IHRoaXMudGhyZWFkLnggKyB0aGlzLnRocmVhZC55ICogdGhpcy5vdXRwdXQueDtcbiAgICBmb3IgKGxldCBmaWx0ZXJZID0gMDsgZmlsdGVyWSA8IHRoaXMuY29uc3RhbnRzLmZpbHRlckNvdW50OyBmaWx0ZXJZKyspIHtcbiAgICAgICAgc3VtICs9IGZpbHRlcnNbZmlsdGVyWV1bZmlsdGVyWF0gKiBkZWx0YXNbMF1bZmlsdGVyWV07XG4gICAgfVxuICAgIHJldHVybiBzdW0gKyBpbnB1dERlbHRhc1t0aGlzLnRocmVhZC56XVt0aGlzLnRocmVhZC55XVt0aGlzLnRocmVhZC54XTtcbn1cbmZ1bmN0aW9uIGNvbXBhcmVCaWFzZXMoYmlhc2VzLCBkZWx0YXMpIHtcbiAgICByZXR1cm4gYmlhc2VzW3RoaXMudGhyZWFkLnhdICsgZGVsdGFzW3RoaXMudGhyZWFkLnldW3RoaXMudGhyZWFkLnhdO1xufVxuZnVuY3Rpb24gY29tcGFyZUZpbHRlckRlbHRhcyhmaWx0ZXJEZWx0YXMsIGlucHV0V2VpZ2h0cywgZGVsdGFzKSB7XG4gICAgcmV0dXJuIChmaWx0ZXJEZWx0YXNbdGhpcy50aHJlYWQueV1bdGhpcy50aHJlYWQueF0gK1xuICAgICAgICBpbnB1dFdlaWdodHNbdGhpcy50aHJlYWQueV1bdGhpcy50aHJlYWQueF0gKlxuICAgICAgICAgICAgZGVsdGFzW3RoaXMuY29uc3RhbnRzLmRlbHRhWV1bdGhpcy5jb25zdGFudHMuZGVsdGFYXSk7XG59XG5mdW5jdGlvbiBjb21wYXJlRmlsdGVyRGVsdGFzM0QoZmlsdGVyRGVsdGFzLCBpbnB1dFdlaWdodHMsIGRlbHRhcykge1xuICAgIGNvbnN0IGlucHV0WiA9IE1hdGguZmxvb3IodGhpcy50aHJlYWQueCAvICh0aGlzLmNvbnN0YW50cy5pbnB1dFdpZHRoICogdGhpcy5jb25zdGFudHMuaW5wdXRIZWlnaHQpKTtcbiAgICBjb25zdCBpbnB1dFkgPSBNYXRoLmZsb29yKCh0aGlzLnRocmVhZC54IC1cbiAgICAgICAgaW5wdXRaICogdGhpcy5jb25zdGFudHMuaW5wdXRXaWR0aCAqIHRoaXMuY29uc3RhbnRzLmlucHV0SGVpZ2h0KSAvXG4gICAgICAgIHRoaXMuY29uc3RhbnRzLmlucHV0V2lkdGgpO1xuICAgIGNvbnN0IGlucHV0WCA9IHRoaXMudGhyZWFkLnggLVxuICAgICAgICB0aGlzLmNvbnN0YW50cy5pbnB1dFdpZHRoICogKGlucHV0WSArIHRoaXMuY29uc3RhbnRzLmlucHV0SGVpZ2h0ICogaW5wdXRaKTtcbiAgICByZXR1cm4gKGZpbHRlckRlbHRhc1t0aGlzLnRocmVhZC55XVt0aGlzLnRocmVhZC54XSArXG4gICAgICAgIGlucHV0V2VpZ2h0c1tpbnB1dFpdW2lucHV0WV1baW5wdXRYXSAqIGRlbHRhc1swXVt0aGlzLnRocmVhZC55XSk7XG59XG5jbGFzcyBGdWxseUNvbm5lY3RlZCBleHRlbmRzIEZpbHRlciB7XG4gICAgY29uc3RydWN0b3Ioc2V0dGluZ3MsIGlucHV0TGF5ZXIpIHtcbiAgICAgICAgc3VwZXIoc2V0dGluZ3MsIGlucHV0TGF5ZXIpO1xuICAgICAgICB0aGlzLmNvbXBhcmVGaWx0ZXJEZWx0YXNLZXJuZWwgPSBudWxsO1xuICAgICAgICB0aGlzLmNvbXBhcmVJbnB1dERlbHRhc0tlcm5lbCA9IG51bGw7XG4gICAgICAgIHRoaXMuY29tcGFyZUJpYXNlc0tlcm5lbCA9IG51bGw7XG4gICAgICAgIHRoaXMuc2V0dGluZ3MgPSB7IC4uLnNldHRpbmdzIH07XG4gICAgICAgIHRoaXMudmFsaWRhdGUoKTtcbiAgICAgICAgY29uc3QgY29ubmVjdGlvbkNvdW50ID0gaW5wdXRMYXllci53aWR0aCAqIGlucHV0TGF5ZXIuaGVpZ2h0ICogaW5wdXRMYXllci5kZXB0aDtcbiAgICAgICAgdGhpcy5iaWFzZXMgPSB2YWx1ZXModGhpcy5oZWlnaHQsIHRoaXMuYmlhcyk7XG4gICAgICAgIHRoaXMuYmlhc0RlbHRhcyA9IHplcm9zJDEodGhpcy5oZWlnaHQpO1xuICAgICAgICB0aGlzLmZpbHRlcnMgPSByYW5kb3MyRChjb25uZWN0aW9uQ291bnQsIHRoaXMuaGVpZ2h0KTtcbiAgICAgICAgdGhpcy5maWx0ZXJEZWx0YXMgPSB6ZXJvczJEKGNvbm5lY3Rpb25Db3VudCwgdGhpcy5oZWlnaHQpO1xuICAgICAgICBpZiAodGhpcy5kZXB0aCA+IDApIHtcbiAgICAgICAgICAgIHRoaXMud2VpZ2h0cyA9IHJhbmRvczNEKHRoaXMud2lkdGgsIHRoaXMuaGVpZ2h0LCB0aGlzLmRlcHRoKTtcbiAgICAgICAgICAgIHRoaXMuZGVsdGFzID0gemVyb3MzRCh0aGlzLndpZHRoLCB0aGlzLmhlaWdodCwgdGhpcy5kZXB0aCk7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSBpZiAodGhpcy5oZWlnaHQgPiAwKSB7XG4gICAgICAgICAgICB0aGlzLndlaWdodHMgPSByYW5kb3MyRCh0aGlzLndpZHRoLCB0aGlzLmhlaWdodCk7XG4gICAgICAgICAgICB0aGlzLmRlbHRhcyA9IHplcm9zMkQodGhpcy53aWR0aCwgdGhpcy5oZWlnaHQpO1xuICAgICAgICB9XG4gICAgfVxuICAgIGdldCBiaWFzKCkge1xuICAgICAgICByZXR1cm4gdGhpcy5zZXR0aW5ncy5iaWFzO1xuICAgIH1cbiAgICBnZXQgYmlhc2VzKCkge1xuICAgICAgICByZXR1cm4gdGhpcy5zZXR0aW5ncy5iaWFzZXM7XG4gICAgfVxuICAgIHNldCBiaWFzZXMoYmlhc2VzKSB7XG4gICAgICAgIHRoaXMuc2V0dGluZ3MuYmlhc2VzID0gYmlhc2VzO1xuICAgIH1cbiAgICBnZXQgYmlhc0RlbHRhcygpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuc2V0dGluZ3MuYmlhc2VzO1xuICAgIH1cbiAgICBzZXQgYmlhc0RlbHRhcyhiaWFzRGVsdGFzKSB7XG4gICAgICAgIHRoaXMuc2V0dGluZ3MuYmlhc0RlbHRhcyA9IGJpYXNEZWx0YXM7XG4gICAgfVxuICAgIHZhbGlkYXRlKCkge1xuICAgICAgICBzdXBlci52YWxpZGF0ZSgpO1xuICAgICAgICBpZiAodGhpcy5kZXB0aCA+IDApXG4gICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ2RlcHRoIG5vdCBzdXBwb3J0ZWQnKTtcbiAgICB9XG4gICAgc2V0dXBLZXJuZWxzKCkge1xuICAgICAgICBjb25zdCB7IGlucHV0TGF5ZXIgfSA9IHRoaXM7XG4gICAgICAgIGNvbnN0IGNvbm5lY3Rpb25Db3VudCA9IGlucHV0TGF5ZXIud2lkdGggKiBpbnB1dExheWVyLmhlaWdodCAqIGlucHV0TGF5ZXIuZGVwdGg7XG4gICAgICAgIGlmIChpbnB1dExheWVyLmRlcHRoID4gMCkge1xuICAgICAgICAgICAgdGhpcy5wcmVkaWN0S2VybmVsID0gbWFrZUtlcm5lbChwcmVkaWN0M0QkNCwge1xuICAgICAgICAgICAgICAgIG91dHB1dDogW3RoaXMud2lkdGgsIHRoaXMuaGVpZ2h0XSxcbiAgICAgICAgICAgICAgICBjb25zdGFudHM6IHtcbiAgICAgICAgICAgICAgICAgICAgaW5wdXRIZWlnaHQ6IGlucHV0TGF5ZXIuaGVpZ2h0LFxuICAgICAgICAgICAgICAgICAgICBpbnB1dFdpZHRoOiBpbnB1dExheWVyLndpZHRoLFxuICAgICAgICAgICAgICAgICAgICBpbnB1dERlcHRoOiBpbnB1dExheWVyLmRlcHRoLFxuICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIHRoaXMuY29tcGFyZUZpbHRlckRlbHRhc0tlcm5lbCA9IG1ha2VLZXJuZWwoY29tcGFyZUZpbHRlckRlbHRhczNELCB7XG4gICAgICAgICAgICAgICAgb3V0cHV0OiBbY29ubmVjdGlvbkNvdW50LCB0aGlzLmhlaWdodF0sXG4gICAgICAgICAgICAgICAgY29uc3RhbnRzOiB7XG4gICAgICAgICAgICAgICAgICAgIGlucHV0V2lkdGg6IGlucHV0TGF5ZXIud2lkdGgsXG4gICAgICAgICAgICAgICAgICAgIGlucHV0SGVpZ2h0OiBpbnB1dExheWVyLmhlaWdodCxcbiAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgIGltbXV0YWJsZTogdHJ1ZSxcbiAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgdGhpcy5jb21wYXJlSW5wdXREZWx0YXNLZXJuZWwgPSBtYWtlS2VybmVsKGNvbXBhcmVJbnB1dERlbHRhczNELCB7XG4gICAgICAgICAgICAgICAgb3V0cHV0OiBbaW5wdXRMYXllci53aWR0aCwgaW5wdXRMYXllci5oZWlnaHQsIGlucHV0TGF5ZXIuZGVwdGhdLFxuICAgICAgICAgICAgICAgIGNvbnN0YW50czoge1xuICAgICAgICAgICAgICAgICAgICBmaWx0ZXJDb3VudDogdGhpcy5oZWlnaHQsXG4gICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICBpbW11dGFibGU6IHRydWUsXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgfVxuICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgIHRoaXMucHJlZGljdEtlcm5lbCA9IG1ha2VLZXJuZWwocHJlZGljdCQ0LCB7XG4gICAgICAgICAgICAgICAgb3V0cHV0OiBbdGhpcy53aWR0aCwgdGhpcy5oZWlnaHRdLFxuICAgICAgICAgICAgICAgIGNvbnN0YW50czoge1xuICAgICAgICAgICAgICAgICAgICBpbnB1dEhlaWdodDogaW5wdXRMYXllci5oZWlnaHQsXG4gICAgICAgICAgICAgICAgICAgIGlucHV0V2lkdGg6IGlucHV0TGF5ZXIud2lkdGgsXG4gICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgdGhpcy5jb21wYXJlRmlsdGVyRGVsdGFzS2VybmVsID0gbWFrZUtlcm5lbChjb21wYXJlRmlsdGVyRGVsdGFzLCB7XG4gICAgICAgICAgICAgICAgb3V0cHV0OiBbY29ubmVjdGlvbkNvdW50LCB0aGlzLmhlaWdodF0sXG4gICAgICAgICAgICAgICAgY29uc3RhbnRzOiB7XG4gICAgICAgICAgICAgICAgICAgIGlucHV0V2lkdGg6IGlucHV0TGF5ZXIud2lkdGgsXG4gICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgdGhpcy5jb21wYXJlSW5wdXREZWx0YXNLZXJuZWwgPSBtYWtlS2VybmVsKGNvbXBhcmVJbnB1dERlbHRhcywge1xuICAgICAgICAgICAgICAgIG91dHB1dDogW2lucHV0TGF5ZXIud2lkdGgsIGlucHV0TGF5ZXIuaGVpZ2h0XSxcbiAgICAgICAgICAgICAgICBjb25zdGFudHM6IHtcbiAgICAgICAgICAgICAgICAgICAgZmlsdGVyQ291bnQ6IHRoaXMuaGVpZ2h0LFxuICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgfVxuICAgICAgICB0aGlzLmNvbXBhcmVCaWFzZXNLZXJuZWwgPSBtYWtlS2VybmVsKGNvbXBhcmVCaWFzZXMsIHtcbiAgICAgICAgICAgIG91dHB1dDogW3RoaXMud2lkdGgsIHRoaXMuaGVpZ2h0XSxcbiAgICAgICAgfSk7XG4gICAgfVxuICAgIHByZWRpY3QoKSB7XG4gICAgICAgIHRoaXMud2VpZ2h0cyA9IHRoaXMucHJlZGljdEtlcm5lbCh0aGlzLmlucHV0TGF5ZXIud2VpZ2h0cywgdGhpcy5maWx0ZXJzLCB0aGlzLmJpYXNlcyk7XG4gICAgfVxuICAgIGNvbXBhcmUoKSB7XG4gICAgICAgIGNvbnN0IGlucHV0TGF5ZXJEZWx0YXMgPSB0aGlzLmlucHV0TGF5ZXIuZGVsdGFzO1xuICAgICAgICB0aGlzLmlucHV0TGF5ZXIuZGVsdGFzID0gdGhpc1xuICAgICAgICAgICAgLmNvbXBhcmVJbnB1dERlbHRhc0tlcm5lbChpbnB1dExheWVyRGVsdGFzLCB0aGlzLmRlbHRhcywgdGhpcy5maWx0ZXJzKTtcbiAgICAgICAgcmVsZWFzZShpbnB1dExheWVyRGVsdGFzKTtcbiAgICAgICAgY29uc3QgeyBiaWFzRGVsdGFzLCBmaWx0ZXJEZWx0YXMgfSA9IHRoaXM7XG4gICAgICAgIC8vIFRPRE86IGhhbmRsZSBiaWFzRGVsdGFzIGxlYXJuXG4gICAgICAgIHRoaXMuYmlhc0RlbHRhcyA9IHRoaXMuY29tcGFyZUJpYXNlc0tlcm5lbCh0aGlzLmJpYXNlcywgdGhpcy5kZWx0YXMpO1xuICAgICAgICAvLyBUT0RPOiBoYW5kbGUgZmlsdGVyRGVsdGFzIGxlYXJuXG4gICAgICAgIHRoaXMuZmlsdGVyRGVsdGFzID0gdGhpcy5jb21wYXJlRmlsdGVyRGVsdGFzS2VybmVsKGZpbHRlckRlbHRhcywgdGhpcy5pbnB1dExheWVyLndlaWdodHMsIHRoaXMuZGVsdGFzKTtcbiAgICAgICAgcmVsZWFzZShiaWFzRGVsdGFzKTtcbiAgICAgICAgcmVsZWFzZShmaWx0ZXJEZWx0YXMpO1xuICAgIH1cbn1cbmZ1bmN0aW9uIGZ1bGx5Q29ubmVjdGVkKHNldHRpbmdzLCBpbnB1dExheWVyKSB7XG4gICAgcmV0dXJuIG5ldyBGdWxseUNvbm5lY3RlZChzZXR0aW5ncywgaW5wdXRMYXllcik7XG59XG5cbmZ1bmN0aW9uIHByZWRpY3QkMyh3ZWlnaHRzKSB7XG4gICAgcmV0dXJuIC13ZWlnaHRzW3RoaXMudGhyZWFkLnldW3RoaXMudGhyZWFkLnhdO1xufVxuY2xhc3MgTmVnYXRpdmUgZXh0ZW5kcyBNb2RpZmllciB7XG4gICAgY29uc3RydWN0b3IoaW5wdXRMYXllciwgc2V0dGluZ3MpIHtcbiAgICAgICAgc3VwZXIoaW5wdXRMYXllciwgc2V0dGluZ3MpO1xuICAgICAgICB0aGlzLnZhbGlkYXRlKCk7XG4gICAgfVxuICAgIHNldHVwS2VybmVscygpIHtcbiAgICAgICAgdGhpcy5wcmVkaWN0S2VybmVsID0gbWFrZUtlcm5lbChwcmVkaWN0JDMsIHtcbiAgICAgICAgICAgIG91dHB1dDogW3RoaXMud2lkdGgsIHRoaXMuaGVpZ2h0XSxcbiAgICAgICAgfSk7XG4gICAgfVxuICAgIHByZWRpY3QoKSB7XG4gICAgICAgIHRoaXMud2VpZ2h0cyA9IHRoaXMucHJlZGljdEtlcm5lbCh0aGlzLmlucHV0TGF5ZXIud2VpZ2h0cyk7XG4gICAgfVxufVxuZnVuY3Rpb24gbmVnYXRpdmUoaW5wdXRMYXllciwgc2V0dGluZ3MpIHtcbiAgICByZXR1cm4gbmV3IE5lZ2F0aXZlKGlucHV0TGF5ZXIsIHNldHRpbmdzKTtcbn1cblxuZnVuY3Rpb24gcHJlZGljdCQyKGlucHV0TGF5ZXJXZWlnaHRzMSwgaW5wdXRMYXllcldlaWdodHMyKSB7XG4gICAgcmV0dXJuIChpbnB1dExheWVyV2VpZ2h0czFbdGhpcy50aHJlYWQueV1bdGhpcy50aHJlYWQueF0gKlxuICAgICAgICBpbnB1dExheWVyV2VpZ2h0czJbdGhpcy50aHJlYWQueV1bdGhpcy50aHJlYWQueF0pO1xufVxuZnVuY3Rpb24gY29tcGFyZSQyKHdlaWdodHMsIGRlbHRhcykge1xuICAgIHJldHVybiAod2VpZ2h0c1t0aGlzLnRocmVhZC55XVt0aGlzLnRocmVhZC54XSAqIGRlbHRhc1t0aGlzLnRocmVhZC55XVt0aGlzLnRocmVhZC54XSk7XG59XG5jbGFzcyBNdWx0aXBseUVsZW1lbnQgZXh0ZW5kcyBPcGVyYXRvciB7XG4gICAgZ2V0IHdpZHRoKCkge1xuICAgICAgICByZXR1cm4gdGhpcy5pbnB1dExheWVyMS53aWR0aDtcbiAgICB9XG4gICAgZ2V0IGhlaWdodCgpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuaW5wdXRMYXllcjEuaGVpZ2h0O1xuICAgIH1cbiAgICBnZXQgZGVwdGgoKSB7XG4gICAgICAgIHJldHVybiB0aGlzLmlucHV0TGF5ZXIxLmRlcHRoO1xuICAgIH1cbiAgICB2YWxpZGF0ZSgpIHtcbiAgICAgICAgc3VwZXIudmFsaWRhdGUoKTtcbiAgICAgICAgY2hlY2tTYW1lU2l6ZSh0aGlzLmlucHV0TGF5ZXIxLCB0aGlzLmlucHV0TGF5ZXIyKTtcbiAgICB9XG4gICAgc2V0dXBLZXJuZWxzKCkge1xuICAgICAgICB0aGlzLnByZWRpY3RLZXJuZWwgPSBtYWtlS2VybmVsKHByZWRpY3QkMiwge1xuICAgICAgICAgICAgb3V0cHV0OiBbdGhpcy53aWR0aCwgdGhpcy5oZWlnaHRdLFxuICAgICAgICAgICAgaW1tdXRhYmxlOiB0cnVlLFxuICAgICAgICB9KTtcbiAgICAgICAgdGhpcy5jb21wYXJlS2VybmVsID0gbWFrZUtlcm5lbChjb21wYXJlJDIsIHtcbiAgICAgICAgICAgIG91dHB1dDogW3RoaXMud2lkdGgsIHRoaXMuaGVpZ2h0XSxcbiAgICAgICAgICAgIGltbXV0YWJsZTogdHJ1ZSxcbiAgICAgICAgfSk7XG4gICAgfVxuICAgIHByZWRpY3QoKSB7XG4gICAgICAgIHJlbGVhc2UodGhpcy53ZWlnaHRzKTtcbiAgICAgICAgdGhpcy53ZWlnaHRzID0gdGhpcy5wcmVkaWN0S2VybmVsKHRoaXMuaW5wdXRMYXllcjEud2VpZ2h0cywgdGhpcy5pbnB1dExheWVyMi53ZWlnaHRzKTtcbiAgICAgICAgY2xlYXIodGhpcy5kZWx0YXMpO1xuICAgIH1cbiAgICBjb21wYXJlKCkge1xuICAgICAgICByZWxlYXNlKHRoaXMuaW5wdXRMYXllcjEuZGVsdGFzKTtcbiAgICAgICAgcmVsZWFzZSh0aGlzLmlucHV0TGF5ZXIyLmRlbHRhcyk7XG4gICAgICAgIHRoaXMuaW5wdXRMYXllcjEuZGVsdGFzID0gdGhpcy5jb21wYXJlS2VybmVsKHRoaXMuaW5wdXRMYXllcjIud2VpZ2h0cywgdGhpcy5kZWx0YXMpO1xuICAgICAgICB0aGlzLmlucHV0TGF5ZXIyLmRlbHRhcyA9IHRoaXMuY29tcGFyZUtlcm5lbCh0aGlzLmlucHV0TGF5ZXIxLndlaWdodHMsIHRoaXMuZGVsdGFzKTtcbiAgICB9XG59XG5mdW5jdGlvbiBtdWx0aXBseUVsZW1lbnQkMShpbnB1dExheWVyMSwgaW5wdXRMYXllcjIsIHNldHRpbmdzKSB7XG4gICAgcmV0dXJuIG5ldyBNdWx0aXBseUVsZW1lbnQoaW5wdXRMYXllcjEsIGlucHV0TGF5ZXIyLCBzZXR0aW5ncyk7XG59XG5cbmZ1bmN0aW9uIG9uZXMkMShzaXplKSB7XG4gICAgcmV0dXJuIG5ldyBGbG9hdDMyQXJyYXkoc2l6ZSkuZmlsbCgxKTtcbn1cbmZ1bmN0aW9uIG9uZXMyRCh3aWR0aCwgaGVpZ2h0KSB7XG4gICAgY29uc3QgcmVzdWx0ID0gbmV3IEFycmF5KGhlaWdodCk7XG4gICAgZm9yIChsZXQgeSA9IDA7IHkgPCBoZWlnaHQ7IHkrKykge1xuICAgICAgICByZXN1bHRbeV0gPSBvbmVzJDEod2lkdGgpO1xuICAgIH1cbiAgICByZXR1cm4gcmVzdWx0O1xufVxuXG5jbGFzcyBPbmVzIGV4dGVuZHMgTW9kZWwge1xuICAgIGNvbnN0cnVjdG9yKHNldHRpbmdzKSB7XG4gICAgICAgIHN1cGVyKHNldHRpbmdzKTtcbiAgICAgICAgdGhpcy52YWxpZGF0ZSgpO1xuICAgICAgICB0aGlzLndlaWdodHMgPSBvbmVzMkQodGhpcy53aWR0aCwgdGhpcy5oZWlnaHQpO1xuICAgICAgICB0aGlzLmRlbHRhcyA9IHplcm9zMkQodGhpcy53aWR0aCwgdGhpcy5oZWlnaHQpO1xuICAgIH1cbn1cbmZ1bmN0aW9uIG9uZXMoc2V0dGluZ3MpIHtcbiAgICByZXR1cm4gbmV3IE9uZXMoc2V0dGluZ3MpO1xufVxuXG5mdW5jdGlvbiBwcmVkaWN0MkQkMyhpbnB1dHMpIHtcbiAgICByZXR1cm4gYWN0aXZhdGUkMShpbnB1dHNbdGhpcy50aHJlYWQueV1bdGhpcy50aHJlYWQueF0pO1xufVxuZnVuY3Rpb24gcHJlZGljdDNEJDMoaW5wdXRzKSB7XG4gICAgcmV0dXJuIGFjdGl2YXRlJDEoaW5wdXRzW3RoaXMudGhyZWFkLnpdW3RoaXMudGhyZWFkLnldW3RoaXMudGhyZWFkLnhdKTtcbn1cbmZ1bmN0aW9uIGNvbXBhcmUyRCQzKHdlaWdodHMsIGVycm9ycykge1xuICAgIHJldHVybiBtZWFzdXJlJDEod2VpZ2h0c1t0aGlzLnRocmVhZC55XVt0aGlzLnRocmVhZC54XSwgZXJyb3JzW3RoaXMudGhyZWFkLnldW3RoaXMudGhyZWFkLnhdKTtcbn1cbmZ1bmN0aW9uIGNvbXBhcmUzRCQzKHdlaWdodHMsIGVycm9ycykge1xuICAgIHJldHVybiBtZWFzdXJlJDEod2VpZ2h0c1t0aGlzLnRocmVhZC56XVt0aGlzLnRocmVhZC55XVt0aGlzLnRocmVhZC54XSwgZXJyb3JzW3RoaXMudGhyZWFkLnpdW3RoaXMudGhyZWFkLnldW3RoaXMudGhyZWFkLnhdKTtcbn1cbmNsYXNzIFRhbmggZXh0ZW5kcyBBY3RpdmF0aW9uIHtcbiAgICBzZXR1cEtlcm5lbHMoKSB7XG4gICAgICAgIGlmICh0aGlzLmRlcHRoID4gMCkge1xuICAgICAgICAgICAgdGhpcy5wcmVkaWN0S2VybmVsID0gbWFrZUtlcm5lbChwcmVkaWN0M0QkMywge1xuICAgICAgICAgICAgICAgIG91dHB1dDogW3RoaXMud2lkdGgsIHRoaXMuaGVpZ2h0LCB0aGlzLmRlcHRoXSxcbiAgICAgICAgICAgICAgICBmdW5jdGlvbnM6IFthY3RpdmF0ZSQxXSxcbiAgICAgICAgICAgICAgICBpbW11dGFibGU6IHRydWUsXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIHRoaXMuY29tcGFyZUtlcm5lbCA9IG1ha2VLZXJuZWwoY29tcGFyZTNEJDMsIHtcbiAgICAgICAgICAgICAgICBvdXRwdXQ6IFt0aGlzLndpZHRoLCB0aGlzLmhlaWdodCwgdGhpcy5kZXB0aF0sXG4gICAgICAgICAgICAgICAgZnVuY3Rpb25zOiBbbWVhc3VyZSQxXSxcbiAgICAgICAgICAgICAgICBpbW11dGFibGU6IHRydWUsXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgfVxuICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgIHRoaXMucHJlZGljdEtlcm5lbCA9IG1ha2VLZXJuZWwocHJlZGljdDJEJDMsIHtcbiAgICAgICAgICAgICAgICBvdXRwdXQ6IFt0aGlzLndpZHRoLCB0aGlzLmhlaWdodF0sXG4gICAgICAgICAgICAgICAgZnVuY3Rpb25zOiBbYWN0aXZhdGUkMV0sXG4gICAgICAgICAgICAgICAgaW1tdXRhYmxlOiB0cnVlLFxuICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICB0aGlzLmNvbXBhcmVLZXJuZWwgPSBtYWtlS2VybmVsKGNvbXBhcmUyRCQzLCB7XG4gICAgICAgICAgICAgICAgb3V0cHV0OiBbdGhpcy53aWR0aCwgdGhpcy5oZWlnaHRdLFxuICAgICAgICAgICAgICAgIGZ1bmN0aW9uczogW21lYXN1cmUkMV0sXG4gICAgICAgICAgICAgICAgaW1tdXRhYmxlOiB0cnVlLFxuICAgICAgICAgICAgfSk7XG4gICAgICAgIH1cbiAgICB9XG4gICAgcHJlZGljdCgpIHtcbiAgICAgICAgcmVsZWFzZSh0aGlzLndlaWdodHMpO1xuICAgICAgICB0aGlzLndlaWdodHMgPSB0aGlzLnByZWRpY3RLZXJuZWwodGhpcy5pbnB1dExheWVyLndlaWdodHMpO1xuICAgICAgICBjbGVhcih0aGlzLmRlbHRhcyk7XG4gICAgfVxuICAgIGNvbXBhcmUoKSB7XG4gICAgICAgIHJlbGVhc2UodGhpcy5pbnB1dExheWVyLmRlbHRhcyk7XG4gICAgICAgIHRoaXMuaW5wdXRMYXllci5kZWx0YXMgPSB0aGlzLmNvbXBhcmVLZXJuZWwodGhpcy53ZWlnaHRzLCB0aGlzLmRlbHRhcyk7XG4gICAgfVxufVxuZnVuY3Rpb24gdGFuaCQxKGlucHV0TGF5ZXIsIHNldHRpbmdzKSB7XG4gICAgcmV0dXJuIG5ldyBUYW5oKGlucHV0TGF5ZXIsIHNldHRpbmdzKTtcbn1cblxuY2xhc3MgWmVyb3MgZXh0ZW5kcyBNb2RlbCB7XG4gICAgY29uc3RydWN0b3Ioc2V0dGluZ3MpIHtcbiAgICAgICAgc3VwZXIoc2V0dGluZ3MpO1xuICAgICAgICB0aGlzLnZhbGlkYXRlKCk7XG4gICAgICAgIHRoaXMud2VpZ2h0cyA9IHplcm9zMkQodGhpcy53aWR0aCwgdGhpcy5oZWlnaHQpO1xuICAgICAgICB0aGlzLmRlbHRhcyA9IHplcm9zMkQodGhpcy53aWR0aCwgdGhpcy5oZWlnaHQpO1xuICAgIH1cbiAgICBwcmVkaWN0KCkge1xuICAgICAgICAvLyB0aHJvdyBuZXcgRXJyb3IoYCR7dGhpcy5jb25zdHJ1Y3Rvci5uYW1lfS1wcmVkaWN0IGlzIG5vdCB5ZXQgaW1wbGVtZW50ZWRgKVxuICAgIH1cbiAgICBjb21wYXJlKCkge1xuICAgICAgICAvLyB0aHJvdyBuZXcgRXJyb3IoYCR7dGhpcy5jb25zdHJ1Y3Rvci5uYW1lfS1jb21wYXJlIGlzIG5vdCB5ZXQgaW1wbGVtZW50ZWRgKVxuICAgIH1cbn1cbmZ1bmN0aW9uIHplcm9zKHNldHRpbmdzKSB7XG4gICAgcmV0dXJuIG5ldyBaZXJvcyhzZXR0aW5ncyk7XG59XG5cbmZ1bmN0aW9uIGdydShzZXR0aW5ncywgcmVjdXJyZW50SW5wdXQsIGlucHV0KSB7XG4gICAgY29uc3QgeyBoZWlnaHQgfSA9IHNldHRpbmdzO1xuICAgIGNvbnN0IHVwZGF0ZUdhdGVXZWlnaHRzID0gcmFuZG9tKHsgaGVpZ2h0LCB3aWR0aDogaW5wdXQuaGVpZ2h0IH0pO1xuICAgIGNvbnN0IHVwZGF0ZUdhdGVQZWVwaG9sZXMgPSByYW5kb20oeyB3aWR0aDogaGVpZ2h0LCBoZWlnaHQgfSk7XG4gICAgY29uc3QgdXBkYXRlR2F0ZUJpYXMgPSB6ZXJvcyh7IGhlaWdodCB9KTtcbiAgICBjb25zdCB1cGRhdGVHYXRlID0gc2lnbW9pZCQxKGFkZCQxKGFkZCQxKG11bHRpcGx5JDEodXBkYXRlR2F0ZVdlaWdodHMsIGlucHV0KSwgbXVsdGlwbHkkMSh1cGRhdGVHYXRlUGVlcGhvbGVzLCByZWN1cnJlbnRJbnB1dCkpLCB1cGRhdGVHYXRlQmlhcykpO1xuICAgIGNvbnN0IHJlc2V0R2F0ZVdlaWdodHMgPSByYW5kb20oeyBoZWlnaHQsIHdpZHRoOiBpbnB1dC5oZWlnaHQgfSk7XG4gICAgY29uc3QgcmVzZXRHYXRlUGVlcGhvbGVzID0gcmFuZG9tKHsgd2lkdGg6IGhlaWdodCwgaGVpZ2h0IH0pO1xuICAgIGNvbnN0IHJlc2V0R2F0ZUJpYXMgPSB6ZXJvcyh7IGhlaWdodCB9KTtcbiAgICBjb25zdCByZXNldEdhdGUgPSBzaWdtb2lkJDEoYWRkJDEoYWRkJDEobXVsdGlwbHkkMShyZXNldEdhdGVXZWlnaHRzLCBpbnB1dCksIG11bHRpcGx5JDEocmVzZXRHYXRlUGVlcGhvbGVzLCByZWN1cnJlbnRJbnB1dCkpLCByZXNldEdhdGVCaWFzKSk7XG4gICAgY29uc3QgY2VsbFdlaWdodHMgPSByYW5kb20oeyBoZWlnaHQsIHdpZHRoOiBpbnB1dC5oZWlnaHQgfSk7XG4gICAgY29uc3QgY2VsbFBlZXBob2xlcyA9IHJhbmRvbSh7IHdpZHRoOiBoZWlnaHQsIGhlaWdodCB9KTtcbiAgICBjb25zdCBjZWxsQmlhcyA9IHplcm9zKHsgaGVpZ2h0IH0pO1xuICAgIGNvbnN0IGNlbGwgPSB0YW5oJDEoYWRkJDEoYWRkJDEobXVsdGlwbHkkMShjZWxsV2VpZ2h0cywgaW5wdXQpLCBtdWx0aXBseSQxKGNlbGxQZWVwaG9sZXMsIG11bHRpcGx5RWxlbWVudCQxKHJlc2V0R2F0ZSwgcmVjdXJyZW50SW5wdXQpKSksIGNlbGxCaWFzKSk7XG4gICAgLy8gY29tcHV0ZSBoaWRkZW4gc3RhdGUgYXMgZ2F0ZWQsIHNhdHVyYXRlZCBjZWxsIGFjdGl2YXRpb25zXG4gICAgLy8gbmVnYXRlIHVwZGF0ZUdhdGVcbiAgICByZXR1cm4gYWRkJDEobXVsdGlwbHlFbGVtZW50JDEoYWRkJDEob25lcyh7IHdpZHRoOiB1cGRhdGVHYXRlLndpZHRoLCBoZWlnaHQ6IHVwZGF0ZUdhdGUuaGVpZ2h0IH0pLCBuZWdhdGl2ZSh1cGRhdGVHYXRlKSksIGNlbGwpLCBtdWx0aXBseUVsZW1lbnQkMShyZWN1cnJlbnRJbnB1dCwgdXBkYXRlR2F0ZSkpO1xufVxuXG5jb25zdCBkZWZhdWx0cyQ1ID0ge1xuICAgIHdlaWdodHM6IG51bGwsXG59O1xuY2xhc3MgSW5wdXQgZXh0ZW5kcyBFbnRyeVBvaW50IHtcbiAgICBjb25zdHJ1Y3RvcihzZXR0aW5ncykge1xuICAgICAgICBzdXBlcih7IC4uLmRlZmF1bHRzJDUsIC4uLnNldHRpbmdzIH0pO1xuICAgICAgICB0aGlzLnJlc2hhcGVJbnB1dCA9IG51bGw7XG4gICAgICAgIHRoaXMudmFsaWRhdGUoKTtcbiAgICAgICAgdGhpcy5yZXNoYXBlSW5wdXQgPSBudWxsO1xuICAgICAgICB0aGlzLmRlbHRhcyA9IHplcm9zMkQodGhpcy53aWR0aCwgdGhpcy5oZWlnaHQpO1xuICAgIH1cbiAgICBzZXR1cEtlcm5lbHMoKSB7XG4gICAgICAgIGlmICh0aGlzLndpZHRoID09PSAxKSB7XG4gICAgICAgICAgICB0aGlzLnByZWRpY3QgPSB0aGlzLnByZWRpY3QxRDtcbiAgICAgICAgICAgIHRoaXMucmVzaGFwZUlucHV0ID0gbWFrZUtlcm5lbChmdW5jdGlvbiAodmFsdWUpIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gdmFsdWVbdGhpcy50aHJlYWQueV07XG4gICAgICAgICAgICB9LCB7XG4gICAgICAgICAgICAgICAgb3V0cHV0OiBbMSwgdGhpcy5oZWlnaHRdLFxuICAgICAgICAgICAgICAgIGltbXV0YWJsZTogdHJ1ZSxcbiAgICAgICAgICAgIH0pO1xuICAgICAgICB9XG4gICAgfVxuICAgIHJldXNlS2VybmVscyhsYXllcikge1xuICAgICAgICAvLyBzdXBlci5yZXVzZUtlcm5lbHMobGF5ZXIpO1xuICAgICAgICB0aGlzLnJlc2hhcGVJbnB1dCA9IGxheWVyLnJlc2hhcGVJbnB1dDtcbiAgICB9XG4gICAgcHJlZGljdChpbnB1dHMpIHtcbiAgICAgICAgaWYgKChBcnJheS5pc0FycmF5KGlucHV0cykgfHwgaW5wdXRzIGluc3RhbmNlb2YgRmxvYXQzMkFycmF5KSAmJlxuICAgICAgICAgICAgdHlwZW9mIGlucHV0c1swXSA9PT0gJ251bWJlcicgJiZcbiAgICAgICAgICAgIGlucHV0cy5sZW5ndGggPT09IHRoaXMuaGVpZ2h0ICogdGhpcy53aWR0aCkge1xuICAgICAgICAgICAgcmVsZWFzZSh0aGlzLndlaWdodHMpO1xuICAgICAgICAgICAgdGhpcy53ZWlnaHRzID0ga2VybmVsSW5wdXQoaW5wdXRzLCBbdGhpcy53aWR0aCwgdGhpcy5oZWlnaHRdKTtcbiAgICAgICAgfVxuICAgICAgICBlbHNlIGlmIChBcnJheS5pc0FycmF5KGlucHV0cykgJiZcbiAgICAgICAgICAgIGlucHV0cy5sZW5ndGggPT09IHRoaXMuaGVpZ2h0ICYmXG4gICAgICAgICAgICAoQXJyYXkuaXNBcnJheShpbnB1dHNbMF0pIHx8IGlucHV0c1swXSBpbnN0YW5jZW9mIEZsb2F0MzJBcnJheSkgJiZcbiAgICAgICAgICAgIGlucHV0c1swXS5sZW5ndGggPT09IHRoaXMud2lkdGgpIHtcbiAgICAgICAgICAgIHRoaXMud2VpZ2h0cyA9IGNsb25lKGlucHV0cyk7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ0lucHV0cyBhcmUgbm90IG9mIHNpemVkIGNvcnJlY3RseScpO1xuICAgICAgICB9XG4gICAgICAgIGNsZWFyKHRoaXMuZGVsdGFzKTtcbiAgICB9XG4gICAgcHJlZGljdDFEKGlucHV0cykge1xuICAgICAgICBpZiAodGhpcy53ZWlnaHRzKVxuICAgICAgICAgICAgcmVsZWFzZSh0aGlzLndlaWdodHMpO1xuICAgICAgICBpZiAodGhpcy5yZXNoYXBlSW5wdXQpIHtcbiAgICAgICAgICAgIHRoaXMud2VpZ2h0cyA9IHRoaXMucmVzaGFwZUlucHV0KGlucHV0cyk7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICB0aGlzLndlaWdodHMgPSBpbnB1dHM7XG4gICAgICAgIH1cbiAgICAgICAgY2xlYXIodGhpcy5kZWx0YXMpO1xuICAgIH1cbiAgICBjb21wYXJlKCkge1xuICAgICAgICAvLyB0aHJvdyBuZXcgRXJyb3IoYCR7dGhpcy5jb25zdHJ1Y3Rvci5uYW1lfS1jb21wYXJlIGlzIG5vdCB5ZXQgaW1wbGVtZW50ZWRgKVxuICAgIH1cbn1cbmZ1bmN0aW9uIGlucHV0KHNldHRpbmdzKSB7XG4gICAgcmV0dXJuIG5ldyBJbnB1dChzZXR0aW5ncyk7XG59XG5cbmZ1bmN0aW9uIHByZWRpY3QyRCQyKGlucHV0cykge1xuICAgIHJldHVybiBhY3RpdmF0ZShpbnB1dHNbdGhpcy50aHJlYWQueV1bdGhpcy50aHJlYWQueF0pO1xufVxuZnVuY3Rpb24gcHJlZGljdDNEJDIoaW5wdXRzKSB7XG4gICAgcmV0dXJuIGFjdGl2YXRlKGlucHV0c1t0aGlzLnRocmVhZC56XVt0aGlzLnRocmVhZC55XVt0aGlzLnRocmVhZC54XSk7XG59XG5mdW5jdGlvbiBjb21wYXJlMkQkMih3ZWlnaHRzLCBkZWx0YXMpIHtcbiAgICByZXR1cm4gbWVhc3VyZSh3ZWlnaHRzW3RoaXMudGhyZWFkLnldW3RoaXMudGhyZWFkLnhdLCBkZWx0YXNbdGhpcy50aHJlYWQueV1bdGhpcy50aHJlYWQueF0pO1xufVxuZnVuY3Rpb24gY29tcGFyZTNEJDIod2VpZ2h0cywgZGVsdGFzKSB7XG4gICAgcmV0dXJuIG1lYXN1cmUod2VpZ2h0c1t0aGlzLnRocmVhZC56XVt0aGlzLnRocmVhZC55XVt0aGlzLnRocmVhZC54XSwgZGVsdGFzW3RoaXMudGhyZWFkLnpdW3RoaXMudGhyZWFkLnldW3RoaXMudGhyZWFkLnhdKTtcbn1cbmNsYXNzIExlYWt5UmVsdSBleHRlbmRzIEFjdGl2YXRpb24ge1xuICAgIHNldHVwS2VybmVscygpIHtcbiAgICAgICAgY29uc3QgeyB3aWR0aCwgaGVpZ2h0LCBkZXB0aCB9ID0gdGhpcy5pbnB1dExheWVyO1xuICAgICAgICBpZiAodGhpcy5kZXB0aCA+IDApIHtcbiAgICAgICAgICAgIHRoaXMucHJlZGljdEtlcm5lbCA9IG1ha2VLZXJuZWwocHJlZGljdDNEJDIsIHtcbiAgICAgICAgICAgICAgICBvdXRwdXQ6IFt3aWR0aCwgaGVpZ2h0LCBkZXB0aF0sXG4gICAgICAgICAgICAgICAgZnVuY3Rpb25zOiBbYWN0aXZhdGVdLFxuICAgICAgICAgICAgICAgIGltbXV0YWJsZTogdHJ1ZSxcbiAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgdGhpcy5jb21wYXJlS2VybmVsID0gbWFrZUtlcm5lbChjb21wYXJlM0QkMiwge1xuICAgICAgICAgICAgICAgIG91dHB1dDogW3dpZHRoLCBoZWlnaHQsIGRlcHRoXSxcbiAgICAgICAgICAgICAgICBmdW5jdGlvbnM6IFttZWFzdXJlXSxcbiAgICAgICAgICAgICAgICBpbW11dGFibGU6IHRydWUsXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgfVxuICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgIHRoaXMucHJlZGljdEtlcm5lbCA9IG1ha2VLZXJuZWwocHJlZGljdDJEJDIsIHtcbiAgICAgICAgICAgICAgICBvdXRwdXQ6IFt3aWR0aCwgaGVpZ2h0XSxcbiAgICAgICAgICAgICAgICBmdW5jdGlvbnM6IFthY3RpdmF0ZV0sXG4gICAgICAgICAgICAgICAgaW1tdXRhYmxlOiB0cnVlLFxuICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICB0aGlzLmNvbXBhcmVLZXJuZWwgPSBtYWtlS2VybmVsKGNvbXBhcmUyRCQyLCB7XG4gICAgICAgICAgICAgICAgb3V0cHV0OiBbd2lkdGgsIGhlaWdodF0sXG4gICAgICAgICAgICAgICAgZnVuY3Rpb25zOiBbbWVhc3VyZV0sXG4gICAgICAgICAgICAgICAgaW1tdXRhYmxlOiB0cnVlLFxuICAgICAgICAgICAgfSk7XG4gICAgICAgIH1cbiAgICB9XG4gICAgcHJlZGljdCgpIHtcbiAgICAgICAgcmVsZWFzZSh0aGlzLndlaWdodHMpO1xuICAgICAgICB0aGlzLndlaWdodHMgPSB0aGlzLnByZWRpY3RLZXJuZWwodGhpcy5pbnB1dExheWVyLndlaWdodHMpO1xuICAgICAgICBjbGVhcih0aGlzLmRlbHRhcyk7XG4gICAgfVxuICAgIGNvbXBhcmUoKSB7XG4gICAgICAgIGNvbnN0IHsgZGVsdGFzIH0gPSB0aGlzO1xuICAgICAgICB0aGlzLmRlbHRhcyA9IHRoaXMuY29tcGFyZUtlcm5lbCh0aGlzLndlaWdodHMsIGRlbHRhcyk7XG4gICAgICAgIHJlbGVhc2UoZGVsdGFzKTtcbiAgICB9XG59XG5mdW5jdGlvbiBsZWFreVJlbHUoaW5wdXRMYXllciwgc2V0dGluZ3MpIHtcbiAgICByZXR1cm4gbmV3IExlYWt5UmVsdShpbnB1dExheWVyLCBzZXR0aW5ncyk7XG59XG5cbmZ1bmN0aW9uIGxzdG1DZWxsKHNldHRpbmdzLCBpbnB1dCwgcmVjdXJyZW50SW5wdXQpIHtcbiAgICBjb25zdCB7IGhlaWdodCB9ID0gc2V0dGluZ3M7XG4gICAgaWYgKHR5cGVvZiBoZWlnaHQgIT09ICdudW1iZXInKSB7XG4gICAgICAgIHRocm93IG5ldyBFcnJvcignbm8gc2V0dGluZ3MuaGVpZ2h0IGdpdmVuJyk7XG4gICAgfVxuICAgIGlmIChyZWN1cnJlbnRJbnB1dC5zZXREaW1lbnNpb25zKSB7XG4gICAgICAgIHJlY3VycmVudElucHV0LnNldERpbWVuc2lvbnMoMSwgaGVpZ2h0KTtcbiAgICB9XG4gICAgY29uc3QgaW5wdXRHYXRlV2VpZ2h0cyA9IHJhbmRvbSh7XG4gICAgICAgIGhlaWdodCxcbiAgICAgICAgd2lkdGg6IGlucHV0LmhlaWdodCxcbiAgICAgICAgc3RkOiAwLjA4LFxuICAgICAgICBpZDogJ2lucHV0R2F0ZVdlaWdodHMnLFxuICAgIH0pO1xuICAgIGNvbnN0IGlucHV0R2F0ZVBlZXBob2xlcyA9IHJhbmRvbSh7XG4gICAgICAgIHdpZHRoOiBoZWlnaHQsXG4gICAgICAgIGhlaWdodCxcbiAgICAgICAgc3RkOiAwLjA4LFxuICAgICAgICBpZDogJ2lucHV0R2F0ZVBlZXBob2xlcycsXG4gICAgfSk7XG4gICAgY29uc3QgaW5wdXRHYXRlQmlhcyA9IHplcm9zKHsgaGVpZ2h0LCBpZDogJ2lucHV0R2F0ZUJpYXMnIH0pO1xuICAgIGNvbnN0IGlucHV0R2F0ZSA9IHNpZ21vaWQkMShhZGQkMShhZGQkMShtdWx0aXBseSQxKGlucHV0R2F0ZVdlaWdodHMsIGlucHV0KSwgbXVsdGlwbHkkMShpbnB1dEdhdGVQZWVwaG9sZXMsIHJlY3VycmVudElucHV0KSksIGlucHV0R2F0ZUJpYXMpLCB7IGlkOiAnaW5wdXRHYXRlJyB9KTtcbiAgICBjb25zdCBmb3JnZXRHYXRlV2VpZ2h0cyA9IHJhbmRvbSh7XG4gICAgICAgIGhlaWdodCxcbiAgICAgICAgd2lkdGg6IGlucHV0LmhlaWdodCxcbiAgICAgICAgc3RkOiAwLjA4LFxuICAgICAgICBpZDogJ2ZvcmdldEdhdGVXZWlnaHRzJyxcbiAgICB9KTtcbiAgICBjb25zdCBmb3JnZXRHYXRlUGVlcGhvbGVzID0gcmFuZG9tKHtcbiAgICAgICAgd2lkdGg6IGhlaWdodCxcbiAgICAgICAgaGVpZ2h0LFxuICAgICAgICBzdGQ6IDAuMDgsXG4gICAgICAgIGlkOiAnZm9yZ2V0R2F0ZVBlZXBob2xlcycsXG4gICAgfSk7XG4gICAgY29uc3QgZm9yZ2V0R2F0ZUJpYXMgPSB6ZXJvcyh7IGhlaWdodCwgaWQ6ICdmb3JnZXRHYXRlQmlhcycgfSk7XG4gICAgY29uc3QgZm9yZ2V0R2F0ZSA9IHNpZ21vaWQkMShhZGQkMShhZGQkMShtdWx0aXBseSQxKGZvcmdldEdhdGVXZWlnaHRzLCBpbnB1dCksIG11bHRpcGx5JDEoZm9yZ2V0R2F0ZVBlZXBob2xlcywgcmVjdXJyZW50SW5wdXQpKSwgZm9yZ2V0R2F0ZUJpYXMpLCB7IGlkOiAnZm9yZ2V0R2F0ZScgfSk7XG4gICAgY29uc3Qgb3V0cHV0R2F0ZVdlaWdodHMgPSByYW5kb20oe1xuICAgICAgICBoZWlnaHQsXG4gICAgICAgIHdpZHRoOiBpbnB1dC5oZWlnaHQsXG4gICAgICAgIHN0ZDogMC4wOCxcbiAgICAgICAgaWQ6ICdvdXRwdXRHYXRlV2VpZ2h0cycsXG4gICAgfSk7XG4gICAgY29uc3Qgb3V0cHV0R2F0ZVBlZXBob2xlcyA9IHJhbmRvbSh7XG4gICAgICAgIHdpZHRoOiBoZWlnaHQsXG4gICAgICAgIGhlaWdodCxcbiAgICAgICAgc3RkOiAwLjA4LFxuICAgICAgICBpZDogJ291dHB1dEdhdGVQZWVwaG9sZXMnLFxuICAgIH0pO1xuICAgIGNvbnN0IG91dHB1dEdhdGVCaWFzID0gemVyb3MoeyBoZWlnaHQsIGlkOiAnb3V0cHV0R2F0ZUJpYXMnIH0pO1xuICAgIGNvbnN0IG91dHB1dEdhdGUgPSBzaWdtb2lkJDEoYWRkJDEoYWRkJDEobXVsdGlwbHkkMShvdXRwdXRHYXRlV2VpZ2h0cywgaW5wdXQpLCBtdWx0aXBseSQxKG91dHB1dEdhdGVQZWVwaG9sZXMsIHJlY3VycmVudElucHV0KSksIG91dHB1dEdhdGVCaWFzKSwgeyBpZDogJ291dHB1dEdhdGUnIH0pO1xuICAgIGNvbnN0IG1lbW9yeVdlaWdodHMgPSByYW5kb20oe1xuICAgICAgICBoZWlnaHQsXG4gICAgICAgIHdpZHRoOiBpbnB1dC5oZWlnaHQsXG4gICAgICAgIHN0ZDogMC4wOCxcbiAgICAgICAgaWQ6ICdtZW1vcnlXZWlnaHRzJyxcbiAgICB9KTtcbiAgICBjb25zdCBtZW1vcnlQZWVwaG9sZXMgPSByYW5kb20oe1xuICAgICAgICB3aWR0aDogaGVpZ2h0LFxuICAgICAgICBoZWlnaHQsXG4gICAgICAgIHN0ZDogMC4wOCxcbiAgICAgICAgaWQ6ICdtZW1vcnlQZWVwaG9sZXMnLFxuICAgIH0pO1xuICAgIGNvbnN0IG1lbW9yeUJpYXMgPSB6ZXJvcyh7IGhlaWdodCwgaWQ6ICdtZW1vcnlCaWFzJyB9KTtcbiAgICBjb25zdCBtZW1vcnkgPSB0YW5oJDEoYWRkJDEoYWRkJDEobXVsdGlwbHkkMShtZW1vcnlXZWlnaHRzLCBpbnB1dCksIG11bHRpcGx5JDEobWVtb3J5UGVlcGhvbGVzLCByZWN1cnJlbnRJbnB1dCkpLCBtZW1vcnlCaWFzKSwgeyBpZDogJ21lbW9yeScgfSk7XG4gICAgLy8gY29tcHV0ZSBuZXcgY2VsbCBhY3RpdmF0aW9uXG4gICAgY29uc3QgcmV0YWluQ2VsbCA9IG11bHRpcGx5RWxlbWVudCQxKGZvcmdldEdhdGUsIHJlY3VycmVudElucHV0LCB7XG4gICAgICAgIGlkOiAncmV0YWluQ2VsbCcsXG4gICAgfSk7IC8vIHdoYXQgZG8gd2Uga2VlcCBmcm9tIGNlbGxcbiAgICBjb25zdCB3cml0ZUNlbGwgPSBtdWx0aXBseUVsZW1lbnQkMShpbnB1dEdhdGUsIG1lbW9yeSwgeyBpZDogJ3dyaXRlQ2VsbCcgfSk7IC8vIHdoYXQgZG8gd2Ugd3JpdGUgdG8gY2VsbFxuICAgIGNvbnN0IGNlbGwgPSBhZGQkMShyZXRhaW5DZWxsLCB3cml0ZUNlbGwsIHsgaWQ6ICdjZWxsJyB9KTsgLy8gbmV3IGNlbGwgY29udGVudHNcbiAgICAvLyBjb21wdXRlIGhpZGRlbiBzdGF0ZSBhcyBnYXRlZCwgc2F0dXJhdGVkIGNlbGwgYWN0aXZhdGlvbnNcbiAgICByZXR1cm4gbXVsdGlwbHlFbGVtZW50JDEob3V0cHV0R2F0ZSwgdGFuaCQxKGNlbGwpLCB7IGlkOiAnYWN0aXZhdGlvbnMnIH0pO1xufVxuXG5mdW5jdGlvbiBvdXRwdXQoc2V0dGluZ3MsIGlucHV0TGF5ZXIpIHtcbiAgICBjb25zdCB7IGhlaWdodCB9ID0gc2V0dGluZ3M7XG4gICAgY29uc3Qgb3V0cHV0R2F0ZSA9IHJhbmRvbSh7XG4gICAgICAgIGhlaWdodCxcbiAgICAgICAgd2lkdGg6IGlucHV0TGF5ZXIuaGVpZ2h0LFxuICAgICAgICBpZDogJ291dHB1dEdhdGUnLFxuICAgICAgICBzdGQ6IDAuMDgsXG4gICAgfSk7XG4gICAgY29uc3Qgb3V0cHV0ID0gcmFuZG9tKHsgaGVpZ2h0LCBpZDogJ291dHB1dCcsIHN0ZDogMC4wOCB9KTtcbiAgICBjb25zdCBvdXRwdXRHYXRlQ29ubmVjdG9yID0gbXVsdGlwbHkkMShvdXRwdXRHYXRlLCBpbnB1dExheWVyLCB7XG4gICAgICAgIGlkOiAnb3V0cHV0R2F0ZUNvbm5lY3RlZCcsXG4gICAgfSk7XG4gICAgcmV0dXJuIHRhcmdldCh7IGlkOiAndGFyZ2V0JywgLi4uc2V0dGluZ3MgfSwgYWRkJDEob3V0cHV0R2F0ZUNvbm5lY3Rvciwgb3V0cHV0KSk7XG59XG5cbmZ1bmN0aW9uIHNldFN3aXRjaFkodmFsdWUpIHtcbiAgICByZXR1cm4gdmFsdWU7XG59XG5mdW5jdGlvbiBzZXRTd2l0Y2hYKHZhbHVlKSB7XG4gICAgcmV0dXJuIHZhbHVlO1xufVxuZnVuY3Rpb24gcHJlZGljdCQxKGlucHV0cykge1xuICAgIGNvbnN0IHN0YXJ0RmlsdGVyWCA9IHRoaXMuY29uc3RhbnRzLnBhZGRpbmdYIC0gdGhpcy50aHJlYWQueCAqIHRoaXMuY29uc3RhbnRzLnN0cmlkZVg7XG4gICAgY29uc3Qgc3RhcnRJbnB1dFggPSB0aGlzLnRocmVhZC54ICogdGhpcy5jb25zdGFudHMuc3RyaWRlWCAtIHRoaXMuY29uc3RhbnRzLnBhZGRpbmdYO1xuICAgIGNvbnN0IGVuZEZpbHRlclggPSBNYXRoLm1pbih0aGlzLmNvbnN0YW50cy5maWx0ZXJXaWR0aCwgc3RhcnRGaWx0ZXJYICsgdGhpcy5jb25zdGFudHMuaW5wdXRXaWR0aCk7XG4gICAgY29uc3Qgc3RhcnRGaWx0ZXJZID0gdGhpcy5jb25zdGFudHMucGFkZGluZ1kgLSB0aGlzLnRocmVhZC55ICogdGhpcy5jb25zdGFudHMuc3RyaWRlWTtcbiAgICBjb25zdCBzdGFydElucHV0WSA9IHRoaXMudGhyZWFkLnkgKiB0aGlzLmNvbnN0YW50cy5zdHJpZGVZIC0gdGhpcy5jb25zdGFudHMucGFkZGluZ1k7XG4gICAgY29uc3QgZW5kRmlsdGVyWSA9IE1hdGgubWluKHRoaXMuY29uc3RhbnRzLmZpbHRlckhlaWdodCwgc3RhcnRGaWx0ZXJZICsgdGhpcy5jb25zdGFudHMuaW5wdXRIZWlnaHQpO1xuICAgIGxldCBsYXJnZXN0VmFsdWUgPSAtOTk5OTk7XG4gICAgLy8gY29udm9sdmUgY2VudGVyZWQgYXQgdGhpcyBwYXJ0aWN1bGFyIGxvY2F0aW9uXG4gICAgZm9yIChsZXQgZmlsdGVyWSA9IE1hdGgubWF4KDAsIHN0YXJ0RmlsdGVyWSksIGlucHV0WSA9IE1hdGgubWF4KDAsIHN0YXJ0SW5wdXRZKTsgZmlsdGVyWSA8IGVuZEZpbHRlclk7IGZpbHRlclkrKywgaW5wdXRZKyspIHtcbiAgICAgICAgZm9yIChsZXQgZmlsdGVyWCA9IE1hdGgubWF4KDAsIHN0YXJ0RmlsdGVyWCksIGlucHV0WCA9IE1hdGgubWF4KDAsIHN0YXJ0SW5wdXRYKTsgZmlsdGVyWCA8IGVuZEZpbHRlclg7IGZpbHRlclgrKywgaW5wdXRYKyspIHtcbiAgICAgICAgICAgIGlmIChpbnB1dFkgPj0gMCAmJlxuICAgICAgICAgICAgICAgIGlucHV0WSA8IHRoaXMuY29uc3RhbnRzLmlucHV0SGVpZ2h0ICYmXG4gICAgICAgICAgICAgICAgaW5wdXRYID49IDAgJiZcbiAgICAgICAgICAgICAgICBpbnB1dFggPCB0aGlzLmNvbnN0YW50cy5pbnB1dFdpZHRoKSB7XG4gICAgICAgICAgICAgICAgY29uc3QgaW5wdXQgPSBpbnB1dHNbdGhpcy50aHJlYWQuel1baW5wdXRZXVtpbnB1dFhdO1xuICAgICAgICAgICAgICAgIGlmIChpbnB1dCA+IGxhcmdlc3RWYWx1ZSkge1xuICAgICAgICAgICAgICAgICAgICBsYXJnZXN0VmFsdWUgPSBpbnB1dDtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9XG4gICAgcmV0dXJuIGxhcmdlc3RWYWx1ZTtcbn1cbmZ1bmN0aW9uIGNvbXBhcmUkMShkZWx0YXMsIHN3aXRjaFksIHN3aXRjaFgpIHtcbiAgICBjb25zdCB4ID0gTWF0aC5mbG9vcigodGhpcy50aHJlYWQueCAvIHRoaXMub3V0cHV0LngpICogdGhpcy5jb25zdGFudHMub3V0cHV0V2lkdGgpO1xuICAgIGNvbnN0IHkgPSBNYXRoLmZsb29yKCh0aGlzLnRocmVhZC55IC8gdGhpcy5vdXRwdXQueSkgKiB0aGlzLmNvbnN0YW50cy5vdXRwdXRIZWlnaHQpO1xuICAgIGxldCB2YWx1ZSA9IDA7XG4gICAgZm9yIChsZXQgZGVsdGFzWSA9IDA7IGRlbHRhc1kgPCB0aGlzLmNvbnN0YW50cy5pbnB1dEhlaWdodDsgZGVsdGFzWSsrKSB7XG4gICAgICAgIGZvciAobGV0IGRlbHRhc1ggPSAwOyBkZWx0YXNYIDwgdGhpcy5jb25zdGFudHMuaW5wdXRXaWR0aDsgZGVsdGFzWCsrKSB7XG4gICAgICAgICAgICBjb25zdCBzd2l0Y2hYVmFsdWUgPSBzd2l0Y2hYW2RlbHRhc1ldW2RlbHRhc1hdO1xuICAgICAgICAgICAgY29uc3Qgc3dpdGNoWVZhbHVlID0gc3dpdGNoWVtkZWx0YXNZXVtkZWx0YXNYXTtcbiAgICAgICAgICAgIGlmIChzd2l0Y2hYVmFsdWUgPT09IHggJiYgc3dpdGNoWVZhbHVlID09PSB5KSB7XG4gICAgICAgICAgICAgICAgdmFsdWUgKz0gZGVsdGFzW2RlbHRhc1ldW2RlbHRhc1hdO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfVxuICAgIHJldHVybiB2YWx1ZTtcbn1cbmNvbnN0IGRlZmF1bHRzJDQgPSB7XG4gICAgcGFkZGluZzogMCxcbiAgICBzdHJpZGU6IDAsXG4gICAgZmlsdGVyV2lkdGg6IDAsXG4gICAgZmlsdGVySGVpZ2h0OiAwLFxuICAgIGZpbHRlckNvdW50OiAwLFxufTtcbmNsYXNzIFBvb2wgZXh0ZW5kcyBGaWx0ZXIge1xuICAgIGNvbnN0cnVjdG9yKHNldHRpbmdzLCBpbnB1dExheWVyKSB7XG4gICAgICAgIHN1cGVyKHNldHRpbmdzLCBpbnB1dExheWVyKTtcbiAgICAgICAgdGhpcy5wcmVkaWN0S2VybmVsTWFwID0gbnVsbDtcbiAgICAgICAgdGhpcy5zZXR0aW5ncyA9IHtcbiAgICAgICAgICAgIC4uLnNldHRpbmdzLFxuICAgICAgICAgICAgLi4uZ2V0U3RyaWRlKHNldHRpbmdzLCBkZWZhdWx0cyQ0KSxcbiAgICAgICAgICAgIC4uLmdldFBhZGRpbmcoc2V0dGluZ3MsIGRlZmF1bHRzJDQpLFxuICAgICAgICB9O1xuICAgICAgICB0aGlzLndlaWdodHMgPSByYW5kb3MzRCh0aGlzLndpZHRoLCB0aGlzLmhlaWdodCwgdGhpcy5kZXB0aCk7XG4gICAgICAgIHRoaXMuZGVsdGFzID0gemVyb3MzRCh0aGlzLndpZHRoLCB0aGlzLmhlaWdodCwgdGhpcy5kZXB0aCk7XG4gICAgICAgIHRoaXMuZmlsdGVycyA9IHJhbmRvczNEKHRoaXMuZmlsdGVyV2lkdGgsIHRoaXMuZmlsdGVySGVpZ2h0LCB0aGlzLmZpbHRlckNvdW50KTtcbiAgICAgICAgdGhpcy5maWx0ZXJEZWx0YXMgPSB6ZXJvczNEKHRoaXMuZmlsdGVyV2lkdGgsIHRoaXMuZmlsdGVySGVpZ2h0LCB0aGlzLmZpbHRlckNvdW50KTtcbiAgICAgICAgdGhpcy52YWxpZGF0ZSgpO1xuICAgIH1cbiAgICBnZXQgc3RyaWRlWCgpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuc2V0dGluZ3Muc3RyaWRlWDtcbiAgICB9XG4gICAgZ2V0IHN0cmlkZVkoKSB7XG4gICAgICAgIHJldHVybiB0aGlzLnNldHRpbmdzLnN0cmlkZVk7XG4gICAgfVxuICAgIGdldCBwYWRkaW5nWCgpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuc2V0dGluZ3MucGFkZGluZ1g7XG4gICAgfVxuICAgIGdldCBwYWRkaW5nWSgpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuc2V0dGluZ3MucGFkZGluZ1k7XG4gICAgfVxuICAgIGdldCB3aWR0aCgpIHtcbiAgICAgICAgcmV0dXJuIE1hdGguZmxvb3IoKHRoaXMuaW5wdXRMYXllci53aWR0aCArIHRoaXMucGFkZGluZ1ggKiAyIC0gdGhpcy5maWx0ZXJXaWR0aCkgL1xuICAgICAgICAgICAgdGhpcy5zdHJpZGVYICtcbiAgICAgICAgICAgIDEpO1xuICAgIH1cbiAgICBnZXQgaGVpZ2h0KCkge1xuICAgICAgICByZXR1cm4gTWF0aC5mbG9vcigodGhpcy5pbnB1dExheWVyLmhlaWdodCArIHRoaXMucGFkZGluZ1kgKiAyIC0gdGhpcy5maWx0ZXJIZWlnaHQpIC9cbiAgICAgICAgICAgIHRoaXMuc3RyaWRlWSArXG4gICAgICAgICAgICAxKTtcbiAgICB9XG4gICAgZ2V0IGRlcHRoKCkge1xuICAgICAgICByZXR1cm4gdGhpcy5zZXR0aW5ncy5maWx0ZXJDb3VudDtcbiAgICB9XG4gICAgZ2V0IGZpbHRlckNvdW50KCkge1xuICAgICAgICAvLyBUT0RPOiBoYW5kbGUgMSBkZXB0aD9cbiAgICAgICAgcmV0dXJuIHRoaXMuc2V0dGluZ3MuZmlsdGVyQ291bnQ7XG4gICAgfVxuICAgIGdldCBzd2l0Y2hYKCkge1xuICAgICAgICByZXR1cm4gdGhpcy5zZXR0aW5ncy5zd2l0Y2hYO1xuICAgIH1cbiAgICBzZXQgc3dpdGNoWChzd2l0Y2hYKSB7XG4gICAgICAgIHRoaXMuc2V0dGluZ3Muc3dpdGNoWCA9IHN3aXRjaFg7XG4gICAgfVxuICAgIGdldCBzd2l0Y2hZKCkge1xuICAgICAgICByZXR1cm4gdGhpcy5zZXR0aW5ncy5zd2l0Y2hZO1xuICAgIH1cbiAgICBzZXQgc3dpdGNoWShzd2l0Y2hZKSB7XG4gICAgICAgIHRoaXMuc2V0dGluZ3Muc3dpdGNoWSA9IHN3aXRjaFk7XG4gICAgfVxuICAgIHNldHVwS2VybmVscygpIHtcbiAgICAgICAgdGhpcy5wcmVkaWN0S2VybmVsTWFwID0gbWFrZUtlcm5lbE1hcCh7XG4gICAgICAgICAgICBzd2l0Y2hYOiBzZXRTd2l0Y2hYLFxuICAgICAgICAgICAgc3dpdGNoWTogc2V0U3dpdGNoWSxcbiAgICAgICAgfSwgcHJlZGljdCQxLCB7XG4gICAgICAgICAgICBvdXRwdXQ6IFt0aGlzLndpZHRoLCB0aGlzLmhlaWdodCwgdGhpcy5kZXB0aF0sXG4gICAgICAgICAgICBjb25zdGFudHM6IHtcbiAgICAgICAgICAgICAgICBpbnB1dFdpZHRoOiB0aGlzLmlucHV0TGF5ZXIud2lkdGgsXG4gICAgICAgICAgICAgICAgaW5wdXRIZWlnaHQ6IHRoaXMuaW5wdXRMYXllci5oZWlnaHQsXG4gICAgICAgICAgICAgICAgcGFkZGluZ1g6IHRoaXMucGFkZGluZ1gsXG4gICAgICAgICAgICAgICAgcGFkZGluZ1k6IHRoaXMucGFkZGluZ1ksXG4gICAgICAgICAgICAgICAgZmlsdGVySGVpZ2h0OiB0aGlzLmZpbHRlckhlaWdodCxcbiAgICAgICAgICAgICAgICBmaWx0ZXJXaWR0aDogdGhpcy5maWx0ZXJXaWR0aCxcbiAgICAgICAgICAgIH0sXG4gICAgICAgIH0pO1xuICAgICAgICB0aGlzLmNvbXBhcmVLZXJuZWwgPSBtYWtlS2VybmVsKGNvbXBhcmUkMSwge1xuICAgICAgICAgICAgb3V0cHV0OiBbXG4gICAgICAgICAgICAgICAgdGhpcy5pbnB1dExheWVyLndpZHRoLFxuICAgICAgICAgICAgICAgIHRoaXMuaW5wdXRMYXllci5oZWlnaHQsXG4gICAgICAgICAgICAgICAgdGhpcy5pbnB1dExheWVyLmRlcHRoLFxuICAgICAgICAgICAgXSxcbiAgICAgICAgICAgIGNvbnN0YW50czoge1xuICAgICAgICAgICAgICAgIGlucHV0V2lkdGg6IHRoaXMuaW5wdXRMYXllci53aWR0aCxcbiAgICAgICAgICAgICAgICBpbnB1dEhlaWdodDogdGhpcy5pbnB1dExheWVyLmhlaWdodCxcbiAgICAgICAgICAgICAgICBvdXRwdXRXaWR0aDogdGhpcy53aWR0aCxcbiAgICAgICAgICAgICAgICBvdXRwdXRIZWlnaHQ6IHRoaXMuaGVpZ2h0LFxuICAgICAgICAgICAgfSxcbiAgICAgICAgfSk7XG4gICAgfVxuICAgIHByZWRpY3QoKSB7XG4gICAgICAgIGNvbnN0IHsgcmVzdWx0OiB3ZWlnaHRzLCBzd2l0Y2hYLCBzd2l0Y2hZIH0gPSB0aGlzXG4gICAgICAgICAgICAucHJlZGljdEtlcm5lbE1hcCh0aGlzLmlucHV0TGF5ZXIud2VpZ2h0cyk7XG4gICAgICAgIHRoaXMuc3dpdGNoWCA9IHN3aXRjaFg7XG4gICAgICAgIHRoaXMuc3dpdGNoWSA9IHN3aXRjaFk7XG4gICAgICAgIHRoaXMud2VpZ2h0cyA9IHdlaWdodHM7XG4gICAgfVxuICAgIGNvbXBhcmUoKSB7XG4gICAgICAgIC8vIGRlYnVnZ2VyO1xuICAgICAgICAvLyBjb25zdCBkZXB0aCA9IHRoaXMuaW5wdXRMYXllci5kZWx0YXMubGVuZ3RoO1xuICAgICAgICAvLyBjb25zdCBoZWlnaHQgPSB0aGlzLmlucHV0TGF5ZXIuZGVsdGFzWzBdLmxlbmd0aDtcbiAgICAgICAgLy8gY29uc3Qgd2lkdGggPSB0aGlzLmlucHV0TGF5ZXIuZGVsdGFzWzBdWzBdLmxlbmd0aDtcbiAgICAgICAgLy8gY29uc3QgdHlwZSA9IHR5cGVvZiB0aGlzLmlucHV0TGF5ZXIuZGVsdGFzWzBdWzBdWzBdO1xuICAgICAgICBjb25zdCBpbnB1dExheWVyRGVsdGFzID0gdGhpcy5pbnB1dExheWVyLmRlbHRhcztcbiAgICAgICAgdGhpcy5pbnB1dExheWVyLmRlbHRhcyA9IHRoaXMuY29tcGFyZUtlcm5lbCh0aGlzLmRlbHRhcywgdGhpcy5zd2l0Y2hYLCB0aGlzLnN3aXRjaFkpO1xuICAgICAgICByZWxlYXNlKGlucHV0TGF5ZXJEZWx0YXMpO1xuICAgICAgICAvLyBkZWJ1Z2dlcjtcbiAgICAgICAgLy8gaWYgKGRlcHRoICE9PSB0aGlzLmlucHV0TGF5ZXIuZGVsdGFzLmxlbmd0aCkgZGVidWdnZXI7XG4gICAgICAgIC8vIGlmIChoZWlnaHQgIT09IHRoaXMuaW5wdXRMYXllci5kZWx0YXNbMF0ubGVuZ3RoKSBkZWJ1Z2dlcjtcbiAgICAgICAgLy8gaWYgKHdpZHRoICE9PSB0aGlzLmlucHV0TGF5ZXIuZGVsdGFzWzBdWzBdLmxlbmd0aCkgZGVidWdnZXI7XG4gICAgICAgIC8vIGlmICh0eXBlICE9PSB0eXBlb2YgdGhpcy5pbnB1dExheWVyLmRlbHRhc1swXVswXVswXSkgZGVidWdnZXI7XG4gICAgfVxufVxuZnVuY3Rpb24gcG9vbChzZXR0aW5ncywgaW5wdXRMYXllcikge1xuICAgIHJldHVybiBuZXcgUG9vbChzZXR0aW5ncywgaW5wdXRMYXllcik7XG59XG5cbmNsYXNzIFJlY3VycmVudElucHV0IGV4dGVuZHMgSW50ZXJuYWwge1xuICAgIGNvbnN0cnVjdG9yKHJlY3VycmVudElucHV0KSB7XG4gICAgICAgIHN1cGVyKCk7XG4gICAgICAgIHRoaXMucHJheGlzID0gbnVsbDtcbiAgICAgICAgdGhpcy5wcmVkaWN0S2VybmVsID0gbnVsbDtcbiAgICAgICAgdGhpcy5jb21wYXJlS2VybmVsID0gbnVsbDtcbiAgICAgICAgdGhpcy5zZXR0aW5ncyA9IHt9O1xuICAgICAgICB0aGlzLnJlY3VycmVudElucHV0ID0gcmVjdXJyZW50SW5wdXQ7XG4gICAgICAgIHRoaXMudmFsaWRhdGUoKTtcbiAgICB9XG4gICAgZ2V0IHdpZHRoKCkge1xuICAgICAgICByZXR1cm4gdGhpcy5yZWN1cnJlbnRJbnB1dC53aWR0aDtcbiAgICB9XG4gICAgZ2V0IGhlaWdodCgpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMucmVjdXJyZW50SW5wdXQuaGVpZ2h0O1xuICAgIH1cbiAgICBnZXQgZGVwdGgoKSB7XG4gICAgICAgIHJldHVybiB0aGlzLnJlY3VycmVudElucHV0LmRlcHRoO1xuICAgIH1cbiAgICBnZXQgZGVsdGFzKCkge1xuICAgICAgICByZXR1cm4gdGhpcy5yZWN1cnJlbnRJbnB1dC5kZWx0YXM7XG4gICAgfVxuICAgIHNldCBkZWx0YXMoZGVsdGFzKSB7XG4gICAgICAgIGNvbnN0IHJlY3VycmVudElucHV0RGVsdGFzID0gdGhpcy5yZWN1cnJlbnRJbnB1dC5kZWx0YXM7XG4gICAgICAgIHRoaXMucmVjdXJyZW50SW5wdXQuZGVsdGFzID0gZGVsdGFzO1xuICAgICAgICByZWxlYXNlKHJlY3VycmVudElucHV0RGVsdGFzKTtcbiAgICB9XG4gICAgZ2V0IHdlaWdodHMoKSB7XG4gICAgICAgIHJldHVybiB0aGlzLnJlY3VycmVudElucHV0LndlaWdodHM7XG4gICAgfVxuICAgIHNldCB3ZWlnaHRzKHdlaWdodHMpIHtcbiAgICAgICAgY29uc3QgcmVjdXJyZW50SW5wdXRXZWlnaHRzID0gdGhpcy5yZWN1cnJlbnRJbnB1dC53ZWlnaHRzO1xuICAgICAgICB0aGlzLnJlY3VycmVudElucHV0LndlaWdodHMgPSB3ZWlnaHRzO1xuICAgICAgICByZWxlYXNlKHJlY3VycmVudElucHV0V2VpZ2h0cyk7XG4gICAgfVxuICAgIHZhbGlkYXRlKCkge1xuICAgICAgICBCYXNlTGF5ZXIucHJvdG90eXBlLnZhbGlkYXRlLmNhbGwodGhpcyk7XG4gICAgICAgIGlmICh0aGlzLndpZHRoICE9PSB0aGlzLnJlY3VycmVudElucHV0LndpZHRoKSB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoYCR7dGhpcy5jb25zdHJ1Y3Rvci5uYW1lfSBsYXllciB3aWR0aCAke3RoaXMud2lkdGh9IGFuZCAke3RoaXMucmVjdXJyZW50SW5wdXQuY29uc3RydWN0b3IubmFtZX0gd2lkdGggKCR7dGhpcy5yZWN1cnJlbnRJbnB1dC53aWR0aH0pIGFyZSBub3Qgc2FtZWApO1xuICAgICAgICB9XG4gICAgICAgIGlmICh0aGlzLmhlaWdodCAhPT0gdGhpcy5yZWN1cnJlbnRJbnB1dC5oZWlnaHQpIHtcbiAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcihgJHt0aGlzLmNvbnN0cnVjdG9yLm5hbWV9IGxheWVyIGhlaWdodCAke3RoaXMuaGVpZ2h0fSBhbmQgJHt0aGlzLnJlY3VycmVudElucHV0LmNvbnN0cnVjdG9yLm5hbWV9IHdpZHRoICgke3RoaXMucmVjdXJyZW50SW5wdXQuaGVpZ2h0fSkgYXJlIG5vdCBzYW1lYCk7XG4gICAgICAgIH1cbiAgICB9XG4gICAgc2V0RGltZW5zaW9ucyh3aWR0aCwgaGVpZ2h0KSB7XG4gICAgICAgIHRoaXMucmVjdXJyZW50SW5wdXQud2lkdGggPSB3aWR0aDtcbiAgICAgICAgdGhpcy5yZWN1cnJlbnRJbnB1dC5oZWlnaHQgPSBoZWlnaHQ7XG4gICAgfVxuICAgIHByZWRpY3QoKSB7XG4gICAgICAgIC8vIHRocm93IG5ldyBFcnJvcihgJHt0aGlzLmNvbnN0cnVjdG9yLm5hbWV9LXByZWRpY3QgaXMgbm90IHlldCBpbXBsZW1lbnRlZGApXG4gICAgfVxuICAgIGNvbXBhcmUoKSB7XG4gICAgICAgIC8vIHRocm93IG5ldyBFcnJvcihgJHt0aGlzLmNvbnN0cnVjdG9yLm5hbWV9LWNvbXBhcmUgaXMgbm90IHlldCBpbXBsZW1lbnRlZGApXG4gICAgfVxuICAgIGxlYXJuKCkge1xuICAgICAgICAvLyB0aHJvdyBuZXcgRXJyb3IoYCR7dGhpcy5jb25zdHJ1Y3Rvci5uYW1lfS1sZWFybiBpcyBub3QgeWV0IGltcGxlbWVudGVkYClcbiAgICB9XG4gICAgc2V0dXBLZXJuZWxzKCkge1xuICAgICAgICAvLyB0aHJvdyBuZXcgRXJyb3IoXG4gICAgICAgIC8vICAgYCR7dGhpcy5jb25zdHJ1Y3Rvci5uYW1lfS1zZXR1cEtlcm5lbHMgaXMgbm90IHlldCBpbXBsZW1lbnRlZGBcbiAgICAgICAgLy8gKVxuICAgIH1cbiAgICByZXVzZUtlcm5lbHMoKSB7XG4gICAgICAgIC8vIHRocm93IG5ldyBFcnJvcihcbiAgICAgICAgLy8gICBgJHt0aGlzLmNvbnN0cnVjdG9yLm5hbWV9LXJldXNlS2VybmVscyBpcyBub3QgeWV0IGltcGxlbWVudGVkYFxuICAgICAgICAvLyApXG4gICAgfVxufVxuXG5jbGFzcyBSZWN1cnJlbnRaZXJvcyBleHRlbmRzIEludGVybmFsIHtcbiAgICBjb25zdHJ1Y3RvcihzZXR0aW5ncykge1xuICAgICAgICBzdXBlcigpO1xuICAgICAgICB0aGlzLnByYXhpcyA9IG51bGw7XG4gICAgICAgIHRoaXMuc2V0dGluZ3MgPSB7fTtcbiAgICAgICAgdGhpcy5wcmVkaWN0S2VybmVsID0gbnVsbDtcbiAgICAgICAgdGhpcy5jb21wYXJlS2VybmVsID0gbnVsbDtcbiAgICAgICAgaWYgKHNldHRpbmdzKSB7XG4gICAgICAgICAgICB0aGlzLnNldHRpbmdzID0geyAuLi5zZXR0aW5ncyB9O1xuICAgICAgICB9XG4gICAgfVxuICAgIHNldERpbWVuc2lvbnMod2lkdGgsIGhlaWdodCkge1xuICAgICAgICB0aGlzLnByYXhpcyA9IG51bGw7XG4gICAgICAgIHRoaXMuc2V0dGluZ3MgPSB7XG4gICAgICAgICAgICAuLi50aGlzLnNldHRpbmdzLFxuICAgICAgICAgICAgd2lkdGgsXG4gICAgICAgICAgICBoZWlnaHQsXG4gICAgICAgICAgICB3ZWlnaHRzOiB6ZXJvczJEKHdpZHRoLCBoZWlnaHQpLFxuICAgICAgICAgICAgZGVsdGFzOiB6ZXJvczJEKHdpZHRoLCBoZWlnaHQpLFxuICAgICAgICB9O1xuICAgIH1cbiAgICBzZXR1cEtlcm5lbHMoKSB7XG4gICAgICAgIC8vIHRocm93IG5ldyBFcnJvcihcbiAgICAgICAgLy8gICBgJHt0aGlzLmNvbnN0cnVjdG9yLm5hbWV9LXNldHVwS2VybmVscyBpcyBub3QgeWV0IGltcGxlbWVudGVkYFxuICAgICAgICAvLyApXG4gICAgfVxuICAgIHJldXNlS2VybmVscygpIHtcbiAgICAgICAgLy8gdGhyb3cgbmV3IEVycm9yKFxuICAgICAgICAvLyAgIGAke3RoaXMuY29uc3RydWN0b3IubmFtZX0tcmV1c2VLZXJuZWxzIGlzIG5vdCB5ZXQgaW1wbGVtZW50ZWRgXG4gICAgICAgIC8vIClcbiAgICB9XG4gICAgcHJlZGljdCgpIHtcbiAgICAgICAgLy8gdGhyb3cgbmV3IEVycm9yKGAke3RoaXMuY29uc3RydWN0b3IubmFtZX0tcHJlZGljdCBpcyBub3QgeWV0IGltcGxlbWVudGVkYClcbiAgICB9XG4gICAgY29tcGFyZSgpIHtcbiAgICAgICAgLy8gdGhyb3cgbmV3IEVycm9yKGAke3RoaXMuY29uc3RydWN0b3IubmFtZX0tY29tcGFyZSBpcyBub3QgeWV0IGltcGxlbWVudGVkYClcbiAgICB9XG4gICAgbGVhcm4obGVhcm5pbmdSYXRlKSB7XG4gICAgICAgIGNvbnN0IHsgd2VpZ2h0czogb2xkV2VpZ2h0cyB9ID0gdGhpcztcbiAgICAgICAgdGhpcy53ZWlnaHRzID0gdGhpcy5wcmF4aXMucnVuKHRoaXMsIGxlYXJuaW5nUmF0ZSk7XG4gICAgICAgIC8vIHRoaXMuZGVsdGFzID0gZGVsdGFzO1xuICAgICAgICByZWxlYXNlKG9sZFdlaWdodHMpO1xuICAgICAgICBjbGVhcih0aGlzLmRlbHRhcyk7XG4gICAgfVxufVxuZnVuY3Rpb24gcmVjdXJyZW50WmVyb3MoKSB7XG4gICAgcmV0dXJuIG5ldyBSZWN1cnJlbnRaZXJvcygpO1xufVxuXG5mdW5jdGlvbiBwcmVkaWN0MkQkMShpbnB1dHMpIHtcbiAgICByZXR1cm4gYWN0aXZhdGUkMyhpbnB1dHNbdGhpcy50aHJlYWQueV1bdGhpcy50aHJlYWQueF0pO1xufVxuZnVuY3Rpb24gY29tcGFyZTJEJDEod2VpZ2h0cywgZGVsdGFzKSB7XG4gICAgcmV0dXJuIG1lYXN1cmUkMyh3ZWlnaHRzW3RoaXMudGhyZWFkLnldW3RoaXMudGhyZWFkLnhdLCBkZWx0YXNbdGhpcy50aHJlYWQueV1bdGhpcy50aHJlYWQueF0pO1xufVxuZnVuY3Rpb24gcHJlZGljdDNEJDEoaW5wdXRzKSB7XG4gICAgcmV0dXJuIGFjdGl2YXRlJDMoaW5wdXRzW3RoaXMudGhyZWFkLnpdW3RoaXMudGhyZWFkLnldW3RoaXMudGhyZWFkLnhdKTtcbn1cbmZ1bmN0aW9uIGNvbXBhcmUzRCQxKHdlaWdodHMsIGRlbHRhcykge1xuICAgIHJldHVybiBtZWFzdXJlJDMod2VpZ2h0c1t0aGlzLnRocmVhZC56XVt0aGlzLnRocmVhZC55XVt0aGlzLnRocmVhZC54XSwgZGVsdGFzW3RoaXMudGhyZWFkLnpdW3RoaXMudGhyZWFkLnldW3RoaXMudGhyZWFkLnhdKTtcbn1cbmNsYXNzIFJlbHUgZXh0ZW5kcyBBY3RpdmF0aW9uIHtcbiAgICBzZXR1cEtlcm5lbHMoKSB7XG4gICAgICAgIGNvbnN0IHsgd2lkdGgsIGhlaWdodCwgZGVwdGggfSA9IHRoaXMuaW5wdXRMYXllcjtcbiAgICAgICAgaWYgKGRlcHRoID4gMCkge1xuICAgICAgICAgICAgdGhpcy5wcmVkaWN0S2VybmVsID0gbWFrZUtlcm5lbChwcmVkaWN0M0QkMSwge1xuICAgICAgICAgICAgICAgIG91dHB1dDogW3dpZHRoLCBoZWlnaHQsIGRlcHRoXSxcbiAgICAgICAgICAgICAgICBmdW5jdGlvbnM6IFthY3RpdmF0ZSQzXSxcbiAgICAgICAgICAgICAgICBpbW11dGFibGU6IHRydWUsXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIHRoaXMuY29tcGFyZUtlcm5lbCA9IG1ha2VLZXJuZWwoY29tcGFyZTNEJDEsIHtcbiAgICAgICAgICAgICAgICBvdXRwdXQ6IFt3aWR0aCwgaGVpZ2h0LCBkZXB0aF0sXG4gICAgICAgICAgICAgICAgZnVuY3Rpb25zOiBbbWVhc3VyZSQzXSxcbiAgICAgICAgICAgICAgICBpbW11dGFibGU6IHRydWUsXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgfVxuICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgIHRoaXMucHJlZGljdEtlcm5lbCA9IG1ha2VLZXJuZWwocHJlZGljdDJEJDEsIHtcbiAgICAgICAgICAgICAgICBvdXRwdXQ6IFt3aWR0aCwgaGVpZ2h0XSxcbiAgICAgICAgICAgICAgICBmdW5jdGlvbnM6IFthY3RpdmF0ZSQzXSxcbiAgICAgICAgICAgICAgICBpbW11dGFibGU6IHRydWUsXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIHRoaXMuY29tcGFyZUtlcm5lbCA9IG1ha2VLZXJuZWwoY29tcGFyZTJEJDEsIHtcbiAgICAgICAgICAgICAgICBvdXRwdXQ6IFt3aWR0aCwgaGVpZ2h0XSxcbiAgICAgICAgICAgICAgICBmdW5jdGlvbnM6IFttZWFzdXJlJDNdLFxuICAgICAgICAgICAgICAgIGltbXV0YWJsZTogdHJ1ZSxcbiAgICAgICAgICAgIH0pO1xuICAgICAgICB9XG4gICAgfVxuICAgIHByZWRpY3QoKSB7XG4gICAgICAgIHJlbGVhc2UodGhpcy53ZWlnaHRzKTtcbiAgICAgICAgdGhpcy53ZWlnaHRzID0gdGhpcy5wcmVkaWN0S2VybmVsKHRoaXMuaW5wdXRMYXllci53ZWlnaHRzKTtcbiAgICAgICAgY2xlYXIodGhpcy5kZWx0YXMpO1xuICAgIH1cbiAgICBjb21wYXJlKCkge1xuICAgICAgICByZWxlYXNlKHRoaXMuaW5wdXRMYXllci5kZWx0YXMpO1xuICAgICAgICB0aGlzLmlucHV0TGF5ZXIuZGVsdGFzID0gdGhpcy5jb21wYXJlS2VybmVsKHRoaXMud2VpZ2h0cywgdGhpcy5kZWx0YXMpO1xuICAgIH1cbn1cbmZ1bmN0aW9uIHJlbHUkMShpbnB1dExheWVyLCBzZXR0aW5ncykge1xuICAgIHJldHVybiBuZXcgUmVsdShpbnB1dExheWVyLCBzZXR0aW5ncyk7XG59XG5cbmZ1bmN0aW9uIHJubkNlbGwoc2V0dGluZ3MsIGlucHV0LCByZWN1cnJlbnRJbnB1dCkge1xuICAgIGNvbnN0IHsgaGVpZ2h0IH0gPSBzZXR0aW5ncztcbiAgICBpZiAodHlwZW9mIGhlaWdodCAhPT0gJ251bWJlcicpXG4gICAgICAgIHRocm93IG5ldyBFcnJvcignaGVpZ2h0IG5vdCBzZXQnKTtcbiAgICBpZiAocmVjdXJyZW50SW5wdXQuc2V0RGltZW5zaW9ucykge1xuICAgICAgICByZWN1cnJlbnRJbnB1dC5zZXREaW1lbnNpb25zKDEsIGhlaWdodCk7XG4gICAgfVxuICAgIC8vIHd4aFxuICAgIGNvbnN0IHdlaWdodCA9IHJhbmRvbSh7XG4gICAgICAgIGlkOiAnd2VpZ2h0JyxcbiAgICAgICAgaGVpZ2h0LFxuICAgICAgICB3aWR0aDogaW5wdXQuaGVpZ2h0LFxuICAgICAgICBzdGQ6IDAuMDgsXG4gICAgfSk7XG4gICAgLy8gd2hoXG4gICAgY29uc3QgdHJhbnNpdGlvbiA9IHJhbmRvbSh7XG4gICAgICAgIGlkOiAndHJhbnNpdGlvbicsXG4gICAgICAgIGhlaWdodCxcbiAgICAgICAgd2lkdGg6IGhlaWdodCxcbiAgICAgICAgc3RkOiAwLjA4LFxuICAgIH0pO1xuICAgIC8vIGJoaFxuICAgIGNvbnN0IGJpYXMgPSB6ZXJvcyh7IGlkOiAnYmlhcycsIGhlaWdodCB9KTtcbiAgICByZXR1cm4gcmVsdSQxKGFkZCQxKGFkZCQxKG11bHRpcGx5JDEod2VpZ2h0LCBpbnB1dCksIG11bHRpcGx5JDEodHJhbnNpdGlvbiwgcmVjdXJyZW50SW5wdXQpKSwgYmlhcykpO1xufVxuXG5jbGFzcyBSZWdyZXNzaW9uIGV4dGVuZHMgQmFzZUxheWVyIHtcbiAgICBjb25zdHJ1Y3RvcihzZXR0aW5ncywgaW5wdXRMYXllcikge1xuICAgICAgICBzdXBlcihzZXR0aW5ncyk7XG4gICAgICAgIHRoaXMuaW5wdXRMYXllciA9IGlucHV0TGF5ZXI7XG4gICAgICAgIHRoaXMudmFsaWRhdGUoKTtcbiAgICB9XG4gICAgcHJlZGljdCgpIHtcbiAgICAgICAgcmVsZWFzZSh0aGlzLndlaWdodHMpO1xuICAgICAgICB0aGlzLndlaWdodHMgPSBjbG9uZSh0aGlzLmlucHV0TGF5ZXIud2VpZ2h0cyk7XG4gICAgfVxuICAgIGxlYXJuKCkge1xuICAgICAgICAvLyB0aHJvdyBuZXcgRXJyb3IoYCR7dGhpcy5jb25zdHJ1Y3Rvci5uYW1lfS1sZWFybiBpcyBub3QgeWV0IGltcGxlbWVudGVkYClcbiAgICB9XG59XG4vLyBUT0RPOiBoYW5kbGUgYGxvc3MgKz0gMC41KmR5KmR5O2AgdG90YWwgYW5kIHN1bSBpbiBsZWFyblxuZnVuY3Rpb24gcmVncmVzc2lvbihzZXR0aW5ncywgaW5wdXRMYXllcikge1xuICAgIHJldHVybiBuZXcgUmVncmVzc2lvbihzZXR0aW5ncywgaW5wdXRMYXllcik7XG59XG5cbmZ1bmN0aW9uIGdldE1heFZhbHVlMkQoaW5wdXRzKSB7XG4gICAgbGV0IG1heElucHV0ID0gLUluZmluaXR5O1xuICAgIGZvciAobGV0IHkgPSAwOyB5IDwgdGhpcy5jb25zdGFudHMuaW5wdXRIZWlnaHQ7IHkrKykge1xuICAgICAgICBmb3IgKGxldCB4ID0gMDsgeCA8IHRoaXMuY29uc3RhbnRzLmlucHV0V2lkdGg7IHgrKykge1xuICAgICAgICAgICAgY29uc3QgaW5wdXQgPSBpbnB1dHNbeV1beF07XG4gICAgICAgICAgICBpZiAoaW5wdXQgPiBtYXhJbnB1dCkge1xuICAgICAgICAgICAgICAgIG1heElucHV0ID0gaW5wdXQ7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9XG4gICAgcmV0dXJuIG1heElucHV0O1xufVxuZnVuY3Rpb24gZ2V0TWF4VmFsdWUzRChpbnB1dHMpIHtcbiAgICBsZXQgbWF4SW5wdXQgPSAtSW5maW5pdHk7XG4gICAgZm9yIChsZXQgeiA9IDA7IHogPCB0aGlzLmNvbnN0YW50cy5pbnB1dERlcHRoOyB6KyspIHtcbiAgICAgICAgZm9yIChsZXQgeSA9IDA7IHkgPCB0aGlzLmNvbnN0YW50cy5pbnB1dEhlaWdodDsgeSsrKSB7XG4gICAgICAgICAgICBmb3IgKGxldCB4ID0gMDsgeCA8IHRoaXMuY29uc3RhbnRzLmlucHV0V2lkdGg7IHgrKykge1xuICAgICAgICAgICAgICAgIGNvbnN0IGlucHV0ID0gaW5wdXRzW3pdW3ldW3hdO1xuICAgICAgICAgICAgICAgIGlmIChpbnB1dCA+IG1heElucHV0KSB7XG4gICAgICAgICAgICAgICAgICAgIG1heElucHV0ID0gaW5wdXQ7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfVxuICAgIHJldHVybiBtYXhJbnB1dDtcbn1cbmZ1bmN0aW9uIGdldFN1bTJEKGlucHV0cykge1xuICAgIGxldCBzdW0gPSAwO1xuICAgIGZvciAobGV0IHkgPSAwOyB5IDwgdGhpcy5jb25zdGFudHMuaW5wdXRIZWlnaHQ7IHkrKykge1xuICAgICAgICBmb3IgKGxldCB4ID0gMDsgeCA8IHRoaXMuY29uc3RhbnRzLmlucHV0V2lkdGg7IHgrKykge1xuICAgICAgICAgICAgc3VtICs9IGlucHV0c1t5XVt4XTtcbiAgICAgICAgfVxuICAgIH1cbiAgICByZXR1cm4gc3VtO1xufVxuZnVuY3Rpb24gZ2V0U3VtM0QoaW5wdXRzKSB7XG4gICAgbGV0IHN1bSA9IDA7XG4gICAgZm9yIChsZXQgeiA9IDA7IHogPCB0aGlzLmNvbnN0YW50cy5pbnB1dERlcHRoOyB6KyspIHtcbiAgICAgICAgZm9yIChsZXQgeSA9IDA7IHkgPCB0aGlzLmNvbnN0YW50cy5pbnB1dEhlaWdodDsgeSsrKSB7XG4gICAgICAgICAgICBmb3IgKGxldCB4ID0gMDsgeCA8IHRoaXMuY29uc3RhbnRzLmlucHV0V2lkdGg7IHgrKykge1xuICAgICAgICAgICAgICAgIHN1bSArPSBpbnB1dHNbel1beV1beF07XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9XG4gICAgcmV0dXJuIHN1bTtcbn1cbmZ1bmN0aW9uIGdldEV4cG9uZW50aWFscyhpbnB1dHMsIG1heElucHV0KSB7XG4gICAgcmV0dXJuIE1hdGguZXhwKGlucHV0c1t0aGlzLnRocmVhZC54XSAtIG1heElucHV0WzBdKTtcbn1cbmZ1bmN0aW9uIGdldEV4cG9uZW50aWFsczNEKGlucHV0cywgbWF4SW5wdXQpIHtcbiAgICByZXR1cm4gTWF0aC5leHAoaW5wdXRzW3RoaXMudGhyZWFkLnpdW3RoaXMudGhyZWFkLnldW3RoaXMudGhyZWFkLnhdIC0gbWF4SW5wdXRbMF0pO1xufVxuZnVuY3Rpb24gcHJlZGljdDJEKGV4cG9uZW50aWFscywgZXhwb25lbnRpYWxzU3VtKSB7XG4gICAgcmV0dXJuIGV4cG9uZW50aWFsc1t0aGlzLnRocmVhZC55XVt0aGlzLnRocmVhZC54XSAvIGV4cG9uZW50aWFsc1N1bVswXTtcbn1cbmZ1bmN0aW9uIHByZWRpY3QzRChleHBvbmVudGlhbHMsIGV4cG9uZW50aWFsc1N1bSkge1xuICAgIHJldHVybiAoZXhwb25lbnRpYWxzW3RoaXMudGhyZWFkLnpdW3RoaXMudGhyZWFkLnldW3RoaXMudGhyZWFkLnhdIC9cbiAgICAgICAgZXhwb25lbnRpYWxzU3VtWzBdKTtcbn1cbmZ1bmN0aW9uIGNvbXBhcmUyRCh0YXJnZXQsIGV4cG9uZW50aWFscykge1xuICAgIGxldCBpbmRpY2F0b3IgPSAwO1xuICAgIGNvbnN0IGluZGV4ID0gdGhpcy50aHJlYWQueCArIHRoaXMudGhyZWFkLnkgKiB0aGlzLm91dHB1dC54O1xuICAgIGlmIChpbmRleCA9PT0gdGFyZ2V0KSB7XG4gICAgICAgIGluZGljYXRvciA9IDE7XG4gICAgfVxuICAgIHJldHVybiAtKGluZGljYXRvciAtIGV4cG9uZW50aWFsc1t0aGlzLnRocmVhZC55XVt0aGlzLnRocmVhZC54XSk7XG59XG5mdW5jdGlvbiBjb21wYXJlM0QodGFyZ2V0LCBleHBvbmVudGlhbHMpIHtcbiAgICBsZXQgaW5kaWNhdG9yID0gMDtcbiAgICBjb25zdCBpbmRleCA9IHRoaXMudGhyZWFkLnggK1xuICAgICAgICB0aGlzLnRocmVhZC55ICogdGhpcy5vdXRwdXQueCArXG4gICAgICAgIHRoaXMudGhyZWFkLnogKiB0aGlzLm91dHB1dC54ICogdGhpcy5vdXRwdXQueTtcbiAgICBpZiAoaW5kZXggPT09IHRhcmdldCkge1xuICAgICAgICBpbmRpY2F0b3IgPSAxO1xuICAgIH1cbiAgICByZXR1cm4gLShpbmRpY2F0b3IgLSBleHBvbmVudGlhbHNbdGhpcy50aHJlYWQuel1bdGhpcy50aHJlYWQueV1bdGhpcy50aHJlYWQueF0pO1xufVxuLy8gVE9ETzogaGFuZGxlOiBgcmV0dXJuIC1NYXRoLmxvZyh0aGlzLmVzW3ldKTtgIGluIGxlYXJuXG5jbGFzcyBTb2Z0TWF4IGV4dGVuZHMgTW9kaWZpZXIge1xuICAgIGNvbnN0cnVjdG9yKGlucHV0TGF5ZXIsIHNldHRpbmdzKSB7XG4gICAgICAgIHN1cGVyKGlucHV0TGF5ZXIsIHNldHRpbmdzKTtcbiAgICAgICAgdGhpcy5lcnJvcnMgPSBudWxsO1xuICAgICAgICB0aGlzLmdldEV4cG9uZW50aWFsc0tlcm5lbCA9IG51bGw7XG4gICAgICAgIHRoaXMuZ2V0TWF4VmFsdWVLZXJuZWwgPSBudWxsO1xuICAgICAgICB0aGlzLmdldFN1bUtlcm5lbCA9IG51bGw7XG4gICAgICAgIHRoaXMudmFsaWRhdGUoKTtcbiAgICAgICAgaWYgKHRoaXMuZGVwdGggPiAwKSB7XG4gICAgICAgICAgICB0aGlzLndlaWdodHMgPSByYW5kb3MzRCh0aGlzLndpZHRoLCB0aGlzLmhlaWdodCwgdGhpcy5kZXB0aCk7XG4gICAgICAgICAgICB0aGlzLmRlbHRhcyA9IHplcm9zM0QodGhpcy53aWR0aCwgdGhpcy5oZWlnaHQsIHRoaXMuZGVwdGgpO1xuICAgICAgICB9XG4gICAgICAgIGVsc2UgaWYgKHRoaXMuaGVpZ2h0ID4gMCkge1xuICAgICAgICAgICAgdGhpcy53ZWlnaHRzID0gcmFuZG9zMkQodGhpcy53aWR0aCwgdGhpcy5oZWlnaHQpO1xuICAgICAgICAgICAgdGhpcy5kZWx0YXMgPSB6ZXJvczJEKHRoaXMud2lkdGgsIHRoaXMuaGVpZ2h0KTtcbiAgICAgICAgfVxuICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgIHRoaXMud2VpZ2h0cyA9IHJhbmRvcyh0aGlzLndpZHRoKTtcbiAgICAgICAgICAgIHRoaXMuZGVsdGFzID0gemVyb3MkMSh0aGlzLndpZHRoKTtcbiAgICAgICAgfVxuICAgIH1cbiAgICBzZXR1cEtlcm5lbHMoKSB7XG4gICAgICAgIGNvbnN0IHsgd2lkdGgsIGhlaWdodCwgZGVwdGggfSA9IHRoaXM7XG4gICAgICAgIGlmIChkZXB0aCA+IDApIHtcbiAgICAgICAgICAgIHRoaXMuZ2V0RXhwb25lbnRpYWxzS2VybmVsID0gbWFrZUtlcm5lbChnZXRFeHBvbmVudGlhbHMzRCwge1xuICAgICAgICAgICAgICAgIG91dHB1dDogW3dpZHRoLCBoZWlnaHQsIGRlcHRoXSxcbiAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgdGhpcy5nZXRNYXhWYWx1ZUtlcm5lbCA9IG1ha2VLZXJuZWwoZ2V0TWF4VmFsdWUzRCwge1xuICAgICAgICAgICAgICAgIG91dHB1dDogWzEsIDEsIDFdLFxuICAgICAgICAgICAgICAgIGNvbnN0YW50czoge1xuICAgICAgICAgICAgICAgICAgICBpbnB1dFdpZHRoOiB3aWR0aCxcbiAgICAgICAgICAgICAgICAgICAgaW5wdXRIZWlnaHQ6IGhlaWdodCxcbiAgICAgICAgICAgICAgICAgICAgaW5wdXREZXB0aDogZGVwdGgsXG4gICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgdGhpcy5nZXRTdW1LZXJuZWwgPSBtYWtlS2VybmVsKGdldFN1bTNELCB7XG4gICAgICAgICAgICAgICAgb3V0cHV0OiBbMSwgMSwgMV0sXG4gICAgICAgICAgICAgICAgY29uc3RhbnRzOiB7XG4gICAgICAgICAgICAgICAgICAgIGlucHV0V2lkdGg6IHdpZHRoLFxuICAgICAgICAgICAgICAgICAgICBpbnB1dEhlaWdodDogaGVpZ2h0LFxuICAgICAgICAgICAgICAgICAgICBpbnB1dERlcHRoOiBkZXB0aCxcbiAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICB0aGlzLnByZWRpY3RLZXJuZWwgPSBtYWtlS2VybmVsKHByZWRpY3QzRCwge1xuICAgICAgICAgICAgICAgIG91dHB1dDogW3dpZHRoLCBoZWlnaHQsIGRlcHRoXSxcbiAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgdGhpcy5jb21wYXJlS2VybmVsID0gbWFrZUtlcm5lbChjb21wYXJlM0QsIHtcbiAgICAgICAgICAgICAgICBvdXRwdXQ6IFt3aWR0aCwgaGVpZ2h0LCBkZXB0aF0sXG4gICAgICAgICAgICAgICAgaW1tdXRhYmxlOiB0cnVlLFxuICAgICAgICAgICAgfSk7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICB0aGlzLmdldEV4cG9uZW50aWFsc0tlcm5lbCA9IG1ha2VLZXJuZWwoZ2V0RXhwb25lbnRpYWxzLCB7XG4gICAgICAgICAgICAgICAgb3V0cHV0OiBbd2lkdGgsIGhlaWdodF0sXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIHRoaXMuZ2V0TWF4VmFsdWVLZXJuZWwgPSBtYWtlS2VybmVsKGdldE1heFZhbHVlMkQsIHtcbiAgICAgICAgICAgICAgICBvdXRwdXQ6IFsxLCAxXSxcbiAgICAgICAgICAgICAgICBjb25zdGFudHM6IHtcbiAgICAgICAgICAgICAgICAgICAgaW5wdXRXaWR0aDogd2lkdGgsXG4gICAgICAgICAgICAgICAgICAgIGlucHV0SGVpZ2h0OiBoZWlnaHQsXG4gICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgdGhpcy5nZXRTdW1LZXJuZWwgPSBtYWtlS2VybmVsKGdldFN1bTJELCB7XG4gICAgICAgICAgICAgICAgb3V0cHV0OiBbMSwgMV0sXG4gICAgICAgICAgICAgICAgY29uc3RhbnRzOiB7XG4gICAgICAgICAgICAgICAgICAgIGlucHV0V2lkdGg6IHdpZHRoLFxuICAgICAgICAgICAgICAgICAgICBpbnB1dEhlaWdodDogaGVpZ2h0LFxuICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIHRoaXMucHJlZGljdEtlcm5lbCA9IG1ha2VLZXJuZWwocHJlZGljdDJELCB7XG4gICAgICAgICAgICAgICAgb3V0cHV0OiBbd2lkdGgsIGhlaWdodF0sXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIHRoaXMuY29tcGFyZUtlcm5lbCA9IG1ha2VLZXJuZWwoY29tcGFyZTJELCB7XG4gICAgICAgICAgICAgICAgb3V0cHV0OiBbd2lkdGgsIGhlaWdodF0sXG4gICAgICAgICAgICAgICAgaW1tdXRhYmxlOiB0cnVlLFxuICAgICAgICAgICAgfSk7XG4gICAgICAgIH1cbiAgICB9XG4gICAgcHJlZGljdCgpIHtcbiAgICAgICAgY29uc3QgbWF4VmFsdWUgPSB0aGlzLmdldE1heFZhbHVlS2VybmVsKHRoaXMuaW5wdXRMYXllci53ZWlnaHRzKTtcbiAgICAgICAgY29uc3QgZXhwb25lbnRpYWxzID0gdGhpcy5nZXRFeHBvbmVudGlhbHNLZXJuZWwodGhpcy5pbnB1dExheWVyLndlaWdodHMsIG1heFZhbHVlKTtcbiAgICAgICAgY29uc3QgZXhwb25lbnRpYWxzU3VtID0gdGhpcy5nZXRTdW1LZXJuZWwoZXhwb25lbnRpYWxzKTtcbiAgICAgICAgdGhpcy53ZWlnaHRzID0gdGhpcy5wcmVkaWN0S2VybmVsKGV4cG9uZW50aWFscywgZXhwb25lbnRpYWxzU3VtKTtcbiAgICB9XG4gICAgY29tcGFyZSh0YXJnZXRWYWx1ZXMpIHtcbiAgICAgICAgY29uc3QgeyBkZWx0YXMsIGVycm9ycyB9ID0gdGhpcztcbiAgICAgICAgdGhpcy5lcnJvcnMgPSB0aGlzLmNvbXBhcmVLZXJuZWwodGFyZ2V0VmFsdWVzWzBdLCBkZWx0YXMpO1xuICAgICAgICB0aGlzLmRlbHRhcyA9IGNsb25lKHRoaXMuZXJyb3JzKTtcbiAgICAgICAgcmVsZWFzZShkZWx0YXMpO1xuICAgICAgICByZWxlYXNlKGVycm9ycyk7XG4gICAgICAgIGNvbnN0IGlucHV0TGF5ZXJEZWx0YXMgPSB0aGlzLmlucHV0TGF5ZXIuZGVsdGFzO1xuICAgICAgICB0aGlzLmlucHV0TGF5ZXIuZGVsdGFzID0gY2xvbmUodGhpcy5kZWx0YXMpO1xuICAgICAgICByZWxlYXNlKGlucHV0TGF5ZXJEZWx0YXMpO1xuICAgIH1cbn1cbmZ1bmN0aW9uIHNvZnRNYXgoaW5wdXRMYXllciwgc2V0dGluZ3MpIHtcbiAgICByZXR1cm4gbmV3IFNvZnRNYXgoaW5wdXRMYXllciwgc2V0dGluZ3MpO1xufVxuXG5jbGFzcyBTVk0gZXh0ZW5kcyBCYXNlTGF5ZXIge1xuICAgIGNvbnN0cnVjdG9yKGlucHV0TGF5ZXIsIHNldHRpbmdzKSB7XG4gICAgICAgIHN1cGVyKHNldHRpbmdzKTtcbiAgICAgICAgdGhpcy5pbnB1dExheWVyID0gaW5wdXRMYXllcjtcbiAgICB9XG4gICAgcHJlZGljdCgpIHtcbiAgICAgICAgcmVsZWFzZSh0aGlzLndlaWdodHMpO1xuICAgICAgICB0aGlzLndlaWdodHMgPSBjbG9uZSh0aGlzLmlucHV0TGF5ZXIud2VpZ2h0cyk7XG4gICAgICAgIHRoaXMudmFsaWRhdGUoKTtcbiAgICB9XG4gICAgbGVhcm4oKSB7XG4gICAgICAgIC8vIHRocm93IG5ldyBFcnJvcihgJHt0aGlzLmNvbnN0cnVjdG9yLm5hbWV9LWxlYXJuIGlzIG5vdCB5ZXQgaW1wbGVtZW50ZWRgKVxuICAgIH1cbn1cbi8vIGZ1bmN0aW9uIGxlYXJuKHRhcmdldCkge1xuLy8gICBpZiAoeSA9PT0gaSkge1xuLy8gICAgIGNvbnRpbnVlO1xuLy8gICB9XG4vLyAgIGNvbnN0IHlkaWZmID0gLXlzY29yZSArIHgud1tpXSArIG1hcmdpbjtcbi8vICAgaWYgKHlkaWZmID4gMCkge1xuLy8gICAgIC8vIHZpb2xhdGluZyBkaW1lbnNpb24sIGFwcGx5IGxvc3Ncbi8vICAgICB4LmR3W2ldICs9IDE7XG4vLyAgICAgeC5kd1t5XSAtPSAxO1xuLy8gICAgIGxvc3MgKz0geWRpZmY7XG4vLyAgIH1cbi8vIH1cbmZ1bmN0aW9uIHN2bShpbnB1dExheWVyLCBzZXR0aW5ncykge1xuICAgIHJldHVybiBuZXcgU1ZNKGlucHV0TGF5ZXIsIHNldHRpbmdzKTtcbn1cblxuZnVuY3Rpb24gcHJlZGljdCh2YWx1ZSkge1xuICAgIHJldHVybiB2YWx1ZVt0aGlzLnRocmVhZC54XVt0aGlzLnRocmVhZC55XTtcbn1cbmNvbnN0IGNvbXBhcmUgPSBwcmVkaWN0O1xuY2xhc3MgVHJhbnNwb3NlIGV4dGVuZHMgTW9kaWZpZXIge1xuICAgIGdldCB3aWR0aCgpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuaW5wdXRMYXllci5oZWlnaHQ7XG4gICAgfVxuICAgIGdldCBoZWlnaHQoKSB7XG4gICAgICAgIHJldHVybiB0aGlzLmlucHV0TGF5ZXIud2lkdGg7XG4gICAgfVxuICAgIGNvbnN0cnVjdG9yKGlucHV0TGF5ZXIpIHtcbiAgICAgICAgc3VwZXIoaW5wdXRMYXllcik7XG4gICAgICAgIHRoaXMudmFsaWRhdGUoKTtcbiAgICB9XG4gICAgc2V0dXBLZXJuZWxzKCkge1xuICAgICAgICB0aGlzLnByZWRpY3RLZXJuZWwgPSBtYWtlS2VybmVsKHByZWRpY3QsIHtcbiAgICAgICAgICAgIG91dHB1dDogW3RoaXMuaGVpZ2h0LCB0aGlzLndpZHRoXSxcbiAgICAgICAgfSk7XG4gICAgICAgIHRoaXMuY29tcGFyZUtlcm5lbCA9IG1ha2VLZXJuZWwoY29tcGFyZSwge1xuICAgICAgICAgICAgb3V0cHV0OiBbdGhpcy53aWR0aCwgdGhpcy5oZWlnaHRdLFxuICAgICAgICB9KTtcbiAgICB9XG4gICAgcHJlZGljdCgpIHtcbiAgICAgICAgdGhpcy53ZWlnaHRzID0gdGhpcy5wcmVkaWN0S2VybmVsKHRoaXMuaW5wdXRMYXllci53ZWlnaHRzKTtcbiAgICAgICAgY2xlYXIodGhpcy5kZWx0YXMpO1xuICAgIH1cbiAgICBjb21wYXJlKCkge1xuICAgICAgICB0aGlzLmlucHV0TGF5ZXIuZGVsdGFzID0gdGhpcy5jb21wYXJlS2VybmVsKHRoaXMuZGVsdGFzKTtcbiAgICB9XG59XG5mdW5jdGlvbiB0cmFuc3Bvc2UoaW5wdXRMYXllcikge1xuICAgIHJldHVybiBuZXcgVHJhbnNwb3NlKGlucHV0TGF5ZXIpO1xufVxuXG5jb25zdCBsYXllclR5cGVzID0ge1xuICAgIEFjdGl2YXRpb24sXG4gICAgSW50ZXJuYWwsXG4gICAgSW50ZXJuYWxNb2RlbCxcbiAgICBFbnRyeVBvaW50LFxuICAgIEZpbHRlcixcbiAgICBNb2RlbCxcbiAgICBNb2RpZmllcixcbiAgICBPcGVyYXRvcixcbiAgICBUYXJnZXQsXG59O1xuXG52YXIgbGF5ZXIgPSAvKiNfX1BVUkVfXyovT2JqZWN0LmZyZWV6ZSh7XG4gICAgX19wcm90b19fOiBudWxsLFxuICAgIGxheWVyVHlwZXM6IGxheWVyVHlwZXMsXG4gICAgQWRkOiBBZGQsXG4gICAgYWRkOiBhZGQkMSxcbiAgICBhcnRodXJGZWVkRm9yd2FyZDogYXJ0aHVyRmVlZEZvcndhcmQsXG4gICAgQmFzZUxheWVyOiBCYXNlTGF5ZXIsXG4gICAgYmFzZUxheWVyRGVmYXVsdFNldHRpbmdzOiBiYXNlTGF5ZXJEZWZhdWx0U2V0dGluZ3MsXG4gICAgQ29udm9sdXRpb246IENvbnZvbHV0aW9uLFxuICAgIGNvbnZvbHV0aW9uOiBjb252b2x1dGlvbixcbiAgICBEcm9wb3V0OiBEcm9wb3V0LFxuICAgIGRyb3BvdXQ6IGRyb3BvdXQsXG4gICAgZmVlZEZvcndhcmQ6IGZlZWRGb3J3YXJkLFxuICAgIEZ1bGx5Q29ubmVjdGVkOiBGdWxseUNvbm5lY3RlZCxcbiAgICBmdWxseUNvbm5lY3RlZDogZnVsbHlDb25uZWN0ZWQsXG4gICAgZ3J1OiBncnUsXG4gICAgSW5wdXQ6IElucHV0LFxuICAgIGlucHV0OiBpbnB1dCxcbiAgICBMZWFreVJlbHU6IExlYWt5UmVsdSxcbiAgICBsZWFreVJlbHU6IGxlYWt5UmVsdSxcbiAgICBsc3RtQ2VsbDogbHN0bUNlbGwsXG4gICAgTXVsdGlwbHk6IE11bHRpcGx5LFxuICAgIG11bHRpcGx5OiBtdWx0aXBseSQxLFxuICAgIE11bHRpcGx5RWxlbWVudDogTXVsdGlwbHlFbGVtZW50LFxuICAgIG11bHRpcGx5RWxlbWVudDogbXVsdGlwbHlFbGVtZW50JDEsXG4gICAgTmVnYXRpdmU6IE5lZ2F0aXZlLFxuICAgIG5lZ2F0aXZlOiBuZWdhdGl2ZSxcbiAgICBPbmVzOiBPbmVzLFxuICAgIG9uZXM6IG9uZXMsXG4gICAgb3V0cHV0OiBvdXRwdXQsXG4gICAgUG9vbDogUG9vbCxcbiAgICBwb29sOiBwb29sLFxuICAgIFJhbmRvbTogUmFuZG9tLFxuICAgIHJhbmRvbTogcmFuZG9tLFxuICAgIFJlY3VycmVudElucHV0OiBSZWN1cnJlbnRJbnB1dCxcbiAgICBSZWN1cnJlbnRaZXJvczogUmVjdXJyZW50WmVyb3MsXG4gICAgcm5uQ2VsbDogcm5uQ2VsbCxcbiAgICBSZWdyZXNzaW9uOiBSZWdyZXNzaW9uLFxuICAgIHJlZ3Jlc3Npb246IHJlZ3Jlc3Npb24sXG4gICAgUmVsdTogUmVsdSxcbiAgICByZWx1OiByZWx1JDEsXG4gICAgU2lnbW9pZDogU2lnbW9pZCxcbiAgICBzaWdtb2lkOiBzaWdtb2lkJDEsXG4gICAgU29mdE1heDogU29mdE1heCxcbiAgICBzb2Z0TWF4OiBzb2Z0TWF4LFxuICAgIFNWTTogU1ZNLFxuICAgIHN2bTogc3ZtLFxuICAgIFRhbmg6IFRhbmgsXG4gICAgdGFuaDogdGFuaCQxLFxuICAgIFRhcmdldDogVGFyZ2V0LFxuICAgIHRhcmdldDogdGFyZ2V0LFxuICAgIFRyYW5zcG9zZTogVHJhbnNwb3NlLFxuICAgIHRyYW5zcG9zZTogdHJhbnNwb3NlLFxuICAgIFplcm9zOiBaZXJvcyxcbiAgICB6ZXJvczogemVyb3Ncbn0pO1xuXG5jb25zdCBsYXllck5hbWVUeXBlcyA9IE9iamVjdC5rZXlzKGxheWVyKTtcbmZ1bmN0aW9uIGxheWVyRnJvbUpTT04oanNvbkxheWVyLCBpbnB1dExheWVyMSwgaW5wdXRMYXllcjIpIHtcbiAgICBpZiAoIWxheWVyTmFtZVR5cGVzLmZpbmQoKGxheWVyTmFtZVR5cGUpID0+IGxheWVyTmFtZVR5cGUgPT09IGpzb25MYXllci50eXBlKSkge1xuICAgICAgICByZXR1cm4gbnVsbDtcbiAgICB9XG4gICAgY29uc3QgTGF5ZXIgPSBsYXllcltqc29uTGF5ZXIudHlwZV07XG4gICAgaWYgKExheWVyLnByb3RvdHlwZSBpbnN0YW5jZW9mIGxheWVyVHlwZXMuRmlsdGVyKSB7XG4gICAgICAgIGlmICghaW5wdXRMYXllcjEpXG4gICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ2lucHV0TGF5ZXIgbWlzc2luZycpO1xuICAgICAgICByZXR1cm4gbmV3IExheWVyKGpzb25MYXllciwgaW5wdXRMYXllcjEpO1xuICAgIH1cbiAgICBlbHNlIGlmIChMYXllci5wcm90b3R5cGUgaW5zdGFuY2VvZiBsYXllclR5cGVzLkFjdGl2YXRpb24gfHxcbiAgICAgICAgTGF5ZXIucHJvdG90eXBlIGluc3RhbmNlb2YgbGF5ZXJUeXBlcy5Nb2RpZmllcikge1xuICAgICAgICBpZiAoIWlucHV0TGF5ZXIxKVxuICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdpbnB1dExheWVyIG1pc3NpbmcnKTtcbiAgICAgICAgcmV0dXJuIG5ldyBMYXllcihpbnB1dExheWVyMSwganNvbkxheWVyKTtcbiAgICB9XG4gICAgZWxzZSBpZiAoTGF5ZXIucHJvdG90eXBlIGluc3RhbmNlb2YgbGF5ZXJUeXBlcy5JbnRlcm5hbCkge1xuICAgICAgICByZXR1cm4gbmV3IExheWVyKGpzb25MYXllcik7XG4gICAgfVxuICAgIGVsc2UgaWYgKExheWVyLnByb3RvdHlwZSBpbnN0YW5jZW9mIGxheWVyVHlwZXMuT3BlcmF0b3IpIHtcbiAgICAgICAgaWYgKCFpbnB1dExheWVyMSlcbiAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcignaW5wdXRMYXllcjEgbWlzc2luZycpO1xuICAgICAgICBpZiAoIWlucHV0TGF5ZXIyKVxuICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdpbnB1dExheWVyMiBtaXNzaW5nJyk7XG4gICAgICAgIHJldHVybiBuZXcgTGF5ZXIoaW5wdXRMYXllcjEsIGlucHV0TGF5ZXIyLCBqc29uTGF5ZXIpO1xuICAgIH1cbiAgICBlbHNlIGlmIChMYXllci5wcm90b3R5cGUgaW5zdGFuY2VvZiBsYXllclR5cGVzLkludGVybmFsTW9kZWwgfHxcbiAgICAgICAgTGF5ZXIucHJvdG90eXBlIGluc3RhbmNlb2YgbGF5ZXJUeXBlcy5FbnRyeVBvaW50IHx8XG4gICAgICAgIExheWVyLnByb3RvdHlwZSBpbnN0YW5jZW9mIGxheWVyVHlwZXMuTW9kZWwpIHtcbiAgICAgICAgcmV0dXJuIG5ldyBMYXllcihqc29uTGF5ZXIpO1xuICAgIH1cbiAgICBlbHNlIGlmIChMYXllciA9PT0gVGFyZ2V0KSB7XG4gICAgICAgIGlmICghaW5wdXRMYXllcjEpXG4gICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ2lucHV0TGF5ZXIgbWlzc2luZycpO1xuICAgICAgICByZXR1cm4gbmV3IExheWVyKGpzb25MYXllciwgaW5wdXRMYXllcjEpO1xuICAgIH1cbiAgICByZXR1cm4gbnVsbDtcbn1cblxuY2xhc3MgTG9va3VwVGFibGUge1xuICAgIGNvbnN0cnVjdG9yKGRhdGEsIHByb3ApIHtcbiAgICAgICAgdGhpcy5wcm9wID0gbnVsbDtcbiAgICAgICAgdGhpcy50YWJsZSA9IHt9O1xuICAgICAgICB0aGlzLmxlbmd0aCA9IDA7XG4gICAgICAgIGNvbnN0IHRhYmxlID0gdGhpcy50YWJsZTtcbiAgICAgICAgaWYgKHByb3ApIHtcbiAgICAgICAgICAgIHRoaXMucHJvcCA9IHByb3A7XG4gICAgICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IGRhdGEubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgICAgICAgICBjb25zdCBkYXR1bSA9IGRhdGFbaV07XG4gICAgICAgICAgICAgICAgY29uc3Qgb2JqZWN0ID0gZGF0dW1bcHJvcF07XG4gICAgICAgICAgICAgICAgZm9yIChjb25zdCBwIGluIG9iamVjdCkge1xuICAgICAgICAgICAgICAgICAgICBpZiAoIW9iamVjdC5oYXNPd25Qcm9wZXJ0eShwKSlcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnRpbnVlO1xuICAgICAgICAgICAgICAgICAgICBpZiAodGFibGUuaGFzT3duUHJvcGVydHkocCkpXG4gICAgICAgICAgICAgICAgICAgICAgICBjb250aW51ZTtcbiAgICAgICAgICAgICAgICAgICAgdGFibGVbcF0gPSB0aGlzLmxlbmd0aCsrO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBlbHNlIGlmIChBcnJheS5pc0FycmF5KGRhdGEpICYmIEFycmF5LmlzQXJyYXkoZGF0YVswXSkpIHtcbiAgICAgICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgZGF0YS5sZW5ndGg7IGkrKykge1xuICAgICAgICAgICAgICAgIGNvbnN0IGFycmF5ID0gZGF0YVtpXTtcbiAgICAgICAgICAgICAgICBmb3IgKGxldCBqID0gMDsgaiA8IGFycmF5Lmxlbmd0aDsgaisrKSB7XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IG9iamVjdCA9IGFycmF5W2pdO1xuICAgICAgICAgICAgICAgICAgICBmb3IgKGNvbnN0IHAgaW4gb2JqZWN0KSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoIW9iamVjdC5oYXNPd25Qcm9wZXJ0eShwKSlcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb250aW51ZTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmICh0YWJsZS5oYXNPd25Qcm9wZXJ0eShwKSlcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb250aW51ZTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRhYmxlW3BdID0gdGhpcy5sZW5ndGgrKztcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgZGF0YS5sZW5ndGg7IGkrKykge1xuICAgICAgICAgICAgICAgIGNvbnN0IG9iamVjdCA9IGRhdGFbaV07XG4gICAgICAgICAgICAgICAgZm9yIChjb25zdCBwIGluIG9iamVjdCkge1xuICAgICAgICAgICAgICAgICAgICBpZiAoIW9iamVjdC5oYXNPd25Qcm9wZXJ0eShwKSlcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnRpbnVlO1xuICAgICAgICAgICAgICAgICAgICBpZiAodGFibGUuaGFzT3duUHJvcGVydHkocCkpXG4gICAgICAgICAgICAgICAgICAgICAgICBjb250aW51ZTtcbiAgICAgICAgICAgICAgICAgICAgdGFibGVbcF0gPSB0aGlzLmxlbmd0aCsrO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIH1cbn1cblxuY29uc3QgZGVmYXVsdHMkMyA9IHtcbiAgICBsZWFybmluZ1JhdGU6IDAuMyxcbiAgICBiaW5hcnlUaHJlc2g6IDAuNSxcbiAgICBpbml0UHJheGlzOiAobGF5ZXJUZW1wbGF0ZSwgc2V0dGluZ3MpID0+IHtcbiAgICAgICAgdmFyIF9hO1xuICAgICAgICByZXR1cm4gbW9tZW50dW1Sb290TWVhblNxdWFyZWRQcm9wYWdhdGlvbihsYXllclRlbXBsYXRlLCAoX2EgPSBsYXllclRlbXBsYXRlLnNldHRpbmdzLnByYXhpc09wdHMpICE9PSBudWxsICYmIF9hICE9PSB2b2lkIDAgPyBfYSA6IHNldHRpbmdzKTtcbiAgICB9LFxufTtcbmNvbnN0IHRyYWluRGVmYXVsdHMkMyA9IHtcbiAgICBpdGVyYXRpb25zOiAyMDAwMCxcbiAgICBlcnJvclRocmVzaDogMC4wMDUsXG4gICAgbG9nOiBmYWxzZSxcbiAgICBsb2dQZXJpb2Q6IDEwLFxuICAgIGxlYXJuaW5nUmF0ZTogMC4zLFxuICAgIGNhbGxiYWNrUGVyaW9kOiAxMCxcbiAgICBlcnJvckNoZWNrSW50ZXJ2YWw6IDEwMCxcbiAgICB0aW1lb3V0OiBJbmZpbml0eSxcbn07XG5jbGFzcyBGZWVkRm9yd2FyZCB7XG4gICAgY29uc3RydWN0b3Iob3B0aW9ucyA9IHt9KSB7XG4gICAgICAgIHRoaXMudHJhaW5PcHRzID0ge307XG4gICAgICAgIHRoaXMubGF5ZXJzID0gbnVsbDtcbiAgICAgICAgdGhpcy5faW5wdXRMYXllciA9IG51bGw7XG4gICAgICAgIHRoaXMuX2hpZGRlbkxheWVycyA9IG51bGw7XG4gICAgICAgIHRoaXMuX291dHB1dExheWVyID0gbnVsbDtcbiAgICAgICAgdGhpcy5fbW9kZWwgPSBudWxsO1xuICAgICAgICB0aGlzLm1lYW5TcXVhcmVkRXJyb3IgPSBudWxsO1xuICAgICAgICB0aGlzLmlucHV0TG9va3VwID0gbnVsbDtcbiAgICAgICAgdGhpcy5pbnB1dExvb2t1cExlbmd0aCA9IG51bGw7XG4gICAgICAgIHRoaXMub3V0cHV0TG9va3VwID0gbnVsbDtcbiAgICAgICAgdGhpcy5vdXRwdXRMb29rdXBMZW5ndGggPSBudWxsO1xuICAgICAgICB0aGlzLm9wdGlvbnMgPSB7IC4uLmRlZmF1bHRzJDMsIC4uLm9wdGlvbnMgfTtcbiAgICAgICAgdGhpcy5fdXBkYXRlVHJhaW5pbmdPcHRpb25zKHtcbiAgICAgICAgICAgIC4uLnRyYWluRGVmYXVsdHMkMyxcbiAgICAgICAgICAgIC4uLm9wdGlvbnMsXG4gICAgICAgIH0pO1xuICAgIH1cbiAgICBzdGF0aWMgX3ZhbGlkYXRlVHJhaW5pbmdPcHRpb25zKG9wdGlvbnMpIHtcbiAgICAgICAgY29uc3QgeyBpdGVyYXRpb25zLCBlcnJvclRocmVzaCwgbG9nLCBsb2dQZXJpb2QsIGxlYXJuaW5nUmF0ZSwgY2FsbGJhY2ssIGNhbGxiYWNrUGVyaW9kLCB0aW1lb3V0LCB9ID0gb3B0aW9ucztcbiAgICAgICAgY29uc3QgdmFsaWRhdGlvbnMgPSB7XG4gICAgICAgICAgICBpdGVyYXRpb25zOiAoKSA9PiB0eXBlb2YgaXRlcmF0aW9ucyA9PT0gJ251bWJlcicgJiYgaXRlcmF0aW9ucyA+IDAsXG4gICAgICAgICAgICBlcnJvclRocmVzaDogKCkgPT4gdHlwZW9mIGVycm9yVGhyZXNoID09PSAnbnVtYmVyJyAmJiBlcnJvclRocmVzaCA+IDAgJiYgZXJyb3JUaHJlc2ggPCAxLFxuICAgICAgICAgICAgbG9nOiAoKSA9PiB0eXBlb2YgbG9nID09PSAnZnVuY3Rpb24nIHx8IHR5cGVvZiBsb2cgPT09ICdib29sZWFuJyxcbiAgICAgICAgICAgIGxvZ1BlcmlvZDogKCkgPT4gdHlwZW9mIGxvZ1BlcmlvZCA9PT0gJ251bWJlcicgJiYgbG9nUGVyaW9kID4gMCxcbiAgICAgICAgICAgIGxlYXJuaW5nUmF0ZTogKCkgPT4gdHlwZW9mIGxlYXJuaW5nUmF0ZSA9PT0gJ251bWJlcicgJiZcbiAgICAgICAgICAgICAgICBsZWFybmluZ1JhdGUgPiAwICYmXG4gICAgICAgICAgICAgICAgbGVhcm5pbmdSYXRlIDwgMSxcbiAgICAgICAgICAgIGNhbGxiYWNrOiAoKSA9PiB0eXBlb2YgY2FsbGJhY2sgPT09ICdmdW5jdGlvbicgfHwgY2FsbGJhY2sgPT09IG51bGwsXG4gICAgICAgICAgICBjYWxsYmFja1BlcmlvZDogKCkgPT4gdHlwZW9mIGNhbGxiYWNrUGVyaW9kID09PSAnbnVtYmVyJyAmJiBjYWxsYmFja1BlcmlvZCA+IDAsXG4gICAgICAgICAgICB0aW1lb3V0OiAoKSA9PiB0eXBlb2YgdGltZW91dCA9PT0gJ251bWJlcicgJiYgdGltZW91dCA+IDAsXG4gICAgICAgIH07XG4gICAgICAgIE9iamVjdC5rZXlzKHRyYWluRGVmYXVsdHMkMykuZm9yRWFjaCgoa2V5KSA9PiB7XG4gICAgICAgICAgICBpZiAodmFsaWRhdGlvbnMuaGFzT3duUHJvcGVydHkoa2V5KSAmJiAhdmFsaWRhdGlvbnNba2V5XSgpKSB7XG4gICAgICAgICAgICAgICAgY29uc3QgdmFsID0gb3B0aW9uc1trZXldO1xuICAgICAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcihgWyR7a2V5fSwgJHsodmFsICE9PSBudWxsICYmIHZhbCAhPT0gdm9pZCAwID8gdmFsIDogJ3VuZGVmaW5lZCcpLnRvU3RyaW5nKCl9XSBpcyBvdXQgb2Ygbm9ybWFsIHRyYWluaW5nIHJhbmdlLCB5b3VyIG5ldHdvcmsgd2lsbCBwcm9iYWJseSBub3QgdHJhaW4uYCk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH0pO1xuICAgIH1cbiAgICAvKipcbiAgICAgKiBpZiBhIG1ldGhvZCBpcyBwYXNzZWQgaW4gbWV0aG9kIGlzIHVzZWRcbiAgICAgKiBpZiBmYWxzZSBwYXNzZWQgaW4gbm90aGluZyBpcyBsb2dnZWRcbiAgICAgKi9cbiAgICBfc2V0TG9nTWV0aG9kKGxvZykge1xuICAgICAgICBpZiAodHlwZW9mIGxvZyA9PT0gJ2Z1bmN0aW9uJykge1xuICAgICAgICAgICAgdGhpcy50cmFpbk9wdHMubG9nID0gbG9nO1xuICAgICAgICB9XG4gICAgICAgIGVsc2UgaWYgKGxvZykge1xuICAgICAgICAgICAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lXG4gICAgICAgICAgICB0aGlzLnRyYWluT3B0cy5sb2cgPSBjb25zb2xlLmxvZztcbiAgICAgICAgfVxuICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgIHRoaXMudHJhaW5PcHRzLmxvZyA9IGZhbHNlO1xuICAgICAgICB9XG4gICAgfVxuICAgIF91cGRhdGVUcmFpbmluZ09wdGlvbnMob3B0cykge1xuICAgICAgICB2YXIgX2E7XG4gICAgICAgIHRoaXMudHJhaW5PcHRzID0geyAuLi50cmFpbkRlZmF1bHRzJDMsIC4uLnRoaXMudHJhaW5PcHRzLCAuLi5vcHRzIH07XG4gICAgICAgIEZlZWRGb3J3YXJkLl92YWxpZGF0ZVRyYWluaW5nT3B0aW9ucyh0aGlzLnRyYWluT3B0cyk7XG4gICAgICAgIHRoaXMuX3NldExvZ01ldGhvZCgoX2EgPSBvcHRzLmxvZykgIT09IG51bGwgJiYgX2EgIT09IHZvaWQgMCA/IF9hIDogdGhpcy50cmFpbk9wdHMubG9nKTtcbiAgICAgICAgY29uc3QgeyBjYWxsYmFjaywgY2FsbGJhY2tQZXJpb2QsIGVycm9yQ2hlY2tJbnRlcnZhbCB9ID0gdGhpcy50cmFpbk9wdHM7XG4gICAgICAgIGlmIChjYWxsYmFjayAmJiBjYWxsYmFja1BlcmlvZCAhPT0gZXJyb3JDaGVja0ludGVydmFsKSB7XG4gICAgICAgICAgICBjb25zb2xlLndhcm4oYG9wdGlvbnMuY2FsbGJhY2tQZXJpb2Qgd2l0aCB2YWx1ZSBvZiAkeyhjYWxsYmFja1BlcmlvZCAhPT0gbnVsbCAmJiBjYWxsYmFja1BlcmlvZCAhPT0gdm9pZCAwID8gY2FsbGJhY2tQZXJpb2QgOiAndW5kZWZpbmVkJykudG9TdHJpbmcoKX0gZG9lcyBub3QgbWF0Y2ggb3B0aW9ucy5lcnJvckNoZWNrSW50ZXJ2YWwgd2l0aCB2YWx1ZSBvZiAkeyhlcnJvckNoZWNrSW50ZXJ2YWwgIT09IG51bGwgJiYgZXJyb3JDaGVja0ludGVydmFsICE9PSB2b2lkIDAgPyBlcnJvckNoZWNrSW50ZXJ2YWwgOiAndW5kZWZpbmVkJykudG9TdHJpbmcoKX0sIGlmIGxvZ2dpbmcgZXJyb3IsIGl0IHdpbGwgcmVwZWF0LiAgVGhlc2UgdmFsdWVzIG1heSBuZWVkIHRvIG1hdGNoYCk7XG4gICAgICAgIH1cbiAgICB9XG4gICAgX2Nvbm5lY3RPcHRpb25zTGF5ZXJzKCkge1xuICAgICAgICBjb25zdCB7IGlucHV0TGF5ZXJJbmRleCwgb3V0cHV0TGF5ZXJJbmRleCwgbGF5ZXJzIH0gPSB0aGlzLm9wdGlvbnM7XG4gICAgICAgIGlmICghbGF5ZXJzKVxuICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKCd0aGlzLm9wdGlvbnMubGF5ZXJzIGluIHVuZXhwZWN0ZWQgc3RhdGUnKTtcbiAgICAgICAgaWYgKHR5cGVvZiBpbnB1dExheWVySW5kZXggIT09ICdudW1iZXInKVxuICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdpbnB1dExheWVySW5kZXggbm90IGEgbnVtYmVyJyk7XG4gICAgICAgIGlmICh0eXBlb2Ygb3V0cHV0TGF5ZXJJbmRleCAhPT0gJ251bWJlcicpXG4gICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ2lucHV0TGF5ZXJJbmRleCBub3QgYSBudW1iZXInKTtcbiAgICAgICAgY29uc3QgaW5wdXRMYXllciA9IGxheWVyc1tpbnB1dExheWVySW5kZXhdO1xuICAgICAgICBpZiAoIWlucHV0TGF5ZXIpIHtcbiAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcignaW5wdXRMYXllciBub3QgZm91bmQgaW4gdGhpcy5vcHRpb25zLmxheWVycycpO1xuICAgICAgICB9XG4gICAgICAgIGNvbnN0IG91dHB1dExheWVyID0gbGF5ZXJzW291dHB1dExheWVySW5kZXhdO1xuICAgICAgICBpZiAoIW91dHB1dExheWVyKSB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ291dHB1dExheWVyIG5vdCBmb3VuZCBpbiB0aGlzLm9wdGlvbnMubGF5ZXJzJyk7XG4gICAgICAgIH1cbiAgICAgICAgdGhpcy5faW5wdXRMYXllciA9IGlucHV0TGF5ZXI7XG4gICAgICAgIHRoaXMuX2hpZGRlbkxheWVycyA9IGxheWVycy5zbGljZShpbnB1dExheWVySW5kZXgsIG91dHB1dExheWVySW5kZXggLSBpbnB1dExheWVySW5kZXgpO1xuICAgICAgICB0aGlzLl9vdXRwdXRMYXllciA9IG91dHB1dExheWVyO1xuICAgICAgICByZXR1cm4gbGF5ZXJzO1xuICAgIH1cbiAgICBfY29ubmVjdE5ld0xheWVycygpIHtcbiAgICAgICAgY29uc3QgeyBpbnB1dExheWVyLCBvdXRwdXRMYXllciB9ID0gdGhpcy5vcHRpb25zO1xuICAgICAgICBpZiAoIWlucHV0TGF5ZXIpXG4gICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ2lucHV0TGF5ZXIgbm90IGRlZmluZWQnKTtcbiAgICAgICAgY29uc3QgbGF5ZXJzID0gW107XG4gICAgICAgIHRoaXMuX2lucHV0TGF5ZXIgPSBpbnB1dExheWVyKCk7XG4gICAgICAgIGNvbnN0IGhpZGRlbkxheWVycyA9IHRoaXMuX2Nvbm5lY3RIaWRkZW5MYXllcnModGhpcy5faW5wdXRMYXllcik7XG4gICAgICAgIGlmICghb3V0cHV0TGF5ZXIpXG4gICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ291dHB1dExheWVyIG5vdCBkZWZpbmVkJyk7XG4gICAgICAgIHRoaXMuX291dHB1dExheWVyID0gb3V0cHV0TGF5ZXIoaGlkZGVuTGF5ZXJzW2hpZGRlbkxheWVycy5sZW5ndGggLSAxXSwgaGlkZGVuTGF5ZXJzLmxlbmd0aCk7XG4gICAgICAgIGxheWVycy5wdXNoKHRoaXMuX2lucHV0TGF5ZXIpO1xuICAgICAgICBsYXllcnMucHVzaCguLi5oaWRkZW5MYXllcnMpO1xuICAgICAgICBsYXllcnMucHVzaCh0aGlzLl9vdXRwdXRMYXllcik7XG4gICAgICAgIHJldHVybiBmbGF0dGVuTGF5ZXJzKGxheWVycyk7XG4gICAgfVxuICAgIF9jb25uZWN0SGlkZGVuTGF5ZXJzKHByZXZpb3VzTGF5ZXIpIHtcbiAgICAgICAgdGhpcy5faGlkZGVuTGF5ZXJzID0gW107XG4gICAgICAgIGNvbnN0IHJlc3VsdCA9IFtdO1xuICAgICAgICBjb25zdCB7IGhpZGRlbkxheWVycyB9ID0gdGhpcy5vcHRpb25zO1xuICAgICAgICBpZiAoIWhpZGRlbkxheWVycylcbiAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcignaGlkZGVuTGF5ZXJzIG5vdCBkZWZpbmVkJyk7XG4gICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgaGlkZGVuTGF5ZXJzLmxlbmd0aDsgaSsrKSB7XG4gICAgICAgICAgICBjb25zdCBoaWRkZW5MYXllciA9IGhpZGRlbkxheWVyc1tpXShwcmV2aW91c0xheWVyLCBpKTtcbiAgICAgICAgICAgIHJlc3VsdC5wdXNoKGhpZGRlbkxheWVyKTtcbiAgICAgICAgICAgIHRoaXMuX2hpZGRlbkxheWVycy5wdXNoKGhpZGRlbkxheWVyKTtcbiAgICAgICAgICAgIHByZXZpb3VzTGF5ZXIgPSBoaWRkZW5MYXllcjtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gcmVzdWx0O1xuICAgIH1cbiAgICBpbml0aWFsaXplKCkge1xuICAgICAgICB0aGlzLmxheWVycyA9IHRoaXMub3B0aW9ucy5sYXllcnNcbiAgICAgICAgICAgID8gdGhpcy5fY29ubmVjdE9wdGlvbnNMYXllcnMoKVxuICAgICAgICAgICAgOiB0aGlzLl9jb25uZWN0TmV3TGF5ZXJzKCk7XG4gICAgICAgIHRoaXMuaW5pdGlhbGl6ZUxheWVycyh0aGlzLmxheWVycyk7XG4gICAgICAgIHRoaXMuX21vZGVsID0gdGhpcy5sYXllcnMuZmlsdGVyKChsKSA9PiBsIGluc3RhbmNlb2YgTW9kZWwpO1xuICAgIH1cbiAgICBpbml0aWFsaXplTGF5ZXJzKGxheWVycykge1xuICAgICAgICB2YXIgX2EsIF9iO1xuICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IGxheWVycy5sZW5ndGg7IGkrKykge1xuICAgICAgICAgICAgY29uc3QgbGF5ZXIgPSBsYXllcnNbaV07XG4gICAgICAgICAgICAvLyBUT0RPOiBvcHRpbWl6ZSBmb3Igd2hlbiB0cmFpbmluZyBvciBqdXN0IHJ1bm5pbmdcbiAgICAgICAgICAgIGxheWVyLnNldHVwS2VybmVscyh0cnVlKTtcbiAgICAgICAgICAgIGlmIChsYXllciBpbnN0YW5jZW9mIE1vZGVsICYmXG4gICAgICAgICAgICAgICAgbGF5ZXIucHJheGlzID09PSBudWxsICYmXG4gICAgICAgICAgICAgICAgdHlwZW9mIHRoaXMub3B0aW9ucy5pbml0UHJheGlzID09PSAnZnVuY3Rpb24nKSB7XG4gICAgICAgICAgICAgICAgbGF5ZXIucHJheGlzID0gdGhpcy5vcHRpb25zLmluaXRQcmF4aXMobGF5ZXIsIChfYiA9IChfYSA9IGxheWVyLnNldHRpbmdzLnByYXhpc09wdHMpICE9PSBudWxsICYmIF9hICE9PSB2b2lkIDAgPyBfYSA6IHRoaXMub3B0aW9ucy5wcmF4aXNPcHRzKSAhPT0gbnVsbCAmJiBfYiAhPT0gdm9pZCAwID8gX2IgOiB7fSk7XG4gICAgICAgICAgICAgICAgbGF5ZXIucHJheGlzLnNldHVwS2VybmVscygpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIGNvbnN0IGxhc3RMYXllciA9IGxheWVyc1tsYXllcnMubGVuZ3RoIC0gMV07XG4gICAgICAgIHRoaXMubWVhblNxdWFyZWRFcnJvciA9IG5ldyBNZWFuU3F1YXJlZEVycm9yKHtcbiAgICAgICAgICAgIHdpZHRoOiBsYXN0TGF5ZXIud2lkdGgsXG4gICAgICAgICAgICBoZWlnaHQ6IGxhc3RMYXllci5oZWlnaHQsXG4gICAgICAgIH0pO1xuICAgIH1cbiAgICBydW4oaW5wdXQpIHtcbiAgICAgICAgbGV0IHR5cGVTYWZlSW5wdXQ7XG4gICAgICAgIGlmIChBcnJheS5pc0FycmF5KGlucHV0KSB8fCBpbnB1dC5idWZmZXIpIHtcbiAgICAgICAgICAgIHR5cGVTYWZlSW5wdXQgPSBpbnB1dDtcbiAgICAgICAgfVxuICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgIGlmICh0aGlzLmlucHV0TG9va3VwKSB7XG4gICAgICAgICAgICAgICAgdHlwZVNhZmVJbnB1dCA9IGxvb2t1cC50b0FycmF5KHRoaXMuaW5wdXRMb29rdXAsIGlucHV0LCB0aGlzLmlucHV0TG9va3VwTGVuZ3RoKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcignaW5wdXQgaXMgaW5jb21wYXRpYmxlIHdpdGggbmV0Jyk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgbGV0IG91dHB1dCA9IHRoaXMucnVuSW5wdXQodHlwZVNhZmVJbnB1dCk7XG4gICAgICAgIGlmIChvdXRwdXQgaW5zdGFuY2VvZiBncHVfanMuVGV4dHVyZSkge1xuICAgICAgICAgICAgb3V0cHV0ID0gb3V0cHV0LnRvQXJyYXkoKTtcbiAgICAgICAgfVxuICAgICAgICBpZiAodGhpcy5vdXRwdXRMb29rdXApIHtcbiAgICAgICAgICAgIHJldHVybiBsb29rdXAudG9PYmplY3QodGhpcy5vdXRwdXRMb29rdXAsIG91dHB1dCk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIG91dHB1dDtcbiAgICB9XG4gICAgcnVuSW5wdXQoaW5wdXQpIHtcbiAgICAgICAgaWYgKCF0aGlzLmxheWVycylcbiAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcignbm90IGluaXRpYWxpemVkJyk7XG4gICAgICAgIHRoaXMubGF5ZXJzWzBdLnByZWRpY3QoaW5wdXQpO1xuICAgICAgICBmb3IgKGxldCBpID0gMTsgaSA8IHRoaXMubGF5ZXJzLmxlbmd0aDsgaSsrKSB7XG4gICAgICAgICAgICB0aGlzLmxheWVyc1tpXS5wcmVkaWN0KCk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHRoaXMubGF5ZXJzW3RoaXMubGF5ZXJzLmxlbmd0aCAtIDFdLndlaWdodHM7XG4gICAgfVxuICAgIHRyYWluKGRhdGEsIG9wdGlvbnMgPSB7fSkge1xuICAgICAgICBjb25zdCB7IHByZXBhcmVkRGF0YSwgc3RhdHVzLCBlbmRUaW1lIH0gPSB0aGlzLl9wcmVwVHJhaW5pbmcoZGF0YSwgb3B0aW9ucyk7XG4gICAgICAgIGxldCBjb250aW51ZVRpY2tpbmcgPSB0cnVlO1xuICAgICAgICBjb25zdCBjYWxjdWxhdGVFcnJvciA9ICgpID0+IHRoaXMuX2NhbGN1bGF0ZVRyYWluaW5nRXJyb3IocHJlcGFyZWREYXRhKTtcbiAgICAgICAgY29uc3QgdHJhaW5QYXR0ZXJzID0gKCkgPT4gdGhpcy5fdHJhaW5QYXR0ZXJucyhwcmVwYXJlZERhdGEpO1xuICAgICAgICB3aGlsZSAoY29udGludWVUaWNraW5nKSB7XG4gICAgICAgICAgICBjb250aW51ZVRpY2tpbmcgPSB0aGlzLl90cmFpbmluZ1RpY2soc3RhdHVzLCBlbmRUaW1lLCBjYWxjdWxhdGVFcnJvciwgdHJhaW5QYXR0ZXJzKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gc3RhdHVzO1xuICAgIH1cbiAgICBfdHJhaW5pbmdUaWNrKHN0YXR1cywgZW5kVGltZSwgY2FsY3VsYXRlRXJyb3IsIHRyYWluUGF0dGVybnMpIHtcbiAgICAgICAgY29uc3QgeyB0cmFpbk9wdHMgfSA9IHRoaXM7XG4gICAgICAgIGlmIChzdGF0dXMuaXRlcmF0aW9ucyA+PSB0cmFpbk9wdHMuaXRlcmF0aW9ucyB8fFxuICAgICAgICAgICAgc3RhdHVzLmVycm9yIDw9IHRyYWluT3B0cy5lcnJvclRocmVzaCB8fFxuICAgICAgICAgICAgRGF0ZS5ub3coKSA+PSBlbmRUaW1lKSB7XG4gICAgICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKHR5cGVvZiB0cmFpbk9wdHMubG9nID09PSAnZnVuY3Rpb24nICYmXG4gICAgICAgICAgICBzdGF0dXMuaXRlcmF0aW9ucyAlIHRyYWluT3B0cy5sb2dQZXJpb2QgPT09IDApIHtcbiAgICAgICAgICAgIHN0YXR1cy5lcnJvciA9IGNhbGN1bGF0ZUVycm9yKCk7XG4gICAgICAgICAgICB0cmFpbk9wdHMubG9nKGBpdGVyYXRpb25zOiAke3N0YXR1cy5pdGVyYXRpb25zfSwgdHJhaW5pbmcgZXJyb3I6ICR7c3RhdHVzLmVycm9yfWApO1xuICAgICAgICB9XG4gICAgICAgIGVsc2UgaWYgKHN0YXR1cy5pdGVyYXRpb25zICUgdHJhaW5PcHRzLmVycm9yQ2hlY2tJbnRlcnZhbCA9PT1cbiAgICAgICAgICAgIDApIHtcbiAgICAgICAgICAgIHN0YXR1cy5lcnJvciA9IGNhbGN1bGF0ZUVycm9yKCk7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICB0cmFpblBhdHRlcm5zKCk7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKHRyYWluT3B0cy5jYWxsYmFjayAmJlxuICAgICAgICAgICAgc3RhdHVzLml0ZXJhdGlvbnMgJSB0cmFpbk9wdHMuY2FsbGJhY2tQZXJpb2QgPT09IDApIHtcbiAgICAgICAgICAgIHRyYWluT3B0cy5jYWxsYmFjayhPYmplY3QuYXNzaWduKHN0YXR1cykpO1xuICAgICAgICB9XG4gICAgICAgIHN0YXR1cy5pdGVyYXRpb25zKys7XG4gICAgICAgIHJldHVybiB0cnVlO1xuICAgIH1cbiAgICBfcHJlcFRyYWluaW5nKGRhdGEsIG9wdGlvbnMpIHtcbiAgICAgICAgdGhpcy5fdXBkYXRlVHJhaW5pbmdPcHRpb25zKG9wdGlvbnMpO1xuICAgICAgICBjb25zdCBmb3JtYXR0ZWREYXRhID0gdGhpcy5mb3JtYXREYXRhKGRhdGEpO1xuICAgICAgICBjb25zdCBlbmRUaW1lID0gdGhpcy50cmFpbk9wdHMudGltZW91dFxuICAgICAgICAgICAgPyBEYXRlLm5vdygpICsgdGhpcy50cmFpbk9wdHMudGltZW91dFxuICAgICAgICAgICAgOiAwO1xuICAgICAgICBjb25zdCBzdGF0dXMgPSB7XG4gICAgICAgICAgICBlcnJvcjogMSxcbiAgICAgICAgICAgIGl0ZXJhdGlvbnM6IDAsXG4gICAgICAgIH07XG4gICAgICAgIHRoaXMudmVyaWZ5SXNJbml0aWFsaXplZCgpO1xuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgcHJlcGFyZWREYXRhOiB0aGlzLnRyYW5zZmVyRGF0YShmb3JtYXR0ZWREYXRhKSxcbiAgICAgICAgICAgIHN0YXR1cyxcbiAgICAgICAgICAgIGVuZFRpbWUsXG4gICAgICAgIH07XG4gICAgfVxuICAgIHZlcmlmeUlzSW5pdGlhbGl6ZWQoKSB7XG4gICAgICAgIGlmICghdGhpcy5fbW9kZWwpIHtcbiAgICAgICAgICAgIHRoaXMuaW5pdGlhbGl6ZSgpO1xuICAgICAgICB9XG4gICAgfVxuICAgIF9jYWxjdWxhdGVUcmFpbmluZ0Vycm9yKHByZXBhcmVkRGF0YSkge1xuICAgICAgICBsZXQgc3VtID0gbmV3IEZsb2F0MzJBcnJheShbMF0pO1xuICAgICAgICBjb25zdCBtZWFuU3F1YXJlZEVycm9yID0gdGhpcy5tZWFuU3F1YXJlZEVycm9yO1xuICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IHByZXBhcmVkRGF0YS5sZW5ndGg7ICsraSkge1xuICAgICAgICAgICAgY29uc3QgcHJldlN1bSA9IHN1bTtcbiAgICAgICAgICAgIGNvbnN0IGVycm9yID0gdGhpcy5fdHJhaW5QYXR0ZXJuKHByZXBhcmVkRGF0YVtpXS5pbnB1dCwgcHJlcGFyZWREYXRhW2ldLm91dHB1dCwgdHJ1ZSk7XG4gICAgICAgICAgICBzdW0gPSBtZWFuU3F1YXJlZEVycm9yLmFkZChzdW0sIGVycm9yKTtcbiAgICAgICAgICAgIHJlbGVhc2UoZXJyb3IpO1xuICAgICAgICAgICAgcmVsZWFzZShwcmV2U3VtKTtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCByZXN1bHQgPSBtZWFuU3F1YXJlZEVycm9yLmRpdmlkZShwcmVwYXJlZERhdGEubGVuZ3RoLCBzdW0pO1xuICAgICAgICByZWxlYXNlKHN1bSk7XG4gICAgICAgIGlmIChyZXN1bHQgaW5zdGFuY2VvZiBncHVfanMuVGV4dHVyZSkge1xuICAgICAgICAgICAgY29uc3QgcmVzdWx0QXJyYXkgPSByZXN1bHQudG9BcnJheSgpO1xuICAgICAgICAgICAgcmVsZWFzZShyZXN1bHQpO1xuICAgICAgICAgICAgcmV0dXJuIHJlc3VsdEFycmF5WzBdO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiByZXN1bHRbMF07XG4gICAgfVxuICAgIC8qKlxuICAgICAqIEBwYXJhbSBkYXRhXG4gICAgICogQHByaXZhdGVcbiAgICAgKi9cbiAgICBfdHJhaW5QYXR0ZXJucyhkYXRhKSB7XG4gICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgZGF0YS5sZW5ndGg7ICsraSkge1xuICAgICAgICAgICAgdGhpcy5fdHJhaW5QYXR0ZXJuKGRhdGFbaV0uaW5wdXQsIGRhdGFbaV0ub3V0cHV0LCBmYWxzZSk7XG4gICAgICAgIH1cbiAgICB9XG4gICAgX3RyYWluUGF0dGVybihpbnB1dCwgdGFyZ2V0LCBsb2dFcnJvclJhdGUpIHtcbiAgICAgICAgdmFyIF9hO1xuICAgICAgICAvLyBmb3J3YXJkIHByb3BhZ2F0ZVxuICAgICAgICB0aGlzLnJ1bklucHV0KGlucHV0KTtcbiAgICAgICAgLy8gYmFjayBwcm9wYWdhdGVcbiAgICAgICAgdGhpcy5fY2FsY3VsYXRlRGVsdGFzKHRhcmdldCk7XG4gICAgICAgIHRoaXMuYWRqdXN0V2VpZ2h0cygpO1xuICAgICAgICBpZiAobG9nRXJyb3JSYXRlKSB7XG4gICAgICAgICAgICBpZiAoISgoX2EgPSB0aGlzLl9vdXRwdXRMYXllcikgPT09IG51bGwgfHwgX2EgPT09IHZvaWQgMCA/IHZvaWQgMCA6IF9hLmVycm9ycykpIHtcbiAgICAgICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ291dHB1dExheWVyLmVycm9ycyBub3QgZGVmaW5lZCcpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgcmV0dXJuIHRoaXMubWVhblNxdWFyZWRFcnJvci5jYWxjdWxhdGUodGhpcy5fb3V0cHV0TGF5ZXIuZXJyb3JzKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gbnVsbDtcbiAgICB9XG4gICAgX2NhbGN1bGF0ZURlbHRhcyh0YXJnZXQpIHtcbiAgICAgICAgY29uc3QgbGF5ZXJzID0gdGhpcy5sYXllcnM7XG4gICAgICAgIGZvciAobGV0IGkgPSBsYXllcnMubGVuZ3RoIC0gMTsgaSA+IC0xOyBpLS0pIHtcbiAgICAgICAgICAgIGxheWVyc1tpXS5jb21wYXJlKHRhcmdldCk7XG4gICAgICAgIH1cbiAgICB9XG4gICAgLyoqXG4gICAgICpcbiAgICAgKi9cbiAgICBhZGp1c3RXZWlnaHRzKCkge1xuICAgICAgICBjb25zdCBfbW9kZWwgPSB0aGlzLl9tb2RlbDtcbiAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBfbW9kZWwubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgICAgIF9tb2RlbFtpXS5sZWFybih0aGlzLnRyYWluT3B0cy5sZWFybmluZ1JhdGUpO1xuICAgICAgICB9XG4gICAgfVxuICAgIC8qKlxuICAgICAqXG4gICAgICogQHBhcmFtIGRhdGFcbiAgICAgKiBAcmV0dXJucyB7Kn1cbiAgICAgKi9cbiAgICBmb3JtYXREYXRhKGRhdGEpIHtcbiAgICAgICAgaWYgKCFBcnJheS5pc0FycmF5KGRhdGEpKSB7XG4gICAgICAgICAgICAvLyB0dXJuIHN0cmVhbSBkYXR1bSBpbnRvIGFycmF5XG4gICAgICAgICAgICBjb25zdCB0bXAgPSBbXTtcbiAgICAgICAgICAgIHRtcC5wdXNoKGRhdGEpO1xuICAgICAgICAgICAgZGF0YSA9IHRtcDtcbiAgICAgICAgfVxuICAgICAgICAvLyB0dXJuIHNwYXJzZSBoYXNoIGlucHV0IGludG8gYXJyYXlzIHdpdGggMHMgYXMgZmlsbGVyXG4gICAgICAgIGNvbnN0IGlucHV0RGF0dW1DaGVjayA9IGRhdGFbMF0uaW5wdXQ7XG4gICAgICAgIGxldCBmb3JtYXR0ZWREYXRhO1xuICAgICAgICBpZiAoQXJyYXkuaXNBcnJheShkYXRhKSAmJlxuICAgICAgICAgICAgIUFycmF5LmlzQXJyYXkoaW5wdXREYXR1bUNoZWNrKSAmJlxuICAgICAgICAgICAgIShpbnB1dERhdHVtQ2hlY2sgaW5zdGFuY2VvZiBGbG9hdDMyQXJyYXkpKSB7XG4gICAgICAgICAgICBpZiAoIXRoaXMuaW5wdXRMb29rdXApIHtcbiAgICAgICAgICAgICAgICBjb25zdCBsb29rdXBUYWJsZSA9IG5ldyBMb29rdXBUYWJsZShkYXRhLCAnaW5wdXQnKTtcbiAgICAgICAgICAgICAgICB0aGlzLmlucHV0TG9va3VwID0gbG9va3VwVGFibGUudGFibGU7XG4gICAgICAgICAgICAgICAgdGhpcy5pbnB1dExvb2t1cExlbmd0aCA9IGxvb2t1cFRhYmxlLmxlbmd0aDtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGZvcm1hdHRlZERhdGEgPSBkYXRhLm1hcCgoZGF0dW1QYXJhbSkgPT4ge1xuICAgICAgICAgICAgICAgIGNvbnN0IGFycmF5ID0gbG9va3VwLnRvQXJyYXkodGhpcy5pbnB1dExvb2t1cCwgZGF0dW1QYXJhbS5pbnB1dCwgdGhpcy5pbnB1dExvb2t1cExlbmd0aCk7XG4gICAgICAgICAgICAgICAgcmV0dXJuIHsgaW5wdXQ6IGFycmF5IH07XG4gICAgICAgICAgICB9LCB0aGlzKTtcbiAgICAgICAgfVxuICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgIGZvcm1hdHRlZERhdGEgPSBkYXRhO1xuICAgICAgICB9XG4gICAgICAgIGNvbnN0IG91dHB1dERhdHVtQ2hlY2sgPSBkYXRhWzBdLm91dHB1dDtcbiAgICAgICAgaWYgKCFBcnJheS5pc0FycmF5KG91dHB1dERhdHVtQ2hlY2spICYmXG4gICAgICAgICAgICAhKG91dHB1dERhdHVtQ2hlY2sgaW5zdGFuY2VvZiBGbG9hdDMyQXJyYXkpKSB7XG4gICAgICAgICAgICBpZiAoIXRoaXMub3V0cHV0TG9va3VwKSB7XG4gICAgICAgICAgICAgICAgY29uc3QgbG9va3VwVGFibGUgPSBuZXcgTG9va3VwVGFibGUoZGF0YSwgJ291dHB1dCcpO1xuICAgICAgICAgICAgICAgIHRoaXMub3V0cHV0TG9va3VwID0gbG9va3VwVGFibGUudGFibGU7XG4gICAgICAgICAgICAgICAgdGhpcy5vdXRwdXRMb29rdXBMZW5ndGggPSBsb29rdXBUYWJsZS5sZW5ndGg7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBmb3JtYXR0ZWREYXRhID0gZGF0YS5tYXAoKGRhdHVtUGFyYW0sIGluZGV4KSA9PiB7XG4gICAgICAgICAgICAgICAgY29uc3QgYXJyYXkgPSBsb29rdXAudG9BcnJheSh0aGlzLm91dHB1dExvb2t1cCwgZGF0dW1QYXJhbS5vdXRwdXQsIHRoaXMuaW5wdXRMb29rdXBMZW5ndGgpO1xuICAgICAgICAgICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICAgICAgICAgIGlucHV0OiBmb3JtYXR0ZWREYXRhW2luZGV4XS5pbnB1dCxcbiAgICAgICAgICAgICAgICAgICAgb3V0cHV0OiBhcnJheSxcbiAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgfSwgdGhpcyk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIGZvcm1hdHRlZERhdGE7XG4gICAgfVxuICAgIHRyYW5zZmVyRGF0YShmb3JtYXR0ZWREYXRhKSB7XG4gICAgICAgIGNvbnN0IHRyYW5zZmVycmVkRGF0YSA9IG5ldyBBcnJheShmb3JtYXR0ZWREYXRhLmxlbmd0aCk7XG4gICAgICAgIGNvbnN0IHRyYW5zZmVySW5wdXQgPSBtYWtlS2VybmVsKGZ1bmN0aW9uICh2YWx1ZSkge1xuICAgICAgICAgICAgcmV0dXJuIHZhbHVlW3RoaXMudGhyZWFkLnhdO1xuICAgICAgICB9LCB7XG4gICAgICAgICAgICBvdXRwdXQ6IFtmb3JtYXR0ZWREYXRhWzBdLmlucHV0Lmxlbmd0aF0sXG4gICAgICAgICAgICBpbW11dGFibGU6IHRydWUsXG4gICAgICAgIH0pO1xuICAgICAgICBjb25zdCB0cmFuc2Zlck91dHB1dCA9IG1ha2VLZXJuZWwoZnVuY3Rpb24gKHZhbHVlKSB7XG4gICAgICAgICAgICByZXR1cm4gdmFsdWVbdGhpcy50aHJlYWQueF07XG4gICAgICAgIH0sIHtcbiAgICAgICAgICAgIG91dHB1dDogW2Zvcm1hdHRlZERhdGFbMF0ub3V0cHV0Lmxlbmd0aF0sXG4gICAgICAgICAgICBpbW11dGFibGU6IHRydWUsXG4gICAgICAgIH0pO1xuICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IGZvcm1hdHRlZERhdGEubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgICAgIGNvbnN0IGZvcm1hdHRlZERhdHVtID0gZm9ybWF0dGVkRGF0YVtpXTtcbiAgICAgICAgICAgIHRyYW5zZmVycmVkRGF0YVtpXSA9IHtcbiAgICAgICAgICAgICAgICBpbnB1dDogdHJhbnNmZXJJbnB1dChmb3JtYXR0ZWREYXR1bS5pbnB1dCksXG4gICAgICAgICAgICAgICAgb3V0cHV0OiB0cmFuc2Zlck91dHB1dChmb3JtYXR0ZWREYXR1bS5vdXRwdXQpLFxuICAgICAgICAgICAgfTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gdHJhbnNmZXJyZWREYXRhO1xuICAgIH1cbiAgICAvKipcbiAgICAgKlxuICAgICAqIEBwYXJhbSBkYXRhXG4gICAgICogQHJldHVybnMge1xuICAgICAqICB7XG4gICAgICogICAgZXJyb3I6IG51bWJlcixcbiAgICAgKiAgICBtaXNjbGFzc2VzOiBBcnJheVxuICAgICAqICB9XG4gICAgICogfVxuICAgICAqL1xuICAgIHRlc3QoKSB7XG4gICAgICAgIHRocm93IG5ldyBFcnJvcihgJHt0aGlzLmNvbnN0cnVjdG9yLm5hbWV9LXRlc3QgaXMgbm90IHlldCBpbXBsZW1lbnRlZGApO1xuICAgIH1cbiAgICAvKipcbiAgICAgKlxuICAgICAqL1xuICAgIHRvSlNPTigpIHtcbiAgICAgICAgdmFyIF9hO1xuICAgICAgICBpZiAoIXRoaXMubGF5ZXJzKSB7XG4gICAgICAgICAgICB0aGlzLmluaXRpYWxpemUoKTtcbiAgICAgICAgfVxuICAgICAgICBpZiAoIXRoaXMuX21vZGVsIHx8XG4gICAgICAgICAgICAhdGhpcy5sYXllcnMgfHxcbiAgICAgICAgICAgICF0aGlzLl9pbnB1dExheWVyIHx8XG4gICAgICAgICAgICAhdGhpcy5faGlkZGVuTGF5ZXJzIHx8XG4gICAgICAgICAgICAhdGhpcy5fb3V0cHV0TGF5ZXIpIHtcbiAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcignbmV0d29yayBpcyBub3QgaW5pdGlhbGl6ZWQnKTtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCBqc29uTGF5ZXJzID0gW107XG4gICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgdGhpcy5sYXllcnMubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgICAgIGNvbnN0IGxheWVyID0gdGhpcy5sYXllcnNbaV07XG4gICAgICAgICAgICBjb25zdCBqc29uTGF5ZXIgPSBsYXllci50b0pTT04oKTtcbiAgICAgICAgICAgIGlmIChsYXllci5oYXNPd25Qcm9wZXJ0eSgnaW5wdXRMYXllcicpKSB7XG4gICAgICAgICAgICAgICAganNvbkxheWVyLmlucHV0TGF5ZXJJbmRleCA9IHRoaXMubGF5ZXJzLmluZGV4T2YobGF5ZXIuaW5wdXRMYXllcik7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBlbHNlIGlmIChsYXllci5oYXNPd25Qcm9wZXJ0eSgnaW5wdXRMYXllcjEnKSAmJlxuICAgICAgICAgICAgICAgIGxheWVyLmhhc093blByb3BlcnR5KCdpbnB1dExheWVyMicpKSB7XG4gICAgICAgICAgICAgICAganNvbkxheWVyLmlucHV0TGF5ZXIxSW5kZXggPSB0aGlzLmxheWVycy5pbmRleE9mKGxheWVyLmlucHV0TGF5ZXIxKTtcbiAgICAgICAgICAgICAgICBqc29uTGF5ZXIuaW5wdXRMYXllcjJJbmRleCA9IHRoaXMubGF5ZXJzLmluZGV4T2YobGF5ZXIuaW5wdXRMYXllcjIpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAganNvbkxheWVycy5wdXNoKGpzb25MYXllcik7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgIHR5cGU6IHRoaXMuY29uc3RydWN0b3IubmFtZSxcbiAgICAgICAgICAgIHNpemVzOiAoX2EgPSB0aGlzLm9wdGlvbnMuc2l6ZXMpICE9PSBudWxsICYmIF9hICE9PSB2b2lkIDAgPyBfYSA6IFt0aGlzLl9pbnB1dExheWVyLmhlaWdodF1cbiAgICAgICAgICAgICAgICAuY29uY2F0KHRoaXMuX2hpZGRlbkxheWVycy5tYXAoKGwpID0+IGwuaGVpZ2h0KSlcbiAgICAgICAgICAgICAgICAuY29uY2F0KFt0aGlzLl9vdXRwdXRMYXllci5oZWlnaHRdKSxcbiAgICAgICAgICAgIG91dHB1dExheWVySW5kZXg6IHRoaXMubGF5ZXJzLmluZGV4T2YodGhpcy5fb3V0cHV0TGF5ZXIpLFxuICAgICAgICAgICAgbGF5ZXJzOiBqc29uTGF5ZXJzLFxuICAgICAgICAgICAgaW5wdXRMYXllckluZGV4OiB0aGlzLmxheWVycy5pbmRleE9mKHRoaXMuX2lucHV0TGF5ZXIpLFxuICAgICAgICB9O1xuICAgIH1cbiAgICBzdGF0aWMgZnJvbUpTT04oanNvbiwgZ2V0TGF5ZXIpIHtcbiAgICAgICAgdmFyIF9hLCBfYiwgX2MsIF9kO1xuICAgICAgICBjb25zdCBqc29uTGF5ZXJzID0ganNvbi5sYXllcnM7XG4gICAgICAgIGNvbnN0IGxheWVycyA9IFtdO1xuICAgICAgICBjb25zdCBpbnB1dExheWVyID0gZ2V0TGF5ZXJcbiAgICAgICAgICAgID8gKF9hID0gbGF5ZXJGcm9tSlNPTihqc29uTGF5ZXJzWzBdKSkgIT09IG51bGwgJiYgX2EgIT09IHZvaWQgMCA/IF9hIDogZ2V0TGF5ZXIoanNvbkxheWVyc1swXSkgOiBsYXllckZyb21KU09OKGpzb25MYXllcnNbMF0pO1xuICAgICAgICBpZiAoIWlucHV0TGF5ZXIpXG4gICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ3VuYWJsZSB0byBmaW5kIGxheWVyJyk7XG4gICAgICAgIGxheWVycy5wdXNoKGlucHV0TGF5ZXIpO1xuICAgICAgICBmb3IgKGxldCBpID0gMTsgaSA8IGpzb25MYXllcnMubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgICAgIGNvbnN0IGpzb25MYXllciA9IGpzb25MYXllcnNbaV07XG4gICAgICAgICAgICBpZiAodHlwZW9mIGpzb25MYXllci5pbnB1dExheWVySW5kZXggPT09ICd1bmRlZmluZWQnICYmXG4gICAgICAgICAgICAgICAgdHlwZW9mIGpzb25MYXllci5pbnB1dExheWVyMUluZGV4ID09PSAndW5kZWZpbmVkJyAmJlxuICAgICAgICAgICAgICAgIHR5cGVvZiBqc29uTGF5ZXIuaW5wdXRMYXllcjJJbmRleCA9PT0gJ3VuZGVmaW5lZCcpIHtcbiAgICAgICAgICAgICAgICBjb25zdCBsYXllciA9IGdldExheWVyXG4gICAgICAgICAgICAgICAgICAgID8gKF9iID0gbGF5ZXJGcm9tSlNPTihqc29uTGF5ZXIpKSAhPT0gbnVsbCAmJiBfYiAhPT0gdm9pZCAwID8gX2IgOiBnZXRMYXllcihqc29uTGF5ZXIpIDogbGF5ZXJGcm9tSlNPTihqc29uTGF5ZXIpO1xuICAgICAgICAgICAgICAgIGlmICghbGF5ZXIpXG4gICAgICAgICAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcigndW5hYmxlIHRvIGZpbmQgbGF5ZXInKTtcbiAgICAgICAgICAgICAgICBsYXllcnMucHVzaChsYXllcik7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBlbHNlIGlmICh0eXBlb2YganNvbkxheWVyLmlucHV0TGF5ZXJJbmRleCA9PT0gJ251bWJlcicpIHtcbiAgICAgICAgICAgICAgICBjb25zdCBpbnB1dExheWVyID0gbGF5ZXJzW2pzb25MYXllci5pbnB1dExheWVySW5kZXhdO1xuICAgICAgICAgICAgICAgIGlmICghaW5wdXRMYXllcikge1xuICAgICAgICAgICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ2lucHV0TGF5ZXIxIG5vdCBmb3VuZCcpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBjb25zdCBsYXllciA9IGdldExheWVyXG4gICAgICAgICAgICAgICAgICAgID8gKF9jID0gbGF5ZXJGcm9tSlNPTihqc29uTGF5ZXIsIGlucHV0TGF5ZXIpKSAhPT0gbnVsbCAmJiBfYyAhPT0gdm9pZCAwID8gX2MgOiBnZXRMYXllcihqc29uTGF5ZXIsIGlucHV0TGF5ZXIpIDogbGF5ZXJGcm9tSlNPTihqc29uTGF5ZXIsIGlucHV0TGF5ZXIpO1xuICAgICAgICAgICAgICAgIGlmICghbGF5ZXIpXG4gICAgICAgICAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcigndW5hYmxlIHRvIGZpbmQgbGF5ZXInKTtcbiAgICAgICAgICAgICAgICBsYXllcnMucHVzaChsYXllcik7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgICAgICBpZiAodHlwZW9mIGpzb25MYXllci5pbnB1dExheWVyMUluZGV4ICE9PSAnbnVtYmVyJykge1xuICAgICAgICAgICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ0Nhbm5vdCBjcmVhdGUgbmV0d29yayBmcm9tIHByb3ZpZGVkIEpTT04uIGlucHV0TGF5ZXIxSW5kZXggbm90IGRlZmluZWQuJyk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGlmICh0eXBlb2YganNvbkxheWVyLmlucHV0TGF5ZXIySW5kZXggIT09ICdudW1iZXInKSB7XG4gICAgICAgICAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcignQ2Fubm90IGNyZWF0ZSBuZXR3b3JrIGZyb20gcHJvdmlkZWQgSlNPTi4gaW5wdXRMYXllcjJJbmRleCBub3QgZGVmaW5lZC4nKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgY29uc3QgaW5wdXRMYXllcjEgPSBsYXllcnNbanNvbkxheWVyLmlucHV0TGF5ZXIxSW5kZXhdO1xuICAgICAgICAgICAgICAgIGNvbnN0IGlucHV0TGF5ZXIyID0gbGF5ZXJzW2pzb25MYXllci5pbnB1dExheWVyMkluZGV4XTtcbiAgICAgICAgICAgICAgICBpZiAoaW5wdXRMYXllcjEgPT09IHVuZGVmaW5lZClcbiAgICAgICAgICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKGBDYW5ub3QgY3JlYXRlIG5ldHdvcmsgZnJvbSBwcm92aWRlZCBKU09OLiBsYXllciBvZiBpbmRleCAke2pzb25MYXllci5pbnB1dExheWVyMUluZGV4fSBub3QgZm91bmQuYCk7XG4gICAgICAgICAgICAgICAgaWYgKGlucHV0TGF5ZXIyID09PSB1bmRlZmluZWQpXG4gICAgICAgICAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcihgQ2Fubm90IGNyZWF0ZSBuZXR3b3JrIGZyb20gcHJvdmlkZWQgSlNPTi4gbGF5ZXIgb2YgaW5kZXggJHtqc29uTGF5ZXIuaW5wdXRMYXllcjJJbmRleH0gbm90IGZvdW5kLmApO1xuICAgICAgICAgICAgICAgIGNvbnN0IGxheWVyID0gZ2V0TGF5ZXJcbiAgICAgICAgICAgICAgICAgICAgPyAoX2QgPSBsYXllckZyb21KU09OKGpzb25MYXllciwgaW5wdXRMYXllcjEsIGlucHV0TGF5ZXIyKSkgIT09IG51bGwgJiYgX2QgIT09IHZvaWQgMCA/IF9kIDogZ2V0TGF5ZXIoanNvbkxheWVyLCBpbnB1dExheWVyMSwgaW5wdXRMYXllcjIpIDogbGF5ZXJGcm9tSlNPTihqc29uTGF5ZXIsIGlucHV0TGF5ZXIxLCBpbnB1dExheWVyMik7XG4gICAgICAgICAgICAgICAgaWYgKCFsYXllcilcbiAgICAgICAgICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKCd1bmFibGUgdG8gZmluZCBsYXllcicpO1xuICAgICAgICAgICAgICAgIGxheWVycy5wdXNoKGxheWVyKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gbmV3IHRoaXMoeyAuLi5qc29uLCBsYXllcnMgfSk7XG4gICAgfVxuICAgIC8qKlxuICAgICAqXG4gICAgICogQHJldHVybnMge0Z1bmN0aW9ufVxuICAgICAqL1xuICAgIHRvRnVuY3Rpb24oKSB7XG4gICAgICAgIHRocm93IG5ldyBFcnJvcihgJHt0aGlzLmNvbnN0cnVjdG9yLm5hbWV9LXRvRnVuY3Rpb24gaXMgbm90IHlldCBpbXBsZW1lbnRlZGApO1xuICAgIH1cbiAgICAvKipcbiAgICAgKiBUaGlzIHdpbGwgY3JlYXRlIGEgVHJhaW5TdHJlYW0gKFdyaXRlU3RyZWFtKSBmb3IgdXMgdG8gc2VuZCB0aGUgdHJhaW5pbmcgZGF0YSB0by5cbiAgICAgKiBAcGFyYW0gb3B0cyB0cmFpbmluZyBvcHRpb25zXG4gICAgICogQHJldHVybnMge1RyYWluU3RyZWFtfCp9XG4gICAgICovXG4gICAgY3JlYXRlVHJhaW5TdHJlYW0oKSB7XG4gICAgICAgIHRocm93IG5ldyBFcnJvcihgJHt0aGlzLmNvbnN0cnVjdG9yLm5hbWV9LWNyZWF0ZVRyYWluU3RyZWFtIGlzIG5vdCB5ZXQgaW1wbGVtZW50ZWRgKTtcbiAgICB9XG59XG5cbmZ1bmN0aW9uIGxpa2VseShpbnB1dCwgbmV0KSB7XG4gICAgaWYgKCFuZXQpIHtcbiAgICAgICAgdGhyb3cgbmV3IFR5cGVFcnJvcihgUmVxdWlyZWQgcGFyYW1ldGVyICduZXQnIGlzIG9mIHR5cGUgJHt0eXBlb2YgbmV0fS4gTXVzdCBiZSBvZiB0eXBlICdicmFpbi5OZXVyYWxOZXR3b3JrJ2ApO1xuICAgIH1cbiAgICBjb25zdCBvdXRwdXQgPSBuZXQucnVuKGlucHV0KTtcbiAgICBsZXQgbWF4UHJvcCA9IG51bGw7XG4gICAgbGV0IG1heFZhbHVlID0gLTE7XG4gICAgT2JqZWN0LmVudHJpZXMob3V0cHV0KS5mb3JFYWNoKChba2V5LCB2YWx1ZV0pID0+IHtcbiAgICAgICAgaWYgKHR5cGVvZiB2YWx1ZSAhPT0gJ3VuZGVmaW5lZCcgJiZcbiAgICAgICAgICAgIHR5cGVvZiB2YWx1ZSA9PT0gJ251bWJlcicgJiZcbiAgICAgICAgICAgIHZhbHVlID4gbWF4VmFsdWUpIHtcbiAgICAgICAgICAgIG1heFByb3AgPSBrZXk7XG4gICAgICAgICAgICBtYXhWYWx1ZSA9IHZhbHVlO1xuICAgICAgICB9XG4gICAgfSk7XG4gICAgcmV0dXJuIG1heFByb3A7XG59XG5cbnZhciBjb21tb25qc0dsb2JhbCA9IHR5cGVvZiBnbG9iYWxUaGlzICE9PSAndW5kZWZpbmVkJyA/IGdsb2JhbFRoaXMgOiB0eXBlb2Ygd2luZG93ICE9PSAndW5kZWZpbmVkJyA/IHdpbmRvdyA6IHR5cGVvZiBnbG9iYWwgIT09ICd1bmRlZmluZWQnID8gZ2xvYmFsIDogdHlwZW9mIHNlbGYgIT09ICd1bmRlZmluZWQnID8gc2VsZiA6IHt9O1xuXG5mdW5jdGlvbiBjcmVhdGVDb21tb25qc01vZHVsZShmbiwgYmFzZWRpciwgbW9kdWxlKSB7XG5cdHJldHVybiBtb2R1bGUgPSB7XG5cdFx0cGF0aDogYmFzZWRpcixcblx0XHRleHBvcnRzOiB7fSxcblx0XHRyZXF1aXJlOiBmdW5jdGlvbiAocGF0aCwgYmFzZSkge1xuXHRcdFx0cmV0dXJuIGNvbW1vbmpzUmVxdWlyZShwYXRoLCAoYmFzZSA9PT0gdW5kZWZpbmVkIHx8IGJhc2UgPT09IG51bGwpID8gbW9kdWxlLnBhdGggOiBiYXNlKTtcblx0XHR9XG5cdH0sIGZuKG1vZHVsZSwgbW9kdWxlLmV4cG9ydHMpLCBtb2R1bGUuZXhwb3J0cztcbn1cblxuZnVuY3Rpb24gY29tbW9uanNSZXF1aXJlICgpIHtcblx0dGhyb3cgbmV3IEVycm9yKCdEeW5hbWljIHJlcXVpcmVzIGFyZSBub3QgY3VycmVudGx5IHN1cHBvcnRlZCBieSBAcm9sbHVwL3BsdWdpbi1jb21tb25qcycpO1xufVxuXG52YXIgdGhhd18xID0gY3JlYXRlQ29tbW9uanNNb2R1bGUoZnVuY3Rpb24gKG1vZHVsZSwgZXhwb3J0cykge1xudmFyIF9fYXNzaWduID0gKGNvbW1vbmpzR2xvYmFsICYmIGNvbW1vbmpzR2xvYmFsLl9fYXNzaWduKSB8fCBmdW5jdGlvbiAoKSB7XG4gICAgX19hc3NpZ24gPSBPYmplY3QuYXNzaWduIHx8IGZ1bmN0aW9uKHQpIHtcbiAgICAgICAgZm9yICh2YXIgcywgaSA9IDEsIG4gPSBhcmd1bWVudHMubGVuZ3RoOyBpIDwgbjsgaSsrKSB7XG4gICAgICAgICAgICBzID0gYXJndW1lbnRzW2ldO1xuICAgICAgICAgICAgZm9yICh2YXIgcCBpbiBzKSBpZiAoT2JqZWN0LnByb3RvdHlwZS5oYXNPd25Qcm9wZXJ0eS5jYWxsKHMsIHApKVxuICAgICAgICAgICAgICAgIHRbcF0gPSBzW3BdO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiB0O1xuICAgIH07XG4gICAgcmV0dXJuIF9fYXNzaWduLmFwcGx5KHRoaXMsIGFyZ3VtZW50cyk7XG59O1xuT2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsIFwiX19lc01vZHVsZVwiLCB7IHZhbHVlOiB0cnVlIH0pO1xuZXhwb3J0cy50aGF3ID0gZXhwb3J0cy5UaGF3ID0gdm9pZCAwO1xuLyoqXG4gKiB0aGF3IGFuIGFycmF5IG9mIGl0ZW1zXG4gKi9cbnZhciBUaGF3ID0gLyoqIEBjbGFzcyAqLyAoZnVuY3Rpb24gKCkge1xuICAgIGZ1bmN0aW9uIFRoYXcoaXRlbXMsIG9wdGlvbnMpIHtcbiAgICAgICAgdmFyIF90aGlzID0gdGhpcztcbiAgICAgICAgaWYgKG9wdGlvbnMgPT09IHZvaWQgMCkgeyBvcHRpb25zID0ge307IH1cbiAgICAgICAgdmFyIF9hID0gX19hc3NpZ24oX19hc3NpZ24oe30sIFRoYXcuZGVmYXVsdFNldHRpbmdzKSwgb3B0aW9ucyksIGVhY2ggPSBfYS5lYWNoLCBkb25lID0gX2EuZG9uZTtcbiAgICAgICAgdGhpcy5pID0gMDtcbiAgICAgICAgdGhpcy5pc1N0b3BwZWQgPSBmYWxzZTtcbiAgICAgICAgdGhpcy5pdGVtcyA9IGl0ZW1zO1xuICAgICAgICB0aGlzLm9wdGlvbnMgPSBvcHRpb25zO1xuICAgICAgICB0aGlzLnRpY2sgPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICBpZiAoX3RoaXMuaXNTdG9wcGVkKVxuICAgICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgIF90aGlzLnRpbWVvdXQgPSBzZXRUaW1lb3V0KF90aGlzLnRpY2ssIDApO1xuICAgICAgICAgICAgaWYgKFRoYXcudGhhd2luZylcbiAgICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICB2YXIgaXRlbSA9IF90aGlzLml0ZW1zW190aGlzLmldO1xuICAgICAgICAgICAgaWYgKF90aGlzLmkgPj0gX3RoaXMuaXRlbXMubGVuZ3RoKSB7XG4gICAgICAgICAgICAgICAgaWYgKGRvbmUgIT09IG51bGwpIHtcbiAgICAgICAgICAgICAgICAgICAgVGhhdy50aGF3aW5nID0gdHJ1ZTtcbiAgICAgICAgICAgICAgICAgICAgZG9uZSgpO1xuICAgICAgICAgICAgICAgICAgICBUaGF3LnRoYXdpbmcgPSBmYWxzZTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgX3RoaXMuaXNTdG9wcGVkID0gdHJ1ZTtcbiAgICAgICAgICAgICAgICBjbGVhclRpbWVvdXQoX3RoaXMudGltZW91dCk7XG4gICAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaWYgKGVhY2ggIT09IG51bGwpIHtcbiAgICAgICAgICAgICAgICBUaGF3LnRoYXdpbmcgPSB0cnVlO1xuICAgICAgICAgICAgICAgIGVhY2goaXRlbSwgX3RoaXMuaSk7XG4gICAgICAgICAgICAgICAgVGhhdy50aGF3aW5nID0gZmFsc2U7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBlbHNlIGlmIChpdGVtICE9PSB1bmRlZmluZWQpIHtcbiAgICAgICAgICAgICAgICBpdGVtKCk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBfdGhpcy5pKys7XG4gICAgICAgIH07XG4gICAgICAgIFRoYXcudGhhd3MucHVzaCh0aGlzKTtcbiAgICAgICAgaWYgKCFvcHRpb25zLmRlbGF5KSB7XG4gICAgICAgICAgICB0aGlzLnRpY2soKTtcbiAgICAgICAgfVxuICAgIH1cbiAgICBPYmplY3QuZGVmaW5lUHJvcGVydHkoVGhhdywgXCJpc1RoYXdpbmdcIiwge1xuICAgICAgICAvKipcbiAgICAgICAgICogcmV0dXJucyBpZiBUaGF3LmpzIGlzIHRoYXdpbmdcbiAgICAgICAgICovXG4gICAgICAgIGdldDogZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgcmV0dXJuIFRoYXcudGhhd2luZztcbiAgICAgICAgfSxcbiAgICAgICAgZW51bWVyYWJsZTogZmFsc2UsXG4gICAgICAgIGNvbmZpZ3VyYWJsZTogdHJ1ZVxuICAgIH0pO1xuICAgIC8qKlxuICAgICAqIFN0b3BzIGFsbCBUaGF3IGluc3RhbmNlc1xuICAgICAqL1xuICAgIFRoYXcuc3RvcEFsbCA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgZm9yICh2YXIgaSA9IDA7IGkgPCBUaGF3LnRoYXdzLmxlbmd0aDsgaSsrKSB7XG4gICAgICAgICAgICBUaGF3LnRoYXdzW2ldLnN0b3AoKTtcbiAgICAgICAgfVxuICAgIH07XG4gICAgLyoqXG4gICAgICogcmVhZGllcyB0aGF3IHRvIGNvbnRpbnVlXG4gICAgICovXG4gICAgVGhhdy5wcm90b3R5cGUubWFrZVJlYWR5ID0gZnVuY3Rpb24gKCkge1xuICAgICAgICBpZiAodGhpcy5pc1N0b3BwZWQpIHtcbiAgICAgICAgICAgIHRoaXMuaXNTdG9wcGVkID0gZmFsc2U7XG4gICAgICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgfTtcbiAgICAvKipcbiAgICAgKiBBZGRzIGFuIGl0ZW0gdG8gdGhlIGVuZCBvZiB0aGlzIGluc3RhbmNlIG9mIFRoYXcgYW5kIHJlYWRpZXMgVGhhdyB0byBwcm9jZXNzIGl0XG4gICAgICovXG4gICAgVGhhdy5wcm90b3R5cGUuYWRkID0gZnVuY3Rpb24gKGl0ZW0pIHtcbiAgICAgICAgdGhpcy5pdGVtcy5wdXNoKGl0ZW0pO1xuICAgICAgICBpZiAodGhpcy5tYWtlUmVhZHkoKSkge1xuICAgICAgICAgICAgdGhpcy50aWNrKCk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHRoaXM7XG4gICAgfTtcbiAgICAvKipcbiAgICAgKiBJbnNlcnRzIGFuIGl0ZW0ganVzdCBhZnRlciB0aGUgY3VycmVudCBpdGVtIGJlaW5nIHByb2Nlc3NlZCBpbiBUaGF3IGFuZCByZWFkaWVzIFRoYXcgdG8gcHJvY2VzcyBpdFxuICAgICAqL1xuICAgIFRoYXcucHJvdG90eXBlLmluc2VydCA9IGZ1bmN0aW9uIChpdGVtKSB7XG4gICAgICAgIHRoaXMuaXRlbXMuc3BsaWNlKHRoaXMuaSwgMCwgaXRlbSk7XG4gICAgICAgIGlmICh0aGlzLm1ha2VSZWFkeSgpKSB7XG4gICAgICAgICAgICB0aGlzLnRpY2soKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gdGhpcztcbiAgICB9O1xuICAgIC8qKlxuICAgICAqIEFkZHMgYW4gQXJyYXkgdG8gdGhlIGVuZCBvZiB0aGlzIGluc3RhbmNlIG9mIFRoYXcgYW5kIHJlYWRpZXMgVGhhdyB0byBwcm9jZXNzIGl0XG4gICAgICovXG4gICAgVGhhdy5wcm90b3R5cGUuYWRkQXJyYXkgPSBmdW5jdGlvbiAoaXRlbXMpIHtcbiAgICAgICAgdGhpcy5pdGVtcyA9IHRoaXMuaXRlbXMuY29uY2F0KGl0ZW1zKTtcbiAgICAgICAgaWYgKHRoaXMubWFrZVJlYWR5KCkpIHtcbiAgICAgICAgICAgIHRoaXMudGljaygpO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiB0aGlzO1xuICAgIH07XG4gICAgLyoqXG4gICAgICogSW5zZXJ0cyBhbiBBcnJheSBqdXN0IGFmdGVyIHRoZSBjdXJyZW50IGl0ZW0gYmVpbmcgcHJvY2Vzc2VkIGluIFRoYXcgYW5kIHJlYWRpZXMgVGhhdyB0byBwcm9jZXNzIHRoZW1cbiAgICAgKi9cbiAgICBUaGF3LnByb3RvdHlwZS5pbnNlcnRBcnJheSA9IGZ1bmN0aW9uIChpdGVtcykge1xuICAgICAgICB2YXIgYmVmb3JlID0gdGhpcy5pdGVtcy5zcGxpY2UoMCwgdGhpcy5pKTtcbiAgICAgICAgdmFyIGFmdGVyID0gdGhpcy5pdGVtcztcbiAgICAgICAgdGhpcy5pdGVtcyA9IGJlZm9yZS5jb25jYXQoaXRlbXMsIGFmdGVyKTtcbiAgICAgICAgaWYgKHRoaXMubWFrZVJlYWR5KCkpIHtcbiAgICAgICAgICAgIHRoaXMudGljaygpO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiB0aGlzO1xuICAgIH07XG4gICAgLyoqXG4gICAgICogU3RvcHMgdGhpcyBpbnN0YW5jZSBvZiBUaGF3XG4gICAgICovXG4gICAgVGhhdy5wcm90b3R5cGUuc3RvcCA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgdGhpcy5pc1N0b3BwZWQgPSB0cnVlO1xuICAgICAgICBjbGVhclRpbWVvdXQodGhpcy50aW1lb3V0KTtcbiAgICAgICAgaWYgKHRoaXMub3B0aW9ucy5kb25lKSB7XG4gICAgICAgICAgICB0aGlzLm9wdGlvbnMuZG9uZSgpO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiB0aGlzO1xuICAgIH07XG4gICAgVGhhdy50aGF3aW5nID0gZmFsc2U7XG4gICAgVGhhdy50aGF3cyA9IFtdO1xuICAgIFRoYXcuZGVmYXVsdFNldHRpbmdzID0ge1xuICAgICAgICBlYWNoOiBudWxsLFxuICAgICAgICBkb25lOiBudWxsXG4gICAgfTtcbiAgICByZXR1cm4gVGhhdztcbn0oKSk7XG5leHBvcnRzLlRoYXcgPSBUaGF3O1xuLyoqXG4gKiBzaW1wbGUgdGhhd1xuICovXG5mdW5jdGlvbiB0aGF3KGl0ZW1zLCBvcHRpb25zKSB7XG4gICAgcmV0dXJuIG5ldyBUaGF3KGl0ZW1zLCBvcHRpb25zKTtcbn1cbmV4cG9ydHMudGhhdyA9IHRoYXc7XG5cbn0pO1xuXG52YXIgYmxvY2sgPSBjcmVhdGVDb21tb25qc01vZHVsZShmdW5jdGlvbiAobW9kdWxlLCBleHBvcnRzKSB7XG5PYmplY3QuZGVmaW5lUHJvcGVydHkoZXhwb3J0cywgXCJfX2VzTW9kdWxlXCIsIHsgdmFsdWU6IHRydWUgfSk7XG5leHBvcnRzLkJsb2NrID0gdm9pZCAwO1xuXG52YXIgQmxvY2sgPSAvKiogQGNsYXNzICovIChmdW5jdGlvbiAoKSB7XG4gICAgZnVuY3Rpb24gQmxvY2sob3B0aW9ucywgY291bnQpIHtcbiAgICAgICAgaWYgKGNvdW50ID09PSB2b2lkIDApIHsgY291bnQgPSAyMDA7IH1cbiAgICAgICAgdGhpcy5pbmRleCA9IDA7XG4gICAgICAgIHRoaXMudGhhd3MgPSBbXTtcbiAgICAgICAgdGhpcy5jb3VudCA9IGNvdW50O1xuICAgICAgICB0aGlzLm9wdGlvbnMgPSBvcHRpb25zO1xuICAgIH1cbiAgICAvKipcbiAgICAgKiBhZGQgYW4gaXRlbSB0byB0aGUgZW5kIG9mIGl0ZW1zXG4gICAgICovXG4gICAgQmxvY2sucHJvdG90eXBlLmFkZCA9IGZ1bmN0aW9uIChpdGVtKSB7XG4gICAgICAgIHZhciBuZXh0ID0gdGhpcy5uZXh0KCk7XG4gICAgICAgIG5leHQuYWRkKGl0ZW0pO1xuICAgICAgICByZXR1cm4gdGhpcztcbiAgICB9O1xuICAgIC8qKlxuICAgICAqIGFkZCBhbiBBcnJheSB0byB0aGUgZW5kIG9mIGl0ZW1zXG4gICAgICovXG4gICAgQmxvY2sucHJvdG90eXBlLmFkZEFycmF5ID0gZnVuY3Rpb24gKGl0ZW1zKSB7XG4gICAgICAgIHZhciBuZXh0ID0gdGhpcy5uZXh0KCk7XG4gICAgICAgIG5leHQuYWRkQXJyYXkoaXRlbXMpO1xuICAgICAgICByZXR1cm4gdGhpcztcbiAgICB9O1xuICAgIC8qKlxuICAgICAqIGluc2VydCBhbiBpdGVtIGludG8gaXRlbXMgQCBjdXJyZW50IHBvc2l0aW9uXG4gICAgICovXG4gICAgQmxvY2sucHJvdG90eXBlLmluc2VydCA9IGZ1bmN0aW9uIChpdGVtKSB7XG4gICAgICAgIHZhciBuZXh0ID0gdGhpcy5uZXh0KCk7XG4gICAgICAgIG5leHQuaW5zZXJ0KGl0ZW0pO1xuICAgICAgICByZXR1cm4gdGhpcztcbiAgICB9O1xuICAgIC8qKlxuICAgICAqIGluc2VydCBhbmQgYXJyYXkgaW50byBpdGVtcyBAIGN1cnJlbnQgcG9zaXRpb25cbiAgICAgKi9cbiAgICBCbG9jay5wcm90b3R5cGUuaW5zZXJ0QXJyYXkgPSBmdW5jdGlvbiAoaXRlbXMpIHtcbiAgICAgICAgdmFyIG5leHQgPSB0aGlzLm5leHQoKTtcbiAgICAgICAgbmV4dC5pbnNlcnRBcnJheShpdGVtcyk7XG4gICAgICAgIHJldHVybiB0aGlzO1xuICAgIH07XG4gICAgLyoqXG4gICAgICogU3RvcHMgYWxsIHRoYXdzIGluIHRoaXMgYmxvY2tcbiAgICAgKi9cbiAgICBCbG9jay5wcm90b3R5cGUuc3RvcCA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgZm9yICh2YXIgaSA9IDA7IGkgPCB0aGlzLnRoYXdzLmxlbmd0aDsgaSsrKSB7XG4gICAgICAgICAgICB0aGlzLnRoYXdzW2ldLnN0b3AoKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gdGhpcztcbiAgICB9O1xuICAgIC8qKlxuICAgICAqIEdldCBuZXh0IGF2YWlsYWJsZSBpbiBibG9ja1xuICAgICAqL1xuICAgIEJsb2NrLnByb3RvdHlwZS5uZXh0ID0gZnVuY3Rpb24gKCkge1xuICAgICAgICB2YXIgdGhhdztcbiAgICAgICAgdmFyIHRoYXdzID0gdGhpcy50aGF3cztcbiAgICAgICAgaWYgKHRoYXdzLmxlbmd0aCA8IHRoaXMuY291bnQpIHtcbiAgICAgICAgICAgIHRoYXcgPSBuZXcgdGhhd18xLlRoYXcoW10sIHRoaXMub3B0aW9ucyk7XG4gICAgICAgICAgICB0aGF3cy5wdXNoKHRoYXcpO1xuICAgICAgICB9XG4gICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgdGhhdyA9IHRoYXdzW3RoaXMuaW5kZXhdIHx8IG51bGw7XG4gICAgICAgIH1cbiAgICAgICAgdGhpcy5pbmRleCsrO1xuICAgICAgICBpZiAodGhpcy5pbmRleCA+PSB0aGlzLmNvdW50KSB7XG4gICAgICAgICAgICB0aGlzLmluZGV4ID0gMDtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gdGhhdztcbiAgICB9O1xuICAgIHJldHVybiBCbG9jaztcbn0oKSk7XG5leHBvcnRzLkJsb2NrID0gQmxvY2s7XG5cbn0pO1xuXG52YXIgZGlzdCA9IGNyZWF0ZUNvbW1vbmpzTW9kdWxlKGZ1bmN0aW9uIChtb2R1bGUsIGV4cG9ydHMpIHtcbk9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCBcIl9fZXNNb2R1bGVcIiwgeyB2YWx1ZTogdHJ1ZSB9KTtcbmV4cG9ydHMuQmxvY2sgPSBleHBvcnRzLnRoYXcgPSBleHBvcnRzLlRoYXcgPSB2b2lkIDA7XG5cbk9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCBcIlRoYXdcIiwgeyBlbnVtZXJhYmxlOiB0cnVlLCBnZXQ6IGZ1bmN0aW9uICgpIHsgcmV0dXJuIHRoYXdfMS5UaGF3OyB9IH0pO1xuT2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsIFwidGhhd1wiLCB7IGVudW1lcmFibGU6IHRydWUsIGdldDogZnVuY3Rpb24gKCkgeyByZXR1cm4gdGhhd18xLnRoYXc7IH0gfSk7XG5cbk9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCBcIkJsb2NrXCIsIHsgZW51bWVyYWJsZTogdHJ1ZSwgZ2V0OiBmdW5jdGlvbiAoKSB7IHJldHVybiBibG9jay5CbG9jazsgfSB9KTtcbmlmICh0eXBlb2Ygd2luZG93ICE9PSAndW5kZWZpbmVkJykge1xuICAgIC8vIEB0cy1pZ25vcmVcbiAgICB3aW5kb3cuVGhhdyA9IHRoYXdfMS5UaGF3O1xuICAgIC8vIEB0cy1pZ25vcmVcbiAgICB3aW5kb3cudGhhdyA9IHRoYXdfMS50aGF3O1xuICAgIC8vIEB0cy1pZ25vcmVcbiAgICB3aW5kb3cuVGhhdy5CbG9jayA9IGJsb2NrLkJsb2NrO1xufVxuXG59KTtcblxuZnVuY3Rpb24gYXJyYXlzVG9GbG9hdDMyQXJyYXlzKGFycmF5cykge1xuICAgIGNvbnN0IHJlc3VsdCA9IFtdO1xuICAgIGZvciAobGV0IGkgPSAwOyBpIDwgYXJyYXlzLmxlbmd0aDsgaSsrKSB7XG4gICAgICAgIHJlc3VsdC5wdXNoKEZsb2F0MzJBcnJheS5mcm9tKGFycmF5c1tpXSkpO1xuICAgIH1cbiAgICByZXR1cm4gcmVzdWx0O1xufVxuZnVuY3Rpb24gaW5wdXRPdXRwdXRBcnJheXNUb0Zsb2F0MzJBcnJheXMoaW5wdXQsIG91dHB1dCkge1xuICAgIGNvbnN0IHJlc3VsdCA9IFtdO1xuICAgIGZvciAobGV0IGkgPSAwOyBpIDwgaW5wdXQubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgcmVzdWx0LnB1c2goRmxvYXQzMkFycmF5LmZyb20oaW5wdXRbaV0pKTtcbiAgICB9XG4gICAgZm9yIChsZXQgaSA9IDA7IGkgPCBvdXRwdXQubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgcmVzdWx0LnB1c2goRmxvYXQzMkFycmF5LmZyb20ob3V0cHV0W2ldKSk7XG4gICAgfVxuICAgIHJldHVybiByZXN1bHQ7XG59XG5mdW5jdGlvbiBhcnJheVRvRmxvYXQzMkFycmF5cyhhcnJheSkge1xuICAgIGNvbnN0IHJlc3VsdCA9IFtdO1xuICAgIGZvciAobGV0IGkgPSAwOyBpIDwgYXJyYXkubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgcmVzdWx0LnB1c2goRmxvYXQzMkFycmF5LmZyb20oW2FycmF5W2ldXSkpO1xuICAgIH1cbiAgICByZXR1cm4gcmVzdWx0O1xufVxuZnVuY3Rpb24gaW5wdXRPdXRwdXRBcnJheVRvRmxvYXQzMkFycmF5cyhpbnB1dCwgb3V0cHV0KSB7XG4gICAgY29uc3QgcmVzdWx0ID0gW107XG4gICAgZm9yIChsZXQgaSA9IDA7IGkgPCBpbnB1dC5sZW5ndGg7IGkrKykge1xuICAgICAgICByZXN1bHQucHVzaChGbG9hdDMyQXJyYXkuZnJvbShbaW5wdXRbaV1dKSk7XG4gICAgfVxuICAgIGZvciAobGV0IGkgPSAwOyBpIDwgb3V0cHV0Lmxlbmd0aDsgaSsrKSB7XG4gICAgICAgIHJlc3VsdC5wdXNoKEZsb2F0MzJBcnJheS5mcm9tKFtvdXRwdXRbaV1dKSk7XG4gICAgfVxuICAgIHJldHVybiByZXN1bHQ7XG59XG5mdW5jdGlvbiBhcnJheVRvRmxvYXQzMkFycmF5KGFycmF5KSB7XG4gICAgcmV0dXJuIEZsb2F0MzJBcnJheS5mcm9tKGFycmF5KTtcbn1cbmZ1bmN0aW9uIGlucHV0T3V0cHV0T2JqZWN0c1RvRmxvYXQzMkFycmF5cyhpbnB1dCwgb3V0cHV0LCBpbnB1dFRhYmxlLCBvdXRwdXRUYWJsZSwgaW5wdXRMZW5ndGgsIG91dHB1dExlbmd0aCkge1xuICAgIGNvbnN0IHJlc3VsdHMgPSBbXTtcbiAgICBmb3IgKGxldCBpID0gMDsgaSA8IGlucHV0Lmxlbmd0aDsgaSsrKSB7XG4gICAgICAgIGNvbnN0IG9iamVjdCA9IGlucHV0W2ldO1xuICAgICAgICBjb25zdCByZXN1bHQgPSBuZXcgRmxvYXQzMkFycmF5KGlucHV0TGVuZ3RoKTtcbiAgICAgICAgZm9yIChjb25zdCBwIGluIG9iamVjdCkge1xuICAgICAgICAgICAgaWYgKG9iamVjdC5oYXNPd25Qcm9wZXJ0eShwKSkge1xuICAgICAgICAgICAgICAgIHJlc3VsdFtpbnB1dFRhYmxlW3BdXSA9IG9iamVjdFtwXTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICByZXN1bHRzLnB1c2gocmVzdWx0KTtcbiAgICB9XG4gICAgZm9yIChsZXQgaSA9IDA7IGkgPCBvdXRwdXQubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgY29uc3Qgb2JqZWN0ID0gb3V0cHV0W2ldO1xuICAgICAgICBjb25zdCByZXN1bHQgPSBuZXcgRmxvYXQzMkFycmF5KG91dHB1dExlbmd0aCk7XG4gICAgICAgIGZvciAoY29uc3QgcCBpbiBvYmplY3QpIHtcbiAgICAgICAgICAgIGlmIChvYmplY3QuaGFzT3duUHJvcGVydHkocCkpIHtcbiAgICAgICAgICAgICAgICByZXN1bHRbb3V0cHV0VGFibGVbcF1dID0gb2JqZWN0W3BdO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIHJlc3VsdHMucHVzaChyZXN1bHQpO1xuICAgIH1cbiAgICByZXR1cm4gcmVzdWx0cztcbn1cbmZ1bmN0aW9uIG9iamVjdFRvRmxvYXQzMkFycmF5cyhvYmplY3QpIHtcbiAgICBjb25zdCByZXN1bHQgPSBbXTtcbiAgICBmb3IgKGNvbnN0IHAgaW4gb2JqZWN0KSB7XG4gICAgICAgIGlmICghb2JqZWN0Lmhhc093blByb3BlcnR5KHApKVxuICAgICAgICAgICAgY29udGludWU7XG4gICAgICAgIHJlc3VsdC5wdXNoKEZsb2F0MzJBcnJheS5mcm9tKFtvYmplY3RbcF1dKSk7XG4gICAgfVxuICAgIHJldHVybiByZXN1bHQ7XG59XG5mdW5jdGlvbiBpbnB1dE91dHB1dE9iamVjdFRvRmxvYXQzMkFycmF5cyhpbnB1dCwgb3V0cHV0KSB7XG4gICAgY29uc3QgcmVzdWx0ID0gW107XG4gICAgZm9yIChjb25zdCBwIGluIGlucHV0KSB7XG4gICAgICAgIGlmICghaW5wdXQuaGFzT3duUHJvcGVydHkocCkpXG4gICAgICAgICAgICBjb250aW51ZTtcbiAgICAgICAgcmVzdWx0LnB1c2goRmxvYXQzMkFycmF5LmZyb20oW2lucHV0W3BdXSkpO1xuICAgIH1cbiAgICBmb3IgKGNvbnN0IHAgaW4gb3V0cHV0KSB7XG4gICAgICAgIGlmICghb3V0cHV0Lmhhc093blByb3BlcnR5KHApKVxuICAgICAgICAgICAgY29udGludWU7XG4gICAgICAgIHJlc3VsdC5wdXNoKEZsb2F0MzJBcnJheS5mcm9tKFtvdXRwdXRbcF1dKSk7XG4gICAgfVxuICAgIHJldHVybiByZXN1bHQ7XG59XG5mdW5jdGlvbiBvYmplY3RUb0Zsb2F0MzJBcnJheShvYmplY3QsIHRhYmxlLCBsZW5ndGgpIHtcbiAgICBjb25zdCByZXN1bHQgPSBuZXcgRmxvYXQzMkFycmF5KGxlbmd0aCk7XG4gICAgZm9yIChjb25zdCBwIGluIG9iamVjdCkge1xuICAgICAgICBpZiAob2JqZWN0Lmhhc093blByb3BlcnR5KHApKSB7XG4gICAgICAgICAgICByZXN1bHRbdGFibGVbcF1dID0gb2JqZWN0W3BdO1xuICAgICAgICB9XG4gICAgfVxuICAgIHJldHVybiByZXN1bHQ7XG59XG5cbmZ1bmN0aW9uIG1heCh2YWx1ZXMpIHtcbiAgICBpZiAoQXJyYXkuaXNBcnJheSh2YWx1ZXMpIHx8IHZhbHVlcyBpbnN0YW5jZW9mIEZsb2F0MzJBcnJheSkge1xuICAgICAgICByZXR1cm4gTWF0aC5tYXgoLi4udmFsdWVzKTtcbiAgICB9XG4gICAgZWxzZSB7XG4gICAgICAgIHJldHVybiBNYXRoLm1heCguLi5PYmplY3QudmFsdWVzKHZhbHVlcykpO1xuICAgIH1cbn1cblxuZnVuY3Rpb24gbXNlJDEoZXJyb3JzKSB7XG4gICAgLy8gbWVhbiBzcXVhcmVkIGVycm9yXG4gICAgbGV0IHN1bSA9IDA7XG4gICAgZm9yIChsZXQgaSA9IDA7IGkgPCBlcnJvcnMubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgc3VtICs9IGVycm9yc1tpXSAqKiAyO1xuICAgIH1cbiAgICByZXR1cm4gc3VtIC8gZXJyb3JzLmxlbmd0aDtcbn1cblxuZnVuY3Rpb24gZ2V0VHlwZWRBcnJheUZuKHZhbHVlLCB0YWJsZSkge1xuICAgIGlmICh2YWx1ZS5idWZmZXIgaW5zdGFuY2VvZiBBcnJheUJ1ZmZlcikge1xuICAgICAgICByZXR1cm4gbnVsbDtcbiAgICB9XG4gICAgaWYgKEFycmF5LmlzQXJyYXkodmFsdWUpKSB7XG4gICAgICAgIHJldHVybiBhcnJheVRvRmxvYXQzMkFycmF5O1xuICAgIH1cbiAgICBpZiAoIXRhYmxlKVxuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ3RhYmxlIGlzIG5vdCBPYmplY3QnKTtcbiAgICBjb25zdCB7IGxlbmd0aCB9ID0gT2JqZWN0LmtleXModGFibGUpO1xuICAgIHJldHVybiAodikgPT4ge1xuICAgICAgICBjb25zdCBhcnJheSA9IG5ldyBGbG9hdDMyQXJyYXkobGVuZ3RoKTtcbiAgICAgICAgZm9yIChjb25zdCBwIGluIHRhYmxlKSB7XG4gICAgICAgICAgICBpZiAoIXRhYmxlLmhhc093blByb3BlcnR5KHApKVxuICAgICAgICAgICAgICAgIGNvbnRpbnVlO1xuICAgICAgICAgICAgYXJyYXlbdGFibGVbcF1dID0gdltwXSB8fCAwO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBhcnJheTtcbiAgICB9O1xufVxuZnVuY3Rpb24gZGVmYXVsdHMkMigpIHtcbiAgICByZXR1cm4ge1xuICAgICAgICBpbnB1dFNpemU6IDAsXG4gICAgICAgIG91dHB1dFNpemU6IDAsXG4gICAgICAgIGJpbmFyeVRocmVzaDogMC41LFxuICAgIH07XG59XG5mdW5jdGlvbiB0cmFpbkRlZmF1bHRzJDIoKSB7XG4gICAgcmV0dXJuIHtcbiAgICAgICAgYWN0aXZhdGlvbjogJ3NpZ21vaWQnLFxuICAgICAgICBpdGVyYXRpb25zOiAyMDAwMCxcbiAgICAgICAgZXJyb3JUaHJlc2g6IDAuMDA1LFxuICAgICAgICBsb2c6IGZhbHNlLFxuICAgICAgICBsb2dQZXJpb2Q6IDEwLFxuICAgICAgICBsZWFreVJlbHVBbHBoYTogMC4wMSxcbiAgICAgICAgbGVhcm5pbmdSYXRlOiAwLjMsXG4gICAgICAgIG1vbWVudHVtOiAwLjEsXG4gICAgICAgIGNhbGxiYWNrUGVyaW9kOiAxMCxcbiAgICAgICAgdGltZW91dDogSW5maW5pdHksXG4gICAgICAgIGJldGExOiAwLjksXG4gICAgICAgIGJldGEyOiAwLjk5OSxcbiAgICAgICAgZXBzaWxvbjogMWUtOCxcbiAgICB9O1xufVxuY2xhc3MgTmV1cmFsTmV0d29yayB7XG4gICAgY29uc3RydWN0b3Iob3B0aW9ucyA9IHt9KSB7XG4gICAgICAgIHRoaXMub3B0aW9ucyA9IGRlZmF1bHRzJDIoKTtcbiAgICAgICAgdGhpcy50cmFpbk9wdHMgPSB0cmFpbkRlZmF1bHRzJDIoKTtcbiAgICAgICAgdGhpcy5zaXplcyA9IFtdO1xuICAgICAgICB0aGlzLm91dHB1dExheWVyID0gLTE7XG4gICAgICAgIHRoaXMuYmlhc2VzID0gW107XG4gICAgICAgIHRoaXMud2VpZ2h0cyA9IFtdOyAvLyB3ZWlnaHRzIGZvciBiaWFzIG5vZGVzXG4gICAgICAgIHRoaXMub3V0cHV0cyA9IFtdO1xuICAgICAgICAvLyBzdGF0ZSBmb3IgdHJhaW5pbmdcbiAgICAgICAgdGhpcy5kZWx0YXMgPSBbXTtcbiAgICAgICAgdGhpcy5jaGFuZ2VzID0gW107IC8vIGZvciBtb21lbnR1bVxuICAgICAgICB0aGlzLmVycm9ycyA9IFtdO1xuICAgICAgICB0aGlzLmVycm9yQ2hlY2tJbnRlcnZhbCA9IDE7XG4gICAgICAgIHRoaXMuaW5wdXRMb29rdXAgPSBudWxsO1xuICAgICAgICB0aGlzLmlucHV0TG9va3VwTGVuZ3RoID0gMDtcbiAgICAgICAgdGhpcy5vdXRwdXRMb29rdXAgPSBudWxsO1xuICAgICAgICB0aGlzLm91dHB1dExvb2t1cExlbmd0aCA9IDA7XG4gICAgICAgIHRoaXMuX2Zvcm1hdElucHV0ID0gbnVsbDtcbiAgICAgICAgdGhpcy5fZm9ybWF0T3V0cHV0ID0gbnVsbDtcbiAgICAgICAgdGhpcy5ydW5JbnB1dCA9IChpbnB1dCkgPT4ge1xuICAgICAgICAgICAgdGhpcy5zZXRBY3RpdmF0aW9uKCk7XG4gICAgICAgICAgICByZXR1cm4gdGhpcy5ydW5JbnB1dChpbnB1dCk7XG4gICAgICAgIH07XG4gICAgICAgIHRoaXMuY2FsY3VsYXRlRGVsdGFzID0gKG91dHB1dCkgPT4ge1xuICAgICAgICAgICAgdGhpcy5zZXRBY3RpdmF0aW9uKCk7XG4gICAgICAgICAgICByZXR1cm4gdGhpcy5jYWxjdWxhdGVEZWx0YXMob3V0cHV0KTtcbiAgICAgICAgfTtcbiAgICAgICAgLy8gYWRhbVxuICAgICAgICB0aGlzLmJpYXNDaGFuZ2VzTG93ID0gW107XG4gICAgICAgIHRoaXMuYmlhc0NoYW5nZXNIaWdoID0gW107XG4gICAgICAgIHRoaXMuY2hhbmdlc0xvdyA9IFtdO1xuICAgICAgICB0aGlzLmNoYW5nZXNIaWdoID0gW107XG4gICAgICAgIHRoaXMuaXRlcmF0aW9ucyA9IDA7XG4gICAgICAgIHRoaXMub3B0aW9ucyA9IHsgLi4udGhpcy5vcHRpb25zLCAuLi5vcHRpb25zIH07XG4gICAgICAgIHRoaXMudXBkYXRlVHJhaW5pbmdPcHRpb25zKG9wdGlvbnMpO1xuICAgICAgICBjb25zdCB7IGlucHV0U2l6ZSwgaGlkZGVuTGF5ZXJzLCBvdXRwdXRTaXplIH0gPSB0aGlzLm9wdGlvbnM7XG4gICAgICAgIGlmIChpbnB1dFNpemUgJiYgb3V0cHV0U2l6ZSkge1xuICAgICAgICAgICAgdGhpcy5zaXplcyA9IFtpbnB1dFNpemVdLmNvbmNhdChoaWRkZW5MYXllcnMgIT09IG51bGwgJiYgaGlkZGVuTGF5ZXJzICE9PSB2b2lkIDAgPyBoaWRkZW5MYXllcnMgOiBbXSkuY29uY2F0KFtvdXRwdXRTaXplXSk7XG4gICAgICAgIH1cbiAgICB9XG4gICAgLyoqXG4gICAgICpcbiAgICAgKiBFeHBlY3RzIHRoaXMuc2l6ZXMgdG8gaGF2ZSBiZWVuIHNldFxuICAgICAqL1xuICAgIGluaXRpYWxpemUoKSB7XG4gICAgICAgIGlmICghdGhpcy5zaXplcy5sZW5ndGgpIHtcbiAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcignU2l6ZXMgbXVzdCBiZSBzZXQgYmVmb3JlIGluaXRpYWxpemluZycpO1xuICAgICAgICB9XG4gICAgICAgIHRoaXMub3V0cHV0TGF5ZXIgPSB0aGlzLnNpemVzLmxlbmd0aCAtIDE7XG4gICAgICAgIHRoaXMuYmlhc2VzID0gbmV3IEFycmF5KHRoaXMub3V0cHV0TGF5ZXIpOyAvLyB3ZWlnaHRzIGZvciBiaWFzIG5vZGVzXG4gICAgICAgIHRoaXMud2VpZ2h0cyA9IG5ldyBBcnJheSh0aGlzLm91dHB1dExheWVyKTtcbiAgICAgICAgdGhpcy5vdXRwdXRzID0gbmV3IEFycmF5KHRoaXMub3V0cHV0TGF5ZXIpO1xuICAgICAgICAvLyBzdGF0ZSBmb3IgdHJhaW5pbmdcbiAgICAgICAgdGhpcy5kZWx0YXMgPSBuZXcgQXJyYXkodGhpcy5vdXRwdXRMYXllcik7XG4gICAgICAgIHRoaXMuY2hhbmdlcyA9IG5ldyBBcnJheSh0aGlzLm91dHB1dExheWVyKTsgLy8gZm9yIG1vbWVudHVtXG4gICAgICAgIHRoaXMuZXJyb3JzID0gbmV3IEFycmF5KHRoaXMub3V0cHV0TGF5ZXIpO1xuICAgICAgICBmb3IgKGxldCBsYXllckluZGV4ID0gMDsgbGF5ZXJJbmRleCA8PSB0aGlzLm91dHB1dExheWVyOyBsYXllckluZGV4KyspIHtcbiAgICAgICAgICAgIGNvbnN0IHNpemUgPSB0aGlzLnNpemVzW2xheWVySW5kZXhdO1xuICAgICAgICAgICAgdGhpcy5kZWx0YXNbbGF5ZXJJbmRleF0gPSB6ZXJvcyQxKHNpemUpO1xuICAgICAgICAgICAgdGhpcy5lcnJvcnNbbGF5ZXJJbmRleF0gPSB6ZXJvcyQxKHNpemUpO1xuICAgICAgICAgICAgdGhpcy5vdXRwdXRzW2xheWVySW5kZXhdID0gemVyb3MkMShzaXplKTtcbiAgICAgICAgICAgIGlmIChsYXllckluZGV4ID4gMCkge1xuICAgICAgICAgICAgICAgIHRoaXMuYmlhc2VzW2xheWVySW5kZXhdID0gcmFuZG9zKHNpemUpO1xuICAgICAgICAgICAgICAgIHRoaXMud2VpZ2h0c1tsYXllckluZGV4XSA9IG5ldyBBcnJheShzaXplKTtcbiAgICAgICAgICAgICAgICB0aGlzLmNoYW5nZXNbbGF5ZXJJbmRleF0gPSBuZXcgQXJyYXkoc2l6ZSk7XG4gICAgICAgICAgICAgICAgZm9yIChsZXQgbm9kZUluZGV4ID0gMDsgbm9kZUluZGV4IDwgc2l6ZTsgbm9kZUluZGV4KyspIHtcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgcHJldlNpemUgPSB0aGlzLnNpemVzW2xheWVySW5kZXggLSAxXTtcbiAgICAgICAgICAgICAgICAgICAgdGhpcy53ZWlnaHRzW2xheWVySW5kZXhdW25vZGVJbmRleF0gPSByYW5kb3MocHJldlNpemUpO1xuICAgICAgICAgICAgICAgICAgICB0aGlzLmNoYW5nZXNbbGF5ZXJJbmRleF1bbm9kZUluZGV4XSA9IHplcm9zJDEocHJldlNpemUpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICB0aGlzLnNldEFjdGl2YXRpb24oKTtcbiAgICAgICAgaWYgKHRoaXMudHJhaW5PcHRzLnByYXhpcyA9PT0gJ2FkYW0nKSB7XG4gICAgICAgICAgICB0aGlzLl9zZXR1cEFkYW0oKTtcbiAgICAgICAgfVxuICAgIH1cbiAgICBzZXRBY3RpdmF0aW9uKGFjdGl2YXRpb24pIHtcbiAgICAgICAgY29uc3QgdmFsdWUgPSBhY3RpdmF0aW9uICE9PSBudWxsICYmIGFjdGl2YXRpb24gIT09IHZvaWQgMCA/IGFjdGl2YXRpb24gOiB0aGlzLnRyYWluT3B0cy5hY3RpdmF0aW9uO1xuICAgICAgICBzd2l0Y2ggKHZhbHVlKSB7XG4gICAgICAgICAgICBjYXNlICdzaWdtb2lkJzpcbiAgICAgICAgICAgICAgICB0aGlzLnJ1bklucHV0ID0gdGhpcy5fcnVuSW5wdXRTaWdtb2lkO1xuICAgICAgICAgICAgICAgIHRoaXMuY2FsY3VsYXRlRGVsdGFzID0gdGhpcy5fY2FsY3VsYXRlRGVsdGFzU2lnbW9pZDtcbiAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgIGNhc2UgJ3JlbHUnOlxuICAgICAgICAgICAgICAgIHRoaXMucnVuSW5wdXQgPSB0aGlzLl9ydW5JbnB1dFJlbHU7XG4gICAgICAgICAgICAgICAgdGhpcy5jYWxjdWxhdGVEZWx0YXMgPSB0aGlzLl9jYWxjdWxhdGVEZWx0YXNSZWx1O1xuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgY2FzZSAnbGVha3ktcmVsdSc6XG4gICAgICAgICAgICAgICAgdGhpcy5ydW5JbnB1dCA9IHRoaXMuX3J1bklucHV0TGVha3lSZWx1O1xuICAgICAgICAgICAgICAgIHRoaXMuY2FsY3VsYXRlRGVsdGFzID0gdGhpcy5fY2FsY3VsYXRlRGVsdGFzTGVha3lSZWx1O1xuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgY2FzZSAndGFuaCc6XG4gICAgICAgICAgICAgICAgdGhpcy5ydW5JbnB1dCA9IHRoaXMuX3J1bklucHV0VGFuaDtcbiAgICAgICAgICAgICAgICB0aGlzLmNhbGN1bGF0ZURlbHRhcyA9IHRoaXMuX2NhbGN1bGF0ZURlbHRhc1Rhbmg7XG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICBkZWZhdWx0OlxuICAgICAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcihgVW5rbm93biBhY3RpdmF0aW9uICR7dmFsdWV9LiBBdmFpbGFibGUgYWN0aXZhdGlvbnMgYXJlOiAnc2lnbW9pZCcsICdyZWx1JywgJ2xlYWt5LXJlbHUnLCAndGFuaCdgKTtcbiAgICAgICAgfVxuICAgIH1cbiAgICBnZXQgaXNSdW5uYWJsZSgpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuc2l6ZXMubGVuZ3RoID4gMDtcbiAgICB9XG4gICAgcnVuKGlucHV0KSB7XG4gICAgICAgIGlmICghdGhpcy5pc1J1bm5hYmxlKSB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ25ldHdvcmsgbm90IHJ1bm5hYmxlJyk7XG4gICAgICAgIH1cbiAgICAgICAgbGV0IGZvcm1hdHRlZElucHV0O1xuICAgICAgICBpZiAodGhpcy5pbnB1dExvb2t1cCkge1xuICAgICAgICAgICAgZm9ybWF0dGVkSW5wdXQgPSBsb29rdXAudG9BcnJheSh0aGlzLmlucHV0TG9va3VwLCBpbnB1dCwgdGhpcy5pbnB1dExvb2t1cExlbmd0aCk7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICBmb3JtYXR0ZWRJbnB1dCA9IGlucHV0O1xuICAgICAgICB9XG4gICAgICAgIGlmIChmb3JtYXR0ZWRJbnB1dC5sZW5ndGggIT09IHRoaXMuc2l6ZXNbMF0pIHtcbiAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcihgaW5wdXQgaXMgbm90IGluIGNvcnJlY3QgbGVuZ3RoIG9mICR7dGhpcy5zaXplc1swXX1gKTtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCBvdXRwdXQgPSB0aGlzLnJ1bklucHV0KGZvcm1hdHRlZElucHV0KS5zbGljZSgwKTtcbiAgICAgICAgaWYgKHRoaXMub3V0cHV0TG9va3VwKSB7XG4gICAgICAgICAgICByZXR1cm4gbG9va3VwLnRvT2JqZWN0KHRoaXMub3V0cHV0TG9va3VwLCBvdXRwdXQpO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBvdXRwdXQ7XG4gICAgfVxuICAgIF9ydW5JbnB1dFNpZ21vaWQoaW5wdXQpIHtcbiAgICAgICAgdGhpcy5vdXRwdXRzWzBdID0gaW5wdXQ7IC8vIHNldCBvdXRwdXQgc3RhdGUgb2YgaW5wdXQgbGF5ZXJcbiAgICAgICAgbGV0IG91dHB1dCA9IG51bGw7XG4gICAgICAgIGZvciAobGV0IGxheWVyID0gMTsgbGF5ZXIgPD0gdGhpcy5vdXRwdXRMYXllcjsgbGF5ZXIrKykge1xuICAgICAgICAgICAgY29uc3QgYWN0aXZlTGF5ZXIgPSB0aGlzLnNpemVzW2xheWVyXTtcbiAgICAgICAgICAgIGNvbnN0IGFjdGl2ZVdlaWdodHMgPSB0aGlzLndlaWdodHNbbGF5ZXJdO1xuICAgICAgICAgICAgY29uc3QgYWN0aXZlQmlhc2VzID0gdGhpcy5iaWFzZXNbbGF5ZXJdO1xuICAgICAgICAgICAgY29uc3QgYWN0aXZlT3V0cHV0cyA9IHRoaXMub3V0cHV0c1tsYXllcl07XG4gICAgICAgICAgICBmb3IgKGxldCBub2RlID0gMDsgbm9kZSA8IGFjdGl2ZUxheWVyOyBub2RlKyspIHtcbiAgICAgICAgICAgICAgICBjb25zdCB3ZWlnaHRzID0gYWN0aXZlV2VpZ2h0c1tub2RlXTtcbiAgICAgICAgICAgICAgICBsZXQgc3VtID0gYWN0aXZlQmlhc2VzW25vZGVdO1xuICAgICAgICAgICAgICAgIGZvciAobGV0IGsgPSAwOyBrIDwgd2VpZ2h0cy5sZW5ndGg7IGsrKykge1xuICAgICAgICAgICAgICAgICAgICBzdW0gKz0gd2VpZ2h0c1trXSAqIGlucHV0W2tdO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAvLyBzaWdtb2lkXG4gICAgICAgICAgICAgICAgYWN0aXZlT3V0cHV0c1tub2RlXSA9IDEgLyAoMSArIE1hdGguZXhwKC1zdW0pKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIG91dHB1dCA9IGlucHV0ID0gYWN0aXZlT3V0cHV0cztcbiAgICAgICAgfVxuICAgICAgICBpZiAoIW91dHB1dCkge1xuICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdvdXRwdXQgd2FzIGVtcHR5Jyk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIG91dHB1dDtcbiAgICB9XG4gICAgX3J1bklucHV0UmVsdShpbnB1dCkge1xuICAgICAgICB0aGlzLm91dHB1dHNbMF0gPSBpbnB1dDsgLy8gc2V0IG91dHB1dCBzdGF0ZSBvZiBpbnB1dCBsYXllclxuICAgICAgICBsZXQgb3V0cHV0ID0gbnVsbDtcbiAgICAgICAgZm9yIChsZXQgbGF5ZXIgPSAxOyBsYXllciA8PSB0aGlzLm91dHB1dExheWVyOyBsYXllcisrKSB7XG4gICAgICAgICAgICBjb25zdCBhY3RpdmVTaXplID0gdGhpcy5zaXplc1tsYXllcl07XG4gICAgICAgICAgICBjb25zdCBhY3RpdmVXZWlnaHRzID0gdGhpcy53ZWlnaHRzW2xheWVyXTtcbiAgICAgICAgICAgIGNvbnN0IGFjdGl2ZUJpYXNlcyA9IHRoaXMuYmlhc2VzW2xheWVyXTtcbiAgICAgICAgICAgIGNvbnN0IGFjdGl2ZU91dHB1dHMgPSB0aGlzLm91dHB1dHNbbGF5ZXJdO1xuICAgICAgICAgICAgZm9yIChsZXQgbm9kZSA9IDA7IG5vZGUgPCBhY3RpdmVTaXplOyBub2RlKyspIHtcbiAgICAgICAgICAgICAgICBjb25zdCB3ZWlnaHRzID0gYWN0aXZlV2VpZ2h0c1tub2RlXTtcbiAgICAgICAgICAgICAgICBsZXQgc3VtID0gYWN0aXZlQmlhc2VzW25vZGVdO1xuICAgICAgICAgICAgICAgIGZvciAobGV0IGsgPSAwOyBrIDwgd2VpZ2h0cy5sZW5ndGg7IGsrKykge1xuICAgICAgICAgICAgICAgICAgICBzdW0gKz0gd2VpZ2h0c1trXSAqIGlucHV0W2tdO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAvLyByZWx1XG4gICAgICAgICAgICAgICAgYWN0aXZlT3V0cHV0c1tub2RlXSA9IHN1bSA8IDAgPyAwIDogc3VtO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgb3V0cHV0ID0gaW5wdXQgPSBhY3RpdmVPdXRwdXRzO1xuICAgICAgICB9XG4gICAgICAgIGlmICghb3V0cHV0KSB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ291dHB1dCB3YXMgZW1wdHknKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gb3V0cHV0O1xuICAgIH1cbiAgICBfcnVuSW5wdXRMZWFreVJlbHUoaW5wdXQpIHtcbiAgICAgICAgdGhpcy5vdXRwdXRzWzBdID0gaW5wdXQ7IC8vIHNldCBvdXRwdXQgc3RhdGUgb2YgaW5wdXQgbGF5ZXJcbiAgICAgICAgY29uc3QgeyBsZWFreVJlbHVBbHBoYSB9ID0gdGhpcy50cmFpbk9wdHM7XG4gICAgICAgIGxldCBvdXRwdXQgPSBudWxsO1xuICAgICAgICBmb3IgKGxldCBsYXllciA9IDE7IGxheWVyIDw9IHRoaXMub3V0cHV0TGF5ZXI7IGxheWVyKyspIHtcbiAgICAgICAgICAgIGNvbnN0IGFjdGl2ZVNpemUgPSB0aGlzLnNpemVzW2xheWVyXTtcbiAgICAgICAgICAgIGNvbnN0IGFjdGl2ZVdlaWdodHMgPSB0aGlzLndlaWdodHNbbGF5ZXJdO1xuICAgICAgICAgICAgY29uc3QgYWN0aXZlQmlhc2VzID0gdGhpcy5iaWFzZXNbbGF5ZXJdO1xuICAgICAgICAgICAgY29uc3QgYWN0aXZlT3V0cHV0cyA9IHRoaXMub3V0cHV0c1tsYXllcl07XG4gICAgICAgICAgICBmb3IgKGxldCBub2RlID0gMDsgbm9kZSA8IGFjdGl2ZVNpemU7IG5vZGUrKykge1xuICAgICAgICAgICAgICAgIGNvbnN0IHdlaWdodHMgPSBhY3RpdmVXZWlnaHRzW25vZGVdO1xuICAgICAgICAgICAgICAgIGxldCBzdW0gPSBhY3RpdmVCaWFzZXNbbm9kZV07XG4gICAgICAgICAgICAgICAgZm9yIChsZXQgayA9IDA7IGsgPCB3ZWlnaHRzLmxlbmd0aDsgaysrKSB7XG4gICAgICAgICAgICAgICAgICAgIHN1bSArPSB3ZWlnaHRzW2tdICogaW5wdXRba107XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIC8vIGxlYWt5IHJlbHVcbiAgICAgICAgICAgICAgICBhY3RpdmVPdXRwdXRzW25vZGVdID0gTWF0aC5tYXgoc3VtLCBsZWFreVJlbHVBbHBoYSAqIHN1bSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBvdXRwdXQgPSBpbnB1dCA9IGFjdGl2ZU91dHB1dHM7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKCFvdXRwdXQpIHtcbiAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcignb3V0cHV0IHdhcyBlbXB0eScpO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBvdXRwdXQ7XG4gICAgfVxuICAgIF9ydW5JbnB1dFRhbmgoaW5wdXQpIHtcbiAgICAgICAgdGhpcy5vdXRwdXRzWzBdID0gaW5wdXQ7IC8vIHNldCBvdXRwdXQgc3RhdGUgb2YgaW5wdXQgbGF5ZXJcbiAgICAgICAgbGV0IG91dHB1dCA9IG51bGw7XG4gICAgICAgIGZvciAobGV0IGxheWVyID0gMTsgbGF5ZXIgPD0gdGhpcy5vdXRwdXRMYXllcjsgbGF5ZXIrKykge1xuICAgICAgICAgICAgY29uc3QgYWN0aXZlU2l6ZSA9IHRoaXMuc2l6ZXNbbGF5ZXJdO1xuICAgICAgICAgICAgY29uc3QgYWN0aXZlV2VpZ2h0cyA9IHRoaXMud2VpZ2h0c1tsYXllcl07XG4gICAgICAgICAgICBjb25zdCBhY3RpdmVCaWFzZXMgPSB0aGlzLmJpYXNlc1tsYXllcl07XG4gICAgICAgICAgICBjb25zdCBhY3RpdmVPdXRwdXRzID0gdGhpcy5vdXRwdXRzW2xheWVyXTtcbiAgICAgICAgICAgIGZvciAobGV0IG5vZGUgPSAwOyBub2RlIDwgYWN0aXZlU2l6ZTsgbm9kZSsrKSB7XG4gICAgICAgICAgICAgICAgY29uc3Qgd2VpZ2h0cyA9IGFjdGl2ZVdlaWdodHNbbm9kZV07XG4gICAgICAgICAgICAgICAgbGV0IHN1bSA9IGFjdGl2ZUJpYXNlc1tub2RlXTtcbiAgICAgICAgICAgICAgICBmb3IgKGxldCBrID0gMDsgayA8IHdlaWdodHMubGVuZ3RoOyBrKyspIHtcbiAgICAgICAgICAgICAgICAgICAgc3VtICs9IHdlaWdodHNba10gKiBpbnB1dFtrXTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgLy8gdGFuaFxuICAgICAgICAgICAgICAgIGFjdGl2ZU91dHB1dHNbbm9kZV0gPSBNYXRoLnRhbmgoc3VtKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIG91dHB1dCA9IGlucHV0ID0gYWN0aXZlT3V0cHV0cztcbiAgICAgICAgfVxuICAgICAgICBpZiAoIW91dHB1dCkge1xuICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdvdXRwdXQgd2FzIGVtcHR5Jyk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIG91dHB1dDtcbiAgICB9XG4gICAgLyoqXG4gICAgICpcbiAgICAgKiBWZXJpZmllcyBuZXR3b3JrIHNpemVzIGFyZSBpbml0aWFsaXplZFxuICAgICAqIElmIHRoZXkgYXJlIG5vdCBpdCB3aWxsIGluaXRpYWxpemUgdGhlbSBiYXNlZCBvZmYgdGhlIGRhdGEgc2V0LlxuICAgICAqL1xuICAgIHZlcmlmeUlzSW5pdGlhbGl6ZWQocHJlcGFyZWREYXRhKSB7XG4gICAgICAgIGlmICh0aGlzLnNpemVzLmxlbmd0aClcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgdGhpcy5zaXplcyA9IFtdO1xuICAgICAgICB0aGlzLnNpemVzLnB1c2gocHJlcGFyZWREYXRhWzBdLmlucHV0Lmxlbmd0aCk7XG4gICAgICAgIGlmICghdGhpcy5vcHRpb25zLmhpZGRlbkxheWVycykge1xuICAgICAgICAgICAgdGhpcy5zaXplcy5wdXNoKE1hdGgubWF4KDMsIE1hdGguZmxvb3IocHJlcGFyZWREYXRhWzBdLmlucHV0Lmxlbmd0aCAvIDIpKSk7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICB0aGlzLm9wdGlvbnMuaGlkZGVuTGF5ZXJzLmZvckVhY2goKHNpemUpID0+IHtcbiAgICAgICAgICAgICAgICB0aGlzLnNpemVzLnB1c2goc2l6ZSk7XG4gICAgICAgICAgICB9KTtcbiAgICAgICAgfVxuICAgICAgICB0aGlzLnNpemVzLnB1c2gocHJlcGFyZWREYXRhWzBdLm91dHB1dC5sZW5ndGgpO1xuICAgICAgICB0aGlzLmluaXRpYWxpemUoKTtcbiAgICB9XG4gICAgdXBkYXRlVHJhaW5pbmdPcHRpb25zKHRyYWluT3B0cykge1xuICAgICAgICBjb25zdCBtZXJnZWQgPSB7IC4uLnRoaXMudHJhaW5PcHRzLCAuLi50cmFpbk9wdHMgfTtcbiAgICAgICAgdGhpcy52YWxpZGF0ZVRyYWluaW5nT3B0aW9ucyhtZXJnZWQpO1xuICAgICAgICB0aGlzLnRyYWluT3B0cyA9IG1lcmdlZDtcbiAgICAgICAgdGhpcy5zZXRMb2dNZXRob2QodGhpcy50cmFpbk9wdHMubG9nKTtcbiAgICB9XG4gICAgdmFsaWRhdGVUcmFpbmluZ09wdGlvbnMob3B0aW9ucykge1xuICAgICAgICBjb25zdCB2YWxpZGF0aW9ucyA9IHtcbiAgICAgICAgICAgIGFjdGl2YXRpb246ICgpID0+IHtcbiAgICAgICAgICAgICAgICByZXR1cm4gWydzaWdtb2lkJywgJ3JlbHUnLCAnbGVha3ktcmVsdScsICd0YW5oJ10uaW5jbHVkZXMob3B0aW9ucy5hY3RpdmF0aW9uKTtcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBpdGVyYXRpb25zOiAoKSA9PiB7XG4gICAgICAgICAgICAgICAgY29uc3QgdmFsID0gb3B0aW9ucy5pdGVyYXRpb25zO1xuICAgICAgICAgICAgICAgIHJldHVybiB0eXBlb2YgdmFsID09PSAnbnVtYmVyJyAmJiB2YWwgPiAwO1xuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIGVycm9yVGhyZXNoOiAoKSA9PiB7XG4gICAgICAgICAgICAgICAgY29uc3QgdmFsID0gb3B0aW9ucy5lcnJvclRocmVzaDtcbiAgICAgICAgICAgICAgICByZXR1cm4gdHlwZW9mIHZhbCA9PT0gJ251bWJlcicgJiYgdmFsID4gMCAmJiB2YWwgPCAxO1xuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIGxvZzogKCkgPT4ge1xuICAgICAgICAgICAgICAgIGNvbnN0IHZhbCA9IG9wdGlvbnMubG9nO1xuICAgICAgICAgICAgICAgIHJldHVybiB0eXBlb2YgdmFsID09PSAnZnVuY3Rpb24nIHx8IHR5cGVvZiB2YWwgPT09ICdib29sZWFuJztcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBsb2dQZXJpb2Q6ICgpID0+IHtcbiAgICAgICAgICAgICAgICBjb25zdCB2YWwgPSBvcHRpb25zLmxvZ1BlcmlvZDtcbiAgICAgICAgICAgICAgICByZXR1cm4gdHlwZW9mIHZhbCA9PT0gJ251bWJlcicgJiYgdmFsID4gMDtcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBsZWFreVJlbHVBbHBoYTogKCkgPT4ge1xuICAgICAgICAgICAgICAgIGNvbnN0IHZhbCA9IG9wdGlvbnMubGVha3lSZWx1QWxwaGE7XG4gICAgICAgICAgICAgICAgcmV0dXJuIHR5cGVvZiB2YWwgPT09ICdudW1iZXInICYmIHZhbCA+IDAgJiYgdmFsIDwgMTtcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBsZWFybmluZ1JhdGU6ICgpID0+IHtcbiAgICAgICAgICAgICAgICBjb25zdCB2YWwgPSBvcHRpb25zLmxlYXJuaW5nUmF0ZTtcbiAgICAgICAgICAgICAgICByZXR1cm4gdHlwZW9mIHZhbCA9PT0gJ251bWJlcicgJiYgdmFsID4gMCAmJiB2YWwgPCAxO1xuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIG1vbWVudHVtOiAoKSA9PiB7XG4gICAgICAgICAgICAgICAgY29uc3QgdmFsID0gb3B0aW9ucy5tb21lbnR1bTtcbiAgICAgICAgICAgICAgICByZXR1cm4gdHlwZW9mIHZhbCA9PT0gJ251bWJlcicgJiYgdmFsID4gMCAmJiB2YWwgPCAxO1xuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIGNhbGxiYWNrOiAoKSA9PiB7XG4gICAgICAgICAgICAgICAgY29uc3QgdmFsID0gb3B0aW9ucy5jYWxsYmFjaztcbiAgICAgICAgICAgICAgICByZXR1cm4gdHlwZW9mIHZhbCA9PT0gJ2Z1bmN0aW9uJyB8fCB2YWwgPT09IHVuZGVmaW5lZDtcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBjYWxsYmFja1BlcmlvZDogKCkgPT4ge1xuICAgICAgICAgICAgICAgIGNvbnN0IHZhbCA9IG9wdGlvbnMuY2FsbGJhY2tQZXJpb2Q7XG4gICAgICAgICAgICAgICAgcmV0dXJuIHR5cGVvZiB2YWwgPT09ICdudW1iZXInICYmIHZhbCA+IDA7XG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgdGltZW91dDogKCkgPT4ge1xuICAgICAgICAgICAgICAgIGNvbnN0IHZhbCA9IG9wdGlvbnMudGltZW91dDtcbiAgICAgICAgICAgICAgICByZXR1cm4gdHlwZW9mIHZhbCA9PT0gJ251bWJlcicgJiYgdmFsID4gMDtcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBwcmF4aXM6ICgpID0+IHtcbiAgICAgICAgICAgICAgICBjb25zdCB2YWwgPSBvcHRpb25zLnByYXhpcztcbiAgICAgICAgICAgICAgICByZXR1cm4gIXZhbCB8fCB2YWwgPT09ICdhZGFtJztcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBiZXRhMTogKCkgPT4ge1xuICAgICAgICAgICAgICAgIGNvbnN0IHZhbCA9IG9wdGlvbnMuYmV0YTE7XG4gICAgICAgICAgICAgICAgcmV0dXJuIHZhbCA+IDAgJiYgdmFsIDwgMTtcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBiZXRhMjogKCkgPT4ge1xuICAgICAgICAgICAgICAgIGNvbnN0IHZhbCA9IG9wdGlvbnMuYmV0YTI7XG4gICAgICAgICAgICAgICAgcmV0dXJuIHZhbCA+IDAgJiYgdmFsIDwgMTtcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBlcHNpbG9uOiAoKSA9PiB7XG4gICAgICAgICAgICAgICAgY29uc3QgdmFsID0gb3B0aW9ucy5lcHNpbG9uO1xuICAgICAgICAgICAgICAgIHJldHVybiB2YWwgPiAwICYmIHZhbCA8IDE7XG4gICAgICAgICAgICB9LFxuICAgICAgICB9O1xuICAgICAgICBmb3IgKGNvbnN0IHAgaW4gdmFsaWRhdGlvbnMpIHtcbiAgICAgICAgICAgIGNvbnN0IHYgPSBvcHRpb25zO1xuICAgICAgICAgICAgaWYgKCF2YWxpZGF0aW9uc1twXSgpKSB7XG4gICAgICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKGBbJHtwfSwgJHt2W3BdfV0gaXMgb3V0IG9mIG5vcm1hbCB0cmFpbmluZyByYW5nZSwgeW91ciBuZXR3b3JrIHdpbGwgcHJvYmFibHkgbm90IHRyYWluLmApO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfVxuICAgIC8qKlxuICAgICAqXG4gICAgICogIEdldHMgSlNPTiBvZiB0cmFpbk9wdHMgb2JqZWN0XG4gICAgICogICAgTk9URTogQWN0aXZhdGlvbiBpcyBzdG9yZWQgZGlyZWN0bHkgb24gSlNPTiBvYmplY3QgYW5kIG5vdCBpbiB0aGUgdHJhaW5pbmcgb3B0aW9uc1xuICAgICAqL1xuICAgIGdldFRyYWluT3B0c0pTT04oKSB7XG4gICAgICAgIGNvbnN0IHsgYWN0aXZhdGlvbiwgaXRlcmF0aW9ucywgZXJyb3JUaHJlc2gsIGxvZywgbG9nUGVyaW9kLCBsZWFreVJlbHVBbHBoYSwgbGVhcm5pbmdSYXRlLCBtb21lbnR1bSwgY2FsbGJhY2tQZXJpb2QsIHRpbWVvdXQsIHByYXhpcywgYmV0YTEsIGJldGEyLCBlcHNpbG9uLCB9ID0gdGhpcy50cmFpbk9wdHM7XG4gICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICBhY3RpdmF0aW9uLFxuICAgICAgICAgICAgaXRlcmF0aW9ucyxcbiAgICAgICAgICAgIGVycm9yVGhyZXNoLFxuICAgICAgICAgICAgbG9nOiB0eXBlb2YgbG9nID09PSAnZnVuY3Rpb24nXG4gICAgICAgICAgICAgICAgPyB0cnVlXG4gICAgICAgICAgICAgICAgOiB0eXBlb2YgbG9nID09PSAnYm9vbGVhbidcbiAgICAgICAgICAgICAgICAgICAgPyBsb2dcbiAgICAgICAgICAgICAgICAgICAgOiBmYWxzZSxcbiAgICAgICAgICAgIGxvZ1BlcmlvZCxcbiAgICAgICAgICAgIGxlYWt5UmVsdUFscGhhLFxuICAgICAgICAgICAgbGVhcm5pbmdSYXRlLFxuICAgICAgICAgICAgbW9tZW50dW0sXG4gICAgICAgICAgICBjYWxsYmFja1BlcmlvZCxcbiAgICAgICAgICAgIHRpbWVvdXQ6IHRpbWVvdXQgPT09IEluZmluaXR5ID8gJ0luZmluaXR5JyA6IHRpbWVvdXQsXG4gICAgICAgICAgICBwcmF4aXMsXG4gICAgICAgICAgICBiZXRhMSxcbiAgICAgICAgICAgIGJldGEyLFxuICAgICAgICAgICAgZXBzaWxvbixcbiAgICAgICAgfTtcbiAgICB9XG4gICAgc2V0TG9nTWV0aG9kKGxvZykge1xuICAgICAgICBpZiAodHlwZW9mIGxvZyA9PT0gJ2Z1bmN0aW9uJykge1xuICAgICAgICAgICAgdGhpcy50cmFpbk9wdHMubG9nID0gbG9nO1xuICAgICAgICB9XG4gICAgICAgIGVsc2UgaWYgKGxvZykge1xuICAgICAgICAgICAgdGhpcy50cmFpbk9wdHMubG9nID0gdGhpcy5sb2dUcmFpbmluZ1N0YXR1cztcbiAgICAgICAgfVxuICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgIHRoaXMudHJhaW5PcHRzLmxvZyA9IGZhbHNlO1xuICAgICAgICB9XG4gICAgfVxuICAgIGxvZ1RyYWluaW5nU3RhdHVzKHN0YXR1cykge1xuICAgICAgICBjb25zb2xlLmxvZyhgaXRlcmF0aW9uczogJHtzdGF0dXMuaXRlcmF0aW9uc30sIHRyYWluaW5nIGVycm9yOiAke3N0YXR1cy5lcnJvcn1gKTtcbiAgICB9XG4gICAgY2FsY3VsYXRlVHJhaW5pbmdFcnJvcihkYXRhKSB7XG4gICAgICAgIGxldCBzdW0gPSAwO1xuICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IGRhdGEubGVuZ3RoOyArK2kpIHtcbiAgICAgICAgICAgIHN1bSArPSB0aGlzLnRyYWluUGF0dGVybihkYXRhW2ldLCB0cnVlKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gc3VtIC8gZGF0YS5sZW5ndGg7XG4gICAgfVxuICAgIHRyYWluUGF0dGVybnMoZGF0YSkge1xuICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IGRhdGEubGVuZ3RoOyArK2kpIHtcbiAgICAgICAgICAgIHRoaXMudHJhaW5QYXR0ZXJuKGRhdGFbaV0pO1xuICAgICAgICB9XG4gICAgfVxuICAgIHRyYWluaW5nVGljayhkYXRhLCBzdGF0dXMsIGVuZFRpbWUpIHtcbiAgICAgICAgY29uc3QgeyBjYWxsYmFjaywgY2FsbGJhY2tQZXJpb2QsIGVycm9yVGhyZXNoLCBpdGVyYXRpb25zLCBsb2csIGxvZ1BlcmlvZCwgfSA9IHRoaXMudHJhaW5PcHRzO1xuICAgICAgICBpZiAoc3RhdHVzLml0ZXJhdGlvbnMgPj0gaXRlcmF0aW9ucyB8fFxuICAgICAgICAgICAgc3RhdHVzLmVycm9yIDw9IGVycm9yVGhyZXNoIHx8XG4gICAgICAgICAgICBEYXRlLm5vdygpID49IGVuZFRpbWUpIHtcbiAgICAgICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgICAgfVxuICAgICAgICBzdGF0dXMuaXRlcmF0aW9ucysrO1xuICAgICAgICBpZiAobG9nICYmIHN0YXR1cy5pdGVyYXRpb25zICUgbG9nUGVyaW9kID09PSAwKSB7XG4gICAgICAgICAgICBzdGF0dXMuZXJyb3IgPSB0aGlzLmNhbGN1bGF0ZVRyYWluaW5nRXJyb3IoZGF0YSk7XG4gICAgICAgICAgICBsb2coc3RhdHVzKTtcbiAgICAgICAgfVxuICAgICAgICBlbHNlIGlmIChzdGF0dXMuaXRlcmF0aW9ucyAlIHRoaXMuZXJyb3JDaGVja0ludGVydmFsID09PSAwKSB7XG4gICAgICAgICAgICBzdGF0dXMuZXJyb3IgPSB0aGlzLmNhbGN1bGF0ZVRyYWluaW5nRXJyb3IoZGF0YSk7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICB0aGlzLnRyYWluUGF0dGVybnMoZGF0YSk7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKGNhbGxiYWNrICYmIHN0YXR1cy5pdGVyYXRpb25zICUgY2FsbGJhY2tQZXJpb2QgPT09IDApIHtcbiAgICAgICAgICAgIGNhbGxiYWNrKHtcbiAgICAgICAgICAgICAgICBpdGVyYXRpb25zOiBzdGF0dXMuaXRlcmF0aW9ucyxcbiAgICAgICAgICAgICAgICBlcnJvcjogc3RhdHVzLmVycm9yLFxuICAgICAgICAgICAgfSk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgfVxuICAgIHByZXBUcmFpbmluZyhkYXRhLCBvcHRpb25zID0ge30pIHtcbiAgICAgICAgdGhpcy51cGRhdGVUcmFpbmluZ09wdGlvbnMob3B0aW9ucyk7XG4gICAgICAgIGNvbnN0IHByZXBhcmVkRGF0YSA9IHRoaXMuZm9ybWF0RGF0YShkYXRhKTtcbiAgICAgICAgY29uc3QgZW5kVGltZSA9IERhdGUubm93KCkgKyB0aGlzLnRyYWluT3B0cy50aW1lb3V0O1xuICAgICAgICBjb25zdCBzdGF0dXMgPSB7XG4gICAgICAgICAgICBlcnJvcjogMSxcbiAgICAgICAgICAgIGl0ZXJhdGlvbnM6IDAsXG4gICAgICAgIH07XG4gICAgICAgIHRoaXMudmVyaWZ5SXNJbml0aWFsaXplZChwcmVwYXJlZERhdGEpO1xuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgcHJlcGFyZWREYXRhLFxuICAgICAgICAgICAgc3RhdHVzLFxuICAgICAgICAgICAgZW5kVGltZSxcbiAgICAgICAgfTtcbiAgICB9XG4gICAgdHJhaW4oZGF0YSwgb3B0aW9ucyA9IHt9KSB7XG4gICAgICAgIGNvbnN0IHsgcHJlcGFyZWREYXRhLCBzdGF0dXMsIGVuZFRpbWUgfSA9IHRoaXMucHJlcFRyYWluaW5nKGRhdGEsIG9wdGlvbnMpO1xuICAgICAgICB3aGlsZSAodHJ1ZSkge1xuICAgICAgICAgICAgaWYgKCF0aGlzLnRyYWluaW5nVGljayhwcmVwYXJlZERhdGEsIHN0YXR1cywgZW5kVGltZSkpIHtcbiAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gc3RhdHVzO1xuICAgIH1cbiAgICBhc3luYyB0cmFpbkFzeW5jKGRhdGEsIG9wdGlvbnMgPSB7fSkge1xuICAgICAgICBjb25zdCB7IHByZXBhcmVkRGF0YSwgc3RhdHVzLCBlbmRUaW1lIH0gPSB0aGlzLnByZXBUcmFpbmluZyhkYXRhLCBvcHRpb25zKTtcbiAgICAgICAgcmV0dXJuIGF3YWl0IG5ldyBQcm9taXNlKChyZXNvbHZlLCByZWplY3QpID0+IHtcbiAgICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgICAgY29uc3QgdGhhd2VkVHJhaW4gPSBuZXcgZGlzdC5UaGF3KG5ldyBBcnJheSh0aGlzLnRyYWluT3B0cy5pdGVyYXRpb25zKSwge1xuICAgICAgICAgICAgICAgICAgICBkZWxheTogdHJ1ZSxcbiAgICAgICAgICAgICAgICAgICAgZWFjaDogKCkgPT4gdGhpcy50cmFpbmluZ1RpY2socHJlcGFyZWREYXRhLCBzdGF0dXMsIGVuZFRpbWUpIHx8XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGF3ZWRUcmFpbi5zdG9wKCksXG4gICAgICAgICAgICAgICAgICAgIGRvbmU6ICgpID0+IHJlc29sdmUoc3RhdHVzKSxcbiAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICB0aGF3ZWRUcmFpbi50aWNrKCk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBjYXRjaCAodHJhaW5FcnJvcikge1xuICAgICAgICAgICAgICAgIHJlamVjdCh0cmFpbkVycm9yKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfSk7XG4gICAgfVxuICAgIHRyYWluUGF0dGVybih2YWx1ZSwgbG9nRXJyb3JSYXRlKSB7XG4gICAgICAgIC8vIGZvcndhcmQgcHJvcGFnYXRlXG4gICAgICAgIHRoaXMucnVuSW5wdXQodmFsdWUuaW5wdXQpO1xuICAgICAgICAvLyBiYWNrIHByb3BhZ2F0ZVxuICAgICAgICB0aGlzLmNhbGN1bGF0ZURlbHRhcyh2YWx1ZS5vdXRwdXQpO1xuICAgICAgICB0aGlzLmFkanVzdFdlaWdodHMoKTtcbiAgICAgICAgaWYgKGxvZ0Vycm9yUmF0ZSkge1xuICAgICAgICAgICAgcmV0dXJuIG1zZSQxKHRoaXMuZXJyb3JzW3RoaXMub3V0cHV0TGF5ZXJdKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gbnVsbDtcbiAgICB9XG4gICAgX2NhbGN1bGF0ZURlbHRhc1NpZ21vaWQodGFyZ2V0KSB7XG4gICAgICAgIGZvciAobGV0IGxheWVyID0gdGhpcy5vdXRwdXRMYXllcjsgbGF5ZXIgPj0gMDsgbGF5ZXItLSkge1xuICAgICAgICAgICAgY29uc3QgYWN0aXZlU2l6ZSA9IHRoaXMuc2l6ZXNbbGF5ZXJdO1xuICAgICAgICAgICAgY29uc3QgYWN0aXZlT3V0cHV0ID0gdGhpcy5vdXRwdXRzW2xheWVyXTtcbiAgICAgICAgICAgIGNvbnN0IGFjdGl2ZUVycm9yID0gdGhpcy5lcnJvcnNbbGF5ZXJdO1xuICAgICAgICAgICAgY29uc3QgYWN0aXZlRGVsdGFzID0gdGhpcy5kZWx0YXNbbGF5ZXJdO1xuICAgICAgICAgICAgY29uc3QgbmV4dExheWVyID0gdGhpcy53ZWlnaHRzW2xheWVyICsgMV07XG4gICAgICAgICAgICBmb3IgKGxldCBub2RlID0gMDsgbm9kZSA8IGFjdGl2ZVNpemU7IG5vZGUrKykge1xuICAgICAgICAgICAgICAgIGNvbnN0IG91dHB1dCA9IGFjdGl2ZU91dHB1dFtub2RlXTtcbiAgICAgICAgICAgICAgICBsZXQgZXJyb3IgPSAwO1xuICAgICAgICAgICAgICAgIGlmIChsYXllciA9PT0gdGhpcy5vdXRwdXRMYXllcikge1xuICAgICAgICAgICAgICAgICAgICBlcnJvciA9IHRhcmdldFtub2RlXSAtIG91dHB1dDtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IGRlbHRhcyA9IHRoaXMuZGVsdGFzW2xheWVyICsgMV07XG4gICAgICAgICAgICAgICAgICAgIGZvciAobGV0IGsgPSAwOyBrIDwgZGVsdGFzLmxlbmd0aDsgaysrKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBlcnJvciArPSBkZWx0YXNba10gKiBuZXh0TGF5ZXJba11bbm9kZV07XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgYWN0aXZlRXJyb3Jbbm9kZV0gPSBlcnJvcjtcbiAgICAgICAgICAgICAgICBhY3RpdmVEZWx0YXNbbm9kZV0gPSBlcnJvciAqIG91dHB1dCAqICgxIC0gb3V0cHV0KTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIH1cbiAgICBfY2FsY3VsYXRlRGVsdGFzUmVsdSh0YXJnZXQpIHtcbiAgICAgICAgZm9yIChsZXQgbGF5ZXIgPSB0aGlzLm91dHB1dExheWVyOyBsYXllciA+PSAwOyBsYXllci0tKSB7XG4gICAgICAgICAgICBjb25zdCBjdXJyZW50U2l6ZSA9IHRoaXMuc2l6ZXNbbGF5ZXJdO1xuICAgICAgICAgICAgY29uc3QgY3VycmVudE91dHB1dHMgPSB0aGlzLm91dHB1dHNbbGF5ZXJdO1xuICAgICAgICAgICAgY29uc3QgbmV4dFdlaWdodHMgPSB0aGlzLndlaWdodHNbbGF5ZXIgKyAxXTtcbiAgICAgICAgICAgIGNvbnN0IG5leHREZWx0YXMgPSB0aGlzLmRlbHRhc1tsYXllciArIDFdO1xuICAgICAgICAgICAgY29uc3QgY3VycmVudEVycm9ycyA9IHRoaXMuZXJyb3JzW2xheWVyXTtcbiAgICAgICAgICAgIGNvbnN0IGN1cnJlbnREZWx0YXMgPSB0aGlzLmRlbHRhc1tsYXllcl07XG4gICAgICAgICAgICBmb3IgKGxldCBub2RlID0gMDsgbm9kZSA8IGN1cnJlbnRTaXplOyBub2RlKyspIHtcbiAgICAgICAgICAgICAgICBjb25zdCBvdXRwdXQgPSBjdXJyZW50T3V0cHV0c1tub2RlXTtcbiAgICAgICAgICAgICAgICBsZXQgZXJyb3IgPSAwO1xuICAgICAgICAgICAgICAgIGlmIChsYXllciA9PT0gdGhpcy5vdXRwdXRMYXllcikge1xuICAgICAgICAgICAgICAgICAgICBlcnJvciA9IHRhcmdldFtub2RlXSAtIG91dHB1dDtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgIGZvciAobGV0IGsgPSAwOyBrIDwgbmV4dERlbHRhcy5sZW5ndGg7IGsrKykge1xuICAgICAgICAgICAgICAgICAgICAgICAgZXJyb3IgKz0gbmV4dERlbHRhc1trXSAqIG5leHRXZWlnaHRzW2tdW25vZGVdO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGN1cnJlbnRFcnJvcnNbbm9kZV0gPSBlcnJvcjtcbiAgICAgICAgICAgICAgICBjdXJyZW50RGVsdGFzW25vZGVdID0gb3V0cHV0ID4gMCA/IGVycm9yIDogMDtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIH1cbiAgICBfY2FsY3VsYXRlRGVsdGFzTGVha3lSZWx1KHRhcmdldCkge1xuICAgICAgICBjb25zdCBhbHBoYSA9IHRoaXMudHJhaW5PcHRzLmxlYWt5UmVsdUFscGhhO1xuICAgICAgICBmb3IgKGxldCBsYXllciA9IHRoaXMub3V0cHV0TGF5ZXI7IGxheWVyID49IDA7IGxheWVyLS0pIHtcbiAgICAgICAgICAgIGNvbnN0IGN1cnJlbnRTaXplID0gdGhpcy5zaXplc1tsYXllcl07XG4gICAgICAgICAgICBjb25zdCBjdXJyZW50T3V0cHV0cyA9IHRoaXMub3V0cHV0c1tsYXllcl07XG4gICAgICAgICAgICBjb25zdCBuZXh0RGVsdGFzID0gdGhpcy5kZWx0YXNbbGF5ZXIgKyAxXTtcbiAgICAgICAgICAgIGNvbnN0IG5leHRXZWlnaHRzID0gdGhpcy53ZWlnaHRzW2xheWVyICsgMV07XG4gICAgICAgICAgICBjb25zdCBjdXJyZW50RXJyb3JzID0gdGhpcy5lcnJvcnNbbGF5ZXJdO1xuICAgICAgICAgICAgY29uc3QgY3VycmVudERlbHRhcyA9IHRoaXMuZGVsdGFzW2xheWVyXTtcbiAgICAgICAgICAgIGZvciAobGV0IG5vZGUgPSAwOyBub2RlIDwgY3VycmVudFNpemU7IG5vZGUrKykge1xuICAgICAgICAgICAgICAgIGNvbnN0IG91dHB1dCA9IGN1cnJlbnRPdXRwdXRzW25vZGVdO1xuICAgICAgICAgICAgICAgIGxldCBlcnJvciA9IDA7XG4gICAgICAgICAgICAgICAgaWYgKGxheWVyID09PSB0aGlzLm91dHB1dExheWVyKSB7XG4gICAgICAgICAgICAgICAgICAgIGVycm9yID0gdGFyZ2V0W25vZGVdIC0gb3V0cHV0O1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgZm9yIChsZXQgayA9IDA7IGsgPCBuZXh0RGVsdGFzLmxlbmd0aDsgaysrKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBlcnJvciArPSBuZXh0RGVsdGFzW2tdICogbmV4dFdlaWdodHNba11bbm9kZV07XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgY3VycmVudEVycm9yc1tub2RlXSA9IGVycm9yO1xuICAgICAgICAgICAgICAgIGN1cnJlbnREZWx0YXNbbm9kZV0gPSBvdXRwdXQgPiAwID8gZXJyb3IgOiBhbHBoYSAqIGVycm9yO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfVxuICAgIF9jYWxjdWxhdGVEZWx0YXNUYW5oKHRhcmdldCkge1xuICAgICAgICBmb3IgKGxldCBsYXllciA9IHRoaXMub3V0cHV0TGF5ZXI7IGxheWVyID49IDA7IGxheWVyLS0pIHtcbiAgICAgICAgICAgIGNvbnN0IGN1cnJlbnRTaXplID0gdGhpcy5zaXplc1tsYXllcl07XG4gICAgICAgICAgICBjb25zdCBjdXJyZW50T3V0cHV0cyA9IHRoaXMub3V0cHV0c1tsYXllcl07XG4gICAgICAgICAgICBjb25zdCBuZXh0RGVsdGFzID0gdGhpcy5kZWx0YXNbbGF5ZXIgKyAxXTtcbiAgICAgICAgICAgIGNvbnN0IG5leHRXZWlnaHRzID0gdGhpcy53ZWlnaHRzW2xheWVyICsgMV07XG4gICAgICAgICAgICBjb25zdCBjdXJyZW50RXJyb3JzID0gdGhpcy5lcnJvcnNbbGF5ZXJdO1xuICAgICAgICAgICAgY29uc3QgY3VycmVudERlbHRhcyA9IHRoaXMuZGVsdGFzW2xheWVyXTtcbiAgICAgICAgICAgIGZvciAobGV0IG5vZGUgPSAwOyBub2RlIDwgY3VycmVudFNpemU7IG5vZGUrKykge1xuICAgICAgICAgICAgICAgIGNvbnN0IG91dHB1dCA9IGN1cnJlbnRPdXRwdXRzW25vZGVdO1xuICAgICAgICAgICAgICAgIGxldCBlcnJvciA9IDA7XG4gICAgICAgICAgICAgICAgaWYgKGxheWVyID09PSB0aGlzLm91dHB1dExheWVyKSB7XG4gICAgICAgICAgICAgICAgICAgIGVycm9yID0gdGFyZ2V0W25vZGVdIC0gb3V0cHV0O1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgZm9yIChsZXQgayA9IDA7IGsgPCBuZXh0RGVsdGFzLmxlbmd0aDsgaysrKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBlcnJvciArPSBuZXh0RGVsdGFzW2tdICogbmV4dFdlaWdodHNba11bbm9kZV07XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgY3VycmVudEVycm9yc1tub2RlXSA9IGVycm9yO1xuICAgICAgICAgICAgICAgIGN1cnJlbnREZWx0YXNbbm9kZV0gPSAoMSAtIG91dHB1dCAqIG91dHB1dCkgKiBlcnJvcjtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIH1cbiAgICAvKipcbiAgICAgKlxuICAgICAqIENoYW5nZXMgd2VpZ2h0cyBvZiBuZXR3b3Jrc1xuICAgICAqL1xuICAgIGFkanVzdFdlaWdodHMoKSB7XG4gICAgICAgIGNvbnN0IHsgbGVhcm5pbmdSYXRlLCBtb21lbnR1bSB9ID0gdGhpcy50cmFpbk9wdHM7XG4gICAgICAgIGZvciAobGV0IGxheWVyID0gMTsgbGF5ZXIgPD0gdGhpcy5vdXRwdXRMYXllcjsgbGF5ZXIrKykge1xuICAgICAgICAgICAgY29uc3QgaW5jb21pbmcgPSB0aGlzLm91dHB1dHNbbGF5ZXIgLSAxXTtcbiAgICAgICAgICAgIGNvbnN0IGFjdGl2ZVNpemUgPSB0aGlzLnNpemVzW2xheWVyXTtcbiAgICAgICAgICAgIGNvbnN0IGFjdGl2ZURlbHRhID0gdGhpcy5kZWx0YXNbbGF5ZXJdO1xuICAgICAgICAgICAgY29uc3QgYWN0aXZlQ2hhbmdlcyA9IHRoaXMuY2hhbmdlc1tsYXllcl07XG4gICAgICAgICAgICBjb25zdCBhY3RpdmVXZWlnaHRzID0gdGhpcy53ZWlnaHRzW2xheWVyXTtcbiAgICAgICAgICAgIGNvbnN0IGFjdGl2ZUJpYXNlcyA9IHRoaXMuYmlhc2VzW2xheWVyXTtcbiAgICAgICAgICAgIGZvciAobGV0IG5vZGUgPSAwOyBub2RlIDwgYWN0aXZlU2l6ZTsgbm9kZSsrKSB7XG4gICAgICAgICAgICAgICAgY29uc3QgZGVsdGEgPSBhY3RpdmVEZWx0YVtub2RlXTtcbiAgICAgICAgICAgICAgICBmb3IgKGxldCBrID0gMDsgayA8IGluY29taW5nLmxlbmd0aDsgaysrKSB7XG4gICAgICAgICAgICAgICAgICAgIGxldCBjaGFuZ2UgPSBhY3RpdmVDaGFuZ2VzW25vZGVdW2tdO1xuICAgICAgICAgICAgICAgICAgICBjaGFuZ2UgPSBsZWFybmluZ1JhdGUgKiBkZWx0YSAqIGluY29taW5nW2tdICsgbW9tZW50dW0gKiBjaGFuZ2U7XG4gICAgICAgICAgICAgICAgICAgIGFjdGl2ZUNoYW5nZXNbbm9kZV1ba10gPSBjaGFuZ2U7XG4gICAgICAgICAgICAgICAgICAgIGFjdGl2ZVdlaWdodHNbbm9kZV1ba10gKz0gY2hhbmdlO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBhY3RpdmVCaWFzZXNbbm9kZV0gKz0gbGVhcm5pbmdSYXRlICogZGVsdGE7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9XG4gICAgX3NldHVwQWRhbSgpIHtcbiAgICAgICAgdGhpcy5iaWFzQ2hhbmdlc0xvdyA9IFtdO1xuICAgICAgICB0aGlzLmJpYXNDaGFuZ2VzSGlnaCA9IFtdO1xuICAgICAgICB0aGlzLmNoYW5nZXNMb3cgPSBbXTtcbiAgICAgICAgdGhpcy5jaGFuZ2VzSGlnaCA9IFtdO1xuICAgICAgICB0aGlzLml0ZXJhdGlvbnMgPSAwO1xuICAgICAgICBmb3IgKGxldCBsYXllciA9IDA7IGxheWVyIDw9IHRoaXMub3V0cHV0TGF5ZXI7IGxheWVyKyspIHtcbiAgICAgICAgICAgIGNvbnN0IHNpemUgPSB0aGlzLnNpemVzW2xheWVyXTtcbiAgICAgICAgICAgIGlmIChsYXllciA+IDApIHtcbiAgICAgICAgICAgICAgICB0aGlzLmJpYXNDaGFuZ2VzTG93W2xheWVyXSA9IHplcm9zJDEoc2l6ZSk7XG4gICAgICAgICAgICAgICAgdGhpcy5iaWFzQ2hhbmdlc0hpZ2hbbGF5ZXJdID0gemVyb3MkMShzaXplKTtcbiAgICAgICAgICAgICAgICB0aGlzLmNoYW5nZXNMb3dbbGF5ZXJdID0gbmV3IEFycmF5KHNpemUpO1xuICAgICAgICAgICAgICAgIHRoaXMuY2hhbmdlc0hpZ2hbbGF5ZXJdID0gbmV3IEFycmF5KHNpemUpO1xuICAgICAgICAgICAgICAgIGZvciAobGV0IG5vZGUgPSAwOyBub2RlIDwgc2l6ZTsgbm9kZSsrKSB7XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IHByZXZTaXplID0gdGhpcy5zaXplc1tsYXllciAtIDFdO1xuICAgICAgICAgICAgICAgICAgICB0aGlzLmNoYW5nZXNMb3dbbGF5ZXJdW25vZGVdID0gemVyb3MkMShwcmV2U2l6ZSk7XG4gICAgICAgICAgICAgICAgICAgIHRoaXMuY2hhbmdlc0hpZ2hbbGF5ZXJdW25vZGVdID0gemVyb3MkMShwcmV2U2l6ZSk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIHRoaXMuYWRqdXN0V2VpZ2h0cyA9IHRoaXMuX2FkanVzdFdlaWdodHNBZGFtO1xuICAgIH1cbiAgICBfYWRqdXN0V2VpZ2h0c0FkYW0oKSB7XG4gICAgICAgIHRoaXMuaXRlcmF0aW9ucysrO1xuICAgICAgICBjb25zdCB7IGl0ZXJhdGlvbnMgfSA9IHRoaXM7XG4gICAgICAgIGNvbnN0IHsgYmV0YTEsIGJldGEyLCBlcHNpbG9uLCBsZWFybmluZ1JhdGUgfSA9IHRoaXMudHJhaW5PcHRzO1xuICAgICAgICBmb3IgKGxldCBsYXllciA9IDE7IGxheWVyIDw9IHRoaXMub3V0cHV0TGF5ZXI7IGxheWVyKyspIHtcbiAgICAgICAgICAgIGNvbnN0IGluY29taW5nID0gdGhpcy5vdXRwdXRzW2xheWVyIC0gMV07XG4gICAgICAgICAgICBjb25zdCBjdXJyZW50U2l6ZSA9IHRoaXMuc2l6ZXNbbGF5ZXJdO1xuICAgICAgICAgICAgY29uc3QgY3VycmVudERlbHRhcyA9IHRoaXMuZGVsdGFzW2xheWVyXTtcbiAgICAgICAgICAgIGNvbnN0IGN1cnJlbnRDaGFuZ2VzTG93ID0gdGhpcy5jaGFuZ2VzTG93W2xheWVyXTtcbiAgICAgICAgICAgIGNvbnN0IGN1cnJlbnRDaGFuZ2VzSGlnaCA9IHRoaXMuY2hhbmdlc0hpZ2hbbGF5ZXJdO1xuICAgICAgICAgICAgY29uc3QgY3VycmVudFdlaWdodHMgPSB0aGlzLndlaWdodHNbbGF5ZXJdO1xuICAgICAgICAgICAgY29uc3QgY3VycmVudEJpYXNlcyA9IHRoaXMuYmlhc2VzW2xheWVyXTtcbiAgICAgICAgICAgIGNvbnN0IGN1cnJlbnRCaWFzQ2hhbmdlc0xvdyA9IHRoaXMuYmlhc0NoYW5nZXNMb3dbbGF5ZXJdO1xuICAgICAgICAgICAgY29uc3QgY3VycmVudEJpYXNDaGFuZ2VzSGlnaCA9IHRoaXMuYmlhc0NoYW5nZXNIaWdoW2xheWVyXTtcbiAgICAgICAgICAgIGZvciAobGV0IG5vZGUgPSAwOyBub2RlIDwgY3VycmVudFNpemU7IG5vZGUrKykge1xuICAgICAgICAgICAgICAgIGNvbnN0IGRlbHRhID0gY3VycmVudERlbHRhc1tub2RlXTtcbiAgICAgICAgICAgICAgICBmb3IgKGxldCBrID0gMDsgayA8IGluY29taW5nLmxlbmd0aDsgaysrKSB7XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IGdyYWRpZW50ID0gZGVsdGEgKiBpbmNvbWluZ1trXTtcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgY2hhbmdlTG93ID0gY3VycmVudENoYW5nZXNMb3dbbm9kZV1ba10gKiBiZXRhMSArICgxIC0gYmV0YTEpICogZ3JhZGllbnQ7XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IGNoYW5nZUhpZ2ggPSBjdXJyZW50Q2hhbmdlc0hpZ2hbbm9kZV1ba10gKiBiZXRhMiArXG4gICAgICAgICAgICAgICAgICAgICAgICAoMSAtIGJldGEyKSAqIGdyYWRpZW50ICogZ3JhZGllbnQ7XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IG1vbWVudHVtQ29ycmVjdGlvbiA9IGNoYW5nZUxvdyAvICgxIC0gTWF0aC5wb3coYmV0YTEsIGl0ZXJhdGlvbnMpKTtcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgZ3JhZGllbnRDb3JyZWN0aW9uID0gY2hhbmdlSGlnaCAvICgxIC0gTWF0aC5wb3coYmV0YTIsIGl0ZXJhdGlvbnMpKTtcbiAgICAgICAgICAgICAgICAgICAgY3VycmVudENoYW5nZXNMb3dbbm9kZV1ba10gPSBjaGFuZ2VMb3c7XG4gICAgICAgICAgICAgICAgICAgIGN1cnJlbnRDaGFuZ2VzSGlnaFtub2RlXVtrXSA9IGNoYW5nZUhpZ2g7XG4gICAgICAgICAgICAgICAgICAgIGN1cnJlbnRXZWlnaHRzW25vZGVdW2tdICs9XG4gICAgICAgICAgICAgICAgICAgICAgICAobGVhcm5pbmdSYXRlICogbW9tZW50dW1Db3JyZWN0aW9uKSAvXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgKE1hdGguc3FydChncmFkaWVudENvcnJlY3Rpb24pICsgZXBzaWxvbik7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGNvbnN0IGJpYXNHcmFkaWVudCA9IGN1cnJlbnREZWx0YXNbbm9kZV07XG4gICAgICAgICAgICAgICAgY29uc3QgYmlhc0NoYW5nZUxvdyA9IGN1cnJlbnRCaWFzQ2hhbmdlc0xvd1tub2RlXSAqIGJldGExICsgKDEgLSBiZXRhMSkgKiBiaWFzR3JhZGllbnQ7XG4gICAgICAgICAgICAgICAgY29uc3QgYmlhc0NoYW5nZUhpZ2ggPSBjdXJyZW50Qmlhc0NoYW5nZXNIaWdoW25vZGVdICogYmV0YTIgK1xuICAgICAgICAgICAgICAgICAgICAoMSAtIGJldGEyKSAqIGJpYXNHcmFkaWVudCAqIGJpYXNHcmFkaWVudDtcbiAgICAgICAgICAgICAgICBjb25zdCBiaWFzTW9tZW50dW1Db3JyZWN0aW9uID0gY3VycmVudEJpYXNDaGFuZ2VzTG93W25vZGVdIC8gKDEgLSBNYXRoLnBvdyhiZXRhMSwgaXRlcmF0aW9ucykpO1xuICAgICAgICAgICAgICAgIGNvbnN0IGJpYXNHcmFkaWVudENvcnJlY3Rpb24gPSBjdXJyZW50Qmlhc0NoYW5nZXNIaWdoW25vZGVdIC8gKDEgLSBNYXRoLnBvdyhiZXRhMiwgaXRlcmF0aW9ucykpO1xuICAgICAgICAgICAgICAgIGN1cnJlbnRCaWFzQ2hhbmdlc0xvd1tub2RlXSA9IGJpYXNDaGFuZ2VMb3c7XG4gICAgICAgICAgICAgICAgY3VycmVudEJpYXNDaGFuZ2VzSGlnaFtub2RlXSA9IGJpYXNDaGFuZ2VIaWdoO1xuICAgICAgICAgICAgICAgIGN1cnJlbnRCaWFzZXNbbm9kZV0gKz1cbiAgICAgICAgICAgICAgICAgICAgKGxlYXJuaW5nUmF0ZSAqIGJpYXNNb21lbnR1bUNvcnJlY3Rpb24pIC9cbiAgICAgICAgICAgICAgICAgICAgICAgIChNYXRoLnNxcnQoYmlhc0dyYWRpZW50Q29ycmVjdGlvbikgKyBlcHNpbG9uKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIH1cbiAgICBmb3JtYXREYXRhKGRhdGEpIHtcbiAgICAgICAgaWYgKCFBcnJheS5pc0FycmF5KGRhdGFbMF0uaW5wdXQpKSB7XG4gICAgICAgICAgICBpZiAodGhpcy5pbnB1dExvb2t1cCkge1xuICAgICAgICAgICAgICAgIHRoaXMuaW5wdXRMb29rdXBMZW5ndGggPSBPYmplY3Qua2V5cyh0aGlzLmlucHV0TG9va3VwKS5sZW5ndGg7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgICAgICBjb25zdCBpbnB1dExvb2t1cCA9IG5ldyBMb29rdXBUYWJsZShkYXRhLCAnaW5wdXQnKTtcbiAgICAgICAgICAgICAgICB0aGlzLmlucHV0TG9va3VwID0gaW5wdXRMb29rdXAudGFibGU7XG4gICAgICAgICAgICAgICAgdGhpcy5pbnB1dExvb2t1cExlbmd0aCA9IGlucHV0TG9va3VwLmxlbmd0aDtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBpZiAoIUFycmF5LmlzQXJyYXkoZGF0YVswXS5vdXRwdXQpKSB7XG4gICAgICAgICAgICBpZiAodGhpcy5vdXRwdXRMb29rdXApIHtcbiAgICAgICAgICAgICAgICB0aGlzLm91dHB1dExvb2t1cExlbmd0aCA9IE9iamVjdC5rZXlzKHRoaXMub3V0cHV0TG9va3VwKS5sZW5ndGg7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgICAgICBjb25zdCBsb29rdXAgPSBuZXcgTG9va3VwVGFibGUoZGF0YSwgJ291dHB1dCcpO1xuICAgICAgICAgICAgICAgIHRoaXMub3V0cHV0TG9va3VwID0gbG9va3VwLnRhYmxlO1xuICAgICAgICAgICAgICAgIHRoaXMub3V0cHV0TG9va3VwTGVuZ3RoID0gbG9va3VwLmxlbmd0aDtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBpZiAoIXRoaXMuX2Zvcm1hdElucHV0KSB7XG4gICAgICAgICAgICB0aGlzLl9mb3JtYXRJbnB1dCA9IGdldFR5cGVkQXJyYXlGbihkYXRhWzBdLmlucHV0LCB0aGlzLmlucHV0TG9va3VwKTtcbiAgICAgICAgfVxuICAgICAgICBpZiAoIXRoaXMuX2Zvcm1hdE91dHB1dCkge1xuICAgICAgICAgICAgdGhpcy5fZm9ybWF0T3V0cHV0ID0gZ2V0VHlwZWRBcnJheUZuKGRhdGFbMF0ub3V0cHV0LCB0aGlzLm91dHB1dExvb2t1cCk7XG4gICAgICAgIH1cbiAgICAgICAgLy8gdHVybiBzcGFyc2UgaGFzaCBpbnB1dCBpbnRvIGFycmF5cyB3aXRoIDBzIGFzIGZpbGxlclxuICAgICAgICBpZiAodGhpcy5fZm9ybWF0SW5wdXQgJiYgdGhpcy5fZm9ybWF0T3V0cHV0KSB7XG4gICAgICAgICAgICBjb25zdCByZXN1bHQgPSBbXTtcbiAgICAgICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgZGF0YS5sZW5ndGg7IGkrKykge1xuICAgICAgICAgICAgICAgIHJlc3VsdC5wdXNoKHtcbiAgICAgICAgICAgICAgICAgICAgaW5wdXQ6IHRoaXMuX2Zvcm1hdElucHV0KGRhdGFbaV0uaW5wdXQpLFxuICAgICAgICAgICAgICAgICAgICBvdXRwdXQ6IHRoaXMuX2Zvcm1hdE91dHB1dChkYXRhW2ldLm91dHB1dCksXG4gICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICByZXR1cm4gcmVzdWx0O1xuICAgICAgICB9XG4gICAgICAgIGlmICh0aGlzLl9mb3JtYXRJbnB1dCkge1xuICAgICAgICAgICAgY29uc3QgcmVzdWx0ID0gW107XG4gICAgICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IGRhdGEubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgICAgICAgICByZXN1bHQucHVzaCh7XG4gICAgICAgICAgICAgICAgICAgIGlucHV0OiB0aGlzLl9mb3JtYXRJbnB1dChkYXRhW2ldLmlucHV0KSxcbiAgICAgICAgICAgICAgICAgICAgb3V0cHV0OiBkYXRhW2ldLm91dHB1dCxcbiAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHJldHVybiByZXN1bHQ7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKHRoaXMuX2Zvcm1hdE91dHB1dCkge1xuICAgICAgICAgICAgY29uc3QgcmVzdWx0ID0gW107XG4gICAgICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IGRhdGEubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgICAgICAgICByZXN1bHQucHVzaCh7XG4gICAgICAgICAgICAgICAgICAgIGlucHV0OiBkYXRhW2ldLmlucHV0LFxuICAgICAgICAgICAgICAgICAgICBvdXRwdXQ6IHRoaXMuX2Zvcm1hdE91dHB1dChkYXRhW2ldLm91dHB1dCksXG4gICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICByZXR1cm4gcmVzdWx0O1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBkYXRhO1xuICAgIH1cbiAgICBhZGRGb3JtYXQoZGF0YSkge1xuICAgICAgICB2YXIgX2EsIF9iO1xuICAgICAgICBpZiAoIUFycmF5LmlzQXJyYXkoZGF0YS5pbnB1dCkgfHwgdHlwZW9mIGRhdGEuaW5wdXRbMF0gIT09ICdudW1iZXInKSB7XG4gICAgICAgICAgICB0aGlzLmlucHV0TG9va3VwID0gbG9va3VwLmFkZEtleXMoZGF0YS5pbnB1dCwgKF9hID0gdGhpcy5pbnB1dExvb2t1cCkgIT09IG51bGwgJiYgX2EgIT09IHZvaWQgMCA/IF9hIDoge30pO1xuICAgICAgICAgICAgaWYgKHRoaXMuaW5wdXRMb29rdXApIHtcbiAgICAgICAgICAgICAgICB0aGlzLmlucHV0TG9va3VwTGVuZ3RoID0gT2JqZWN0LmtleXModGhpcy5pbnB1dExvb2t1cCkubGVuZ3RoO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIGlmICghQXJyYXkuaXNBcnJheShkYXRhLm91dHB1dCkgfHwgdHlwZW9mIGRhdGEub3V0cHV0WzBdICE9PSAnbnVtYmVyJykge1xuICAgICAgICAgICAgdGhpcy5vdXRwdXRMb29rdXAgPSBsb29rdXAuYWRkS2V5cyhkYXRhLm91dHB1dCwgKF9iID0gdGhpcy5vdXRwdXRMb29rdXApICE9PSBudWxsICYmIF9iICE9PSB2b2lkIDAgPyBfYiA6IHt9KTtcbiAgICAgICAgICAgIGlmICh0aGlzLm91dHB1dExvb2t1cCkge1xuICAgICAgICAgICAgICAgIHRoaXMub3V0cHV0TG9va3VwTGVuZ3RoID0gT2JqZWN0LmtleXModGhpcy5vdXRwdXRMb29rdXApLmxlbmd0aDtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIH1cbiAgICB0ZXN0KGRhdGEpIHtcbiAgICAgICAgY29uc3QgeyBwcmVwYXJlZERhdGEgfSA9IHRoaXMucHJlcFRyYWluaW5nKGRhdGEpO1xuICAgICAgICAvLyBmb3IgYmluYXJ5IGNsYXNzaWZpY2F0aW9uIHByb2JsZW1zIHdpdGggb25lIG91dHB1dCBub2RlXG4gICAgICAgIGNvbnN0IGlzQmluYXJ5ID0gcHJlcGFyZWREYXRhWzBdLm91dHB1dC5sZW5ndGggPT09IDE7XG4gICAgICAgIC8vIGZvciBjbGFzc2lmaWNhdGlvbiBwcm9ibGVtc1xuICAgICAgICBjb25zdCBtaXNjbGFzc2VzID0gW107XG4gICAgICAgIC8vIHJ1biBlYWNoIHBhdHRlcm4gdGhyb3VnaCB0aGUgdHJhaW5lZCBuZXR3b3JrIGFuZCBjb2xsZWN0XG4gICAgICAgIC8vIGVycm9yIGFuZCBtaXNjbGFzc2lmaWNhdGlvbiBzdGF0aXN0aWNzXG4gICAgICAgIGxldCBlcnJvclN1bSA9IDA7XG4gICAgICAgIGlmIChpc0JpbmFyeSkge1xuICAgICAgICAgICAgbGV0IGZhbHNlUG9zID0gMDtcbiAgICAgICAgICAgIGxldCBmYWxzZU5lZyA9IDA7XG4gICAgICAgICAgICBsZXQgdHJ1ZVBvcyA9IDA7XG4gICAgICAgICAgICBsZXQgdHJ1ZU5lZyA9IDA7XG4gICAgICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IHByZXBhcmVkRGF0YS5sZW5ndGg7IGkrKykge1xuICAgICAgICAgICAgICAgIGNvbnN0IG91dHB1dCA9IHRoaXMucnVuSW5wdXQocHJlcGFyZWREYXRhW2ldLmlucHV0KTtcbiAgICAgICAgICAgICAgICBjb25zdCB0YXJnZXQgPSBwcmVwYXJlZERhdGFbaV0ub3V0cHV0O1xuICAgICAgICAgICAgICAgIGNvbnN0IGFjdHVhbCA9IG91dHB1dFswXSA+IHRoaXMub3B0aW9ucy5iaW5hcnlUaHJlc2ggPyAxIDogMDtcbiAgICAgICAgICAgICAgICBjb25zdCBleHBlY3RlZCA9IHRhcmdldFswXTtcbiAgICAgICAgICAgICAgICBpZiAoYWN0dWFsICE9PSBleHBlY3RlZCkge1xuICAgICAgICAgICAgICAgICAgICBjb25zdCBtaXNjbGFzcyA9IHByZXBhcmVkRGF0YVtpXTtcbiAgICAgICAgICAgICAgICAgICAgbWlzY2xhc3Nlcy5wdXNoKHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGlucHV0OiBtaXNjbGFzcy5pbnB1dCxcbiAgICAgICAgICAgICAgICAgICAgICAgIG91dHB1dDogbWlzY2xhc3Mub3V0cHV0LFxuICAgICAgICAgICAgICAgICAgICAgICAgYWN0dWFsLFxuICAgICAgICAgICAgICAgICAgICAgICAgZXhwZWN0ZWQsXG4gICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBpZiAoYWN0dWFsID09PSAwICYmIGV4cGVjdGVkID09PSAwKSB7XG4gICAgICAgICAgICAgICAgICAgIHRydWVOZWcrKztcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgZWxzZSBpZiAoYWN0dWFsID09PSAxICYmIGV4cGVjdGVkID09PSAxKSB7XG4gICAgICAgICAgICAgICAgICAgIHRydWVQb3MrKztcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgZWxzZSBpZiAoYWN0dWFsID09PSAwICYmIGV4cGVjdGVkID09PSAxKSB7XG4gICAgICAgICAgICAgICAgICAgIGZhbHNlTmVnKys7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGVsc2UgaWYgKGFjdHVhbCA9PT0gMSAmJiBleHBlY3RlZCA9PT0gMCkge1xuICAgICAgICAgICAgICAgICAgICBmYWxzZVBvcysrO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBlcnJvclN1bSArPSBtc2UkMShvdXRwdXQubWFwKCh2YWx1ZSwgaSkgPT4ge1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gdGFyZ2V0W2ldIC0gdmFsdWU7XG4gICAgICAgICAgICAgICAgfSkpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgICAgICBlcnJvcjogZXJyb3JTdW0gLyBwcmVwYXJlZERhdGEubGVuZ3RoLFxuICAgICAgICAgICAgICAgIG1pc2NsYXNzZXMsXG4gICAgICAgICAgICAgICAgdG90YWw6IHByZXBhcmVkRGF0YS5sZW5ndGgsXG4gICAgICAgICAgICAgICAgdHJ1ZU5lZyxcbiAgICAgICAgICAgICAgICB0cnVlUG9zLFxuICAgICAgICAgICAgICAgIGZhbHNlTmVnLFxuICAgICAgICAgICAgICAgIGZhbHNlUG9zLFxuICAgICAgICAgICAgICAgIHByZWNpc2lvbjogdHJ1ZVBvcyA+IDAgPyB0cnVlUG9zIC8gKHRydWVQb3MgKyBmYWxzZVBvcykgOiAwLFxuICAgICAgICAgICAgICAgIHJlY2FsbDogdHJ1ZVBvcyA+IDAgPyB0cnVlUG9zIC8gKHRydWVQb3MgKyBmYWxzZU5lZykgOiAwLFxuICAgICAgICAgICAgICAgIGFjY3VyYWN5OiAodHJ1ZU5lZyArIHRydWVQb3MpIC8gcHJlcGFyZWREYXRhLmxlbmd0aCxcbiAgICAgICAgICAgIH07XG4gICAgICAgIH1cbiAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBwcmVwYXJlZERhdGEubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgICAgIGNvbnN0IG91dHB1dCA9IHRoaXMucnVuSW5wdXQocHJlcGFyZWREYXRhW2ldLmlucHV0KTtcbiAgICAgICAgICAgIGNvbnN0IHRhcmdldCA9IHByZXBhcmVkRGF0YVtpXS5vdXRwdXQ7XG4gICAgICAgICAgICBjb25zdCBhY3R1YWwgPSBvdXRwdXQuaW5kZXhPZihtYXgob3V0cHV0KSk7XG4gICAgICAgICAgICBjb25zdCBleHBlY3RlZCA9IHRhcmdldC5pbmRleE9mKG1heCh0YXJnZXQpKTtcbiAgICAgICAgICAgIGlmIChhY3R1YWwgIT09IGV4cGVjdGVkKSB7XG4gICAgICAgICAgICAgICAgY29uc3QgbWlzY2xhc3MgPSBwcmVwYXJlZERhdGFbaV07XG4gICAgICAgICAgICAgICAgbWlzY2xhc3Nlcy5wdXNoKHtcbiAgICAgICAgICAgICAgICAgICAgaW5wdXQ6IG1pc2NsYXNzLmlucHV0LFxuICAgICAgICAgICAgICAgICAgICBvdXRwdXQ6IG1pc2NsYXNzLm91dHB1dCxcbiAgICAgICAgICAgICAgICAgICAgYWN0dWFsLFxuICAgICAgICAgICAgICAgICAgICBleHBlY3RlZCxcbiAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGVycm9yU3VtICs9IG1zZSQxKG91dHB1dC5tYXAoKHZhbHVlLCBpKSA9PiB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIHRhcmdldFtpXSAtIHZhbHVlO1xuICAgICAgICAgICAgfSkpO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICBlcnJvcjogZXJyb3JTdW0gLyBwcmVwYXJlZERhdGEubGVuZ3RoLFxuICAgICAgICAgICAgbWlzY2xhc3NlcyxcbiAgICAgICAgICAgIHRvdGFsOiBwcmVwYXJlZERhdGEubGVuZ3RoLFxuICAgICAgICB9O1xuICAgIH1cbiAgICB0b0pTT04oKSB7XG4gICAgICAgIHZhciBfYSwgX2I7XG4gICAgICAgIGlmICghdGhpcy5pc1J1bm5hYmxlKSB7XG4gICAgICAgICAgICB0aGlzLmluaXRpYWxpemUoKTtcbiAgICAgICAgfVxuICAgICAgICAvLyB1c2UgQXJyYXkuZnJvbSwga2VlcGluZyBqc29uIHNtYWxsXG4gICAgICAgIGNvbnN0IGpzb25MYXllcldlaWdodHMgPSB0aGlzLndlaWdodHMubWFwKChsYXllcldlaWdodHMpID0+IHtcbiAgICAgICAgICAgIHJldHVybiBsYXllcldlaWdodHMubWFwKChsYXllcldlaWdodHMpID0+IEFycmF5LmZyb20obGF5ZXJXZWlnaHRzKSk7XG4gICAgICAgIH0pO1xuICAgICAgICBjb25zdCBqc29uTGF5ZXJCaWFzZXMgPSB0aGlzLmJpYXNlcy5tYXAoKGxheWVyQmlhc2VzKSA9PiBBcnJheS5mcm9tKGxheWVyQmlhc2VzKSk7XG4gICAgICAgIGNvbnN0IGpzb25MYXllcnMgPSBbXTtcbiAgICAgICAgY29uc3Qgb3V0cHV0TGVuZ3RoID0gdGhpcy5zaXplcy5sZW5ndGggLSAxO1xuICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8PSBvdXRwdXRMZW5ndGg7IGkrKykge1xuICAgICAgICAgICAganNvbkxheWVycy5wdXNoKHtcbiAgICAgICAgICAgICAgICB3ZWlnaHRzOiAoX2EgPSBqc29uTGF5ZXJXZWlnaHRzW2ldKSAhPT0gbnVsbCAmJiBfYSAhPT0gdm9pZCAwID8gX2EgOiBbXSxcbiAgICAgICAgICAgICAgICBiaWFzZXM6IChfYiA9IGpzb25MYXllckJpYXNlc1tpXSkgIT09IG51bGwgJiYgX2IgIT09IHZvaWQgMCA/IF9iIDogW10sXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgdHlwZTogJ05ldXJhbE5ldHdvcmsnLFxuICAgICAgICAgICAgc2l6ZXM6IFsuLi50aGlzLnNpemVzXSxcbiAgICAgICAgICAgIGxheWVyczoganNvbkxheWVycyxcbiAgICAgICAgICAgIGlucHV0TG9va3VwOiB0aGlzLmlucHV0TG9va3VwID8geyAuLi50aGlzLmlucHV0TG9va3VwIH0gOiBudWxsLFxuICAgICAgICAgICAgaW5wdXRMb29rdXBMZW5ndGg6IHRoaXMuaW5wdXRMb29rdXBMZW5ndGgsXG4gICAgICAgICAgICBvdXRwdXRMb29rdXA6IHRoaXMub3V0cHV0TG9va3VwID8geyAuLi50aGlzLm91dHB1dExvb2t1cCB9IDogbnVsbCxcbiAgICAgICAgICAgIG91dHB1dExvb2t1cExlbmd0aDogdGhpcy5vdXRwdXRMb29rdXBMZW5ndGgsXG4gICAgICAgICAgICBvcHRpb25zOiB7IC4uLnRoaXMub3B0aW9ucyB9LFxuICAgICAgICAgICAgdHJhaW5PcHRzOiB0aGlzLmdldFRyYWluT3B0c0pTT04oKSxcbiAgICAgICAgfTtcbiAgICB9XG4gICAgZnJvbUpTT04oanNvbikge1xuICAgICAgICB0aGlzLm9wdGlvbnMgPSB7IC4uLmRlZmF1bHRzJDIoKSwgLi4uanNvbi5vcHRpb25zIH07XG4gICAgICAgIGlmIChqc29uLmhhc093blByb3BlcnR5KCd0cmFpbk9wdHMnKSkge1xuICAgICAgICAgICAgY29uc3QgdHJhaW5PcHRzID0ge1xuICAgICAgICAgICAgICAgIC4uLmpzb24udHJhaW5PcHRzLFxuICAgICAgICAgICAgICAgIHRpbWVvdXQ6IGpzb24udHJhaW5PcHRzLnRpbWVvdXQgPT09ICdJbmZpbml0eSdcbiAgICAgICAgICAgICAgICAgICAgPyBJbmZpbml0eVxuICAgICAgICAgICAgICAgICAgICA6IGpzb24udHJhaW5PcHRzLnRpbWVvdXQsXG4gICAgICAgICAgICB9O1xuICAgICAgICAgICAgdGhpcy51cGRhdGVUcmFpbmluZ09wdGlvbnModHJhaW5PcHRzKTtcbiAgICAgICAgfVxuICAgICAgICB0aGlzLnNpemVzID0ganNvbi5zaXplcztcbiAgICAgICAgdGhpcy5pbml0aWFsaXplKCk7XG4gICAgICAgIHRoaXMuaW5wdXRMb29rdXAgPSBqc29uLmlucHV0TG9va3VwID8geyAuLi5qc29uLmlucHV0TG9va3VwIH0gOiBudWxsO1xuICAgICAgICB0aGlzLmlucHV0TG9va3VwTGVuZ3RoID0ganNvbi5pbnB1dExvb2t1cExlbmd0aDtcbiAgICAgICAgdGhpcy5vdXRwdXRMb29rdXAgPSBqc29uLm91dHB1dExvb2t1cCA/IHsgLi4uanNvbi5vdXRwdXRMb29rdXAgfSA6IG51bGw7XG4gICAgICAgIHRoaXMub3V0cHV0TG9va3VwTGVuZ3RoID0ganNvbi5vdXRwdXRMb29rdXBMZW5ndGg7XG4gICAgICAgIGNvbnN0IGpzb25MYXllcnMgPSBqc29uLmxheWVycztcbiAgICAgICAgY29uc3QgbGF5ZXJXZWlnaHRzID0gdGhpcy53ZWlnaHRzLm1hcCgobGF5ZXJXZWlnaHRzLCBsYXllckluZGV4KSA9PiB7XG4gICAgICAgICAgICByZXR1cm4ganNvbkxheWVyc1tsYXllckluZGV4XS53ZWlnaHRzLm1hcCgobGF5ZXJXZWlnaHRzKSA9PiBGbG9hdDMyQXJyYXkuZnJvbShsYXllcldlaWdodHMpKTtcbiAgICAgICAgfSk7XG4gICAgICAgIGNvbnN0IGxheWVyQmlhc2VzID0gdGhpcy5iaWFzZXMubWFwKChsYXllckJpYXNlcywgbGF5ZXJJbmRleCkgPT4gRmxvYXQzMkFycmF5LmZyb20oanNvbkxheWVyc1tsYXllckluZGV4XS5iaWFzZXMpKTtcbiAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPD0gdGhpcy5vdXRwdXRMYXllcjsgaSsrKSB7XG4gICAgICAgICAgICB0aGlzLndlaWdodHNbaV0gPSBsYXllcldlaWdodHNbaV0gfHwgW107XG4gICAgICAgICAgICB0aGlzLmJpYXNlc1tpXSA9IGxheWVyQmlhc2VzW2ldIHx8IFtdO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiB0aGlzO1xuICAgIH1cbiAgICB0b0Z1bmN0aW9uKGNiKSB7XG4gICAgICAgIGNvbnN0IHsgYWN0aXZhdGlvbiwgbGVha3lSZWx1QWxwaGEgfSA9IHRoaXMudHJhaW5PcHRzO1xuICAgICAgICBsZXQgbmVlZHNWYXIgPSBmYWxzZTtcbiAgICAgICAgY29uc3Qgbm9kZUhhbmRsZSA9IChsYXllckluZGV4LCBub2RlSW5kZXgpID0+IHtcbiAgICAgICAgICAgIGlmIChsYXllckluZGV4ID09PSAwKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIGAoaW5wdXRbJHtub2RlSW5kZXh9XXx8MClgO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgY29uc3Qgd2VpZ2h0cyA9IHRoaXMud2VpZ2h0c1tsYXllckluZGV4XVtub2RlSW5kZXhdO1xuICAgICAgICAgICAgY29uc3QgYmlhcyA9IHRoaXMuYmlhc2VzW2xheWVySW5kZXhdW25vZGVJbmRleF07XG4gICAgICAgICAgICBpZiAoIXdlaWdodHMpIHtcbiAgICAgICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoYHdlaWdodHMgYXQgbGF5ZXJJbmRleCAke2xheWVySW5kZXh9ICYgbm9kZUluZGV4ICR7bm9kZUluZGV4fSBub3QgZm91bmRgKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGlmICghYmlhcykge1xuICAgICAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcihgYmlhcyBhcyBsYXllckluZGV4ICR7bGF5ZXJJbmRleH0gJiBub2RlSW5kZXggJHtub2RlSW5kZXh9IG5vdCBmb3VuZGApO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgY29uc3Qgd2VpZ2h0c0FycmF5ID0gW107XG4gICAgICAgICAgICB3ZWlnaHRzLmZvckVhY2goKHdlaWdodCwgc3ViTm9kZUluZGV4KSA9PiB7XG4gICAgICAgICAgICAgICAgaWYgKHdlaWdodCA8IDApIHtcbiAgICAgICAgICAgICAgICAgICAgd2VpZ2h0c0FycmF5LnB1c2goYCR7d2VpZ2h0fSoke25vZGVIYW5kbGUobGF5ZXJJbmRleCAtIDEsIHN1Yk5vZGVJbmRleCl9YCk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICB3ZWlnaHRzQXJyYXkucHVzaChgKyR7d2VpZ2h0fSoke25vZGVIYW5kbGUobGF5ZXJJbmRleCAtIDEsIHN1Yk5vZGVJbmRleCl9YCk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICBjb25zdCByZXN1bHQgPSBgKCR7Ymlhcy50b1N0cmluZygpfSR7d2VpZ2h0c0FycmF5LmpvaW4oJycpfSlgO1xuICAgICAgICAgICAgc3dpdGNoIChhY3RpdmF0aW9uKSB7XG4gICAgICAgICAgICAgICAgY2FzZSAnc2lnbW9pZCc6XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBgMS8oMSsxL01hdGguZXhwKCR7cmVzdWx0fSkpYDtcbiAgICAgICAgICAgICAgICBjYXNlICdyZWx1Jzoge1xuICAgICAgICAgICAgICAgICAgICBuZWVkc1ZhciA9IHRydWU7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBgKCh2PSR7cmVzdWx0fSk8MD8wOnYpYDtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgY2FzZSAnbGVha3ktcmVsdSc6IHtcbiAgICAgICAgICAgICAgICAgICAgbmVlZHNWYXIgPSB0cnVlO1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gYE1hdGgubWF4KCh2PSR7cmVzdWx0fSksJHtsZWFreVJlbHVBbHBoYX0qdilgO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBjYXNlICd0YW5oJzpcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGBNYXRoLnRhbmgoJHtyZXN1bHR9KWA7XG4gICAgICAgICAgICAgICAgZGVmYXVsdDpcbiAgICAgICAgICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKGBVbmtub3duIGFjdGl2YXRpb24gJHthY3RpdmF0aW9ufS4gQXZhaWxhYmxlIGFjdGl2YXRpb25zIGFyZTogJ3NpZ21vaWQnLCAncmVsdScsICdsZWFreS1yZWx1JywgJ3RhbmgnYCk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH07XG4gICAgICAgIGZ1bmN0aW9uIGNoZWNrS2V5cyhrZXlzKSB7XG4gICAgICAgICAgICBpZiAoa2V5cy5maW5kKCh2KSA9PiB2LmluY2x1ZGVzKCdcIicpKSkge1xuICAgICAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcihga2V5IGNvbnRhaW5zICdcIicsIHdoaWNoIGlzIG5vdCBjb21wYXRpYmxlYCk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgY29uc3QgbGF5ZXJzQXNNYXRoID0gW107XG4gICAgICAgIGxldCByZXN1bHQ7XG4gICAgICAgIGxldCBpbnB1dExvb2t1cCA9ICcnO1xuICAgICAgICBpZiAodGhpcy5pbnB1dExvb2t1cCkge1xuICAgICAgICAgICAgY29uc3Qga2V5cyA9IE9iamVjdC5rZXlzKHRoaXMuaW5wdXRMb29rdXApO1xuICAgICAgICAgICAgY2hlY2tLZXlzKGtleXMpO1xuICAgICAgICAgICAgaW5wdXRMb29rdXAgPSBgaW5wdXQgPSBuZXcgRmxvYXQzMkFycmF5KFske09iamVjdC5rZXlzKHRoaXMuaW5wdXRMb29rdXApXG4gICAgICAgICAgICAgICAgLm1hcCgoa2V5KSA9PiBgaW5wdXRbXCIke2tleX1cIl1gKVxuICAgICAgICAgICAgICAgIC5qb2luKCcsJyl9XSk7YDtcbiAgICAgICAgfVxuICAgICAgICBpZiAodGhpcy5zaXplcy5sZW5ndGggPCAxKVxuICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdObyBsYXllcnMnKTtcbiAgICAgICAgZm9yIChsZXQgbm9kZUluZGV4ID0gMDsgbm9kZUluZGV4IDwgdGhpcy5zaXplc1t0aGlzLm91dHB1dExheWVyXTsgbm9kZUluZGV4KyspIHtcbiAgICAgICAgICAgIGxheWVyc0FzTWF0aC5wdXNoKG5vZGVIYW5kbGUodGhpcy5vdXRwdXRMYXllciwgbm9kZUluZGV4KSk7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKHRoaXMub3V0cHV0TG9va3VwKSB7XG4gICAgICAgICAgICBjb25zdCBrZXlzID0gT2JqZWN0LmtleXModGhpcy5vdXRwdXRMb29rdXApO1xuICAgICAgICAgICAgY2hlY2tLZXlzKGtleXMpO1xuICAgICAgICAgICAgY29uc3QgdmFsdWVzID0ga2V5c1xuICAgICAgICAgICAgICAgIC5tYXAoKGtleSwgaSkgPT4gYFwiJHtrZXl9XCI6JHtsYXllcnNBc01hdGhbaV19YClcbiAgICAgICAgICAgICAgICAuam9pbignLCcpO1xuICAgICAgICAgICAgcmVzdWx0ID0gYHske3ZhbHVlc319YDtcbiAgICAgICAgfVxuICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgIHJlc3VsdCA9IGBbJHtsYXllcnNBc01hdGguam9pbignLCcpfV1gO1xuICAgICAgICB9XG4gICAgICAgIGNvbnN0IHNvdXJjZSA9IGAke2lucHV0TG9va3VwfSR7bmVlZHNWYXIgPyAndmFyIHY7JyA6ICcnfXJldHVybiAke3Jlc3VsdH07YDtcbiAgICAgICAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIEB0eXBlc2NyaXB0LWVzbGludC9uby1pbXBsaWVkLWV2YWwsbm8tbmV3LWZ1bmNcbiAgICAgICAgcmV0dXJuIG5ldyBGdW5jdGlvbignaW5wdXQnLCBjYiA/IGNiKHNvdXJjZSkgOiBzb3VyY2UpO1xuICAgIH1cbn1cblxuZnVuY3Rpb24gd2VpZ2h0ZWRTdW1TaWdtb2lkKHdlaWdodHMsIGJpYXNlcywgaW5wdXRzKSB7XG4gICAgbGV0IHN1bSA9IGJpYXNlc1t0aGlzLnRocmVhZC54XTtcbiAgICBmb3IgKGxldCBrID0gMDsgayA8IHRoaXMuY29uc3RhbnRzLnNpemU7IGsrKykge1xuICAgICAgICBzdW0gKz0gd2VpZ2h0c1t0aGlzLnRocmVhZC54XVtrXSAqIGlucHV0c1trXTtcbiAgICB9XG4gICAgLy8gc2lnbW9pZFxuICAgIHJldHVybiAxIC8gKDEgKyBNYXRoLmV4cCgtc3VtKSk7XG59XG5mdW5jdGlvbiB3ZWlnaHRlZFN1bVJlbHUod2VpZ2h0cywgYmlhc2VzLCBpbnB1dHMpIHtcbiAgICBsZXQgc3VtID0gYmlhc2VzW3RoaXMudGhyZWFkLnhdO1xuICAgIGZvciAobGV0IGsgPSAwOyBrIDwgdGhpcy5jb25zdGFudHMuc2l6ZTsgaysrKSB7XG4gICAgICAgIHN1bSArPSB3ZWlnaHRzW3RoaXMudGhyZWFkLnhdW2tdICogaW5wdXRzW2tdO1xuICAgIH1cbiAgICAvLyByZWx1XG4gICAgcmV0dXJuIHN1bSA8IDAgPyAwIDogc3VtO1xufVxuZnVuY3Rpb24gd2VpZ2h0ZWRTdW1MZWFreVJlbHUod2VpZ2h0cywgYmlhc2VzLCBpbnB1dHMpIHtcbiAgICBsZXQgc3VtID0gYmlhc2VzW3RoaXMudGhyZWFkLnhdO1xuICAgIGZvciAobGV0IGsgPSAwOyBrIDwgdGhpcy5jb25zdGFudHMuc2l6ZTsgaysrKSB7XG4gICAgICAgIHN1bSArPSB3ZWlnaHRzW3RoaXMudGhyZWFkLnhdW2tdICogaW5wdXRzW2tdO1xuICAgIH1cbiAgICAvLyBsZWFreSByZWx1XG4gICAgcmV0dXJuIHN1bSA8IDAgPyAwIDogMC4wMSAqIHN1bTtcbn1cbmZ1bmN0aW9uIHdlaWdodGVkU3VtVGFuaCh3ZWlnaHRzLCBiaWFzZXMsIGlucHV0cykge1xuICAgIGxldCBzdW0gPSBiaWFzZXNbdGhpcy50aHJlYWQueF07XG4gICAgZm9yIChsZXQgayA9IDA7IGsgPCB0aGlzLmNvbnN0YW50cy5zaXplOyBrKyspIHtcbiAgICAgICAgc3VtICs9IHdlaWdodHNbdGhpcy50aHJlYWQueF1ba10gKiBpbnB1dHNba107XG4gICAgfVxuICAgIC8vIHRhbmhcbiAgICByZXR1cm4gTWF0aC50YW5oKHN1bSk7XG59XG5mdW5jdGlvbiBjYWxjRXJyb3JPdXRwdXQob3V0cHV0LCB0YXJnZXQpIHtcbiAgICByZXR1cm4gdGFyZ2V0IC0gb3V0cHV0O1xufVxuZnVuY3Rpb24gY2FsY0RlbHRhc1NpZ21vaWQoZXJyb3IsIG91dHB1dCkge1xuICAgIC8vIHNpZ21vaWQgZGVyaXZhdGl2ZVxuICAgIHJldHVybiBlcnJvciAqIG91dHB1dCAqICgxIC0gb3V0cHV0KTtcbn1cbmZ1bmN0aW9uIGNhbGNEZWx0YXNSZWx1KGVycm9yLCBvdXRwdXQpIHtcbiAgICAvLyByZWx1IGRlcml2YXRpdmVcbiAgICByZXR1cm4gb3V0cHV0ID4gMCA/IGVycm9yIDogMDtcbn1cbmZ1bmN0aW9uIGNhbGNEZWx0YXNMZWFreVJlbHUoZXJyb3IsIG91dHB1dCkge1xuICAgIC8vIGxlYWt5IHJlbHUgZGVyaXZhdGl2ZVxuICAgIHJldHVybiBvdXRwdXQgPiAwID8gZXJyb3IgOiAwLjAxICogZXJyb3I7XG59XG5mdW5jdGlvbiBjYWxjRGVsdGFzVGFuaChlcnJvciwgb3V0cHV0KSB7XG4gICAgLy8gdGFuaCBkZXJpdmF0aXZlXG4gICAgcmV0dXJuICgxIC0gb3V0cHV0ICogb3V0cHV0KSAqIGVycm9yO1xufVxuZnVuY3Rpb24gY2FsY0Vycm9yKHgsIHNpemUsIG5leHRXZWlnaHRzLCBuZXh0RGVsdGFzKSB7XG4gICAgbGV0IGVycm9yID0gMDtcbiAgICBmb3IgKGxldCBrID0gMDsgayA8IHNpemU7IGsrKykge1xuICAgICAgICBlcnJvciArPSBuZXh0RGVsdGFzW2tdICogbmV4dFdlaWdodHNba11beF07XG4gICAgfVxuICAgIHJldHVybiBlcnJvcjtcbn1cbmZ1bmN0aW9uIGNhbGNDaGFuZ2VzKGxlYXJuaW5nUmF0ZSwgbW9tZW50dW0sIHByZXZpb3VzQ2hhbmdlLCBkZWx0YSwgcHJldmlvdXNPdXRwdXQpIHtcbiAgICByZXR1cm4gbGVhcm5pbmdSYXRlICogZGVsdGEgKiBwcmV2aW91c091dHB1dCArIG1vbWVudHVtICogcHJldmlvdXNDaGFuZ2U7XG59XG5mdW5jdGlvbiBhZGRXZWlnaHRzKGNoYW5nZSwgd2VpZ2h0KSB7XG4gICAgcmV0dXJuIGNoYW5nZSArIHdlaWdodDtcbn1cbmZ1bmN0aW9uIGFkZEJpYXNlcyhiaWFzZXMsIGRlbHRhcykge1xuICAgIHJldHVybiAoYmlhc2VzW3RoaXMudGhyZWFkLnhdICsgZGVsdGFzW3RoaXMudGhyZWFkLnhdICogdGhpcy5jb25zdGFudHMubGVhcm5pbmdSYXRlKTtcbn1cbi8vIG1lYW4gc3F1YXJlZCBlcnJvciwgcmVpbXBsZW1lbnRlZCBmb3IgR1BVXG5mdW5jdGlvbiBtc2UoZXJyb3JzKSB7XG4gICAgbGV0IHN1bSA9IDA7XG4gICAgZm9yIChsZXQgaSA9IDA7IGkgPCB0aGlzLmNvbnN0YW50cy5zaXplOyBpKyspIHtcbiAgICAgICAgc3VtICs9IGVycm9yc1tpXSAqKiAyO1xuICAgIH1cbiAgICByZXR1cm4gc3VtIC8gdGhpcy5jb25zdGFudHMuc2l6ZTtcbn1cbmNsYXNzIE5ldXJhbE5ldHdvcmtHUFUgZXh0ZW5kcyBOZXVyYWxOZXR3b3JrIHtcbiAgICBjb25zdHJ1Y3RvcihvcHRpb25zID0ge30pIHtcbiAgICAgICAgc3VwZXIob3B0aW9ucyk7XG4gICAgICAgIHRoaXMudGV4dHVyaXplSW5wdXREYXRhID0gKCkgPT4ge1xuICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdub3QgeWV0IHNldHVwJyk7XG4gICAgICAgIH07XG4gICAgICAgIHRoaXMuZm9yd2FyZFByb3BhZ2F0ZSA9IFtdO1xuICAgICAgICB0aGlzLmJhY2t3YXJkUHJvcGFnYXRlID0gW107XG4gICAgICAgIHRoaXMuY2hhbmdlc1Byb3BhZ2F0ZSA9IFtdO1xuICAgICAgICB0aGlzLmJpYXNlc1Byb3BhZ2F0ZSA9IFtdO1xuICAgICAgICB0aGlzLmdldE1TRSA9ICgpID0+IHtcbiAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcignbm90IHlldCBzZXR1cCcpO1xuICAgICAgICB9O1xuICAgICAgICB0aGlzLl9hZGRNU0UgPSAoKSA9PiB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ25vdCB5ZXQgc2V0dXAnKTtcbiAgICAgICAgfTtcbiAgICAgICAgdGhpcy5fZGl2aWRlTVNFU3VtID0gKCkgPT4ge1xuICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdub3QgeWV0IHNldHVwJyk7XG4gICAgICAgIH07XG4gICAgICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBAdHlwZXNjcmlwdC1lc2xpbnQvYmFuLXRzLWNvbW1lbnRcbiAgICAgICAgLy8gQHRzLWV4cGVjdC1lcnJvclxuICAgICAgICB0aGlzLm91dHB1dHMgPSBbXTtcbiAgICAgICAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIEB0eXBlc2NyaXB0LWVzbGludC9iYW4tdHMtY29tbWVudFxuICAgICAgICAvLyBAdHMtZXhwZWN0LWVycm9yXG4gICAgICAgIHRoaXMuZGVsdGFzID0gW107XG4gICAgICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBAdHlwZXNjcmlwdC1lc2xpbnQvYmFuLXRzLWNvbW1lbnRcbiAgICAgICAgLy8gQHRzLWV4cGVjdC1lcnJvclxuICAgICAgICB0aGlzLmVycm9ycyA9IFtdO1xuICAgICAgICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgQHR5cGVzY3JpcHQtZXNsaW50L2Jhbi10cy1jb21tZW50XG4gICAgICAgIC8vIEB0cy1leHBlY3QtZXJyb3JcbiAgICAgICAgdGhpcy53ZWlnaHRzID0gW107XG4gICAgICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBAdHlwZXNjcmlwdC1lc2xpbnQvYmFuLXRzLWNvbW1lbnRcbiAgICAgICAgLy8gQHRzLWV4cGVjdC1lcnJvclxuICAgICAgICB0aGlzLmNoYW5nZXMgPSBbXTtcbiAgICAgICAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIEB0eXBlc2NyaXB0LWVzbGludC9iYW4tdHMtY29tbWVudFxuICAgICAgICAvLyBAdHMtZXhwZWN0LWVycm9yXG4gICAgICAgIHRoaXMuYmlhc2VzID0gW107XG4gICAgICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBAdHlwZXNjcmlwdC1lc2xpbnQvYmFuLXRzLWNvbW1lbnRcbiAgICAgICAgLy8gQHRzLWV4cGVjdC1lcnJvclxuICAgICAgICB0aGlzLnJ1bklucHV0ID0gKGlucHV0KSA9PiB7XG4gICAgICAgICAgICBsZXQgb3V0cHV0O1xuICAgICAgICAgICAgdGhpcy5vdXRwdXRzWzBdID0gaW5wdXQ7XG4gICAgICAgICAgICBmb3IgKGxldCBsYXllciA9IDE7IGxheWVyIDw9IHRoaXMub3V0cHV0TGF5ZXI7IGxheWVyKyspIHtcbiAgICAgICAgICAgICAgICByZWxlYXNlKHRoaXMub3V0cHV0c1tsYXllcl0pO1xuICAgICAgICAgICAgICAgIHRoaXMub3V0cHV0c1tsYXllcl0gPSB0aGlzLmZvcndhcmRQcm9wYWdhdGVbbGF5ZXJdKHRoaXMud2VpZ2h0c1tsYXllcl0sIHRoaXMuYmlhc2VzW2xheWVyXSwgaW5wdXQpO1xuICAgICAgICAgICAgICAgIG91dHB1dCA9IGlucHV0ID0gdGhpcy5vdXRwdXRzW2xheWVyXTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHJldHVybiBvdXRwdXQ7XG4gICAgICAgIH07XG4gICAgICAgIHRoaXMuY2FsY3VsYXRlRGVsdGFzID0gKHRhcmdldCkgPT4ge1xuICAgICAgICAgICAgZm9yIChsZXQgbGF5ZXIgPSB0aGlzLm91dHB1dExheWVyOyBsYXllciA+IDA7IGxheWVyLS0pIHtcbiAgICAgICAgICAgICAgICByZWxlYXNlKHRoaXMuZGVsdGFzW2xheWVyXSk7XG4gICAgICAgICAgICAgICAgcmVsZWFzZSh0aGlzLmVycm9yc1tsYXllcl0pO1xuICAgICAgICAgICAgICAgIGxldCBvdXRwdXQ7XG4gICAgICAgICAgICAgICAgaWYgKGxheWVyID09PSB0aGlzLm91dHB1dExheWVyKSB7XG4gICAgICAgICAgICAgICAgICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBAdHlwZXNjcmlwdC1lc2xpbnQvYmFuLXRzLWNvbW1lbnRcbiAgICAgICAgICAgICAgICAgICAgLy8gQHRzLWV4cGVjdC1lcnJvclxuICAgICAgICAgICAgICAgICAgICBvdXRwdXQgPSB0aGlzLmJhY2t3YXJkUHJvcGFnYXRlW2xheWVyXSh0aGlzLm91dHB1dHNbbGF5ZXJdLCB0YXJnZXQpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIEB0eXBlc2NyaXB0LWVzbGludC9iYW4tdHMtY29tbWVudFxuICAgICAgICAgICAgICAgICAgICAvLyBAdHMtZXhwZWN0LWVycm9yXG4gICAgICAgICAgICAgICAgICAgIG91dHB1dCA9IHRoaXMuYmFja3dhcmRQcm9wYWdhdGVbbGF5ZXJdKHRoaXMud2VpZ2h0c1tsYXllciArIDFdLCB0aGlzLm91dHB1dHNbbGF5ZXJdLCB0aGlzLmRlbHRhc1tsYXllciArIDFdKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgdGhpcy5kZWx0YXNbbGF5ZXJdID0gb3V0cHV0LnJlc3VsdDtcbiAgICAgICAgICAgICAgICB0aGlzLmVycm9yc1tsYXllcl0gPSBvdXRwdXQuZXJyb3I7XG4gICAgICAgICAgICB9XG4gICAgICAgIH07XG4gICAgICAgIHRoaXMuZXJyb3JDaGVja0ludGVydmFsID0gMTAwO1xuICAgICAgICB0aGlzLmdwdSA9IG5ldyBncHVfanMuR1BVKHsgbW9kZTogb3B0aW9ucy5tb2RlIH0pO1xuICAgIH1cbiAgICBpbml0aWFsaXplKCkge1xuICAgICAgICBzdXBlci5pbml0aWFsaXplKCk7XG4gICAgICAgIHRoaXMuYnVpbGRSdW5JbnB1dCgpO1xuICAgICAgICB0aGlzLmJ1aWxkQ2FsY3VsYXRlRGVsdGFzKCk7XG4gICAgICAgIHRoaXMuYnVpbGRHZXRDaGFuZ2VzKCk7XG4gICAgICAgIHRoaXMuYnVpbGRDaGFuZ2VCaWFzZXMoKTtcbiAgICAgICAgdGhpcy5idWlsZEdldE1TRSgpO1xuICAgIH1cbiAgICBzZXRBY3RpdmF0aW9uKCkgeyB9XG4gICAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIEB0eXBlc2NyaXB0LWVzbGludC9iYW4tdHMtY29tbWVudFxuICAgIC8vIEB0cy1leHBlY3QtZXJyb3JcbiAgICB0cmFpblBhdHRlcm4odmFsdWUsIGxvZ0Vycm9yUmF0ZSkge1xuICAgICAgICAvLyBmb3J3YXJkIHByb3BhZ2F0ZVxuICAgICAgICB0aGlzLnJ1bklucHV0KHZhbHVlLmlucHV0KTtcbiAgICAgICAgLy8gYmFjayBwcm9wYWdhdGVcbiAgICAgICAgdGhpcy5jYWxjdWxhdGVEZWx0YXModmFsdWUub3V0cHV0KTtcbiAgICAgICAgdGhpcy5hZGp1c3RXZWlnaHRzKCk7XG4gICAgICAgIGlmIChsb2dFcnJvclJhdGUpIHtcbiAgICAgICAgICAgIHJldHVybiB0aGlzLmdldE1TRSh0aGlzLmVycm9yc1t0aGlzLm91dHB1dExheWVyXSk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIG51bGw7XG4gICAgfVxuICAgIGNhbGN1bGF0ZVRyYWluaW5nRXJyb3IoZGF0YSkge1xuICAgICAgICBsZXQgc3VtID0gbmV3IEZsb2F0MzJBcnJheShbMF0pO1xuICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IGRhdGEubGVuZ3RoOyArK2kpIHtcbiAgICAgICAgICAgIGNvbnN0IHByZXZTdW0gPSBzdW07XG4gICAgICAgICAgICBjb25zdCBlcnJvciA9IHRoaXMudHJhaW5QYXR0ZXJuKGRhdGFbaV0sIHRydWUpO1xuICAgICAgICAgICAgc3VtID0gdGhpcy5fYWRkTVNFKHN1bSwgZXJyb3IpO1xuICAgICAgICAgICAgcmVsZWFzZShlcnJvcik7XG4gICAgICAgICAgICByZWxlYXNlKHByZXZTdW0pO1xuICAgICAgICB9XG4gICAgICAgIGNvbnN0IHJlc3VsdCA9IHRoaXMuX2RpdmlkZU1TRVN1bShkYXRhLmxlbmd0aCwgc3VtKTtcbiAgICAgICAgcmVsZWFzZShzdW0pO1xuICAgICAgICByZXR1cm4gKHJlc3VsdCBpbnN0YW5jZW9mIGdwdV9qcy5UZXh0dXJlXG4gICAgICAgICAgICA/IHJlc3VsdC50b0FycmF5KClcbiAgICAgICAgICAgIDogcmVzdWx0KVswXTtcbiAgICB9XG4gICAgYWRqdXN0V2VpZ2h0cygpIHtcbiAgICAgICAgdGhpcy5nZXRDaGFuZ2VzKCk7XG4gICAgICAgIHRoaXMuY2hhbmdlQmlhc2VzKCk7XG4gICAgfVxuICAgIGJ1aWxkUnVuSW5wdXQoKSB7XG4gICAgICAgIGxldCB3ZWlnaHRlZFN1bSA9IG51bGw7XG4gICAgICAgIHN3aXRjaCAodGhpcy50cmFpbk9wdHMuYWN0aXZhdGlvbikge1xuICAgICAgICAgICAgY2FzZSAnc2lnbW9pZCc6XG4gICAgICAgICAgICAgICAgd2VpZ2h0ZWRTdW0gPSB3ZWlnaHRlZFN1bVNpZ21vaWQ7XG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICBjYXNlICdyZWx1JzpcbiAgICAgICAgICAgICAgICB3ZWlnaHRlZFN1bSA9IHdlaWdodGVkU3VtUmVsdTtcbiAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgIGNhc2UgJ2xlYWt5LXJlbHUnOlxuICAgICAgICAgICAgICAgIHdlaWdodGVkU3VtID0gd2VpZ2h0ZWRTdW1MZWFreVJlbHU7XG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICBjYXNlICd0YW5oJzpcbiAgICAgICAgICAgICAgICB3ZWlnaHRlZFN1bSA9IHdlaWdodGVkU3VtVGFuaDtcbiAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgIGRlZmF1bHQ6XG4gICAgICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKGBVbmtub3duIGFjdGl2YXRpb24gJHt0aGlzLnRyYWluT3B0cy5hY3RpdmF0aW9ufS4gQXZhaWxhYmxlIGFjdGl2YXRpb25zIGFyZTogJ3NpZ21vaWQnLCAncmVsdScsICdsZWFreS1yZWx1JywgJ3RhbmgnYCk7XG4gICAgICAgIH1cbiAgICAgICAgZm9yIChsZXQgbGF5ZXIgPSAxOyBsYXllciA8PSB0aGlzLm91dHB1dExheWVyOyBsYXllcisrKSB7XG4gICAgICAgICAgICB0aGlzLmZvcndhcmRQcm9wYWdhdGVbbGF5ZXJdID0gdGhpcy5ncHUuY3JlYXRlS2VybmVsKHdlaWdodGVkU3VtLCB7XG4gICAgICAgICAgICAgICAgb3V0cHV0OiBbdGhpcy5zaXplc1tsYXllcl1dLFxuICAgICAgICAgICAgICAgIHBpcGVsaW5lOiB0cnVlLFxuICAgICAgICAgICAgICAgIGNvbnN0YW50czoge1xuICAgICAgICAgICAgICAgICAgICBzaXplOiB0aGlzLnNpemVzW2xheWVyIC0gMV0sXG4gICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICBpbW11dGFibGU6IHRydWUsXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgfVxuICAgICAgICB0aGlzLnRleHR1cml6ZUlucHV0RGF0YSA9IHRoaXMuZ3B1LmNyZWF0ZUtlcm5lbChmdW5jdGlvbiAodmFsdWUpIHtcbiAgICAgICAgICAgIHJldHVybiB2YWx1ZVt0aGlzLnRocmVhZC54XTtcbiAgICAgICAgfSwge1xuICAgICAgICAgICAgb3V0cHV0OiBbdGhpcy5zaXplc1sxXV0sXG4gICAgICAgICAgICBwaXBlbGluZTogdHJ1ZSxcbiAgICAgICAgICAgIGltbXV0YWJsZTogdHJ1ZSxcbiAgICAgICAgfSk7XG4gICAgfVxuICAgIGJ1aWxkQ2FsY3VsYXRlRGVsdGFzKCkge1xuICAgICAgICBsZXQgY2FsY0RlbHRhcztcbiAgICAgICAgc3dpdGNoICh0aGlzLnRyYWluT3B0cy5hY3RpdmF0aW9uKSB7XG4gICAgICAgICAgICBjYXNlICdzaWdtb2lkJzpcbiAgICAgICAgICAgICAgICBjYWxjRGVsdGFzID0gY2FsY0RlbHRhc1NpZ21vaWQ7XG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICBjYXNlICdyZWx1JzpcbiAgICAgICAgICAgICAgICBjYWxjRGVsdGFzID0gY2FsY0RlbHRhc1JlbHU7XG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICBjYXNlICdsZWFreS1yZWx1JzpcbiAgICAgICAgICAgICAgICBjYWxjRGVsdGFzID0gY2FsY0RlbHRhc0xlYWt5UmVsdTtcbiAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgIGNhc2UgJ3RhbmgnOlxuICAgICAgICAgICAgICAgIGNhbGNEZWx0YXMgPSBjYWxjRGVsdGFzVGFuaDtcbiAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgIGRlZmF1bHQ6XG4gICAgICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKGBVbmtub3duIGFjdGl2YXRpb24gJHt0aGlzLnRyYWluT3B0cy5hY3RpdmF0aW9ufS4gQXZhaWxhYmxlIGFjdGl2YXRpb25zIGFyZTogJ3NpZ21vaWQnLCAncmVsdScsICdsZWFreS1yZWx1JywgJ3RhbmgnYCk7XG4gICAgICAgIH1cbiAgICAgICAgY2FsY0RlbHRhcyA9IGdwdV9qcy5hbGlhcyhncHVfanMudXRpbHMuZ2V0TWluaWZ5U2FmZU5hbWUoKCkgPT4gY2FsY0RlbHRhcyksIGNhbGNEZWx0YXMpO1xuICAgICAgICB0aGlzLmdwdS5hZGRGdW5jdGlvbihjYWxjRGVsdGFzKTtcbiAgICAgICAgZm9yIChsZXQgbGF5ZXIgPSB0aGlzLm91dHB1dExheWVyOyBsYXllciA+IDA7IGxheWVyLS0pIHtcbiAgICAgICAgICAgIGlmIChsYXllciA9PT0gdGhpcy5vdXRwdXRMYXllcikge1xuICAgICAgICAgICAgICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBAdHlwZXNjcmlwdC1lc2xpbnQvYmFuLXRzLWNvbW1lbnRcbiAgICAgICAgICAgICAgICAvLyBAdHMtZXhwZWN0LWVycm9yXG4gICAgICAgICAgICAgICAgdGhpcy5iYWNrd2FyZFByb3BhZ2F0ZVt0aGlzLm91dHB1dExheWVyXSA9IHRoaXMuZ3B1LmNyZWF0ZUtlcm5lbE1hcCh7XG4gICAgICAgICAgICAgICAgICAgIGVycm9yOiBjYWxjRXJyb3JPdXRwdXQsXG4gICAgICAgICAgICAgICAgfSwgZnVuY3Rpb24gKG91dHB1dHMsIHRhcmdldHMpIHtcbiAgICAgICAgICAgICAgICAgICAgY29uc3Qgb3V0cHV0ID0gb3V0cHV0c1t0aGlzLnRocmVhZC54XTtcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgdGFyZ2V0ID0gdGFyZ2V0c1t0aGlzLnRocmVhZC54XTtcbiAgICAgICAgICAgICAgICAgICAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIEB0eXBlc2NyaXB0LWVzbGludC9iYW4tdHMtY29tbWVudFxuICAgICAgICAgICAgICAgICAgICAvLyBAdHMtZXhwZWN0LWVycm9yXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBjYWxjRGVsdGFzKGNhbGNFcnJvck91dHB1dChvdXRwdXQsIHRhcmdldCksIG91dHB1dCk7XG4gICAgICAgICAgICAgICAgfSwge1xuICAgICAgICAgICAgICAgICAgICBvdXRwdXQ6IFt0aGlzLnNpemVzW3RoaXMub3V0cHV0TGF5ZXJdXSxcbiAgICAgICAgICAgICAgICAgICAgcGlwZWxpbmU6IHRydWUsXG4gICAgICAgICAgICAgICAgICAgIGltbXV0YWJsZTogdHJ1ZSxcbiAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBAdHlwZXNjcmlwdC1lc2xpbnQvYmFuLXRzLWNvbW1lbnRcbiAgICAgICAgICAgICAgICAvLyBAdHMtZXhwZWN0LWVycm9yXG4gICAgICAgICAgICAgICAgdGhpcy5iYWNrd2FyZFByb3BhZ2F0ZVtsYXllcl0gPSB0aGlzLmdwdS5jcmVhdGVLZXJuZWxNYXAoe1xuICAgICAgICAgICAgICAgICAgICBlcnJvcjogY2FsY0Vycm9yLFxuICAgICAgICAgICAgICAgIH0sIGZ1bmN0aW9uIChuZXh0V2VpZ2h0cywgb3V0cHV0cywgbmV4dERlbHRhcykge1xuICAgICAgICAgICAgICAgICAgICBjb25zdCBvdXRwdXQgPSBvdXRwdXRzW3RoaXMudGhyZWFkLnhdO1xuICAgICAgICAgICAgICAgICAgICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgQHR5cGVzY3JpcHQtZXNsaW50L2Jhbi10cy1jb21tZW50XG4gICAgICAgICAgICAgICAgICAgIC8vIEB0cy1leHBlY3QtZXJyb3JcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGNhbGNEZWx0YXMoY2FsY0Vycm9yKHRoaXMudGhyZWFkLngsIHRoaXMuY29uc3RhbnRzLnNpemUsIG5leHRXZWlnaHRzLCBuZXh0RGVsdGFzKSwgb3V0cHV0KTtcbiAgICAgICAgICAgICAgICB9LCB7XG4gICAgICAgICAgICAgICAgICAgIG91dHB1dDogW3RoaXMuc2l6ZXNbbGF5ZXJdXSxcbiAgICAgICAgICAgICAgICAgICAgcGlwZWxpbmU6IHRydWUsXG4gICAgICAgICAgICAgICAgICAgIGNvbnN0YW50czoge1xuICAgICAgICAgICAgICAgICAgICAgICAgc2l6ZTogdGhpcy5zaXplc1tsYXllciArIDFdLFxuICAgICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgICAgICBpbW11dGFibGU6IHRydWUsXG4gICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9XG4gICAgYnVpbGRHZXRDaGFuZ2VzKCkge1xuICAgICAgICBmb3IgKGxldCBsYXllciA9IDE7IGxheWVyIDw9IHRoaXMub3V0cHV0TGF5ZXI7IGxheWVyKyspIHtcbiAgICAgICAgICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBAdHlwZXNjcmlwdC1lc2xpbnQvYmFuLXRzLWNvbW1lbnRcbiAgICAgICAgICAgIC8vIEB0cy1leHBlY3QtZXJyb3JcbiAgICAgICAgICAgIHRoaXMuY2hhbmdlc1Byb3BhZ2F0ZVtsYXllcl0gPSB0aGlzLmdwdS5jcmVhdGVLZXJuZWxNYXAoe1xuICAgICAgICAgICAgICAgIHdlaWdodHM6IGFkZFdlaWdodHMsXG4gICAgICAgICAgICAgICAgY2hhbmdlczogY2FsY0NoYW5nZXMsXG4gICAgICAgICAgICB9LCBmdW5jdGlvbiAocHJldmlvdXNPdXRwdXRzLCBkZWx0YXMsIHdlaWdodHMsIHByZXZpb3VzQ2hhbmdlcykge1xuICAgICAgICAgICAgICAgIGNvbnN0IGNoYW5nZSA9IGNhbGNDaGFuZ2VzKHRoaXMuY29uc3RhbnRzLmxlYXJuaW5nUmF0ZSwgdGhpcy5jb25zdGFudHMubW9tZW50dW0sIHByZXZpb3VzQ2hhbmdlc1t0aGlzLnRocmVhZC55XVt0aGlzLnRocmVhZC54XSwgZGVsdGFzW3RoaXMudGhyZWFkLnldLCBwcmV2aW91c091dHB1dHNbdGhpcy50aHJlYWQueF0pO1xuICAgICAgICAgICAgICAgIHJldHVybiBhZGRXZWlnaHRzKGNoYW5nZSwgd2VpZ2h0c1t0aGlzLnRocmVhZC55XVt0aGlzLnRocmVhZC54XSk7XG4gICAgICAgICAgICB9LCB7XG4gICAgICAgICAgICAgICAgb3V0cHV0OiBbdGhpcy5zaXplc1tsYXllciAtIDFdLCB0aGlzLnNpemVzW2xheWVyXV0sXG4gICAgICAgICAgICAgICAgcGlwZWxpbmU6IHRydWUsXG4gICAgICAgICAgICAgICAgY29uc3RhbnRzOiB7XG4gICAgICAgICAgICAgICAgICAgIHNpemU6IHRoaXMuc2l6ZXNbbGF5ZXIgLSAxXSxcbiAgICAgICAgICAgICAgICAgICAgbGVhcm5pbmdSYXRlOiB0aGlzLnRyYWluT3B0cy5sZWFybmluZ1JhdGUsXG4gICAgICAgICAgICAgICAgICAgIG1vbWVudHVtOiB0aGlzLnRyYWluT3B0cy5tb21lbnR1bSxcbiAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgIGltbXV0YWJsZTogdHJ1ZSxcbiAgICAgICAgICAgIH0pO1xuICAgICAgICB9XG4gICAgfVxuICAgIGdldENoYW5nZXMoKSB7XG4gICAgICAgIGZvciAobGV0IGxheWVyID0gMTsgbGF5ZXIgPD0gdGhpcy5vdXRwdXRMYXllcjsgbGF5ZXIrKykge1xuICAgICAgICAgICAgY29uc3Qgd2VpZ2h0cyA9IHRoaXMud2VpZ2h0c1tsYXllcl07XG4gICAgICAgICAgICBjb25zdCBjaGFuZ2VzID0gdGhpcy5jaGFuZ2VzW2xheWVyXTtcbiAgICAgICAgICAgIGNvbnN0IG91dHB1dCA9IHRoaXMuY2hhbmdlc1Byb3BhZ2F0ZVtsYXllcl0odGhpcy5vdXRwdXRzW2xheWVyIC0gMV0sIHRoaXMuZGVsdGFzW2xheWVyXSwgd2VpZ2h0cywgY2hhbmdlcyk7XG4gICAgICAgICAgICByZWxlYXNlKHdlaWdodHMpO1xuICAgICAgICAgICAgcmVsZWFzZShjaGFuZ2VzKTtcbiAgICAgICAgICAgIHRoaXMud2VpZ2h0c1tsYXllcl0gPSBvdXRwdXQud2VpZ2h0cztcbiAgICAgICAgICAgIHRoaXMuY2hhbmdlc1tsYXllcl0gPSBvdXRwdXQuY2hhbmdlcztcbiAgICAgICAgICAgIHJlbGVhc2Uob3V0cHV0LnJlc3VsdCk7XG4gICAgICAgIH1cbiAgICB9XG4gICAgYnVpbGRDaGFuZ2VCaWFzZXMoKSB7XG4gICAgICAgIGZvciAobGV0IGxheWVyID0gMTsgbGF5ZXIgPD0gdGhpcy5vdXRwdXRMYXllcjsgbGF5ZXIrKykge1xuICAgICAgICAgICAgdGhpcy5iaWFzZXNQcm9wYWdhdGVbbGF5ZXJdID0gdGhpcy5ncHUuY3JlYXRlS2VybmVsKGFkZEJpYXNlcywge1xuICAgICAgICAgICAgICAgIG91dHB1dDogW3RoaXMuc2l6ZXNbbGF5ZXJdXSxcbiAgICAgICAgICAgICAgICBwaXBlbGluZTogdHJ1ZSxcbiAgICAgICAgICAgICAgICBjb25zdGFudHM6IHtcbiAgICAgICAgICAgICAgICAgICAgbGVhcm5pbmdSYXRlOiB0aGlzLnRyYWluT3B0cy5sZWFybmluZ1JhdGUsXG4gICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICBpbW11dGFibGU6IHRydWUsXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgfVxuICAgIH1cbiAgICBjaGFuZ2VCaWFzZXMoKSB7XG4gICAgICAgIGZvciAobGV0IGxheWVyID0gMTsgbGF5ZXIgPD0gdGhpcy5vdXRwdXRMYXllcjsgbGF5ZXIrKykge1xuICAgICAgICAgICAgY29uc3QgYmlhc2VzID0gdGhpcy5iaWFzZXNbbGF5ZXJdO1xuICAgICAgICAgICAgdGhpcy5iaWFzZXNbbGF5ZXJdID0gdGhpcy5iaWFzZXNQcm9wYWdhdGVbbGF5ZXJdKGJpYXNlcywgdGhpcy5kZWx0YXNbbGF5ZXJdKTtcbiAgICAgICAgICAgIHJlbGVhc2UoYmlhc2VzKTtcbiAgICAgICAgfVxuICAgIH1cbiAgICBidWlsZEdldE1TRSgpIHtcbiAgICAgICAgdGhpcy5nZXRNU0UgPSB0aGlzLmdwdS5jcmVhdGVLZXJuZWwobXNlLCB7XG4gICAgICAgICAgICBvdXRwdXQ6IFsxXSxcbiAgICAgICAgICAgIGNvbnN0YW50czoge1xuICAgICAgICAgICAgICAgIHNpemU6IHRoaXMuc2l6ZXNbdGhpcy5vdXRwdXRMYXllcl0sXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgcGlwZWxpbmU6IHRydWUsXG4gICAgICAgICAgICBpbW11dGFibGU6IHRydWUsXG4gICAgICAgIH0pO1xuICAgICAgICB0aGlzLl9hZGRNU0UgPSB0aGlzLmdwdS5jcmVhdGVLZXJuZWwoZnVuY3Rpb24gKHZhbHVlMSwgdmFsdWUyKSB7XG4gICAgICAgICAgICByZXR1cm4gdmFsdWUxWzBdICsgdmFsdWUyWzBdO1xuICAgICAgICB9LCB7XG4gICAgICAgICAgICBvdXRwdXQ6IFsxXSxcbiAgICAgICAgICAgIHBpcGVsaW5lOiB0cnVlLFxuICAgICAgICAgICAgaW1tdXRhYmxlOiB0cnVlLFxuICAgICAgICB9KTtcbiAgICAgICAgdGhpcy5fZGl2aWRlTVNFU3VtID0gdGhpcy5ncHUuY3JlYXRlS2VybmVsKGZ1bmN0aW9uIChsZW5ndGgsIG1zZVN1bSkge1xuICAgICAgICAgICAgY29uc3QgdmFsdWUgPSBtc2VTdW1bMF07XG4gICAgICAgICAgICBpZiAodmFsdWUgPiAwKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIHZhbHVlIC8gbGVuZ3RoO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgcmV0dXJuIDA7XG4gICAgICAgIH0sIHtcbiAgICAgICAgICAgIG91dHB1dDogWzFdLFxuICAgICAgICB9KTtcbiAgICB9XG4gICAgcnVuKGlucHV0KSB7XG4gICAgICAgIGlmICghdGhpcy5pc1J1bm5hYmxlKSB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ25ldHdvcmsgbm90IHJ1bm5hYmxlJyk7XG4gICAgICAgIH1cbiAgICAgICAgbGV0IGZvcm1hdHRlZElucHV0O1xuICAgICAgICBpZiAodGhpcy5pbnB1dExvb2t1cCkge1xuICAgICAgICAgICAgZm9ybWF0dGVkSW5wdXQgPSBsb29rdXAudG9BcnJheSh0aGlzLmlucHV0TG9va3VwLCBpbnB1dCwgdGhpcy5pbnB1dExvb2t1cExlbmd0aCk7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICBmb3JtYXR0ZWRJbnB1dCA9IGlucHV0O1xuICAgICAgICB9XG4gICAgICAgIGNvbnN0IG91dHB1dFRleHR1cmVzID0gdGhpcy5ydW5JbnB1dChmb3JtYXR0ZWRJbnB1dCk7XG4gICAgICAgIGNvbnN0IG91dHB1dCA9IG91dHB1dFRleHR1cmVzIGluc3RhbmNlb2YgZ3B1X2pzLlRleHR1cmVcbiAgICAgICAgICAgID8gb3V0cHV0VGV4dHVyZXMudG9BcnJheSgpXG4gICAgICAgICAgICA6IG91dHB1dFRleHR1cmVzO1xuICAgICAgICBpZiAodGhpcy5vdXRwdXRMb29rdXApIHtcbiAgICAgICAgICAgIHJldHVybiBsb29rdXAudG9PYmplY3QodGhpcy5vdXRwdXRMb29rdXAsIG91dHB1dCk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIG91dHB1dDtcbiAgICB9XG4gICAgLy8gQHRzLWV4cGVjdC1lcnJvciB0aGUgdW5kZXJseWluZyBuZXR3b3JrIHdvcmtzIGFzIG5vcm1hbCwgYnV0IHdlIGFyZSB3b3JraW5nIG9uIHRoZSBHUFVcbiAgICBwcmVwVHJhaW5pbmcoZGF0YSwgb3B0aW9ucyA9IHt9KSB7XG4gICAgICAgIHRoaXMudXBkYXRlVHJhaW5pbmdPcHRpb25zKG9wdGlvbnMpO1xuICAgICAgICBjb25zdCBwcmVwYXJlZERhdGEgPSB0aGlzLmZvcm1hdERhdGEoZGF0YSk7XG4gICAgICAgIGNvbnN0IGVuZFRpbWUgPSBEYXRlLm5vdygpICsgdGhpcy50cmFpbk9wdHMudGltZW91dDtcbiAgICAgICAgY29uc3Qgc3RhdHVzID0ge1xuICAgICAgICAgICAgZXJyb3I6IDEsXG4gICAgICAgICAgICBpdGVyYXRpb25zOiAwLFxuICAgICAgICB9O1xuICAgICAgICB0aGlzLnZlcmlmeUlzSW5pdGlhbGl6ZWQocHJlcGFyZWREYXRhKTtcbiAgICAgICAgY29uc3QgdGV4dHVyaXplT3V0cHV0RGF0YSA9IHRoaXMuZ3B1LmNyZWF0ZUtlcm5lbChmdW5jdGlvbiAodmFsdWUpIHtcbiAgICAgICAgICAgIHJldHVybiB2YWx1ZVt0aGlzLnRocmVhZC54XTtcbiAgICAgICAgfSwge1xuICAgICAgICAgICAgb3V0cHV0OiBbcHJlcGFyZWREYXRhWzBdLm91dHB1dC5sZW5ndGhdLFxuICAgICAgICAgICAgcGlwZWxpbmU6IHRydWUsXG4gICAgICAgICAgICBpbW11dGFibGU6IHRydWUsXG4gICAgICAgIH0pO1xuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgcHJlcGFyZWREYXRhOiBwcmVwYXJlZERhdGEubWFwKChzZXQpID0+ICh7XG4gICAgICAgICAgICAgICAgaW5wdXQ6IHRoaXMudGV4dHVyaXplSW5wdXREYXRhKHNldC5pbnB1dCksXG4gICAgICAgICAgICAgICAgb3V0cHV0OiB0ZXh0dXJpemVPdXRwdXREYXRhKHNldC5vdXRwdXQpLFxuICAgICAgICAgICAgfSkpLFxuICAgICAgICAgICAgc3RhdHVzLFxuICAgICAgICAgICAgZW5kVGltZSxcbiAgICAgICAgfTtcbiAgICB9XG4gICAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIEB0eXBlc2NyaXB0LWVzbGludC9iYW4tdHMtY29tbWVudFxuICAgIC8vIEB0cy1leHBlY3QtZXJyb3JcbiAgICB0b0Z1bmN0aW9uKCkge1xuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoYCR7dGhpcy5jb25zdHJ1Y3Rvci5uYW1lfS10b0Z1bmN0aW9uIGlzIG5vdCB5ZXQgaW1wbGVtZW50ZWRgKTtcbiAgICB9XG4gICAgdG9KU09OKCkge1xuICAgICAgICB2YXIgX2EsIF9iO1xuICAgICAgICBpZiAodGhpcy5zaXplcyA9PT0gbnVsbCkge1xuICAgICAgICAgICAgdGhpcy5pbml0aWFsaXplKCk7XG4gICAgICAgIH1cbiAgICAgICAgLy8gdXNlIEFycmF5LmZyb20sIGtlZXBpbmcganNvbiBzbWFsbFxuICAgICAgICBjb25zdCBqc29uTGF5ZXJXZWlnaHRzID0gdGhpcy53ZWlnaHRzLm1hcCgobGF5ZXJXZWlnaHRzKSA9PiB7XG4gICAgICAgICAgICByZXR1cm4gKGxheWVyV2VpZ2h0cyBpbnN0YW5jZW9mIGdwdV9qcy5UZXh0dXJlXG4gICAgICAgICAgICAgICAgPyBsYXllcldlaWdodHMudG9BcnJheSgpXG4gICAgICAgICAgICAgICAgOiBsYXllcldlaWdodHMpLm1hcCgobGF5ZXJXZWlnaHRzKSA9PiBBcnJheS5mcm9tKGxheWVyV2VpZ2h0cykpO1xuICAgICAgICB9KTtcbiAgICAgICAgY29uc3QganNvbkxheWVyQmlhc2VzID0gdGhpcy5iaWFzZXMubWFwKChsYXllckJpYXNlcykgPT4gQXJyYXkuZnJvbShsYXllckJpYXNlcyBpbnN0YW5jZW9mIGdwdV9qcy5UZXh0dXJlXG4gICAgICAgICAgICA/IGxheWVyQmlhc2VzLnRvQXJyYXkoKVxuICAgICAgICAgICAgOiBsYXllckJpYXNlcykpO1xuICAgICAgICBjb25zdCBqc29uTGF5ZXJzID0gW107XG4gICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDw9IHRoaXMub3V0cHV0TGF5ZXI7IGkrKykge1xuICAgICAgICAgICAganNvbkxheWVycy5wdXNoKHtcbiAgICAgICAgICAgICAgICB3ZWlnaHRzOiAoX2EgPSBqc29uTGF5ZXJXZWlnaHRzW2ldKSAhPT0gbnVsbCAmJiBfYSAhPT0gdm9pZCAwID8gX2EgOiBbXSxcbiAgICAgICAgICAgICAgICBiaWFzZXM6IChfYiA9IGpzb25MYXllckJpYXNlc1tpXSkgIT09IG51bGwgJiYgX2IgIT09IHZvaWQgMCA/IF9iIDogW10sXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgdHlwZTogJ05ldXJhbE5ldHdvcmtHUFUnLFxuICAgICAgICAgICAgc2l6ZXM6IFsuLi50aGlzLnNpemVzXSxcbiAgICAgICAgICAgIGxheWVyczoganNvbkxheWVycyxcbiAgICAgICAgICAgIGlucHV0TG9va3VwOiB0aGlzLmlucHV0TG9va3VwID8geyAuLi50aGlzLmlucHV0TG9va3VwIH0gOiBudWxsLFxuICAgICAgICAgICAgaW5wdXRMb29rdXBMZW5ndGg6IHRoaXMuaW5wdXRMb29rdXBMZW5ndGgsXG4gICAgICAgICAgICBvdXRwdXRMb29rdXA6IHRoaXMub3V0cHV0TG9va3VwID8geyAuLi50aGlzLm91dHB1dExvb2t1cCB9IDogbnVsbCxcbiAgICAgICAgICAgIG91dHB1dExvb2t1cExlbmd0aDogdGhpcy5vdXRwdXRMb29rdXBMZW5ndGgsXG4gICAgICAgICAgICBvcHRpb25zOiB7IC4uLnRoaXMub3B0aW9ucyB9LFxuICAgICAgICAgICAgdHJhaW5PcHRzOiB0aGlzLmdldFRyYWluT3B0c0pTT04oKSxcbiAgICAgICAgfTtcbiAgICB9XG59XG5cbmNsYXNzIFJlY3VycmVudENvbm5lY3Rpb24gZXh0ZW5kcyBJbnRlcm5hbCB7XG4gICAgY29uc3RydWN0b3IoKSB7XG4gICAgICAgIHN1cGVyKC4uLmFyZ3VtZW50cyk7XG4gICAgICAgIHRoaXMuc2V0dGluZ3MgPSB7fTtcbiAgICAgICAgdGhpcy5sYXllciA9IG51bGw7XG4gICAgfVxuICAgIHNldExheWVyKGxheWVyKSB7XG4gICAgICAgIHRoaXMubGF5ZXIgPSBsYXllcjtcbiAgICB9XG4gICAgZ2V0IHdpZHRoKCkge1xuICAgICAgICBpZiAoIXRoaXMubGF5ZXIpXG4gICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ2xheWVyIG5vdCBzZXQnKTtcbiAgICAgICAgcmV0dXJuIHRoaXMubGF5ZXIud2lkdGg7XG4gICAgfVxuICAgIHNldCB3aWR0aCh2YWx1ZSkge1xuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoYCR7dGhpcy5jb25zdHJ1Y3Rvci5uYW1lfS13aWR0aCBpcyBub3QgeWV0IGltcGxlbWVudGVkYCk7XG4gICAgfVxuICAgIGdldCBoZWlnaHQoKSB7XG4gICAgICAgIGlmICghdGhpcy5sYXllcilcbiAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcignbGF5ZXIgbm90IHNldCcpO1xuICAgICAgICByZXR1cm4gdGhpcy5sYXllci5oZWlnaHQ7XG4gICAgfVxuICAgIHNldCBoZWlnaHQodmFsdWUpIHtcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKGAke3RoaXMuY29uc3RydWN0b3IubmFtZX0taGVpZ2h0IGlzIG5vdCB5ZXQgaW1wbGVtZW50ZWRgKTtcbiAgICB9XG4gICAgZ2V0IGRlbHRhcygpIHtcbiAgICAgICAgaWYgKCF0aGlzLmxheWVyKVxuICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdsYXllciBub3Qgc2V0Jyk7XG4gICAgICAgIHJldHVybiB0aGlzLmxheWVyLmRlbHRhcztcbiAgICB9XG4gICAgc2V0IGRlbHRhcyhkZWx0YXMpIHtcbiAgICAgICAgaWYgKCF0aGlzLmxheWVyKVxuICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdsYXllciBub3Qgc2V0Jyk7XG4gICAgICAgIHJlbGVhc2UodGhpcy5sYXllci5kZWx0YXMpO1xuICAgICAgICB0aGlzLmxheWVyLmRlbHRhcyA9IGRlbHRhcztcbiAgICB9XG4gICAgZ2V0IHdlaWdodHMoKSB7XG4gICAgICAgIGlmICghdGhpcy5sYXllcilcbiAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcignbGF5ZXIgbm90IHNldCcpO1xuICAgICAgICByZXR1cm4gdGhpcy5sYXllci53ZWlnaHRzO1xuICAgIH1cbiAgICBzZXQgd2VpZ2h0cyh3ZWlnaHRzKSB7XG4gICAgICAgIGlmICghdGhpcy5sYXllcilcbiAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcignbGF5ZXIgbm90IHNldCcpO1xuICAgICAgICByZWxlYXNlKHRoaXMubGF5ZXIud2VpZ2h0cyk7XG4gICAgICAgIHRoaXMubGF5ZXIud2VpZ2h0cyA9IHdlaWdodHM7XG4gICAgfVxuICAgIHByZWRpY3QoKSB7XG4gICAgICAgIC8vIHRocm93IG5ldyBFcnJvcihgJHt0aGlzLmNvbnN0cnVjdG9yLm5hbWV9LXByZWRpY3QgaXMgbm90IHlldCBpbXBsZW1lbnRlZGApXG4gICAgfVxuICAgIGNvbXBhcmUoKSB7XG4gICAgICAgIC8vIHRocm93IG5ldyBFcnJvcihgJHt0aGlzLmNvbnN0cnVjdG9yLm5hbWV9LWNvbXBhcmUgaXMgbm90IHlldCBpbXBsZW1lbnRlZGApXG4gICAgfVxuICAgIGxlYXJuKCkge1xuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ25vIGxvbmdlciB1c2luZycpO1xuICAgIH1cbiAgICBzZXR1cEtlcm5lbHMoKSB7XG4gICAgICAgIC8vIHRocm93IG5ldyBFcnJvcihcbiAgICAgICAgLy8gICBgJHt0aGlzLmNvbnN0cnVjdG9yLm5hbWV9LXNldHVwS2VybmVscyBpcyBub3QgeWV0IGltcGxlbWVudGVkYFxuICAgICAgICAvLyApXG4gICAgfVxuICAgIHJldXNlS2VybmVscygpIHtcbiAgICAgICAgLy8gdGhyb3cgbmV3IEVycm9yKFxuICAgICAgICAvLyAgIGAke3RoaXMuY29uc3RydWN0b3IubmFtZX0tcmV1c2VLZXJuZWxzIGlzIG5vdCB5ZXQgaW1wbGVtZW50ZWRgXG4gICAgICAgIC8vIClcbiAgICB9XG59XG5cbmNsYXNzIFJlY3VycmVudCBleHRlbmRzIEZlZWRGb3J3YXJkIHtcbiAgICAvLyBUT0RPOiB1c2UgZ2VuZXJpY3MgaW4gZXh0ZW5kXG4gICAgY29uc3RydWN0b3Iob3B0aW9ucyA9IHt9KSB7XG4gICAgICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBAdHlwZXNjcmlwdC1lc2xpbnQvYmFuLXRzLWNvbW1lbnRcbiAgICAgICAgLy8gQHRzLWV4cGVjdC1lcnJvclxuICAgICAgICBzdXBlcihvcHRpb25zKTtcbiAgICAgICAgdGhpcy50cmFpbk9wdHMgPSB7fTtcbiAgICAgICAgdGhpcy5fb3V0cHV0Q29ubmVjdGlvbiA9IG51bGw7XG4gICAgICAgIHRoaXMuX2xheWVyU2V0cyA9IFtdO1xuICAgICAgICB0aGlzLl9oaWRkZW5MYXllck91dHB1dEluZGljZXMgPSBbXTtcbiAgICAgICAgdGhpcy5fbW9kZWwgPSBudWxsO1xuICAgIH1cbiAgICBfY29ubmVjdExheWVycygpIHtcbiAgICAgICAgaWYgKCF0aGlzLm9wdGlvbnMuaW5wdXRMYXllcikge1xuICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdpbnB1dExheWVyIG5vdCBmb3VuZCcpO1xuICAgICAgICB9XG4gICAgICAgIGlmICghdGhpcy5vcHRpb25zLm91dHB1dExheWVyKSB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ291dHB1dExheWVyIG5vdCBmb3VuZCcpO1xuICAgICAgICB9XG4gICAgICAgIGNvbnN0IGlucHV0TGF5ZXIgPSB0aGlzLm9wdGlvbnMuaW5wdXRMYXllcigpO1xuICAgICAgICBjb25zdCBoaWRkZW5MYXllcnMgPSB0aGlzLl9jb25uZWN0SGlkZGVuTGF5ZXJzKGlucHV0TGF5ZXIpO1xuICAgICAgICBjb25zdCBvdXRwdXRMYXllciA9IHRoaXMub3B0aW9ucy5vdXRwdXRMYXllcihoaWRkZW5MYXllcnNbaGlkZGVuTGF5ZXJzLmxlbmd0aCAtIDFdLCAtMSk7XG4gICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICBpbnB1dExheWVyLFxuICAgICAgICAgICAgaGlkZGVuTGF5ZXJzLFxuICAgICAgICAgICAgb3V0cHV0TGF5ZXIsXG4gICAgICAgIH07XG4gICAgfVxuICAgIF9jb25uZWN0TGF5ZXJzRGVlcCgpIHtcbiAgICAgICAgY29uc3QgbGF5ZXJzID0gW107XG4gICAgICAgIGNvbnN0IHByZXZpb3VzTGF5ZXJzID0gdGhpcy5fbGF5ZXJTZXRzW3RoaXMuX2xheWVyU2V0cy5sZW5ndGggLSAxXTtcbiAgICAgICAgbGV0IHVzZWRIaWRkZW5MYXllck91dHB1dEluZGV4ID0gMDtcbiAgICAgICAgZnVuY3Rpb24gZmluZElucHV0TGF5ZXIoaW5wdXRMYXllcikge1xuICAgICAgICAgICAgY29uc3QgaW5kZXggPSBwcmV2aW91c0xheWVycy5pbmRleE9mKGlucHV0TGF5ZXIpO1xuICAgICAgICAgICAgaWYgKGluZGV4IDwgMClcbiAgICAgICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ3VuYWJsZSB0byBmaW5kIGxheWVyJyk7XG4gICAgICAgICAgICByZXR1cm4gbGF5ZXJzW2luZGV4XTtcbiAgICAgICAgfVxuICAgICAgICBmdW5jdGlvbiBsYXllclNldHRpbmdzKGxheWVyKSB7XG4gICAgICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgICAgIC4uLmxheWVyLnNldHRpbmdzLFxuICAgICAgICAgICAgICAgIHdlaWdodHM6IG51bGwsXG4gICAgICAgICAgICAgICAgZGVsdGFzOiBudWxsLFxuICAgICAgICAgICAgICAgIHByYXhpczogbnVsbCxcbiAgICAgICAgICAgIH07XG4gICAgICAgIH1cbiAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBwcmV2aW91c0xheWVycy5sZW5ndGg7IGkrKykge1xuICAgICAgICAgICAgY29uc3QgcHJldmlvdXNMYXllciA9IHByZXZpb3VzTGF5ZXJzW2ldO1xuICAgICAgICAgICAgbGV0IGxheWVyO1xuICAgICAgICAgICAgaWYgKHByZXZpb3VzTGF5ZXIgaW5zdGFuY2VvZiBBY3RpdmF0aW9uKSB7XG4gICAgICAgICAgICAgICAgbGF5ZXIgPSBuZXcgcHJldmlvdXNMYXllci5jb25zdHJ1Y3RvcihmaW5kSW5wdXRMYXllcihwcmV2aW91c0xheWVyLmlucHV0TGF5ZXIpLCBsYXllclNldHRpbmdzKHByZXZpb3VzTGF5ZXIpKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGVsc2UgaWYgKHByZXZpb3VzTGF5ZXIgaW5zdGFuY2VvZiBFbnRyeVBvaW50KSB7XG4gICAgICAgICAgICAgICAgbGF5ZXIgPSBuZXcgcHJldmlvdXNMYXllci5jb25zdHJ1Y3RvcihsYXllclNldHRpbmdzKHByZXZpb3VzTGF5ZXIpKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGVsc2UgaWYgKHByZXZpb3VzTGF5ZXIgaW5zdGFuY2VvZiBGaWx0ZXIpIHtcbiAgICAgICAgICAgICAgICBsYXllciA9IG5ldyBwcmV2aW91c0xheWVyLmNvbnN0cnVjdG9yKGxheWVyU2V0dGluZ3MocHJldmlvdXNMYXllci5pbnB1dExheWVyKSwgZmluZElucHV0TGF5ZXIocHJldmlvdXNMYXllci5pbnB1dExheWVyKSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBlbHNlIGlmIChwcmV2aW91c0xheWVyIGluc3RhbmNlb2YgSW50ZXJuYWwpIHtcbiAgICAgICAgICAgICAgICBjb25zdCBwcmV2aW91c0hpZGRlbkxheWVyT3V0cHV0ID0gcHJldmlvdXNMYXllcnNbdGhpcy5faGlkZGVuTGF5ZXJPdXRwdXRJbmRpY2VzW3VzZWRIaWRkZW5MYXllck91dHB1dEluZGV4KytdXTtcbiAgICAgICAgICAgICAgICBpZiAocHJldmlvdXNMYXllciBpbnN0YW5jZW9mIFJlY3VycmVudENvbm5lY3Rpb24pIHtcbiAgICAgICAgICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKCd1bmZpbmlzaGVkJyk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGVsc2UgaWYgKHByZXZpb3VzTGF5ZXIgaW5zdGFuY2VvZiBSZWN1cnJlbnRJbnB1dCkge1xuICAgICAgICAgICAgICAgICAgICBsYXllciA9IG5ldyBSZWN1cnJlbnRJbnB1dChwcmV2aW91c0hpZGRlbkxheWVyT3V0cHV0KTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgZWxzZSBpZiAocHJldmlvdXNMYXllciBpbnN0YW5jZW9mIFJlY3VycmVudFplcm9zKSB7XG4gICAgICAgICAgICAgICAgICAgIGxheWVyID0gbmV3IFJlY3VycmVudElucHV0KHByZXZpb3VzSGlkZGVuTGF5ZXJPdXRwdXQpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKGBoaWRkZW4gbGF5ZXIgJHtwcmV2aW91c0xheWVyLmNvbnN0cnVjdG9yLm5hbWV9IGV4dGVuZHMgdW5rbm93biBoaWRkZW4gbGF5ZXJgKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBlbHNlIGlmIChwcmV2aW91c0xheWVyIGluc3RhbmNlb2YgSW50ZXJuYWxNb2RlbCB8fFxuICAgICAgICAgICAgICAgIHByZXZpb3VzTGF5ZXIgaW5zdGFuY2VvZiBNb2RlbCkge1xuICAgICAgICAgICAgICAgIGxheWVyID0gcHJldmlvdXNMYXllcjtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGVsc2UgaWYgKHByZXZpb3VzTGF5ZXIgaW5zdGFuY2VvZiBNb2RpZmllcikge1xuICAgICAgICAgICAgICAgIGxheWVyID0gbmV3IHByZXZpb3VzTGF5ZXIuY29uc3RydWN0b3IoZmluZElucHV0TGF5ZXIocHJldmlvdXNMYXllci5pbnB1dExheWVyKSwgbGF5ZXJTZXR0aW5ncyhwcmV2aW91c0xheWVyLmlucHV0TGF5ZXIpKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGVsc2UgaWYgKHByZXZpb3VzTGF5ZXIgaW5zdGFuY2VvZiBPcGVyYXRvcikge1xuICAgICAgICAgICAgICAgIGxheWVyID0gbmV3IHByZXZpb3VzTGF5ZXIuY29uc3RydWN0b3IoZmluZElucHV0TGF5ZXIocHJldmlvdXNMYXllci5pbnB1dExheWVyMSksIGZpbmRJbnB1dExheWVyKHByZXZpb3VzTGF5ZXIuaW5wdXRMYXllcjIpLCBsYXllclNldHRpbmdzKHByZXZpb3VzTGF5ZXIpKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGVsc2UgaWYgKHByZXZpb3VzTGF5ZXIgaW5zdGFuY2VvZiBUYXJnZXQpIHtcbiAgICAgICAgICAgICAgICBsYXllciA9IG5ldyBwcmV2aW91c0xheWVyLmNvbnN0cnVjdG9yKGxheWVyU2V0dGluZ3MocHJldmlvdXNMYXllciksIGZpbmRJbnB1dExheWVyKHByZXZpb3VzTGF5ZXIuaW5wdXRMYXllcikpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKGBoaWRkZW4gbGF5ZXIgJHtwcmV2aW91c0xheWVyLmNvbnN0cnVjdG9yLm5hbWV9IGV4dGVuZHMgdW5rbm93biBoaWRkZW4gbGF5ZXJgKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGxheWVycy5wdXNoKGxheWVyKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gbGF5ZXJzO1xuICAgIH1cbiAgICBfY29ubmVjdEhpZGRlbkxheWVycyhwcmV2aW91c0xheWVyKSB7XG4gICAgICAgIGNvbnN0IGhpZGRlbkxheWVycyA9IFtdO1xuICAgICAgICBpZiAoIXRoaXMub3B0aW9ucy5oaWRkZW5MYXllcnMpXG4gICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ2hpZGRlbkxheWVycyBub3QgZGVmaW5lZCcpO1xuICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IHRoaXMub3B0aW9ucy5oaWRkZW5MYXllcnMubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgICAgIGNvbnN0IHJlY3VycmVudElucHV0ID0gbmV3IFJlY3VycmVudFplcm9zKCk7XG4gICAgICAgICAgICBjb25zdCBoaWRkZW5MYXllciA9IHRoaXMub3B0aW9ucy5oaWRkZW5MYXllcnNbaV0ocHJldmlvdXNMYXllciwgcmVjdXJyZW50SW5wdXQsIGkpO1xuICAgICAgICAgICAgcHJldmlvdXNMYXllciA9IGhpZGRlbkxheWVyO1xuICAgICAgICAgICAgaGlkZGVuTGF5ZXJzLnB1c2goaGlkZGVuTGF5ZXIpO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBoaWRkZW5MYXllcnM7XG4gICAgfVxuICAgIGluaXRpYWxpemUoKSB7XG4gICAgICAgIHRoaXMuX291dHB1dENvbm5lY3Rpb24gPSBuZXcgUmVjdXJyZW50Q29ubmVjdGlvbigpO1xuICAgICAgICBsZXQgbGF5ZXJTZXQ7XG4gICAgICAgIGlmICh0aGlzLm9wdGlvbnMubGF5ZXJzKSB7XG4gICAgICAgICAgICBsYXllclNldCA9IHRoaXMuX2Nvbm5lY3RPcHRpb25zTGF5ZXJzKCk7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICBjb25zdCB7IGlucHV0TGF5ZXIsIGhpZGRlbkxheWVycywgb3V0cHV0TGF5ZXIgfSA9IHRoaXMuX2Nvbm5lY3RMYXllcnMoKTtcbiAgICAgICAgICAgIGxheWVyU2V0ID0gZmxhdHRlbkxheWVycyhbaW5wdXRMYXllciwgLi4uaGlkZGVuTGF5ZXJzLCBvdXRwdXRMYXllcl0pO1xuICAgICAgICAgICAgdGhpcy5faGlkZGVuTGF5ZXJPdXRwdXRJbmRpY2VzID0gaGlkZGVuTGF5ZXJzLm1hcCgobCkgPT4gbGF5ZXJTZXQuaW5kZXhPZihsKSk7XG4gICAgICAgICAgICB0aGlzLl9pbnB1dExheWVyID0gaW5wdXRMYXllcjtcbiAgICAgICAgICAgIHRoaXMuX2hpZGRlbkxheWVycyA9IGhpZGRlbkxheWVycztcbiAgICAgICAgICAgIHRoaXMuX291dHB1dExheWVyID0gb3V0cHV0TGF5ZXI7XG4gICAgICAgIH1cbiAgICAgICAgdGhpcy5sYXllcnMgPSBsYXllclNldDtcbiAgICAgICAgdGhpcy5fbGF5ZXJTZXRzID0gW2xheWVyU2V0XTtcbiAgICAgICAgdGhpcy5fbW9kZWwgPSBsYXllclNldC5maWx0ZXIoKGwpID0+IGwgaW5zdGFuY2VvZiBNb2RlbCB8fCBsIGluc3RhbmNlb2YgSW50ZXJuYWxNb2RlbCk7XG4gICAgICAgIHRoaXMuaW5pdGlhbGl6ZUxheWVycyhsYXllclNldCk7XG4gICAgfVxuICAgIGluaXRpYWxpemVEZWVwKCkge1xuICAgICAgICBjb25zdCBsYXllcnMgPSB0aGlzLl9jb25uZWN0TGF5ZXJzRGVlcCgpO1xuICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IGxheWVycy5sZW5ndGg7IGkrKykge1xuICAgICAgICAgICAgY29uc3QgbGF5ZXIgPSBsYXllcnNbaV07XG4gICAgICAgICAgICBsYXllci5zZXR1cEtlcm5lbHModHJ1ZSk7XG4gICAgICAgICAgICAvLyBUT0RPOiBlbmFibGUgdGhpcz9cbiAgICAgICAgICAgIC8vIGxheWVyLnJldXNlS2VybmVscyh0aGlzLl9sYXllclNldHNbMF1baV0pO1xuICAgICAgICB9XG4gICAgICAgIHRoaXMuX2xheWVyU2V0cy5wdXNoKGxheWVycyk7XG4gICAgfVxuICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBAdHlwZXNjcmlwdC1lc2xpbnQvYmFuLXRzLWNvbW1lbnRcbiAgICAvLyBAdHMtZXhwZWN0LWVycm9yXG4gICAgcnVuKGlucHV0cykge1xuICAgICAgICB3aGlsZSAodGhpcy5fbGF5ZXJTZXRzLmxlbmd0aCA8PSBpbnB1dHMubGVuZ3RoKSB7XG4gICAgICAgICAgICB0aGlzLmluaXRpYWxpemVEZWVwKCk7XG4gICAgICAgIH1cbiAgICAgICAgY29uc3QgcmVzdWx0ID0gdGhpcy5ydW5JbnB1dHMoaW5wdXRzKTtcbiAgICAgICAgaWYgKHJlc3VsdCBpbnN0YW5jZW9mIGdwdV9qcy5UZXh0dXJlKVxuICAgICAgICAgICAgcmV0dXJuIHJlc3VsdC50b0FycmF5KCk7XG4gICAgICAgIHJldHVybiByZXN1bHQ7XG4gICAgfVxuICAgIHJ1bklucHV0KGlucHV0KSB7XG4gICAgICAgIHRocm93IG5ldyBFcnJvcigndXNlIC5ydW5JbnB1dHMoKScpO1xuICAgIH1cbiAgICBydW5JbnB1dHMoaW5wdXRzKSB7XG4gICAgICAgIHdoaWxlICh0aGlzLl9sYXllclNldHMubGVuZ3RoIDwgaW5wdXRzLmxlbmd0aCkge1xuICAgICAgICAgICAgdGhpcy5pbml0aWFsaXplRGVlcCgpO1xuICAgICAgICB9XG4gICAgICAgIGNvbnN0IG1heCA9IGlucHV0cy5sZW5ndGggLSAxOyAvLyBsYXN0IG91dHB1dCB3aWxsIGJlIGNvbXBhcmVkIHdpdGggbGFzdCBpbmRleFxuICAgICAgICBmb3IgKGxldCB4ID0gMDsgeCA8PSBtYXg7IHgrKykge1xuICAgICAgICAgICAgY29uc3QgbGF5ZXJTZXQgPSB0aGlzLl9sYXllclNldHNbeF07XG4gICAgICAgICAgICBsYXllclNldFswXS5wcmVkaWN0KGlucHV0c1t4XSk7XG4gICAgICAgICAgICBmb3IgKGxldCBpID0gMTsgaSA8IGxheWVyU2V0Lmxlbmd0aDsgaSsrKSB7XG4gICAgICAgICAgICAgICAgbGF5ZXJTZXRbaV0ucHJlZGljdCgpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIGNvbnN0IGxhc3RMYXllclVzZWQgPSB0aGlzLl9sYXllclNldHNbbWF4XTtcbiAgICAgICAgY29uc3QgcmVzdWx0ID0gbGFzdExheWVyVXNlZFtsYXN0TGF5ZXJVc2VkLmxlbmd0aCAtIDFdLndlaWdodHM7XG4gICAgICAgIHRoaXMuZW5kKCk7XG4gICAgICAgIHJldHVybiByZXN1bHQ7XG4gICAgfVxuICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBAdHlwZXNjcmlwdC1lc2xpbnQvYmFuLXRzLWNvbW1lbnRcbiAgICAvLyBAdHMtZXhwZWN0LWVycm9yXG4gICAgdHJhaW4oZGF0YSwgb3B0aW9ucyA9IHt9KSB7XG4gICAgICAgIGNvbnN0IHsgcHJlcGFyZWREYXRhLCBzdGF0dXMsIGVuZFRpbWUgfSA9IHRoaXMuX3ByZXBUcmFpbmluZyhkYXRhLCBvcHRpb25zKTtcbiAgICAgICAgbGV0IGNvbnRpbnVlVGlja2luZyA9IHRydWU7XG4gICAgICAgIGNvbnN0IGNhbGN1bGF0ZUVycm9yID0gKCkgPT4gdGhpcy5fY2FsY3VsYXRlVHJhaW5pbmdFcnJvcihwcmVwYXJlZERhdGEpO1xuICAgICAgICBjb25zdCB0cmFpblBhdHRlcnMgPSAoKSA9PiB0aGlzLl90cmFpblBhdHRlcm5zKHByZXBhcmVkRGF0YSk7XG4gICAgICAgIHdoaWxlIChjb250aW51ZVRpY2tpbmcpIHtcbiAgICAgICAgICAgIGNvbnRpbnVlVGlja2luZyA9IHRoaXMuX3RyYWluaW5nVGljayhzdGF0dXMsIGVuZFRpbWUsIGNhbGN1bGF0ZUVycm9yLCB0cmFpblBhdHRlcnMpO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBzdGF0dXM7XG4gICAgfVxuICAgIGVuZCgpIHtcbiAgICAgICAgY29uc3QgeCA9IHRoaXMuX2xheWVyU2V0cy5sZW5ndGggLSAxO1xuICAgICAgICBjb25zdCBsYXN0TGF5ZXJTZXQgPSB0aGlzLl9sYXllclNldHNbeF07XG4gICAgICAgIGxhc3RMYXllclNldFswXS5wcmVkaWN0KFtuZXcgRmxvYXQzMkFycmF5KFswXSldKTtcbiAgICAgICAgZm9yIChsZXQgaSA9IDE7IGkgPCBsYXN0TGF5ZXJTZXQubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgICAgIGxhc3RMYXllclNldFtpXS5wcmVkaWN0KCk7XG4gICAgICAgIH1cbiAgICB9XG4gICAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIEB0eXBlc2NyaXB0LWVzbGludC9iYW4tdHMtY29tbWVudFxuICAgIC8vIEB0cy1leHBlY3QtZXJyb3JcbiAgICB0cmFuc2ZlckRhdGEoZm9ybWF0dGVkRGF0YSkge1xuICAgICAgICByZXR1cm4gZm9ybWF0dGVkRGF0YTtcbiAgICB9XG4gICAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIEB0eXBlc2NyaXB0LWVzbGludC9iYW4tdHMtY29tbWVudFxuICAgIC8vIEB0cy1leHBlY3QtZXJyb3JcbiAgICBfcHJlcFRyYWluaW5nKGRhdGEsIG9wdGlvbnMpIHtcbiAgICAgICAgdGhpcy5fdXBkYXRlVHJhaW5pbmdPcHRpb25zKG9wdGlvbnMpO1xuICAgICAgICBjb25zdCBlbmRUaW1lID0gdGhpcy50cmFpbk9wdHMudGltZW91dFxuICAgICAgICAgICAgPyBEYXRlLm5vdygpICsgdGhpcy50cmFpbk9wdHMudGltZW91dFxuICAgICAgICAgICAgOiAwO1xuICAgICAgICBjb25zdCBzdGF0dXMgPSB7XG4gICAgICAgICAgICBlcnJvcjogMSxcbiAgICAgICAgICAgIGl0ZXJhdGlvbnM6IDAsXG4gICAgICAgIH07XG4gICAgICAgIHRoaXMudmVyaWZ5SXNJbml0aWFsaXplZCgpO1xuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgcHJlcGFyZWREYXRhOiB0aGlzLnRyYW5zZmVyRGF0YShkYXRhKSxcbiAgICAgICAgICAgIHN0YXR1cyxcbiAgICAgICAgICAgIGVuZFRpbWUsXG4gICAgICAgIH07XG4gICAgfVxuICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBAdHlwZXNjcmlwdC1lc2xpbnQvYmFuLXRzLWNvbW1lbnRcbiAgICAvLyBAdHMtZXhwZWN0LWVycm9yXG4gICAgX2NhbGN1bGF0ZVRyYWluaW5nRXJyb3IoZGF0YSkge1xuICAgICAgICBpZiAoIXRoaXMubWVhblNxdWFyZWRFcnJvcikge1xuICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKCd0aGlzLm1lYW5TcXVhcmVkRXJyb3Igbm90IHNldHVwJyk7XG4gICAgICAgIH1cbiAgICAgICAgbGV0IHN1bSA9IG5ldyBGbG9hdDMyQXJyYXkoMSk7XG4gICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgZGF0YS5sZW5ndGg7ICsraSkge1xuICAgICAgICAgICAgY29uc3QgcHJldlN1bSA9IHN1bTtcbiAgICAgICAgICAgIGNvbnN0IGVycm9yID0gdGhpcy5fdHJhaW5QYXR0ZXJuKGRhdGFbaV0sIHRydWUpO1xuICAgICAgICAgICAgc3VtID0gdGhpcy5tZWFuU3F1YXJlZEVycm9yLmFkZChzdW0sIGVycm9yKTtcbiAgICAgICAgICAgIHJlbGVhc2UoZXJyb3IpO1xuICAgICAgICAgICAgcmVsZWFzZShwcmV2U3VtKTtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCByZXN1bHQgPSB0aGlzLm1lYW5TcXVhcmVkRXJyb3IuZGl2aWRlKGRhdGEubGVuZ3RoLCBzdW0pO1xuICAgICAgICByZWxlYXNlKHN1bSk7XG4gICAgICAgIGlmIChyZXN1bHQgaW5zdGFuY2VvZiBncHVfanMuVGV4dHVyZSkge1xuICAgICAgICAgICAgY29uc3QgcmVzdWx0QXJyYXkgPSByZXN1bHQudG9BcnJheSgpO1xuICAgICAgICAgICAgcmV0dXJuIHJlc3VsdEFycmF5WzBdO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiByZXN1bHRbMF07XG4gICAgfVxuICAgIC8vIFRPRE86IG1vcmUgdHlwZXNcbiAgICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgQHR5cGVzY3JpcHQtZXNsaW50L2Jhbi10cy1jb21tZW50XG4gICAgLy8gQHRzLWV4cGVjdC1lcnJvclxuICAgIGZvcm1hdERhdGEoZGF0YSkge1xuICAgICAgICByZXR1cm4gZGF0YTtcbiAgICB9XG4gICAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIEB0eXBlc2NyaXB0LWVzbGludC9iYW4tdHMtY29tbWVudFxuICAgIC8vIEB0cy1leHBlY3QtZXJyb3JcbiAgICBfY2FsY3VsYXRlRGVsdGFzKHRhcmdldCkge1xuICAgICAgICBjb25zdCBsYXN0TGF5ZXJTZXQgPSB0aGlzLl9sYXllclNldHNbdGhpcy5fbGF5ZXJTZXRzLmxlbmd0aCAtIDFdO1xuICAgICAgICAvLyBJdGVyYXRlIGZyb20gdGhlIHNlY29uZCB0byBsYXN0IGxheWVyIGJhY2t3YXJkcywgcHJvcGFnYXRpbmcgMCdzXG4gICAgICAgIGZvciAobGV0IGkgPSBsYXN0TGF5ZXJTZXQubGVuZ3RoIC0gMjsgaSA+PSAwOyBpLS0pIHtcbiAgICAgICAgICAgIGxhc3RMYXllclNldFtpXS5jb21wYXJlKCk7XG4gICAgICAgIH1cbiAgICAgICAgZm9yIChsZXQgeCA9IHRhcmdldC5sZW5ndGggLSAyOyB4ID49IDA7IHgtLSkge1xuICAgICAgICAgICAgY29uc3QgbGF5ZXJTZXQgPSB0aGlzLl9sYXllclNldHNbeF07XG4gICAgICAgICAgICBsYXllclNldFtsYXllclNldC5sZW5ndGggLSAxXS5jb21wYXJlKHRhcmdldFt4ICsgMV0pO1xuICAgICAgICAgICAgZm9yIChsZXQgaSA9IGxheWVyU2V0Lmxlbmd0aCAtIDI7IGkgPj0gMDsgaS0tKSB7XG4gICAgICAgICAgICAgICAgbGF5ZXJTZXRbaV0uY29tcGFyZSgpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfVxuICAgIGFkanVzdFdlaWdodHMoKSB7XG4gICAgICAgIHZhciBfYTtcbiAgICAgICAgY29uc3QgX21vZGVsID0gdGhpcy5fbW9kZWw7XG4gICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgX21vZGVsLmxlbmd0aDsgaSsrKSB7XG4gICAgICAgICAgICBfbW9kZWxbaV0ubGVhcm4oKF9hID0gdGhpcy5vcHRpb25zLmxlYXJuaW5nUmF0ZSkgIT09IG51bGwgJiYgX2EgIT09IHZvaWQgMCA/IF9hIDogMCk7XG4gICAgICAgIH1cbiAgICB9XG4gICAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIEB0eXBlc2NyaXB0LWVzbGludC9iYW4tdHMtY29tbWVudFxuICAgIC8vIEB0cy1leHBlY3QtZXJyb3JcbiAgICBfdHJhaW5QYXR0ZXJucyhkYXRhKSB7XG4gICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgZGF0YS5sZW5ndGg7ICsraSkge1xuICAgICAgICAgICAgdGhpcy5fdHJhaW5QYXR0ZXJuKGRhdGFbaV0sIGZhbHNlKTtcbiAgICAgICAgfVxuICAgIH1cbiAgICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgQHR5cGVzY3JpcHQtZXNsaW50L2Jhbi10cy1jb21tZW50XG4gICAgLy8gQHRzLWV4cGVjdC1lcnJvclxuICAgIF90cmFpblBhdHRlcm4oaW5wdXRzLCBsb2dFcnJvclJhdGUpIHtcbiAgICAgICAgLy8gZm9yd2FyZCBwcm9wYWdhdGVcbiAgICAgICAgdGhpcy5ydW5JbnB1dHMoaW5wdXRzKTtcbiAgICAgICAgLy8gYmFjayBwcm9wYWdhdGVcbiAgICAgICAgdGhpcy5fY2FsY3VsYXRlRGVsdGFzKGlucHV0cyk7XG4gICAgICAgIHRoaXMuYWRqdXN0V2VpZ2h0cygpO1xuICAgICAgICBpZiAobG9nRXJyb3JSYXRlKSB7XG4gICAgICAgICAgICBpZiAoIXRoaXMubWVhblNxdWFyZWRFcnJvcikge1xuICAgICAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcigndGhpcy5tZWFuU3F1YXJlZEVycm9yIG5vdCBzZXR1cCcpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgbGV0IGVycm9yID0gbmV3IEZsb2F0MzJBcnJheSgxKTtcbiAgICAgICAgICAgIGZvciAobGV0IGkgPSAwLCBtYXggPSBpbnB1dHMubGVuZ3RoIC0gMTsgaSA8PSBtYXg7IGkrKykge1xuICAgICAgICAgICAgICAgIGNvbnN0IGxheWVyU2V0ID0gdGhpcy5fbGF5ZXJTZXRzW2ldO1xuICAgICAgICAgICAgICAgIGNvbnN0IGxhc3RMYXllciA9IGxheWVyU2V0W2xheWVyU2V0Lmxlbmd0aCAtIDFdO1xuICAgICAgICAgICAgICAgIGNvbnN0IHByZXZFcnJvciA9IGVycm9yO1xuICAgICAgICAgICAgICAgIGVycm9yID0gdGhpcy5tZWFuU3F1YXJlZEVycm9yLmFkZEFic29sdXRlKHByZXZFcnJvciwgbGFzdExheWVyLmVycm9ycyk7XG4gICAgICAgICAgICAgICAgcmVsZWFzZShwcmV2RXJyb3IpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgcmV0dXJuIGNsb25lKHRoaXMubWVhblNxdWFyZWRFcnJvci5kaXZpZGUoaW5wdXRzLmxlbmd0aCwgZXJyb3IpKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gbnVsbDtcbiAgICB9XG59XG5cbi8qKlxuICogQSBtYXRyaXhcbiAqL1xuY2xhc3MgTWF0cml4IHtcbiAgICBjb25zdHJ1Y3Rvcihyb3dzLCBjb2x1bW5zKSB7XG4gICAgICAgIHRoaXMucm93cyA9IDA7XG4gICAgICAgIHRoaXMuY29sdW1ucyA9IDA7XG4gICAgICAgIGlmIChyb3dzKVxuICAgICAgICAgICAgdGhpcy5yb3dzID0gcm93cztcbiAgICAgICAgaWYgKGNvbHVtbnMpXG4gICAgICAgICAgICB0aGlzLmNvbHVtbnMgPSBjb2x1bW5zO1xuICAgICAgICB0aGlzLndlaWdodHMgPSB6ZXJvcyQxKHRoaXMucm93cyAqIHRoaXMuY29sdW1ucyk7XG4gICAgICAgIHRoaXMuZGVsdGFzID0gemVyb3MkMSh0aGlzLnJvd3MgKiB0aGlzLmNvbHVtbnMpO1xuICAgIH1cbiAgICBnZXRXZWlnaHQocm93LCBjb2wpIHtcbiAgICAgICAgLy8gc2xvdyBidXQgY2FyZWZ1bCBhY2Nlc3NvciBmdW5jdGlvblxuICAgICAgICAvLyB3ZSB3YW50IHJvdy1tYWpvciBvcmRlclxuICAgICAgICBjb25zdCBpeCA9IHRoaXMuY29sdW1ucyAqIHJvdyArIGNvbDtcbiAgICAgICAgaWYgKGl4IDwgMCB8fCBpeCA+PSB0aGlzLndlaWdodHMubGVuZ3RoKSB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ2dldCBhY2Nlc3NvciBpcyBza2V3ZWQnKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gdGhpcy53ZWlnaHRzW2l4XTtcbiAgICB9XG4gICAgc2V0V2VpZ2h0KHJvdywgY29sLCB2KSB7XG4gICAgICAgIC8vIHNsb3cgYnV0IGNhcmVmdWwgYWNjZXNzb3IgZnVuY3Rpb25cbiAgICAgICAgY29uc3QgaXggPSB0aGlzLmNvbHVtbnMgKiByb3cgKyBjb2w7XG4gICAgICAgIGlmIChpeCA8IDAgfHwgaXggPj0gdGhpcy53ZWlnaHRzLmxlbmd0aCkge1xuICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdzZXQgYWNjZXNzb3IgaXMgc2tld2VkJyk7XG4gICAgICAgIH1cbiAgICAgICAgdGhpcy53ZWlnaHRzW2l4XSA9IHY7XG4gICAgICAgIHJldHVybiB0aGlzO1xuICAgIH1cbiAgICBnZXREZWx0YShyb3csIGNvbCkge1xuICAgICAgICAvLyBzbG93IGJ1dCBjYXJlZnVsIGFjY2Vzc29yIGZ1bmN0aW9uXG4gICAgICAgIC8vIHdlIHdhbnQgcm93LW1ham9yIG9yZGVyXG4gICAgICAgIGNvbnN0IGl4ID0gdGhpcy5jb2x1bW5zICogcm93ICsgY29sO1xuICAgICAgICBpZiAoaXggPCAwIHx8IGl4ID49IHRoaXMuZGVsdGFzLmxlbmd0aCkge1xuICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdnZXQgYWNjZXNzb3IgaXMgc2tld2VkJyk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHRoaXMuZGVsdGFzW2l4XTtcbiAgICB9XG4gICAgc2V0RGVsdGEocm93LCBjb2wsIHYpIHtcbiAgICAgICAgLy8gc2xvdyBidXQgY2FyZWZ1bCBhY2Nlc3NvciBmdW5jdGlvblxuICAgICAgICBjb25zdCBpeCA9IHRoaXMuY29sdW1ucyAqIHJvdyArIGNvbDtcbiAgICAgICAgaWYgKGl4IDwgMCB8fCBpeCA+PSB0aGlzLndlaWdodHMubGVuZ3RoKSB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ3NldCBhY2Nlc3NvciBpcyBza2V3ZWQnKTtcbiAgICAgICAgfVxuICAgICAgICB0aGlzLmRlbHRhc1tpeF0gPSB2O1xuICAgICAgICByZXR1cm4gdGhpcztcbiAgICB9XG4gICAgdG9KU09OKCkge1xuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgcm93czogdGhpcy5yb3dzLFxuICAgICAgICAgICAgY29sdW1uczogdGhpcy5jb2x1bW5zLFxuICAgICAgICAgICAgd2VpZ2h0czogQXJyYXkuZnJvbSh0aGlzLndlaWdodHMuc2xpY2UoMCkpLFxuICAgICAgICB9O1xuICAgIH1cbiAgICBzdGF0aWMgZnJvbUpTT04oanNvbikge1xuICAgICAgICBjb25zdCBtYXRyaXggPSBuZXcgTWF0cml4KGpzb24ucm93cywganNvbi5jb2x1bW5zKTtcbiAgICAgICAgZm9yIChsZXQgaSA9IDAsIG1heCA9IGpzb24ucm93cyAqIGpzb24uY29sdW1uczsgaSA8IG1heDsgaSsrKSB7XG4gICAgICAgICAgICBtYXRyaXgud2VpZ2h0c1tpXSA9IGpzb24ud2VpZ2h0c1tpXTsgLy8gY29weSBvdmVyIHdlaWdodHNcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gbWF0cml4O1xuICAgIH1cbiAgICBzdGF0aWMgZnJvbUFycmF5KHdlaWdodHMpIHtcbiAgICAgICAgY29uc3QgbWF0cml4ID0gbmV3IE1hdHJpeCh3ZWlnaHRzLmxlbmd0aCwgd2VpZ2h0c1swXS5sZW5ndGgpO1xuICAgICAgICBtYXRyaXguZnJvbUFycmF5KHdlaWdodHMpO1xuICAgICAgICByZXR1cm4gbWF0cml4O1xuICAgIH1cbiAgICBkZWx0YXNUb0FycmF5KCkge1xuICAgICAgICByZXR1cm4gdGhpcy50b0FycmF5KCdkZWx0YXMnKTtcbiAgICB9XG4gICAgd2VpZ2h0c1RvQXJyYXkoKSB7XG4gICAgICAgIHJldHVybiB0aGlzLnRvQXJyYXkoJ3dlaWdodHMnKTtcbiAgICB9XG4gICAgdG9BcnJheShwcm9wID0gJ3dlaWdodHMnKSB7XG4gICAgICAgIGNvbnN0IHJlc3VsdCA9IG5ldyBBcnJheSh0aGlzLnJvd3MpO1xuICAgICAgICB0aGlzLml0ZXJhdGUoe1xuICAgICAgICAgICAgcm93OiAocm93SW5kZXgpID0+IHtcbiAgICAgICAgICAgICAgICByZXN1bHRbcm93SW5kZXhdID0gbmV3IEFycmF5KHRoaXMuY29sdW1ucyk7XG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgY29sdW1uOiAocm93SW5kZXgsIGNvbHVtbkluZGV4KSA9PiB7XG4gICAgICAgICAgICAgICAgaWYgKHByb3AgPT09ICd3ZWlnaHRzJykge1xuICAgICAgICAgICAgICAgICAgICByZXN1bHRbcm93SW5kZXhdW2NvbHVtbkluZGV4XSA9IHRoaXMuZ2V0V2VpZ2h0KHJvd0luZGV4LCBjb2x1bW5JbmRleCk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGVsc2UgaWYgKHByb3AgPT09ICdkZWx0YXMnKSB7XG4gICAgICAgICAgICAgICAgICAgIHJlc3VsdFtyb3dJbmRleF1bY29sdW1uSW5kZXhdID0gdGhpcy5nZXREZWx0YShyb3dJbmRleCwgY29sdW1uSW5kZXgpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH0sXG4gICAgICAgIH0pO1xuICAgICAgICByZXR1cm4gcmVzdWx0O1xuICAgIH1cbiAgICBmcm9tQXJyYXkoYXJyYXksIHByb3AgPSAnd2VpZ2h0cycpIHtcbiAgICAgICAgaWYgKGFycmF5Lmxlbmd0aCAhPT0gdGhpcy5yb3dzKSB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ3Jvd3MgZG8gbm90IG1hdGNoJyk7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKGFycmF5WzBdLmxlbmd0aCAhPT0gdGhpcy5jb2x1bW5zKSB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ2NvbHVtbnMgZG8gbm90IG1hdGNoJyk7XG4gICAgICAgIH1cbiAgICAgICAgdGhpcy5pdGVyYXRlKHtcbiAgICAgICAgICAgIGNvbHVtbjogKHJvd0luZGV4LCBjb2x1bW5JbmRleCkgPT4ge1xuICAgICAgICAgICAgICAgIGNvbnN0IHZhbHVlID0gYXJyYXlbcm93SW5kZXhdW2NvbHVtbkluZGV4XTtcbiAgICAgICAgICAgICAgICBpZiAodHlwZW9mIHZhbHVlICE9PSAnbnVtYmVyJykge1xuICAgICAgICAgICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ3ZhbHVlIG5vdCBudW1iZXInKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgaWYgKHByb3AgPT09ICd3ZWlnaHRzJykge1xuICAgICAgICAgICAgICAgICAgICB0aGlzLnNldFdlaWdodChyb3dJbmRleCwgY29sdW1uSW5kZXgsIHZhbHVlKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgZWxzZSBpZiAocHJvcCA9PT0gJ2RlbHRhcycpIHtcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5zZXREZWx0YShyb3dJbmRleCwgY29sdW1uSW5kZXgsIHZhbHVlKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9LFxuICAgICAgICB9KTtcbiAgICAgICAgcmV0dXJuIHRoaXM7XG4gICAgfVxuICAgIGl0ZXJhdGUoY2FsbGJhY2tzKSB7XG4gICAgICAgIGNvbnN0IHJvd3MgPSB0aGlzLnJvd3M7XG4gICAgICAgIGNvbnN0IGNvbHVtbnMgPSB0aGlzLmNvbHVtbnM7XG4gICAgICAgIGZvciAobGV0IHJvd0luZGV4ID0gMDsgcm93SW5kZXggPCByb3dzOyByb3dJbmRleCsrKSB7XG4gICAgICAgICAgICBpZiAoY2FsbGJhY2tzLnJvdykge1xuICAgICAgICAgICAgICAgIGNhbGxiYWNrcy5yb3cocm93SW5kZXgpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZm9yIChsZXQgY29sdW1uSW5kZXggPSAwOyBjb2x1bW5JbmRleCA8IGNvbHVtbnM7IGNvbHVtbkluZGV4KyspIHtcbiAgICAgICAgICAgICAgICBpZiAoY2FsbGJhY2tzLmNvbHVtbikge1xuICAgICAgICAgICAgICAgICAgICBjYWxsYmFja3MuY29sdW1uKHJvd0luZGV4LCBjb2x1bW5JbmRleCk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIHJldHVybiB0aGlzO1xuICAgIH1cbn1cblxuLyoqIHJldHVybiBNYXRyaXggYnV0IGZpbGxlZCB3aXRoIHJhbmRvbSBudW1iZXJzIGZyb20gZ2F1c3NpYW5cbiAqL1xuY2xhc3MgUmFuZG9tTWF0cml4IGV4dGVuZHMgTWF0cml4IHtcbiAgICBjb25zdHJ1Y3Rvcihyb3dzLCBjb2x1bW5zLCBzdGQpIHtcbiAgICAgICAgc3VwZXIocm93cywgY29sdW1ucyk7XG4gICAgICAgIHRoaXMuc3RkID0gc3RkO1xuICAgICAgICBmb3IgKGxldCBpID0gMCwgbWF4ID0gdGhpcy53ZWlnaHRzLmxlbmd0aDsgaSA8IG1heDsgaSsrKSB7XG4gICAgICAgICAgICB0aGlzLndlaWdodHNbaV0gPSByYW5kb21GbG9hdCgtc3RkLCBzdGQpO1xuICAgICAgICB9XG4gICAgfVxufVxuXG5jbGFzcyBEYXRhRm9ybWF0dGVyIHtcbiAgICBjb25zdHJ1Y3Rvcih2YWx1ZXMsIG1heFRocmVzaG9sZCA9IDApIHtcbiAgICAgICAgdGhpcy52YWx1ZXMgPSB2YWx1ZXM7XG4gICAgICAgIHRoaXMuaW5kZXhUYWJsZSA9IHt9O1xuICAgICAgICB0aGlzLmNoYXJhY3RlclRhYmxlID0ge307XG4gICAgICAgIHRoaXMuY2hhcmFjdGVycyA9IFtdO1xuICAgICAgICB0aGlzLnNwZWNpYWxJbmRleGVzID0gW107XG4gICAgICAgIHRoaXMuaXNTZXR1cCA9IGZhbHNlO1xuICAgICAgICBpZiAodmFsdWVzID09PSB1bmRlZmluZWQpXG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIHRoaXMuc2V0dXAodmFsdWVzLCBtYXhUaHJlc2hvbGQpO1xuICAgIH1cbiAgICBzZXR1cCh2YWx1ZXMsIG1heFRocmVzaG9sZCA9IDApIHtcbiAgICAgICAgaWYgKHRoaXMuaXNTZXR1cClcbiAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcignRGF0YUZvcm1hdHRlciBpcyBhbHJlYWR5IHNldHVwJyk7XG4gICAgICAgIHRoaXMudmFsdWVzID0gdmFsdWVzO1xuICAgICAgICAvLyBnbyBvdmVyIGFsbCBjaGFyYWN0ZXJzIGFuZCBrZWVwIHRyYWNrIG9mIGFsbCB1bmlxdWUgb25lcyBzZWVuXG4gICAgICAgIC8vIGNvdW50IHVwIGFsbCBjaGFyYWN0ZXJzXG4gICAgICAgIHRoaXMuYnVpbGRDaGFyYWN0ZXJzRnJvbUl0ZXJhYmxlKHZhbHVlcyk7XG4gICAgICAgIHRoaXMuYnVpbGRUYWJsZXMobWF4VGhyZXNob2xkKTtcbiAgICAgICAgaWYgKHZhbHVlc1swXS5pbnB1dCkge1xuICAgICAgICAgICAgdGhpcy5hZGRJbnB1dE91dHB1dCgpO1xuICAgICAgICB9XG4gICAgICAgIHRoaXMuYWRkVW5yZWNvZ25pemVkKCk7XG4gICAgICAgIHRoaXMuaXNTZXR1cCA9IHRydWU7XG4gICAgfVxuICAgIGJ1aWxkQ2hhcmFjdGVyc0Zyb21JdGVyYWJsZSh2YWx1ZXMpIHtcbiAgICAgICAgY29uc3QgdGVtcENoYXJhY3RlcnNUYWJsZSA9IHt9O1xuICAgICAgICBmb3IgKGxldCBkYXRhRm9ybWF0dGVySW5kZXggPSAwLCBkYXRhRm9ybWF0dGVyTGVuZ3RoID0gdmFsdWVzLmxlbmd0aDsgZGF0YUZvcm1hdHRlckluZGV4IDwgZGF0YUZvcm1hdHRlckxlbmd0aDsgZGF0YUZvcm1hdHRlckluZGV4KyspIHtcbiAgICAgICAgICAgIGNvbnN0IGNoYXJhY3RlcnMgPSB2YWx1ZXNbZGF0YUZvcm1hdHRlckluZGV4XTtcbiAgICAgICAgICAgIC8vIGlmICh0eXBlb2YgY2hhcmFjdGVycyA9PT0gJ3N0cmluZycpIHtcbiAgICAgICAgICAgIC8vICAgY29uc3QgY2hhcmFjdGVyID0gY2hhcmFjdGVycztcbiAgICAgICAgICAgIC8vICAgaWYgKHRlbXBDaGFyYWN0ZXJzVGFibGUuaGFzT3duUHJvcGVydHkoY2hhcmFjdGVyKSkgY29udGludWU7XG4gICAgICAgICAgICAvLyAgIHRlbXBDaGFyYWN0ZXJzVGFibGVbY2hhcmFjdGVyXSA9IHRydWU7XG4gICAgICAgICAgICAvLyAgIHRoaXMuY2hhcmFjdGVycy5wdXNoKGNoYXJhY3Rlcik7XG4gICAgICAgICAgICBpZiAoY2hhcmFjdGVycy5oYXNPd25Qcm9wZXJ0eSgnbGVuZ3RoJykpIHtcbiAgICAgICAgICAgICAgICBjb25zdCBpdGVyYXRhYmxlID0gY2hhcmFjdGVycztcbiAgICAgICAgICAgICAgICBmb3IgKGxldCBjaGFyYWN0ZXJJbmRleCA9IDAsIGNoYXJhY3RlcnNMZW5ndGggPSBpdGVyYXRhYmxlLmxlbmd0aDsgY2hhcmFjdGVySW5kZXggPCBjaGFyYWN0ZXJzTGVuZ3RoOyBjaGFyYWN0ZXJJbmRleCsrKSB7XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IGNoYXJhY3RlciA9IGl0ZXJhdGFibGVbY2hhcmFjdGVySW5kZXhdO1xuICAgICAgICAgICAgICAgICAgICBpZiAodGVtcENoYXJhY3RlcnNUYWJsZS5oYXNPd25Qcm9wZXJ0eShjaGFyYWN0ZXIpKVxuICAgICAgICAgICAgICAgICAgICAgICAgY29udGludWU7XG4gICAgICAgICAgICAgICAgICAgIHRlbXBDaGFyYWN0ZXJzVGFibGVbY2hhcmFjdGVyXSA9IHRydWU7XG4gICAgICAgICAgICAgICAgICAgIHRoaXMuY2hhcmFjdGVycy5wdXNoKGNoYXJhY3Rlcik7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZWxzZSBpZiAodHlwZW9mIGNoYXJhY3RlcnMgPT09ICdudW1iZXInKSB7XG4gICAgICAgICAgICAgICAgaWYgKHRlbXBDaGFyYWN0ZXJzVGFibGUuaGFzT3duUHJvcGVydHkoY2hhcmFjdGVycykpXG4gICAgICAgICAgICAgICAgICAgIGNvbnRpbnVlO1xuICAgICAgICAgICAgICAgIHRlbXBDaGFyYWN0ZXJzVGFibGVbY2hhcmFjdGVyc10gPSB0cnVlO1xuICAgICAgICAgICAgICAgIHRoaXMuY2hhcmFjdGVycy5wdXNoKGNoYXJhY3RlcnMpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZWxzZSBpZiAodHlwZW9mIGNoYXJhY3RlcnMgPT09ICdib29sZWFuJykge1xuICAgICAgICAgICAgICAgIGNvbnN0IGNoYXJhY3RlciA9IGNoYXJhY3RlcnMudG9TdHJpbmcoKTtcbiAgICAgICAgICAgICAgICBpZiAodGVtcENoYXJhY3RlcnNUYWJsZS5oYXNPd25Qcm9wZXJ0eShjaGFyYWN0ZXIpKVxuICAgICAgICAgICAgICAgICAgICBjb250aW51ZTtcbiAgICAgICAgICAgICAgICB0ZW1wQ2hhcmFjdGVyc1RhYmxlW2NoYXJhY3Rlcl0gPSB0cnVlO1xuICAgICAgICAgICAgICAgIHRoaXMuY2hhcmFjdGVycy5wdXNoKGNoYXJhY3Rlcik7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBlbHNlIGlmIChBcnJheS5pc0FycmF5KGNoYXJhY3RlcnMpICYmXG4gICAgICAgICAgICAgICAgdHlwZW9mIGNoYXJhY3RlcnNbMF0gPT09ICdzdHJpbmcnKSB7XG4gICAgICAgICAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBjaGFyYWN0ZXJzLmxlbmd0aDsgaSsrKSB7XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IGNoYXJhY3RlciA9IGNoYXJhY3RlcnNbaV07XG4gICAgICAgICAgICAgICAgICAgIGlmICh0ZW1wQ2hhcmFjdGVyc1RhYmxlLmhhc093blByb3BlcnR5KGNoYXJhY3RlcikpXG4gICAgICAgICAgICAgICAgICAgICAgICBjb250aW51ZTtcbiAgICAgICAgICAgICAgICAgICAgdGVtcENoYXJhY3RlcnNUYWJsZVtjaGFyYWN0ZXJdID0gdHJ1ZTtcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5jaGFyYWN0ZXJzLnB1c2goY2hhcmFjdGVyKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBlbHNlIGlmIChBcnJheS5pc0FycmF5KGNoYXJhY3RlcnMpICYmXG4gICAgICAgICAgICAgICAgKHR5cGVvZiBjaGFyYWN0ZXJzWzBdID09PSAnbnVtYmVyJyB8fFxuICAgICAgICAgICAgICAgICAgICB0eXBlb2YgY2hhcmFjdGVyc1swXSA9PT0gJ2Jvb2xlYW4nKSkge1xuICAgICAgICAgICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgY2hhcmFjdGVycy5sZW5ndGg7IGkrKykge1xuICAgICAgICAgICAgICAgICAgICBjb25zdCBjaGFyYWN0ZXIgPSBjaGFyYWN0ZXJzW2ldLnRvU3RyaW5nKCk7XG4gICAgICAgICAgICAgICAgICAgIGlmICh0ZW1wQ2hhcmFjdGVyc1RhYmxlLmhhc093blByb3BlcnR5KGRhdGFGb3JtYXR0ZXJJbmRleCkpXG4gICAgICAgICAgICAgICAgICAgICAgICBjb250aW51ZTtcbiAgICAgICAgICAgICAgICAgICAgdGVtcENoYXJhY3RlcnNUYWJsZVtjaGFyYWN0ZXJdID0gdHJ1ZTtcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5jaGFyYWN0ZXJzLnB1c2goY2hhcmFjdGVyKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBlbHNlIGlmIChjaGFyYWN0ZXJzLmhhc093blByb3BlcnR5KCdpbnB1dCcpICYmXG4gICAgICAgICAgICAgICAgY2hhcmFjdGVycy5oYXNPd25Qcm9wZXJ0eSgnb3V0cHV0JykpIHtcbiAgICAgICAgICAgICAgICBjb25zdCB7IGlucHV0LCBvdXRwdXQgfSA9IGNoYXJhY3RlcnM7XG4gICAgICAgICAgICAgICAgaWYgKEFycmF5LmlzQXJyYXkoaW5wdXQpKSB7XG4gICAgICAgICAgICAgICAgICAgIHRoaXMuYWRkQ2hhcmFjdGVycyhpbnB1dCwgdGVtcENoYXJhY3RlcnNUYWJsZSk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICB0aGlzLmFkZENoYXJhY3RlcnMoaW5wdXQudG9TdHJpbmcoKSwgdGVtcENoYXJhY3RlcnNUYWJsZSk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGlmIChBcnJheS5pc0FycmF5KG91dHB1dCkpIHtcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5hZGRDaGFyYWN0ZXJzKG91dHB1dCwgdGVtcENoYXJhY3RlcnNUYWJsZSk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICB0aGlzLmFkZENoYXJhY3RlcnMob3V0cHV0LnRvU3RyaW5nKCksIHRlbXBDaGFyYWN0ZXJzVGFibGUpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcignVW5oYW5kbGVkIHZhbHVlJyk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9XG4gICAgYWRkQ2hhcmFjdGVycyhjaGFyYWN0ZXJzLCBjaGFyYWN0ZXJzVGFibGUpIHtcbiAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBjaGFyYWN0ZXJzLmxlbmd0aDsgaSsrKSB7XG4gICAgICAgICAgICBjb25zdCBjaGFyYWN0ZXIgPSBjaGFyYWN0ZXJzW2ldLnRvU3RyaW5nKCk7XG4gICAgICAgICAgICBpZiAoY2hhcmFjdGVyc1RhYmxlLmhhc093blByb3BlcnR5KGNoYXJhY3RlcikpXG4gICAgICAgICAgICAgICAgY29udGludWU7XG4gICAgICAgICAgICBjaGFyYWN0ZXJzVGFibGVbY2hhcmFjdGVyXSA9IHRydWU7XG4gICAgICAgICAgICB0aGlzLmNoYXJhY3RlcnMucHVzaChjaGFyYWN0ZXIpO1xuICAgICAgICB9XG4gICAgfVxuICAgIGJ1aWxkVGFibGVzKG1heFRocmVzaG9sZCkge1xuICAgICAgICAvLyBmaWx0ZXIgYnkgY291bnQgdGhyZXNob2xkIGFuZCBjcmVhdGUgcG9pbnRlcnNcbiAgICAgICAgY29uc3QgY2hhcmFjdGVyc0xlbmd0aCA9IHRoaXMuY2hhcmFjdGVycy5sZW5ndGg7XG4gICAgICAgIGZvciAobGV0IGNoYXJhY3RlckluZGV4ID0gMDsgY2hhcmFjdGVySW5kZXggPCBjaGFyYWN0ZXJzTGVuZ3RoOyBjaGFyYWN0ZXJJbmRleCsrKSB7XG4gICAgICAgICAgICBjb25zdCBjaGFyYWN0ZXIgPSB0aGlzLmNoYXJhY3RlcnNbY2hhcmFjdGVySW5kZXhdO1xuICAgICAgICAgICAgaWYgKGNoYXJhY3RlckluZGV4ID49IG1heFRocmVzaG9sZCkge1xuICAgICAgICAgICAgICAgIC8vIGFkZCBjaGFyYWN0ZXIgdG8gZGF0YUZvcm1hdHRlclxuICAgICAgICAgICAgICAgIHRoaXMuaW5kZXhUYWJsZVtjaGFyYWN0ZXJdID0gY2hhcmFjdGVySW5kZXg7XG4gICAgICAgICAgICAgICAgdGhpcy5jaGFyYWN0ZXJUYWJsZVtjaGFyYWN0ZXJJbmRleF0gPSBjaGFyYWN0ZXI7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9XG4gICAgdG9JbmRleGVzKHZhbHVlLCBtYXhUaHJlc2hvbGQgPSAwKSB7XG4gICAgICAgIGNvbnN0IHJlc3VsdCA9IFtdO1xuICAgICAgICBjb25zdCB7IGluZGV4VGFibGUgfSA9IHRoaXM7XG4gICAgICAgIHN3aXRjaCAodHlwZW9mIHZhbHVlKSB7XG4gICAgICAgICAgICBjYXNlICdudW1iZXInOlxuICAgICAgICAgICAgY2FzZSAnYm9vbGVhbic6XG4gICAgICAgICAgICAgICAgdmFsdWUgPSB2YWx1ZS50b1N0cmluZygpO1xuICAgICAgICB9XG4gICAgICAgIGZvciAobGV0IGkgPSAwLCBtYXggPSB2YWx1ZS5sZW5ndGg7IGkgPCBtYXg7IGkrKykge1xuICAgICAgICAgICAgY29uc3QgY2hhcmFjdGVyID0gdmFsdWVbaV0udG9TdHJpbmcoKTtcbiAgICAgICAgICAgIGxldCBpbmRleCA9IGluZGV4VGFibGVbY2hhcmFjdGVyXTtcbiAgICAgICAgICAgIGlmIChpbmRleCA9PT0gdW5kZWZpbmVkKSB7XG4gICAgICAgICAgICAgICAgaWYgKGluZGV4VGFibGUudW5yZWNvZ25pemVkKSB7XG4gICAgICAgICAgICAgICAgICAgIGluZGV4ID0gaW5kZXhUYWJsZS51bnJlY29nbml6ZWQ7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoYHVucmVjb2duaXplZCBjaGFyYWN0ZXIgXCIke2NoYXJhY3Rlcn1cImApO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGlmIChpbmRleCA8IG1heFRocmVzaG9sZClcbiAgICAgICAgICAgICAgICBjb250aW51ZTtcbiAgICAgICAgICAgIHJlc3VsdC5wdXNoKGluZGV4KTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gcmVzdWx0O1xuICAgIH1cbiAgICB0b0luZGV4ZXNJbnB1dE91dHB1dChpbnB1dCwgb3V0cHV0LCBtYXhUaHJlc2hvbGQgPSAwKSB7XG4gICAgICAgIGNvbnN0IHJlc3VsdCA9IHRoaXMudG9JbmRleGVzVmFsdWUoaW5wdXQsIG1heFRocmVzaG9sZCwgdHJ1ZSk7XG4gICAgICAgIGlmICh0eXBlb2Ygb3V0cHV0ID09PSAndW5kZWZpbmVkJylcbiAgICAgICAgICAgIHJldHVybiByZXN1bHQ7XG4gICAgICAgIHJldHVybiByZXN1bHQuY29uY2F0KHRoaXMudG9JbmRleGVzVmFsdWUob3V0cHV0LCBtYXhUaHJlc2hvbGQsIGZhbHNlKSk7XG4gICAgfVxuICAgIHRvSW5kZXhlc1ZhbHVlKHZhbHVlLCBtYXhUaHJlc2hvbGQsIGlzSW5wdXQpIHtcbiAgICAgICAgaWYgKHR5cGVvZiB2YWx1ZSA9PT0gJ3N0cmluZycpIHtcbiAgICAgICAgICAgIHZhbHVlID0gdmFsdWUuc3BsaXQoJycpO1xuICAgICAgICB9XG4gICAgICAgIGVsc2UgaWYgKHR5cGVvZiB2YWx1ZSA9PT0gJ251bWJlcicgfHwgdHlwZW9mIHZhbHVlID09PSAnYm9vbGVhbicpIHtcbiAgICAgICAgICAgIHZhbHVlID0gdmFsdWUudG9TdHJpbmcoKS5zcGxpdCgnJyk7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSBpZiAoQXJyYXkuaXNBcnJheSh2YWx1ZSkgJiZcbiAgICAgICAgICAgICh0eXBlb2YgdmFsdWVbMF0gPT09ICdudW1iZXInIHx8XG4gICAgICAgICAgICAgICAgdHlwZW9mIHZhbHVlWzBdID09PSAnYm9vbGVhbicgfHxcbiAgICAgICAgICAgICAgICB0eXBlb2YgdmFsdWVbMF0gPT09ICdzdHJpbmcnKSkge1xuICAgICAgICAgICAgdmFsdWUgPSB2YWx1ZS5tYXAoKHYpID0+IHYudG9TdHJpbmcoKSk7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ3VucmVjb2duaXplZCB2YWx1ZScpO1xuICAgICAgICB9XG4gICAgICAgIGlmIChpc0lucHV0KSB7XG4gICAgICAgICAgICB2YWx1ZSA9IHZhbHVlLmNvbmNhdChbJ3N0b3AtaW5wdXQnLCAnc3RhcnQtb3V0cHV0J10pO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiB0aGlzLnRvSW5kZXhlcyh2YWx1ZSwgbWF4VGhyZXNob2xkKTtcbiAgICB9XG4gICAgdG9DaGFyYWN0ZXJzKGluZGljZXMsIG1heFRocmVzaG9sZCA9IDApIHtcbiAgICAgICAgY29uc3QgcmVzdWx0ID0gW107XG4gICAgICAgIGNvbnN0IHsgaW5kZXhUYWJsZSwgY2hhcmFjdGVyVGFibGUgfSA9IHRoaXM7XG4gICAgICAgIGZvciAobGV0IGkgPSAwLCBtYXggPSBpbmRpY2VzLmxlbmd0aDsgaSA8IG1heDsgaSsrKSB7XG4gICAgICAgICAgICBjb25zdCBpbmRleCA9IGluZGljZXNbaV07XG4gICAgICAgICAgICBpZiAoaW5kZXggPCBtYXhUaHJlc2hvbGQpXG4gICAgICAgICAgICAgICAgY29udGludWU7XG4gICAgICAgICAgICBsZXQgY2hhcmFjdGVyID0gY2hhcmFjdGVyVGFibGVbaW5kZXhdO1xuICAgICAgICAgICAgaWYgKGNoYXJhY3RlciA9PT0gdW5kZWZpbmVkKSB7XG4gICAgICAgICAgICAgICAgaWYgKGluZGV4VGFibGUudW5yZWNvZ25pemVkKSB7XG4gICAgICAgICAgICAgICAgICAgIGNoYXJhY3RlciA9IGNoYXJhY3RlclRhYmxlW2luZGV4VGFibGUudW5yZWNvZ25pemVkXTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcihgdW5yZWNvZ25pemVkIGluZGV4IFwiJHtpbmRleH1cImApO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGVsc2UgaWYgKGNoYXJhY3RlciAhPT0gbnVsbCkge1xuICAgICAgICAgICAgICAgIHJlc3VsdC5wdXNoKGNoYXJhY3Rlci50b1N0cmluZygpKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gcmVzdWx0O1xuICAgIH1cbiAgICB0b1N0cmluZyhpbmRpY2VzLCBtYXhUaHJlc2hvbGQpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMudG9DaGFyYWN0ZXJzKGluZGljZXMsIG1heFRocmVzaG9sZCkuam9pbignJyk7XG4gICAgfVxuICAgIGFkZElucHV0T3V0cHV0KCkge1xuICAgICAgICB0aGlzLmFkZFNwZWNpYWwoJ3N0b3AtaW5wdXQnKTtcbiAgICAgICAgdGhpcy5hZGRTcGVjaWFsKCdzdGFydC1vdXRwdXQnKTtcbiAgICB9XG4gICAgYWRkVW5yZWNvZ25pemVkKCkge1xuICAgICAgICB0aGlzLmFkZFNwZWNpYWwoJ3VucmVjb2duaXplZCcpO1xuICAgIH1cbiAgICBzdGF0aWMgZnJvbUFsbFByaW50YWJsZShtYXhUaHJlc2hvbGQsIHZhbHVlcyA9IFsnXFxuJ10pIHtcbiAgICAgICAgZm9yIChsZXQgaSA9IDMyOyBpIDw9IDEyNjsgaSsrKSB7XG4gICAgICAgICAgICB2YWx1ZXMucHVzaChTdHJpbmcuZnJvbUNoYXJDb2RlKGkpKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gbmV3IERhdGFGb3JtYXR0ZXIodmFsdWVzLCBtYXhUaHJlc2hvbGQpO1xuICAgIH1cbiAgICBzdGF0aWMgZnJvbUFsbFByaW50YWJsZUlucHV0T3V0cHV0KG1heFRocmVzaG9sZCwgdmFsdWVzID0gWydcXG4nXSkge1xuICAgICAgICBjb25zdCBkYXRhRm9ybWF0dGVyID0gRGF0YUZvcm1hdHRlci5mcm9tQWxsUHJpbnRhYmxlKG1heFRocmVzaG9sZCwgdmFsdWVzKTtcbiAgICAgICAgZGF0YUZvcm1hdHRlci5hZGRJbnB1dE91dHB1dCgpO1xuICAgICAgICBkYXRhRm9ybWF0dGVyLmFkZFVucmVjb2duaXplZCgpO1xuICAgICAgICByZXR1cm4gZGF0YUZvcm1hdHRlcjtcbiAgICB9XG4gICAgc3RhdGljIGZyb21TdHJpbmdJbnB1dE91dHB1dChzdHJpbmcsIG1heFRocmVzaG9sZCkge1xuICAgICAgICBjb25zdCB2YWx1ZXMgPSBBcnJheS5mcm9tKG5ldyBTZXQoc3RyaW5nKSkuam9pbignJyk7XG4gICAgICAgIGNvbnN0IGRhdGFGb3JtYXR0ZXIgPSBuZXcgRGF0YUZvcm1hdHRlcih2YWx1ZXMuc3BsaXQoJycpLCBtYXhUaHJlc2hvbGQpO1xuICAgICAgICBkYXRhRm9ybWF0dGVyLmFkZElucHV0T3V0cHV0KCk7XG4gICAgICAgIGRhdGFGb3JtYXR0ZXIuYWRkVW5yZWNvZ25pemVkKCk7XG4gICAgICAgIGRhdGFGb3JtYXR0ZXIuaXNTZXR1cCA9IHRydWU7XG4gICAgICAgIHJldHVybiBkYXRhRm9ybWF0dGVyO1xuICAgIH1cbiAgICBzdGF0aWMgZnJvbUFycmF5SW5wdXRPdXRwdXQoZGF0YSwgbWF4VGhyZXNob2xkKSB7XG4gICAgICAgIGNvbnN0IHZhbHVlcyA9IFtdO1xuICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IGRhdGEubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgICAgIGNvbnN0IGRhdHVtID0gZGF0YVtpXTtcbiAgICAgICAgICAgIHZhbHVlcy5wdXNoKHZhbGlkYXRlQW5kQ2FzdChkYXR1bS5pbnB1dCksIHZhbGlkYXRlQW5kQ2FzdChkYXR1bS5vdXRwdXQpKTtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCBmbGF0QXJyYXkgPSBBcnJheS5pc0FycmF5KHZhbHVlcylcbiAgICAgICAgICAgID8gdmFsdWVzLmZsYXQoKVxuICAgICAgICAgICAgOiB2YWx1ZXM7XG4gICAgICAgIGNvbnN0IGRhdGFGb3JtYXR0ZXIgPSBuZXcgRGF0YUZvcm1hdHRlcihBcnJheS5mcm9tKG5ldyBTZXQoZmxhdEFycmF5KSksIG1heFRocmVzaG9sZCk7XG4gICAgICAgIGRhdGFGb3JtYXR0ZXIuYWRkSW5wdXRPdXRwdXQoKTtcbiAgICAgICAgZGF0YUZvcm1hdHRlci5hZGRVbnJlY29nbml6ZWQoKTtcbiAgICAgICAgZGF0YUZvcm1hdHRlci5pc1NldHVwID0gdHJ1ZTtcbiAgICAgICAgcmV0dXJuIGRhdGFGb3JtYXR0ZXI7XG4gICAgfVxuICAgIHN0YXRpYyBmcm9tU3RyaW5nKHN0cmluZywgbWF4VGhyZXNob2xkID0gMCkge1xuICAgICAgICBjb25zdCB2YWx1ZXMgPSBBcnJheS5mcm9tKG5ldyBTZXQoc3RyaW5nKSkuam9pbignJyk7XG4gICAgICAgIHJldHVybiBuZXcgRGF0YUZvcm1hdHRlcih2YWx1ZXMuc3BsaXQoJycpLCBtYXhUaHJlc2hvbGQpO1xuICAgIH1cbiAgICB0b0pTT04oKSB7XG4gICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICBpbmRleFRhYmxlOiB0aGlzLmluZGV4VGFibGUsXG4gICAgICAgICAgICBjaGFyYWN0ZXJUYWJsZTogdGhpcy5jaGFyYWN0ZXJUYWJsZSxcbiAgICAgICAgICAgIHZhbHVlczogdGhpcy52YWx1ZXMsXG4gICAgICAgICAgICBjaGFyYWN0ZXJzOiB0aGlzLmNoYXJhY3RlcnMsXG4gICAgICAgICAgICBzcGVjaWFsSW5kZXhlczogdGhpcy5zcGVjaWFsSW5kZXhlcyxcbiAgICAgICAgfTtcbiAgICB9XG4gICAgLyoqIFRPRE86IFR5cGUgYmV0dGVyLCBUaGUgdHlwZSBvZiBqc29uIGlzIG5vdCBcInN0cmluZyB0aGF0IGlzIGEgdmFsaWQgSlNPTlwiLCBpdCBpcyBhIFBPSk8gaW4gdGhlIHNoYXBlIG9mIERhdGFGb3JtYXR0ZXIuXG4gICAgICogdGhpcyBtZXRob2QgcmUtaHlkcmF0ZXMgdGhlIHRoZSBkYXRhIGFzIGFuIGluc3RhbmNlIG9mIERhdGFGb3JtYXR0ZXIuXG4gICAgICovXG4gICAgc3RhdGljIGZyb21KU09OKGpzb24pIHtcbiAgICAgICAgY29uc3QgZGF0YUZvcm1hdHRlciA9IG5ldyBEYXRhRm9ybWF0dGVyKCk7XG4gICAgICAgIGRhdGFGb3JtYXR0ZXIuaW5kZXhUYWJsZSA9IGpzb24uaW5kZXhUYWJsZTtcbiAgICAgICAgZGF0YUZvcm1hdHRlci5jaGFyYWN0ZXJUYWJsZSA9IGpzb24uY2hhcmFjdGVyVGFibGU7XG4gICAgICAgIGRhdGFGb3JtYXR0ZXIudmFsdWVzID0ganNvbi52YWx1ZXM7XG4gICAgICAgIGRhdGFGb3JtYXR0ZXIuY2hhcmFjdGVycyA9IGpzb24uY2hhcmFjdGVycztcbiAgICAgICAgZGF0YUZvcm1hdHRlci5zcGVjaWFsSW5kZXhlcyA9IGpzb24uc3BlY2lhbEluZGV4ZXM7XG4gICAgICAgIHJldHVybiBkYXRhRm9ybWF0dGVyO1xuICAgIH1cbiAgICBhZGRTcGVjaWFsKHNwZWNpYWwsIGNoYXJhY3RlciA9IG51bGwpIHtcbiAgICAgICAgY29uc3Qgc3BlY2lhbEluZGV4ID0gKHRoaXMuaW5kZXhUYWJsZVtzcGVjaWFsXSA9IHRoaXMuY2hhcmFjdGVycy5sZW5ndGgpO1xuICAgICAgICB0aGlzLmNoYXJhY3RlclRhYmxlW3NwZWNpYWxJbmRleF0gPSBjaGFyYWN0ZXI7XG4gICAgICAgIHRoaXMuc3BlY2lhbEluZGV4ZXMucHVzaCh0aGlzLmNoYXJhY3RlcnMubGVuZ3RoKTtcbiAgICAgICAgdGhpcy5jaGFyYWN0ZXJzLnB1c2goc3BlY2lhbCk7XG4gICAgfVxuICAgIHRvRnVuY3Rpb25TdHJpbmcoKSB7XG4gICAgICAgIHJldHVybiBgXG52YXIgY2hhcmFjdGVyVGFibGUgPSAke0pTT04uc3RyaW5naWZ5KHRoaXMuY2hhcmFjdGVyVGFibGUpfTtcbnZhciBpbmRleFRhYmxlID0gJHtKU09OLnN0cmluZ2lmeSh0aGlzLmluZGV4VGFibGUpfTtcbnZhciBjaGFyYWN0ZXJzID0gJHtKU09OLnN0cmluZ2lmeSh0aGlzLmNoYXJhY3RlcnMpfTtcbnZhciBkYXRhRm9ybWF0dGVyID0ge1xuICB0b0luZGV4ZXM6IGZ1bmN0aW9uICR7dGhpcy50b0luZGV4ZXMudG9TdHJpbmcoKX0sXG4gIHRvSW5kZXhlc0lucHV0T3V0cHV0OiBmdW5jdGlvbiAke3RoaXMudG9JbmRleGVzSW5wdXRPdXRwdXQudG9TdHJpbmcoKX0sXG4gIHRvQ2hhcmFjdGVyczogZnVuY3Rpb24gJHt0aGlzLnRvQ2hhcmFjdGVycy50b1N0cmluZygpfSxcbiAgdG9JbmRleGVzVmFsdWU6IGZ1bmN0aW9uICR7dGhpcy50b0luZGV4ZXNWYWx1ZS50b1N0cmluZygpfSxcbn07YDtcbiAgICB9XG4gICAgZm9ybWF0RGF0YUluKGlucHV0LCBvdXRwdXQpIHtcbiAgICAgICAgdmFyIF9hO1xuICAgICAgICBpZiAoaW5wdXQgPT09IHVuZGVmaW5lZClcbiAgICAgICAgICAgIHJldHVybiBbXTtcbiAgICAgICAgaWYgKEFycmF5LmlzQXJyYXkoaW5wdXQpICYmIHR5cGVvZiBpbnB1dFswXSA9PT0gJ251bWJlcicpIHtcbiAgICAgICAgICAgIHJldHVybiBpbnB1dDtcbiAgICAgICAgfVxuICAgICAgICBpZiAoKF9hID0gdGhpcy5pbmRleFRhYmxlKSA9PT0gbnVsbCB8fCBfYSA9PT0gdm9pZCAwID8gdm9pZCAwIDogX2EuaGFzT3duUHJvcGVydHkoJ3N0b3AtaW5wdXQnKSkge1xuICAgICAgICAgICAgcmV0dXJuIHRoaXMudG9JbmRleGVzSW5wdXRPdXRwdXQoaW5wdXQsIG91dHB1dCk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHRoaXMudG9JbmRleGVzKGlucHV0KTtcbiAgICB9XG4gICAgZm9ybWF0RGF0YU91dChpbnB1dCwgb3V0cHV0KSB7XG4gICAgICAgIHJldHVybiB0aGlzLnRvQ2hhcmFjdGVycyhvdXRwdXQpLmpvaW4oJycpO1xuICAgIH1cbiAgICBmb3JtYXQoZGF0YSkge1xuICAgICAgICBpZiAodHlwZW9mIGRhdGFbMF0gPT09ICdudW1iZXInICYmXG4gICAgICAgICAgICAhQXJyYXkuaXNBcnJheShkYXRhWzBdKSAmJlxuICAgICAgICAgICAgKCFkYXRhWzBdLmhhc093blByb3BlcnR5KCdpbnB1dCcpIHx8ICFkYXRhWzBdLmhhc093blByb3BlcnR5KCdvdXRwdXQnKSkpIHtcbiAgICAgICAgICAgIHJldHVybiBkYXRhO1xuICAgICAgICB9XG4gICAgICAgIGNvbnN0IHJlc3VsdCA9IFtdO1xuICAgICAgICBpZiAodHlwZW9mIGRhdGFbMF0gPT09ICdzdHJpbmcnIHx8XG4gICAgICAgICAgICB0eXBlb2YgZGF0YVswXSA9PT0gJ251bWJlcicgfHxcbiAgICAgICAgICAgIEFycmF5LmlzQXJyYXkoZGF0YVswXSkpIHtcbiAgICAgICAgICAgIGlmICghdGhpcy5pc1NldHVwKSB7XG4gICAgICAgICAgICAgICAgdGhpcy5zZXR1cChkYXRhKTtcbiAgICAgICAgICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IGRhdGEubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgICAgICAgICAgICAgcmVzdWx0LnB1c2godGhpcy5mb3JtYXREYXRhSW4odmFsaWRhdGVBbmRDYXN0KGRhdGFbaV0pKSk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgICAgZm9yIChsZXQgaSA9IDAsIG1heCA9IGRhdGEubGVuZ3RoOyBpIDwgbWF4OyBpKyspIHtcbiAgICAgICAgICAgICAgICAgICAgcmVzdWx0LnB1c2godGhpcy5mb3JtYXREYXRhSW4oZGF0YVtpXSkpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBlbHNlIGlmIChkYXRhWzBdLmlucHV0ICYmIGRhdGFbMF0ub3V0cHV0KSB7XG4gICAgICAgICAgICBpZiAoIXRoaXMuaXNTZXR1cCkge1xuICAgICAgICAgICAgICAgIHRoaXMuc2V0dXAoZGF0YSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBmb3IgKGxldCBpID0gMCwgbWF4ID0gZGF0YS5sZW5ndGg7IGkgPCBtYXg7IGkrKykge1xuICAgICAgICAgICAgICAgIHJlc3VsdC5wdXNoKHRoaXMuZm9ybWF0RGF0YUluKHZhbGlkYXRlQW5kQ2FzdChkYXRhW2ldLmlucHV0KSwgdmFsaWRhdGVBbmRDYXN0KGRhdGFbaV0ub3V0cHV0KSkpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKCd1bnJlY29nbml6ZWQgZGF0YScpO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiByZXN1bHQ7XG4gICAgfVxufVxuZnVuY3Rpb24gdmFsaWRhdGVBbmRDYXN0KHZhbHVlKSB7XG4gICAgaWYgKHR5cGVvZiB2YWx1ZSA9PT0gJ3N0cmluZycpXG4gICAgICAgIHJldHVybiB2YWx1ZTtcbiAgICBpZiAodHlwZW9mIHZhbHVlID09PSAnbnVtYmVyJylcbiAgICAgICAgcmV0dXJuIHZhbHVlLnRvU3RyaW5nKCk7XG4gICAgaWYgKHR5cGVvZiB2YWx1ZSA9PT0gJ2Jvb2xlYW4nKVxuICAgICAgICByZXR1cm4gdmFsdWUudG9TdHJpbmcoKTtcbiAgICBpZiAoQXJyYXkuaXNBcnJheSh2YWx1ZSkgJiYgdHlwZW9mIHZhbHVlWzBdID09PSAnc3RyaW5nJylcbiAgICAgICAgcmV0dXJuIHZhbHVlO1xuICAgIGlmICh0eXBlb2YgdmFsdWVbMF0gPT09ICdib29sZWFuJykge1xuICAgICAgICByZXR1cm4gdmFsdWUubWFwKCh2KSA9PiB2LnRvU3RyaW5nKCkpO1xuICAgIH1cbiAgICBpZiAodHlwZW9mIHZhbHVlWzBdID09PSAnbnVtYmVyJykge1xuICAgICAgICByZXR1cm4gdmFsdWUubWFwKCh2KSA9PiB2LnRvU3RyaW5nKCkpO1xuICAgIH1cbiAgICB0aHJvdyBuZXcgRXJyb3IoJ3VucmVjb2duaXplZCB2YWx1ZSwgZXhwZWN0ZWQgc3RyaW5nW10sIHN0cmluZywgbnVtYmVyW10sIG51bWJlciwgYm9vbGVhbltdLCBvciBib29sZWFuJyk7XG59XG5cbmZ1bmN0aW9uIGNvcHkocHJvZHVjdCwgbGVmdCkge1xuICAgIHByb2R1Y3Qucm93cyA9IGxlZnQucm93cztcbiAgICBwcm9kdWN0LmNvbHVtbnMgPSBsZWZ0LmNvbHVtbnM7XG4gICAgcHJvZHVjdC53ZWlnaHRzID0gbGVmdC53ZWlnaHRzLnNsaWNlKDApO1xuICAgIHByb2R1Y3QuZGVsdGFzID0gbGVmdC5kZWx0YXMuc2xpY2UoMCk7XG59XG5cbi8qKlxuICogYWRkIHtsZWZ0fSBhbmQge3JpZ2h0fSBtYXRyaXggd2VpZ2h0cyBpbnRvIHtpbnRvfVxuICovXG5mdW5jdGlvbiBhZGQocHJvZHVjdCwgbGVmdCwgcmlnaHQpIHtcbiAgICBmb3IgKGxldCBpID0gMDsgaSA8IGxlZnQud2VpZ2h0cy5sZW5ndGg7IGkrKykge1xuICAgICAgICBwcm9kdWN0LndlaWdodHNbaV0gPSBsZWZ0LndlaWdodHNbaV0gKyByaWdodC53ZWlnaHRzW2ldO1xuICAgICAgICBwcm9kdWN0LmRlbHRhc1tpXSA9IDA7XG4gICAgfVxufVxuXG4vKipcbiAqIGFkZHMge2Zyb219IGRlbHRhcyB0byB7bGVmdH0gYW5kIHtyaWdodH0gZGVsdGFzXG4gKi9cbmZ1bmN0aW9uIGFkZEIocHJvZHVjdCwgbGVmdCwgcmlnaHQpIHtcbiAgICBmb3IgKGxldCBpID0gMDsgaSA8IHByb2R1Y3QuZGVsdGFzLmxlbmd0aDsgaSsrKSB7XG4gICAgICAgIGxlZnQuZGVsdGFzW2ldID0gcHJvZHVjdC5kZWx0YXNbaV07XG4gICAgICAgIHJpZ2h0LmRlbHRhc1tpXSA9IHByb2R1Y3QuZGVsdGFzW2ldO1xuICAgIH1cbn1cblxuLyoqXG4gKiBtYWtlcyBtYXRyaXggd2VpZ2h0cyBhbmQgZGVsdGFzIGFsbCBvbmVzXG4gKi9cbmZ1bmN0aW9uIGFsbE9uZXMocHJvZHVjdCkge1xuICAgIGZvciAobGV0IGkgPSAwOyBpIDwgcHJvZHVjdC53ZWlnaHRzLmxlbmd0aDsgaSsrKSB7XG4gICAgICAgIHByb2R1Y3Qud2VpZ2h0c1tpXSA9IDE7XG4gICAgICAgIHByb2R1Y3QuZGVsdGFzW2ldID0gMDtcbiAgICB9XG59XG5cbmZ1bmN0aW9uIGNsb25lTmVnYXRpdmUocHJvZHVjdCwgbGVmdCkge1xuICAgIHByb2R1Y3Qucm93cyA9IGxlZnQucm93cztcbiAgICBwcm9kdWN0LmNvbHVtbnMgPSBsZWZ0LmNvbHVtbnM7XG4gICAgcHJvZHVjdC53ZWlnaHRzID0gbGVmdC53ZWlnaHRzLnNsaWNlKDApO1xuICAgIHByb2R1Y3QuZGVsdGFzID0gbGVmdC5kZWx0YXMuc2xpY2UoMCk7XG4gICAgZm9yIChsZXQgaSA9IDA7IGkgPCBsZWZ0LndlaWdodHMubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgcHJvZHVjdC53ZWlnaHRzW2ldID0gLWxlZnQud2VpZ2h0c1tpXTtcbiAgICAgICAgcHJvZHVjdC5kZWx0YXNbaV0gPSAwO1xuICAgIH1cbn1cblxuLyoqXG4gKiBtdWx0aXBseSB7bGVmdH0gYW5kIHtyaWdodH0gbWF0cml4IHdlaWdodHMgdG8ge2ludG99XG4gKi9cbmZ1bmN0aW9uIG11bHRpcGx5KHByb2R1Y3QsIGxlZnQsIHJpZ2h0KSB7XG4gICAgY29uc3QgbGVmdFJvd3MgPSBsZWZ0LnJvd3M7XG4gICAgY29uc3QgbGVmdENvbHVtbnMgPSBsZWZ0LmNvbHVtbnM7XG4gICAgY29uc3QgcmlnaHRDb2x1bW5zID0gcmlnaHQuY29sdW1ucztcbiAgICAvLyBsb29wIG92ZXIgcm93cyBvZiBsZWZ0XG4gICAgZm9yIChsZXQgbGVmdFJvdyA9IDA7IGxlZnRSb3cgPCBsZWZ0Um93czsgbGVmdFJvdysrKSB7XG4gICAgICAgIGNvbnN0IGxlZnRSb3dCYXNlID0gbGVmdENvbHVtbnMgKiBsZWZ0Um93O1xuICAgICAgICBjb25zdCByaWdodFJvd0Jhc2UgPSByaWdodENvbHVtbnMgKiBsZWZ0Um93O1xuICAgICAgICAvLyBsb29wIG92ZXIgY29scyBvZiByaWdodFxuICAgICAgICBmb3IgKGxldCByaWdodENvbHVtbiA9IDA7IHJpZ2h0Q29sdW1uIDwgcmlnaHRDb2x1bW5zOyByaWdodENvbHVtbisrKSB7XG4gICAgICAgICAgICAvLyBkb3QgcHJvZHVjdCBsb29wXG4gICAgICAgICAgICBsZXQgZG90ID0gMDtcbiAgICAgICAgICAgIC8vIGxvb3Agb3ZlciBjb2x1bW5zIG9mIGxlZnRcbiAgICAgICAgICAgIGZvciAobGV0IGxlZnRDb2x1bW4gPSAwOyBsZWZ0Q29sdW1uIDwgbGVmdENvbHVtbnM7IGxlZnRDb2x1bW4rKykge1xuICAgICAgICAgICAgICAgIGNvbnN0IHJpZ2h0Q29sdW1uQmFzZSA9IHJpZ2h0Q29sdW1ucyAqIGxlZnRDb2x1bW47XG4gICAgICAgICAgICAgICAgY29uc3QgbGVmdEluZGV4ID0gbGVmdFJvd0Jhc2UgKyBsZWZ0Q29sdW1uO1xuICAgICAgICAgICAgICAgIGNvbnN0IHJpZ2h0SW5kZXggPSByaWdodENvbHVtbkJhc2UgKyByaWdodENvbHVtbjtcbiAgICAgICAgICAgICAgICBkb3QgKz0gbGVmdC53ZWlnaHRzW2xlZnRJbmRleF0gKiByaWdodC53ZWlnaHRzW3JpZ2h0SW5kZXhdO1xuICAgICAgICAgICAgICAgIGxlZnQuZGVsdGFzW2xlZnRJbmRleF0gPSAwO1xuICAgICAgICAgICAgICAgIHJpZ2h0LmRlbHRhc1tyaWdodEluZGV4XSA9IDA7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBwcm9kdWN0LndlaWdodHNbcmlnaHRSb3dCYXNlICsgcmlnaHRDb2x1bW5dID0gZG90O1xuICAgICAgICB9XG4gICAgfVxufVxuXG4vKipcbiAqIG11bHRpcGxpZXMge2Zyb219IGRlbHRhcyB0byB7bGVmdH0gYW5kIHtyaWdodH1cbiAqL1xuZnVuY3Rpb24gbXVsdGlwbHlCKHByb2R1Y3QsIGxlZnQsIHJpZ2h0KSB7XG4gICAgY29uc3QgbGVmdFJvd3MgPSBsZWZ0LnJvd3M7XG4gICAgY29uc3QgbGVmdENvbHVtbnMgPSBsZWZ0LmNvbHVtbnM7XG4gICAgY29uc3QgcmlnaHRDb2x1bW5zID0gcmlnaHQuY29sdW1ucztcbiAgICAvLyBsb29wIG92ZXIgcm93cyBvZiBsZWZ0XG4gICAgZm9yIChsZXQgbGVmdFJvd1Jvb3QgPSAwOyBsZWZ0Um93Um9vdCA8IGxlZnRSb3dzOyBsZWZ0Um93Um9vdCsrKSB7XG4gICAgICAgIGNvbnN0IGxlZnRSb3dCYXNlID0gbGVmdENvbHVtbnMgKiBsZWZ0Um93Um9vdDtcbiAgICAgICAgY29uc3QgcmlnaHRSb3dCYXNlID0gcmlnaHRDb2x1bW5zICogbGVmdFJvd1Jvb3Q7XG4gICAgICAgIC8vIGxvb3Agb3ZlciBjb2xzIG9mIHJpZ2h0XG4gICAgICAgIGZvciAobGV0IHJpZ2h0Q29sdW1uID0gMDsgcmlnaHRDb2x1bW4gPCByaWdodENvbHVtbnM7IHJpZ2h0Q29sdW1uKyspIHtcbiAgICAgICAgICAgIC8vIGxvb3Agb3ZlciBjb2x1bW5zIG9mIGxlZnRcbiAgICAgICAgICAgIGZvciAobGV0IGxlZnRDb2x1bW4gPSAwOyBsZWZ0Q29sdW1uIDwgbGVmdENvbHVtbnM7IGxlZnRDb2x1bW4rKykge1xuICAgICAgICAgICAgICAgIGNvbnN0IHJpZ2h0Q29sdW1uQmFzZSA9IHJpZ2h0Q29sdW1ucyAqIGxlZnRDb2x1bW47XG4gICAgICAgICAgICAgICAgY29uc3QgbGVmdFJvdyA9IGxlZnRSb3dCYXNlICsgbGVmdENvbHVtbjtcbiAgICAgICAgICAgICAgICBjb25zdCByaWdodFJvdyA9IHJpZ2h0Q29sdW1uQmFzZSArIHJpZ2h0Q29sdW1uO1xuICAgICAgICAgICAgICAgIGNvbnN0IGJhY2tQcm9wYWdhdGVWYWx1ZSA9IHByb2R1Y3QuZGVsdGFzW3JpZ2h0Um93QmFzZSArIHJpZ2h0Q29sdW1uXTtcbiAgICAgICAgICAgICAgICBsZWZ0LmRlbHRhc1tsZWZ0Um93XSArPSByaWdodC53ZWlnaHRzW3JpZ2h0Um93XSAqIGJhY2tQcm9wYWdhdGVWYWx1ZTtcbiAgICAgICAgICAgICAgICByaWdodC5kZWx0YXNbcmlnaHRSb3ddICs9IGxlZnQud2VpZ2h0c1tsZWZ0Um93XSAqIGJhY2tQcm9wYWdhdGVWYWx1ZTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIH1cbn1cblxuZnVuY3Rpb24gbXVsdGlwbHlFbGVtZW50KHByb2R1Y3QsIGxlZnQsIHJpZ2h0KSB7XG4gICAgY29uc3QgeyB3ZWlnaHRzIH0gPSBsZWZ0O1xuICAgIGZvciAobGV0IGkgPSAwOyBpIDwgd2VpZ2h0cy5sZW5ndGg7IGkrKykge1xuICAgICAgICBwcm9kdWN0LndlaWdodHNbaV0gPSBsZWZ0LndlaWdodHNbaV0gKiByaWdodC53ZWlnaHRzW2ldO1xuICAgICAgICBwcm9kdWN0LmRlbHRhc1tpXSA9IDA7XG4gICAgfVxufVxuXG4vKipcbiAqIG11bHRpcGxpZXMge2xlZnR9IGFuZCB7cmlnaHR9IHdlaWdodCBieSB7ZnJvbX0gZGVsdGFzIGludG8ge2xlZnR9IGFuZCB7cmlnaHR9IGRlbHRhc1xuICovXG5mdW5jdGlvbiBtdWx0aXBseUVsZW1lbnRCKHByb2R1Y3QsIGxlZnQsIHJpZ2h0KSB7XG4gICAgZm9yIChsZXQgaSA9IDA7IGkgPCBsZWZ0LndlaWdodHMubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgbGVmdC5kZWx0YXNbaV0gPSByaWdodC53ZWlnaHRzW2ldICogcHJvZHVjdC5kZWx0YXNbaV07XG4gICAgICAgIHJpZ2h0LmRlbHRhc1tpXSA9IGxlZnQud2VpZ2h0c1tpXSAqIHByb2R1Y3QuZGVsdGFzW2ldO1xuICAgIH1cbn1cblxuLyoqXG4gKlxuICogcmVsdSB7bX0gd2VpZ2h0cyB0byB7aW50b30gd2VpZ2h0c1xuICovXG5mdW5jdGlvbiByZWx1KHByb2R1Y3QsIGxlZnQpIHtcbiAgICBmb3IgKGxldCBpID0gMDsgaSA8IGxlZnQud2VpZ2h0cy5sZW5ndGg7IGkrKykge1xuICAgICAgICBwcm9kdWN0LndlaWdodHNbaV0gPSBNYXRoLm1heCgwLCBsZWZ0LndlaWdodHNbaV0pOyAvLyByZWx1XG4gICAgICAgIHByb2R1Y3QuZGVsdGFzW2ldID0gMDtcbiAgICB9XG59XG5cbi8qKlxuICogYWRkcyB7ZnJvbX0gZGVsdGFzIHRvIHttfSBkZWx0YXMgd2hlbiB7bX0gd2VpZ2h0cyBhcmUgYWJvdmUgb3RoZXIgYSB0aHJlc2hvbGQgb2YgMFxuICovXG5mdW5jdGlvbiByZWx1Qihwcm9kdWN0LCBsZWZ0KSB7XG4gICAgZm9yIChsZXQgaSA9IDA7IGkgPCBwcm9kdWN0LmRlbHRhcy5sZW5ndGg7IGkrKykge1xuICAgICAgICBsZWZ0LmRlbHRhc1tpXSA9IGxlZnQud2VpZ2h0c1tpXSA+IDAgPyBwcm9kdWN0LmRlbHRhc1tpXSA6IDA7XG4gICAgfVxufVxuXG5mdW5jdGlvbiByb3dQbHVjayhwcm9kdWN0LCBsZWZ0LCByb3dQbHVja0luZGV4KSB7XG4gICAgY29uc3QgeyBjb2x1bW5zIH0gPSBsZWZ0O1xuICAgIGNvbnN0IHJvd0Jhc2UgPSBjb2x1bW5zICogcm93UGx1Y2tJbmRleDtcbiAgICBmb3IgKGxldCBjb2x1bW4gPSAwOyBjb2x1bW4gPCBjb2x1bW5zOyBjb2x1bW4rKykge1xuICAgICAgICBwcm9kdWN0LndlaWdodHNbY29sdW1uXSA9IGxlZnQud2VpZ2h0c1tyb3dCYXNlICsgY29sdW1uXTtcbiAgICAgICAgcHJvZHVjdC5kZWx0YXNbY29sdW1uXSA9IDA7XG4gICAgfVxufVxuXG4vKipcbiAqIGFkZHMge2Zyb219IGRlbHRhcyBpbnRvIHttfSBkZWx0YXNcbiAqL1xuZnVuY3Rpb24gcm93UGx1Y2tCKHByb2R1Y3QsIGxlZnQsIHJvd0luZGV4KSB7XG4gICAgY29uc3QgeyBjb2x1bW5zIH0gPSBsZWZ0O1xuICAgIGNvbnN0IHJvd0Jhc2UgPSBjb2x1bW5zICogcm93SW5kZXg7XG4gICAgZm9yIChsZXQgY29sdW1uID0gMDsgY29sdW1uIDwgY29sdW1uczsgY29sdW1uKyspIHtcbiAgICAgICAgbGVmdC5kZWx0YXNbcm93QmFzZSArIGNvbHVtbl0gPSBwcm9kdWN0LmRlbHRhc1tjb2x1bW5dO1xuICAgIH1cbn1cblxuZnVuY3Rpb24gc2lnbW9pZChwcm9kdWN0LCBsZWZ0KSB7XG4gICAgLy8gc2lnbW9pZCBub25saW5lYXJpdHlcbiAgICBmb3IgKGxldCBpID0gMDsgaSA8IGxlZnQud2VpZ2h0cy5sZW5ndGg7IGkrKykge1xuICAgICAgICBwcm9kdWN0LndlaWdodHNbaV0gPSAxIC8gKDEgKyBNYXRoLmV4cCgtbGVmdC53ZWlnaHRzW2ldKSk7XG4gICAgICAgIHByb2R1Y3QuZGVsdGFzW2ldID0gMDtcbiAgICB9XG59XG4vLyBmdW5jdGlvbiBzaWcoeCkge1xuLy8gICAvLyBoZWxwZXIgZnVuY3Rpb24gZm9yIGNvbXB1dGluZyBzaWdtb2lkXG4vLyAgIHJldHVybiAxIC8gKDEgKyBNYXRoLmV4cCgteCkpO1xuLy8gfVxuXG5mdW5jdGlvbiBzaWdtb2lkQihwcm9kdWN0LCBsZWZ0KSB7XG4gICAgZm9yIChsZXQgaSA9IDA7IGkgPCBwcm9kdWN0LmRlbHRhcy5sZW5ndGg7IGkrKykge1xuICAgICAgICBjb25zdCBtd2kgPSBwcm9kdWN0LndlaWdodHNbaV07XG4gICAgICAgIGxlZnQuZGVsdGFzW2ldID0gbXdpICogKDEgLSBtd2kpICogcHJvZHVjdC5kZWx0YXNbaV07XG4gICAgfVxufVxuXG5mdW5jdGlvbiBzb2Z0bWF4KG1hdHJpeCkge1xuICAgIC8vIHByb2JhYmlsaXR5IHZvbHVtZVxuICAgIGNvbnN0IHJlc3VsdCA9IG5ldyBNYXRyaXgobWF0cml4LnJvd3MsIG1hdHJpeC5jb2x1bW5zKTtcbiAgICBsZXQgbWF4VmFsID0gLTk5OTk5OTtcbiAgICBmb3IgKGxldCBpID0gMDsgaSA8IG1hdHJpeC53ZWlnaHRzLmxlbmd0aDsgaSsrKSB7XG4gICAgICAgIGlmIChtYXRyaXgud2VpZ2h0c1tpXSA+IG1heFZhbCkge1xuICAgICAgICAgICAgbWF4VmFsID0gbWF0cml4LndlaWdodHNbaV07XG4gICAgICAgIH1cbiAgICB9XG4gICAgbGV0IHMgPSAwO1xuICAgIGZvciAobGV0IGkgPSAwOyBpIDwgbWF0cml4LndlaWdodHMubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgcmVzdWx0LndlaWdodHNbaV0gPSBNYXRoLmV4cChtYXRyaXgud2VpZ2h0c1tpXSAtIG1heFZhbCk7XG4gICAgICAgIHMgKz0gcmVzdWx0LndlaWdodHNbaV07XG4gICAgfVxuICAgIGZvciAobGV0IGkgPSAwOyBpIDwgbWF0cml4LndlaWdodHMubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgcmVzdWx0LndlaWdodHNbaV0gLz0gcztcbiAgICB9XG4gICAgLy8gbm8gYmFja3dhcmQgcGFzcyBoZXJlIG5lZWRlZFxuICAgIC8vIHNpbmNlIHdlIHdpbGwgdXNlIHRoZSBjb21wdXRlZCBwcm9iYWJpbGl0aWVzIG91dHNpZGVcbiAgICAvLyB0byBzZXQgZ3JhZGllbnRzIGRpcmVjdGx5IG9uIG1cbiAgICByZXR1cm4gcmVzdWx0O1xufVxuXG5mdW5jdGlvbiB0YW5oKHByb2R1Y3QsIGxlZnQpIHtcbiAgICAvLyB0YW5oIG5vbmxpbmVhcml0eVxuICAgIGZvciAobGV0IGkgPSAwOyBpIDwgbGVmdC53ZWlnaHRzLmxlbmd0aDsgaSsrKSB7XG4gICAgICAgIHByb2R1Y3Qud2VpZ2h0c1tpXSA9IE1hdGgudGFuaChsZWZ0LndlaWdodHNbaV0pO1xuICAgICAgICBwcm9kdWN0LmRlbHRhc1tpXSA9IDA7XG4gICAgfVxufVxuXG5mdW5jdGlvbiB0YW5oQihwcm9kdWN0LCBsZWZ0KSB7XG4gICAgZm9yIChsZXQgaSA9IDA7IGkgPCBwcm9kdWN0LmRlbHRhcy5sZW5ndGg7IGkrKykge1xuICAgICAgICAvLyBncmFkIGZvciB6ID0gdGFuaCh4KSBpcyAoMSAtIHpeMilcbiAgICAgICAgY29uc3QgbXdpID0gcHJvZHVjdC53ZWlnaHRzW2ldO1xuICAgICAgICBsZWZ0LmRlbHRhc1tpXSA9ICgxIC0gbXdpICogbXdpKSAqIHByb2R1Y3QuZGVsdGFzW2ldO1xuICAgIH1cbn1cblxuY2xhc3MgRXF1YXRpb24ge1xuICAgIGNvbnN0cnVjdG9yKCkge1xuICAgICAgICB0aGlzLnN0YXRlcyA9IFtdO1xuICAgICAgICB0aGlzLmlucHV0Um93ID0gMDtcbiAgICB9XG4gICAgYWRkKGxlZnQsIHJpZ2h0KSB7XG4gICAgICAgIGlmIChsZWZ0LndlaWdodHMubGVuZ3RoICE9PSByaWdodC53ZWlnaHRzLmxlbmd0aCkge1xuICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdtaXNhbGlnbmVkIG1hdHJpY2VzJyk7XG4gICAgICAgIH1cbiAgICAgICAgY29uc3QgcHJvZHVjdCA9IG5ldyBNYXRyaXgobGVmdC5yb3dzLCBsZWZ0LmNvbHVtbnMpO1xuICAgICAgICB0aGlzLnN0YXRlcy5wdXNoKHtcbiAgICAgICAgICAgIG5hbWU6ICdhZGQnLFxuICAgICAgICAgICAgcHJvZHVjdCxcbiAgICAgICAgICAgIGxlZnQsXG4gICAgICAgICAgICByaWdodCxcbiAgICAgICAgICAgIGZvcndhcmRGbjogYWRkLFxuICAgICAgICAgICAgYmFja3Byb3BhZ2F0aW9uRm46IGFkZEIsXG4gICAgICAgIH0pO1xuICAgICAgICByZXR1cm4gcHJvZHVjdDtcbiAgICB9XG4gICAgYWxsT25lcyhyb3dzLCBjb2x1bW5zKSB7XG4gICAgICAgIGNvbnN0IHByb2R1Y3QgPSBuZXcgTWF0cml4KHJvd3MsIGNvbHVtbnMpO1xuICAgICAgICB0aGlzLnN0YXRlcy5wdXNoKHtcbiAgICAgICAgICAgIG5hbWU6ICdhbGxPbmVzJyxcbiAgICAgICAgICAgIHByb2R1Y3QsXG4gICAgICAgICAgICBsZWZ0OiBwcm9kdWN0LFxuICAgICAgICAgICAgZm9yd2FyZEZuOiBhbGxPbmVzLFxuICAgICAgICAgICAgYmFja3Byb3BhZ2F0aW9uRm46ICgpID0+IHsgfSxcbiAgICAgICAgfSk7XG4gICAgICAgIHJldHVybiBwcm9kdWN0O1xuICAgIH1cbiAgICBjbG9uZU5lZ2F0aXZlKG1hdHJpeCkge1xuICAgICAgICBjb25zdCBwcm9kdWN0ID0gbmV3IE1hdHJpeChtYXRyaXgucm93cywgbWF0cml4LmNvbHVtbnMpO1xuICAgICAgICB0aGlzLnN0YXRlcy5wdXNoKHtcbiAgICAgICAgICAgIG5hbWU6ICdjbG9uZU5lZ2F0aXZlJyxcbiAgICAgICAgICAgIHByb2R1Y3QsXG4gICAgICAgICAgICBsZWZ0OiBtYXRyaXgsXG4gICAgICAgICAgICBmb3J3YXJkRm46IGNsb25lTmVnYXRpdmUsXG4gICAgICAgICAgICBiYWNrcHJvcGFnYXRpb25GbjogKCkgPT4geyB9LFxuICAgICAgICB9KTtcbiAgICAgICAgcmV0dXJuIHByb2R1Y3Q7XG4gICAgfVxuICAgIC8qKlxuICAgICAqIGNvbm5lY3RzIHR3byBtYXRyaWNlcyB0b2dldGhlciBieSBzdWJ0cmFjdFxuICAgICAqL1xuICAgIHN1YnRyYWN0KGxlZnQsIHJpZ2h0KSB7XG4gICAgICAgIGlmIChsZWZ0LndlaWdodHMubGVuZ3RoICE9PSByaWdodC53ZWlnaHRzLmxlbmd0aCkge1xuICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdtaXNhbGlnbmVkIG1hdHJpY2VzJyk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHRoaXMuYWRkKHRoaXMuYWRkKHRoaXMuYWxsT25lcyhsZWZ0LnJvd3MsIGxlZnQuY29sdW1ucyksIHRoaXMuY2xvbmVOZWdhdGl2ZShsZWZ0KSksIHJpZ2h0KTtcbiAgICB9XG4gICAgLyoqXG4gICAgICogY29ubmVjdHMgdHdvIG1hdHJpY2VzIHRvZ2V0aGVyIGJ5IG11bHRpcGx5XG4gICAgICovXG4gICAgbXVsdGlwbHkobGVmdCwgcmlnaHQpIHtcbiAgICAgICAgaWYgKGxlZnQuY29sdW1ucyAhPT0gcmlnaHQucm93cykge1xuICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdtaXNhbGlnbmVkIG1hdHJpY2VzJyk7XG4gICAgICAgIH1cbiAgICAgICAgY29uc3QgcHJvZHVjdCA9IG5ldyBNYXRyaXgobGVmdC5yb3dzLCByaWdodC5jb2x1bW5zKTtcbiAgICAgICAgdGhpcy5zdGF0ZXMucHVzaCh7XG4gICAgICAgICAgICBuYW1lOiAnbXVsdGlwbHknLFxuICAgICAgICAgICAgcHJvZHVjdCxcbiAgICAgICAgICAgIGxlZnQsXG4gICAgICAgICAgICByaWdodCxcbiAgICAgICAgICAgIGZvcndhcmRGbjogbXVsdGlwbHksXG4gICAgICAgICAgICBiYWNrcHJvcGFnYXRpb25GbjogbXVsdGlwbHlCLFxuICAgICAgICB9KTtcbiAgICAgICAgcmV0dXJuIHByb2R1Y3Q7XG4gICAgfVxuICAgIC8qKlxuICAgICAqIGNvbm5lY3RzIHR3byBtYXRyaWNlcyB0b2dldGhlciBieSBtdWx0aXBseUVsZW1lbnRcbiAgICAgKi9cbiAgICBtdWx0aXBseUVsZW1lbnQobGVmdCwgcmlnaHQpIHtcbiAgICAgICAgaWYgKGxlZnQud2VpZ2h0cy5sZW5ndGggIT09IHJpZ2h0LndlaWdodHMubGVuZ3RoKSB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ21pc2FsaWduZWQgbWF0cmljZXMnKTtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCBwcm9kdWN0ID0gbmV3IE1hdHJpeChsZWZ0LnJvd3MsIGxlZnQuY29sdW1ucyk7XG4gICAgICAgIHRoaXMuc3RhdGVzLnB1c2goe1xuICAgICAgICAgICAgbmFtZTogJ211bHRpcGx5RWxlbWVudCcsXG4gICAgICAgICAgICBwcm9kdWN0LFxuICAgICAgICAgICAgbGVmdCxcbiAgICAgICAgICAgIHJpZ2h0LFxuICAgICAgICAgICAgZm9yd2FyZEZuOiBtdWx0aXBseUVsZW1lbnQsXG4gICAgICAgICAgICBiYWNrcHJvcGFnYXRpb25GbjogbXVsdGlwbHlFbGVtZW50QixcbiAgICAgICAgfSk7XG4gICAgICAgIHJldHVybiBwcm9kdWN0O1xuICAgIH1cbiAgICAvKipcbiAgICAgKiBjb25uZWN0cyBhIG1hdHJpeCB0byByZWx1XG4gICAgICovXG4gICAgcmVsdShtYXRyaXgpIHtcbiAgICAgICAgY29uc3QgcHJvZHVjdCA9IG5ldyBNYXRyaXgobWF0cml4LnJvd3MsIG1hdHJpeC5jb2x1bW5zKTtcbiAgICAgICAgdGhpcy5zdGF0ZXMucHVzaCh7XG4gICAgICAgICAgICBuYW1lOiAncmVsdScsXG4gICAgICAgICAgICBwcm9kdWN0LFxuICAgICAgICAgICAgbGVmdDogbWF0cml4LFxuICAgICAgICAgICAgZm9yd2FyZEZuOiByZWx1LFxuICAgICAgICAgICAgYmFja3Byb3BhZ2F0aW9uRm46IHJlbHVCLFxuICAgICAgICB9KTtcbiAgICAgICAgcmV0dXJuIHByb2R1Y3Q7XG4gICAgfVxuICAgIC8qKlxuICAgICAqIGlucHV0IGEgbWF0cml4XG4gICAgICovXG4gICAgaW5wdXQoaW5wdXQpIHtcbiAgICAgICAgdGhpcy5zdGF0ZXMucHVzaCh7XG4gICAgICAgICAgICBuYW1lOiAnaW5wdXQnLFxuICAgICAgICAgICAgcHJvZHVjdDogaW5wdXQsXG4gICAgICAgICAgICBmb3J3YXJkRm46IChwcm9kdWN0KSA9PiB7XG4gICAgICAgICAgICAgICAgaWYgKCF0aGlzLmlucHV0VmFsdWUpXG4gICAgICAgICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgICAgICBpZiAodGhpcy5pbnB1dFZhbHVlLmxlbmd0aCAhPT0gcHJvZHVjdC53ZWlnaHRzLmxlbmd0aCkge1xuICAgICAgICAgICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ3RoaXMuaW5wdXRWYWx1ZSBpcyBvZiB3cm9uZyBkaW1lbnNpb25zJyk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIHByb2R1Y3Qud2VpZ2h0cyA9IGlucHV0LndlaWdodHMgPSB0aGlzLmlucHV0VmFsdWU7XG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgYmFja3Byb3BhZ2F0aW9uRm46ICgpID0+IHsgfSxcbiAgICAgICAgfSk7XG4gICAgICAgIHJldHVybiBpbnB1dDtcbiAgICB9XG4gICAgLyoqXG4gICAgICogY29ubmVjdHMgYSBtYXRyaXggdmlhIGEgcm93XG4gICAgICovXG4gICAgaW5wdXRNYXRyaXhUb1JvdyhtYXRyaXgpIHtcbiAgICAgICAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIEB0eXBlc2NyaXB0LWVzbGludC9uby10aGlzLWFsaWFzXG4gICAgICAgIGNvbnN0IHNlbGYgPSB0aGlzO1xuICAgICAgICBjb25zdCBwcm9kdWN0ID0gbmV3IE1hdHJpeChtYXRyaXguY29sdW1ucywgMSk7XG4gICAgICAgIHRoaXMuc3RhdGVzLnB1c2goe1xuICAgICAgICAgICAgbmFtZTogJ2lucHV0TWF0cml4VG9Sb3cnLFxuICAgICAgICAgICAgcHJvZHVjdCxcbiAgICAgICAgICAgIGxlZnQ6IG1hdHJpeCxcbiAgICAgICAgICAgIGdldCByaWdodCgpIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gc2VsZi5pbnB1dFJvdztcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBmb3J3YXJkRm46IHJvd1BsdWNrLFxuICAgICAgICAgICAgYmFja3Byb3BhZ2F0aW9uRm46IHJvd1BsdWNrQixcbiAgICAgICAgfSk7XG4gICAgICAgIHJldHVybiBwcm9kdWN0O1xuICAgIH1cbiAgICAvKipcbiAgICAgKiBjb25uZWN0cyBhIG1hdHJpeCB0byBzaWdtb2lkXG4gICAgICovXG4gICAgc2lnbW9pZChtYXRyaXgpIHtcbiAgICAgICAgY29uc3QgcHJvZHVjdCA9IG5ldyBNYXRyaXgobWF0cml4LnJvd3MsIG1hdHJpeC5jb2x1bW5zKTtcbiAgICAgICAgdGhpcy5zdGF0ZXMucHVzaCh7XG4gICAgICAgICAgICBuYW1lOiAnc2lnbW9pZCcsXG4gICAgICAgICAgICBwcm9kdWN0LFxuICAgICAgICAgICAgbGVmdDogbWF0cml4LFxuICAgICAgICAgICAgZm9yd2FyZEZuOiBzaWdtb2lkLFxuICAgICAgICAgICAgYmFja3Byb3BhZ2F0aW9uRm46IHNpZ21vaWRCLFxuICAgICAgICB9KTtcbiAgICAgICAgcmV0dXJuIHByb2R1Y3Q7XG4gICAgfVxuICAgIC8qKlxuICAgICAqIGNvbm5lY3RzIGEgbWF0cml4IHRvIHRhbmhcbiAgICAgKi9cbiAgICB0YW5oKG1hdHJpeCkge1xuICAgICAgICBjb25zdCBwcm9kdWN0ID0gbmV3IE1hdHJpeChtYXRyaXgucm93cywgbWF0cml4LmNvbHVtbnMpO1xuICAgICAgICB0aGlzLnN0YXRlcy5wdXNoKHtcbiAgICAgICAgICAgIG5hbWU6ICd0YW5oJyxcbiAgICAgICAgICAgIHByb2R1Y3QsXG4gICAgICAgICAgICBsZWZ0OiBtYXRyaXgsXG4gICAgICAgICAgICBmb3J3YXJkRm46IHRhbmgsXG4gICAgICAgICAgICBiYWNrcHJvcGFnYXRpb25GbjogdGFuaEIsXG4gICAgICAgIH0pO1xuICAgICAgICByZXR1cm4gcHJvZHVjdDtcbiAgICB9XG4gICAgLyoqXG4gICAgICpcbiAgICAgKiBPYnNlcnZlIGEgbWF0cml4IGZvciBkZWJ1Z2dpbmdcbiAgICAgKi9cbiAgICBvYnNlcnZlKG1hdHJpeCkge1xuICAgICAgICB0aGlzLnN0YXRlcy5wdXNoKHtcbiAgICAgICAgICAgIG5hbWU6ICdvYnNlcnZlJyxcbiAgICAgICAgICAgIHByb2R1Y3Q6IG5ldyBNYXRyaXgoKSxcbiAgICAgICAgICAgIGZvcndhcmRGbjogKCkgPT4geyB9LFxuICAgICAgICAgICAgYmFja3Byb3BhZ2F0aW9uRm46ICgpID0+IHsgfSxcbiAgICAgICAgfSk7XG4gICAgICAgIHJldHVybiBtYXRyaXg7XG4gICAgfVxuICAgIC8qKlxuICAgICAqIFJ1biBpbmRleCB0aHJvdWdoIGVxdWF0aW9ucyB2aWEgZm9yd2FyZCBwcm9wYWdhdGlvblxuICAgICAqL1xuICAgIHJ1bkluZGV4KHJvd0luZGV4ID0gMCkge1xuICAgICAgICB0aGlzLmlucHV0Um93ID0gcm93SW5kZXg7XG4gICAgICAgIGxldCBzdGF0ZSA9IHRoaXMuc3RhdGVzWzBdO1xuICAgICAgICBmb3IgKGxldCBpID0gMCwgbWF4ID0gdGhpcy5zdGF0ZXMubGVuZ3RoOyBpIDwgbWF4OyBpKyspIHtcbiAgICAgICAgICAgIHN0YXRlID0gdGhpcy5zdGF0ZXNbaV07XG4gICAgICAgICAgICBpZiAoIXN0YXRlLmhhc093blByb3BlcnR5KCdmb3J3YXJkRm4nKSlcbiAgICAgICAgICAgICAgICBjb250aW51ZTtcbiAgICAgICAgICAgIHN0YXRlLmZvcndhcmRGbihzdGF0ZS5wcm9kdWN0LCBzdGF0ZS5sZWZ0LCBzdGF0ZS5yaWdodCk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHN0YXRlLnByb2R1Y3Q7XG4gICAgfVxuICAgIC8qKlxuICAgICAqIFJ1biB2YWx1ZSB0aHJvdWdoIGVxdWF0aW9ucyB2aWEgZm9yd2FyZCBwcm9wYWdhdGlvblxuICAgICAqL1xuICAgIHJ1bklucHV0KGlucHV0VmFsdWUpIHtcbiAgICAgICAgdGhpcy5pbnB1dFZhbHVlID0gaW5wdXRWYWx1ZTtcbiAgICAgICAgbGV0IHN0YXRlID0gdGhpcy5zdGF0ZXNbMF07XG4gICAgICAgIGZvciAobGV0IGkgPSAwLCBtYXggPSB0aGlzLnN0YXRlcy5sZW5ndGg7IGkgPCBtYXg7IGkrKykge1xuICAgICAgICAgICAgc3RhdGUgPSB0aGlzLnN0YXRlc1tpXTtcbiAgICAgICAgICAgIGlmICghc3RhdGUuaGFzT3duUHJvcGVydHkoJ2ZvcndhcmRGbicpKVxuICAgICAgICAgICAgICAgIGNvbnRpbnVlO1xuICAgICAgICAgICAgc3RhdGUuZm9yd2FyZEZuKHN0YXRlLnByb2R1Y3QsIHN0YXRlLmxlZnQsIHN0YXRlLnJpZ2h0KTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gc3RhdGUucHJvZHVjdDtcbiAgICB9XG4gICAgLyoqXG4gICAgICogUnVuIHZhbHVlIHRocm91Z2ggZXF1YXRpb25zIHZpYSBiYWNrIHByb3BhZ2F0aW9uXG4gICAgICovXG4gICAgYmFja3Byb3BhZ2F0ZSgpIHtcbiAgICAgICAgbGV0IGkgPSB0aGlzLnN0YXRlcy5sZW5ndGg7XG4gICAgICAgIGxldCBzdGF0ZSA9IHRoaXMuc3RhdGVzWzBdO1xuICAgICAgICB3aGlsZSAoaS0tID4gMCkge1xuICAgICAgICAgICAgc3RhdGUgPSB0aGlzLnN0YXRlc1tpXTtcbiAgICAgICAgICAgIGlmICghc3RhdGUuaGFzT3duUHJvcGVydHkoJ2JhY2twcm9wYWdhdGlvbkZuJykpXG4gICAgICAgICAgICAgICAgY29udGludWU7XG4gICAgICAgICAgICBzdGF0ZS5iYWNrcHJvcGFnYXRpb25GbihzdGF0ZS5wcm9kdWN0LCBzdGF0ZS5sZWZ0LCBzdGF0ZS5yaWdodCk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHN0YXRlLnByb2R1Y3Q7XG4gICAgfVxuICAgIC8qKlxuICAgICAqIFJ1biBpbmRleCB0aHJvdWdoIGVxdWF0aW9ucyB2aWEgYmFjayBwcm9wYWdhdGlvblxuICAgICAqL1xuICAgIGJhY2twcm9wYWdhdGVJbmRleChyb3dJbmRleCA9IDApIHtcbiAgICAgICAgdGhpcy5pbnB1dFJvdyA9IHJvd0luZGV4O1xuICAgICAgICBsZXQgaSA9IHRoaXMuc3RhdGVzLmxlbmd0aDtcbiAgICAgICAgbGV0IHN0YXRlID0gdGhpcy5zdGF0ZXNbMF07XG4gICAgICAgIHdoaWxlIChpLS0gPiAwKSB7XG4gICAgICAgICAgICBzdGF0ZSA9IHRoaXMuc3RhdGVzW2ldO1xuICAgICAgICAgICAgaWYgKCFzdGF0ZS5oYXNPd25Qcm9wZXJ0eSgnYmFja3Byb3BhZ2F0aW9uRm4nKSlcbiAgICAgICAgICAgICAgICBjb250aW51ZTtcbiAgICAgICAgICAgIHN0YXRlLmJhY2twcm9wYWdhdGlvbkZuKHN0YXRlLnByb2R1Y3QsIHN0YXRlLmxlZnQsIHN0YXRlLnJpZ2h0KTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gc3RhdGUucHJvZHVjdDtcbiAgICB9XG4gICAgLyoqXG4gICAgICogUHJlZGljdCBhIHRhcmdldCB2YWx1ZSBmcm9tIGVxdWF0aW9uXG4gICAgICovXG4gICAgcHJlZGljdFRhcmdldChpbnB1dCwgdGFyZ2V0KSB7XG4gICAgICAgIGxldCBlcnJvclN1bSA9IDA7XG4gICAgICAgIGNvbnN0IG91dHB1dCA9IHRoaXMucnVuSW5wdXQoaW5wdXQpO1xuICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IG91dHB1dC53ZWlnaHRzLmxlbmd0aDsgaSsrKSB7XG4gICAgICAgICAgICBjb25zdCBlcnJvciA9IG91dHB1dC53ZWlnaHRzW2ldIC0gdGFyZ2V0W2ldO1xuICAgICAgICAgICAgLy8gc2V0IGdyYWRpZW50cyBpbnRvIGxvZyBwcm9iYWJpbGl0aWVzXG4gICAgICAgICAgICBlcnJvclN1bSArPSBNYXRoLmFicyhlcnJvcik7XG4gICAgICAgICAgICAvLyB3cml0ZSBncmFkaWVudHMgaW50byBsb2cgcHJvYmFiaWxpdGllc1xuICAgICAgICAgICAgb3V0cHV0LmRlbHRhc1tpXSA9IGVycm9yO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBlcnJvclN1bTtcbiAgICB9XG4gICAgLyoqXG4gICAgICogUHJlZGljdCBhIHRhcmdldCBpbmRleCBmcm9tIGVxdWF0aW9uXG4gICAgICovXG4gICAgcHJlZGljdFRhcmdldEluZGV4KGlucHV0LCB0YXJnZXQpIHtcbiAgICAgICAgY29uc3Qgb3V0cHV0ID0gdGhpcy5ydW5JbmRleChpbnB1dCk7XG4gICAgICAgIC8vIHNldCBncmFkaWVudHMgaW50byBsb2cgcHJvYmFiaWxpdGllc1xuICAgICAgICBjb25zdCBsb2dQcm9iYWJpbGl0aWVzID0gb3V0cHV0OyAvLyBpbnRlcnByZXQgb3V0cHV0IGFzIGxvZyBwcm9iYWJpbGl0aWVzXG4gICAgICAgIGNvbnN0IHByb2JhYmlsaXRpZXMgPSBzb2Z0bWF4KG91dHB1dCk7IC8vIGNvbXB1dGUgdGhlIHNvZnRtYXggcHJvYmFiaWxpdGllc1xuICAgICAgICAvLyB3cml0ZSBncmFkaWVudHMgaW50byBsb2cgcHJvYmFiaWxpdGllc1xuICAgICAgICBsb2dQcm9iYWJpbGl0aWVzLmRlbHRhcyA9IHByb2JhYmlsaXRpZXMud2VpZ2h0cy5zbGljZSgwKTtcbiAgICAgICAgbG9nUHJvYmFiaWxpdGllcy5kZWx0YXNbdGFyZ2V0XSAtPSAxO1xuICAgICAgICAvLyBhY2N1bXVsYXRlIGJhc2UgMiBsb2cgcHJvYiBhbmQgZG8gc21vb3RoaW5nXG4gICAgICAgIHJldHVybiAtTWF0aC5sb2cyKHByb2JhYmlsaXRpZXMud2VpZ2h0c1t0YXJnZXRdKTtcbiAgICB9XG59XG5cbmZ1bmN0aW9uIG1heEkobWF0cml4KSB7XG4gICAgLy8gYXJnbWF4IG9mIGFycmF5IHdcbiAgICBjb25zdCB7IHdlaWdodHMgfSA9IG1hdHJpeDtcbiAgICBsZXQgbWF4diA9IHdlaWdodHNbMF07XG4gICAgbGV0IG1heGl4ID0gMDtcbiAgICBmb3IgKGxldCBpID0gMTsgaSA8IHdlaWdodHMubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgY29uc3QgdiA9IHdlaWdodHNbaV07XG4gICAgICAgIGlmICh2IDwgbWF4dilcbiAgICAgICAgICAgIGNvbnRpbnVlO1xuICAgICAgICBtYXhpeCA9IGk7XG4gICAgICAgIG1heHYgPSB2O1xuICAgIH1cbiAgICByZXR1cm4gbWF4aXg7XG59XG5cbmZ1bmN0aW9uIHNhbXBsZUkobWF0cml4KSB7XG4gICAgLy8gc2FtcGxlIGFyZ21heCBmcm9tIHcsIGFzc3VtaW5nIHcgYXJlXG4gICAgLy8gcHJvYmFiaWxpdGllcyB0aGF0IHN1bSB0byBvbmVcbiAgICBjb25zdCByID0gcmFuZG9tRmxvYXQoMCwgMSk7XG4gICAgY29uc3QgdyA9IG1hdHJpeC53ZWlnaHRzO1xuICAgIGxldCB4ID0gMDtcbiAgICBsZXQgaSA9IDA7XG4gICAgd2hpbGUgKHRydWUpIHtcbiAgICAgICAgeCArPSB3W2ldO1xuICAgICAgICBpZiAoeCA+IHIpIHtcbiAgICAgICAgICAgIHJldHVybiBpO1xuICAgICAgICB9XG4gICAgICAgIGkrKztcbiAgICB9XG59XG5cbmNvbnN0IHRyYWluRGVmYXVsdHMkMSA9IHtcbiAgICBpdGVyYXRpb25zOiAyMDAwMCxcbiAgICBlcnJvclRocmVzaDogMC4wMDUsXG4gICAgbG9nOiBmYWxzZSxcbiAgICBsb2dQZXJpb2Q6IDEwLFxuICAgIGxlYXJuaW5nUmF0ZTogMC4wMSxcbiAgICBjYWxsYmFja1BlcmlvZDogMTAsXG4gICAgdGltZW91dDogSW5maW5pdHksXG59O1xuY29uc3QgZGVmYXVsdHMkMSA9ICgpID0+IHtcbiAgICByZXR1cm4ge1xuICAgICAgICBpbnB1dFNpemU6IDIwLFxuICAgICAgICBpbnB1dFJhbmdlOiAyMCxcbiAgICAgICAgaGlkZGVuTGF5ZXJzOiBbMjAsIDIwXSxcbiAgICAgICAgb3V0cHV0U2l6ZTogMjAsXG4gICAgICAgIGRlY2F5UmF0ZTogMC45OTksXG4gICAgICAgIHNtb290aEVwczogMWUtOCxcbiAgICAgICAgcmVnYzogMC4wMDAwMDEsXG4gICAgICAgIGNsaXB2YWw6IDUsXG4gICAgICAgIG1heFByZWRpY3Rpb25MZW5ndGg6IDEwMCxcbiAgICAgICAgZGF0YUZvcm1hdHRlcjogbmV3IERhdGFGb3JtYXR0ZXIoKSxcbiAgICB9O1xufTtcbmNsYXNzIFJOTiB7XG4gICAgY29uc3RydWN0b3Iob3B0aW9ucyA9IHt9KSB7XG4gICAgICAgIHRoaXMub3B0aW9ucyA9IHsgLi4uZGVmYXVsdHMkMSgpIH07XG4gICAgICAgIHRoaXMudHJhaW5PcHRzID0geyAuLi50cmFpbkRlZmF1bHRzJDEgfTtcbiAgICAgICAgdGhpcy5zdGVwQ2FjaGUgPSB7fTtcbiAgICAgICAgdGhpcy5ydW5zID0gMDtcbiAgICAgICAgdGhpcy5yYXRpb0NsaXBwZWQgPSAwO1xuICAgICAgICB0aGlzLm1vZGVsID0gT2JqZWN0LnNlYWwoe1xuICAgICAgICAgICAgaXNJbml0aWFsaXplZDogZmFsc2UsXG4gICAgICAgICAgICBpbnB1dDogbmV3IE1hdHJpeCgwLCAwKSxcbiAgICAgICAgICAgIGhpZGRlbkxheWVyczogW10sXG4gICAgICAgICAgICBvdXRwdXQ6IG5ldyBNYXRyaXgoMCwgMCksXG4gICAgICAgICAgICBlcXVhdGlvbnM6IFtdLFxuICAgICAgICAgICAgYWxsTWF0cmljZXM6IFtdLFxuICAgICAgICAgICAgZXF1YXRpb25Db25uZWN0aW9uczogW10sXG4gICAgICAgICAgICBvdXRwdXRDb25uZWN0b3I6IG5ldyBSYW5kb21NYXRyaXgoMCwgMCwgMC4wOCksXG4gICAgICAgIH0pO1xuICAgICAgICB0aGlzLmluaXRpYWxMYXllcklucHV0cyA9IFtdO1xuICAgICAgICB0aGlzLm9wdGlvbnMgPSB7IC4uLnRoaXMub3B0aW9ucywgLi4ub3B0aW9ucyB9O1xuICAgICAgICB0aGlzLnVwZGF0ZVRyYWluaW5nT3B0aW9ucyh7XG4gICAgICAgICAgICAuLi50cmFpbkRlZmF1bHRzJDEsXG4gICAgICAgIH0pO1xuICAgICAgICBpZiAob3B0aW9ucy5qc29uKSB7XG4gICAgICAgICAgICB0aGlzLmZyb21KU09OKG9wdGlvbnMuanNvbik7XG4gICAgICAgIH1cbiAgICB9XG4gICAgaW5pdGlhbGl6ZSgpIHtcbiAgICAgICAgY29uc3QgeyBkYXRhRm9ybWF0dGVyIH0gPSB0aGlzLm9wdGlvbnM7XG4gICAgICAgIGlmIChkYXRhRm9ybWF0dGVyID09PSBudWxsIHx8IGRhdGFGb3JtYXR0ZXIgPT09IHZvaWQgMCA/IHZvaWQgMCA6IGRhdGFGb3JtYXR0ZXIuY2hhcmFjdGVycy5sZW5ndGgpIHtcbiAgICAgICAgICAgIHRoaXMub3B0aW9ucy5pbnB1dFNpemUgPSB0aGlzLm9wdGlvbnMuaW5wdXRSYW5nZSA9IHRoaXMub3B0aW9ucy5vdXRwdXRTaXplID1cbiAgICAgICAgICAgICAgICBkYXRhRm9ybWF0dGVyLmNoYXJhY3RlcnMubGVuZ3RoO1xuICAgICAgICB9XG4gICAgICAgIHRoaXMubW9kZWwgPSB0aGlzLm1hcE1vZGVsKCk7XG4gICAgfVxuICAgIGNyZWF0ZUhpZGRlbkxheWVycygpIHtcbiAgICAgICAgY29uc3QgeyBoaWRkZW5MYXllcnMsIGlucHV0U2l6ZSB9ID0gdGhpcy5vcHRpb25zO1xuICAgICAgICBjb25zdCBoaWRkZW5MYXllcnNNb2RlbCA9IFtdO1xuICAgICAgICAvLyAwIGlzIGVuZCwgc28gYWRkIDEgdG8gb2Zmc2V0XG4gICAgICAgIGhpZGRlbkxheWVyc01vZGVsLnB1c2godGhpcy5nZXRIaWRkZW5MYXllcihoaWRkZW5MYXllcnNbMF0sIGlucHV0U2l6ZSkpO1xuICAgICAgICBsZXQgcHJldlNpemUgPSBoaWRkZW5MYXllcnNbMF07XG4gICAgICAgIGZvciAobGV0IGQgPSAxOyBkIDwgaGlkZGVuTGF5ZXJzLmxlbmd0aDsgZCsrKSB7XG4gICAgICAgICAgICAvLyBsb29wIG92ZXIgZGVwdGhzXG4gICAgICAgICAgICBjb25zdCBoaWRkZW5TaXplID0gaGlkZGVuTGF5ZXJzW2RdO1xuICAgICAgICAgICAgaGlkZGVuTGF5ZXJzTW9kZWwucHVzaCh0aGlzLmdldEhpZGRlbkxheWVyKGhpZGRlblNpemUsIHByZXZTaXplKSk7XG4gICAgICAgICAgICBwcmV2U2l6ZSA9IGhpZGRlblNpemU7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIGhpZGRlbkxheWVyc01vZGVsO1xuICAgIH1cbiAgICBnZXRIaWRkZW5MYXllcihoaWRkZW5TaXplLCBwcmV2U2l6ZSkge1xuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgLy8gd3hoXG4gICAgICAgICAgICB3ZWlnaHQ6IG5ldyBSYW5kb21NYXRyaXgoaGlkZGVuU2l6ZSwgcHJldlNpemUsIDAuMDgpLFxuICAgICAgICAgICAgLy8gd2hoXG4gICAgICAgICAgICB0cmFuc2l0aW9uOiBuZXcgUmFuZG9tTWF0cml4KGhpZGRlblNpemUsIGhpZGRlblNpemUsIDAuMDgpLFxuICAgICAgICAgICAgLy8gYmhoXG4gICAgICAgICAgICBiaWFzOiBuZXcgTWF0cml4KGhpZGRlblNpemUsIDEpLFxuICAgICAgICB9O1xuICAgIH1cbiAgICBnZXRFcXVhdGlvbihlcXVhdGlvbiwgaW5wdXRNYXRyaXgsIHByZXZpb3VzUmVzdWx0LCBoaWRkZW5MYXllcikge1xuICAgICAgICBpZiAoIWhpZGRlbkxheWVyLndlaWdodCB8fCAhaGlkZGVuTGF5ZXIudHJhbnNpdGlvbiB8fCAhaGlkZGVuTGF5ZXIuYmlhcykge1xuICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdoaWRkZW5MYXllciBkb2VzIG5vdCBoYXZlIGV4cGVjdGVkIHByb3BlcnRpZXMnKTtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCByZWx1ID0gZXF1YXRpb24ucmVsdS5iaW5kKGVxdWF0aW9uKTtcbiAgICAgICAgY29uc3QgYWRkID0gZXF1YXRpb24uYWRkLmJpbmQoZXF1YXRpb24pO1xuICAgICAgICBjb25zdCBtdWx0aXBseSA9IGVxdWF0aW9uLm11bHRpcGx5LmJpbmQoZXF1YXRpb24pO1xuICAgICAgICByZXR1cm4gcmVsdShhZGQoYWRkKG11bHRpcGx5KGhpZGRlbkxheWVyLndlaWdodCwgaW5wdXRNYXRyaXgpLCBtdWx0aXBseShoaWRkZW5MYXllci50cmFuc2l0aW9uLCBwcmV2aW91c1Jlc3VsdCkpLCBoaWRkZW5MYXllci5iaWFzKSk7XG4gICAgfVxuICAgIGNyZWF0ZUlucHV0TWF0cml4KCkge1xuICAgICAgICBjb25zdCB7IGlucHV0UmFuZ2UsIGlucHV0U2l6ZSB9ID0gdGhpcy5vcHRpb25zO1xuICAgICAgICBpZiAoaW5wdXRSYW5nZSA8IDEpXG4gICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ3RoaXMub3B0aW9ucy5pbnB1dFJhbmdlIG5vdCBhbiBleHBlY3RlZCBudW1iZXInKTtcbiAgICAgICAgaWYgKGlucHV0U2l6ZSA8IDEpXG4gICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ3RoaXMub3B0aW9ucy5pbnB1dFNpemUgbm90IGFuIGV4cGVjdGVkIG51bWJlcicpO1xuICAgICAgICAvLyAwIGlzIGVuZCwgc28gYWRkIDEgdG8gb2Zmc2V0XG4gICAgICAgIHJldHVybiBuZXcgUmFuZG9tTWF0cml4KGlucHV0UmFuZ2UgKyAxLCBpbnB1dFNpemUsIDAuMDgpO1xuICAgIH1cbiAgICBjcmVhdGVPdXRwdXRNYXRyaWNlcygpIHtcbiAgICAgICAgY29uc3QgeyBvdXRwdXRTaXplLCBoaWRkZW5MYXllcnMgfSA9IHRoaXMub3B0aW9ucztcbiAgICAgICAgY29uc3QgbGFzdEhpZGRlblNpemUgPSBsYXN0KGhpZGRlbkxheWVycyk7XG4gICAgICAgIC8vIDAgaXMgZW5kLCBzbyBhZGQgMSB0byBvZmZzZXRcbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgIC8vIHdoZFxuICAgICAgICAgICAgb3V0cHV0Q29ubmVjdG9yOiBuZXcgUmFuZG9tTWF0cml4KG91dHB1dFNpemUgKyAxLCBsYXN0SGlkZGVuU2l6ZSwgMC4wOCksXG4gICAgICAgICAgICAvLyAwIGlzIGVuZCwgc28gYWRkIDEgdG8gb2Zmc2V0XG4gICAgICAgICAgICAvLyBiZFxuICAgICAgICAgICAgb3V0cHV0OiBuZXcgTWF0cml4KG91dHB1dFNpemUgKyAxLCAxKSxcbiAgICAgICAgfTtcbiAgICB9XG4gICAgYmluZEVxdWF0aW9uKCkge1xuICAgICAgICBjb25zdCB7IG1vZGVsIH0gPSB0aGlzO1xuICAgICAgICBjb25zdCB7IGhpZGRlbkxheWVycyB9ID0gdGhpcy5vcHRpb25zO1xuICAgICAgICBjb25zdCBlcXVhdGlvbiA9IG5ldyBFcXVhdGlvbigpO1xuICAgICAgICBjb25zdCBvdXRwdXRzID0gW107XG4gICAgICAgIGNvbnN0IGVxdWF0aW9uQ29ubmVjdGlvbiA9IG1vZGVsLmVxdWF0aW9uQ29ubmVjdGlvbnMubGVuZ3RoID4gMFxuICAgICAgICAgICAgPyBsYXN0KG1vZGVsLmVxdWF0aW9uQ29ubmVjdGlvbnMpXG4gICAgICAgICAgICA6IHRoaXMuaW5pdGlhbExheWVySW5wdXRzO1xuICAgICAgICAvLyAwIGluZGV4XG4gICAgICAgIGxldCBvdXRwdXQgPSB0aGlzLmdldEVxdWF0aW9uKGVxdWF0aW9uLCBlcXVhdGlvbi5pbnB1dE1hdHJpeFRvUm93KG1vZGVsLmlucHV0KSwgZXF1YXRpb25Db25uZWN0aW9uWzBdLCBtb2RlbC5oaWRkZW5MYXllcnNbMF0pO1xuICAgICAgICBvdXRwdXRzLnB1c2gob3V0cHV0KTtcbiAgICAgICAgLy8gMSsgaW5kaWNlc1xuICAgICAgICBmb3IgKGxldCBpID0gMSwgbWF4ID0gaGlkZGVuTGF5ZXJzLmxlbmd0aDsgaSA8IG1heDsgaSsrKSB7XG4gICAgICAgICAgICBpZiAoIWVxdWF0aW9uQ29ubmVjdGlvbltpXSkge1xuICAgICAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcihgQ2Fubm90IGZpbmQgZXF1YXRpb24gYXQgaW5kZXggJHtpfWApO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgb3V0cHV0ID0gdGhpcy5nZXRFcXVhdGlvbihlcXVhdGlvbiwgb3V0cHV0LCBlcXVhdGlvbkNvbm5lY3Rpb25baV0sIG1vZGVsLmhpZGRlbkxheWVyc1tpXSk7XG4gICAgICAgICAgICBvdXRwdXRzLnB1c2gob3V0cHV0KTtcbiAgICAgICAgfVxuICAgICAgICBtb2RlbC5lcXVhdGlvbkNvbm5lY3Rpb25zLnB1c2gob3V0cHV0cyk7XG4gICAgICAgIGVxdWF0aW9uLmFkZChlcXVhdGlvbi5tdWx0aXBseShtb2RlbC5vdXRwdXRDb25uZWN0b3IsIG91dHB1dCksIG1vZGVsLm91dHB1dCk7XG4gICAgICAgIG1vZGVsLmVxdWF0aW9ucy5wdXNoKGVxdWF0aW9uKTtcbiAgICB9XG4gICAgbWFwTW9kZWwoKSB7XG4gICAgICAgIGNvbnN0IGFsbE1hdHJpY2VzID0gW107XG4gICAgICAgIHRoaXMuaW5pdGlhbExheWVySW5wdXRzID0gdGhpcy5vcHRpb25zLmhpZGRlbkxheWVycy5tYXAoKHNpemUpID0+IG5ldyBNYXRyaXgoc2l6ZSwgMSkpO1xuICAgICAgICBjb25zdCBpbnB1dCA9IHRoaXMuY3JlYXRlSW5wdXRNYXRyaXgoKTtcbiAgICAgICAgYWxsTWF0cmljZXMucHVzaChpbnB1dCk7XG4gICAgICAgIGNvbnN0IGhpZGRlbkxheWVycyA9IHRoaXMuY3JlYXRlSGlkZGVuTGF5ZXJzKCk7XG4gICAgICAgIGlmICghaGlkZGVuTGF5ZXJzLmxlbmd0aClcbiAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcignbmV0LmhpZGRlbkxheWVycyBub3Qgc2V0Jyk7XG4gICAgICAgIGZvciAobGV0IGkgPSAwLCBtYXggPSBoaWRkZW5MYXllcnMubGVuZ3RoOyBpIDwgbWF4OyBpKyspIHtcbiAgICAgICAgICAgIGNvbnN0IGhpZGRlbk1hdHJpeCA9IGhpZGRlbkxheWVyc1tpXTtcbiAgICAgICAgICAgIGZvciAoY29uc3QgcHJvcGVydHkgaW4gaGlkZGVuTWF0cml4KSB7XG4gICAgICAgICAgICAgICAgaWYgKCFoaWRkZW5NYXRyaXguaGFzT3duUHJvcGVydHkocHJvcGVydHkpKVxuICAgICAgICAgICAgICAgICAgICBjb250aW51ZTtcbiAgICAgICAgICAgICAgICBhbGxNYXRyaWNlcy5wdXNoKGhpZGRlbk1hdHJpeFtwcm9wZXJ0eV0pO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIGNvbnN0IHsgb3V0cHV0LCBvdXRwdXRDb25uZWN0b3IgfSA9IHRoaXMuY3JlYXRlT3V0cHV0TWF0cmljZXMoKTtcbiAgICAgICAgYWxsTWF0cmljZXMucHVzaChvdXRwdXRDb25uZWN0b3IpO1xuICAgICAgICBhbGxNYXRyaWNlcy5wdXNoKG91dHB1dCk7XG4gICAgICAgIHJldHVybiBPYmplY3Quc2VhbCh7XG4gICAgICAgICAgICBpc0luaXRpYWxpemVkOiB0cnVlLFxuICAgICAgICAgICAgaW5wdXQsXG4gICAgICAgICAgICBoaWRkZW5MYXllcnMsXG4gICAgICAgICAgICBvdXRwdXQsXG4gICAgICAgICAgICBlcXVhdGlvbnM6IFtdLFxuICAgICAgICAgICAgYWxsTWF0cmljZXMsXG4gICAgICAgICAgICBlcXVhdGlvbkNvbm5lY3Rpb25zOiBbXSxcbiAgICAgICAgICAgIG91dHB1dENvbm5lY3RvcixcbiAgICAgICAgfSk7XG4gICAgfVxuICAgIHRyYWluSW5wdXQoaW5wdXQpIHtcbiAgICAgICAgdGhpcy5ydW5zKys7XG4gICAgICAgIGNvbnN0IHsgbW9kZWwgfSA9IHRoaXM7XG4gICAgICAgIGNvbnN0IG1heCA9IGlucHV0Lmxlbmd0aDtcbiAgICAgICAgbGV0IGxvZzJwcGwgPSAwO1xuICAgICAgICBsZXQgZXF1YXRpb247XG4gICAgICAgIHdoaWxlIChtb2RlbC5lcXVhdGlvbnMubGVuZ3RoIDw9IGlucHV0Lmxlbmd0aCArIDEpIHtcbiAgICAgICAgICAgIC8vIGxhc3QgaXMgemVyb1xuICAgICAgICAgICAgdGhpcy5iaW5kRXF1YXRpb24oKTtcbiAgICAgICAgfVxuICAgICAgICBmb3IgKGxldCBpbnB1dEluZGV4ID0gLTEsIGlucHV0TWF4ID0gaW5wdXQubGVuZ3RoOyBpbnB1dEluZGV4IDwgaW5wdXRNYXg7IGlucHV0SW5kZXgrKykge1xuICAgICAgICAgICAgLy8gc3RhcnQgYW5kIGVuZCB0b2tlbnMgYXJlIHplcm9zXG4gICAgICAgICAgICBjb25zdCBlcXVhdGlvbkluZGV4ID0gaW5wdXRJbmRleCArIDE7XG4gICAgICAgICAgICBlcXVhdGlvbiA9IG1vZGVsLmVxdWF0aW9uc1tlcXVhdGlvbkluZGV4XTtcbiAgICAgICAgICAgIGNvbnN0IHNvdXJjZSA9IGlucHV0SW5kZXggPT09IC0xID8gMCA6IGlucHV0W2lucHV0SW5kZXhdICsgMTsgLy8gZmlyc3Qgc3RlcDogc3RhcnQgd2l0aCBTVEFSVCB0b2tlblxuICAgICAgICAgICAgY29uc3QgdGFyZ2V0ID0gaW5wdXRJbmRleCA9PT0gbWF4IC0gMSA/IDAgOiBpbnB1dFtpbnB1dEluZGV4ICsgMV0gKyAxOyAvLyBsYXN0IHN0ZXA6IGVuZCB3aXRoIEVORCB0b2tlblxuICAgICAgICAgICAgbG9nMnBwbCArPSBlcXVhdGlvbi5wcmVkaWN0VGFyZ2V0SW5kZXgoc291cmNlLCB0YXJnZXQpO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBNYXRoLnBvdygyLCBsb2cycHBsIC8gKG1heCAtIDEpKSAvIDEwMDtcbiAgICB9XG4gICAgYmFja3Byb3BhZ2F0ZShpbnB1dCkge1xuICAgICAgICBsZXQgaSA9IGlucHV0Lmxlbmd0aDtcbiAgICAgICAgY29uc3QgeyBtb2RlbCB9ID0gdGhpcztcbiAgICAgICAgY29uc3QgeyBlcXVhdGlvbnMgfSA9IG1vZGVsO1xuICAgICAgICB3aGlsZSAoaSA+IDApIHtcbiAgICAgICAgICAgIGVxdWF0aW9uc1tpXS5iYWNrcHJvcGFnYXRlSW5kZXgoaW5wdXRbaSAtIDFdICsgMSk7XG4gICAgICAgICAgICBpLS07XG4gICAgICAgIH1cbiAgICAgICAgZXF1YXRpb25zWzBdLmJhY2twcm9wYWdhdGVJbmRleCgwKTtcbiAgICB9XG4gICAgYWRqdXN0V2VpZ2h0cygpIHtcbiAgICAgICAgY29uc3QgeyByZWdjLCBjbGlwdmFsLCBkZWNheVJhdGUsIHNtb290aEVwcyB9ID0gdGhpcy5vcHRpb25zO1xuICAgICAgICBjb25zdCB7IHRyYWluT3B0cywgbW9kZWwsIHN0ZXBDYWNoZSB9ID0gdGhpcztcbiAgICAgICAgY29uc3QgeyBsZWFybmluZ1JhdGUgfSA9IHRyYWluT3B0cztcbiAgICAgICAgY29uc3QgeyBhbGxNYXRyaWNlcyB9ID0gbW9kZWw7XG4gICAgICAgIGxldCBudW1DbGlwcGVkID0gMDtcbiAgICAgICAgbGV0IG51bVRvdCA9IDA7XG4gICAgICAgIGZvciAobGV0IG1hdHJpeEluZGV4ID0gMDsgbWF0cml4SW5kZXggPCBhbGxNYXRyaWNlcy5sZW5ndGg7IG1hdHJpeEluZGV4KyspIHtcbiAgICAgICAgICAgIGNvbnN0IG1hdHJpeCA9IGFsbE1hdHJpY2VzW21hdHJpeEluZGV4XTtcbiAgICAgICAgICAgIGNvbnN0IHsgd2VpZ2h0cywgZGVsdGFzIH0gPSBtYXRyaXg7XG4gICAgICAgICAgICBpZiAoIShtYXRyaXhJbmRleCBpbiBzdGVwQ2FjaGUpKSB7XG4gICAgICAgICAgICAgICAgc3RlcENhY2hlW21hdHJpeEluZGV4XSA9IHplcm9zJDEobWF0cml4LnJvd3MgKiBtYXRyaXguY29sdW1ucyk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBjb25zdCBjYWNoZSA9IHN0ZXBDYWNoZVttYXRyaXhJbmRleF07XG4gICAgICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IHdlaWdodHMubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgICAgICAgICBsZXQgciA9IGRlbHRhc1tpXTtcbiAgICAgICAgICAgICAgICBjb25zdCB3ID0gd2VpZ2h0c1tpXTtcbiAgICAgICAgICAgICAgICAvLyBybXNwcm9wIGFkYXB0aXZlIGxlYXJuaW5nIHJhdGVcbiAgICAgICAgICAgICAgICBjYWNoZVtpXSA9IGNhY2hlW2ldICogZGVjYXlSYXRlICsgKDEgLSBkZWNheVJhdGUpICogciAqIHI7XG4gICAgICAgICAgICAgICAgLy8gZ3JhZGllbnQgY2xpcFxuICAgICAgICAgICAgICAgIGlmIChyID4gY2xpcHZhbCkge1xuICAgICAgICAgICAgICAgICAgICByID0gY2xpcHZhbDtcbiAgICAgICAgICAgICAgICAgICAgbnVtQ2xpcHBlZCsrO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBlbHNlIGlmIChyIDwgLWNsaXB2YWwpIHtcbiAgICAgICAgICAgICAgICAgICAgciA9IC1jbGlwdmFsO1xuICAgICAgICAgICAgICAgICAgICBudW1DbGlwcGVkKys7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIG51bVRvdCsrO1xuICAgICAgICAgICAgICAgIC8vIHVwZGF0ZSAoYW5kIHJlZ3VsYXJpemUpXG4gICAgICAgICAgICAgICAgd2VpZ2h0c1tpXSA9XG4gICAgICAgICAgICAgICAgICAgIHcgKyAoLWxlYXJuaW5nUmF0ZSAqIHIpIC8gTWF0aC5zcXJ0KGNhY2hlW2ldICsgc21vb3RoRXBzKSAtIHJlZ2MgKiB3O1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIHRoaXMucmF0aW9DbGlwcGVkID0gbnVtQ2xpcHBlZCAvIG51bVRvdDtcbiAgICB9XG4gICAgZ2V0IGlzUnVubmFibGUoKSB7XG4gICAgICAgIGlmICh0aGlzLm1vZGVsICYmIHRoaXMubW9kZWwuZXF1YXRpb25zLmxlbmd0aCA9PT0gMCkge1xuICAgICAgICAgICAgY29uc29sZS5lcnJvcihgTm8gZXF1YXRpb25zIGJvdW5kLCBkaWQgeW91IHJ1biB0cmFpbigpP2ApO1xuICAgICAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiB0cnVlO1xuICAgIH1cbiAgICBjaGVja1J1bm5hYmxlKCkge1xuICAgICAgICBpZiAoIXRoaXMuaXNSdW5uYWJsZSkge1xuICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdOZXR3b3JrIG5vdCBydW5uYWJsZScpO1xuICAgICAgICB9XG4gICAgfVxuICAgIHJ1bihyYXdJbnB1dCA9IFtdLCBpc1NhbXBsZUkgPSBmYWxzZSwgdGVtcGVyYXR1cmUgPSAxKSB7XG4gICAgICAgIGNvbnN0IG1heFByZWRpY3Rpb25MZW5ndGggPSB0aGlzLm9wdGlvbnMubWF4UHJlZGljdGlvbkxlbmd0aCArXG4gICAgICAgICAgICAocmF3SW5wdXQgIT09IG51bGwgPyByYXdJbnB1dC5sZW5ndGggOiAwKSArXG4gICAgICAgICAgICAodGhpcy5vcHRpb25zLmRhdGFGb3JtYXR0ZXJcbiAgICAgICAgICAgICAgICA/IHRoaXMub3B0aW9ucy5kYXRhRm9ybWF0dGVyLnNwZWNpYWxJbmRleGVzLmxlbmd0aFxuICAgICAgICAgICAgICAgIDogMCk7XG4gICAgICAgIHRoaXMuY2hlY2tSdW5uYWJsZSgpO1xuICAgICAgICBjb25zdCBpbnB1dCA9IHRoaXMub3B0aW9ucy5kYXRhRm9ybWF0dGVyICYmIHJhd0lucHV0Lmxlbmd0aCA+IDBcbiAgICAgICAgICAgID8gdGhpcy5vcHRpb25zLmRhdGFGb3JtYXR0ZXIuZm9ybWF0RGF0YUluKHJhd0lucHV0KVxuICAgICAgICAgICAgOiByYXdJbnB1dDtcbiAgICAgICAgY29uc3QgeyBtb2RlbCB9ID0gdGhpcztcbiAgICAgICAgY29uc3Qgb3V0cHV0ID0gW107XG4gICAgICAgIGxldCBpID0gMDtcbiAgICAgICAgd2hpbGUgKHRydWUpIHtcbiAgICAgICAgICAgIGNvbnN0IHByZXZpb3VzSW5kZXggPSBpID09PSAwID8gMCA6IGkgPCBpbnB1dC5sZW5ndGggPyBpbnB1dFtpIC0gMV0gKyAxIDogb3V0cHV0W2kgLSAxXTtcbiAgICAgICAgICAgIHdoaWxlIChtb2RlbC5lcXVhdGlvbnMubGVuZ3RoIDw9IGkpIHtcbiAgICAgICAgICAgICAgICB0aGlzLmJpbmRFcXVhdGlvbigpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgY29uc3QgZXF1YXRpb24gPSBtb2RlbC5lcXVhdGlvbnNbaV07XG4gICAgICAgICAgICAvLyBzYW1wbGUgcHJlZGljdGVkIGxldHRlclxuICAgICAgICAgICAgY29uc3Qgb3V0cHV0TWF0cml4ID0gZXF1YXRpb24ucnVuSW5kZXgocHJldmlvdXNJbmRleCk7XG4gICAgICAgICAgICBjb25zdCBsb2dQcm9iYWJpbGl0aWVzID0gbmV3IE1hdHJpeChtb2RlbC5vdXRwdXQucm93cywgbW9kZWwub3V0cHV0LmNvbHVtbnMpO1xuICAgICAgICAgICAgY29weShsb2dQcm9iYWJpbGl0aWVzLCBvdXRwdXRNYXRyaXgpO1xuICAgICAgICAgICAgaWYgKHRlbXBlcmF0dXJlICE9PSAxICYmIGlzU2FtcGxlSSkge1xuICAgICAgICAgICAgICAgIC8qKlxuICAgICAgICAgICAgICAgICAqIHNjYWxlIGxvZyBwcm9iYWJpbGl0aWVzIGJ5IHRlbXBlcmF0dXJlIGFuZCByZS1ub3JtYWxpemVcbiAgICAgICAgICAgICAgICAgKiBpZiB0ZW1wZXJhdHVyZSBpcyBoaWdoLCBsb2dQcm9iYWJpbGl0aWVzIHdpbGwgZ28gdG93YXJkcyB6ZXJvXG4gICAgICAgICAgICAgICAgICogYW5kIHRoZSBzb2Z0bWF4IG91dHB1dHMgd2lsbCBiZSBtb3JlIGRpZmZ1c2UuIGlmIHRlbXBlcmF0dXJlIGlzXG4gICAgICAgICAgICAgICAgICogdmVyeSBsb3csIHRoZSBzb2Z0bWF4IG91dHB1dHMgd2lsbCBiZSBtb3JlIHBlYWt5XG4gICAgICAgICAgICAgICAgICovXG4gICAgICAgICAgICAgICAgZm9yIChsZXQgaiA9IDAsIG1heCA9IGxvZ1Byb2JhYmlsaXRpZXMud2VpZ2h0cy5sZW5ndGg7IGogPCBtYXg7IGorKykge1xuICAgICAgICAgICAgICAgICAgICBsb2dQcm9iYWJpbGl0aWVzLndlaWdodHNbal0gLz0gdGVtcGVyYXR1cmU7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgY29uc3QgcHJvYnMgPSBzb2Z0bWF4KGxvZ1Byb2JhYmlsaXRpZXMpO1xuICAgICAgICAgICAgY29uc3QgbmV4dEluZGV4ID0gaXNTYW1wbGVJID8gc2FtcGxlSShwcm9icykgOiBtYXhJKHByb2JzKTtcbiAgICAgICAgICAgIGkrKztcbiAgICAgICAgICAgIGlmIChuZXh0SW5kZXggPT09IDApIHtcbiAgICAgICAgICAgICAgICAvLyBFTkQgdG9rZW4gcHJlZGljdGVkLCBicmVhayBvdXRcbiAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGlmIChpID49IG1heFByZWRpY3Rpb25MZW5ndGgpIHtcbiAgICAgICAgICAgICAgICAvLyBzb21ldGhpbmcgaXMgd3JvbmdcbiAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIG91dHB1dC5wdXNoKG5leHRJbmRleCk7XG4gICAgICAgIH1cbiAgICAgICAgLyoqXG4gICAgICAgICAqIHdlIHNsaWNlIHRoZSBpbnB1dCBsZW5ndGggaGVyZSwgbm90IGJlY2F1c2Ugb3V0cHV0IGNvbnRhaW5zIGl0LCBidXQgaXQgd2lsbCBiZSBlcnJvbmVvdXMgYXMgd2UgYXJlIHNlbmRpbmcgdGhlXG4gICAgICAgICAqIG5ldHdvcmsgd2hhdCBpcyBjb250YWluZWQgaW4gaW5wdXQsIHNvIHRoZSBkYXRhIGlzIGVzc2VudGlhbGx5IGd1ZXNzZWQgYnkgdGhlIG5ldHdvcmsgd2hhdCBjb3VsZCBiZSBuZXh0LCB0aWxsIGl0XG4gICAgICAgICAqIGxvY2tzIGluIG9uIGEgdmFsdWUuXG4gICAgICAgICAqIEtpbmQgb2YgbGlrZSB0aGlzLCB2YWx1ZXMgYXJlIGZyb20gaW5wdXQ6XG4gICAgICAgICAqIDAgLT4gNCAob3IgaW4gRW5nbGlzaDogXCJiZWdpbm5pbmcgb24gaW5wdXRcIiAtPiBcIkkgaGF2ZSBubyBpZGVhPyBJJ2xsIGd1ZXNzIHdoYXQgdGhleSB3YW50IG5leHQhXCIpXG4gICAgICAgICAqIDIgLT4gMiAob2ggaG93IGludGVyZXN0aW5nLCBJJ3ZlIG5hcnJvd2VkIGRvd24gdmFsdWVzLi4uKVxuICAgICAgICAgKiAxIC0+IDkgKG9oIGhvdyBpbnRlcmVzdGluZywgSSd2ZSBub3cga25vdyB3aGF0IHRoZSB2YWx1ZXMgYXJlLi4uKVxuICAgICAgICAgKiB0aGVuIHRoZSBvdXRwdXQgbG9va3MgbGlrZTogWzQsIDIsIDksLi4uXVxuICAgICAgICAgKiBzbyB3ZSB0aGVuIHJlbW92ZSB0aGUgZXJyb25lb3VzIGRhdGEgdG8gZ2V0IG91ciB0cnVlIG91dHB1dFxuICAgICAgICAgKi9cbiAgICAgICAgcmV0dXJuIHRoaXMub3B0aW9ucy5kYXRhRm9ybWF0dGVyLmZvcm1hdERhdGFPdXQoaW5wdXQsIG91dHB1dC5zbGljZShpbnB1dC5sZW5ndGgpLm1hcCgodmFsdWUpID0+IHZhbHVlIC0gMSkpO1xuICAgIH1cbiAgICAvKipcbiAgICAgKlxuICAgICAqIFZlcmlmaWVzIG5ldHdvcmsgc2l6ZXMgYXJlIGluaXRpYWxpemVkXG4gICAgICogSWYgdGhleSBhcmUgbm90IGl0IHdpbGwgaW5pdGlhbGl6ZSB0aGVtXG4gICAgICovXG4gICAgdmVyaWZ5SXNJbml0aWFsaXplZCgpIHtcbiAgICAgICAgaWYgKCF0aGlzLm1vZGVsLmlzSW5pdGlhbGl6ZWQpIHtcbiAgICAgICAgICAgIHRoaXMuaW5pdGlhbGl6ZSgpO1xuICAgICAgICB9XG4gICAgfVxuICAgIC8qKlxuICAgICAqXG4gICAgICogQHBhcmFtIG9wdGlvbnNcbiAgICAgKiAgICBTdXBwb3J0cyBhbGwgYHRyYWluRGVmYXVsdHNgIHByb3BlcnRpZXNcbiAgICAgKiAgICBhbHNvIHN1cHBvcnRzOlxuICAgICAqICAgICAgIGxlYXJuaW5nUmF0ZTogKG51bWJlciksXG4gICAgICogICAgICAgbW9tZW50dW06IChudW1iZXIpLFxuICAgICAqICAgICAgIGFjdGl2YXRpb246ICdzaWdtb2lkJywgJ3JlbHUnLCAnbGVha3ktcmVsdScsICd0YW5oJ1xuICAgICAqL1xuICAgIHVwZGF0ZVRyYWluaW5nT3B0aW9ucyhvcHRpb25zKSB7XG4gICAgICAgIHZhciBfYTtcbiAgICAgICAgdGhpcy50cmFpbk9wdHMgPSB7IC4uLnRyYWluRGVmYXVsdHMkMSwgLi4ub3B0aW9ucyB9O1xuICAgICAgICB0aGlzLnZhbGlkYXRlVHJhaW5pbmdPcHRpb25zKHRoaXMudHJhaW5PcHRzKTtcbiAgICAgICAgdGhpcy5zZXRMb2dNZXRob2QoKF9hID0gb3B0aW9ucy5sb2cpICE9PSBudWxsICYmIF9hICE9PSB2b2lkIDAgPyBfYSA6IHRoaXMudHJhaW5PcHRzLmxvZyk7XG4gICAgICAgIC8vIFRPRE86IFJlbW92ZSB0aGlzP1xuICAgICAgICAvLyB0aGlzLmFjdGl2YXRpb24gPSBvcHRpb25zLmFjdGl2YXRpb24gfHwgdGhpcy5hY3RpdmF0aW9uO1xuICAgIH1cbiAgICB2YWxpZGF0ZVRyYWluaW5nT3B0aW9ucyhvcHRpb25zKSB7XG4gICAgICAgIGNvbnN0IHZhbGlkYXRpb25zID0ge1xuICAgICAgICAgICAgaXRlcmF0aW9uczogKCkgPT4ge1xuICAgICAgICAgICAgICAgIGNvbnN0IHZhbCA9IG9wdGlvbnMuaXRlcmF0aW9ucztcbiAgICAgICAgICAgICAgICByZXR1cm4gdHlwZW9mIHZhbCA9PT0gJ251bWJlcicgJiYgdmFsID4gMDtcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBlcnJvclRocmVzaDogKCkgPT4ge1xuICAgICAgICAgICAgICAgIGNvbnN0IHZhbCA9IG9wdGlvbnMuZXJyb3JUaHJlc2g7XG4gICAgICAgICAgICAgICAgcmV0dXJuIHR5cGVvZiB2YWwgPT09ICdudW1iZXInICYmIHZhbCA+IDAgJiYgdmFsIDwgMTtcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBsb2c6ICgpID0+IHtcbiAgICAgICAgICAgICAgICBjb25zdCB2YWwgPSBvcHRpb25zLmxvZztcbiAgICAgICAgICAgICAgICByZXR1cm4gdHlwZW9mIHZhbCA9PT0gJ2Z1bmN0aW9uJyB8fCB0eXBlb2YgdmFsID09PSAnYm9vbGVhbic7XG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgbG9nUGVyaW9kOiAoKSA9PiB7XG4gICAgICAgICAgICAgICAgY29uc3QgdmFsID0gb3B0aW9ucy5sb2dQZXJpb2Q7XG4gICAgICAgICAgICAgICAgcmV0dXJuIHR5cGVvZiB2YWwgPT09ICdudW1iZXInICYmIHZhbCA+IDA7XG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgbGVhcm5pbmdSYXRlOiAoKSA9PiB7XG4gICAgICAgICAgICAgICAgY29uc3QgdmFsID0gb3B0aW9ucy5sZWFybmluZ1JhdGU7XG4gICAgICAgICAgICAgICAgcmV0dXJuIHR5cGVvZiB2YWwgPT09ICdudW1iZXInICYmIHZhbCA+IDAgJiYgdmFsIDwgMTtcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBjYWxsYmFjazogKCkgPT4ge1xuICAgICAgICAgICAgICAgIGNvbnN0IHZhbCA9IG9wdGlvbnMuY2FsbGJhY2s7XG4gICAgICAgICAgICAgICAgcmV0dXJuIHR5cGVvZiB2YWwgPT09ICdmdW5jdGlvbicgfHwgdmFsID09PSB1bmRlZmluZWQ7XG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgY2FsbGJhY2tQZXJpb2Q6ICgpID0+IHtcbiAgICAgICAgICAgICAgICBjb25zdCB2YWwgPSBvcHRpb25zLmNhbGxiYWNrUGVyaW9kO1xuICAgICAgICAgICAgICAgIHJldHVybiB0eXBlb2YgdmFsID09PSAnbnVtYmVyJyAmJiB2YWwgPiAwO1xuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIHRpbWVvdXQ6ICgpID0+IHtcbiAgICAgICAgICAgICAgICBjb25zdCB2YWwgPSBvcHRpb25zLnRpbWVvdXQ7XG4gICAgICAgICAgICAgICAgcmV0dXJuIHR5cGVvZiB2YWwgPT09ICdudW1iZXInICYmIHZhbCA+IDA7XG4gICAgICAgICAgICB9LFxuICAgICAgICB9O1xuICAgICAgICBmb3IgKGNvbnN0IHAgaW4gdmFsaWRhdGlvbnMpIHtcbiAgICAgICAgICAgIGNvbnN0IHYgPSBvcHRpb25zO1xuICAgICAgICAgICAgaWYgKCF2YWxpZGF0aW9uc1twXSgpKSB7XG4gICAgICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKGBbJHtwfSwgJHt2W3BdfV0gaXMgb3V0IG9mIG5vcm1hbCB0cmFpbmluZyByYW5nZSwgeW91ciBuZXR3b3JrIHdpbGwgcHJvYmFibHkgbm90IHRyYWluLmApO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfVxuICAgIHNldExvZ01ldGhvZChsb2cpIHtcbiAgICAgICAgaWYgKHR5cGVvZiBsb2cgPT09ICdmdW5jdGlvbicpIHtcbiAgICAgICAgICAgIHRoaXMudHJhaW5PcHRzLmxvZyA9IGxvZztcbiAgICAgICAgfVxuICAgICAgICBlbHNlIGlmIChsb2cpIHtcbiAgICAgICAgICAgIHRoaXMudHJhaW5PcHRzLmxvZyA9IGNvbnNvbGUubG9nO1xuICAgICAgICB9XG4gICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgdGhpcy50cmFpbk9wdHMubG9nID0gZmFsc2U7XG4gICAgICAgIH1cbiAgICB9XG4gICAgcHJlcFRyYWluaW5nKGRhdGEsIG9wdGlvbnMpIHtcbiAgICAgICAgdmFyIF9hO1xuICAgICAgICB0aGlzLnVwZGF0ZVRyYWluaW5nT3B0aW9ucyhvcHRpb25zKTtcbiAgICAgICAgY29uc3QgcHJlcGFyZWREYXRhID0gdGhpcy5vcHRpb25zLmRhdGFGb3JtYXR0ZXIuZm9ybWF0KGRhdGEpO1xuICAgICAgICBjb25zdCBlbmRUaW1lID0gRGF0ZS5ub3coKSArICgoX2EgPSB0aGlzLnRyYWluT3B0cy50aW1lb3V0KSAhPT0gbnVsbCAmJiBfYSAhPT0gdm9pZCAwID8gX2EgOiAwKTtcbiAgICAgICAgY29uc3Qgc3RhdHVzID0ge1xuICAgICAgICAgICAgZXJyb3I6IDEsXG4gICAgICAgICAgICBpdGVyYXRpb25zOiAwLFxuICAgICAgICB9O1xuICAgICAgICB0aGlzLnZlcmlmeUlzSW5pdGlhbGl6ZWQoKTtcbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgIHByZXBhcmVkRGF0YSxcbiAgICAgICAgICAgIHN0YXR1cyxcbiAgICAgICAgICAgIGVuZFRpbWUsXG4gICAgICAgIH07XG4gICAgfVxuICAgIHRyYWluKGRhdGEsIHRyYWluT3B0cyA9IHt9KSB7XG4gICAgICAgIHZhciBfYTtcbiAgICAgICAgdGhpcy50cmFpbk9wdHMgPSB0cmFpbk9wdHMgPSB7XG4gICAgICAgICAgICAuLi50cmFpbkRlZmF1bHRzJDEsXG4gICAgICAgICAgICAuLi50cmFpbk9wdHMsXG4gICAgICAgIH07XG4gICAgICAgIGNvbnN0IHsgaXRlcmF0aW9ucywgZXJyb3JUaHJlc2gsIGxvZ1BlcmlvZCwgY2FsbGJhY2ssIGNhbGxiYWNrUGVyaW9kLCB9ID0gdGhpcy50cmFpbk9wdHM7XG4gICAgICAgIGNvbnN0IGxvZyA9IHRyYWluT3B0cy5sb2cgPT09IHRydWUgPyBjb25zb2xlLmxvZyA6IHRyYWluT3B0cy5sb2c7XG4gICAgICAgIGxldCBlcnJvciA9IEluZmluaXR5O1xuICAgICAgICBsZXQgaTtcbiAgICAgICAgbGV0IGlucHV0cztcbiAgICAgICAgaWYgKChfYSA9IHRoaXMub3B0aW9ucykgPT09IG51bGwgfHwgX2EgPT09IHZvaWQgMCA/IHZvaWQgMCA6IF9hLmRhdGFGb3JtYXR0ZXIpIHtcbiAgICAgICAgICAgIGlucHV0cyA9IHRoaXMub3B0aW9ucy5kYXRhRm9ybWF0dGVyLmZvcm1hdChkYXRhKTtcbiAgICAgICAgfVxuICAgICAgICBlbHNlIGlmIChBcnJheS5pc0FycmF5KGRhdGEpICYmXG4gICAgICAgICAgICBBcnJheS5pc0FycmF5KGRhdGFbMF0pICYmXG4gICAgICAgICAgICB0eXBlb2YgZGF0YVswXVswXSA9PT0gJ251bWJlcicpIHtcbiAgICAgICAgICAgIGlucHV0cyA9IGRhdGE7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ3RyYWluaW5nIG5vdCBpbiBleHBlY3RlZCBmb3JtYXQgb2YgbnVtYmVyW11bXScpO1xuICAgICAgICB9XG4gICAgICAgIHRoaXMudmVyaWZ5SXNJbml0aWFsaXplZCgpO1xuICAgICAgICBmb3IgKGkgPSAwOyBpIDwgaXRlcmF0aW9ucyAmJiBlcnJvciA+IGVycm9yVGhyZXNoOyBpKyspIHtcbiAgICAgICAgICAgIGxldCBzdW0gPSAwO1xuICAgICAgICAgICAgZm9yIChsZXQgaiA9IDA7IGogPCBpbnB1dHMubGVuZ3RoOyBqKyspIHtcbiAgICAgICAgICAgICAgICBjb25zdCBlcnIgPSB0aGlzLnRyYWluUGF0dGVybihpbnB1dHNbal0sIHRydWUpO1xuICAgICAgICAgICAgICAgIHN1bSArPSBlcnI7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBlcnJvciA9IHN1bSAvIGRhdGEubGVuZ3RoO1xuICAgICAgICAgICAgaWYgKGlzTmFOKGVycm9yKSkge1xuICAgICAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcignTmV0d29yayBlcnJvciByYXRlIGlzIHVuZXhwZWN0ZWQgTmFOLCBjaGVjayBuZXR3b3JrIGNvbmZpZ3VyYXRpb25zIGFuZCB0cnkgYWdhaW4uIE1vc3QgcHJvYmFibHkgaW5wdXQgZm9ybWF0IGlzIG5vdCBjb3JyZWN0IG9yIHRyYWluaW5nIGRhdGEgaXMgbm90IGVub3VnaC4gJyk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBpZiAobG9nICYmIGkgJSBsb2dQZXJpb2QgPT09IDApIHtcbiAgICAgICAgICAgICAgICBsb2coYGl0ZXJhdGlvbnM6ICR7aX0sIHRyYWluaW5nIGVycm9yOiAke2Vycm9yfWApO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaWYgKGNhbGxiYWNrICYmIGkgJSBjYWxsYmFja1BlcmlvZCA9PT0gMCkge1xuICAgICAgICAgICAgICAgIGNhbGxiYWNrKHsgZXJyb3IsIGl0ZXJhdGlvbnM6IGkgfSk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgIGVycm9yLFxuICAgICAgICAgICAgaXRlcmF0aW9uczogaSxcbiAgICAgICAgfTtcbiAgICB9XG4gICAgYWRkRm9ybWF0KCkge1xuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ25vdCB5ZXQgaW1wbGVtZW50ZWQnKTtcbiAgICB9XG4gICAgdG9KU09OKCkge1xuICAgICAgICBpZiAoIXRoaXMubW9kZWwuaXNJbml0aWFsaXplZCkge1xuICAgICAgICAgICAgdGhpcy5pbml0aWFsaXplKCk7XG4gICAgICAgIH1cbiAgICAgICAgY29uc3QgeyBtb2RlbCwgb3B0aW9ucyB9ID0gdGhpcztcbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgIHR5cGU6IHRoaXMuY29uc3RydWN0b3IubmFtZSxcbiAgICAgICAgICAgIG9wdGlvbnM6IHsgLi4ub3B0aW9ucywgZGF0YUZvcm1hdHRlcjogb3B0aW9ucy5kYXRhRm9ybWF0dGVyLnRvSlNPTigpIH0sXG4gICAgICAgICAgICB0cmFpbk9wdHM6IHtcbiAgICAgICAgICAgICAgICAuLi50aGlzLnRyYWluT3B0cyxcbiAgICAgICAgICAgICAgICB0aW1lb3V0OiB0aGlzLnRyYWluT3B0cy50aW1lb3V0ID09PSBJbmZpbml0eVxuICAgICAgICAgICAgICAgICAgICA/ICdJbmZpbml0eSdcbiAgICAgICAgICAgICAgICAgICAgOiB0aGlzLnRyYWluT3B0cy50aW1lb3V0LFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIGlucHV0OiBtb2RlbC5pbnB1dC50b0pTT04oKSxcbiAgICAgICAgICAgIGhpZGRlbkxheWVyczogbW9kZWwuaGlkZGVuTGF5ZXJzLm1hcCgoaGlkZGVuTGF5ZXIpID0+IHtcbiAgICAgICAgICAgICAgICBjb25zdCBsYXllcnMgPSB7fTtcbiAgICAgICAgICAgICAgICBmb3IgKGNvbnN0IHAgaW4gaGlkZGVuTGF5ZXIpIHtcbiAgICAgICAgICAgICAgICAgICAgaWYgKCFoaWRkZW5MYXllci5oYXNPd25Qcm9wZXJ0eShwKSlcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnRpbnVlO1xuICAgICAgICAgICAgICAgICAgICBsYXllcnNbcF0gPSBoaWRkZW5MYXllcltwXS50b0pTT04oKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgcmV0dXJuIGxheWVycztcbiAgICAgICAgICAgIH0pLFxuICAgICAgICAgICAgb3V0cHV0Q29ubmVjdG9yOiB0aGlzLm1vZGVsLm91dHB1dENvbm5lY3Rvci50b0pTT04oKSxcbiAgICAgICAgICAgIG91dHB1dDogdGhpcy5tb2RlbC5vdXRwdXQudG9KU09OKCksXG4gICAgICAgIH07XG4gICAgfVxuICAgIGZyb21KU09OKGpzb24pIHtcbiAgICAgICAgY29uc3QgeyBvcHRpb25zIH0gPSBqc29uO1xuICAgICAgICBjb25zdCBhbGxNYXRyaWNlcyA9IFtdO1xuICAgICAgICBjb25zdCBpbnB1dCA9IE1hdHJpeC5mcm9tSlNPTihqc29uLmlucHV0KTtcbiAgICAgICAgYWxsTWF0cmljZXMucHVzaChpbnB1dCk7XG4gICAgICAgIGNvbnN0IGhpZGRlbkxheWVycyA9IFtdO1xuICAgICAgICBqc29uLmhpZGRlbkxheWVycy5mb3JFYWNoKChoaWRkZW5MYXllcikgPT4ge1xuICAgICAgICAgICAgY29uc3QgbGF5ZXJzID0ge307XG4gICAgICAgICAgICBmb3IgKGNvbnN0IHAgaW4gaGlkZGVuTGF5ZXIpIHtcbiAgICAgICAgICAgICAgICBsYXllcnNbcF0gPSBNYXRyaXguZnJvbUpTT04oaGlkZGVuTGF5ZXJbcF0pO1xuICAgICAgICAgICAgICAgIGFsbE1hdHJpY2VzLnB1c2gobGF5ZXJzW3BdKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGhpZGRlbkxheWVycy5wdXNoKGxheWVycyk7XG4gICAgICAgIH0pO1xuICAgICAgICBjb25zdCBvdXRwdXRDb25uZWN0b3IgPSBNYXRyaXguZnJvbUpTT04oanNvbi5vdXRwdXRDb25uZWN0b3IpO1xuICAgICAgICBhbGxNYXRyaWNlcy5wdXNoKG91dHB1dENvbm5lY3Rvcik7XG4gICAgICAgIGNvbnN0IG91dHB1dCA9IE1hdHJpeC5mcm9tSlNPTihqc29uLm91dHB1dCk7XG4gICAgICAgIGFsbE1hdHJpY2VzLnB1c2gob3V0cHV0KTtcbiAgICAgICAgaWYgKG9wdGlvbnMuZGF0YUZvcm1hdHRlcikge1xuICAgICAgICAgICAgdGhpcy5vcHRpb25zID0ge1xuICAgICAgICAgICAgICAgIC4uLmRlZmF1bHRzJDEoKSxcbiAgICAgICAgICAgICAgICAuLi5vcHRpb25zLFxuICAgICAgICAgICAgICAgIGRhdGFGb3JtYXR0ZXI6IERhdGFGb3JtYXR0ZXIuZnJvbUpTT04ob3B0aW9ucy5kYXRhRm9ybWF0dGVyKSxcbiAgICAgICAgICAgIH07XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICB0aGlzLm9wdGlvbnMgPSB7XG4gICAgICAgICAgICAgICAgLi4uZGVmYXVsdHMkMSgpLFxuICAgICAgICAgICAgICAgIC4uLm9wdGlvbnMsXG4gICAgICAgICAgICAgICAgZGF0YUZvcm1hdHRlcjogbmV3IERhdGFGb3JtYXR0ZXIoKSxcbiAgICAgICAgICAgIH07XG4gICAgICAgIH1cbiAgICAgICAgdGhpcy5tb2RlbCA9IE9iamVjdC5zZWFsKHtcbiAgICAgICAgICAgIGlzSW5pdGlhbGl6ZWQ6IHRydWUsXG4gICAgICAgICAgICBpbnB1dCxcbiAgICAgICAgICAgIGhpZGRlbkxheWVycyxcbiAgICAgICAgICAgIG91dHB1dCxcbiAgICAgICAgICAgIGFsbE1hdHJpY2VzLFxuICAgICAgICAgICAgb3V0cHV0Q29ubmVjdG9yLFxuICAgICAgICAgICAgZXF1YXRpb25zOiBbXSxcbiAgICAgICAgICAgIGVxdWF0aW9uQ29ubmVjdGlvbnM6IFtdLFxuICAgICAgICB9KTtcbiAgICAgICAgdGhpcy5pbml0aWFsTGF5ZXJJbnB1dHMgPSB0aGlzLm9wdGlvbnMuaGlkZGVuTGF5ZXJzLm1hcCgoc2l6ZSkgPT4gbmV3IE1hdHJpeChzaXplLCAxKSk7XG4gICAgICAgIHRoaXMuYmluZEVxdWF0aW9uKCk7XG4gICAgICAgIHJldHVybiB0aGlzO1xuICAgIH1cbiAgICB0b0Z1bmN0aW9uKGNiKSB7XG4gICAgICAgIGNvbnN0IHsgbW9kZWwgfSA9IHRoaXM7XG4gICAgICAgIGNvbnN0IHsgZXF1YXRpb25zIH0gPSB0aGlzLm1vZGVsO1xuICAgICAgICBjb25zdCBlcXVhdGlvbiA9IGVxdWF0aW9uc1sxXTtcbiAgICAgICAgY29uc3QgeyBzdGF0ZXMgfSA9IGVxdWF0aW9uO1xuICAgICAgICBjb25zdCBqc29uU3RyaW5nID0gSlNPTi5zdHJpbmdpZnkodGhpcy50b0pTT04oKSk7XG4gICAgICAgIGZ1bmN0aW9uIHByZXZpb3VzQ29ubmVjdGlvbkluZGV4KG0pIHtcbiAgICAgICAgICAgIGNvbnN0IGNvbm5lY3Rpb24gPSBtb2RlbC5lcXVhdGlvbkNvbm5lY3Rpb25zWzBdO1xuICAgICAgICAgICAgY29uc3QgeyBzdGF0ZXMgfSA9IGVxdWF0aW9uc1swXTtcbiAgICAgICAgICAgIGZvciAobGV0IGkgPSAwLCBtYXggPSBzdGF0ZXMubGVuZ3RoOyBpIDwgbWF4OyBpKyspIHtcbiAgICAgICAgICAgICAgICBpZiAoc3RhdGVzW2ldLnByb2R1Y3QgPT09IG0pIHtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgcmV0dXJuIGNvbm5lY3Rpb24uaW5kZXhPZihtKTtcbiAgICAgICAgfVxuICAgICAgICBmdW5jdGlvbiBtYXRyaXhPcmlnaW4obSwgc3RhdGVJbmRleCkge1xuICAgICAgICAgICAgZm9yIChsZXQgaSA9IDAsIG1heCA9IHN0YXRlcy5sZW5ndGg7IGkgPCBtYXg7IGkrKykge1xuICAgICAgICAgICAgICAgIGNvbnN0IHN0YXRlID0gc3RhdGVzW2ldO1xuICAgICAgICAgICAgICAgIGlmIChpID09PSBzdGF0ZUluZGV4KSB7XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IGogPSBwcmV2aW91c0Nvbm5lY3Rpb25JbmRleChtKTtcbiAgICAgICAgICAgICAgICAgICAgaWYgKGogPiAtMSAmJiAobSA9PT0gc3RhdGUubGVmdCB8fCBtID09PSBzdGF0ZS5yaWdodCkpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBgdHlwZW9mIHByZXZTdGF0ZXNbJHtqfV0gPT09ICdvYmplY3QnID8gcHJldlN0YXRlc1ske2p9XS5wcm9kdWN0IDogbmV3IE1hdHJpeCgke20ucm93c30sICR7bS5jb2x1bW5zfSlgO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBgbmV3IE1hdHJpeCgke20ucm93c30sICR7bS5jb2x1bW5zfSlgO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBpZiAobSA9PT0gc3RhdGUucHJvZHVjdClcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGBzdGF0ZXNbJHtpfV0ucHJvZHVjdGA7XG4gICAgICAgICAgICAgICAgaWYgKG0gPT09IHN0YXRlLnJpZ2h0KVxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gYHN0YXRlc1ske2l9XS5yaWdodGA7XG4gICAgICAgICAgICAgICAgaWYgKG0gPT09IHN0YXRlLmxlZnQpXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBgc3RhdGVzWyR7aX1dLmxlZnRgO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgcmV0dXJuICcnO1xuICAgICAgICB9XG4gICAgICAgIGZ1bmN0aW9uIG1hdHJpeFRvU3RyaW5nKG0sIHN0YXRlSW5kZXgpIHtcbiAgICAgICAgICAgIGlmICghbSB8fCAhbS5yb3dzIHx8ICFtLmNvbHVtbnMpXG4gICAgICAgICAgICAgICAgcmV0dXJuICdudWxsJztcbiAgICAgICAgICAgIGlmIChtID09PSBtb2RlbC5pbnB1dClcbiAgICAgICAgICAgICAgICByZXR1cm4gYGpzb24uaW5wdXRgO1xuICAgICAgICAgICAgaWYgKG0gPT09IG1vZGVsLm91dHB1dENvbm5lY3RvcilcbiAgICAgICAgICAgICAgICByZXR1cm4gYGpzb24ub3V0cHV0Q29ubmVjdG9yYDtcbiAgICAgICAgICAgIGlmIChtID09PSBtb2RlbC5vdXRwdXQpXG4gICAgICAgICAgICAgICAgcmV0dXJuIGBqc29uLm91dHB1dGA7XG4gICAgICAgICAgICBmb3IgKGxldCBpID0gMCwgbWF4ID0gbW9kZWwuaGlkZGVuTGF5ZXJzLmxlbmd0aDsgaSA8IG1heDsgaSsrKSB7XG4gICAgICAgICAgICAgICAgY29uc3QgaGlkZGVuTGF5ZXIgPSBtb2RlbC5oaWRkZW5MYXllcnNbaV07XG4gICAgICAgICAgICAgICAgZm9yIChjb25zdCBwIGluIGhpZGRlbkxheWVyKSB7XG4gICAgICAgICAgICAgICAgICAgIGlmICghaGlkZGVuTGF5ZXIuaGFzT3duUHJvcGVydHkocCkpXG4gICAgICAgICAgICAgICAgICAgICAgICBjb250aW51ZTtcbiAgICAgICAgICAgICAgICAgICAgaWYgKGhpZGRlbkxheWVyW3BdICE9PSBtKVxuICAgICAgICAgICAgICAgICAgICAgICAgY29udGludWU7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBganNvbi5oaWRkZW5MYXllcnNbJHtpfV0uJHtwfWA7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgcmV0dXJuIG1hdHJpeE9yaWdpbihtLCBzdGF0ZUluZGV4KTtcbiAgICAgICAgfVxuICAgICAgICBmdW5jdGlvbiB0b0lubmVyKGZuU3RyaW5nKSB7XG4gICAgICAgICAgICAvLyBjcnVkZSwgYnV0IHNob3VsZCBiZSBzdWZmaWNpZW50IGZvciBub3dcbiAgICAgICAgICAgIC8vIGZ1bmN0aW9uKCkgeyBib2R5IH1cbiAgICAgICAgICAgIGNvbnN0IGZuUGFydHMgPSBmblN0cmluZy50b1N0cmluZygpLnNwbGl0KCd7Jyk7XG4gICAgICAgICAgICBmblBhcnRzLnNoaWZ0KCk7XG4gICAgICAgICAgICAvLyBib2R5IH1cbiAgICAgICAgICAgIGNvbnN0IGZuQm9keVN0cmluZyA9IGZuUGFydHMuam9pbigneycpO1xuICAgICAgICAgICAgY29uc3QgZm5Cb2R5UGFydHMgPSBmbkJvZHlTdHJpbmcuc3BsaXQoJ30nKTtcbiAgICAgICAgICAgIGZuQm9keVBhcnRzLnBvcCgpO1xuICAgICAgICAgICAgLy8gYm9keVxuICAgICAgICAgICAgcmV0dXJuIGZuQm9keVBhcnRzXG4gICAgICAgICAgICAgICAgLmpvaW4oJ30nKVxuICAgICAgICAgICAgICAgIC5zcGxpdCgnXFxuJylcbiAgICAgICAgICAgICAgICAuam9pbignXFxuICAgICAgICAnKVxuICAgICAgICAgICAgICAgIC5yZXBsYWNlKCdwcm9kdWN0LmRlbHRhc1tpXSA9IDA7JywgJycpXG4gICAgICAgICAgICAgICAgLnJlcGxhY2UoJ3Byb2R1Y3QuZGVsdGFzW2NvbHVtbl0gPSAwOycsICcnKVxuICAgICAgICAgICAgICAgIC5yZXBsYWNlKCdsZWZ0LmRlbHRhc1tsZWZ0SW5kZXhdID0gMDsnLCAnJylcbiAgICAgICAgICAgICAgICAucmVwbGFjZSgncmlnaHQuZGVsdGFzW3JpZ2h0SW5kZXhdID0gMDsnLCAnJylcbiAgICAgICAgICAgICAgICAucmVwbGFjZSgncHJvZHVjdC5kZWx0YXMgPSBsZWZ0LmRlbHRhcy5zbGljZSgwKTsnLCAnJyk7XG4gICAgICAgIH1cbiAgICAgICAgZnVuY3Rpb24gZmlsZU5hbWUoZm5OYW1lKSB7XG4gICAgICAgICAgICByZXR1cm4gYHNyYy9yZWN1cnJlbnQvbWF0cml4LyR7Zm5OYW1lLnJlcGxhY2UoL1tBLVpdL2csIGZ1bmN0aW9uICh2YWx1ZSkge1xuICAgICAgICAgICAgICAgIHJldHVybiBgLSR7dmFsdWUudG9Mb3dlckNhc2UoKX1gO1xuICAgICAgICAgICAgfSl9LmpzYDtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCBzdGF0ZXNSYXcgPSBbXTtcbiAgICAgICAgY29uc3QgdXNlZEZ1bmN0aW9uTmFtZXMgPSB7fTtcbiAgICAgICAgY29uc3QgaW5uZXJGdW5jdGlvbnNTd2l0Y2ggPSBbXTtcbiAgICAgICAgZm9yIChsZXQgaSA9IDAsIG1heCA9IHN0YXRlcy5sZW5ndGg7IGkgPCBtYXg7IGkrKykge1xuICAgICAgICAgICAgY29uc3Qgc3RhdGUgPSBzdGF0ZXNbaV07XG4gICAgICAgICAgICBzdGF0ZXNSYXcucHVzaChgc3RhdGVzWyR7aX1dID0ge1xuICAgICAgbmFtZTogJyR7c3RhdGUuZm9yd2FyZEZuLm5hbWV9JyxcbiAgICAgIGxlZnQ6ICR7c3RhdGUubGVmdCA/IG1hdHJpeFRvU3RyaW5nKHN0YXRlLmxlZnQsIGkpIDogJ3VuZGVmaW5lZCd9LFxuICAgICAgcmlnaHQ6ICR7c3RhdGUucmlnaHQgPyBtYXRyaXhUb1N0cmluZyhzdGF0ZS5yaWdodCwgaSkgOiAndW5kZWZpbmVkJ30sXG4gICAgICBwcm9kdWN0OiAke21hdHJpeFRvU3RyaW5nKHN0YXRlLnByb2R1Y3QsIGkpfVxuICAgIH1gKTtcbiAgICAgICAgICAgIGNvbnN0IGZuTmFtZSA9IHN0YXRlLmZvcndhcmRGbi5uYW1lO1xuICAgICAgICAgICAgaWYgKCF1c2VkRnVuY3Rpb25OYW1lc1tmbk5hbWVdKSB7XG4gICAgICAgICAgICAgICAgdXNlZEZ1bmN0aW9uTmFtZXNbZm5OYW1lXSA9IHRydWU7XG4gICAgICAgICAgICAgICAgaW5uZXJGdW5jdGlvbnNTd2l0Y2gucHVzaChgICAgICAgICBjYXNlICcke2ZuTmFtZX0nOiAvL2NvbXBpbGVkIGZyb20gJHtmaWxlTmFtZShmbk5hbWUpfVxuICAgICAgICAgICR7dG9Jbm5lcihzdGF0ZS5mb3J3YXJkRm4udG9TdHJpbmcoKSl9XG4gICAgICAgICAgYnJlYWs7YCk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgY29uc3Qgc3JjID0gYFxuICBpZiAodHlwZW9mIHJhd0lucHV0ID09PSAndW5kZWZpbmVkJykgcmF3SW5wdXQgPSBbXTtcbiAgaWYgKHR5cGVvZiBpc1NhbXBsZUkgPT09ICd1bmRlZmluZWQnKSBpc1NhbXBsZUkgPSBmYWxzZTtcbiAgaWYgKHR5cGVvZiB0ZW1wZXJhdHVyZSA9PT0gJ3VuZGVmaW5lZCcpIHRlbXBlcmF0dXJlID0gMTtcbiAgdmFyIGpzb24gPSAke2pzb25TdHJpbmd9O1xuICAke3RoaXMub3B0aW9ucy5kYXRhRm9ybWF0dGVyXG4gICAgICAgICAgICA/IGAke3RoaXMub3B0aW9ucy5kYXRhRm9ybWF0dGVyLnRvRnVuY3Rpb25TdHJpbmcoKX07XG4gIE9iamVjdC5hc3NpZ24oZGF0YUZvcm1hdHRlciwganNvbi5vcHRpb25zLmRhdGFGb3JtYXR0ZXIpO2BcbiAgICAgICAgICAgIDogJyd9XG4gICR7dGhpcy5vcHRpb25zLmRhdGFGb3JtYXR0ZXIgJiZcbiAgICAgICAgICAgIHR5cGVvZiB0aGlzLm9wdGlvbnMuZGF0YUZvcm1hdHRlci5mb3JtYXREYXRhSW4gPT09ICdmdW5jdGlvbidcbiAgICAgICAgICAgID8gYGNvbnN0IGZvcm1hdERhdGFJbiA9IGZ1bmN0aW9uIChpbnB1dCwgb3V0cHV0KSB7ICR7dG9Jbm5lcih0aGlzLm9wdGlvbnMuZGF0YUZvcm1hdHRlci5mb3JtYXREYXRhSW4udG9TdHJpbmcoKSl9IH0uYmluZChkYXRhRm9ybWF0dGVyKTtgXG4gICAgICAgICAgICA6ICcnfVxuICAke3RoaXMub3B0aW9ucy5kYXRhRm9ybWF0dGVyICE9PSBudWxsICYmXG4gICAgICAgICAgICB0eXBlb2YgdGhpcy5vcHRpb25zLmRhdGFGb3JtYXR0ZXIuZm9ybWF0RGF0YU91dCA9PT0gJ2Z1bmN0aW9uJ1xuICAgICAgICAgICAgPyBgY29uc3QgZm9ybWF0RGF0YU91dCA9IGZ1bmN0aW9uIGZvcm1hdERhdGFPdXQoaW5wdXQsIG91dHB1dCkgeyAke3RvSW5uZXIodGhpcy5vcHRpb25zLmRhdGFGb3JtYXR0ZXIuZm9ybWF0RGF0YU91dC50b1N0cmluZygpKX0gfS5iaW5kKGRhdGFGb3JtYXR0ZXIpO2BcbiAgICAgICAgICAgIDogJyd9XG4gIHZhciBtYXhQcmVkaWN0aW9uTGVuZ3RoID1cbiAgICAke3RoaXMub3B0aW9ucy5tYXhQcmVkaWN0aW9uTGVuZ3RofSArXG4gICAgcmF3SW5wdXQubGVuZ3RoICtcbiAgICAke3RoaXMub3B0aW9ucy5kYXRhRm9ybWF0dGVyXG4gICAgICAgICAgICA/IHRoaXMub3B0aW9ucy5kYXRhRm9ybWF0dGVyLnNwZWNpYWxJbmRleGVzLmxlbmd0aFxuICAgICAgICAgICAgOiAwfTtcbiAgdmFyIGlucHV0ID0gJHt0aGlzLm9wdGlvbnMuZGF0YUZvcm1hdHRlciAmJlxuICAgICAgICAgICAgdHlwZW9mIHRoaXMub3B0aW9ucy5kYXRhRm9ybWF0dGVyLmZvcm1hdERhdGFJbiA9PT0gJ2Z1bmN0aW9uJ1xuICAgICAgICAgICAgPyAnZm9ybWF0RGF0YUluKHJhd0lucHV0KSdcbiAgICAgICAgICAgIDogJ3Jhd0lucHV0J307XG4gIHZhciBfaSA9IDA7XG4gIHZhciBvdXRwdXQgPSBbXTtcbiAgdmFyIHN0YXRlcyA9IFtdO1xuICB2YXIgcHJldlN0YXRlcztcbiAgd2hpbGUgKHRydWUpIHtcbiAgICB2YXIgcHJldmlvdXNJbmRleCA9IChfaSA9PT0gMFxuICAgICAgICA/IDBcbiAgICAgICAgOiBfaSA8IGlucHV0Lmxlbmd0aFxuICAgICAgICAgID8gaW5wdXRbX2kgLSAxXSArIDFcbiAgICAgICAgICA6IG91dHB1dFtfaSAtIDFdKVxuICAgICAgICAgIDtcbiAgICB2YXIgcm93UGx1Y2tJbmRleCA9IHByZXZpb3VzSW5kZXg7XG4gICAgcHJldlN0YXRlcyA9IHN0YXRlcztcbiAgICBzdGF0ZXMgPSBbXTtcbiAgICAke3N0YXRlc1Jhdy5qb2luKCc7XFxuICAgICcpfTtcbiAgICBmb3IgKHZhciBzdGF0ZUluZGV4ID0gMCwgc3RhdGVNYXggPSAke3N0YXRlc1Jhdy5sZW5ndGh9OyBzdGF0ZUluZGV4IDwgc3RhdGVNYXg7IHN0YXRlSW5kZXgrKykge1xuICAgICAgdmFyIHN0YXRlID0gc3RhdGVzW3N0YXRlSW5kZXhdO1xuICAgICAgdmFyIHByb2R1Y3QgPSBzdGF0ZS5wcm9kdWN0O1xuICAgICAgdmFyIGxlZnQgPSBzdGF0ZS5sZWZ0O1xuICAgICAgdmFyIHJpZ2h0ID0gc3RhdGUucmlnaHQ7XG4gICAgICBzd2l0Y2ggKHN0YXRlLm5hbWUpIHtcbiR7aW5uZXJGdW5jdGlvbnNTd2l0Y2guam9pbignXFxuJyl9XG4gICAgICB9XG4gICAgfVxuXG4gICAgdmFyIGxvZ1Byb2JhYmlsaXRpZXMgPSBzdGF0ZS5wcm9kdWN0O1xuICAgIGlmICh0ZW1wZXJhdHVyZSAhPT0gMSAmJiBpc1NhbXBsZUkpIHtcbiAgICAgIGZvciAodmFyIHEgPSAwLCBucSA9IGxvZ1Byb2JhYmlsaXRpZXMud2VpZ2h0cy5sZW5ndGg7IHEgPCBucTsgcSsrKSB7XG4gICAgICAgIGxvZ1Byb2JhYmlsaXRpZXMud2VpZ2h0c1txXSAvPSB0ZW1wZXJhdHVyZTtcbiAgICAgIH1cbiAgICB9XG5cbiAgICB2YXIgcHJvYnMgPSBzb2Z0bWF4KGxvZ1Byb2JhYmlsaXRpZXMpO1xuICAgIHZhciBuZXh0SW5kZXggPSBpc1NhbXBsZUkgPyBzYW1wbGVJKHByb2JzKSA6IG1heEkocHJvYnMpO1xuXG4gICAgX2krKztcbiAgICBpZiAobmV4dEluZGV4ID09PSAwKSB7XG4gICAgICBicmVhaztcbiAgICB9XG4gICAgaWYgKF9pID49IG1heFByZWRpY3Rpb25MZW5ndGgpIHtcbiAgICAgIGJyZWFrO1xuICAgIH1cblxuICAgIG91dHB1dC5wdXNoKG5leHRJbmRleCk7XG4gIH1cbiAgJHt0aGlzLm9wdGlvbnMuZGF0YUZvcm1hdHRlciAmJlxuICAgICAgICAgICAgdHlwZW9mIHRoaXMub3B0aW9ucy5kYXRhRm9ybWF0dGVyLmZvcm1hdERhdGFPdXQgPT09ICdmdW5jdGlvbidcbiAgICAgICAgICAgID8gJ3JldHVybiBmb3JtYXREYXRhT3V0KGlucHV0LCBvdXRwdXQuc2xpY2UoaW5wdXQubGVuZ3RoKS5tYXAoZnVuY3Rpb24odmFsdWUpIHsgcmV0dXJuIHZhbHVlIC0gMTsgfSkpJ1xuICAgICAgICAgICAgOiAncmV0dXJuIG91dHB1dC5zbGljZShpbnB1dC5sZW5ndGgpLm1hcChmdW5jdGlvbih2YWx1ZSkgeyByZXR1cm4gdmFsdWUgLSAxOyB9KSd9O1xuICBmdW5jdGlvbiBNYXRyaXgocm93cywgY29sdW1ucykge1xuICAgIHRoaXMucm93cyA9IHJvd3M7XG4gICAgdGhpcy5jb2x1bW5zID0gY29sdW1ucztcbiAgICB0aGlzLndlaWdodHMgPSB6ZXJvcyhyb3dzICogY29sdW1ucyk7XG4gIH1cbiAgJHt6ZXJvcyQxLnRvU3RyaW5nKCl9XG4gICR7c29mdG1heC50b1N0cmluZygpLnJlcGxhY2UoJ18xLk1hdHJpeCcsICdNYXRyaXgnKX1cbiAgJHtyYW5kb21GbG9hdC50b1N0cmluZygpfVxuICAke3NhbXBsZUkudG9TdHJpbmcoKX1cbiAgJHttYXhJLnRvU3RyaW5nKCl9YDtcbiAgICAgICAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lXG4gICAgICAgIHJldHVybiBuZXcgRnVuY3Rpb24oJ3Jhd0lucHV0JywgJ2lzU2FtcGxlSScsICd0ZW1wZXJhdHVyZScsIGNiID8gY2Ioc3JjKSA6IHNyYyk7XG4gICAgfVxuICAgIHRyYWluUGF0dGVybihpbnB1dCwgbG9nRXJyb3JSYXRlKSB7XG4gICAgICAgIGNvbnN0IGVycm9yID0gdGhpcy50cmFpbklucHV0KGlucHV0KTtcbiAgICAgICAgdGhpcy5iYWNrcHJvcGFnYXRlKGlucHV0KTtcbiAgICAgICAgdGhpcy5hZGp1c3RXZWlnaHRzKCk7XG4gICAgICAgIGlmIChsb2dFcnJvclJhdGUpIHtcbiAgICAgICAgICAgIHJldHVybiBlcnJvcjtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gMDtcbiAgICB9XG59XG5mdW5jdGlvbiBsYXN0KHZhbHVlcykge1xuICAgIHJldHVybiB2YWx1ZXNbdmFsdWVzLmxlbmd0aCAtIDFdO1xufVxuXG5jbGFzcyBHUlUgZXh0ZW5kcyBSTk4ge1xuICAgIGdldEhpZGRlbkxheWVyKGhpZGRlblNpemUsIHByZXZTaXplKSB7XG4gICAgICAgIHJldHVybiBnZXRHUlVIaWRkZW5MYXllcihoaWRkZW5TaXplLCBwcmV2U2l6ZSk7XG4gICAgfVxuICAgIGdldEVxdWF0aW9uKGVxdWF0aW9uLCBpbnB1dE1hdHJpeCwgcHJldmlvdXNSZXN1bHQsIGhpZGRlbkxheWVyKSB7XG4gICAgICAgIHJldHVybiBnZXRHUlVFcXVhdGlvbihlcXVhdGlvbiwgaW5wdXRNYXRyaXgsIHByZXZpb3VzUmVzdWx0LCBoaWRkZW5MYXllcik7XG4gICAgfVxufVxuZnVuY3Rpb24gZ2V0R1JVSGlkZGVuTGF5ZXIoaGlkZGVuU2l6ZSwgcHJldlNpemUpIHtcbiAgICByZXR1cm4ge1xuICAgICAgICAvLyB1cGRhdGUgR2F0ZVxuICAgICAgICAvLyB3enhoXG4gICAgICAgIHVwZGF0ZUdhdGVJbnB1dE1hdHJpeDogbmV3IFJhbmRvbU1hdHJpeChoaWRkZW5TaXplLCBwcmV2U2l6ZSwgMC4wOCksXG4gICAgICAgIHVwZGF0ZUdhdGVIaWRkZW5NYXRyaXg6IG5ldyBSYW5kb21NYXRyaXgoaGlkZGVuU2l6ZSwgaGlkZGVuU2l6ZSwgMC4wOCksXG4gICAgICAgIHVwZGF0ZUdhdGVCaWFzOiBuZXcgTWF0cml4KGhpZGRlblNpemUsIDEpLFxuICAgICAgICAvLyByZXNldCBHYXRlXG4gICAgICAgIC8vIHdyeGhcbiAgICAgICAgcmVzZXRHYXRlSW5wdXRNYXRyaXg6IG5ldyBSYW5kb21NYXRyaXgoaGlkZGVuU2l6ZSwgcHJldlNpemUsIDAuMDgpLFxuICAgICAgICByZXNldEdhdGVIaWRkZW5NYXRyaXg6IG5ldyBSYW5kb21NYXRyaXgoaGlkZGVuU2l6ZSwgaGlkZGVuU2l6ZSwgMC4wOCksXG4gICAgICAgIHJlc2V0R2F0ZUJpYXM6IG5ldyBNYXRyaXgoaGlkZGVuU2l6ZSwgMSksXG4gICAgICAgIC8vIGNlbGwgd3JpdGUgcGFyYW1ldGVyc1xuICAgICAgICAvLyB3Y3hoXG4gICAgICAgIGNlbGxXcml0ZUlucHV0TWF0cml4OiBuZXcgUmFuZG9tTWF0cml4KGhpZGRlblNpemUsIHByZXZTaXplLCAwLjA4KSxcbiAgICAgICAgY2VsbFdyaXRlSGlkZGVuTWF0cml4OiBuZXcgUmFuZG9tTWF0cml4KGhpZGRlblNpemUsIGhpZGRlblNpemUsIDAuMDgpLFxuICAgICAgICBjZWxsV3JpdGVCaWFzOiBuZXcgTWF0cml4KGhpZGRlblNpemUsIDEpLFxuICAgIH07XG59XG5mdW5jdGlvbiBnZXRHUlVFcXVhdGlvbihlcXVhdGlvbiwgaW5wdXRNYXRyaXgsIHByZXZpb3VzUmVzdWx0LCBoaWRkZW5MYXllcikge1xuICAgIGlmICghaGlkZGVuTGF5ZXIudXBkYXRlR2F0ZUlucHV0TWF0cml4IHx8XG4gICAgICAgICFoaWRkZW5MYXllci51cGRhdGVHYXRlSGlkZGVuTWF0cml4IHx8XG4gICAgICAgICFoaWRkZW5MYXllci51cGRhdGVHYXRlQmlhcyB8fFxuICAgICAgICAhaGlkZGVuTGF5ZXIucmVzZXRHYXRlSW5wdXRNYXRyaXggfHxcbiAgICAgICAgIWhpZGRlbkxheWVyLnJlc2V0R2F0ZUhpZGRlbk1hdHJpeCB8fFxuICAgICAgICAhaGlkZGVuTGF5ZXIucmVzZXRHYXRlQmlhcyB8fFxuICAgICAgICAhaGlkZGVuTGF5ZXIuY2VsbFdyaXRlSW5wdXRNYXRyaXggfHxcbiAgICAgICAgIWhpZGRlbkxheWVyLmNlbGxXcml0ZUhpZGRlbk1hdHJpeCB8fFxuICAgICAgICAhaGlkZGVuTGF5ZXIuY2VsbFdyaXRlQmlhcykge1xuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ2hpZGRlbkxheWVyIGRvZXMgbm90IGhhdmUgZXhwZWN0ZWQgcHJvcGVydGllcycpO1xuICAgIH1cbiAgICBjb25zdCBzaWdtb2lkID0gZXF1YXRpb24uc2lnbW9pZC5iaW5kKGVxdWF0aW9uKTtcbiAgICBjb25zdCBhZGQgPSBlcXVhdGlvbi5hZGQuYmluZChlcXVhdGlvbik7XG4gICAgY29uc3QgbXVsdGlwbHkgPSBlcXVhdGlvbi5tdWx0aXBseS5iaW5kKGVxdWF0aW9uKTtcbiAgICBjb25zdCBtdWx0aXBseUVsZW1lbnQgPSBlcXVhdGlvbi5tdWx0aXBseUVsZW1lbnQuYmluZChlcXVhdGlvbik7XG4gICAgY29uc3QgdGFuaCA9IGVxdWF0aW9uLnRhbmguYmluZChlcXVhdGlvbik7XG4gICAgY29uc3QgYWxsT25lcyA9IGVxdWF0aW9uLmFsbE9uZXMuYmluZChlcXVhdGlvbik7XG4gICAgY29uc3QgY2xvbmVOZWdhdGl2ZSA9IGVxdWF0aW9uLmNsb25lTmVnYXRpdmUuYmluZChlcXVhdGlvbik7XG4gICAgLy8gdXBkYXRlIGdhdGVcbiAgICBjb25zdCB1cGRhdGVHYXRlID0gc2lnbW9pZChhZGQoYWRkKG11bHRpcGx5KGhpZGRlbkxheWVyLnVwZGF0ZUdhdGVJbnB1dE1hdHJpeCwgaW5wdXRNYXRyaXgpLCBtdWx0aXBseShoaWRkZW5MYXllci51cGRhdGVHYXRlSGlkZGVuTWF0cml4LCBwcmV2aW91c1Jlc3VsdCkpLCBoaWRkZW5MYXllci51cGRhdGVHYXRlQmlhcykpO1xuICAgIC8vIHJlc2V0IGdhdGVcbiAgICBjb25zdCByZXNldEdhdGUgPSBzaWdtb2lkKGFkZChhZGQobXVsdGlwbHkoaGlkZGVuTGF5ZXIucmVzZXRHYXRlSW5wdXRNYXRyaXgsIGlucHV0TWF0cml4KSwgbXVsdGlwbHkoaGlkZGVuTGF5ZXIucmVzZXRHYXRlSGlkZGVuTWF0cml4LCBwcmV2aW91c1Jlc3VsdCkpLCBoaWRkZW5MYXllci5yZXNldEdhdGVCaWFzKSk7XG4gICAgLy8gY2VsbFxuICAgIGNvbnN0IGNlbGwgPSB0YW5oKGFkZChhZGQobXVsdGlwbHkoaGlkZGVuTGF5ZXIuY2VsbFdyaXRlSW5wdXRNYXRyaXgsIGlucHV0TWF0cml4KSwgbXVsdGlwbHkoaGlkZGVuTGF5ZXIuY2VsbFdyaXRlSGlkZGVuTWF0cml4LCBtdWx0aXBseUVsZW1lbnQocmVzZXRHYXRlLCBwcmV2aW91c1Jlc3VsdCkpKSwgaGlkZGVuTGF5ZXIuY2VsbFdyaXRlQmlhcykpO1xuICAgIC8vIGNvbXB1dGUgaGlkZGVuIHN0YXRlIGFzIGdhdGVkLCBzYXR1cmF0ZWQgY2VsbCBhY3RpdmF0aW9uc1xuICAgIC8vIG5lZ2F0ZSB1cGRhdGVHYXRlXG4gICAgcmV0dXJuIGFkZChtdWx0aXBseUVsZW1lbnQoYWRkKGFsbE9uZXModXBkYXRlR2F0ZS5yb3dzLCB1cGRhdGVHYXRlLmNvbHVtbnMpLCBjbG9uZU5lZ2F0aXZlKHVwZGF0ZUdhdGUpKSwgY2VsbCksIG11bHRpcGx5RWxlbWVudChwcmV2aW91c1Jlc3VsdCwgdXBkYXRlR2F0ZSkpO1xufVxuXG5jbGFzcyBBcnJheUxvb2t1cFRhYmxlIHtcbiAgICBjb25zdHJ1Y3RvcihkYXRhLCBwcm9wKSB7XG4gICAgICAgIHRoaXMucHJvcCA9IHByb3A7XG4gICAgICAgIHRoaXMubGVuZ3RoID0gMDtcbiAgICAgICAgdGhpcy50YWJsZSA9IHt9O1xuICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IGRhdGEubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgICAgIGNvbnN0IGRhdHVtID0gZGF0YVtpXTtcbiAgICAgICAgICAgIGNvbnN0IGlvVmFsdWUgPSBkYXR1bVtwcm9wXTtcbiAgICAgICAgICAgIGZvciAobGV0IGogPSAwOyBqIDwgaW9WYWx1ZS5sZW5ndGg7IGorKykge1xuICAgICAgICAgICAgICAgIGNvbnN0IHZhbHVlID0gaW9WYWx1ZVtqXTtcbiAgICAgICAgICAgICAgICBmb3IgKGNvbnN0IHAgaW4gdmFsdWUpIHtcbiAgICAgICAgICAgICAgICAgICAgaWYgKCF2YWx1ZS5oYXNPd25Qcm9wZXJ0eShwKSlcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnRpbnVlO1xuICAgICAgICAgICAgICAgICAgICBpZiAodGhpcy50YWJsZS5oYXNPd25Qcm9wZXJ0eShwKSlcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnRpbnVlO1xuICAgICAgICAgICAgICAgICAgICB0aGlzLnRhYmxlW3BdID0gdGhpcy5sZW5ndGgrKztcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9XG59XG5cbmNvbnN0IGRlZmF1bHRzID0gKCkgPT4ge1xuICAgIHJldHVybiB7XG4gICAgICAgIC4uLmRlZmF1bHRzJDEoKSxcbiAgICAgICAgaW5wdXRTaXplOiAxLFxuICAgICAgICBoaWRkZW5MYXllcnM6IFsyMF0sXG4gICAgICAgIG91dHB1dFNpemU6IDEsXG4gICAgICAgIGlucHV0UmFuZ2U6IDAsXG4gICAgfTtcbn07XG5jbGFzcyBSTk5UaW1lU3RlcCBleHRlbmRzIFJOTiB7XG4gICAgY29uc3RydWN0b3Iob3B0aW9ucyA9IHt9KSB7XG4gICAgICAgIHN1cGVyKCk7XG4gICAgICAgIHRoaXMuaW5wdXRMb29rdXBMZW5ndGggPSAwO1xuICAgICAgICB0aGlzLmlucHV0TG9va3VwID0gbnVsbDtcbiAgICAgICAgdGhpcy5vdXRwdXRMb29rdXAgPSBudWxsO1xuICAgICAgICB0aGlzLm91dHB1dExvb2t1cExlbmd0aCA9IDA7XG4gICAgICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBAdHlwZXNjcmlwdC1lc2xpbnQvYmFuLXRzLWNvbW1lbnRcbiAgICAgICAgLy8gQHRzLWV4cGVjdC1lcnJvclxuICAgICAgICB0aGlzLm1vZGVsID0gT2JqZWN0LnNlYWwoe1xuICAgICAgICAgICAgaXNJbml0aWFsaXplZDogZmFsc2UsXG4gICAgICAgICAgICBoaWRkZW5MYXllcnM6IFtdLFxuICAgICAgICAgICAgb3V0cHV0OiBuZXcgTWF0cml4KDAsIDApLFxuICAgICAgICAgICAgZXF1YXRpb25zOiBbXSxcbiAgICAgICAgICAgIGFsbE1hdHJpY2VzOiBbXSxcbiAgICAgICAgICAgIGVxdWF0aW9uQ29ubmVjdGlvbnM6IFtdLFxuICAgICAgICAgICAgb3V0cHV0Q29ubmVjdG9yOiBuZXcgUmFuZG9tTWF0cml4KDAsIDAsIDAuMDgpLFxuICAgICAgICB9KTtcbiAgICAgICAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIEB0eXBlc2NyaXB0LWVzbGludC9iYW4tdHMtY29tbWVudFxuICAgICAgICAvLyBAdHMtZXhwZWN0LWVycm9yXG4gICAgICAgIHRoaXMub3B0aW9ucyA9IGRlZmF1bHRzKCk7XG4gICAgICAgIHRoaXMub3B0aW9ucyA9IHsgLi4udGhpcy5vcHRpb25zLCAuLi5vcHRpb25zIH07XG4gICAgICAgIHRoaXMudXBkYXRlVHJhaW5pbmdPcHRpb25zKHtcbiAgICAgICAgICAgIC4uLnRyYWluRGVmYXVsdHMsXG4gICAgICAgICAgICAuLi5vcHRpb25zLFxuICAgICAgICB9KTtcbiAgICAgICAgaWYgKG9wdGlvbnMuanNvbikge1xuICAgICAgICAgICAgdGhpcy5mcm9tSlNPTihvcHRpb25zLmpzb24pO1xuICAgICAgICB9XG4gICAgfVxuICAgIGNyZWF0ZUlucHV0TWF0cml4KCkge1xuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ0lucHV0IE1hdHJpY2VzIGRvIG5vdCBleGlzdCBvbiBSTk5UaW1lU3RlcCcpO1xuICAgIH1cbiAgICBjcmVhdGVPdXRwdXRNYXRyaWNlcygpIHtcbiAgICAgICAgY29uc3QgeyBvdXRwdXRTaXplIH0gPSB0aGlzLm9wdGlvbnM7XG4gICAgICAgIGNvbnN0IGxhc3RIaWRkZW5TaXplID0gbGFzdCh0aGlzLm9wdGlvbnMuaGlkZGVuTGF5ZXJzKTtcbiAgICAgICAgLy8gd2hkXG4gICAgICAgIGNvbnN0IG91dHB1dENvbm5lY3RvciA9IG5ldyBSYW5kb21NYXRyaXgob3V0cHV0U2l6ZSwgbGFzdEhpZGRlblNpemUsIDAuMDgpO1xuICAgICAgICAvLyBiZFxuICAgICAgICBjb25zdCBvdXRwdXQgPSBuZXcgUmFuZG9tTWF0cml4KG91dHB1dFNpemUsIDEsIDAuMDgpO1xuICAgICAgICByZXR1cm4geyBvdXRwdXQsIG91dHB1dENvbm5lY3RvciB9O1xuICAgIH1cbiAgICBiaW5kRXF1YXRpb24oKSB7XG4gICAgICAgIGNvbnN0IHsgbW9kZWwsIG9wdGlvbnMgfSA9IHRoaXM7XG4gICAgICAgIGNvbnN0IHsgaGlkZGVuTGF5ZXJzLCBpbnB1dFNpemUgfSA9IG9wdGlvbnM7XG4gICAgICAgIGNvbnN0IGxheWVycyA9IG1vZGVsLmhpZGRlbkxheWVycztcbiAgICAgICAgY29uc3QgZXF1YXRpb24gPSBuZXcgRXF1YXRpb24oKTtcbiAgICAgICAgY29uc3Qgb3V0cHV0cyA9IFtdO1xuICAgICAgICBjb25zdCBlcXVhdGlvbkNvbm5lY3Rpb24gPSBtb2RlbC5lcXVhdGlvbkNvbm5lY3Rpb25zLmxlbmd0aCA+IDBcbiAgICAgICAgICAgID8gbW9kZWwuZXF1YXRpb25Db25uZWN0aW9uc1ttb2RlbC5lcXVhdGlvbkNvbm5lY3Rpb25zLmxlbmd0aCAtIDFdXG4gICAgICAgICAgICA6IHRoaXMuaW5pdGlhbExheWVySW5wdXRzO1xuICAgICAgICAvLyAwIGluZGV4XG4gICAgICAgIGxldCBvdXRwdXQgPSB0aGlzLmdldEVxdWF0aW9uKGVxdWF0aW9uLCBlcXVhdGlvbi5pbnB1dChuZXcgTWF0cml4KGlucHV0U2l6ZSwgMSkpLCBlcXVhdGlvbkNvbm5lY3Rpb25bMF0sIGxheWVyc1swXSk7XG4gICAgICAgIG91dHB1dHMucHVzaChvdXRwdXQpO1xuICAgICAgICAvLyAxKyBpbmRpY2VzXG4gICAgICAgIGZvciAobGV0IGkgPSAxLCBtYXggPSBoaWRkZW5MYXllcnMubGVuZ3RoOyBpIDwgbWF4OyBpKyspIHtcbiAgICAgICAgICAgIG91dHB1dCA9IHRoaXMuZ2V0RXF1YXRpb24oZXF1YXRpb24sIG91dHB1dCwgZXF1YXRpb25Db25uZWN0aW9uW2ldLCBsYXllcnNbaV0pO1xuICAgICAgICAgICAgb3V0cHV0cy5wdXNoKG91dHB1dCk7XG4gICAgICAgIH1cbiAgICAgICAgbW9kZWwuZXF1YXRpb25Db25uZWN0aW9ucy5wdXNoKG91dHB1dHMpO1xuICAgICAgICBlcXVhdGlvbi5hZGQoZXF1YXRpb24ubXVsdGlwbHkobW9kZWwub3V0cHV0Q29ubmVjdG9yLCBvdXRwdXQpLCBtb2RlbC5vdXRwdXQpO1xuICAgICAgICBtb2RlbC5lcXVhdGlvbnMucHVzaChlcXVhdGlvbik7XG4gICAgfVxuICAgIGluaXRpYWxpemUoKSB7XG4gICAgICAgIHRoaXMubW9kZWwgPSB0aGlzLm1hcE1vZGVsKCk7XG4gICAgfVxuICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBAdHlwZXNjcmlwdC1lc2xpbnQvYmFuLXRzLWNvbW1lbnRcbiAgICAvLyBAdHMtZXhwZWN0LWVycm9yXG4gICAgbWFwTW9kZWwoKSB7XG4gICAgICAgIGNvbnN0IGFsbE1hdHJpY2VzID0gW107XG4gICAgICAgIHRoaXMuaW5pdGlhbExheWVySW5wdXRzID0gdGhpcy5vcHRpb25zLmhpZGRlbkxheWVycy5tYXAoKHNpemUpID0+IG5ldyBNYXRyaXgoc2l6ZSwgMSkpO1xuICAgICAgICBjb25zdCBoaWRkZW5MYXllcnMgPSB0aGlzLmNyZWF0ZUhpZGRlbkxheWVycygpO1xuICAgICAgICBmb3IgKGxldCBpID0gMCwgbWF4ID0gaGlkZGVuTGF5ZXJzLmxlbmd0aDsgaSA8IG1heDsgaSsrKSB7XG4gICAgICAgICAgICBjb25zdCBoaWRkZW5NYXRyaXggPSBoaWRkZW5MYXllcnNbaV07XG4gICAgICAgICAgICBmb3IgKGNvbnN0IHByb3BlcnR5IGluIGhpZGRlbk1hdHJpeCkge1xuICAgICAgICAgICAgICAgIGlmICghaGlkZGVuTWF0cml4Lmhhc093blByb3BlcnR5KHByb3BlcnR5KSlcbiAgICAgICAgICAgICAgICAgICAgY29udGludWU7XG4gICAgICAgICAgICAgICAgYWxsTWF0cmljZXMucHVzaChoaWRkZW5NYXRyaXhbcHJvcGVydHldKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBjb25zdCB7IG91dHB1dENvbm5lY3Rvciwgb3V0cHV0IH0gPSB0aGlzLmNyZWF0ZU91dHB1dE1hdHJpY2VzKCk7XG4gICAgICAgIGFsbE1hdHJpY2VzLnB1c2gob3V0cHV0Q29ubmVjdG9yKTtcbiAgICAgICAgYWxsTWF0cmljZXMucHVzaChvdXRwdXQpO1xuICAgICAgICByZXR1cm4gT2JqZWN0LnNlYWwoe1xuICAgICAgICAgICAgaXNJbml0aWFsaXplZDogdHJ1ZSxcbiAgICAgICAgICAgIGhpZGRlbkxheWVycyxcbiAgICAgICAgICAgIG91dHB1dCxcbiAgICAgICAgICAgIGVxdWF0aW9uczogW10sXG4gICAgICAgICAgICBhbGxNYXRyaWNlcyxcbiAgICAgICAgICAgIGVxdWF0aW9uQ29ubmVjdGlvbnM6IFtdLFxuICAgICAgICAgICAgb3V0cHV0Q29ubmVjdG9yLFxuICAgICAgICB9KTtcbiAgICB9XG4gICAgYmFja3Byb3BhZ2F0ZSgpIHtcbiAgICAgICAgZm9yIChsZXQgaSA9IHRoaXMubW9kZWwuZXF1YXRpb25zLmxlbmd0aCAtIDE7IGkgPiAtMTsgaS0tKSB7XG4gICAgICAgICAgICB0aGlzLm1vZGVsLmVxdWF0aW9uc1tpXS5iYWNrcHJvcGFnYXRlKCk7XG4gICAgICAgIH1cbiAgICB9XG4gICAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIEB0eXBlc2NyaXB0LWVzbGludC9iYW4tdHMtY29tbWVudFxuICAgIC8vIEB0cy1leHBlY3QtZXJyb3JcbiAgICBydW4ocmF3SW5wdXQpIHtcbiAgICAgICAgY29uc3Qgc2hhcGUgPSBsb29rdXAuZGF0YVNoYXBlKHJhd0lucHV0KS5qb2luKCcsJyk7XG4gICAgICAgIHN3aXRjaCAoc2hhcGUpIHtcbiAgICAgICAgICAgIGNhc2UgJ2FycmF5LG51bWJlcic6XG4gICAgICAgICAgICAgICAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIEB0eXBlc2NyaXB0LWVzbGludC9iYW4tdHMtY29tbWVudFxuICAgICAgICAgICAgICAgIC8vIEB0cy1leHBlY3QtZXJyb3JcbiAgICAgICAgICAgICAgICByZXR1cm4gdGhpcy5ydW5BcnJheShyYXdJbnB1dCk7XG4gICAgICAgICAgICBjYXNlICdhcnJheSxhcnJheSxudW1iZXInOlxuICAgICAgICAgICAgICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBAdHlwZXNjcmlwdC1lc2xpbnQvYmFuLXRzLWNvbW1lbnRcbiAgICAgICAgICAgICAgICAvLyBAdHMtZXhwZWN0LWVycm9yXG4gICAgICAgICAgICAgICAgcmV0dXJuIHRoaXMucnVuQXJyYXlPZkFycmF5KHJhd0lucHV0KTtcbiAgICAgICAgICAgIGNhc2UgJ29iamVjdCxudW1iZXInOlxuICAgICAgICAgICAgICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBAdHlwZXNjcmlwdC1lc2xpbnQvYmFuLXRzLWNvbW1lbnRcbiAgICAgICAgICAgICAgICAvLyBAdHMtZXhwZWN0LWVycm9yXG4gICAgICAgICAgICAgICAgcmV0dXJuIHRoaXMucnVuT2JqZWN0KHJhd0lucHV0KTsgLy8gQmFja3dhcmQgY29tcGF0aWJpbGl0eSwgd2lsbCBiZSByZXN1bHQgb2YgYHVua25vd25gIGFuZCBuZWVkIGNhc3RpbmcuICBCZXR0ZXIgdG8ganVzdCB1c2UgbmV0LnJ1bk9iamVjdCgpIGRpcmVjdGx5XG4gICAgICAgICAgICBjYXNlICdhcnJheSxvYmplY3QsbnVtYmVyJzpcbiAgICAgICAgICAgICAgICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgQHR5cGVzY3JpcHQtZXNsaW50L2Jhbi10cy1jb21tZW50XG4gICAgICAgICAgICAgICAgLy8gQHRzLWV4cGVjdC1lcnJvclxuICAgICAgICAgICAgICAgIHJldHVybiB0aGlzLnJ1bkFycmF5T2ZPYmplY3QocmF3SW5wdXQpO1xuICAgICAgICAgICAgZGVmYXVsdDpcbiAgICAgICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoYFVucmVjb2duaXplZCBkYXRhIHNoYXBlICR7c2hhcGV9YCk7XG4gICAgICAgIH1cbiAgICB9XG4gICAgZm9yZWNhc3QocmF3SW5wdXQsIGNvdW50ID0gMSkge1xuICAgICAgICBjb25zdCBzaGFwZSA9IGxvb2t1cC5kYXRhU2hhcGUocmF3SW5wdXQpLmpvaW4oJywnKTtcbiAgICAgICAgc3dpdGNoIChzaGFwZSkge1xuICAgICAgICAgICAgY2FzZSAnYXJyYXksbnVtYmVyJzpcbiAgICAgICAgICAgICAgICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgQHR5cGVzY3JpcHQtZXNsaW50L2Jhbi10cy1jb21tZW50XG4gICAgICAgICAgICAgICAgLy8gQHRzLWV4cGVjdC1lcnJvclxuICAgICAgICAgICAgICAgIHJldHVybiB0aGlzLmZvcmVjYXN0QXJyYXkocmF3SW5wdXQsIGNvdW50KTtcbiAgICAgICAgICAgIGNhc2UgJ2FycmF5LGFycmF5LG51bWJlcic6XG4gICAgICAgICAgICAgICAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIEB0eXBlc2NyaXB0LWVzbGludC9iYW4tdHMtY29tbWVudFxuICAgICAgICAgICAgICAgIC8vIEB0cy1leHBlY3QtZXJyb3JcbiAgICAgICAgICAgICAgICByZXR1cm4gdGhpcy5mb3JlY2FzdEFycmF5T2ZBcnJheShyYXdJbnB1dCwgY291bnQpO1xuICAgICAgICAgICAgY2FzZSAnb2JqZWN0LG51bWJlcic6XG4gICAgICAgICAgICAgICAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIEB0eXBlc2NyaXB0LWVzbGludC9iYW4tdHMtY29tbWVudFxuICAgICAgICAgICAgICAgIC8vIEB0cy1leHBlY3QtZXJyb3JcbiAgICAgICAgICAgICAgICByZXR1cm4gdGhpcy5ydW5PYmplY3QocmF3SW5wdXQpO1xuICAgICAgICAgICAgY2FzZSAnYXJyYXksb2JqZWN0LG51bWJlcic6XG4gICAgICAgICAgICAgICAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIEB0eXBlc2NyaXB0LWVzbGludC9iYW4tdHMtY29tbWVudFxuICAgICAgICAgICAgICAgIC8vIEB0cy1leHBlY3QtZXJyb3JcbiAgICAgICAgICAgICAgICByZXR1cm4gdGhpcy5mb3JlY2FzdEFycmF5T2ZPYmplY3QocmF3SW5wdXQsIGNvdW50KTtcbiAgICAgICAgICAgIGRlZmF1bHQ6XG4gICAgICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKGBVbnJlY29nbml6ZWQgZGF0YSBzaGFwZSAke3NoYXBlfWApO1xuICAgICAgICB9XG4gICAgfVxuICAgIGZvcmVjYXN0QXJyYXkoaW5wdXQsIGNvdW50ID0gMSkge1xuICAgICAgICB0aGlzLmNoZWNrUnVubmFibGUoKTtcbiAgICAgICAgY29uc3QgeyBtb2RlbCB9ID0gdGhpcztcbiAgICAgICAgY29uc3QgeyBlcXVhdGlvbnMgfSA9IG1vZGVsO1xuICAgICAgICBjb25zdCBsZW5ndGggPSBpbnB1dC5sZW5ndGggKyBjb3VudDtcbiAgICAgICAgd2hpbGUgKGVxdWF0aW9ucy5sZW5ndGggPD0gbGVuZ3RoKSB7XG4gICAgICAgICAgICB0aGlzLmJpbmRFcXVhdGlvbigpO1xuICAgICAgICB9XG4gICAgICAgIGxldCBsYXN0T3V0cHV0O1xuICAgICAgICBsZXQgZXF1YXRpb25JbmRleCA9IDA7XG4gICAgICAgIGlmICh0aGlzLm9wdGlvbnMuaW5wdXRTaXplID09PSAxKSB7XG4gICAgICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IGlucHV0Lmxlbmd0aDsgaSsrKSB7XG4gICAgICAgICAgICAgICAgbGFzdE91dHB1dCA9IGVxdWF0aW9uc1tlcXVhdGlvbkluZGV4KytdLnJ1bklucHV0KEZsb2F0MzJBcnJheS5mcm9tKFtpbnB1dFtpXV0pKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgaW5wdXQubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgICAgICAgICBsYXN0T3V0cHV0ID0gZXF1YXRpb25zW2VxdWF0aW9uSW5kZXgrK10ucnVuSW5wdXQoRmxvYXQzMkFycmF5LmZyb20oW10pKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBpZiAoIWxhc3RPdXRwdXQpIHtcbiAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcignbGFzdE91dHB1dCBub3Qgc2V0Jyk7XG4gICAgICAgIH1cbiAgICAgICAgY29uc3QgcmVzdWx0ID0gW2xhc3RPdXRwdXQud2VpZ2h0c1swXV07XG4gICAgICAgIGZvciAobGV0IGkgPSAwLCBtYXggPSBjb3VudCAtIDE7IGkgPCBtYXg7IGkrKykge1xuICAgICAgICAgICAgbGFzdE91dHB1dCA9IGVxdWF0aW9uc1tlcXVhdGlvbkluZGV4KytdLnJ1bklucHV0KGxhc3RPdXRwdXQud2VpZ2h0cyk7XG4gICAgICAgICAgICByZXN1bHQucHVzaChsYXN0T3V0cHV0LndlaWdodHNbMF0pO1xuICAgICAgICB9XG4gICAgICAgIHRoaXMuZW5kKCk7XG4gICAgICAgIHJldHVybiBGbG9hdDMyQXJyYXkuZnJvbShyZXN1bHQpO1xuICAgIH1cbiAgICBmb3JlY2FzdEFycmF5T2ZBcnJheShpbnB1dCwgY291bnQgPSAxKSB7XG4gICAgICAgIHRoaXMuY2hlY2tSdW5uYWJsZSgpO1xuICAgICAgICBjb25zdCB7IG1vZGVsIH0gPSB0aGlzO1xuICAgICAgICBjb25zdCB7IGVxdWF0aW9ucyB9ID0gbW9kZWw7XG4gICAgICAgIGNvbnN0IGxlbmd0aCA9IGlucHV0Lmxlbmd0aCArIGNvdW50O1xuICAgICAgICB3aGlsZSAoZXF1YXRpb25zLmxlbmd0aCA8PSBsZW5ndGgpIHtcbiAgICAgICAgICAgIHRoaXMuYmluZEVxdWF0aW9uKCk7XG4gICAgICAgIH1cbiAgICAgICAgbGV0IGxhc3RPdXRwdXQ7XG4gICAgICAgIGxldCBlcXVhdGlvbkluZGV4ID0gMDtcbiAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBpbnB1dC5sZW5ndGg7IGkrKykge1xuICAgICAgICAgICAgbGFzdE91dHB1dCA9IGVxdWF0aW9uc1tlcXVhdGlvbkluZGV4KytdLnJ1bklucHV0KGlucHV0W2ldKTtcbiAgICAgICAgfVxuICAgICAgICBpZiAoIWxhc3RPdXRwdXQpIHtcbiAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcignbGFzdE91dHB1dCBub3Qgc2V0Jyk7XG4gICAgICAgIH1cbiAgICAgICAgY29uc3QgcmVzdWx0ID0gW0Zsb2F0MzJBcnJheS5mcm9tKGxhc3RPdXRwdXQud2VpZ2h0cyldO1xuICAgICAgICBmb3IgKGxldCBpID0gMCwgbWF4ID0gY291bnQgLSAxOyBpIDwgbWF4OyBpKyspIHtcbiAgICAgICAgICAgIGxhc3RPdXRwdXQgPSBlcXVhdGlvbnNbZXF1YXRpb25JbmRleCsrXS5ydW5JbnB1dChsYXN0T3V0cHV0LndlaWdodHMpO1xuICAgICAgICAgICAgcmVzdWx0LnB1c2goRmxvYXQzMkFycmF5LmZyb20obGFzdE91dHB1dC53ZWlnaHRzLnNsaWNlKDApKSk7XG4gICAgICAgIH1cbiAgICAgICAgdGhpcy5lbmQoKTtcbiAgICAgICAgcmV0dXJuIHJlc3VsdDtcbiAgICB9XG4gICAgZm9yZWNhc3RBcnJheU9mT2JqZWN0KGlucHV0LCBjb3VudCA9IDEpIHtcbiAgICAgICAgaWYgKCF0aGlzLmlucHV0TG9va3VwKSB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ3RoaXMuaW5wdXRMb29rdXAgbm90IHNldCcpO1xuICAgICAgICB9XG4gICAgICAgIGlmICghdGhpcy5vdXRwdXRMb29rdXApIHtcbiAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcigndGhpcy5vdXRwdXRMb29rdXAgbm90IHNldCcpO1xuICAgICAgICB9XG4gICAgICAgIGNvbnN0IGZvcm1hdHRlZERhdGEgPSBpbnB1dC5tYXAoKHZhbHVlKSA9PiBsb29rdXAudG9BcnJheSh0aGlzLmlucHV0TG9va3VwLCB2YWx1ZSwgdGhpcy5pbnB1dExvb2t1cExlbmd0aCkpO1xuICAgICAgICByZXR1cm4gdGhpcy5mb3JlY2FzdEFycmF5T2ZBcnJheShmb3JtYXR0ZWREYXRhLCBjb3VudCkubWFwKCh2YWx1ZSkgPT4gbG9va3VwLnRvT2JqZWN0KHRoaXMub3V0cHV0TG9va3VwLCB2YWx1ZSkpO1xuICAgIH1cbiAgICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgQHR5cGVzY3JpcHQtZXNsaW50L2Jhbi10cy1jb21tZW50XG4gICAgLy8gQHRzLWV4cGVjdC1lcnJvclxuICAgIHRyYWluKGRhdGEsIHRyYWluT3B0cyA9IHt9KSB7XG4gICAgICAgIHRoaXMudHJhaW5PcHRzID0gdHJhaW5PcHRzID0ge1xuICAgICAgICAgICAgLi4udHJhaW5EZWZhdWx0cyQxLFxuICAgICAgICAgICAgLi4udHJhaW5PcHRzLFxuICAgICAgICB9O1xuICAgICAgICAvLyBEb24ndCBkZXN0cnVjdHVyZSBoZXJlIGJlY2F1c2UgdGhpcy5zZXRTaXplKCkgY2FuIHJlc2V0IHRoaXMub3B0aW9ucy5cbiAgICAgICAgaWYgKHRoaXMub3B0aW9ucy5pbnB1dFNpemUgPT09IDEgJiYgdGhpcy5vcHRpb25zLm91dHB1dFNpemUgPT09IDEpIHtcbiAgICAgICAgICAgIHRoaXMuc2V0U2l6ZShkYXRhKTtcbiAgICAgICAgfVxuICAgICAgICB0aGlzLnZlcmlmeVNpemUoKTtcbiAgICAgICAgY29uc3QgZm9ybWF0dGVkRGF0YSA9IHRoaXMuZm9ybWF0RGF0YShkYXRhKTtcbiAgICAgICAgbGV0IGVycm9yID0gSW5maW5pdHk7XG4gICAgICAgIGxldCBpO1xuICAgICAgICB0aGlzLnZlcmlmeUlzSW5pdGlhbGl6ZWQoKTtcbiAgICAgICAgY29uc3QgeyBpdGVyYXRpb25zLCBlcnJvclRocmVzaCwgbG9nUGVyaW9kLCBjYWxsYmFjaywgY2FsbGJhY2tQZXJpb2QsIH0gPSB0aGlzLnRyYWluT3B0cztcbiAgICAgICAgY29uc3QgbG9nID0gdHJhaW5PcHRzLmxvZyA9PT0gdHJ1ZSA/IGNvbnNvbGUubG9nIDogdHJhaW5PcHRzLmxvZztcbiAgICAgICAgZm9yIChpID0gMDsgaSA8IGl0ZXJhdGlvbnMgJiYgZXJyb3IgPiBlcnJvclRocmVzaDsgaSsrKSB7XG4gICAgICAgICAgICBsZXQgc3VtID0gMDtcbiAgICAgICAgICAgIGZvciAobGV0IGogPSAwOyBqIDwgZm9ybWF0dGVkRGF0YS5sZW5ndGg7IGorKykge1xuICAgICAgICAgICAgICAgIGNvbnN0IGVyciA9IHRoaXMudHJhaW5QYXR0ZXJuKGZvcm1hdHRlZERhdGFbal0sIHRydWUpO1xuICAgICAgICAgICAgICAgIHN1bSArPSBlcnI7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBlcnJvciA9IHN1bSAvIGZvcm1hdHRlZERhdGEubGVuZ3RoO1xuICAgICAgICAgICAgaWYgKGlzTmFOKGVycm9yKSlcbiAgICAgICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ05ldHdvcmsgZXJyb3IgcmF0ZSBpcyB1bmV4cGVjdGVkIE5hTiwgY2hlY2sgbmV0d29yayBjb25maWd1cmF0aW9ucyBhbmQgdHJ5IGFnYWluLiBNb3N0IHByb2JhYmx5IGlucHV0IGZvcm1hdCBpcyBub3QgY29ycmVjdCBvciB0cmFpbmluZyBkYXRhIGlzIG5vdCBlbm91Z2guICcpO1xuICAgICAgICAgICAgaWYgKGxvZyAmJiBpICUgbG9nUGVyaW9kID09PSAwKSB7XG4gICAgICAgICAgICAgICAgbG9nKGBpdGVyYXRpb25zOiAke2l9LCB0cmFpbmluZyBlcnJvcjogJHtlcnJvcn1gKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGlmIChjYWxsYmFjayAmJiBpICUgY2FsbGJhY2tQZXJpb2QgPT09IDApIHtcbiAgICAgICAgICAgICAgICBjYWxsYmFjayh7IGVycm9yLCBpdGVyYXRpb25zOiBpIH0pO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICBlcnJvcixcbiAgICAgICAgICAgIGl0ZXJhdGlvbnM6IGksXG4gICAgICAgIH07XG4gICAgfVxuICAgIHRyYWluQXJyYXlPZkFycmF5KGlucHV0KSB7XG4gICAgICAgIGlmIChpbnB1dC5sZW5ndGggPCAyKSB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ2lucHV0IG11c3QgYmUgYW4gYXJyYXkgb2YgMiBvciBtb3JlJyk7XG4gICAgICAgIH1cbiAgICAgICAgY29uc3QgeyBlcXVhdGlvbnMgfSA9IHRoaXMubW9kZWw7XG4gICAgICAgIHdoaWxlIChlcXVhdGlvbnMubGVuZ3RoIDwgaW5wdXQubGVuZ3RoKSB7XG4gICAgICAgICAgICB0aGlzLmJpbmRFcXVhdGlvbigpO1xuICAgICAgICB9XG4gICAgICAgIGxldCBlcnJvclN1bSA9IDA7XG4gICAgICAgIGZvciAobGV0IGkgPSAwLCBtYXggPSBpbnB1dC5sZW5ndGggLSAxOyBpIDwgbWF4OyBpKyspIHtcbiAgICAgICAgICAgIGVycm9yU3VtICs9IGVxdWF0aW9uc1tpXS5wcmVkaWN0VGFyZ2V0KGlucHV0W2ldLCBpbnB1dFtpICsgMV0pO1xuICAgICAgICB9XG4gICAgICAgIHRoaXMuZW5kKCk7XG4gICAgICAgIHJldHVybiBlcnJvclN1bSAvIGlucHV0Lmxlbmd0aDtcbiAgICB9XG4gICAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIEB0eXBlc2NyaXB0LWVzbGludC9iYW4tdHMtY29tbWVudFxuICAgIC8vIEB0cy1leHBlY3QtZXJyb3JcbiAgICB0cmFpblBhdHRlcm4oaW5wdXQsIGxvZ0Vycm9yUmF0ZSkge1xuICAgICAgICBjb25zdCBlcnJvciA9IHRoaXMudHJhaW5BcnJheU9mQXJyYXkoaW5wdXQpO1xuICAgICAgICB0aGlzLmJhY2twcm9wYWdhdGUoKTtcbiAgICAgICAgdGhpcy5hZGp1c3RXZWlnaHRzKCk7XG4gICAgICAgIGlmIChsb2dFcnJvclJhdGUpIHtcbiAgICAgICAgICAgIHJldHVybiBlcnJvcjtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gMDtcbiAgICB9XG4gICAgc2V0U2l6ZShkYXRhKSB7XG4gICAgICAgIGxldCBzaXplID0gMDtcbiAgICAgICAgY29uc3QgZGF0YVNoYXBlID0gbG9va3VwLmRhdGFTaGFwZShkYXRhKS5qb2luKCcsJyk7XG4gICAgICAgIHN3aXRjaCAoZGF0YVNoYXBlKSB7XG4gICAgICAgICAgICBjYXNlICdhcnJheSxhcnJheSxudW1iZXInOlxuICAgICAgICAgICAgY2FzZSAnYXJyYXksb2JqZWN0LG51bWJlcic6XG4gICAgICAgICAgICBjYXNlICdhcnJheSxkYXR1bSxhcnJheSxudW1iZXInOlxuICAgICAgICAgICAgY2FzZSAnYXJyYXksZGF0dW0sb2JqZWN0LG51bWJlcic6XG4gICAgICAgICAgICAgICAgc2l6ZSA9IDE7XG4gICAgICAgICAgICAgICAgLy8gcHJvYmFibHkgMVxuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgY2FzZSAnYXJyYXksYXJyYXksYXJyYXksbnVtYmVyJzpcbiAgICAgICAgICAgICAgICBzaXplID0gZGF0YVswXVswXS5sZW5ndGg7XG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICBjYXNlICdhcnJheSxhcnJheSxvYmplY3QsbnVtYmVyJzpcbiAgICAgICAgICAgICAgICAvLyBpbnB1dHMgYW5kIG91dHB1dHMgc2hvdWxkIG1hdGNoXG4gICAgICAgICAgICAgICAgc2l6ZSA9IE9iamVjdC5rZXlzKGxvb2t1cC50b1RhYmxlMkQoZGF0YSkpLmxlbmd0aDtcbiAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgIGNhc2UgJ2FycmF5LGRhdHVtLGFycmF5LGFycmF5LG51bWJlcic6XG4gICAgICAgICAgICAgICAgc2l6ZSA9IGRhdGFbMF0uaW5wdXRbMF0ubGVuZ3RoO1xuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgY2FzZSAnYXJyYXksZGF0dW0sYXJyYXksb2JqZWN0LG51bWJlcic6XG4gICAgICAgICAgICAgICAgc2l6ZSA9IE9iamVjdC5rZXlzKGxvb2t1cC50b0lucHV0VGFibGUyRChkYXRhKSkubGVuZ3RoO1xuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgZGVmYXVsdDpcbiAgICAgICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ3Vua25vd24gZGF0YSBzaGFwZSBvciBjb25maWd1cmF0aW9uJyk7XG4gICAgICAgIH1cbiAgICAgICAgdGhpcy5vcHRpb25zID0gT2JqZWN0LnNlYWwoe1xuICAgICAgICAgICAgLi4udGhpcy5vcHRpb25zLFxuICAgICAgICAgICAgaW5wdXRTaXplOiBzaXplLFxuICAgICAgICAgICAgb3V0cHV0U2l6ZTogc2l6ZSxcbiAgICAgICAgfSk7XG4gICAgfVxuICAgIHZlcmlmeVNpemUoKSB7XG4gICAgICAgIGlmICh0aGlzLm9wdGlvbnMuaW5wdXRTaXplIHx8IHRoaXMub3B0aW9ucy5vdXRwdXRTaXplKSB7XG4gICAgICAgICAgICBpZiAodGhpcy5vcHRpb25zLmlucHV0U2l6ZSAhPT0gdGhpcy5vcHRpb25zLm91dHB1dFNpemUpIHtcbiAgICAgICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ21hbnVhbGx5IHNldCBpbnB1dFNpemUgYW5kIG91dHB1dFNpemUgbWlzbWF0Y2gnKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIH1cbiAgICBydW5BcnJheShpbnB1dCkge1xuICAgICAgICB0aGlzLmNoZWNrUnVubmFibGUoKTtcbiAgICAgICAgY29uc3QgeyBlcXVhdGlvbnMgfSA9IHRoaXMubW9kZWw7XG4gICAgICAgIHdoaWxlIChlcXVhdGlvbnMubGVuZ3RoIDw9IGlucHV0Lmxlbmd0aCkge1xuICAgICAgICAgICAgdGhpcy5iaW5kRXF1YXRpb24oKTtcbiAgICAgICAgfVxuICAgICAgICBsZXQgbGFzdE91dHB1dDtcbiAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBpbnB1dC5sZW5ndGg7IGkrKykge1xuICAgICAgICAgICAgbGFzdE91dHB1dCA9IGVxdWF0aW9uc1tpXS5ydW5JbnB1dChuZXcgRmxvYXQzMkFycmF5KFtpbnB1dFtpXV0pKTtcbiAgICAgICAgfVxuICAgICAgICB0aGlzLmVuZCgpO1xuICAgICAgICByZXR1cm4gbGFzdE91dHB1dC53ZWlnaHRzWzBdO1xuICAgIH1cbiAgICBydW5BcnJheU9mQXJyYXkoaW5wdXQpIHtcbiAgICAgICAgdGhpcy5jaGVja1J1bm5hYmxlKCk7XG4gICAgICAgIGNvbnN0IHsgbW9kZWwgfSA9IHRoaXM7XG4gICAgICAgIGNvbnN0IHsgZXF1YXRpb25zIH0gPSBtb2RlbDtcbiAgICAgICAgd2hpbGUgKGVxdWF0aW9ucy5sZW5ndGggPD0gaW5wdXQubGVuZ3RoKSB7XG4gICAgICAgICAgICB0aGlzLmJpbmRFcXVhdGlvbigpO1xuICAgICAgICB9XG4gICAgICAgIGxldCBsYXN0T3V0cHV0O1xuICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IGlucHV0Lmxlbmd0aDsgaSsrKSB7XG4gICAgICAgICAgICBjb25zdCBvdXRwdXRNYXRyaXggPSBlcXVhdGlvbnNbaV0ucnVuSW5wdXQoaW5wdXRbaV0pO1xuICAgICAgICAgICAgbGFzdE91dHB1dCA9IG91dHB1dE1hdHJpeC53ZWlnaHRzO1xuICAgICAgICB9XG4gICAgICAgIHRoaXMuZW5kKCk7XG4gICAgICAgIHJldHVybiBsYXN0T3V0cHV0ICE9PSBudWxsICYmIGxhc3RPdXRwdXQgIT09IHZvaWQgMCA/IGxhc3RPdXRwdXQgOiBGbG9hdDMyQXJyYXkuZnJvbShbXSk7XG4gICAgfVxuICAgIHJ1bk9iamVjdChpbnB1dCkge1xuICAgICAgICBpZiAoIXRoaXMuaW5wdXRMb29rdXApIHtcbiAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcigndGhpcy5pbnB1dExvb2t1cCBub3Qgc2V0Jyk7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKCF0aGlzLm91dHB1dExvb2t1cCkge1xuICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKCd0aGlzLm91dHB1dExvb2t1cCBub3Qgc2V0Jyk7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKCF0aGlzLm91dHB1dExvb2t1cExlbmd0aCkge1xuICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKCd0aGlzLm91dHB1dExvb2t1cExlbmd0aCBub3Qgc2V0Jyk7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKHRoaXMuaW5wdXRMb29rdXAgPT09IHRoaXMub3V0cHV0TG9va3VwKSB7XG4gICAgICAgICAgICBjb25zdCBpbnB1dEFycmF5ID0gbG9va3VwLnRvQXJyYXlTaG9ydCh0aGlzLmlucHV0TG9va3VwLCBpbnB1dCk7XG4gICAgICAgICAgICByZXR1cm4gbG9va3VwLnRvT2JqZWN0UGFydGlhbCh0aGlzLm91dHB1dExvb2t1cCwgdGhpcy5mb3JlY2FzdEFycmF5KGlucHV0QXJyYXksIHRoaXMub3V0cHV0TG9va3VwTGVuZ3RoIC0gaW5wdXRBcnJheS5sZW5ndGgpLCBpbnB1dEFycmF5Lmxlbmd0aCk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIGxvb2t1cC50b09iamVjdCh0aGlzLm91dHB1dExvb2t1cCwgdGhpcy5mb3JlY2FzdEFycmF5KGxvb2t1cC50b0FycmF5KHRoaXMuaW5wdXRMb29rdXAsIGlucHV0LCB0aGlzLmlucHV0TG9va3VwTGVuZ3RoKSwgdGhpcy5vdXRwdXRMb29rdXBMZW5ndGgpKTtcbiAgICB9XG4gICAgcnVuQXJyYXlPZk9iamVjdChpbnB1dCkge1xuICAgICAgICBpZiAodGhpcy5pbnB1dExvb2t1cCA9PT0gbnVsbCkge1xuICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKCd0aGlzLmlucHV0TG9va3VwIG5vdCBzZXQnKTtcbiAgICAgICAgfVxuICAgICAgICBpZiAodGhpcy5vdXRwdXRMb29rdXAgPT09IG51bGwpIHtcbiAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcigndGhpcy5vdXRwdXRMb29rdXAgbm90IHNldCcpO1xuICAgICAgICB9XG4gICAgICAgIGNvbnN0IGZvcm1hdHRlZElucHV0ID0gaW5wdXQubWFwKCh2YWx1ZSkgPT4gbG9va3VwLnRvQXJyYXkodGhpcy5pbnB1dExvb2t1cCwgdmFsdWUsIHRoaXMuaW5wdXRMb29rdXBMZW5ndGgpKTtcbiAgICAgICAgcmV0dXJuIHRoaXMuZm9yZWNhc3RBcnJheU9mQXJyYXkoZm9ybWF0dGVkSW5wdXQsIDEpLm1hcCgodmFsdWUpID0+IGxvb2t1cC50b09iamVjdCh0aGlzLm91dHB1dExvb2t1cCwgdmFsdWUpKVswXTtcbiAgICB9XG4gICAgcnVuQXJyYXlPZk9iamVjdE9mQXJyYXkoaW5wdXQpIHtcbiAgICAgICAgaWYgKCF0aGlzLmlucHV0TG9va3VwKSB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ3RoaXMuaW5wdXRMb29rdXAgbm90IHNldCcpO1xuICAgICAgICB9XG4gICAgICAgIGlmICghdGhpcy5vdXRwdXRMb29rdXApIHtcbiAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcigndGhpcy5vdXRwdXRMb29rdXAgbm90IHNldCcpO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBsb29rdXAudG9PYmplY3QodGhpcy5vdXRwdXRMb29rdXAsIHRoaXMucnVuQXJyYXlPZkFycmF5KGxvb2t1cC50b0FycmF5cyh0aGlzLmlucHV0TG9va3VwLCBpbnB1dCwgdGhpcy5pbnB1dExvb2t1cExlbmd0aCkpKTtcbiAgICB9XG4gICAgZW5kKCkge1xuICAgICAgICB0aGlzLm1vZGVsLmVxdWF0aW9uc1t0aGlzLm1vZGVsLmVxdWF0aW9ucy5sZW5ndGggLSAxXS5ydW5JbnB1dChuZXcgRmxvYXQzMkFycmF5KHRoaXMub3B0aW9ucy5vdXRwdXRTaXplKSk7XG4gICAgfVxuICAgIHJlcXVpcmVJbnB1dE91dHB1dE9mT25lKCkge1xuICAgICAgICBpZiAodGhpcy5vcHRpb25zLmlucHV0U2l6ZSAhPT0gMSkge1xuICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdpbnB1dFNpemUgbXVzdCBiZSAxIGZvciB0aGlzIGRhdGEgc2l6ZScpO1xuICAgICAgICB9XG4gICAgICAgIGlmICh0aGlzLm9wdGlvbnMub3V0cHV0U2l6ZSAhPT0gMSkge1xuICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdvdXRwdXRTaXplIG11c3QgYmUgMSBmb3IgdGhpcyBkYXRhIHNpemUnKTtcbiAgICAgICAgfVxuICAgIH1cbiAgICAvLyBIYW5kbGVzIGRhdGEgc2hhcGUgb2YgJ2FycmF5LG51bWJlcidcbiAgICBmb3JtYXRBcnJheShkYXRhKSB7XG4gICAgICAgIGNvbnN0IHJlc3VsdCA9IFtdO1xuICAgICAgICB0aGlzLnJlcXVpcmVJbnB1dE91dHB1dE9mT25lKCk7XG4gICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgZGF0YS5sZW5ndGg7IGkrKykge1xuICAgICAgICAgICAgcmVzdWx0LnB1c2goRmxvYXQzMkFycmF5LmZyb20oW2RhdGFbaV1dKSk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIFtyZXN1bHRdO1xuICAgIH1cbiAgICAvLyBIYW5kbGVzIGRhdGEgc2hhcGUgb2YgJ2FycmF5LGFycmF5LG51bWJlcidcbiAgICBmb3JtYXRBcnJheU9mQXJyYXkoZGF0YSkge1xuICAgICAgICBjb25zdCByZXN1bHQgPSBbXTtcbiAgICAgICAgY29uc3QgeyBpbnB1dFNpemUsIG91dHB1dFNpemUgfSA9IHRoaXMub3B0aW9ucztcbiAgICAgICAgaWYgKGlucHV0U2l6ZSA9PT0gMSAmJiBvdXRwdXRTaXplID09PSAxKSB7XG4gICAgICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IGRhdGEubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgICAgICAgICByZXN1bHQucHVzaChhcnJheVRvRmxvYXQzMkFycmF5cyhkYXRhW2ldKSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICByZXR1cm4gcmVzdWx0O1xuICAgICAgICB9XG4gICAgICAgIGlmIChpbnB1dFNpemUgIT09IGRhdGFbMF0ubGVuZ3RoKSB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ2lucHV0U2l6ZSBtdXN0IG1hdGNoIGRhdGEgaW5wdXQgc2l6ZScpO1xuICAgICAgICB9XG4gICAgICAgIGlmIChvdXRwdXRTaXplICE9PSBkYXRhWzBdLmxlbmd0aCkge1xuICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdvdXRwdXRTaXplIG11c3QgbWF0Y2ggZGF0YSBvdXRwdXQgc2l6ZScpO1xuICAgICAgICB9XG4gICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgZGF0YS5sZW5ndGg7IGkrKykge1xuICAgICAgICAgICAgcmVzdWx0LnB1c2goRmxvYXQzMkFycmF5LmZyb20oZGF0YVtpXSkpO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBbcmVzdWx0XTtcbiAgICB9XG4gICAgLy8gSGFuZGxlcyBkYXRhIHNoYXBlIG9mICdhcnJheSxvYmplY3QsbnVtYmVyJ1xuICAgIGZvcm1hdEFycmF5T2ZPYmplY3QoZGF0YSkge1xuICAgICAgICB0aGlzLnJlcXVpcmVJbnB1dE91dHB1dE9mT25lKCk7XG4gICAgICAgIGlmICghdGhpcy5pbnB1dExvb2t1cCkge1xuICAgICAgICAgICAgY29uc3QgbG9va3VwVGFibGUgPSBuZXcgTG9va3VwVGFibGUoZGF0YSk7XG4gICAgICAgICAgICB0aGlzLmlucHV0TG9va3VwID0gdGhpcy5vdXRwdXRMb29rdXAgPSBsb29rdXBUYWJsZS50YWJsZTtcbiAgICAgICAgICAgIHRoaXMuaW5wdXRMb29rdXBMZW5ndGggPSB0aGlzLm91dHB1dExvb2t1cExlbmd0aCA9IGxvb2t1cFRhYmxlLmxlbmd0aDtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCByZXN1bHQgPSBbXTtcbiAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBkYXRhLmxlbmd0aDsgaSsrKSB7XG4gICAgICAgICAgICByZXN1bHQucHVzaChvYmplY3RUb0Zsb2F0MzJBcnJheXMoZGF0YVtpXSkpO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiByZXN1bHQ7XG4gICAgfVxuICAgIC8vIEhhbmRsZXMgZGF0YSBzaGFwZSBvZiAnYXJyYXksb2JqZWN0LG51bWJlcicgd2hlbiB0aGlzLm9wdGlvbnMuaW5wdXRTaXplID4gMVxuICAgIGZvcm1hdEFycmF5T2ZPYmplY3RNdWx0aShkYXRhKSB7XG4gICAgICAgIGlmICghdGhpcy5pbnB1dExvb2t1cCkge1xuICAgICAgICAgICAgY29uc3QgbG9va3VwVGFibGUgPSBuZXcgTG9va3VwVGFibGUoZGF0YSk7XG4gICAgICAgICAgICB0aGlzLmlucHV0TG9va3VwID0gdGhpcy5vdXRwdXRMb29rdXAgPSBsb29rdXBUYWJsZS50YWJsZTtcbiAgICAgICAgICAgIHRoaXMuaW5wdXRMb29rdXBMZW5ndGggPSB0aGlzLm91dHB1dExvb2t1cExlbmd0aCA9IGxvb2t1cFRhYmxlLmxlbmd0aDtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCByZXN1bHQgPSBbXTtcbiAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBkYXRhLmxlbmd0aDsgaSsrKSB7XG4gICAgICAgICAgICByZXN1bHQucHVzaChbXG4gICAgICAgICAgICAgICAgb2JqZWN0VG9GbG9hdDMyQXJyYXkoZGF0YVtpXSwgdGhpcy5pbnB1dExvb2t1cCwgdGhpcy5pbnB1dExvb2t1cExlbmd0aCksXG4gICAgICAgICAgICBdKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gcmVzdWx0O1xuICAgIH1cbiAgICAvLyBIYW5kbGVzIGRhdGEgc2hhcGUgb2YgJ2FycmF5LGRhdHVtLGFycmF5LG51bWJlcidcbiAgICBmb3JtYXRBcnJheU9mRGF0dW1PZkFycmF5KGRhdGEpIHtcbiAgICAgICAgY29uc3QgcmVzdWx0ID0gW107XG4gICAgICAgIHRoaXMucmVxdWlyZUlucHV0T3V0cHV0T2ZPbmUoKTtcbiAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBkYXRhLmxlbmd0aDsgaSsrKSB7XG4gICAgICAgICAgICBjb25zdCBkYXR1bSA9IGRhdGFbaV07XG4gICAgICAgICAgICByZXN1bHQucHVzaChpbnB1dE91dHB1dEFycmF5VG9GbG9hdDMyQXJyYXlzKGRhdHVtLmlucHV0LCBkYXR1bS5vdXRwdXQpKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gcmVzdWx0O1xuICAgIH1cbiAgICAvLyBIYW5kbGVzIGRhdGEgc2hhcGUgb2YgJ2FycmF5LGRhdHVtLG9iamVjdCxudW1iZXInXG4gICAgZm9ybWF0QXJyYXlPZkRhdHVtT2ZPYmplY3QoZGF0YSkge1xuICAgICAgICB0aGlzLnJlcXVpcmVJbnB1dE91dHB1dE9mT25lKCk7XG4gICAgICAgIGlmICghdGhpcy5pbnB1dExvb2t1cCkge1xuICAgICAgICAgICAgY29uc3QgaW5wdXRMb29rdXAgPSBuZXcgTG9va3VwVGFibGUoZGF0YSwgJ2lucHV0Jyk7XG4gICAgICAgICAgICB0aGlzLmlucHV0TG9va3VwID0gaW5wdXRMb29rdXAudGFibGU7XG4gICAgICAgICAgICB0aGlzLmlucHV0TG9va3VwTGVuZ3RoID0gaW5wdXRMb29rdXAubGVuZ3RoO1xuICAgICAgICB9XG4gICAgICAgIGlmICghdGhpcy5vdXRwdXRMb29rdXApIHtcbiAgICAgICAgICAgIGNvbnN0IG91dHB1dExvb2t1cCA9IG5ldyBMb29rdXBUYWJsZShkYXRhLCAnb3V0cHV0Jyk7XG4gICAgICAgICAgICB0aGlzLm91dHB1dExvb2t1cCA9IG91dHB1dExvb2t1cC50YWJsZTtcbiAgICAgICAgICAgIHRoaXMub3V0cHV0TG9va3VwTGVuZ3RoID0gb3V0cHV0TG9va3VwLmxlbmd0aDtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCByZXN1bHQgPSBbXTtcbiAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBkYXRhLmxlbmd0aDsgaSsrKSB7XG4gICAgICAgICAgICBjb25zdCBkYXR1bSA9IGRhdGFbaV07XG4gICAgICAgICAgICByZXN1bHQucHVzaChpbnB1dE91dHB1dE9iamVjdFRvRmxvYXQzMkFycmF5cyhkYXR1bS5pbnB1dCwgZGF0dW0ub3V0cHV0KSk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHJlc3VsdDtcbiAgICB9XG4gICAgLy8gSGFuZGxlcyBkYXRhIHNoYXBlIG9mICdhcnJheSxhcnJheSxhcnJheSxudW1iZXInXG4gICAgZm9ybWF0QXJyYXlPZkFycmF5T2ZBcnJheShkYXRhKSB7XG4gICAgICAgIGNvbnN0IHJlc3VsdCA9IFtdO1xuICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IGRhdGEubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgICAgIHJlc3VsdC5wdXNoKGFycmF5c1RvRmxvYXQzMkFycmF5cyhkYXRhW2ldKSk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHJlc3VsdDtcbiAgICB9XG4gICAgLy8gSGFuZGxlcyBkYXRhIHNoYXBlIG9mICdhcnJheSxhcnJheSxvYmplY3QsbnVtYmVyJ1xuICAgIGZvcm1hdEFycmF5T2ZBcnJheU9mT2JqZWN0KGRhdGEpIHtcbiAgICAgICAgaWYgKCF0aGlzLmlucHV0TG9va3VwKSB7XG4gICAgICAgICAgICBjb25zdCBsb29rdXBUYWJsZSA9IG5ldyBMb29rdXBUYWJsZShkYXRhKTtcbiAgICAgICAgICAgIHRoaXMuaW5wdXRMb29rdXAgPSB0aGlzLm91dHB1dExvb2t1cCA9IGxvb2t1cFRhYmxlLnRhYmxlO1xuICAgICAgICAgICAgdGhpcy5pbnB1dExvb2t1cExlbmd0aCA9IHRoaXMub3V0cHV0TG9va3VwTGVuZ3RoID0gbG9va3VwVGFibGUubGVuZ3RoO1xuICAgICAgICB9XG4gICAgICAgIGNvbnN0IHJlc3VsdCA9IFtdO1xuICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IGRhdGEubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgICAgIGNvbnN0IGFycmF5ID0gW107XG4gICAgICAgICAgICBmb3IgKGxldCBqID0gMDsgaiA8IGRhdGFbaV0ubGVuZ3RoOyBqKyspIHtcbiAgICAgICAgICAgICAgICBhcnJheS5wdXNoKG9iamVjdFRvRmxvYXQzMkFycmF5KGRhdGFbaV1bal0sIHRoaXMuaW5wdXRMb29rdXAsIHRoaXMuaW5wdXRMb29rdXBMZW5ndGgpKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHJlc3VsdC5wdXNoKGFycmF5KTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gcmVzdWx0O1xuICAgIH1cbiAgICAvLyBIYW5kbGVzIGRhdGEgc2hhcGUgb2YgJ2FycmF5LGRhdHVtLGFycmF5LGFycmF5LG51bWJlcidcbiAgICBmb3JtYXRBcnJheU9mRGF0dW1PZkFycmF5T2ZBcnJheShkYXRhKSB7XG4gICAgICAgIGNvbnN0IHJlc3VsdCA9IFtdO1xuICAgICAgICBjb25zdCB7IGlucHV0U2l6ZSwgb3V0cHV0U2l6ZSB9ID0gdGhpcy5vcHRpb25zO1xuICAgICAgICBpZiAoaW5wdXRTaXplICE9PSBkYXRhWzBdLmlucHV0WzBdLmxlbmd0aCkge1xuICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdpbnB1dFNpemUgbXVzdCBtYXRjaCBkYXRhIGlucHV0IHNpemUnKTtcbiAgICAgICAgfVxuICAgICAgICBpZiAob3V0cHV0U2l6ZSAhPT0gZGF0YVswXS5vdXRwdXRbMF0ubGVuZ3RoKSB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ291dHB1dFNpemUgbXVzdCBtYXRjaCBkYXRhIG91dHB1dCBzaXplJyk7XG4gICAgICAgIH1cbiAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBkYXRhLmxlbmd0aDsgaSsrKSB7XG4gICAgICAgICAgICBjb25zdCBkYXR1bSA9IGRhdGFbaV07XG4gICAgICAgICAgICByZXN1bHQucHVzaChpbnB1dE91dHB1dEFycmF5c1RvRmxvYXQzMkFycmF5cyhkYXR1bS5pbnB1dCwgZGF0dW0ub3V0cHV0KSk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHJlc3VsdDtcbiAgICB9XG4gICAgLy8gJ0hhbmRsZXMgZGF0YSBzaGFwZSBvZiBhcnJheSxkYXR1bSxhcnJheSxvYmplY3QsbnVtYmVyJ1xuICAgIGZvcm1hdEFycmF5T2ZEYXR1bU9mQXJyYXlPZk9iamVjdChkYXRhKSB7XG4gICAgICAgIGlmICghdGhpcy5pbnB1dExvb2t1cCkge1xuICAgICAgICAgICAgY29uc3QgaW5wdXRMb29rdXAgPSBuZXcgQXJyYXlMb29rdXBUYWJsZShkYXRhLCAnaW5wdXQnKTtcbiAgICAgICAgICAgIHRoaXMuaW5wdXRMb29rdXAgPSBpbnB1dExvb2t1cC50YWJsZTtcbiAgICAgICAgICAgIHRoaXMuaW5wdXRMb29rdXBMZW5ndGggPSBpbnB1dExvb2t1cC5sZW5ndGg7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKCF0aGlzLm91dHB1dExvb2t1cCkge1xuICAgICAgICAgICAgY29uc3Qgb3V0cHV0TG9va3VwID0gbmV3IEFycmF5TG9va3VwVGFibGUoZGF0YSwgJ291dHB1dCcpO1xuICAgICAgICAgICAgdGhpcy5vdXRwdXRMb29rdXAgPSBvdXRwdXRMb29rdXAudGFibGU7XG4gICAgICAgICAgICB0aGlzLm91dHB1dExvb2t1cExlbmd0aCA9IG91dHB1dExvb2t1cC5sZW5ndGg7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKCF0aGlzLm91dHB1dExvb2t1cExlbmd0aCkge1xuICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKCd0aGlzLm91dHB1dExvb2t1cExlbmd0aCBub3Qgc2V0IHRvIHVzYWJsZSBudW1iZXInKTtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCByZXN1bHQgPSBbXTtcbiAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBkYXRhLmxlbmd0aDsgaSsrKSB7XG4gICAgICAgICAgICBjb25zdCBkYXR1bSA9IGRhdGFbaV07XG4gICAgICAgICAgICByZXN1bHQucHVzaChpbnB1dE91dHB1dE9iamVjdHNUb0Zsb2F0MzJBcnJheXMoZGF0dW0uaW5wdXQsIGRhdHVtLm91dHB1dCwgdGhpcy5pbnB1dExvb2t1cCwgdGhpcy5vdXRwdXRMb29rdXAsIHRoaXMuaW5wdXRMb29rdXBMZW5ndGgsIHRoaXMub3V0cHV0TG9va3VwTGVuZ3RoKSk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHJlc3VsdDtcbiAgICB9XG4gICAgZm9ybWF0RGF0YShkYXRhKSB7XG4gICAgICAgIGNvbnN0IGRhdGFTaGFwZSA9IGxvb2t1cC5kYXRhU2hhcGUoZGF0YSkuam9pbignLCcpO1xuICAgICAgICBzd2l0Y2ggKGRhdGFTaGFwZSkge1xuICAgICAgICAgICAgY2FzZSAnYXJyYXksbnVtYmVyJzpcbiAgICAgICAgICAgICAgICByZXR1cm4gdGhpcy5mb3JtYXRBcnJheShkYXRhKTtcbiAgICAgICAgICAgIGNhc2UgJ2FycmF5LGFycmF5LG51bWJlcic6XG4gICAgICAgICAgICAgICAgcmV0dXJuIHRoaXMuZm9ybWF0QXJyYXlPZkFycmF5KGRhdGEpO1xuICAgICAgICAgICAgY2FzZSAnYXJyYXksb2JqZWN0LG51bWJlcic6XG4gICAgICAgICAgICAgICAgaWYgKHRoaXMub3B0aW9ucy5pbnB1dFNpemUgPT09IDEpIHtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHRoaXMuZm9ybWF0QXJyYXlPZk9iamVjdChkYXRhKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiB0aGlzLmZvcm1hdEFycmF5T2ZPYmplY3RNdWx0aShkYXRhKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICBjYXNlICdhcnJheSxkYXR1bSxhcnJheSxudW1iZXInOlxuICAgICAgICAgICAgICAgIHJldHVybiB0aGlzLmZvcm1hdEFycmF5T2ZEYXR1bU9mQXJyYXkoZGF0YSk7XG4gICAgICAgICAgICBjYXNlICdhcnJheSxkYXR1bSxvYmplY3QsbnVtYmVyJzpcbiAgICAgICAgICAgICAgICByZXR1cm4gdGhpcy5mb3JtYXRBcnJheU9mRGF0dW1PZk9iamVjdChkYXRhKTtcbiAgICAgICAgICAgIGNhc2UgJ2FycmF5LGFycmF5LGFycmF5LG51bWJlcic6XG4gICAgICAgICAgICAgICAgcmV0dXJuIHRoaXMuZm9ybWF0QXJyYXlPZkFycmF5T2ZBcnJheShkYXRhKTtcbiAgICAgICAgICAgIGNhc2UgJ2FycmF5LGFycmF5LG9iamVjdCxudW1iZXInOlxuICAgICAgICAgICAgICAgIHJldHVybiB0aGlzLmZvcm1hdEFycmF5T2ZBcnJheU9mT2JqZWN0KGRhdGEpO1xuICAgICAgICAgICAgY2FzZSAnYXJyYXksZGF0dW0sYXJyYXksYXJyYXksbnVtYmVyJzpcbiAgICAgICAgICAgICAgICByZXR1cm4gdGhpcy5mb3JtYXRBcnJheU9mRGF0dW1PZkFycmF5T2ZBcnJheShkYXRhKTtcbiAgICAgICAgICAgIGNhc2UgJ2FycmF5LGRhdHVtLGFycmF5LG9iamVjdCxudW1iZXInOlxuICAgICAgICAgICAgICAgIHJldHVybiB0aGlzLmZvcm1hdEFycmF5T2ZEYXR1bU9mQXJyYXlPZk9iamVjdChkYXRhKTtcbiAgICAgICAgICAgIGRlZmF1bHQ6XG4gICAgICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKCd1bmtub3duIGRhdGEgc2hhcGUgb3IgY29uZmlndXJhdGlvbicpO1xuICAgICAgICB9XG4gICAgfVxuICAgIHRlc3QoZGF0YSkge1xuICAgICAgICAvLyBmb3IgY2xhc3NpZmljYXRpb24gcHJvYmxlbXNcbiAgICAgICAgY29uc3QgbWlzY2xhc3NlcyA9IFtdO1xuICAgICAgICAvLyBydW4gZWFjaCBwYXR0ZXJuIHRocm91Z2ggdGhlIHRyYWluZWQgbmV0d29yayBhbmQgY29sbGVjdFxuICAgICAgICAvLyBlcnJvciBhbmQgbWlzY2xhc3NpZmljYXRpb24gc3RhdGlzdGljc1xuICAgICAgICBsZXQgZXJyb3JTdW0gPSAwO1xuICAgICAgICBjb25zdCBmb3JtYXR0ZWREYXRhID0gdGhpcy5mb3JtYXREYXRhKGRhdGEpO1xuICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IGZvcm1hdHRlZERhdGEubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgICAgIGNvbnN0IGlucHV0ID0gZm9ybWF0dGVkRGF0YVtpXTtcbiAgICAgICAgICAgIGNvbnN0IG91dHB1dCA9IHRoaXMucnVuKGlucHV0LnNwbGljZSgwLCBpbnB1dC5sZW5ndGggLSAxKSk7XG4gICAgICAgICAgICBjb25zdCB0YXJnZXQgPSBpbnB1dFtpbnB1dC5sZW5ndGggLSAxXTtcbiAgICAgICAgICAgIGxldCBlcnJvcnMgPSAwO1xuICAgICAgICAgICAgbGV0IGVycm9yQ291bnQgPSAwO1xuICAgICAgICAgICAgZm9yIChsZXQgaiA9IDA7IGogPCBvdXRwdXQubGVuZ3RoOyBqKyspIHtcbiAgICAgICAgICAgICAgICBlcnJvckNvdW50Kys7XG4gICAgICAgICAgICAgICAgY29uc3QgZXJyb3IgPSB0YXJnZXRbal0gLSBvdXRwdXRbal07XG4gICAgICAgICAgICAgICAgLy8gbXNlXG4gICAgICAgICAgICAgICAgZXJyb3JzICs9IGVycm9yICogZXJyb3I7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBlcnJvclN1bSArPSBlcnJvcnMgLyBlcnJvckNvdW50O1xuICAgICAgICAgICAgY29uc3QgZXJyb3JzQWJzID0gTWF0aC5hYnMoZXJyb3JzKTtcbiAgICAgICAgICAgIGlmIChlcnJvcnNBYnMgPiB0aGlzLnRyYWluT3B0cy5lcnJvclRocmVzaCkge1xuICAgICAgICAgICAgICAgIGNvbnN0IG1pc2NsYXNzID0gZGF0YVtpXTtcbiAgICAgICAgICAgICAgICBtaXNjbGFzc2VzLnB1c2goe1xuICAgICAgICAgICAgICAgICAgICB2YWx1ZTogbWlzY2xhc3MsXG4gICAgICAgICAgICAgICAgICAgIGFjdHVhbDogb3V0cHV0LFxuICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICBlcnJvcjogZXJyb3JTdW0gLyBmb3JtYXR0ZWREYXRhLmxlbmd0aCxcbiAgICAgICAgICAgIG1pc2NsYXNzZXMsXG4gICAgICAgICAgICB0b3RhbDogZm9ybWF0dGVkRGF0YS5sZW5ndGgsXG4gICAgICAgIH07XG4gICAgfVxuICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBAdHlwZXNjcmlwdC1lc2xpbnQvYmFuLXRzLWNvbW1lbnRcbiAgICAvLyBAdHMtZXhwZWN0LWVycm9yXG4gICAgYWRkRm9ybWF0KHZhbHVlKSB7XG4gICAgICAgIHZhciBfYSwgX2IsIF9jLCBfZCwgX2UsIF9mO1xuICAgICAgICBjb25zdCBkYXRhU2hhcGUgPSBsb29rdXAuZGF0YVNoYXBlKHZhbHVlKS5qb2luKCcsJyk7XG4gICAgICAgIHN3aXRjaCAoZGF0YVNoYXBlKSB7XG4gICAgICAgICAgICBjYXNlICdhcnJheSxhcnJheSxudW1iZXInOlxuICAgICAgICAgICAgY2FzZSAnZGF0dW0sYXJyYXksYXJyYXksbnVtYmVyJzpcbiAgICAgICAgICAgIGNhc2UgJ2FycmF5LG51bWJlcic6XG4gICAgICAgICAgICBjYXNlICdkYXR1bSxhcnJheSxudW1iZXInOlxuICAgICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgIGNhc2UgJ2RhdHVtLG9iamVjdCxudW1iZXInOiB7XG4gICAgICAgICAgICAgICAgdGhpcy5pbnB1dExvb2t1cCA9IGxvb2t1cC5hZGRLZXlzKHZhbHVlLmlucHV0LCAoX2EgPSB0aGlzLmlucHV0TG9va3VwKSAhPT0gbnVsbCAmJiBfYSAhPT0gdm9pZCAwID8gX2EgOiB7fSk7XG4gICAgICAgICAgICAgICAgaWYgKHRoaXMuaW5wdXRMb29rdXApIHtcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5pbnB1dExvb2t1cExlbmd0aCA9IE9iamVjdC5rZXlzKHRoaXMuaW5wdXRMb29rdXApLmxlbmd0aDtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgdGhpcy5vdXRwdXRMb29rdXAgPSBsb29rdXAuYWRkS2V5cyh2YWx1ZS5vdXRwdXQsIChfYiA9IHRoaXMub3V0cHV0TG9va3VwKSAhPT0gbnVsbCAmJiBfYiAhPT0gdm9pZCAwID8gX2IgOiB7fSk7XG4gICAgICAgICAgICAgICAgaWYgKHRoaXMub3V0cHV0TG9va3VwKSB7XG4gICAgICAgICAgICAgICAgICAgIHRoaXMub3V0cHV0TG9va3VwTGVuZ3RoID0gT2JqZWN0LmtleXModGhpcy5vdXRwdXRMb29rdXApLmxlbmd0aDtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBjYXNlICdvYmplY3QsbnVtYmVyJzoge1xuICAgICAgICAgICAgICAgIHRoaXMuaW5wdXRMb29rdXAgPSB0aGlzLm91dHB1dExvb2t1cCA9IGxvb2t1cC5hZGRLZXlzKHZhbHVlLCAoX2MgPSB0aGlzLmlucHV0TG9va3VwKSAhPT0gbnVsbCAmJiBfYyAhPT0gdm9pZCAwID8gX2MgOiB7fSk7XG4gICAgICAgICAgICAgICAgaWYgKHRoaXMuaW5wdXRMb29rdXApIHtcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5pbnB1dExvb2t1cExlbmd0aCA9IHRoaXMub3V0cHV0TG9va3VwTGVuZ3RoID0gT2JqZWN0LmtleXModGhpcy5pbnB1dExvb2t1cCkubGVuZ3RoO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGNhc2UgJ2FycmF5LG9iamVjdCxudW1iZXInOiB7XG4gICAgICAgICAgICAgICAgY29uc3QgdHlwZWRWYWx1ZSA9IHZhbHVlO1xuICAgICAgICAgICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgdHlwZWRWYWx1ZS5sZW5ndGg7IGkrKykge1xuICAgICAgICAgICAgICAgICAgICB0aGlzLmlucHV0TG9va3VwID0gdGhpcy5vdXRwdXRMb29rdXAgPSBsb29rdXAuYWRkS2V5cyh0eXBlZFZhbHVlW2ldLCAoX2QgPSB0aGlzLmlucHV0TG9va3VwKSAhPT0gbnVsbCAmJiBfZCAhPT0gdm9pZCAwID8gX2QgOiB7fSk7XG4gICAgICAgICAgICAgICAgICAgIGlmICh0aGlzLmlucHV0TG9va3VwKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLmlucHV0TG9va3VwTGVuZ3RoID0gdGhpcy5vdXRwdXRMb29rdXBMZW5ndGggPSBPYmplY3Qua2V5cyh0aGlzLmlucHV0TG9va3VwKS5sZW5ndGg7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBjYXNlICdkYXR1bSxhcnJheSxvYmplY3QsbnVtYmVyJzoge1xuICAgICAgICAgICAgICAgIGNvbnN0IHR5cGVkVmFsdWUgPSB2YWx1ZTtcbiAgICAgICAgICAgICAgICBjb25zdCB0eXBlZElucHV0ID0gdHlwZWRWYWx1ZS5pbnB1dDtcbiAgICAgICAgICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IHR5cGVkSW5wdXQubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5pbnB1dExvb2t1cCA9IGxvb2t1cC5hZGRLZXlzKHR5cGVkSW5wdXRbaV0sIChfZSA9IHRoaXMuaW5wdXRMb29rdXApICE9PSBudWxsICYmIF9lICE9PSB2b2lkIDAgPyBfZSA6IHt9KTtcbiAgICAgICAgICAgICAgICAgICAgaWYgKHRoaXMuaW5wdXRMb29rdXApIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuaW5wdXRMb29rdXBMZW5ndGggPSBPYmplY3Qua2V5cyh0aGlzLmlucHV0TG9va3VwKS5sZW5ndGg7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgY29uc3QgdHlwZWRPdXRwdXQgPSB0eXBlZFZhbHVlLm91dHB1dDtcbiAgICAgICAgICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IHR5cGVkT3V0cHV0Lmxlbmd0aDsgaSsrKSB7XG4gICAgICAgICAgICAgICAgICAgIHRoaXMub3V0cHV0TG9va3VwID0gbG9va3VwLmFkZEtleXModHlwZWRPdXRwdXRbaV0sIChfZiA9IHRoaXMub3V0cHV0TG9va3VwKSAhPT0gbnVsbCAmJiBfZiAhPT0gdm9pZCAwID8gX2YgOiB7fSk7XG4gICAgICAgICAgICAgICAgICAgIGlmICh0aGlzLm91dHB1dExvb2t1cCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5vdXRwdXRMb29rdXBMZW5ndGggPSBPYmplY3Qua2V5cyh0aGlzLm91dHB1dExvb2t1cCkubGVuZ3RoO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZGVmYXVsdDpcbiAgICAgICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ3Vua25vd24gZGF0YSBzaGFwZSBvciBjb25maWd1cmF0aW9uJyk7XG4gICAgICAgIH1cbiAgICB9XG4gICAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIEB0eXBlc2NyaXB0LWVzbGludC9iYW4tdHMtY29tbWVudFxuICAgIC8vIEB0cy1leHBlY3QtZXJyb3JcbiAgICB0b0pTT04oKSB7XG4gICAgICAgIGlmICghdGhpcy5tb2RlbCkge1xuICAgICAgICAgICAgdGhpcy5pbml0aWFsaXplKCk7XG4gICAgICAgIH1cbiAgICAgICAgY29uc3QgeyBtb2RlbCB9ID0gdGhpcztcbiAgICAgICAgY29uc3Qgb3B0aW9ucyA9IHsgLi4udGhpcy5vcHRpb25zLCAuLi5kZWZhdWx0cyQxIH07XG4gICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICB0eXBlOiB0aGlzLmNvbnN0cnVjdG9yLm5hbWUsXG4gICAgICAgICAgICBvcHRpb25zLFxuICAgICAgICAgICAgaGlkZGVuTGF5ZXJzOiBtb2RlbC5oaWRkZW5MYXllcnMubWFwKChoaWRkZW5MYXllcikgPT4ge1xuICAgICAgICAgICAgICAgIGNvbnN0IGxheWVycyA9IHt9O1xuICAgICAgICAgICAgICAgIGZvciAoY29uc3QgcCBpbiBoaWRkZW5MYXllcikge1xuICAgICAgICAgICAgICAgICAgICBpZiAoIWhpZGRlbkxheWVyLmhhc093blByb3BlcnR5KHApKVxuICAgICAgICAgICAgICAgICAgICAgICAgY29udGludWU7XG4gICAgICAgICAgICAgICAgICAgIGxheWVyc1twXSA9IGhpZGRlbkxheWVyW3BdLnRvSlNPTigpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICByZXR1cm4gbGF5ZXJzO1xuICAgICAgICAgICAgfSksXG4gICAgICAgICAgICBvdXRwdXRDb25uZWN0b3I6IG1vZGVsLm91dHB1dENvbm5lY3Rvci50b0pTT04oKSxcbiAgICAgICAgICAgIG91dHB1dDogbW9kZWwub3V0cHV0LnRvSlNPTigpLFxuICAgICAgICAgICAgaW5wdXRMb29rdXA6IHRoaXMuaW5wdXRMb29rdXAsXG4gICAgICAgICAgICBpbnB1dExvb2t1cExlbmd0aDogdGhpcy5pbnB1dExvb2t1cExlbmd0aCxcbiAgICAgICAgICAgIG91dHB1dExvb2t1cDogdGhpcy5vdXRwdXRMb29rdXAsXG4gICAgICAgICAgICBvdXRwdXRMb29rdXBMZW5ndGg6IHRoaXMub3V0cHV0TG9va3VwTGVuZ3RoLFxuICAgICAgICB9O1xuICAgIH1cbiAgICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgQHR5cGVzY3JpcHQtZXNsaW50L2Jhbi10cy1jb21tZW50XG4gICAgLy8gQHRzLWV4cGVjdC1lcnJvclxuICAgIGZyb21KU09OKGpzb24pIHtcbiAgICAgICAgY29uc3QgeyBvcHRpb25zIH0gPSBqc29uO1xuICAgICAgICBjb25zdCBhbGxNYXRyaWNlcyA9IFtdO1xuICAgICAgICBjb25zdCBoaWRkZW5MYXllcnMgPSBbXTtcbiAgICAgICAgLy8gYmFja3dhcmQgY29tcGF0aWJpbGl0eSBmb3IgaGlkZGVuU2l6ZXNcbiAgICAgICAganNvbi5oaWRkZW5MYXllcnMuZm9yRWFjaCgoaGlkZGVuTGF5ZXIpID0+IHtcbiAgICAgICAgICAgIGNvbnN0IGxheWVycyA9IHt9O1xuICAgICAgICAgICAgZm9yIChjb25zdCBwIGluIGhpZGRlbkxheWVyKSB7XG4gICAgICAgICAgICAgICAgbGF5ZXJzW3BdID0gTWF0cml4LmZyb21KU09OKGhpZGRlbkxheWVyW3BdKTtcbiAgICAgICAgICAgICAgICBhbGxNYXRyaWNlcy5wdXNoKGxheWVyc1twXSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBoaWRkZW5MYXllcnMucHVzaChsYXllcnMpO1xuICAgICAgICB9KTtcbiAgICAgICAgY29uc3Qgb3V0cHV0Q29ubmVjdG9yID0gTWF0cml4LmZyb21KU09OKGpzb24ub3V0cHV0Q29ubmVjdG9yKTtcbiAgICAgICAgYWxsTWF0cmljZXMucHVzaChvdXRwdXRDb25uZWN0b3IpO1xuICAgICAgICBjb25zdCBvdXRwdXQgPSBNYXRyaXguZnJvbUpTT04oanNvbi5vdXRwdXQpO1xuICAgICAgICBhbGxNYXRyaWNlcy5wdXNoKG91dHB1dCk7XG4gICAgICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBAdHlwZXNjcmlwdC1lc2xpbnQvYmFuLXRzLWNvbW1lbnRcbiAgICAgICAgLy8gQHRzLWV4cGVjdC1lcnJvclxuICAgICAgICB0aGlzLm9wdGlvbnMgPSB7IC4uLmRlZmF1bHRzKCksIC4uLm9wdGlvbnMgfTtcbiAgICAgICAgdGhpcy5pbnB1dExvb2t1cCA9IGpzb24uaW5wdXRMb29rdXA7XG4gICAgICAgIHRoaXMuaW5wdXRMb29rdXBMZW5ndGggPSBqc29uLmlucHV0TG9va3VwTGVuZ3RoO1xuICAgICAgICB0aGlzLm91dHB1dExvb2t1cCA9IGpzb24ub3V0cHV0TG9va3VwO1xuICAgICAgICB0aGlzLm91dHB1dExvb2t1cExlbmd0aCA9IGpzb24ub3V0cHV0TG9va3VwTGVuZ3RoO1xuICAgICAgICB0aGlzLm1vZGVsID0gT2JqZWN0LnNlYWwoe1xuICAgICAgICAgICAgaXNJbml0aWFsaXplZDogdHJ1ZSxcbiAgICAgICAgICAgIGhpZGRlbkxheWVycyxcbiAgICAgICAgICAgIG91dHB1dCxcbiAgICAgICAgICAgIGFsbE1hdHJpY2VzLFxuICAgICAgICAgICAgb3V0cHV0Q29ubmVjdG9yLFxuICAgICAgICAgICAgZXF1YXRpb25zOiBbXSxcbiAgICAgICAgICAgIGVxdWF0aW9uQ29ubmVjdGlvbnM6IFtdLFxuICAgICAgICB9KTtcbiAgICAgICAgdGhpcy5pbml0aWFsTGF5ZXJJbnB1dHMgPSBvcHRpb25zLmhpZGRlbkxheWVycy5tYXAoKHNpemUpID0+IG5ldyBNYXRyaXgoc2l6ZSwgMSkpO1xuICAgICAgICB0aGlzLmJpbmRFcXVhdGlvbigpO1xuICAgICAgICByZXR1cm4gdGhpcztcbiAgICB9XG4gICAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIEB0eXBlc2NyaXB0LWVzbGludC9iYW4tdHMtY29tbWVudFxuICAgIC8vIEB0cy1leHBlY3QtZXJyb3JcbiAgICB0b0Z1bmN0aW9uKGNiKSB7XG4gICAgICAgIGNvbnN0IHsgbW9kZWwsIGlucHV0TG9va3VwLCBpbnB1dExvb2t1cExlbmd0aCwgb3V0cHV0TG9va3VwLCBvdXRwdXRMb29rdXBMZW5ndGgsIH0gPSB0aGlzO1xuICAgICAgICBjb25zdCB7IGlucHV0U2l6ZSB9ID0gdGhpcy5vcHRpb25zO1xuICAgICAgICBjb25zdCB7IGVxdWF0aW9ucyB9ID0gbW9kZWw7XG4gICAgICAgIGNvbnN0IGVxdWF0aW9uID0gZXF1YXRpb25zWzFdO1xuICAgICAgICBjb25zdCB7IHN0YXRlcyB9ID0gZXF1YXRpb247XG4gICAgICAgIGNvbnN0IGpzb25TdHJpbmcgPSBKU09OLnN0cmluZ2lmeSh0aGlzLnRvSlNPTigpKTtcbiAgICAgICAgZnVuY3Rpb24gcHJldmlvdXNDb25uZWN0aW9uSW5kZXgobSkge1xuICAgICAgICAgICAgY29uc3QgY29ubmVjdGlvbiA9IG1vZGVsLmVxdWF0aW9uQ29ubmVjdGlvbnNbMF07XG4gICAgICAgICAgICBjb25zdCB7IHN0YXRlcyB9ID0gZXF1YXRpb25zWzBdO1xuICAgICAgICAgICAgZm9yIChsZXQgaSA9IDAsIG1heCA9IHN0YXRlcy5sZW5ndGg7IGkgPCBtYXg7IGkrKykge1xuICAgICAgICAgICAgICAgIGlmIChzdGF0ZXNbaV0ucHJvZHVjdCA9PT0gbSkge1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gaTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICByZXR1cm4gY29ubmVjdGlvbi5pbmRleE9mKG0pO1xuICAgICAgICB9XG4gICAgICAgIGZ1bmN0aW9uIG1hdHJpeE9yaWdpbihtLCBzdGF0ZUluZGV4KSB7XG4gICAgICAgICAgICBmb3IgKGxldCBpID0gMCwgbWF4ID0gc3RhdGVzLmxlbmd0aDsgaSA8IG1heDsgaSsrKSB7XG4gICAgICAgICAgICAgICAgY29uc3Qgc3RhdGUgPSBzdGF0ZXNbaV07XG4gICAgICAgICAgICAgICAgaWYgKGkgPT09IHN0YXRlSW5kZXgpIHtcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgaiA9IHByZXZpb3VzQ29ubmVjdGlvbkluZGV4KG0pO1xuICAgICAgICAgICAgICAgICAgICBzd2l0Y2ggKG0pIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNhc2Ugc3RhdGUubGVmdDpcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoaiA+IC0xKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBgdHlwZW9mIHByZXZTdGF0ZXNbJHtqfV0gPT09ICdvYmplY3QnID8gcHJldlN0YXRlc1ske2p9XS5wcm9kdWN0IDogbmV3IE1hdHJpeCgke20ucm93c30sICR7bS5jb2x1bW5zfSlgO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBuby1mYWxsdGhyb3VnaFxuICAgICAgICAgICAgICAgICAgICAgICAgY2FzZSBzdGF0ZS5yaWdodDpcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoaiA+IC0xKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBgdHlwZW9mIHByZXZTdGF0ZXNbJHtqfV0gPT09ICdvYmplY3QnID8gcHJldlN0YXRlc1ske2p9XS5wcm9kdWN0IDogbmV3IE1hdHJpeCgke20ucm93c30sICR7bS5jb2x1bW5zfSlgO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBuby1mYWxsdGhyb3VnaFxuICAgICAgICAgICAgICAgICAgICAgICAgY2FzZSBzdGF0ZS5wcm9kdWN0OlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBgbmV3IE1hdHJpeCgke20ucm93c30sICR7bS5jb2x1bW5zfSlgO1xuICAgICAgICAgICAgICAgICAgICAgICAgZGVmYXVsdDpcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aHJvdyBFcnJvcigndW5rbm93biBzdGF0ZScpO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGlmIChtID09PSBzdGF0ZS5wcm9kdWN0KVxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gYHN0YXRlc1ske2l9XS5wcm9kdWN0YDtcbiAgICAgICAgICAgICAgICBpZiAobSA9PT0gc3RhdGUucmlnaHQpXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBgc3RhdGVzWyR7aX1dLnJpZ2h0YDtcbiAgICAgICAgICAgICAgICBpZiAobSA9PT0gc3RhdGUubGVmdClcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGBzdGF0ZXNbJHtpfV0ubGVmdGA7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICByZXR1cm4gJyc7XG4gICAgICAgIH1cbiAgICAgICAgZnVuY3Rpb24gbWF0cml4VG9TdHJpbmcobSwgc3RhdGVJbmRleCkge1xuICAgICAgICAgICAgaWYgKCFtIHx8ICFtLnJvd3MgfHwgIW0uY29sdW1ucylcbiAgICAgICAgICAgICAgICByZXR1cm4gJ251bGwnO1xuICAgICAgICAgICAgaWYgKG0gPT09IG1vZGVsLm91dHB1dENvbm5lY3RvcilcbiAgICAgICAgICAgICAgICByZXR1cm4gYGpzb24ub3V0cHV0Q29ubmVjdG9yYDtcbiAgICAgICAgICAgIGlmIChtID09PSBtb2RlbC5vdXRwdXQpXG4gICAgICAgICAgICAgICAgcmV0dXJuIGBqc29uLm91dHB1dGA7XG4gICAgICAgICAgICBmb3IgKGxldCBpID0gMCwgbWF4ID0gbW9kZWwuaGlkZGVuTGF5ZXJzLmxlbmd0aDsgaSA8IG1heDsgaSsrKSB7XG4gICAgICAgICAgICAgICAgY29uc3QgaGlkZGVuTGF5ZXIgPSBtb2RlbC5oaWRkZW5MYXllcnNbaV07XG4gICAgICAgICAgICAgICAgZm9yIChjb25zdCBwIGluIGhpZGRlbkxheWVyKSB7XG4gICAgICAgICAgICAgICAgICAgIGlmICghaGlkZGVuTGF5ZXIuaGFzT3duUHJvcGVydHkocCkpXG4gICAgICAgICAgICAgICAgICAgICAgICBjb250aW51ZTtcbiAgICAgICAgICAgICAgICAgICAgaWYgKGhpZGRlbkxheWVyW3BdICE9PSBtKVxuICAgICAgICAgICAgICAgICAgICAgICAgY29udGludWU7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBganNvbi5oaWRkZW5MYXllcnNbJHtpfV0uJHtwfWA7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgcmV0dXJuIG1hdHJpeE9yaWdpbihtLCBzdGF0ZUluZGV4KTtcbiAgICAgICAgfVxuICAgICAgICBmdW5jdGlvbiBmb3JtYXRJbnB1dERhdGEoKSB7XG4gICAgICAgICAgICBpZiAoIWlucHV0TG9va3VwKVxuICAgICAgICAgICAgICAgIHJldHVybiAnJztcbiAgICAgICAgICAgIGlmIChpbnB1dFNpemUgPT09IDEpIHtcbiAgICAgICAgICAgICAgICBpZiAoaW5wdXRMb29rdXAgPT09IG91dHB1dExvb2t1cCkge1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gYGZ1bmN0aW9uIGxvb2t1cElucHV0KGlucHV0KSB7XG4gICAgICAgICAgICB2YXIgdGFibGUgPSAke0pTT04uc3RyaW5naWZ5KGlucHV0TG9va3VwKX07XG4gICAgICAgICAgICB2YXIgcmVzdWx0ID0gW107XG4gICAgICAgICAgICBmb3IgKHZhciBwIGluIHRhYmxlKSB7XG4gICAgICAgICAgICAgIGlmICghaW5wdXQuaGFzT3duUHJvcGVydHkocCkpIGJyZWFrO1xuICAgICAgICAgICAgICByZXN1bHQucHVzaChGbG9hdDMyQXJyYXkuZnJvbShbaW5wdXRbcF1dKSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICByZXR1cm4gcmVzdWx0O1xuICAgICAgICAgIH1gO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICByZXR1cm4gYGZ1bmN0aW9uIGxvb2t1cElucHV0KGlucHV0KSB7XG4gICAgICAgICAgdmFyIHRhYmxlID0gJHtKU09OLnN0cmluZ2lmeShpbnB1dExvb2t1cCl9O1xuICAgICAgICAgIHZhciByZXN1bHQgPSBbXTtcbiAgICAgICAgICBmb3IgKHZhciBwIGluIHRhYmxlKSB7XG4gICAgICAgICAgICByZXN1bHQucHVzaChGbG9hdDMyQXJyYXkuZnJvbShbaW5wdXRbcF1dKSk7XG4gICAgICAgICAgfVxuICAgICAgICAgIHJldHVybiByZXN1bHQ7XG4gICAgICAgIH1gO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgcmV0dXJuIGBmdW5jdGlvbiBsb29rdXBJbnB1dChyYXdJbnB1dHMpIHtcbiAgICAgICAgdmFyIHRhYmxlID0gJHtKU09OLnN0cmluZ2lmeShpbnB1dExvb2t1cCl9O1xuICAgICAgICB2YXIgcmVzdWx0ID0gW107XG4gICAgICAgIGZvciAodmFyIGkgPSAwOyBpIDwgcmF3SW5wdXRzLmxlbmd0aDsgaSsrKSB7XG4gICAgICAgICAgdmFyIHJhd0lucHV0ID0gcmF3SW5wdXRzW2ldO1xuICAgICAgICAgIHZhciBpbnB1dCA9IG5ldyBGbG9hdDMyQXJyYXkoJHtpbnB1dExvb2t1cExlbmd0aH0pO1xuICAgICAgICAgIGZvciAodmFyIHAgaW4gdGFibGUpIHtcbiAgICAgICAgICAgIGlucHV0W3RhYmxlW3BdXSA9IHJhd0lucHV0Lmhhc093blByb3BlcnR5KHApID8gcmF3SW5wdXRbcF0gOiAwO1xuICAgICAgICAgIH1cbiAgICAgICAgICByZXN1bHQucHVzaChpbnB1dCk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHJlc3VsdDtcbiAgICAgIH1gO1xuICAgICAgICB9XG4gICAgICAgIGZ1bmN0aW9uIGZvcm1hdE91dHB1dERhdGEoKSB7XG4gICAgICAgICAgICBpZiAoIW91dHB1dExvb2t1cClcbiAgICAgICAgICAgICAgICByZXR1cm4gJyc7XG4gICAgICAgICAgICBpZiAoaW5wdXRTaXplID09PSAxKSB7XG4gICAgICAgICAgICAgICAgaWYgKGlucHV0TG9va3VwID09PSBvdXRwdXRMb29rdXApIHtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGBmdW5jdGlvbiBsb29rdXBPdXRwdXRQYXJ0aWFsKG91dHB1dCwgaW5wdXQpIHtcbiAgICAgICAgICAgIHZhciB0YWJsZSA9ICR7SlNPTi5zdHJpbmdpZnkob3V0cHV0TG9va3VwKX07XG4gICAgICAgICAgICB2YXIgb2Zmc2V0ID0gaW5wdXQubGVuZ3RoO1xuICAgICAgICAgICAgdmFyIHJlc3VsdCA9IHt9O1xuICAgICAgICAgICAgdmFyIGkgPSAwO1xuICAgICAgICAgICAgZm9yICh2YXIgcCBpbiB0YWJsZSkge1xuICAgICAgICAgICAgICBpZiAoaSsrIDwgb2Zmc2V0KSBjb250aW51ZTtcbiAgICAgICAgICAgICAgcmVzdWx0W3BdID0gb3V0cHV0W3RhYmxlW3BdIC0gb2Zmc2V0XVswXTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHJldHVybiByZXN1bHQ7XG4gICAgICAgICAgfWA7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIHJldHVybiBgZnVuY3Rpb24gbG9va3VwT3V0cHV0KG91dHB1dCkge1xuICAgICAgICAgIHZhciB0YWJsZSA9ICR7SlNPTi5zdHJpbmdpZnkob3V0cHV0TG9va3VwKX07XG4gICAgICAgICAgdmFyIHJlc3VsdCA9IHt9O1xuICAgICAgICAgIGZvciAodmFyIHAgaW4gdGFibGUpIHtcbiAgICAgICAgICAgIHJlc3VsdFtwXSA9IG91dHB1dFt0YWJsZVtwXV1bMF07XG4gICAgICAgICAgfVxuICAgICAgICAgIHJldHVybiByZXN1bHQ7XG4gICAgICAgIH1gO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgcmV0dXJuIGBmdW5jdGlvbiBsb29rdXBPdXRwdXQob3V0cHV0KSB7XG4gICAgICAgIHZhciB0YWJsZSA9ICR7SlNPTi5zdHJpbmdpZnkob3V0cHV0TG9va3VwKX07XG4gICAgICAgIHZhciByZXN1bHQgPSB7fTtcbiAgICAgICAgZm9yICh2YXIgcCBpbiB0YWJsZSkge1xuICAgICAgICAgIHJlc3VsdFtwXSA9IG91dHB1dFt0YWJsZVtwXV07XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHJlc3VsdDtcbiAgICAgIH1gO1xuICAgICAgICB9XG4gICAgICAgIGZ1bmN0aW9uIHRvSW5uZXIoZm5TdHJpbmcpIHtcbiAgICAgICAgICAgIC8vIGNydWRlLCBidXQgc2hvdWxkIGJlIHN1ZmZpY2llbnQgZm9yIG5vd1xuICAgICAgICAgICAgLy8gZnVuY3Rpb24oKSB7IGJvZHkgfVxuICAgICAgICAgICAgLy8gY3J1ZGUsIGJ1dCBzaG91bGQgYmUgc3VmZmljaWVudCBmb3Igbm93XG4gICAgICAgICAgICAvLyBmdW5jdGlvbigpIHsgYm9keSB9XG4gICAgICAgICAgICBjb25zdCBmblBhcnRzID0gZm5TdHJpbmcudG9TdHJpbmcoKS5zcGxpdCgneycpO1xuICAgICAgICAgICAgZm5QYXJ0cy5zaGlmdCgpO1xuICAgICAgICAgICAgLy8gYm9keSB9XG4gICAgICAgICAgICBjb25zdCBmbkJvZHlTdHJpbmcgPSBmblBhcnRzLmpvaW4oJ3snKTtcbiAgICAgICAgICAgIGNvbnN0IGZuQm9keVBhcnRzID0gZm5Cb2R5U3RyaW5nLnNwbGl0KCd9Jyk7XG4gICAgICAgICAgICBmbkJvZHlQYXJ0cy5wb3AoKTtcbiAgICAgICAgICAgIC8vIGJvZHlcbiAgICAgICAgICAgIHJldHVybiBmbkJvZHlQYXJ0c1xuICAgICAgICAgICAgICAgIC5qb2luKCd9JylcbiAgICAgICAgICAgICAgICAuc3BsaXQoJ1xcbicpXG4gICAgICAgICAgICAgICAgLmpvaW4oJ1xcbiAgICAgICAgJylcbiAgICAgICAgICAgICAgICAucmVwbGFjZSgncHJvZHVjdC5kZWx0YXNbaV0gPSAwOycsICcnKVxuICAgICAgICAgICAgICAgIC5yZXBsYWNlKCdwcm9kdWN0LmRlbHRhc1tjb2x1bW5dID0gMDsnLCAnJylcbiAgICAgICAgICAgICAgICAucmVwbGFjZSgnbGVmdC5kZWx0YXNbbGVmdEluZGV4XSA9IDA7JywgJycpXG4gICAgICAgICAgICAgICAgLnJlcGxhY2UoJ3JpZ2h0LmRlbHRhc1tyaWdodEluZGV4XSA9IDA7JywgJycpXG4gICAgICAgICAgICAgICAgLnJlcGxhY2UoJ3Byb2R1Y3QuZGVsdGFzID0gbGVmdC5kZWx0YXMuc2xpY2UoMCk7JywgJycpO1xuICAgICAgICB9XG4gICAgICAgIGZ1bmN0aW9uIGZpbGVOYW1lKGZuTmFtZSkge1xuICAgICAgICAgICAgcmV0dXJuIGBzcmMvcmVjdXJyZW50L21hdHJpeC8ke2ZuTmFtZS5yZXBsYWNlKC9bQS1aXS9nLCBmdW5jdGlvbiAodmFsdWUpIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gYC0ke3ZhbHVlLnRvTG93ZXJDYXNlKCl9YDtcbiAgICAgICAgICAgIH0pfS5qc2A7XG4gICAgICAgIH1cbiAgICAgICAgY29uc3Qgc3RhdGVzUmF3ID0gW107XG4gICAgICAgIGNvbnN0IHVzZWRGdW5jdGlvbk5hbWVzID0ge307XG4gICAgICAgIGNvbnN0IGlubmVyRnVuY3Rpb25zU3dpdGNoID0gW107XG4gICAgICAgIGZvciAobGV0IGkgPSAwLCBtYXggPSBzdGF0ZXMubGVuZ3RoOyBpIDwgbWF4OyBpKyspIHtcbiAgICAgICAgICAgIGNvbnN0IHN0YXRlID0gc3RhdGVzW2ldO1xuICAgICAgICAgICAgc3RhdGVzUmF3LnB1c2goYHN0YXRlc1ske2l9XSA9IHtcbiAgICAgIG5hbWU6ICcke3N0YXRlLmZvcndhcmRGbi5uYW1lfScsXG4gICAgICBsZWZ0OiAke3N0YXRlLmxlZnQgPyBtYXRyaXhUb1N0cmluZyhzdGF0ZS5sZWZ0LCBpKSA6ICd1bmRlZmluZWQnfSxcbiAgICAgIHJpZ2h0OiAke3N0YXRlLnJpZ2h0ID8gbWF0cml4VG9TdHJpbmcoc3RhdGUucmlnaHQsIGkpIDogJ3VuZGVmaW5lZCd9LFxuICAgICAgcHJvZHVjdDogJHttYXRyaXhUb1N0cmluZyhzdGF0ZS5wcm9kdWN0LCBpKX1cbiAgICB9YCk7XG4gICAgICAgICAgICBjb25zdCBmbk5hbWUgPSBzdGF0ZS5mb3J3YXJkRm4ubmFtZTtcbiAgICAgICAgICAgIGlmICghdXNlZEZ1bmN0aW9uTmFtZXNbZm5OYW1lXSkge1xuICAgICAgICAgICAgICAgIHVzZWRGdW5jdGlvbk5hbWVzW2ZuTmFtZV0gPSB0cnVlO1xuICAgICAgICAgICAgICAgIGlmIChzdGF0ZS5uYW1lID09PSAnaW5wdXQnKSB7XG4gICAgICAgICAgICAgICAgICAgIGlubmVyRnVuY3Rpb25zU3dpdGNoLnB1c2goYGNhc2UgJyR7Zm5OYW1lfSc6YCk7XG4gICAgICAgICAgICAgICAgICAgIGlubmVyRnVuY3Rpb25zU3dpdGNoLnB1c2goaW5wdXRMb29rdXAgJiYgaW5wdXRTaXplID09PSAxXG4gICAgICAgICAgICAgICAgICAgICAgICA/ICdwcm9kdWN0LndlaWdodHMgPSBfaSA8IGlucHV0Lmxlbmd0aCA/IGlucHV0W19pXTogcHJldlN0YXRlc1twcmV2U3RhdGVzLmxlbmd0aCAtIDFdLnByb2R1Y3Qud2VpZ2h0czsnXG4gICAgICAgICAgICAgICAgICAgICAgICA6IGlucHV0U2l6ZSA9PT0gMVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gJ3Byb2R1Y3Qud2VpZ2h0cyA9IFtpbnB1dFtfaV1dOydcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA6ICdwcm9kdWN0LndlaWdodHMgPSBpbnB1dFtfaV07Jyk7XG4gICAgICAgICAgICAgICAgICAgIGlubmVyRnVuY3Rpb25zU3dpdGNoLnB1c2goJ2JyZWFrOycpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgaW5uZXJGdW5jdGlvbnNTd2l0Y2gucHVzaChgICAgICAgICBjYXNlICcke2ZuTmFtZX0nOiR7Zm5OYW1lICE9PSAnZm9yd2FyZEZuJ1xuICAgICAgICAgICAgICAgICAgICAgICAgPyBgIC8vY29tcGlsZWQgZnJvbSAke2ZpbGVOYW1lKGZuTmFtZSl9YFxuICAgICAgICAgICAgICAgICAgICAgICAgOiAnJ31cbiAgICAgICAgICAke3RvSW5uZXIoc3RhdGUuZm9yd2FyZEZuLnRvU3RyaW5nKCkpfVxuICAgICAgICAgIGJyZWFrO2ApO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBjb25zdCBmb3JjZUZvcmVjYXN0ID0gaW5wdXRTaXplID09PSAxICYmIHRoaXMub3V0cHV0TG9va3VwO1xuICAgICAgICBjb25zdCBzcmMgPSBgXG4gIHZhciBpbnB1dCA9ICR7dGhpcy5pbnB1dExvb2t1cCA/ICdsb29rdXBJbnB1dChyYXdJbnB1dCknIDogJ3Jhd0lucHV0J307XG4gIHZhciBqc29uID0gJHtqc29uU3RyaW5nfTtcbiAgdmFyIG91dHB1dCA9IFtdO1xuICB2YXIgc3RhdGVzID0gW107XG4gIHZhciBwcmV2U3RhdGVzO1xuICB2YXIgc3RhdGU7XG4gIHZhciBtYXggPSAke2ZvcmNlRm9yZWNhc3RcbiAgICAgICAgICAgID8gaW5wdXRMb29rdXAgPT09IG91dHB1dExvb2t1cFxuICAgICAgICAgICAgICAgID8gaW5wdXRMb29rdXBMZW5ndGhcbiAgICAgICAgICAgICAgICA6IGBpbnB1dC5sZW5ndGggKyAke291dHB1dExvb2t1cExlbmd0aCAtIDF9YFxuICAgICAgICAgICAgOiAnaW5wdXQubGVuZ3RoJ307XG4gIGZvciAodmFyIF9pID0gMDsgX2kgPCBtYXg7IF9pKyspIHtcbiAgICBwcmV2U3RhdGVzID0gc3RhdGVzO1xuICAgIHN0YXRlcyA9IFtdO1xuICAgICR7c3RhdGVzUmF3LmpvaW4oJztcXG4gICAgJyl9O1xuICAgIGZvciAodmFyIHN0YXRlSW5kZXggPSAwLCBzdGF0ZU1heCA9ICR7c3RhdGVzUmF3Lmxlbmd0aH07IHN0YXRlSW5kZXggPCBzdGF0ZU1heDsgc3RhdGVJbmRleCsrKSB7XG4gICAgICBzdGF0ZSA9IHN0YXRlc1tzdGF0ZUluZGV4XTtcbiAgICAgIHZhciBwcm9kdWN0ID0gc3RhdGUucHJvZHVjdDtcbiAgICAgIHZhciBsZWZ0ID0gc3RhdGUubGVmdDtcbiAgICAgIHZhciByaWdodCA9IHN0YXRlLnJpZ2h0O1xuXG4gICAgICBzd2l0Y2ggKHN0YXRlLm5hbWUpIHtcbiR7aW5uZXJGdW5jdGlvbnNTd2l0Y2guam9pbignXFxuJyl9XG4gICAgICB9XG4gICAgfVxuICAgICR7aW5wdXRTaXplID09PSAxICYmIGlucHV0TG9va3VwXG4gICAgICAgICAgICA/ICdpZiAoX2kgPj0gaW5wdXQubGVuZ3RoIC0gMSkgeyBvdXRwdXQucHVzaChzdGF0ZS5wcm9kdWN0LndlaWdodHMpOyB9J1xuICAgICAgICAgICAgOiAnb3V0cHV0ID0gc3RhdGUucHJvZHVjdC53ZWlnaHRzOyd9XG4gIH1cbiAgJHtvdXRwdXRMb29rdXBcbiAgICAgICAgICAgID8gb3V0cHV0TG9va3VwID09PSBpbnB1dExvb2t1cFxuICAgICAgICAgICAgICAgID8gJ3JldHVybiBsb29rdXBPdXRwdXRQYXJ0aWFsKG91dHB1dCwgaW5wdXQpJ1xuICAgICAgICAgICAgICAgIDogJ3JldHVybiBsb29rdXBPdXRwdXQob3V0cHV0KSdcbiAgICAgICAgICAgIDogaW5wdXRTaXplID09PSAxXG4gICAgICAgICAgICAgICAgPyAncmV0dXJuIG91dHB1dFswXSdcbiAgICAgICAgICAgICAgICA6ICdyZXR1cm4gb3V0cHV0J307XG4gICR7Zm9ybWF0SW5wdXREYXRhKCl9XG4gICR7Zm9ybWF0T3V0cHV0RGF0YSgpfVxuXG4gIGZ1bmN0aW9uIE1hdHJpeChyb3dzLCBjb2x1bW5zKSB7XG4gICAgdGhpcy5yb3dzID0gcm93cztcbiAgICB0aGlzLmNvbHVtbnMgPSBjb2x1bW5zO1xuICAgIHRoaXMud2VpZ2h0cyA9IHplcm9zKHJvd3MgKiBjb2x1bW5zKTtcbiAgfVxuICAke3plcm9zJDEudG9TdHJpbmcoKX1cbiAgJHtzb2Z0bWF4LnRvU3RyaW5nKCkucmVwbGFjZSgnXzIuZGVmYXVsdCcsICdNYXRyaXgnKX1cbiAgJHtyYW5kb21GbG9hdC50b1N0cmluZygpfVxuICAke3NhbXBsZUkudG9TdHJpbmcoKX1cbiAgJHttYXhJLnRvU3RyaW5nKCl9YDtcbiAgICAgICAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lXG4gICAgICAgIHJldHVybiBuZXcgRnVuY3Rpb24oJ3Jhd0lucHV0JywgY2IgPyBjYihzcmMpIDogc3JjKTtcbiAgICB9XG59XG5jb25zdCB0cmFpbkRlZmF1bHRzID0geyAuLi50cmFpbkRlZmF1bHRzJDEgfTtcblxuY2xhc3MgR1JVVGltZVN0ZXAgZXh0ZW5kcyBSTk5UaW1lU3RlcCB7XG4gICAgZ2V0SGlkZGVuTGF5ZXIoaGlkZGVuU2l6ZSwgcHJldlNpemUpIHtcbiAgICAgICAgcmV0dXJuIGdldEdSVUhpZGRlbkxheWVyKGhpZGRlblNpemUsIHByZXZTaXplKTtcbiAgICB9XG4gICAgZ2V0RXF1YXRpb24oZXF1YXRpb24sIGlucHV0TWF0cml4LCBwcmV2aW91c1Jlc3VsdCwgaGlkZGVuTGF5ZXIpIHtcbiAgICAgICAgcmV0dXJuIGdldEdSVUVxdWF0aW9uKGVxdWF0aW9uLCBpbnB1dE1hdHJpeCwgcHJldmlvdXNSZXN1bHQsIGhpZGRlbkxheWVyKTtcbiAgICB9XG59XG5cbmNsYXNzIExTVE0gZXh0ZW5kcyBSTk4ge1xuICAgIGdldEhpZGRlbkxheWVyKGhpZGRlblNpemUsIHByZXZTaXplKSB7XG4gICAgICAgIHJldHVybiBnZXRIaWRkZW5MU1RNTGF5ZXIoaGlkZGVuU2l6ZSwgcHJldlNpemUpO1xuICAgIH1cbiAgICBnZXRFcXVhdGlvbihlcXVhdGlvbiwgaW5wdXRNYXRyaXgsIHByZXZpb3VzUmVzdWx0LCBoaWRkZW5MYXllcikge1xuICAgICAgICByZXR1cm4gZ2V0TFNUTUVxdWF0aW9uKGVxdWF0aW9uLCBpbnB1dE1hdHJpeCwgcHJldmlvdXNSZXN1bHQsIGhpZGRlbkxheWVyKTtcbiAgICB9XG59XG5mdW5jdGlvbiBnZXRIaWRkZW5MU1RNTGF5ZXIoaGlkZGVuU2l6ZSwgcHJldlNpemUpIHtcbiAgICByZXR1cm4ge1xuICAgICAgICAvLyBnYXRlcyBwYXJhbWV0ZXJzXG4gICAgICAgIC8vIHdpeFxuICAgICAgICBpbnB1dE1hdHJpeDogbmV3IFJhbmRvbU1hdHJpeChoaWRkZW5TaXplLCBwcmV2U2l6ZSwgMC4wOCksXG4gICAgICAgIGlucHV0SGlkZGVuOiBuZXcgUmFuZG9tTWF0cml4KGhpZGRlblNpemUsIGhpZGRlblNpemUsIDAuMDgpLFxuICAgICAgICBpbnB1dEJpYXM6IG5ldyBNYXRyaXgoaGlkZGVuU2l6ZSwgMSksXG4gICAgICAgIC8vIHdmeFxuICAgICAgICBmb3JnZXRNYXRyaXg6IG5ldyBSYW5kb21NYXRyaXgoaGlkZGVuU2l6ZSwgcHJldlNpemUsIDAuMDgpLFxuICAgICAgICBmb3JnZXRIaWRkZW46IG5ldyBSYW5kb21NYXRyaXgoaGlkZGVuU2l6ZSwgaGlkZGVuU2l6ZSwgMC4wOCksXG4gICAgICAgIGZvcmdldEJpYXM6IG5ldyBNYXRyaXgoaGlkZGVuU2l6ZSwgMSksXG4gICAgICAgIC8vIHdveFxuICAgICAgICBvdXRwdXRNYXRyaXg6IG5ldyBSYW5kb21NYXRyaXgoaGlkZGVuU2l6ZSwgcHJldlNpemUsIDAuMDgpLFxuICAgICAgICBvdXRwdXRIaWRkZW46IG5ldyBSYW5kb21NYXRyaXgoaGlkZGVuU2l6ZSwgaGlkZGVuU2l6ZSwgMC4wOCksXG4gICAgICAgIG91dHB1dEJpYXM6IG5ldyBNYXRyaXgoaGlkZGVuU2l6ZSwgMSksXG4gICAgICAgIC8vIGNlbGwgd3JpdGUgcGFyYW1zXG4gICAgICAgIC8vIHdjeFxuICAgICAgICBjZWxsQWN0aXZhdGlvbk1hdHJpeDogbmV3IFJhbmRvbU1hdHJpeChoaWRkZW5TaXplLCBwcmV2U2l6ZSwgMC4wOCksXG4gICAgICAgIGNlbGxBY3RpdmF0aW9uSGlkZGVuOiBuZXcgUmFuZG9tTWF0cml4KGhpZGRlblNpemUsIGhpZGRlblNpemUsIDAuMDgpLFxuICAgICAgICBjZWxsQWN0aXZhdGlvbkJpYXM6IG5ldyBNYXRyaXgoaGlkZGVuU2l6ZSwgMSksXG4gICAgfTtcbn1cbmZ1bmN0aW9uIGdldExTVE1FcXVhdGlvbihlcXVhdGlvbiwgaW5wdXRNYXRyaXgsIHByZXZpb3VzUmVzdWx0LCBoaWRkZW5MYXllcikge1xuICAgIGlmICghaGlkZGVuTGF5ZXIuaW5wdXRNYXRyaXggfHxcbiAgICAgICAgIWhpZGRlbkxheWVyLmlucHV0SGlkZGVuIHx8XG4gICAgICAgICFoaWRkZW5MYXllci5pbnB1dEJpYXMgfHxcbiAgICAgICAgIWhpZGRlbkxheWVyLmZvcmdldE1hdHJpeCB8fFxuICAgICAgICAhaGlkZGVuTGF5ZXIuZm9yZ2V0SGlkZGVuIHx8XG4gICAgICAgICFoaWRkZW5MYXllci5mb3JnZXRCaWFzIHx8XG4gICAgICAgICFoaWRkZW5MYXllci5vdXRwdXRNYXRyaXggfHxcbiAgICAgICAgIWhpZGRlbkxheWVyLm91dHB1dEhpZGRlbiB8fFxuICAgICAgICAhaGlkZGVuTGF5ZXIub3V0cHV0QmlhcyB8fFxuICAgICAgICAhaGlkZGVuTGF5ZXIuY2VsbEFjdGl2YXRpb25NYXRyaXggfHxcbiAgICAgICAgIWhpZGRlbkxheWVyLmNlbGxBY3RpdmF0aW9uSGlkZGVuIHx8XG4gICAgICAgICFoaWRkZW5MYXllci5jZWxsQWN0aXZhdGlvbkJpYXMpIHtcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdoaWRkZW5MYXllciBkb2VzIG5vdCBoYXZlIGV4cGVjdGVkIHByb3BlcnRpZXMnKTtcbiAgICB9XG4gICAgY29uc3Qgc2lnbW9pZCA9IGVxdWF0aW9uLnNpZ21vaWQuYmluZChlcXVhdGlvbik7XG4gICAgY29uc3QgYWRkID0gZXF1YXRpb24uYWRkLmJpbmQoZXF1YXRpb24pO1xuICAgIGNvbnN0IG11bHRpcGx5ID0gZXF1YXRpb24ubXVsdGlwbHkuYmluZChlcXVhdGlvbik7XG4gICAgY29uc3QgbXVsdGlwbHlFbGVtZW50ID0gZXF1YXRpb24ubXVsdGlwbHlFbGVtZW50LmJpbmQoZXF1YXRpb24pO1xuICAgIGNvbnN0IHRhbmggPSBlcXVhdGlvbi50YW5oLmJpbmQoZXF1YXRpb24pO1xuICAgIGNvbnN0IGlucHV0R2F0ZSA9IHNpZ21vaWQoYWRkKGFkZChtdWx0aXBseShoaWRkZW5MYXllci5pbnB1dE1hdHJpeCwgaW5wdXRNYXRyaXgpLCBtdWx0aXBseShoaWRkZW5MYXllci5pbnB1dEhpZGRlbiwgcHJldmlvdXNSZXN1bHQpKSwgaGlkZGVuTGF5ZXIuaW5wdXRCaWFzKSk7XG4gICAgY29uc3QgZm9yZ2V0R2F0ZSA9IHNpZ21vaWQoYWRkKGFkZChtdWx0aXBseShoaWRkZW5MYXllci5mb3JnZXRNYXRyaXgsIGlucHV0TWF0cml4KSwgbXVsdGlwbHkoaGlkZGVuTGF5ZXIuZm9yZ2V0SGlkZGVuLCBwcmV2aW91c1Jlc3VsdCkpLCBoaWRkZW5MYXllci5mb3JnZXRCaWFzKSk7XG4gICAgLy8gb3V0cHV0IGdhdGVcbiAgICBjb25zdCBvdXRwdXRHYXRlID0gc2lnbW9pZChhZGQoYWRkKG11bHRpcGx5KGhpZGRlbkxheWVyLm91dHB1dE1hdHJpeCwgaW5wdXRNYXRyaXgpLCBtdWx0aXBseShoaWRkZW5MYXllci5vdXRwdXRIaWRkZW4sIHByZXZpb3VzUmVzdWx0KSksIGhpZGRlbkxheWVyLm91dHB1dEJpYXMpKTtcbiAgICAvLyB3cml0ZSBvcGVyYXRpb24gb24gY2VsbHNcbiAgICBjb25zdCBjZWxsV3JpdGUgPSB0YW5oKGFkZChhZGQobXVsdGlwbHkoaGlkZGVuTGF5ZXIuY2VsbEFjdGl2YXRpb25NYXRyaXgsIGlucHV0TWF0cml4KSwgbXVsdGlwbHkoaGlkZGVuTGF5ZXIuY2VsbEFjdGl2YXRpb25IaWRkZW4sIHByZXZpb3VzUmVzdWx0KSksIGhpZGRlbkxheWVyLmNlbGxBY3RpdmF0aW9uQmlhcykpO1xuICAgIC8vIGNvbXB1dGUgbmV3IGNlbGwgYWN0aXZhdGlvblxuICAgIGNvbnN0IHJldGFpbkNlbGwgPSBtdWx0aXBseUVsZW1lbnQoZm9yZ2V0R2F0ZSwgcHJldmlvdXNSZXN1bHQpOyAvLyB3aGF0IGRvIHdlIGtlZXAgZnJvbSBjZWxsXG4gICAgY29uc3Qgd3JpdGVDZWxsID0gbXVsdGlwbHlFbGVtZW50KGlucHV0R2F0ZSwgY2VsbFdyaXRlKTsgLy8gd2hhdCBkbyB3ZSB3cml0ZSB0byBjZWxsXG4gICAgY29uc3QgY2VsbCA9IGFkZChyZXRhaW5DZWxsLCB3cml0ZUNlbGwpOyAvLyBuZXcgY2VsbCBjb250ZW50c1xuICAgIC8vIGNvbXB1dGUgaGlkZGVuIHN0YXRlIGFzIGdhdGVkLCBzYXR1cmF0ZWQgY2VsbCBhY3RpdmF0aW9uc1xuICAgIHJldHVybiBtdWx0aXBseUVsZW1lbnQob3V0cHV0R2F0ZSwgdGFuaChjZWxsKSk7XG59XG5cbmNsYXNzIExTVE1UaW1lU3RlcCBleHRlbmRzIFJOTlRpbWVTdGVwIHtcbiAgICBnZXRIaWRkZW5MYXllcihoaWRkZW5TaXplLCBwcmV2U2l6ZSkge1xuICAgICAgICByZXR1cm4gZ2V0SGlkZGVuTFNUTUxheWVyKGhpZGRlblNpemUsIHByZXZTaXplKTtcbiAgICB9XG4gICAgZ2V0RXF1YXRpb24oZXF1YXRpb24sIGlucHV0TWF0cml4LCBwcmV2aW91c1Jlc3VsdCwgaGlkZGVuTGF5ZXIpIHtcbiAgICAgICAgcmV0dXJuIGdldExTVE1FcXVhdGlvbihlcXVhdGlvbiwgaW5wdXRNYXRyaXgsIHByZXZpb3VzUmVzdWx0LCBoaWRkZW5MYXllcik7XG4gICAgfVxufVxuXG4vKipcbiAqXG4gKiBAcGFyYW0gc3RhcnRcbiAqIEBwYXJhbSBlbmRcbiAqIEByZXR1cm5zIHtBcnJheX1cbiAqL1xuZnVuY3Rpb24gcmFuZ2Uoc3RhcnQsIGVuZCkge1xuICAgIGNvbnN0IHJlc3VsdCA9IFtdO1xuICAgIGZvciAoOyBzdGFydCA8IGVuZDsgc3RhcnQrKykge1xuICAgICAgICByZXN1bHQucHVzaChzdGFydCk7XG4gICAgfVxuICAgIHJldHVybiByZXN1bHQ7XG59XG5cbmZ1bmN0aW9uIHRvQXJyYXkodmFsdWVzKSB7XG4gICAgaWYgKEFycmF5LmlzQXJyYXkodmFsdWVzKSkge1xuICAgICAgICByZXR1cm4gRmxvYXQzMkFycmF5LmZyb20odmFsdWVzKTtcbiAgICB9XG4gICAgcmV0dXJuIEZsb2F0MzJBcnJheS5mcm9tKE9iamVjdC52YWx1ZXModmFsdWVzKSk7XG59XG5cbmZ1bmN0aW9uIGRyYXdJbnB1dCh7IHBpeGVsWCwgcGl4ZWxZLCByYWRpdXMsIGlucHV0cywgcm93LCBsaW5lLCBmb250U2l6ZSwgZm9udENsYXNzTmFtZSwgfSkge1xuICAgIGxldCBzdmcgPSBgPHJlY3RcbiAgICAgICAgICAgICAgeD1cIiR7cGl4ZWxYIC8gMiAtIHJhZGl1c31cIlxuICAgICAgICAgICAgICB5PVwiJHtwaXhlbFkgLyAyICsgcm93ICogcGl4ZWxZIC0gcmFkaXVzfVwiXG4gICAgICAgICAgICAgIHdpZHRoPVwiJHsyICogcmFkaXVzfVwiXG4gICAgICAgICAgICAgIGhlaWdodD1cIiR7MiAqIHJhZGl1c31cIlxuICAgICAgICAgICAgICBzdHJva2U9XCJibGFja1wiXG4gICAgICAgICAgICAgIHN0cm9rZS13aWR0aD1cIjFcIlxuICAgICAgICAgICAgICBmaWxsPVwiJHtpbnB1dHMuY29sb3J9XCJcbiAgICAgICAgICAgICAgY2xhc3M9XCIke2lucHV0cy5jbGFzc05hbWV9XCIgLz5cbiAgICAgICAgICAgIDxsaW5lXG4gICAgICAgICAgICAgIHgxPVwiJHtwaXhlbFggLyA0fVwiXG4gICAgICAgICAgICAgIHkxPVwiJHtwaXhlbFkgLyAyICsgcm93ICogcGl4ZWxZfVwiXG4gICAgICAgICAgICAgIHgyPVwiJHtwaXhlbFggLyAyIC0gcmFkaXVzfVwiXG4gICAgICAgICAgICAgIHkyPVwiJHtwaXhlbFkgLyAyICsgcm93ICogcGl4ZWxZfVwiXG4gICAgICAgICAgICAgIHN0eWxlPVwic3Ryb2tlOiR7bGluZS5jb2xvcn07c3Ryb2tlLXdpZHRoOiR7bGluZS53aWR0aH1cIlxuICAgICAgICAgICAgICBjbGFzcz1cIiR7bGluZS5jbGFzc05hbWV9XCIgLz5gO1xuICAgIGlmIChpbnB1dHMubGFiZWxzKSB7XG4gICAgICAgIHN2ZyArPSBgPHRleHRcbiAgICAgICAgICAgICAgeD1cIiR7cGl4ZWxYIC8gOH1cIlxuICAgICAgICAgICAgICB5PVwiJHtwaXhlbFkgLyAyICsgcm93ICogcGl4ZWxZIC0gNX1cIlxuICAgICAgICAgICAgICBmaWxsPVwiYmxhY2tcIlxuICAgICAgICAgICAgICBmb250LXNpemU9XCIke2ZvbnRTaXplfVwiXG4gICAgICAgICAgICAgIGNsYXNzPVwiJHtmb250Q2xhc3NOYW1lfVwiPiR7aW5wdXRzLmxhYmVsc1tyb3ddfTwvdGV4dD5gO1xuICAgIH1cbiAgICByZXR1cm4gc3ZnO1xufVxuZnVuY3Rpb24gZHJhd05ldXJvbih7IHBpeGVsWCwgcGl4ZWxZLCByb3csIGNvbHVtbiwgcmFkaXVzLCBoaWRkZW4sIH0pIHtcbiAgICByZXR1cm4gYDxjaXJjbGVcbiAgICAgICAgICAgIGN4PVwiJHtwaXhlbFggLyAyICsgY29sdW1uICogcGl4ZWxYfVwiXG4gICAgICAgICAgICBjeT1cIiR7cGl4ZWxZIC8gMiArIHJvdyAqIHBpeGVsWX1cIlxuICAgICAgICAgICAgcj1cIiR7cmFkaXVzfVwiXG4gICAgICAgICAgICBzdHJva2U9XCJibGFja1wiXG4gICAgICAgICAgICBzdHJva2Utd2lkdGg9XCIxXCJcbiAgICAgICAgICAgIGZpbGw9XCIke2hpZGRlbi5jb2xvcn1cIlxuICAgICAgICAgICAgY2xhc3M9XCIke2hpZGRlbi5jbGFzc05hbWV9XCIgLz5gO1xufVxuZnVuY3Rpb24gZHJhd091dHB1dCh7IHBpeGVsWCwgcGl4ZWxZLCByb3csIGNvbHVtbiwgbGluZSwgb3V0cHV0cywgcmFkaXVzLCB9KSB7XG4gICAgcmV0dXJuIGA8Y2lyY2xlXG4gICAgICAgICAgICBjeD1cIiR7cGl4ZWxYIC8gMiArIGNvbHVtbiAqIHBpeGVsWH1cIlxuICAgICAgICAgICAgY3k9XCIke3BpeGVsWSAvIDIgKyByb3cgKiBwaXhlbFl9XCJcbiAgICAgICAgICAgIHI9XCIke3JhZGl1c31cIlxuICAgICAgICAgICAgc3Ryb2tlPVwiYmxhY2tcIlxuICAgICAgICAgICAgc3Ryb2tlLXdpZHRoPVwiMVwiXG4gICAgICAgICAgICBmaWxsPVwiJHtvdXRwdXRzLmNvbG9yfVwiXG4gICAgICAgICAgICBjbGFzcz1cIiR7b3V0cHV0cy5jbGFzc05hbWV9XCIgLz5cbiAgICAgICAgICA8bGluZVxuICAgICAgICAgICAgeDE9XCIke3BpeGVsWCAvIDIgKyBjb2x1bW4gKiBwaXhlbFggKyByYWRpdXN9XCJcbiAgICAgICAgICAgIHkxPVwiJHtwaXhlbFkgLyAyICsgcm93ICogcGl4ZWxZfVwiXG4gICAgICAgICAgICB4Mj1cIiR7cGl4ZWxYIC8gMiArIGNvbHVtbiAqIHBpeGVsWCArIHBpeGVsWCAvIDR9XCJcbiAgICAgICAgICAgIHkyPVwiJHtwaXhlbFkgLyAyICsgcm93ICogcGl4ZWxZfVwiXG4gICAgICAgICAgICBzdHlsZT1cInN0cm9rZToke2xpbmUuY29sb3J9O3N0cm9rZS13aWR0aDoke2xpbmUud2lkdGh9XCJcbiAgICAgICAgICAgIGNsYXNzPVwiJHtsaW5lLmNsYXNzTmFtZX1cIiAvPmA7XG59XG5mdW5jdGlvbiBkcmF3QmFja3dhcmRDb25uZWN0aW9ucyh7IHBpeGVsWCwgcGl4ZWxZLCByb3csIGNvbHVtbiwgcmFkaXVzLCBsaW5lWSwgbGluZSwgcHJldmlvdXNDb25uZWN0aW9uSW5kZXgsIH0pIHtcbiAgICByZXR1cm4gYDxsaW5lXG4gICAgICAgICAgICB4MT1cIiR7cGl4ZWxYIC8gMiArIChjb2x1bW4gLSAxKSAqIHBpeGVsWCArIHJhZGl1c31cIlxuICAgICAgICAgICAgeTE9XCIke2xpbmVZIC8gMiArIHByZXZpb3VzQ29ubmVjdGlvbkluZGV4ICogbGluZVl9XCJcbiAgICAgICAgICAgIHgyPVwiJHtwaXhlbFggLyAyICsgY29sdW1uICogcGl4ZWxYIC0gcmFkaXVzfVwiXG4gICAgICAgICAgICB5Mj1cIiR7cGl4ZWxZIC8gMiArIHJvdyAqIHBpeGVsWX1cIlxuICAgICAgICAgICAgc3R5bGU9XCJzdHJva2U6JHtsaW5lLmNvbG9yfTtzdHJva2Utd2lkdGg6JHtsaW5lLndpZHRofVwiXG4gICAgICAgICAgICBjbGFzcz1cIiR7bGluZS5jbGFzc05hbWV9XCIgLz5gO1xufVxuZnVuY3Rpb24gbmV1cmFsTmV0d29ya1RvSW5uZXJTVkcob3B0aW9ucykge1xuICAgIGNvbnN0IHsgc2l6ZXMsIGhlaWdodCwgd2lkdGggfSA9IG9wdGlvbnM7XG4gICAgbGV0IHN2ZyA9ICcnO1xuICAgIGNvbnN0IHBpeGVsWCA9IHdpZHRoIC8gc2l6ZXMubGVuZ3RoO1xuICAgIGZvciAobGV0IGNvbHVtbiA9IDA7IGNvbHVtbiA8IHNpemVzLmxlbmd0aDsgY29sdW1uKyspIHtcbiAgICAgICAgY29uc3Qgc2l6ZSA9IHNpemVzW2NvbHVtbl07XG4gICAgICAgIGNvbnN0IHBpeGVsWSA9IGhlaWdodCAvIHNpemU7XG4gICAgICAgIGZvciAobGV0IHJvdyA9IDA7IHJvdyA8IHNpemU7IHJvdysrKSB7XG4gICAgICAgICAgICBpZiAoY29sdW1uID09PSAwKSB7XG4gICAgICAgICAgICAgICAgc3ZnICs9IGRyYXdJbnB1dCh7IHBpeGVsWCwgcGl4ZWxZLCByb3csIGNvbHVtbiwgLi4ub3B0aW9ucyB9KTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgIGlmIChjb2x1bW4gPT09IHNpemVzLmxlbmd0aCAtIDEpIHtcbiAgICAgICAgICAgICAgICAgICAgc3ZnICs9IGRyYXdPdXRwdXQoeyBwaXhlbFgsIHBpeGVsWSwgcm93LCBjb2x1bW4sIC4uLm9wdGlvbnMgfSk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICBzdmcgKz0gZHJhd05ldXJvbih7IHBpeGVsWCwgcGl4ZWxZLCByb3csIGNvbHVtbiwgLi4ub3B0aW9ucyB9KTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgY29uc3QgcHJldmlvdXNTaXplID0gc2l6ZXNbY29sdW1uIC0gMV07XG4gICAgICAgICAgICAgICAgY29uc3QgbGluZVkgPSBoZWlnaHQgLyBwcmV2aW91c1NpemU7XG4gICAgICAgICAgICAgICAgZm9yIChsZXQgcHJldmlvdXNDb25uZWN0aW9uSW5kZXggPSAwOyBwcmV2aW91c0Nvbm5lY3Rpb25JbmRleCA8IHByZXZpb3VzU2l6ZTsgcHJldmlvdXNDb25uZWN0aW9uSW5kZXgrKykge1xuICAgICAgICAgICAgICAgICAgICBzdmcgKz0gZHJhd0JhY2t3YXJkQ29ubmVjdGlvbnMoe1xuICAgICAgICAgICAgICAgICAgICAgICAgcGl4ZWxYLFxuICAgICAgICAgICAgICAgICAgICAgICAgcGl4ZWxZLFxuICAgICAgICAgICAgICAgICAgICAgICAgcm93LFxuICAgICAgICAgICAgICAgICAgICAgICAgY29sdW1uLFxuICAgICAgICAgICAgICAgICAgICAgICAgbGluZVksXG4gICAgICAgICAgICAgICAgICAgICAgICBwcmV2aW91c0Nvbm5lY3Rpb25JbmRleCxcbiAgICAgICAgICAgICAgICAgICAgICAgIC4uLm9wdGlvbnMsXG4gICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIH1cbiAgICByZXR1cm4gc3ZnO1xufVxuZnVuY3Rpb24gZHJhd1JlY3VycmVudENvbm5lY3Rpb25zKHsgcGl4ZWxYLCBwaXhlbFksIHJvdywgY29sdW1uLCByYWRpdXMsIHJlY3VycmVudExpbmUsIH0pIHtcbiAgICBjb25zdCBtb3ZlWCA9IHBpeGVsWCAvIDIgKyBjb2x1bW4gKiBwaXhlbFggKyByYWRpdXMgKyAxO1xuICAgIGNvbnN0IG1vdmVZID0gcGl4ZWxZIC8gMiArIHJvdyAqIHBpeGVsWTtcbiAgICBjb25zdCB4ID0gbW92ZVggLSByYWRpdXMgKiAyIC0gMjtcbiAgICBjb25zdCB5ID0gbW92ZVk7XG4gICAgY29uc3QgeDEgPSB4ICsgMTAwO1xuICAgIGNvbnN0IHkxID0geSArIDUwO1xuICAgIGNvbnN0IHgyID0gbW92ZVggLSAxMDA7XG4gICAgY29uc3QgeTIgPSBtb3ZlWSArIDUwO1xuICAgIHJldHVybiBgPHBhdGhcbiAgICAgICAgICAgICAgZD1cIk0gJHttb3ZlWH0gJHttb3ZlWX0gQyAke3gxfSAke3kxfSwgJHt4Mn0gJHt5Mn0sICR7eH0gJHt5fVwiXG4gICAgICAgICAgICAgIHN0cm9rZT1cIiR7cmVjdXJyZW50TGluZS5jb2xvcn1cIlxuICAgICAgICAgICAgICBzdHJva2Utd2lkdGg9XCIke3JlY3VycmVudExpbmUud2lkdGh9XCJcbiAgICAgICAgICAgICAgZmlsbD1cInRyYW5zcGFyZW50XCJcbiAgICAgICAgICAgICAgc3Ryb2tlLWxpbmVjYXA9XCJyb3VuZFwiXG4gICAgICAgICAgICAgIG1hcmtlci1lbmQ9XCJ1cmwoI2Fycm93KVwiXG4gICAgICAgICAgICAgIGNsYXNzPVwiJHtyZWN1cnJlbnRMaW5lLmNsYXNzTmFtZX1cIiAvPmA7XG59XG5mdW5jdGlvbiBybm5Ub0lubmVyU1ZHKG9wdGlvbnMpIHtcbiAgICBjb25zdCB7IHdpZHRoLCBoZWlnaHQsIHJlY3VycmVudExpbmUsIHNpemVzLCByYWRpdXMgfSA9IG9wdGlvbnM7XG4gICAgY29uc3QgcGl4ZWxYID0gd2lkdGggLyBzaXplcy5sZW5ndGg7XG4gICAgbGV0IHN2ZyA9IGA8ZGVmcz5cbiAgICAgICAgICAgICAgPG1hcmtlciBpZD1cImFycm93XCIgbWFya2VyV2lkdGg9XCIxMFwiIG1hcmtlckhlaWdodD1cIjEwXCIgcmVmWD1cIjhcIiByZWZZPVwiM1wiIG9yaWVudD1cImF1dG9cIiBtYXJrZXJVbml0cz1cInN0cm9rZVdpZHRoXCI+XG4gICAgICAgICAgICAgICAgPHBhdGggZD1cIk0wLDAgTDAsNiBMOSwzIHpcIiBmaWxsPVwiJHtyZWN1cnJlbnRMaW5lLmNvbG9yfVwiIC8+XG4gICAgICAgICAgICAgIDwvbWFya2VyPlxuICAgICAgICAgICAgPC9kZWZzPmA7XG4gICAgc3ZnICs9IG5ldXJhbE5ldHdvcmtUb0lubmVyU1ZHKG9wdGlvbnMpO1xuICAgIGZvciAobGV0IGNvbHVtbiA9IDE7IGNvbHVtbiA8IHNpemVzLmxlbmd0aDsgY29sdW1uKyspIHtcbiAgICAgICAgY29uc3Qgc2l6ZSA9IHNpemVzW2NvbHVtbl07XG4gICAgICAgIGNvbnN0IHBpeGVsWSA9IGhlaWdodCAvIHNpemU7XG4gICAgICAgIGZvciAobGV0IHJvdyA9IDA7IHJvdyA8IHNpemU7IHJvdysrKSB7XG4gICAgICAgICAgICBzdmcgKz0gZHJhd1JlY3VycmVudENvbm5lY3Rpb25zKHtcbiAgICAgICAgICAgICAgICBwaXhlbFgsXG4gICAgICAgICAgICAgICAgcGl4ZWxZLFxuICAgICAgICAgICAgICAgIHJvdyxcbiAgICAgICAgICAgICAgICBjb2x1bW4sXG4gICAgICAgICAgICAgICAgcmFkaXVzLFxuICAgICAgICAgICAgICAgIHJlY3VycmVudExpbmUsXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgfVxuICAgIH1cbiAgICByZXR1cm4gc3ZnO1xufVxuZnVuY3Rpb24gZ2V0RmVlZEZvcndhcmRMYXllcnMobmV0d29yaykge1xuICAgIGNvbnN0IHsgb3B0aW9ucyB9ID0gbmV0d29yaztcbiAgICBpZiAoIW9wdGlvbnMpIHtcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdvcHRpb25zIG5vdCBkZWZpbmVkJyk7XG4gICAgfVxuICAgIGlmICghb3B0aW9ucy5pbnB1dExheWVyKSB7XG4gICAgICAgIHRocm93IG5ldyBFcnJvcignb3B0aW9ucy5pbnB1dExhdGVyIG5vdCBkZWZpbmVkJyk7XG4gICAgfVxuICAgIGlmICghb3B0aW9ucy5oaWRkZW5MYXllcnMpIHtcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdvcHRpb25zLmhpZGRlbkxheWVycyBub3QgZGVmaW5lZCcpO1xuICAgIH1cbiAgICBpZiAob3B0aW9ucy5oaWRkZW5MYXllcnMubGVuZ3RoIDwgMSkge1xuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ29wdGlvbnMuaGlkZGVuTGF5ZXJzIGlzIGVtcHR5Jyk7XG4gICAgfVxuICAgIGlmICghb3B0aW9ucy5vdXRwdXRMYXllcikge1xuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ29wdGlvbnMub3V0cHV0TGF5ZXIgbm90IGRlZmluZWQnKTtcbiAgICB9XG4gICAgY29uc3QgaW5wdXRMYXllciA9IG9wdGlvbnMuaW5wdXRMYXllcigpO1xuICAgIGNvbnN0IGhpZGRlbkxheWVycyA9IFtdO1xuICAgIGhpZGRlbkxheWVycy5wdXNoKG9wdGlvbnMuaGlkZGVuTGF5ZXJzWzBdKGlucHV0TGF5ZXIsIDApKTtcbiAgICBmb3IgKGxldCBpID0gMTsgaSA8IG9wdGlvbnMuaGlkZGVuTGF5ZXJzLmxlbmd0aDsgaSsrKSB7XG4gICAgICAgIGhpZGRlbkxheWVycy5wdXNoKG9wdGlvbnMuaGlkZGVuTGF5ZXJzW2ldKGhpZGRlbkxheWVyc1tpIC0gMV0sIGkpKTtcbiAgICB9XG4gICAgY29uc3Qgb3V0cHV0TGF5ZXIgPSBvcHRpb25zLm91dHB1dExheWVyKGhpZGRlbkxheWVyc1toaWRkZW5MYXllcnMubGVuZ3RoIC0gMV0sIGhpZGRlbkxheWVycy5sZW5ndGgpO1xuICAgIHJldHVybiB7XG4gICAgICAgIGlucHV0U2l6ZTogaW5wdXRMYXllci5oZWlnaHQsXG4gICAgICAgIGhpZGRlbkxheWVyczogaGlkZGVuTGF5ZXJzLm1hcCgoaGlkZGVuTGF5ZXIpID0+IGhpZGRlbkxheWVyLmhlaWdodCksXG4gICAgICAgIG91dHB1dFNpemU6IG91dHB1dExheWVyLmhlaWdodCxcbiAgICB9O1xufVxuZnVuY3Rpb24gZ2V0UmVjdXJyZW50TGF5ZXJzKG5ldHdvcmspIHtcbiAgICBjb25zdCBoaWRkZW5MYXllcnMgPSBbXTtcbiAgICBjb25zdCB7IG9wdGlvbnMgfSA9IG5ldHdvcms7XG4gICAgaWYgKCFvcHRpb25zLmlucHV0TGF5ZXIpIHtcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdpbnB1dExheWVyIG5vdCBkZWZpbmVkJyk7XG4gICAgfVxuICAgIGlmICghb3B0aW9ucy5vdXRwdXRMYXllcikge1xuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ291dHB1dExheWVyIG5vdCBkZWZpbmVkJyk7XG4gICAgfVxuICAgIGNvbnN0IGlucHV0TGF5ZXIgPSBvcHRpb25zLmlucHV0TGF5ZXIoKTtcbiAgICBoaWRkZW5MYXllcnMucHVzaChvcHRpb25zLmhpZGRlbkxheWVyc1swXShpbnB1dExheWVyLCByZWN1cnJlbnRaZXJvcygpLCAwKSk7XG4gICAgZm9yIChsZXQgaSA9IDE7IGkgPCBvcHRpb25zLmhpZGRlbkxheWVycy5sZW5ndGg7IGkrKykge1xuICAgICAgICBoaWRkZW5MYXllcnMucHVzaChvcHRpb25zLmhpZGRlbkxheWVyc1tpXShoaWRkZW5MYXllcnNbaSAtIDFdLCByZWN1cnJlbnRaZXJvcygpLCBpKSk7XG4gICAgfVxuICAgIGNvbnN0IG91dHB1dExheWVyID0gb3B0aW9ucy5vdXRwdXRMYXllcihoaWRkZW5MYXllcnNbaGlkZGVuTGF5ZXJzLmxlbmd0aCAtIDFdLCAtMSk7XG4gICAgcmV0dXJuIHtcbiAgICAgICAgaW5wdXRTaXplOiBpbnB1dExheWVyLmhlaWdodCxcbiAgICAgICAgaGlkZGVuTGF5ZXJzOiBoaWRkZW5MYXllcnMubWFwKChoaWRkZW5MYXllcikgPT4gaGlkZGVuTGF5ZXIuaGVpZ2h0KSxcbiAgICAgICAgb3V0cHV0U2l6ZTogb3V0cHV0TGF5ZXIuaGVpZ2h0LFxuICAgIH07XG59XG5mdW5jdGlvbiB3cmFwT3V0ZXJTVkcoc3ZnQm9keSwgd2lkdGgsIGhlaWdodCkge1xuICAgIC8vIGxhbmd1YWdlPWh0bWxcbiAgICByZXR1cm4gYDxzdmdcbiAgICAgICAgICAgIHhtbG5zPVwiaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmdcIlxuICAgICAgICAgICAgeG1sbnM6eGxpbms9XCJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rXCJcbiAgICAgICAgICAgIHZlcnNpb249XCIxLjFcIlxuICAgICAgICAgICAgd2lkdGg9XCIke3dpZHRofVwiXG4gICAgICAgICAgICBoZWlnaHQ9XCIke2hlaWdodH1cIj4ke3N2Z0JvZHl9PC9zdmc+YDtcbn1cbmZ1bmN0aW9uIGdldE5ldXJhbE5ldHdvcmtKU09OU2l6ZXMoanNvbikge1xuICAgIHJldHVybiBqc29uLnNpemVzO1xufVxuZnVuY3Rpb24gZ2V0TmV1cmFsTmV0d29ya1NpemVzKG5ldCkge1xuICAgIGNvbnN0IHsgb3B0aW9ucywgc2l6ZXMgfSA9IG5ldDtcbiAgICBjb25zdCB7IGlucHV0U2l6ZSwgb3V0cHV0U2l6ZSwgaGlkZGVuTGF5ZXJzIH0gPSBvcHRpb25zO1xuICAgIGlmICghc2l6ZXMpIHtcbiAgICAgICAgaWYgKHR5cGVvZiBpbnB1dFNpemUgPT09ICdudW1iZXInICYmIGlucHV0U2l6ZSA8IDEpIHtcbiAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcignaW5wdXRTaXplIG5vdCBzZXQnKTtcbiAgICAgICAgfVxuICAgICAgICBpZiAodHlwZW9mIG91dHB1dFNpemUgPT09ICdudW1iZXInICYmIG91dHB1dFNpemUgPCAxKSB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ291dHB1dFNpemUgbm90IHNldCcpO1xuICAgICAgICB9XG4gICAgICAgIGlmIChoaWRkZW5MYXllcnMgPT09IG51bGwgfHwgaGlkZGVuTGF5ZXJzID09PSB2b2lkIDAgPyB2b2lkIDAgOiBoaWRkZW5MYXllcnMuc29tZSgodikgPT4gdiA8IDEpKSB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ2hpZGRlbkxheWVycyBub3Qgc2V0Jyk7XG4gICAgICAgIH1cbiAgICB9XG4gICAgcmV0dXJuIHR5cGVvZiBpbnB1dFNpemUgPT09ICdudW1iZXInICYmXG4gICAgICAgIEFycmF5LmlzQXJyYXkoaGlkZGVuTGF5ZXJzKSAmJlxuICAgICAgICB0eXBlb2Ygb3V0cHV0U2l6ZSA9PT0gJ251bWJlcidcbiAgICAgICAgPyBbaW5wdXRTaXplXS5jb25jYXQoaGlkZGVuTGF5ZXJzKS5jb25jYXQoW291dHB1dFNpemVdKVxuICAgICAgICA6IHNpemVzO1xufVxuZnVuY3Rpb24gZ2V0Uk5OU2l6ZXMobmV0KSB7XG4gICAgY29uc3QgeyBvcHRpb25zIH0gPSBuZXQ7XG4gICAgY29uc3QgeyBpbnB1dFNpemUsIG91dHB1dFNpemUsIGhpZGRlbkxheWVycyB9ID0gb3B0aW9ucztcbiAgICByZXR1cm4gW2lucHV0U2l6ZV0uY29uY2F0KGhpZGRlbkxheWVycykuY29uY2F0KFtvdXRwdXRTaXplXSk7XG59XG5mdW5jdGlvbiBkZWZhdWx0T3B0aW9ucygpIHtcbiAgICByZXR1cm4ge1xuICAgICAgICBsaW5lOiB7XG4gICAgICAgICAgICB3aWR0aDogMC41LFxuICAgICAgICAgICAgY29sb3I6ICdibGFjaycsXG4gICAgICAgICAgICBjbGFzc05hbWU6ICdjb25uZWN0aW9uJyxcbiAgICAgICAgfSxcbiAgICAgICAgcmVjdXJyZW50TGluZToge1xuICAgICAgICAgICAgd2lkdGg6IDEsXG4gICAgICAgICAgICBjb2xvcjogJ3JlZCcsXG4gICAgICAgICAgICBjbGFzc05hbWU6ICdyZWN1cnJlbmNlJyxcbiAgICAgICAgfSxcbiAgICAgICAgaW5wdXRzOiB7XG4gICAgICAgICAgICBjb2xvcjogJ3JnYmEoMCwgMTI4LCAwLCAwLjUpJyxcbiAgICAgICAgICAgIGxhYmVsczogbnVsbCxcbiAgICAgICAgICAgIGNsYXNzTmFtZTogJ2lucHV0JyxcbiAgICAgICAgfSxcbiAgICAgICAgb3V0cHV0czoge1xuICAgICAgICAgICAgY29sb3I6ICdyZ2JhKDEwMCwgMTQ5LCAyMzcsIDAuNSknLFxuICAgICAgICAgICAgY2xhc3NOYW1lOiAnb3V0cHV0JyxcbiAgICAgICAgfSxcbiAgICAgICAgaGlkZGVuOiB7XG4gICAgICAgICAgICBjb2xvcjogJ3JnYmEoMjU1LCAxMjcsIDgwLCAwLjUpJyxcbiAgICAgICAgICAgIGNsYXNzTmFtZTogJ2hpZGRlbi1uZXVyb24nLFxuICAgICAgICB9LFxuICAgICAgICBmb250U2l6ZTogJzE0cHgnLFxuICAgICAgICBmb250Q2xhc3NOYW1lOiAnbGFiZWwnLFxuICAgICAgICByYWRpdXM6IDgsXG4gICAgICAgIHdpZHRoOiA0MDAsXG4gICAgICAgIGhlaWdodDogMjUwLFxuICAgICAgICBzaXplczogW10sXG4gICAgfTtcbn1cbmZ1bmN0aW9uIHRvU1ZHKG5ldCwgb3B0aW9ucykge1xuICAgIGNvbnN0IG1lcmdlZE9wdGlvbnMgPSB7IC4uLmRlZmF1bHRPcHRpb25zKCksIC4uLm9wdGlvbnMgfTtcbiAgICBjb25zdCB7IHdpZHRoLCBoZWlnaHQsIGlucHV0cyB9ID0gbWVyZ2VkT3B0aW9ucztcbiAgICAvLyBHZXQgbmV0d29yayBzaXplIGFycmF5IGZvciBOZXVyYWxOZXR3b3JrIG9yIE5ldXJhbE5ldHdvcmtHUFVcbiAgICBsZXQgc2l6ZXMgPSBbXTtcbiAgICBpZiAobmV0IGluc3RhbmNlb2YgTmV1cmFsTmV0d29yayB8fCBuZXQgaW5zdGFuY2VvZiBOZXVyYWxOZXR3b3JrR1BVKSB7XG4gICAgICAgIHNpemVzID0gZ2V0TmV1cmFsTmV0d29ya1NpemVzKG5ldCk7XG4gICAgfVxuICAgIC8vIGdldCBuZXR3b3JrIHNpemUgZm9yIFJlY3VycmVudFxuICAgIGVsc2UgaWYgKG5ldCBpbnN0YW5jZW9mIFJlY3VycmVudCkge1xuICAgICAgICBjb25zdCB7IGlucHV0U2l6ZSwgaGlkZGVuTGF5ZXJzLCBvdXRwdXRTaXplIH0gPSBnZXRSZWN1cnJlbnRMYXllcnMobmV0KTtcbiAgICAgICAgc2l6ZXMgPSBbaW5wdXRTaXplXS5jb25jYXQoaGlkZGVuTGF5ZXJzKS5jb25jYXQoW291dHB1dFNpemVdKTtcbiAgICB9XG4gICAgLy8gZ2V0IG5ldHdvcmsgc2l6ZSBmb3IgRmVlZEZvcndhcmRcbiAgICBlbHNlIGlmIChuZXQgaW5zdGFuY2VvZiBGZWVkRm9yd2FyZCkge1xuICAgICAgICBjb25zdCB7IGlucHV0U2l6ZSwgaGlkZGVuTGF5ZXJzLCBvdXRwdXRTaXplIH0gPSBnZXRGZWVkRm9yd2FyZExheWVycyhuZXQpO1xuICAgICAgICBzaXplcyA9IFtpbnB1dFNpemVdLmNvbmNhdChoaWRkZW5MYXllcnMpLmNvbmNhdChbb3V0cHV0U2l6ZV0pO1xuICAgIH1cbiAgICAvLyBoYW5kbGUganNvbiwgcmVjdXJyZW50IGZpcnN0XG4gICAgZWxzZSBpZiAobmV0IGluc3RhbmNlb2YgUk5OIHx8XG4gICAgICAgIG5ldCBpbnN0YW5jZW9mIExTVE0gfHxcbiAgICAgICAgbmV0IGluc3RhbmNlb2YgR1JVIHx8XG4gICAgICAgIG5ldCBpbnN0YW5jZW9mIFJOTlRpbWVTdGVwIHx8XG4gICAgICAgIG5ldCBpbnN0YW5jZW9mIExTVE1UaW1lU3RlcCB8fFxuICAgICAgICBuZXQgaW5zdGFuY2VvZiBHUlVUaW1lU3RlcCkge1xuICAgICAgICByZXR1cm4gd3JhcE91dGVyU1ZHKHJublRvSW5uZXJTVkcoe1xuICAgICAgICAgICAgLi4ubWVyZ2VkT3B0aW9ucyxcbiAgICAgICAgICAgIHNpemVzOiBjaGVja1NpemVzKGdldFJOTlNpemVzKG5ldCksIGlucHV0cy5sYWJlbHMpLFxuICAgICAgICB9KSwgd2lkdGgsIGhlaWdodCk7XG4gICAgfVxuICAgIC8vIGhhbmRsZSBqc29uLCBOZXVyYWxOZXR3b3JrXG4gICAgZWxzZSBpZiAobmV0Lmhhc093blByb3BlcnR5KCd0eXBlJykpIHtcbiAgICAgICAgc3dpdGNoIChuZXQudHlwZSkge1xuICAgICAgICAgICAgY2FzZSAnTmV1cmFsTmV0d29yayc6XG4gICAgICAgICAgICBjYXNlICdOZXVyYWxOZXR3b3JrR1BVJzpcbiAgICAgICAgICAgICAgICByZXR1cm4gd3JhcE91dGVyU1ZHKG5ldXJhbE5ldHdvcmtUb0lubmVyU1ZHKHtcbiAgICAgICAgICAgICAgICAgICAgLi4ubWVyZ2VkT3B0aW9ucyxcbiAgICAgICAgICAgICAgICAgICAgc2l6ZXM6IGNoZWNrU2l6ZXMoZ2V0TmV1cmFsTmV0d29ya0pTT05TaXplcyhuZXQpLCBpbnB1dHMubGFiZWxzKSxcbiAgICAgICAgICAgICAgICB9KSwgd2lkdGgsIGhlaWdodCk7XG4gICAgICAgICAgICBjYXNlICdSTk4nOlxuICAgICAgICAgICAgY2FzZSAnR1JVJzpcbiAgICAgICAgICAgIGNhc2UgJ0xTVE0nOlxuICAgICAgICAgICAgY2FzZSAnUk5OVGltZVN0ZXAnOlxuICAgICAgICAgICAgY2FzZSAnR1JVVGltZVN0ZXAnOlxuICAgICAgICAgICAgY2FzZSAnTFNUTVRpbWVTdGVwJzpcbiAgICAgICAgICAgICAgICByZXR1cm4gd3JhcE91dGVyU1ZHKHJublRvSW5uZXJTVkcoe1xuICAgICAgICAgICAgICAgICAgICAuLi5tZXJnZWRPcHRpb25zLFxuICAgICAgICAgICAgICAgICAgICBzaXplczogY2hlY2tTaXplcyhnZXRSTk5TaXplcyhuZXQpLCBpbnB1dHMubGFiZWxzKSxcbiAgICAgICAgICAgICAgICB9KSwgd2lkdGgsIGhlaWdodCk7XG4gICAgICAgICAgICBkZWZhdWx0OlxuICAgICAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcigndW5yZWNvZ25pemVkIG5ldHdvcmsnKTtcbiAgICAgICAgfVxuICAgIH1cbiAgICBlbHNlIGlmIChuZXQuaGFzT3duUHJvcGVydHkoJ2lucHV0U2l6ZScpICYmXG4gICAgICAgIG5ldC5oYXNPd25Qcm9wZXJ0eSgnaGlkZGVuTGF5ZXJzJykgJiZcbiAgICAgICAgbmV0Lmhhc093blByb3BlcnR5KCdvdXRwdXRTaXplJykpIHtcbiAgICAgICAgY29uc3QgeyBpbnB1dFNpemUsIGhpZGRlbkxheWVycywgb3V0cHV0U2l6ZSB9ID0gbmV0O1xuICAgICAgICBzaXplcyA9IFtpbnB1dFNpemUsIC4uLmhpZGRlbkxheWVycywgb3V0cHV0U2l6ZV07XG4gICAgfVxuICAgIGVsc2UgaWYgKG5ldC5oYXNPd25Qcm9wZXJ0eSgnc2l6ZXMnKSkge1xuICAgICAgICBzaXplcyA9IG5ldC5zaXplcztcbiAgICB9XG4gICAgZWxzZSB7XG4gICAgICAgIHRocm93IG5ldyBFcnJvcigndW5yZWNvZ25pemVkIG5ldHdvcmsnKTtcbiAgICB9XG4gICAgcmV0dXJuIHdyYXBPdXRlclNWRyhuZXVyYWxOZXR3b3JrVG9Jbm5lclNWRyh7XG4gICAgICAgIC4uLm1lcmdlZE9wdGlvbnMsXG4gICAgICAgIHNpemVzOiBjaGVja1NpemVzKHNpemVzLCBpbnB1dHMubGFiZWxzKSxcbiAgICB9KSwgd2lkdGgsIGhlaWdodCk7XG59XG5mdW5jdGlvbiBjaGVja1NpemVzKHNpemVzLCBsYWJlbHMpIHtcbiAgICBpZiAoIXNpemVzKSB7XG4gICAgICAgIHRocm93IG5ldyBFcnJvcignc2l6ZXMgbm90IHNldCcpO1xuICAgIH1cbiAgICBpZiAoc2l6ZXMuc29tZSgoc2l6ZSkgPT4gc2l6ZSA8IDEpKSB7XG4gICAgICAgIHRocm93IG5ldyBFcnJvcignc2l6ZXMgbm90IHNldCBjb3JyZWN0bHknKTtcbiAgICB9XG4gICAgaWYgKGxhYmVscyAmJiBsYWJlbHMubGVuZ3RoICE9PSBzaXplc1swXSkge1xuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ25vdCBlbm91Z2ggbGFiZWxzIGZvciBpbnB1dHMnKTtcbiAgICB9XG4gICAgcmV0dXJuIHNpemVzO1xufVxuXG5jb25zdCByZWN1cnJlbnQgPSB7XG4gICAgUk5OVGltZVN0ZXAsXG4gICAgTFNUTVRpbWVTdGVwLFxuICAgIEdSVVRpbWVTdGVwLFxuICAgIFJOTixcbiAgICBMU1RNLFxuICAgIEdSVSxcbn07XG5jb25zdCB1dGlsaXRpZXMgPSB7XG4gICAgbWF4LFxuICAgIG1zZTogbXNlJDEsXG4gICAgb25lczogb25lcyQxLFxuICAgIG9uZXMyRCxcbiAgICByYW5kb206IHJhbmRvbSQxLFxuICAgIHJhbmRvbVdlaWdodCxcbiAgICByYW5kb3MsXG4gICAgcmFuZ2UsXG4gICAgdG9BcnJheSxcbiAgICBEYXRhRm9ybWF0dGVyLFxuICAgIHplcm9zOiB6ZXJvcyQxLFxuICAgIHRvU1ZHLFxufTtcblxuY2xhc3MgVHJhaW5TdHJlYW0gZXh0ZW5kcyBzdHJlYW0uV3JpdGFibGUge1xuICAgIGNvbnN0cnVjdG9yKG9wdGlvbnMpIHtcbiAgICAgICAgc3VwZXIoe1xuICAgICAgICAgICAgb2JqZWN0TW9kZTogdHJ1ZSxcbiAgICAgICAgfSk7XG4gICAgICAgIC8vIHJlcXVpcmUgdGhlIG5ldXJhbE5ldHdvcmtcbiAgICAgICAgaWYgKCFvcHRpb25zLm5ldXJhbE5ldHdvcmspIHtcbiAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcignTm8gbmV1cmFsIG5ldHdvcmsgc3BlY2lmaWVkLiBQbGVhc2Ugc2VlIGxpc3Qgb2YgYXZhaWxhYmxlIG5ldHdvcmsgdHlwZXM6IGh0dHBzOi8vZ2l0aHViLmNvbS9CcmFpbkpTL2JyYWluLmpzI25ldXJhbC1uZXR3b3JrLXR5cGVzJyk7XG4gICAgICAgIH1cbiAgICAgICAgY29uc3QgeyBuZXVyYWxOZXR3b3JrIH0gPSBvcHRpb25zO1xuICAgICAgICAvLyBpbmhlcml0IHRyYWluT3B0cyBzZXR0aW5ncyBmcm9tIG5ldXJhbE5ldHdvcmtcbiAgICAgICAgbmV1cmFsTmV0d29yay51cGRhdGVUcmFpbmluZ09wdGlvbnMob3B0aW9ucyk7XG4gICAgICAgIGNvbnN0IHRyYWluT3B0cyA9IG5ldXJhbE5ldHdvcmsgPT09IG51bGwgfHwgbmV1cmFsTmV0d29yayA9PT0gdm9pZCAwID8gdm9pZCAwIDogbmV1cmFsTmV0d29yay50cmFpbk9wdHM7IC8vIGp1c3QgdXBkYXRlZCBmcm9tIGFib3ZlIGxpbmVcbiAgICAgICAgdGhpcy5uZXVyYWxOZXR3b3JrID0gbmV1cmFsTmV0d29yaztcbiAgICAgICAgdGhpcy5kYXRhRm9ybWF0RGV0ZXJtaW5lZCA9IGZhbHNlO1xuICAgICAgICB0aGlzLmkgPSAwOyAvLyBrZWVwIHRyYWNrIG9mIGludGVybmFsIGl0ZXJhdGlvbnNcbiAgICAgICAgdGhpcy5zaXplID0gMDtcbiAgICAgICAgdGhpcy5jb3VudCA9IDA7XG4gICAgICAgIHRoaXMuc3VtID0gMDtcbiAgICAgICAgdGhpcy5mbG9vZENhbGxiYWNrID0gb3B0aW9ucy5mbG9vZENhbGxiYWNrO1xuICAgICAgICB0aGlzLmRvbmVUcmFpbmluZ0NhbGxiYWNrID0gb3B0aW9ucy5kb25lVHJhaW5pbmdDYWxsYmFjaztcbiAgICAgICAgdGhpcy5pdGVyYXRpb25zID0gdHJhaW5PcHRzLml0ZXJhdGlvbnM7XG4gICAgICAgIHRoaXMuZXJyb3JUaHJlc2ggPSB0cmFpbk9wdHMuZXJyb3JUaHJlc2g7XG4gICAgICAgIHRoaXMubG9nID0gdHJhaW5PcHRzLmxvZztcbiAgICAgICAgdGhpcy5sb2dQZXJpb2QgPSB0cmFpbk9wdHMubG9nUGVyaW9kO1xuICAgICAgICB0aGlzLmNhbGxiYWNrUGVyaW9kID0gdHJhaW5PcHRzLmNhbGxiYWNrUGVyaW9kO1xuICAgICAgICB0aGlzLm9uKCdmaW5pc2gnLCB0aGlzLmZpbmlzaFN0cmVhbUl0ZXJhdGlvbi5iaW5kKHRoaXMpKTtcbiAgICAgICAgdGhpcy5jYWxsYmFjayA9IHRyYWluT3B0cy5jYWxsYmFjaztcbiAgICB9XG4gICAgZW5kSW5wdXRzKCkge1xuICAgICAgICB0aGlzLndyaXRlKGZhbHNlKTtcbiAgICB9XG4gICAgX3dyaXRlKGNodW5rLCBlbmMsIG5leHQpIHtcbiAgICAgICAgaWYgKCFjaHVuaykge1xuICAgICAgICAgICAgLy8gY2hlY2sgZm9yIHRoZSBlbmQgb2Ygb25lIGl0ZXJhdGlvbiBvZiB0aGUgc3RyZWFtXG4gICAgICAgICAgICB0aGlzLmVtaXQoJ2ZpbmlzaCcpO1xuICAgICAgICAgICAgcmV0dXJuIG5leHQoKTtcbiAgICAgICAgfVxuICAgICAgICBpZiAoIXRoaXMuZGF0YUZvcm1hdERldGVybWluZWQpIHtcbiAgICAgICAgICAgIHRoaXMuc2l6ZSsrO1xuICAgICAgICAgICAgdGhpcy5uZXVyYWxOZXR3b3JrLmFkZEZvcm1hdChjaHVuayk7XG4gICAgICAgICAgICBpZiAodGhpcy5maXJzdERhdHVtID09PSB1bmRlZmluZWQpIHtcbiAgICAgICAgICAgICAgICB0aGlzLmZpcnN0RGF0dW0gPSBjaHVuaztcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHJldHVybiBuZXh0KCk7XG4gICAgICAgIH1cbiAgICAgICAgdGhpcy5jb3VudCsrO1xuICAgICAgICBjb25zdCBkYXRhID0gdGhpcy5uZXVyYWxOZXR3b3JrLmZvcm1hdERhdGEoW2NodW5rXSk7XG4gICAgICAgIGNvbnN0IGVycm9yID0gdGhpcy5uZXVyYWxOZXR3b3JrLnRyYWluUGF0dGVybihkYXRhWzBdLCB0cnVlKTtcbiAgICAgICAgaWYgKGVycm9yICE9PSBudWxsKSB7XG4gICAgICAgICAgICB0aGlzLnN1bSArPSBlcnJvcjtcbiAgICAgICAgfVxuICAgICAgICAvLyB0ZWxsIHRoZSBSZWFkYWJsZSBTdHJlYW0gdGhhdCB3ZSBhcmUgcmVhZHkgZm9yIG1vcmUgZGF0YVxuICAgICAgICBuZXh0KCk7XG4gICAgfVxuICAgIGZpbmlzaFN0cmVhbUl0ZXJhdGlvbigpIHtcbiAgICAgICAgaWYgKHRoaXMuZGF0YUZvcm1hdERldGVybWluZWQgJiYgdGhpcy5zaXplICE9PSB0aGlzLmNvdW50KSB7XG4gICAgICAgICAgICBjb25zb2xlLndhcm4oXCJUaGlzIGl0ZXJhdGlvbidzIGRhdGEgbGVuZ3RoIHdhcyBkaWZmZXJlbnQgZnJvbSB0aGUgZmlyc3QhXCIpO1xuICAgICAgICB9XG4gICAgICAgIGlmICghdGhpcy5kYXRhRm9ybWF0RGV0ZXJtaW5lZCAmJiB0aGlzLmZpcnN0RGF0dW0gIT09IHVuZGVmaW5lZCkge1xuICAgICAgICAgICAgY29uc3QgZGF0YSA9IHRoaXMubmV1cmFsTmV0d29yay5mb3JtYXREYXRhKFt0aGlzLmZpcnN0RGF0dW1dKTtcbiAgICAgICAgICAgIHRoaXMubmV1cmFsTmV0d29yay52ZXJpZnlJc0luaXRpYWxpemVkKGRhdGEpO1xuICAgICAgICAgICAgdGhpcy5kYXRhRm9ybWF0RGV0ZXJtaW5lZCA9IHRydWU7XG4gICAgICAgICAgICBpZiAodHlwZW9mIHRoaXMuZmxvb2RDYWxsYmFjayA9PT0gJ2Z1bmN0aW9uJykge1xuICAgICAgICAgICAgICAgIHRoaXMuZmxvb2RDYWxsYmFjaygpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICAgIGNvbnN0IGVycm9yID0gdGhpcy5zdW0gLyB0aGlzLnNpemU7XG4gICAgICAgIGlmICh0aGlzLmxvZyAmJiB0aGlzLmkgJSB0aGlzLmxvZ1BlcmlvZCA9PT0gMCkge1xuICAgICAgICAgICAgaWYgKHR5cGVvZiB0aGlzLmxvZyA9PT0gJ2Z1bmN0aW9uJykge1xuICAgICAgICAgICAgICAgIHRoaXMubG9nKHtcbiAgICAgICAgICAgICAgICAgICAgaXRlcmF0aW9uczogdGhpcy5pLFxuICAgICAgICAgICAgICAgICAgICBlcnJvcjogZXJyb3IsXG4gICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgICAgICBjb25zb2xlLmluZm8oYGl0ZXJhdGlvbnM6ICR7dGhpcy5pfSwgdHJhaW5pbmcgZXJyb3I6ICR7ZXJyb3J9YCk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgaWYgKHRoaXMuY2FsbGJhY2sgJiYgdGhpcy5pICUgdGhpcy5jYWxsYmFja1BlcmlvZCA9PT0gMCkge1xuICAgICAgICAgICAgdGhpcy5jYWxsYmFjayh7XG4gICAgICAgICAgICAgICAgZXJyb3IsXG4gICAgICAgICAgICAgICAgaXRlcmF0aW9uczogdGhpcy5pLFxuICAgICAgICAgICAgfSk7XG4gICAgICAgIH1cbiAgICAgICAgdGhpcy5zdW0gPSAwO1xuICAgICAgICB0aGlzLmNvdW50ID0gMDtcbiAgICAgICAgLy8gdXBkYXRlIHRoZSBpdGVyYXRpb25zXG4gICAgICAgIHRoaXMuaSsrO1xuICAgICAgICAvLyBkbyBhIGNoZWNrIGhlcmUgdG8gc2VlIGlmIHdlIG5lZWQgdGhlIHN0cmVhbSBhZ2FpblxuICAgICAgICBpZiAodGhpcy5pIDwgdGhpcy5pdGVyYXRpb25zICYmIGVycm9yID4gdGhpcy5lcnJvclRocmVzaCkge1xuICAgICAgICAgICAgaWYgKHR5cGVvZiB0aGlzLmZsb29kQ2FsbGJhY2sgPT09ICdmdW5jdGlvbicpIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gdGhpcy5mbG9vZENhbGxiYWNrKCk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAvLyBkb25lIHRyYWluaW5nXG4gICAgICAgICAgICBpZiAodHlwZW9mIHRoaXMuZG9uZVRyYWluaW5nQ2FsbGJhY2sgPT09ICdmdW5jdGlvbicpIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gdGhpcy5kb25lVHJhaW5pbmdDYWxsYmFjayh7XG4gICAgICAgICAgICAgICAgICAgIGVycm9yLFxuICAgICAgICAgICAgICAgICAgICBpdGVyYXRpb25zOiB0aGlzLmksXG4gICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9XG59XG5cbmV4cG9ydHMuQ3Jvc3NWYWxpZGF0ZSA9IENyb3NzVmFsaWRhdGU7XG5leHBvcnRzLkZlZWRGb3J3YXJkID0gRmVlZEZvcndhcmQ7XG5leHBvcnRzLk5ldXJhbE5ldHdvcmsgPSBOZXVyYWxOZXR3b3JrO1xuZXhwb3J0cy5OZXVyYWxOZXR3b3JrR1BVID0gTmV1cmFsTmV0d29ya0dQVTtcbmV4cG9ydHMuUmVjdXJyZW50ID0gUmVjdXJyZW50O1xuZXhwb3J0cy5UcmFpblN0cmVhbSA9IFRyYWluU3RyZWFtO1xuZXhwb3J0cy5hY3RpdmF0aW9uID0gaW5kZXgkMTtcbmV4cG9ydHMubGF5ZXIgPSBsYXllcjtcbmV4cG9ydHMubGF5ZXJUeXBlcyA9IGxheWVyVHlwZXM7XG5leHBvcnRzLmxpa2VseSA9IGxpa2VseTtcbmV4cG9ydHMubG9va3VwID0gbG9va3VwO1xuZXhwb3J0cy5wcmF4aXMgPSBpbmRleDtcbmV4cG9ydHMucmVjdXJyZW50ID0gcmVjdXJyZW50O1xuZXhwb3J0cy51dGlsaXRpZXMgPSB1dGlsaXRpZXM7XG4vLyMgc291cmNlTWFwcGluZ1VSTD1pbmRleC5tYXBcbiIsImltcG9ydCBSZWFjdCBmcm9tICdyZWFjdCc7XG5pbXBvcnQgRGFzaGJvYXJkIGZyb20gJy4uL3NyYy9jb21wb25lbnRzL0Rhc2hib2FyZCc7XG5cbmNvbnN0IEhvbWU6IFJlYWN0LkZDID0gKCkgPT4ge1xuICByZXR1cm4gKFxuICAgIDxEYXNoYm9hcmQgLz5cbiAgKVxufVxuXG5leHBvcnQgZGVmYXVsdCBIb21lOyIsImltcG9ydCB7IEZsZXgsIFNwaW5uZXIgfSBmcm9tICdAY2hha3JhLXVpL3JlYWN0JztcbmltcG9ydCBSZWFjdCwgeyB1c2VFZmZlY3QgfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQge1xuICBDaGFydCBhcyBDaGFydEpTLFxuICBDYXRlZ29yeVNjYWxlLFxuICBMaW5lYXJTY2FsZSxcbiAgUG9pbnRFbGVtZW50LFxuICBMaW5lRWxlbWVudCxcbiAgVGl0bGUsXG4gIFRvb2x0aXAsXG4gIExlZ2VuZCxcbn0gZnJvbSAnY2hhcnQuanMnXG5pbXBvcnQgeyBMaW5lIH0gZnJvbSAncmVhY3QtY2hhcnRqcy0yJztcbmltcG9ydCB7IHVzZUJyYWluQ29udGV4dCB9IGZyb20gJy4uLy4uL2NvbnRleHQvQnJhaW5Db250ZXh0JztcblxuQ2hhcnRKUy5yZWdpc3RlcihcbiAgQ2F0ZWdvcnlTY2FsZSxcbiAgTGluZWFyU2NhbGUsXG4gIFBvaW50RWxlbWVudCxcbiAgTGluZUVsZW1lbnQsXG4gIFRpdGxlLFxuICBUb29sdGlwLFxuICBMZWdlbmRcbilcblxuY29uc3QgQ2hhcnQ6IFJlYWN0LkZDPGFueT4gPSAoeyBkYWlseURhdGEgfSkgPT4ge1xuXG4gIGNvbnN0IHsgc2V0VHJhaW5pbmdEYXRhLCB0cmFpbmluZ0NoYXJ0RGF0YSwgcHJlZGljdGVkQ2hhcnREYXRhLCB0cmFpbmluZyB9ID0gdXNlQnJhaW5Db250ZXh0KCk7XG5cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBpZiAoZGFpbHlEYXRhKSB7XG4gICAgICBzZXRUcmFpbmluZ0RhdGEoZGFpbHlEYXRhLnJldmVyc2UoKSk7XG4gICAgfVxuXG4gIH0sIFtkYWlseURhdGFdKVxuXG5cbiAgcmV0dXJuIChcbiAgICA8RmxleCBkaXJlY3Rpb249e1snY29sdW1uJywgJ2NvbHVtbicsICdjb2x1bW4nLCAncm93J119IHc9JzEwMCUnPlxuICAgICAgPEZsZXggdz17WycxMDAlJywgJzEwMCUnLCAnMTAwJScsICc1MCUnXX0gcD17NTB9PlxuICAgICAgICA8TGluZSBvcHRpb25zPXt0cmFpbmluZ0NoYXJ0RGF0YS5vcHRpb25zfSBkYXRhPXt0cmFpbmluZ0NoYXJ0RGF0YS5kYXRhfSAvPlxuICAgICAgPC9GbGV4PlxuICAgICAgPEZsZXggdz17WycxMDAlJywgJzEwMCUnLCAnMTAwJScsICc1MCUnXX0gcD17NTB9PlxuICAgICAgICB7IXRyYWluaW5nID8gPExpbmUgb3B0aW9ucz17cHJlZGljdGVkQ2hhcnREYXRhLm9wdGlvbnN9IGRhdGE9e3ByZWRpY3RlZENoYXJ0RGF0YS5kYXRhfSAvPiA6IDxTcGlubmVyIHNpemU9J3hsJyAvPn1cblxuICAgICAgPC9GbGV4PlxuICAgIDwvRmxleD5cbiAgKTtcbn1cblxuZXhwb3J0IGRlZmF1bHQgQ2hhcnQ7IiwiaW1wb3J0IHsgQm94LCBCdXR0b24sIEZsZXgsIEhlYWRpbmcsIElucHV0LCBUZXh0IH0gZnJvbSAnQGNoYWtyYS11aS9yZWFjdCc7XG5pbXBvcnQgUmVhY3QsIHsgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgQ2hhcnQgZnJvbSAnLi4vQ2hhcnQnO1xuaW1wb3J0IHsgdXNlQnJhaW5Db250ZXh0IH0gZnJvbSAnLi4vLi4vY29udGV4dC9CcmFpbkNvbnRleHQnO1xuXG50eXBlIERhaWx5RGF0YSA9IHtcbiAgcG9zaXRpdmU6IG51bWJlcixcbiAgcmVjb3ZlcmVkOiBudW1iZXIsXG4gIGRlYXRoOiBudW1iZXIsXG4gIGRhdGU6IHN0cmluZ1xufVxuXG5jb25zdCBEYXNoYm9hcmQ6IFJlYWN0LkZDID0gKCkgPT4ge1xuXG4gIGNvbnN0IHsgZGFpbHlEYXRhLCBmb3JlY2FzdCwgdHJhaW5pbmdEYXRhLCBkYXlzSW5wdXQsIHNldERheXNJbnB1dCB9ID0gdXNlQnJhaW5Db250ZXh0KCk7XG5cbiAgY29uc3QgaGFuZGxlRm9yZWNhc3QgPSAoZSkgPT4ge1xuICAgIGNvbnNvbGUubG9nKGRheXNJbnB1dClcbiAgICBmb3JlY2FzdCh0cmFpbmluZ0RhdGEsIHBhcnNlSW50KGRheXNJbnB1dCwgMTApKVxuICB9XG5cbiAgcmV0dXJuIChcbiAgICA8RmxleCBkaXJlY3Rpb249J2NvbHVtbicgd2lkdGg9JzEwMHZ3JyBqdXN0aWZ5Q29udGVudD0nY2VudGVyJyA+XG4gICAgICA8RmxleCBkaXJlY3Rpb249J2NvbHVtbicgYWxpZ25JdGVtcz0nY2VudGVyJz5cbiAgICAgICAgPEhlYWRpbmcgbT17NX0gc2l6ZT0neGwnPkhvdyBtYW55IGRheXMgYWhlYWQgd291bGQgeW91IGxpa2UgdG8gcHJlZGljdD8gPC9IZWFkaW5nPlxuICAgICAgICA8VGV4dCBtbD17MTB9IG1iPXs1fSBzaXplPSdtZCc+VGV4dGluaG8gZXhwbGljYW5kbyBjb2lzYSBib2FcbiAgICAgICAgVGV4dGluaG8gZXhwbGljYW5kbyBjb2lzYSBib2FcbiAgICAgICAgVGV4dGluaG8gZXhwbGljYW5kbyBjb2lzYSBib2FcbiAgICAgICAgVGV4dGluaG8gZXhwbGljYW5kbyBjb2lzYSBib2FcbiAgICAgICAgVGV4dGluaG8gZXhwbGljYW5kbyBjb2lzYSBib2FcbiAgICAgICAgVGV4dGluaG8gZXhwbGljYW5kbyBjb2lzYSBib2FcbiAgICAgICAgVGV4dGluaG8gZXhwbGljYW5kbyBjb2lzYSBib2FcbiAgICAgICAgVGV4dGluaG8gZXhwbGljYW5kbyBjb2lzYSBib2FcbiAgICAgICAgVGV4dGluaG8gZXhwbGljYW5kbyBjb2lzYSBib2FcbiAgICAgICAgPC9UZXh0PlxuICAgICAgICA8RmxleD5cbiAgICAgICAgICA8SW5wdXRcbiAgICAgICAgICAgIHdpZHRoPScyMDBweCdcbiAgICAgICAgICAgIHBsYWNlaG9sZGVyPSdEYXlzIHRvIHByZWRpY3QnXG4gICAgICAgICAgICB0eXBlPSdudW1iZXInXG4gICAgICAgICAgICB2YWx1ZT17ZGF5c0lucHV0fVxuICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXREYXlzSW5wdXQoZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgIC8+XG4gICAgICAgICAgPEJ1dHRvbiBkaXNhYmxlZD17ZGF5c0lucHV0ID09PSBcIlwifSBtbD0nMS41JyBvbkNsaWNrPXtoYW5kbGVGb3JlY2FzdH0+VHJhaW4gQUk8L0J1dHRvbj5cbiAgICAgICAgPC9GbGV4PlxuICAgICAgPC9GbGV4PlxuICAgICAgPEJveD5cbiAgICAgICAgPENoYXJ0IGRhaWx5RGF0YT17ZGFpbHlEYXRhfSAvPlxuICAgICAgPC9Cb3g+XG4gICAgPC9GbGV4PlxuICApO1xufVxuXG5leHBvcnQgZGVmYXVsdCBEYXNoYm9hcmQ7IiwiaW1wb3J0IHsgY3JlYXRlQ29udGV4dCwgRGlzcGF0Y2gsIFNldFN0YXRlQWN0aW9uLCB1c2VDb250ZXh0LCB1c2VFZmZlY3QsIHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgeyBmZXRjaERhaWx5RGF0YSwgZmV0Y2hHbG9iYWxEYXRhIH0gZnJvbSBcIi4uL3NlcnZpY2VzL2FwaVwiO1xuaW1wb3J0ICogYXMgYnJhaW4gZnJvbSAnYnJhaW4uanMnO1xuLy8gaW1wb3J0IHNjYWxlciBmcm9tICdtaW5tYXhzY2FsZXInXG5pbXBvcnQgc2NhbGVyIGZyb20gJy4uL3V0aWxzL3NjYWxlcidcblxudHlwZSBEYWlseURhdGEgPSB7XG4gIHBvc2l0aXZlOiBudW1iZXIsXG4gIHJlY292ZXJlZDogbnVtYmVyLFxuICBkZWF0aDogbnVtYmVyLFxuICBkYXRlOiBzdHJpbmdcbn1cblxudHlwZSBUcmFpbmluZ0RhdGEgPSB7XG4gIGNvbmZpcm1lZDogbnVtYmVyLFxuICByZWNvdmVyZWQ6IG51bWJlcixcbiAgZGVhdGhzOiBudW1iZXIsXG4gIGRhdGU6IHN0cmluZ1xufVxuXG50eXBlIFRyYWluaW5nQ2hhcnQgPSB7XG4gIGRhdGE6IHtcbiAgICBsYWJlbHM6IHN0cmluZ1tdO1xuICAgIGRhdGFzZXRzOiAoe1xuICAgICAgICBkYXRhOiBudW1iZXJbXTtcbiAgICAgICAgbGFiZWw6IHN0cmluZztcbiAgICAgICAgYm9yZGVyQ29sb3I6IHN0cmluZztcbiAgICAgICAgYmFja2dyb3VuZENvbG9yOiBzdHJpbmc7XG4gICAgICAgIGZpbGw/OiB1bmRlZmluZWQ7XG4gICAgfSB8IHtcbiAgICAgICAgZGF0YTogbnVtYmVyW107XG4gICAgICAgIGxhYmVsOiBzdHJpbmc7XG4gICAgICAgIGJvcmRlckNvbG9yOiBzdHJpbmc7XG4gICAgICAgIGJhY2tncm91bmRDb2xvcjogc3RyaW5nO1xuICAgICAgICBmaWxsOiBib29sZWFuO1xuICAgIH0pW107XG4gIH07XG4gIG9wdGlvbnM6IHtcbiAgICByZXNwb25zaXZlOiBib29sZWFuLFxuICAgIHBsdWdpbnM6IHtcbiAgICAgIGxlZ2VuZDoge1xuICAgICAgICBwb3NpdGlvbjogYW55LFxuICAgICAgfSxcbiAgICAgIHRpdGxlOiB7XG4gICAgICAgIGRpc3BsYXk6IGJvb2xlYW4sXG4gICAgICAgIHRleHQ6IHN0cmluZyxcbiAgICAgIH0sXG4gICAgfVxuICB9O1xufVxuXG50eXBlIFByZWRpY3RlZENoYXJ0ID0ge1xuICBkYXRhOiB7XG4gICAgbGFiZWxzOiBudW1iZXJbXTtcbiAgICBkYXRhc2V0czoge1xuICAgICAgICBkYXRhOiBudW1iZXJbXTtcbiAgICAgICAgbGFiZWw6IHN0cmluZztcbiAgICAgICAgYm9yZGVyQ29sb3I6IHN0cmluZztcbiAgICAgICAgYmFja2dyb3VuZENvbG9yOiBzdHJpbmc7XG4gICAgfVtdO1xuICB9O1xuICBvcHRpb25zOiB7XG4gICAgICByZXNwb25zaXZlOiBib29sZWFuO1xuICAgICAgcGx1Z2luczoge1xuICAgICAgICAgIGxlZ2VuZDoge1xuICAgICAgICAgICAgICBwb3NpdGlvbjogYW55O1xuICAgICAgICAgIH07XG4gICAgICAgICAgdGl0bGU6IHtcbiAgICAgICAgICAgICAgZGlzcGxheTogYm9vbGVhbjtcbiAgICAgICAgICAgICAgdGV4dDogc3RyaW5nO1xuICAgICAgICAgIH07XG4gICAgICB9O1xuICB9O1xufVxuXG50eXBlIEJyYWluQ29udGV4dFR5cGUgPSB7XG4gIHRyYWluaW5nRGF0YTogVHJhaW5pbmdEYXRhW10sXG4gIHNldFRyYWluaW5nRGF0YTogRGlzcGF0Y2g8U2V0U3RhdGVBY3Rpb248VHJhaW5pbmdEYXRhW10+PixcbiAgc2V0RGFpbHlEYXRhOiBEaXNwYXRjaDxTZXRTdGF0ZUFjdGlvbjxEYWlseURhdGFbXT4+LFxuICBkYWlseURhdGE6IERhaWx5RGF0YVtdLFxuICB0cmFpbmluZ0NoYXJ0RGF0YTogVHJhaW5pbmdDaGFydCxcbiAgcHJlZGljdGVkQ2hhcnREYXRhOiBQcmVkaWN0ZWRDaGFydCxcbiAgZm9yZWNhc3Q6IChkYXRhOiBUcmFpbmluZ0RhdGFbXSwgZGF5czogbnVtYmVyKSA9PiB2b2lkLFxuICBkYXlzSW5wdXQ6IHN0cmluZyxcbiAgc2V0RGF5c0lucHV0OiBEaXNwYXRjaDxTZXRTdGF0ZUFjdGlvbjxzdHJpbmc+PixcbiAgcHJlZGljdGlvbjogbnVtYmVyW10sXG4gIHRyYWluaW5nOiBib29sZWFuXG59XG5cbmV4cG9ydCBjb25zdCBCcmFpbkNvbnRleHQgPSBjcmVhdGVDb250ZXh0KHt9IGFzIEJyYWluQ29udGV4dFR5cGUpXG5cbmV4cG9ydCBjb25zdCBCcmFpblByb3ZpZGVyID0gKHsgY2hpbGRyZW4gfSkgPT4ge1xuXG4gIGNvbnN0IFt0cmFpbmluZywgc2V0VHJhaW5pbmddID0gdXNlU3RhdGUoZmFsc2UpXG4gIGNvbnN0IFtkYWlseURhdGEsIHNldERhaWx5RGF0YV0gPSB1c2VTdGF0ZTxEYWlseURhdGFbXT4oW10pXG4gIGNvbnN0IFtnbG9iYWxEYXRhLCBzZXRHbG9iYWxEYXRhXSA9IHVzZVN0YXRlKHt9KVxuICBjb25zdCBbdHJhaW5pbmdEYXRhLCBzZXRUcmFpbmluZ0RhdGFdID0gdXNlU3RhdGU8VHJhaW5pbmdEYXRhW10+KFtdKVxuXG4gIGNvbnN0IFtkYXlzSW5wdXQsIHNldERheXNJbnB1dF0gPSB1c2VTdGF0ZSgnJylcbiAgY29uc3QgW3ByZWRpY3Rpb24sIHNldFByZWRpY3Rpb25dID0gdXNlU3RhdGUoW10pO1xuXG4gIGNvbnN0IHByZWRpY3RlZENoYXJ0RGF0YSA9IHtcbiAgICBkYXRhOiB7XG4gICAgICBsYWJlbHM6IHByZWRpY3Rpb24ubWFwKCggbiwgaW5kZXggKSA9PiBpbmRleCksXG4gICAgICBkYXRhc2V0czogW3tcbiAgICAgICAgZGF0YTogcHJlZGljdGlvbi5tYXAoKGRhdGEpID0+IGRhdGEpLFxuICAgICAgICBsYWJlbDogJ0luZmVjdGVkJyxcbiAgICAgICAgYm9yZGVyQ29sb3I6ICdyZ2IoNTMsIDE2MiwgMjM1KScsXG4gICAgICAgIGJhY2tncm91bmRDb2xvcjogJ3JnYmEoNTMsIDE2MiwgMjM1LCAwLjUpJyxcbiAgICAgIH1dLFxuICAgIH0sXG4gICAgb3B0aW9uczoge1xuICAgICAgcmVzcG9uc2l2ZTogdHJ1ZSxcbiAgICAgIHBsdWdpbnM6IHtcbiAgICAgICAgbGVnZW5kOiB7XG4gICAgICAgICAgcG9zaXRpb246ICd0b3AnIGFzIGNvbnN0LFxuICAgICAgICB9LFxuICAgICAgICB0aXRsZToge1xuICAgICAgICAgIGRpc3BsYXk6IHRydWUsXG4gICAgICAgICAgdGV4dDogJ1lvdXIgQ292aWQtMTkgaW5mZWN0aW9uIGZvcmVjYXN0aW5nJyxcbiAgICAgICAgfSxcbiAgICAgIH1cbiAgICB9XG4gIH1cblxuICBjb25zdCB0cmFpbmluZ0NoYXJ0RGF0YSA9IHtcbiAgICBkYXRhOiB7XG4gICAgICBsYWJlbHM6IHRyYWluaW5nRGF0YS5tYXAoKHsgZGF0ZSB9KSA9PiBuZXcgRGF0ZShkYXRlKS50b0xvY2FsZURhdGVTdHJpbmcoKSksXG4gICAgICBkYXRhc2V0czogW3tcbiAgICAgICAgZGF0YTogdHJhaW5pbmdEYXRhLm1hcCgoZGF0YSkgPT4gZGF0YS5jb25maXJtZWQpLFxuICAgICAgICBsYWJlbDogJ0luZmVjdGVkJyxcbiAgICAgICAgYm9yZGVyQ29sb3I6ICdyZ2IoNTMsIDE2MiwgMjM1KScsXG4gICAgICAgIGJhY2tncm91bmRDb2xvcjogJ3JnYmEoNTMsIDE2MiwgMjM1LCAwLjUpJyxcbiAgICAgIH0sIHtcbiAgICAgICAgZGF0YTogdHJhaW5pbmdEYXRhLm1hcCgoZGF0YSkgPT4gZGF0YS5kZWF0aHMpLFxuICAgICAgICBsYWJlbDogJ0RlYXRocycsXG4gICAgICAgIGJvcmRlckNvbG9yOiAncmdiKDI1NSwgOTksIDEzMiknLFxuICAgICAgICBiYWNrZ3JvdW5kQ29sb3I6ICdyZ2JhKDI1NSwgOTksIDEzMiwgMC41KScsXG4gICAgICB9XSxcbiAgICB9LFxuICAgIG9wdGlvbnM6IHtcbiAgICAgIHJlc3BvbnNpdmU6IHRydWUsXG4gICAgICBwbHVnaW5zOiB7XG4gICAgICAgIGxlZ2VuZDoge1xuICAgICAgICAgIHBvc2l0aW9uOiAndG9wJyBhcyBjb25zdCxcbiAgICAgICAgfSxcbiAgICAgICAgdGl0bGU6IHtcbiAgICAgICAgICBkaXNwbGF5OiB0cnVlLFxuICAgICAgICAgIHRleHQ6ICdBSSB0cmFpbmluZyBkYXRhJyxcbiAgICAgICAgfSxcbiAgICAgIH1cbiAgICB9XG4gIH1cblxuICBjb25zdCBmb3JlY2FzdCA9ICh0cmFpbmluZ0RhdGE6IFRyYWluaW5nRGF0YVtdLCBkYXlzSW5wdXQ6IG51bWJlcikgPT4ge1xuICAgIHNldFRyYWluaW5nKHRydWUpXG5cbiAgICBjb25zdCBuZXdUcmFpbmluZ0RhdGEgPSBuZXcgQXJyYXkoNTApLmZpbGwoMClcblxuICAgIGlmICh0cmFpbmluZ0RhdGEpIHtcbiAgICAgIGZvcihsZXQgaSA9IDA7IGkgPD0gNTA7IGkgKyspIHtcbiAgICAgICAgbmV3VHJhaW5pbmdEYXRhW2ldID0gdHJhaW5pbmdEYXRhW3RyYWluaW5nRGF0YS5sZW5ndGggLSA1MSArIGldPy5jb25maXJtZWRcbiAgICAgIH1cbiAgICB9XG5cbiAgICBjb25zdCBzY2FsZWREYXRhID0gc2NhbGVyLmZpdF90cmFuc2Zvcm0obmV3VHJhaW5pbmdEYXRhKTtcblxuICAgIGNvbnN0IG5ldHdvcmsgPSBuZXcgYnJhaW4ucmVjdXJyZW50LkxTVE1UaW1lU3RlcCh7XG4gICAgICBpbnB1dFNpemU6IDEsXG4gICAgICBoaWRkZW5MYXllcnM6IFsxMF0sXG4gICAgICBvdXRwdXRTaXplOiAxXG4gICAgfSlcblxuICAgIG5ldHdvcmsudHJhaW4oW3NjYWxlZERhdGFdLCB7XG4gICAgICBsZWFybmluZ1JhdGU6IDAuMDA1LFxuICAgICAgZXJyb3JUaHJlc2g6IDAuMDEsXG4gICAgICBsb2c6IHN0YXRzID0+IHtcbiAgICAgICAgY29uc29sZS5sb2coc3RhdHMpO1xuICAgICAgfVxuICAgIH0pXG5cbiAgICBjb25zdCByZXN1bHQgPSBuZXR3b3JrLmZvcmVjYXN0KFsxXSwgZGF5c0lucHV0KVxuICAgIHNldFByZWRpY3Rpb24oc2NhbGVyLmludmVyc2VfdHJhbnNmb3JtKHJlc3VsdCkpXG4gICAgc2V0VHJhaW5pbmcoZmFsc2UpXG4gIH1cblxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGNvbnN0IGxvYWREYWlseURhdGEgPSBhc3luYyAoKSA9PiB7XG4gICAgICBjb25zdCBpbml0aWFsRGFpbHlEYXRhID0gYXdhaXQgZmV0Y2hEYWlseURhdGEoKVxuXG4gICAgICBpZiAoaW5pdGlhbERhaWx5RGF0YSkge1xuICAgICAgICBzZXREYWlseURhdGEoaW5pdGlhbERhaWx5RGF0YSk7XG4gICAgICB9XG4gICAgfVxuXG4gICAgY29uc3QgbG9hZEdsb2JhbERhdGEgPSBhc3luYyAoKSA9PiB7XG4gICAgICBjb25zdCBnbG9iYWxEYXRhID0gYXdhaXQgZmV0Y2hHbG9iYWxEYXRhKClcbiAgICAgIGlmIChnbG9iYWxEYXRhKSB7XG4gICAgICAgIHNldEdsb2JhbERhdGEoZ2xvYmFsRGF0YSlcbiAgICAgIH1cbiAgICB9XG5cbiAgICBsb2FkRGFpbHlEYXRhKClcbiAgICBsb2FkR2xvYmFsRGF0YSgpXG4gIH0sIFtdKVxuXG4gIHJldHVybiAoXG4gICAgPEJyYWluQ29udGV4dC5Qcm92aWRlclxuICAgICAgdmFsdWU9e3tcbiAgICAgICAgdHJhaW5pbmdEYXRhLFxuICAgICAgICBzZXRUcmFpbmluZ0RhdGEsXG4gICAgICAgIHNldERhaWx5RGF0YSxcbiAgICAgICAgZGFpbHlEYXRhLFxuICAgICAgICB0cmFpbmluZ0NoYXJ0RGF0YSxcbiAgICAgICAgZm9yZWNhc3QsXG4gICAgICAgIGRheXNJbnB1dCxcbiAgICAgICAgc2V0RGF5c0lucHV0LFxuICAgICAgICBwcmVkaWN0aW9uLFxuICAgICAgICBwcmVkaWN0ZWRDaGFydERhdGEsXG4gICAgICAgIHRyYWluaW5nXG4gICAgICB9fVxuICAgID5cbiAgICAgIHtjaGlsZHJlbn1cbiAgICA8L0JyYWluQ29udGV4dC5Qcm92aWRlcj5cbiAgKTtcbn1cblxuLy9lYXNpZXIgZXhwb3J0XG5leHBvcnQgY29uc3QgdXNlQnJhaW5Db250ZXh0ID0gKCkgPT4gdXNlQ29udGV4dChCcmFpbkNvbnRleHQpO1xuIiwiaW1wb3J0IGF4aW9zIGZyb20gJ2F4aW9zJ1xuXG5leHBvcnQgY29uc3QgYXBpID0gYXhpb3MuY3JlYXRlKHtcbiAgYmFzZVVSTDogJ2h0dHBzOi8vY292aWQtMTktc3RhdGlzdGljcy5wLnJhcGlkYXBpLmNvbS9yZXBvcnRzJ1xufSlcblxuYXBpLmRlZmF1bHRzLmhlYWRlcnNbJ3gtcmFwaWRhcGktaG9zdCddID0gJ2NvdmlkLTE5LXN0YXRpc3RpY3MucC5yYXBpZGFwaS5jb20nO1xuYXBpLmRlZmF1bHRzLmhlYWRlcnNbJ3gtcmFwaWRhcGkta2V5J10gPSAnMGI4Yjg4Mjk5ZG1zaDYzM2QxNzdiNDgzMGJiMnAxZjRlNjJqc245YTQxMGM3ZTkxZmMnXG5cbmFwaS5pbnRlcmNlcHRvcnMucmVxdWVzdC51c2UoY29uZmlnID0+IHtcbiAgY29uc29sZS5sb2coY29uZmlnKTtcbiAgcmV0dXJuIGNvbmZpZztcbn0pO1xuXG5leHBvcnQgY29uc3QgZmV0Y2hHbG9iYWxEYXRhID0gYXN5bmMgKCkgPT4ge1xuICB0cnkge1xuICAgIGNvbnN0IHsgZGF0YSB9ID0gYXdhaXQgYXBpLmdldCgnL3RvdGFsJyk7XG4gICAgcmV0dXJuIGRhdGE7XG4gIH0gY2F0Y2ggKGVycikge1xuICAgIHJldHVybiBlcnI7XG4gIH1cbn1cblxuZXhwb3J0IGNvbnN0IGZldGNoRGFpbHlEYXRhID0gYXN5bmMgKCkgPT4ge1xuICB0cnkge1xuICAgIGNvbnN0IHsgZGF0YSB9ID0gYXdhaXQgYXhpb3MuZ2V0KCdodHRwczovL2FwaS5jb3ZpZHRyYWNraW5nLmNvbS92MS91cy9kYWlseS5qc29uJyk7XG5cbiAgICByZXR1cm4gZGF0YS5tYXAoKHsgcG9zaXRpdmUsIHJlY292ZXJlZCwgZGVhdGgsIGRhdGVDaGVja2VkOiBkYXRlIH0pID0+ICh7IGNvbmZpcm1lZDogcG9zaXRpdmUsIHJlY292ZXJlZCwgZGVhdGhzOiBkZWF0aCwgZGF0ZSB9KSk7XG4gIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgcmV0dXJuIGVycm9yO1xuICB9XG59OyIsImxldCBYX21pbiA9IDA7XG5sZXQgWF9tYXggPSAwO1xubGV0IG1pbl8gPSAwO1xubGV0IG1heF8gPSAxO1xuXG5sZXQgZGF0YSA9IHsgWF9tYXg6IFhfbWF4LCBYX21pbjogWF9taW4sIG1heF86IG1heF8sIG1pbl86IG1pbl8gfTtcblxuZnVuY3Rpb24gZml0KFgsIG1pbiA9IDAsIG1heCA9IDEpIHtcbiAgWF9tYXggPSBNYXRoLm1heC5hcHBseShudWxsLCBYKTtcbiAgWF9taW4gPSBNYXRoLm1pbi5hcHBseShudWxsLCBYKTtcbiAgbWluXyA9IG1pbjtcbiAgbWF4XyA9IG1heDtcblxuICBkYXRhID0geyBYX21heDogWF9tYXgsIFhfbWluOiBYX21pbiwgbWF4XzogbWF4XywgbWluXzogbWluXyB9O1xuXG4gIGNvbnN0IFhfbWluQXJyID0gWC5tYXAoZnVuY3Rpb24gKHZhbHVlcykge1xuICAgIHJldHVybiB2YWx1ZXMgLSBYX21pbjtcbiAgfSk7XG4gIC8vIFhfc3RkID0gKFggLSBYLm1pbigpKSAvIChYLm1heCgpIC0gWC5taW4oKSlcbiAgY29uc3QgWF9zdGQgPSBYX21pbkFyci5tYXAoZnVuY3Rpb24gKHZhbHVlcykge1xuICAgIHJldHVybiB2YWx1ZXMgLyAoWF9tYXggLSBYX21pbik7XG4gIH0pO1xuICAvLyBYX3NjYWxlZCA9IFhfc3RkICogKG1heCAtIG1pbikgKyBtaW5cbiAgY29uc3QgWF9zY2FsZWQgPSBYX3N0ZC5tYXAoZnVuY3Rpb24gKHZhbHVlcykge1xuICAgIHJldHVybiB2YWx1ZXMgKiAobWF4IC0gbWluKSArIG1pbjtcbiAgfSk7XG5cbiAgcmV0dXJuIFhfc2NhbGVkO1xufVxuXG5mdW5jdGlvbiBmaXRfdHJhbnNmb3JtKGRhdGEsIG1pbiA9IDAsIG1heCA9IDEpIHtcbiAgY29uc3QgdHJhaW5fc2NhbGVkID0gZml0KGRhdGEsIG1pbiwgbWF4KTtcblxuXG4gIHJldHVybiB0cmFpbl9zY2FsZWQ7XG59XG5cbmZ1bmN0aW9uIGludmVyc2VfdHJhbnNmb3JtKGlucHV0LCBtaW4gPSAwLCBtYXggPSAxKSB7XG4gIGNvbnN0IGZpdCA9IGRhdGE7XG4gIGNvbnNvbGUubG9nKGZpdClcblxuICBjb25zdCBYID0gaW5wdXQubWFwKGZ1bmN0aW9uICh2YWx1ZXMpIHtcbiAgICByZXR1cm4gKHZhbHVlcyAtIG1pbikgLyAobWF4IC0gbWluKTtcbiAgfSk7XG4gIGNvbnN0IFhfID0gWC5tYXAoZnVuY3Rpb24gKHZhbHVlcykge1xuICAgIHJldHVybiB2YWx1ZXMgKiAoZml0LlhfbWF4IC0gZml0LlhfbWluKSArIGZpdC5YX21pbjtcbiAgfSk7XG5cbiAgcmV0dXJuIFhfO1xufVxuXG5leHBvcnQgZGVmYXVsdCB7IGZpdF90cmFuc2Zvcm0sIGludmVyc2VfdHJhbnNmb3JtIH07IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwiQGNoYWtyYS11aS9yZWFjdFwiKTsiLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJheGlvc1wiKTsiLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJjaGFydC5qc1wiKTsiLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJncHUuanNcIik7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwicmVhY3RcIik7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwicmVhY3QtY2hhcnRqcy0yXCIpOyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcInJlYWN0L2pzeC1kZXYtcnVudGltZVwiKTsiLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJzdHJlYW1cIik7Il0sIm5hbWVzIjpbIlJlYWN0IiwiRGFzaGJvYXJkIiwiSG9tZSIsIkZsZXgiLCJTcGlubmVyIiwidXNlRWZmZWN0IiwiQ2hhcnQiLCJDaGFydEpTIiwiQ2F0ZWdvcnlTY2FsZSIsIkxpbmVhclNjYWxlIiwiUG9pbnRFbGVtZW50IiwiTGluZUVsZW1lbnQiLCJUaXRsZSIsIlRvb2x0aXAiLCJMZWdlbmQiLCJMaW5lIiwidXNlQnJhaW5Db250ZXh0IiwicmVnaXN0ZXIiLCJkYWlseURhdGEiLCJzZXRUcmFpbmluZ0RhdGEiLCJ0cmFpbmluZ0NoYXJ0RGF0YSIsInByZWRpY3RlZENoYXJ0RGF0YSIsInRyYWluaW5nIiwicmV2ZXJzZSIsIm9wdGlvbnMiLCJkYXRhIiwiQm94IiwiQnV0dG9uIiwiSGVhZGluZyIsIklucHV0IiwiVGV4dCIsImZvcmVjYXN0IiwidHJhaW5pbmdEYXRhIiwiZGF5c0lucHV0Iiwic2V0RGF5c0lucHV0IiwiaGFuZGxlRm9yZWNhc3QiLCJlIiwiY29uc29sZSIsImxvZyIsInBhcnNlSW50IiwidGFyZ2V0IiwidmFsdWUiLCJjcmVhdGVDb250ZXh0IiwidXNlQ29udGV4dCIsInVzZVN0YXRlIiwiZmV0Y2hEYWlseURhdGEiLCJmZXRjaEdsb2JhbERhdGEiLCJicmFpbiIsInNjYWxlciIsIkJyYWluQ29udGV4dCIsIkJyYWluUHJvdmlkZXIiLCJjaGlsZHJlbiIsInNldFRyYWluaW5nIiwic2V0RGFpbHlEYXRhIiwiZ2xvYmFsRGF0YSIsInNldEdsb2JhbERhdGEiLCJwcmVkaWN0aW9uIiwic2V0UHJlZGljdGlvbiIsImxhYmVscyIsIm1hcCIsIm4iLCJpbmRleCIsImRhdGFzZXRzIiwibGFiZWwiLCJib3JkZXJDb2xvciIsImJhY2tncm91bmRDb2xvciIsInJlc3BvbnNpdmUiLCJwbHVnaW5zIiwibGVnZW5kIiwicG9zaXRpb24iLCJ0aXRsZSIsImRpc3BsYXkiLCJ0ZXh0IiwiZGF0ZSIsIkRhdGUiLCJ0b0xvY2FsZURhdGVTdHJpbmciLCJjb25maXJtZWQiLCJkZWF0aHMiLCJuZXdUcmFpbmluZ0RhdGEiLCJBcnJheSIsImZpbGwiLCJpIiwibGVuZ3RoIiwic2NhbGVkRGF0YSIsImZpdF90cmFuc2Zvcm0iLCJuZXR3b3JrIiwicmVjdXJyZW50IiwiTFNUTVRpbWVTdGVwIiwiaW5wdXRTaXplIiwiaGlkZGVuTGF5ZXJzIiwib3V0cHV0U2l6ZSIsInRyYWluIiwibGVhcm5pbmdSYXRlIiwiZXJyb3JUaHJlc2giLCJzdGF0cyIsInJlc3VsdCIsImludmVyc2VfdHJhbnNmb3JtIiwibG9hZERhaWx5RGF0YSIsImluaXRpYWxEYWlseURhdGEiLCJsb2FkR2xvYmFsRGF0YSIsImF4aW9zIiwiYXBpIiwiY3JlYXRlIiwiYmFzZVVSTCIsImRlZmF1bHRzIiwiaGVhZGVycyIsImludGVyY2VwdG9ycyIsInJlcXVlc3QiLCJ1c2UiLCJjb25maWciLCJnZXQiLCJlcnIiLCJwb3NpdGl2ZSIsInJlY292ZXJlZCIsImRlYXRoIiwiZGF0ZUNoZWNrZWQiLCJlcnJvciIsIlhfbWluIiwiWF9tYXgiLCJtaW5fIiwibWF4XyIsImZpdCIsIlgiLCJtaW4iLCJtYXgiLCJNYXRoIiwiYXBwbHkiLCJYX21pbkFyciIsInZhbHVlcyIsIlhfc3RkIiwiWF9zY2FsZWQiLCJ0cmFpbl9zY2FsZWQiLCJpbnB1dCIsIlhfIl0sInNvdXJjZVJvb3QiOiIifQ==